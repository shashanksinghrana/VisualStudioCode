import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FooterComponent } from './modules/structural/footer/footer.component';
import { GenericDropdownComponent } from './modules/form/generic-dropdown/generic-dropdown.component';
import { GenericDatepickerComponent } from './modules/form/generic-datepicker/generic-datepicker.component';
import { GridComponent } from './modules/elements/grid/grid.component';
import { HeaderComponent } from './modules/structural/header/header.component';
import { HowToComponent } from './c2c-main/how-to/how-to.component';
import { NameSearchComponent } from './modules/name-search/name-search.component';
import { NoteComponent } from './modules/form/note/note.component';
import { SidebarComponent } from './modules/structural/sidebar/sidebar.component';
import { WelcomeComponent } from './c2c-main/welcome/welcome.component';
import { ButtonComponent } from './modules/elements/button/button.component';
import { AuditComponent } from './modules/elements/audit/audit.component';
import { GenericInputComponent } from './modules/form/generic-input/generic-input.component';
import { LabelComponent } from './modules/form/label/label.component';
import { FormRadioButtonComponent } from './modules/form/form-radio-button/form-radio-button.component';
import { FormCheckboxComponent } from './modules/form/form-checkbox/form-checkbox.component';
import { WizardComponent } from './modules/structural/wizard/wizard.component';
import { FormDropdownComponent } from './modules/form/form-dropdown/form-dropdown.component';
import { FormDatepickerComponent } from './modules/form/form-datepicker/form-datepicker.component';
import { ExampleReactiveFormComponent } from './c2c-main/examples/example-reactive-form/example-reactive-form.component';
import { ImageUploaderComponent } from './modules/elements/image-uploader/imageUploader.component';
import { LoadingSpinnerComponent } from './modules/elements/loading-spinner/loading-spinner/loading-spinner.component';
import { PowersearchComponent } from './modules/structural/powersearch/powersearch.component';
import { DropdownTypeAheadComponent } from './modules/elements/dropdown-typeahead/dropdown-typeahead.component';
import { FileUploaderComponent } from './modules/elements/file-uploader/file-uploader.component';
import { PeopleComponent } from './modules/people/people.component';
import { CompanyComponent } from './modules/company/company.component';
import { FormJQDatepickerComponent } from './modules/form/form-jqdatePicker/form-jqdatepicker.component';

/**
 * Defines the routes for navigation to each Component in the Library.
 */
const appRoutes: Routes = [
  { path: 'welcome', component: WelcomeComponent },
  { path: 'howTo', component: HowToComponent },
  { path: 'example-reactive-form', component: ExampleReactiveFormComponent },
  { path: 'header', component: HeaderComponent },
  { path: 'footer', component: FooterComponent },
  { path: 'sidebar', component: SidebarComponent },
  { path: 'powersearch', component: PowersearchComponent },
  { path: 'wizard', component: WizardComponent },
  { path: 'wizard/:id', component: WizardComponent, children: [
    { path: 'nameProjectDetails', component: FooterComponent },
    { path: 'summary', component: HowToComponent }
  ] },
  { path: 'formJQDatepickerComponent', component: FormJQDatepickerComponent },
  { path: 'grid', component: GridComponent },
  { path: 'typeAhead', component: NameSearchComponent },
  { path: 'note', component: NoteComponent },
  { path: 'dropdown', component: GenericDropdownComponent },
  { path: 'dropdown-reactive', component: FormDropdownComponent },
  { path: 'datepicker', component: GenericDatepickerComponent },
  { path: 'datepicker-reactive', component: FormDatepickerComponent },
  { path: 'buttons', component: ButtonComponent },
  { path: 'audit', component: AuditComponent },
  { path: 'input', component: GenericInputComponent },
  { path: 'label', component: LabelComponent },
  { path: 'radioButton', component: FormRadioButtonComponent },
  { path: 'checkbox', component: FormCheckboxComponent },
  { path: 'imageUploader', component: ImageUploaderComponent },
  { path: 'fileUploader', component: FileUploaderComponent },
  { path: 'loadingSpinner', component: LoadingSpinnerComponent },
  { path: 'people', component: PeopleComponent},
  { path: 'companies', component: CompanyComponent}, 
  // { path: 'talent', component: TalentComponent },
  { path: 'dropdDownTypeAhead', component: DropdownTypeAheadComponent},
  { path: '', redirectTo: 'welcome', pathMatch: 'full' }
];

/**
 * The AppRoutingModule
 *
 * Contains the routing information for the Common Library.
 */
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
