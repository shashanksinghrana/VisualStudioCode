import { GridLinkTitleModelModule } from './grid-link-title-model.module';

describe('GridLinkTitleModelModule', () => {
  let gridLinkTitleModelModule: GridLinkTitleModelModule;

  beforeEach(() => {
    gridLinkTitleModelModule = new GridLinkTitleModelModule();
  });

  it('should create an instance', () => {
    expect(gridLinkTitleModelModule).toBeTruthy();
  });
});
