import { Directive, AfterViewInit, ElementRef, Input } from '@angular/core';
import { DropdownModel } from "../dropdown/dropdown.model";
import { TypeAheadDisplayResultModel } from '../type-ahead/type-ahead-display-result.model';
import { PeopleModel } from './data-model/people-model';
import { IPeople } from '../../interfaces/people/ipeople';
import { DropdownTypeAheadModel } from "../../models/dropdown-typeahead/dropdown-typeahead.model";
/**
 * The PeopleInputParamsModel
 * Model for passing necessary input parameters which is required for creating people Component.
 */
export class PeopleInputParamsModel implements IPeople {
  public peopleData: any;//PeopleModel;
  public occupationDropdown: DropdownTypeAheadModel;
  // public occupationDropdown: DropdownModel;
  public typeDropdown: DropdownTypeAheadModel;
  public peopleTypeAheadOptions: TypeAheadDisplayResultModel;
  public companyTypeAheadOptions: TypeAheadDisplayResultModel;
  public companyDropdown: DropdownModel;
  public entityTypeOptions: any[];
  public entityCompaniesTypeOptions: any[];
  public phoneDropdown: DropdownTypeAheadModel;
  public emailDropdown: DropdownTypeAheadModel;
  public socialMediaDropdown: DropdownTypeAheadModel;
  public assistantTypeAheadOptions: TypeAheadDisplayResultModel;
  public selectTypeAddDropdown: DropdownTypeAheadModel;
  public selectStateAddDropdown: DropdownTypeAheadModel;
  public selectCountryAddDropdown: DropdownTypeAheadModel;
  public service: {
    serviceClass: any,
    serviceAccentedClass: any,
    getCompanyDetailsFromDb: string,
    getStateListFromDb: string,
    saveParty: string,
    saveAlias: string,
    getTalentDetails: string,
    getaccentedCharacters: string,
    saveCompanyAlias: string,
    saveCompany: string,
    saveLocationCompanies: string,
    getNames: string
  };
  public peopleTypeAheadService: {
    serviceClass: any,
    getPeopleDetailsFromDb: string
  };
  /**
   * Constructor for PeopleInputParamsModel
  //  * @param peopleData holds People Data json
  //  * @param occupationDropdown  holds occupation [id, value] json
  //  * @param typeDropdown holds type [id, value] json
  //  * @param peopleTypeAheadOptions holds people type ahead data json
  //  * @param companyTypeAheadOptions holds company type ahead data json
  //  * @param companyDropdown holds company locations [id, value] json
  //  * @param entityTypeOptions holds entity type - business or personal
  //  * @param entityCompaniesTypeOptions holds entity type - Companies, Film Project and TV series
  //  * @param phoneDropdown holds phone [id, value] json
  //  * @param emailDropdown holds email [id, value] json
  //  * @param socialMediaDropdown holds socialMediaType [id, value] json
  //  * @param assistantTypeAheadOptions holds assistant typeahead options json
  //  * @param selectTypeAddDropdown holds address [id, value] json
  //  * @param selectStateAddDropdown holds state [id, value] json
  //  * @param selectCountryAddDropdown holds country [id, value] json
  //  * @param service the service file to be mapped.
  //  * @param peopleTypeAheadService the people service file to be mapped.
   */
  constructor(peopleData: any,
    occupationDropdown: DropdownTypeAheadModel,
    typeDropdown: DropdownTypeAheadModel,
    peopleTypeAheadOptions: TypeAheadDisplayResultModel,
    companyTypeAheadOptions: TypeAheadDisplayResultModel,
    companyDropdown: DropdownModel,
    entityTypeOptions: any[],
    entityCompaniesTypeOptions: any[],
    phoneDropdown: DropdownTypeAheadModel,
    emailDropdown: DropdownTypeAheadModel,
    socialMediaDropdown: DropdownTypeAheadModel,
    assistantTypeAheadOptions: TypeAheadDisplayResultModel,
    selectTypeAddDropdown: DropdownTypeAheadModel,
    selectStateAddDropdown: DropdownTypeAheadModel,
    selectCountryAddDropdown: DropdownTypeAheadModel,
    service: any,
    peopleTypeAheadService: any
  ) {
    this.peopleData = peopleData;
    this.occupationDropdown = occupationDropdown;
    this.typeDropdown = typeDropdown;
    this.peopleTypeAheadOptions = peopleTypeAheadOptions;
    this.companyTypeAheadOptions = companyTypeAheadOptions;
    this.companyDropdown = companyDropdown;
    this.entityTypeOptions = entityTypeOptions;
    this.entityCompaniesTypeOptions = entityCompaniesTypeOptions;
    this.phoneDropdown = phoneDropdown;
    this.emailDropdown = emailDropdown;
    this.socialMediaDropdown = socialMediaDropdown;
    this.assistantTypeAheadOptions = assistantTypeAheadOptions;
    this.selectTypeAddDropdown = selectTypeAddDropdown;
    this.selectStateAddDropdown = selectStateAddDropdown;
    this.selectCountryAddDropdown = selectCountryAddDropdown;
    this.service = service;
    this.peopleTypeAheadService = peopleTypeAheadService;
  }
}