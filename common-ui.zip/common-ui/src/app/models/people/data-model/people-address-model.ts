export class PeopleAddressModel {

    public addressId: number;
    public locationName: string;
    public addressType: string;
    public addressTypeId: number;
    public firstLine: string;
    public secondLine: string;
    public thirdLine: string
    public city: string;
    public state: string;
    public stateId: string;
    public zip: string;
    public country: string;
    public countryId: string;
    public primary: boolean;
    public validAddress: boolean;

    constructor(
        addressId: number,
        locationName: string,
        addressType: string,
        addressTypeId: number,
        firstLine: string,
        secondLine: string,
        thirdLine: string,
        city: string,
        state: string,
        stateId: string,
        zip: string,
        country: string,
        countryId: string,
        primary: boolean,
        validAddress: boolean
    ) {
        this.addressId = addressId;
        this.locationName = locationName;
        this.addressType = addressType;
        this.addressTypeId = addressTypeId;
        this.firstLine = firstLine;
        this.secondLine = secondLine;
        this.thirdLine = thirdLine;
        this.city = city;
        this.state = state;
        this.stateId = stateId;
        this.zip = zip;
        this.country = country;
        this.countryId = countryId;
        this.primary = primary;
        this.validAddress = validAddress;
    }
}
