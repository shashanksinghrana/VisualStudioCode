export class PeopleModel {
  //var peoplJsonData = { "partyId": 1979476, "firstName": "Diane", "lastName": "Hardy", "imageURL": "http://localhost:4200/rc/dev/talent/party/1979476/image", "image": null, "createdBy": "default", "createdDate": "09/17/2018", "createdTime": "14:42", "updatedBy": "default", "updatedDate": "09/17/2018", "updatedTime": "14:42", "businessPersonal": "Business", "entityTypeId": 1121, "dob": "03/01/1983", "neverEmail": false, "notes": "A laudantium pariatur ea velit consequatur earum. Est molestias quibusdam ducimus sapiente. Labore quaerat aut omnis velit fugiat.", "types": [{ "id": 3620, "name": "Packaging", "typeId": 36, "partyId": 1979476 }], "addresses": [{ "addressId": 3088, "locationName": null, "addressType": "Vacation", "firstLine": "1322 Shepherd Heights", "secondLine": null, "thirdLine": null, "city": "Cairo", "state": "Virginia", "zip": "80204", "country": "USA", "primary": true }], "officeAddress": { "addressId": 2960, "locationName": "Castelbianco HQ", "addressType": null, "firstLine": "Ap #247-5924 Ridiculus Road", "secondLine": "Aptent Road", "thirdLine": null, "city": "Kearny", "state": "Alabama", "zip": "96219", "country": "USA", "primary": null }, "homeAddress": null, "socialMedia": [{ "id": 1040884, "contactId": 2293, "value": "#DianeHardy", "primary": true, "typeId": 1108, "type": "Facebook", "displayValue": "#DianeHardy - Facebook*" }], "deleteImage": false, "dataSet": null, "title": "Global Executive", "AKA": null, "phone": [{ "id": 1131558, "contactId": 2292, "value": "(802) 043-2112", "primary": true, "typeId": 1178, "type": "Home/Fax", "displayValue": "(802) 043-2112 - Home/Fax*" }], "email": [{ "id": 1040883, "contactId": 2291, "value": "bmosley@ma1lbox.com", "primary": true, "typeId": 1061, "type": "Home 2", "displayValue": "bmosley@ma1lbox.com - Home 2*" }], "occupations": [{ "id": 1704165, "occupationId": 271, "partyId": 1979476, "occupationName": "Supervising Producer" }], "assistants": [{ "relationId": 1396517, "parentPartyId": 1979476, "partyId": 1714639, "name": "SA, ERNESTINA", "primary": true, "relationType": null, "_links": { "self": { "href": "http://localhost:4200/rc/dev/talent/rollcall/person/1714639" } } }], "companies": [{ "partyId": 1979185, "companyName": "20th Century Fox Pictures", "locationId": 1893, "partyRelationId": 1396518, "primary": true, "location": { "addressId": 2960, "locationName": "Castelbianco HQ", "addressType": null, "firstLine": "Ap #247-5924 Ridiculus Road", "secondLine": "Aptent Road", "thirdLine": null, "city": "Kearny", "state": "Alabama", "zip": "96219", "country": "USA", "primary": null }, "_links": { "self": { "href": "http://localhost:4200/rc/dev/talent/rollcall/company/1979185" } } }] }

  public partyId: number;
  public firstName: string;
  public lastName: string;
  public imageURL: string;
  public image: any;
  public createdBy: string;
  public createdDate: string;
  public createdTime: string;
  public updatedBy: string;
  public updatedDate: string;
  public updatedTime: string;
  public businessPersonal: string;
  public entityTypeId: number;
  public dob: string;
  public neverEmail: boolean;
  public notes: string;
  public types: Array<Object>;//Object;
  public addresses: Array<Object>;
  public officeAddress: Object;
  public homeAddress: Object;
  public socialMedia: Array<Object>;
  public deleteImage: boolean;
  public dataSet: any;
  public title: string;
  public AKA: Array<Object>;
  public phone: Array<Object>;
  public email: Array<Object>;
  public occupations: Array<Object>;
  public assistants: Array<Object>;
  public companies: Array<Object>;

  constructor(
    partyId: number,
    firstName: string,
    lastName: string,
    imageURL: string,
    image: any,
    createdBy: string,
    createdDate: string,
    createdTime: string,
    updatedBy: string,
    updatedDate: string,
    updatedTime: string,
    businessPersonal: string,
    entityTypeId: number,
    dob: string,
    neverEmail: boolean,
    notes: string,
    types: Array<Object>,
    addresses: Array<Object>,
    officeAddress: Object,
    homeAddress: Object,
    socialMedia: Array<Object>,
    deleteImage: boolean,
    dataSet: any,
    title: string,
    AKA: Array<Object>,
    phone: Array<Object>,
    email: Array<Object>,
    occupations: Array<Object>,
    assistants: Array<Object>,
    companies: Array<Object>
  ) {
    this.partyId = partyId;
    this.firstName = firstName;
    this.lastName = lastName;
    this.imageURL = imageURL;
    this.image = image;
    this.createdBy = createdBy;
    this.createdDate = createdDate;
    this.createdTime = createdTime;
    this.updatedBy = updatedBy;
    this.updatedDate = updatedDate;
    this.updatedTime = updatedTime;
    this.businessPersonal = businessPersonal;
    this.entityTypeId = entityTypeId;
    this.dob = dob;
    this.neverEmail = neverEmail;
    this.notes = notes;
    this.types = types;
    this.addresses = addresses;
    this.officeAddress = officeAddress;
    this.homeAddress = homeAddress;
    this.socialMedia = socialMedia;
    this.deleteImage = deleteImage;
    this.dataSet = dataSet;
    this.title = title;
    this.AKA = AKA;
    this.phone = phone;
    this.email = email;
    this.occupations = occupations;
    this.assistants = assistants;
    this.companies = companies;
  }
}
