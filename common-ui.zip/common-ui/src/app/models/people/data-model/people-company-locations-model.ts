export class PeopleCompanyLocationsModel {

    public partyId: number; //here company party id
    public companyName: string; 
    public locationId: number;
    public addedLocation: any; //selected location for that company
    public locationDropDownList:  any[]; // list of location exists for that company, (each location includes phone as well)
    public addedPhone: Array<Object>; // Phone list esi
    public primaryLocation: boolean;
    public primaryCompany: boolean; 
  
    constructor(
      partyId: number,
      companyName: string,
      locationId: number,
      addedLocation:any,
      locationDropDownList: any[], 
      addedPhone:  Array<Object>, 
      primaryLocation:boolean,
      primaryCompany:boolean
    ) { 
      this.partyId = partyId;
      this.companyName = companyName;
      this.locationId = locationId;
      this.addedLocation = addedLocation; 
      this.locationDropDownList = locationDropDownList;
      this.addedPhone = addedPhone;
      this.primaryLocation = primaryLocation;
      this.primaryCompany = primaryCompany;
    }  
  }
  //addedLocation : JSON Structure
    // "location": {
    //   "addressId": 4713,
    //   "locationName": "Kenya walters",
    //   "addressType": "OFFICE",
    //   "addressTypeId": 353,
    //   "firstLine": "Highlander street",
    //   "secondLine": "vrsova",
    //   "thirdLine": "walfort tower",
    //   "city": "Africa",
    //   "state": "Escaldes-Engordany",
    //   "zip": "123456",
    //   "country": "Andorra",
    //   "primary": null,
    //   "stateId": 3388,
    //   "countryId": "AD"
    // },


  //Each addedPhone : JSON Structure  : Array<Object>;
      //contactId: 1260532
      // displayValue: "3333 | Cell 1"
      // id: 1126733
      // primary: false
      // type: "Cell 1"
      // typeId: 91
      // value: "3333"