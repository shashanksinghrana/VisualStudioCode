import { Directive, HostListener, EventEmitter, Output } from '@angular/core';

/**
 * The PeopleOutputParamsModel
 * Model for passing necessary output parameters which need to be passed from People component.
 */
export class PeopleOutputParamsModel  {
    public peopleData: any;
    public validPeople?: boolean;

  /**
   * Constructor for PeopleOutputParamsModel
   * @param peopleData holds People Data json
   * @param validPeople  holds boolean that people data is valid after form validaion
   */
    constructor( peopleData: any, validPeople?: boolean) {
          this.peopleData = peopleData;
          this.validPeople = validPeople;
    }
  }