import { CompaniesDetailModel } from "./data-model/companies-detail-model";
import { DropdownModel } from "../dropdown/dropdown.model";
import { TypeAheadDisplayResultModel } from '../type-ahead/type-ahead-display-result.model';

/**
 * The CompanyInputParamsModel
 * Model for passing necessary input parameters which is required for creating Company Component.
 */
export class CompanyInputParamsModel  {
  public companyTypeAheadOptions: TypeAheadDisplayResultModel;
  public companyData: CompaniesDetailModel;
  public entityTypeOptions: any[];
  public occupationDropdown: DropdownModel;
  public typeDropdown: DropdownModel;
  public socialMediaTypeDropdown: DropdownModel;
  public phoneDropdown: DropdownModel;
  public countryDropdown: DropdownModel;
  public stateDropdown: DropdownModel;
  public service: {
    serviceClass: any,
    serviceAccentedClass: any,
    getCompanyDetails: string,
    getStateListFromDb: string,
    saveCompany: string,
    saveCompanyAlias: string,
    getTalentDetails: string,
    getaccentedCharacters: string,
    getNames: string
  };

/**
 * Constructor for CompanyInputParamsModel
 * @param companyTypeAheadOptions holds company type ahead data json
 * @param companyData holds companyData CompaniesDetailModel
 * @param entityTypeOptions holds entityTypeOptions
 * @param occupationDropdown  holds occupation DropdownModel
 * @param typeDropdown holds type DropdownModel
 * @param socialMediaTypeDropdown holds socialMediaType DropdownModel
 * @param phoneDropdown holds phone DropdownModel
 * @param countryDropdown holds country DropdownModel
 * @param stateDropdown holds state DropdownModel
 * @param service the service file to be mapped.
 */
  constructor( companyTypeAheadOptions: TypeAheadDisplayResultModel,
    companyData: CompaniesDetailModel,
    entityTypeOptions: any[],
    occupationDropdown: DropdownModel,
    typeDropdown: DropdownModel, 
    socialMediaTypeDropdown: DropdownModel, 
    phoneDropdown: DropdownModel,
    countryDropdown: DropdownModel,
    stateDropdown: DropdownModel,
    service: any) {
        this.companyTypeAheadOptions = companyTypeAheadOptions;
        this.companyData = companyData;
        this.entityTypeOptions = entityTypeOptions
        this.occupationDropdown = occupationDropdown;
        this.typeDropdown = typeDropdown;
        this.socialMediaTypeDropdown = socialMediaTypeDropdown;
        this.phoneDropdown = phoneDropdown;
        this.countryDropdown = countryDropdown;
        this.stateDropdown = stateDropdown;
        this.service = service;
  }
}