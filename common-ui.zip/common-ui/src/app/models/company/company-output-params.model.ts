import { CompaniesDetailModel } from "./data-model/companies-detail-model";
/**
 * The CompanyOutputParamsModel
 * Model for passing necessary output parameters which need to be passed from Company component.
 */
export class CompanyOutputParamsModel  {
    public companyData: CompaniesDetailModel;
    public validCompany?: boolean;
    public validNotes?: boolean;
    
  /**
   * Constructor for CompanyOutputParamsModel
   * @param companyData holds Company Data CompaniesDetailModel
   * @param validCompany  holds boolean that company data is valid after form validaion
   * @param validNotes  holds boolean that notes entere is valid after form validaion
   */
    constructor( companyData: CompaniesDetailModel, validCompany?: boolean, validNotes?: boolean) {
          this.companyData = companyData;
          this.validCompany = validCompany;
          this.validNotes = validNotes;
    }
  }