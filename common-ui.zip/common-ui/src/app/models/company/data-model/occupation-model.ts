export class OccupationModel {

    public id: number; // Primary Key
    public occupationId: number; // dropdown id
    public occupationName: string; // dropdown value
    public partyId: number; // Company/Person Id

    constructor(
        id: number,
        occupationId: number,
        occupationName: string,
        partyId: number,
    ) {
      this.id = id;
      this.occupationId = occupationId;
      this.occupationName = occupationName;
      this.partyId = partyId;
    }
}

