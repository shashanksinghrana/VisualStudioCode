export class PhoneMediaModel {

    public id: number;
    public contactId: number; // Contact table Id
    public typeId: number;
    public type: string;
    public value: string;
    public primary: boolean;
    public addedPhone: any;
    public edited: boolean;
    public validPhone: boolean;

    public formatPhone: any;

    constructor(
        id: number,
        contactId: number,
        typeId: number,
        type: string,
        value: string,
        primary: boolean,
        addedPhone: any,
        edited: boolean,
        validPhone: boolean,
        formatPhone: any
    ) {
      this.id = id;
      this.contactId = contactId;
      this.typeId = typeId;
      this.type = type;
      this.value = value;
      this.primary = primary;
      this.addedPhone = addedPhone;
      this.edited = edited;
      this.validPhone = validPhone;
      this.formatPhone = formatPhone;
    }
}
