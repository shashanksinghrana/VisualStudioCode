export class CompaniesDetailModel {
  public partyId: number;
  public displayName: string;
  public notes: string;
  public image: string;
  public imageUrl: string;
  public createdBy: string;
  public createdDate: string;
  public createdTime: string;
  public updatedBy: string;
  public updatedDate: string;
  public updatedTime: string;
  public entityTypeId: number;
  public entityTypeValue: string;
  public akas: Array<Object>;
  public names: Array<Object>;
  public socialMedia: Array<Object>;
  public occupations: Array<Object>;
  public locations: Array<Object>;
  public types: Array<Object>;
  public deleteImage: boolean;
  public dataSet?: number;
  public updatedByApp: string;

  /*
  * @author Amit Yogi: It is good practice to initialize the constructor with default values if the *param is not passed so that it can be used to get a default object with all properties.
  */
  constructor(
    partyId: number | null = null,
    displayName: string | null = null,
    notes: string | null = null,
    image: string | null = null,
    imageUrl: string | null = null,
    akas: Array<Object> = null,
    names: Array<Object> = null,
    socialMedia: Array<Object> = null,
    occupations: Array<Object> = null,
    locations: Array<Object> = null,
    types: Array<Object> = null,
    createdBy: string | null = null,
    createdDate: string | null = null,
    createdTime: string | null = null,
    updatedBy: string | null = null,
    updatedDate: string | null = null,
    updatedTime: string | null = null,
    entityTypeId: number | null = null,
    entityTypeValue: string | null = null,
    deleteImage: boolean = false,
    dataSet?: number,
    updatedByApp: string = null
  ) {
    this.partyId = partyId;
    this.displayName = displayName;
    this.image = image;
    this.imageUrl = imageUrl;
    this.notes = notes;
    this.createdBy = createdBy;
    this.createdDate = createdDate;
    this.createdTime = createdTime;
    this.updatedBy = updatedBy;
    this.updatedDate = updatedDate;
    this.updatedTime = updatedTime;
    this.entityTypeId = entityTypeId;
    this.entityTypeValue = entityTypeValue;
    this.akas = akas;
    this.names = names;
    this.socialMedia = socialMedia;
    this.occupations = occupations;
    this.locations = locations;
    this.types = types;
    this.deleteImage = deleteImage;
    this.dataSet = dataSet;
    updatedByApp = updatedByApp;
  }

}