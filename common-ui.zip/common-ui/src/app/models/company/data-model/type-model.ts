export class TypeModel {

    public id: number; // Primary Key
    public typeId: number; // dropdown id
    public name: string; // dropdown value
    public partyId: number; // Company/Person Id

    constructor(
        id: number,
        typeId: number,
        name: string,
        partyId: number,
    ) {
      this.id = id;
      this.typeId = typeId;
      this.name = name;
      this.partyId = partyId;
    }
}

