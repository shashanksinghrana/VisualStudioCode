export class SocialMediaModel {

    public id: number; // Primary Key
    public contactId: number; // Contact table Id
    public typeId: number; // dropdown id
    public type: string; // dropdown value
    public value: string; // website text
    public primary: boolean; // primary ind
    public addedMedia: any;
    public validWebsite: boolean;
    public edited: boolean;

    constructor(
        id: number,
        contactId: number,
        typeId: number,
        type: string,
        value: string,
        primary: boolean,
        addedMedia: any,
        validWebsite: boolean,
        edited: boolean,
    ) {
      this.id = id;
      this.contactId = contactId;
      this.typeId = typeId;
      this.type = type;
      this.value = value;
      this.primary = primary;
      this.addedMedia = addedMedia;
      this.validWebsite = validWebsite;
      this.edited = edited;
    }
}

