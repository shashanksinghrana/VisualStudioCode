export class CompaniesLocationsModel {

  public locationId: number;
  public name: string; 
  public addressType:string;
  public address:string;
  public locationAddress:object;
  public primary:boolean;
  public gridLocationAddress:Array<Object>;
  public phone: Array<Object>;
  public selfLink: string;
  public selected: boolean; 

  constructor(
    locationId?: number,
    name?: string,
    addressType?:string,
    address?: string,
    locationAddress?: object,
    primary?: boolean, 
    gridLocationAddress?:Array<Object>,       
    phone?: Array<Object>,
    selfLink?: string,
    selected?: boolean
    
  ) { 
    this.locationId=locationId;
    this.name=name; 
    this.primary=primary;
    this.addressType=addressType;
    this.address=address;
    this.locationAddress=locationAddress; 
    this.primary=primary; 
    this.gridLocationAddress=gridLocationAddress;  
    this.phone=phone;
    this.selfLink = selfLink;
    this.selected=selected;
  }
}