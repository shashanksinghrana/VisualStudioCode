import { LookupModel } from '../lookup.model';

export class WizardModel {
  public dealId: number;
  public id: number;
  public page: LookupModel;
  public status: LookupModel;
  public wizardType: string;

  constructor(
      dealId?: number,
      id?: number,
      page?: LookupModel,
      status?: LookupModel,
      wizardType?: string
  ) {
    this.dealId = dealId;
    this.id = id;
    this.page = page;
    this.status = status;
    this.wizardType = wizardType;
  }
}
