import { IImageUploader } from '../../interfaces/image-uploader/imageUploader';

export class ImageUploaderModel implements IImageUploader {
    imagePlaceholder: string;
    actualImageURL: string;

    constructor(
        imagePlaceholder: string,
        actualImageURL: string
    ) {
        this.imagePlaceholder = imagePlaceholder;
        this.actualImageURL = actualImageURL;
    }
}
