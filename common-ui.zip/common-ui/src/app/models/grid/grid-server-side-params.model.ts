export class GridServerSideParamsModel {
  sort?: { col: string, direction: string };
  filter?: Array<{ col: string, text: string }>;
  page?: { number: number, size: number };
  multiColumnSort?: any = [];

  constructor(sort?: { col: string, direction: string },
              filter?: Array<{ col: string, text: string }>,
              page?: { number: number, size: number },
              multiColumnSort?: any) {
    this.sort = sort;
    this.filter = filter;
    this.page = page;
    this.multiColumnSort = multiColumnSort;
  }

}
