/**
 * selectedColumn- Selected Column Field name of the cell which is edited
 * selectedRowIndex - Selected Row Index of the cell which is edited
 * newValue - New value of the edited cell 
 * newOptionId - New option Id for the selected dropdown item (Applicable only for dropdown values)
 * newRowData - New Row data of the cell which is edited
 * oldRowData - Old Row data of the cell which is edited
 * newOptionRow - New option Json Row of the selected dropdown item (Applicable only for dropdown values)
 * cellParams - params associated with ag-grid cell event
 */
export class GridCellEditOutParamModel {
    selectedColumn?: string;
    selectedRowIndex?: number;
    newValue?: string;
    newOptionId?: string;
    newRowData?: any;
    oldValue?: any;
    newOptionRow?: any;
    cellParams?: any;

    constructor() {}

    setParams(selectedColumn?: string, selectedRowIndex?: number, newValue?: string,
        newOptionId?: string, newRowData?: any, oldValue?: any, newOptionRow?: any, cellParams?: any) {
        this.selectedColumn = selectedColumn;
        this.selectedRowIndex = selectedRowIndex;
        this.newValue = newValue;
        this.newOptionId = newOptionId;
        this.newRowData = newRowData;
        this.oldValue = oldValue;
        this.newOptionRow = newOptionRow;
        this.cellParams = cellParams;
    }
  }