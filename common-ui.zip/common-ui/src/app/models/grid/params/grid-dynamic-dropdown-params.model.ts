import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';
import { ColDef } from 'ag-grid';

/**
 * The GridDynamicDropdownParamsModel
 *
 * Model for passing necessary parameters to a column in order 
 * to configure dropdown options dynamically for each row in grid .
 */
export class GridDynamicDropdownParamsModel implements IColumnDefParamsModel {
  public dynamicDropDown: { options: string, rowIndex?: number, defaultTabbing?: boolean };

  /**
   * Constructor for the GridDynamicDropdownParamsModel
   * @param dynamicDropDownOptions dropdown options dynamically for each row in grid .
   */
  constructor(dynamicDropDown?: { options: string, rowIndex?: number, defaultTabbing?: boolean }) {
    this.dynamicDropDown = dynamicDropDown;
  }


}
