import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';
import { GridLinkParamsModel } from '../../../models/grid/params/grid-link-params.model';

/**
 * The GridListParamsModel
 *
 * Model for passing the parameters needed for defining the values in the {@link GridListComponent}.
 */
export class GridImageListParamsModel implements IColumnDefParamsModel {
  public colValue: { iterable: string, keys?: Array<string>, routing?: GridLinkParamsModel };
  public comparatorValue?: string;
  public isExpandable?: boolean;
  public isMultiple?: boolean;
  public spacingKey?: string;
  public rowheight?: number;
  public custStyle?: boolean;
  public showAsExpanded?: boolean;
  public showPdfImage?: boolean = false;

  /**
   * Constructor for the GridListParamsModel
   *
   * @param colValue An object literal that specifies three things:
   *  'iterable': The name of the property to iterate through (i.e. 'deals')
   *  'keys': An array of strings - each is a name of a property to display (in order) on each list item (i.e. ['firstName', 'lastName])
   *  'routing': Optional parameter for specifying the routing on each list item
   * @param isExpandable If set to true, will show the 'expand/collapse' arrow on the cell of this column.
   * @param isMultiple If set to true, will enable each element in the list (<li> element) to support multiple values (i.e. an Array).
   *  This works directly with the 'colSpacing' param, in order to setup the correct spacing between elements.
   * @param spacingKey Specifies the property that the list will be spacing off of. In other words, this column will look at the length of
   *  the specified property to correctly setup the spacing between the <li> elements.
   * @param comparatorValue The name of the property that the comparator should sort off of
   *  (i.e. 'performer.lastName' would sort off of the last name property in the performer object)
   * @param rowheight To display the height of the row.
   * @param custStyle used to change the style of display from link blue colored to back colored with some style properties
   * @param showAsExpanded If set to true, will always show the cell of this column as expanded.
   * @param showPdfImage If set to true, will always show pdf icon on the cell.
   *
   */
  constructor(colValue: { iterable: string, keys?: Array<string>, routing?: GridLinkParamsModel },
    isExpandable?: boolean, isMultiple?: boolean, spacingKey?: string, comparatorValue?: string, rowheight?: number, custStyle?: boolean, showAsExpanded?: boolean, showPdfImage?: boolean) {
    this.colValue = colValue;
    this.isExpandable = isExpandable;
    this.isMultiple = isMultiple;
    this.spacingKey = spacingKey;
    this.comparatorValue = comparatorValue;
    this.rowheight = rowheight;
    this.custStyle = custStyle;
    this.showAsExpanded = showAsExpanded;
    this.showPdfImage = showPdfImage;
  }
}
