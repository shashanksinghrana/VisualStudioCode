
import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';

/**
 * The GridIconParamsModel
 *
 * Model for passing the parameters needed for defining the values in the {@link GridIconComponent}.
 */
export class GridCarouselParamsModel implements IColumnDefParamsModel {
  public deleteIcon: { visible: boolean, action?: (row: any) => any, displayOnCellEdit?: boolean,
    selectedRowIndex?: number, showIconsOnNextLine?: boolean };
  public editIcon: { visible: boolean, action?: (row: any) => any };
  public pdfIcon: { visible: boolean, action?: (row: any) => any };
  public saveIcon: { visible: boolean, action?: (row: any) => any, showIconsOnNextLine?: boolean };
  public cancelIcon: { visible: boolean, action?: (row: any) => any, showIconsOnNextLine?: boolean };
  public placeHolderText: string = '';
  public showDefaultHeightInViewMode: boolean = false;
  public showDeleteIconInViewMode: boolean = true;

  /**
   * The constructor for GridIconParamsModel
   *
   * @param showDelete Object Literal that defines whether the 'Minus' button is used or not, and what the click action is.
   * @param showEdit Object Literal that defines whether the 'Edit' button is used or not, and what the click action is.
   * @param showPdf Object Literal that defines whether the 'PDF' button is used or not, and what the click action is.
   * @param saveIcon Object Literal that defines whether the 'Save' button is used or not, and what the click action is.
   * @param cancelIcon Object Literal that defines whether the 'Cancel' button is used or not, and what the click action is.
   * @param placeHolderText String literal to e displayed as placeholder for input text field in edit mode.
   * @param showDefaultHeightInViewMode boolean for showing default height i.e. 30 in view mode
   * @param showDeleteIconInViewMode boolean for showing delete icon in view mode
   */
  constructor(deleteIcon?: { visible: boolean, action?: (row: any) => any,
    displayOnCellEdit?: boolean, selectedRowIndex?: number, showIconsOnNextLine?: boolean },
              editIcon?: { visible: boolean, action?: (row: any) => any },
              pdfIcon?: { visible: boolean, action?: (row: any) => any },
              saveIcon?: { visible: boolean, action?: (row: any) => any, showIconsOnNextLine?: boolean },
              cancelIcon?: { visible: boolean, action?: (row: any) => any, showIconsOnNextLine?: boolean },
              placeHolderText?: string, showDefaultHeightInViewMode?: boolean, showDeleteIconInViewMode?: boolean
            ) {
    this.deleteIcon = deleteIcon;
    this.editIcon = editIcon;
    this.pdfIcon = pdfIcon;
    this.saveIcon = saveIcon;
    this.cancelIcon = cancelIcon;
    this.placeHolderText = placeHolderText;
    this.showDefaultHeightInViewMode = showDefaultHeightInViewMode;
    this.showDeleteIconInViewMode = showDeleteIconInViewMode;
  }
}
