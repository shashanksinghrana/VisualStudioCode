import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';
import { ColDef } from 'ag-grid';

/**
 * The ColumnParamsModel
 *
 * Model for passing necessary parameters to a column in order to configure certain properties.
 * This is a generic params-model that can be used on any column definition.
 */
export class ColumnParamsModel implements IColumnDefParamsModel {
  public comparator?: { name: string, key?: string };
  public config?: ColDef;
  public formatter?: string;
  public valGetter?: string;

  /**
   * Constructor for the ColumnParamsModel
   *
   * @param comparator An object literal to define the name of the comparator to be used on the column for sorting.
   * @param formatter A string to define the name of the formatter to be used on the column for custom display text
   *  (i.e. formatting a date).
   * @param config A object literal to define any additional custom configurations that are unique to a column. These
   *  configurations must be present on the ColumnDefModel in order to be applied to the Grid.
   *  (i.e. to disable sorting on a column, pass the following) { config: { suppressSorting: true } }
   */
  constructor(comparator?: { name: string, key?: string }, formatter?: string, config?: ColDef, valGetter?: string) {
    this.comparator = comparator;
    this.formatter = formatter;
    this.config = config;
    this.valGetter = valGetter;
  }
}
