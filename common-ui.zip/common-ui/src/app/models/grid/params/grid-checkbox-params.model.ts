import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';
import { ColDef } from 'ag-grid';

/**
 * The GridCheckBoxParamsModel
 *
 * Model for passing necessary parameters to a column in order 
 * to configure checkbox options dynamically for each row in grid .
 */
export class GridCheckBoxParamsModel implements IColumnDefParamsModel {
  public checkBox: { titleKey?:string, showLabel?: boolean, toggleEditMode?: boolean, rowIndex?: number };

  /**
   * Constructor for the GridCheckBoxParamsModel
   * @param checkBoxOptions checkbox options dynamically for each row in grid .
   */
  constructor(checkBox?: { titleKey?:string, showLabel?: boolean, toggleEditMode?: boolean, rowIndex?: number }) {
    this.checkBox = checkBox;
  }
}
