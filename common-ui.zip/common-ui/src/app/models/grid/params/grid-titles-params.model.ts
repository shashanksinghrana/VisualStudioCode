import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';
import { GridLinkParamsModel } from '../../../models/grid/params/grid-link-params.model';

/**
 * The GridTitlesParamsModel
 *
 * Model for passing the parameters needed for defining the values in the {@link GridTitlesComponent}.
 */
export class GridTitlesParamsModel implements IColumnDefParamsModel {
  public mainTitle: { keys: Array<string>, routing?: GridLinkParamsModel };
  public subTitleKey: string;
  public showMultipleSubTitle: boolean = false;
  public enableRowEditing: boolean = false;
  public disableLinks:boolean=false;

  /**
   * Constructor for the GridTitlesParamsModel
   *
   * @param mainTitle An object literal that defines the properties that should be displayed in the main title (and optional routing).
   *  (i.e. { keys: ['title'], routing: new GridLinkParamsModel('/project', 'id')} ) - displays the value of 'title' as a link.
   * @param subTitleKey The name of a property that is tied to an array of sub-titles (i.e. 'akaNames').
   * @param showMultipleSubTitle boolean for displaying multiple sub-titles in separate rows.
   * @param enableRowEditing boolean for enabling row editing by clicking the title link.
   */
  constructor(mainTitle: { keys: Array<string>, routing?: GridLinkParamsModel }, subTitleKey: string, showMultipleSubTitle?: boolean, enableRowEditing?: boolean,disableLinks?:boolean) {
    this.mainTitle = mainTitle;
    this.subTitleKey = subTitleKey;
    this.showMultipleSubTitle = showMultipleSubTitle;
    this.enableRowEditing = enableRowEditing;
    this.disableLinks=disableLinks;
  }
}
