import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';
import { GridLinkParamsModel } from '../../../models/grid/params/grid-link-params.model';

/**
 * The GridImageParamsModel
 *
 * Model for passing the parameters needed for defining the values in the {@link GridImageComponent}.
 */
export class GridImageParamsModel implements IColumnDefParamsModel {
  public imageKey: string;
  public imageKeyFor?: string;
  public mainTitle: { keys: Array<string>, routing?: GridLinkParamsModel };
  public subTitleKey: string;
  public titleSubtext: { key: string, replaceBooleanWith?: string};
  public isSubtitleExpandable?: boolean;
  public isMultiple?: boolean;
  public dynamicImageKeyFor?: boolean;



  /**
   * Constructor for the GridImageParamsModel
   *
   * @param imageKey The name of the property tied to the image url that will display an image.
   * @param mainTitle An object literal that defines the properties tied to the data for displaying a title
   *  (i.e. a talent's first name / last name), as well as any routing information for configuring it into a link for navigation.
   * @param subTitleKey The name of the property tied to the sub-titles for displaying under the title (i.e. aka names).
   * @param titleSubtext An object literal that defines the property tied to the subtext (i.e. minor or type) to be displayed
   *  next to the title for showing additional data. Also has an optional parameter for replacing a boolean value with the
   *  text passed into the parameter. (i.e. if 'minor' is a key that is a boolean -> if true, display '(K)' next to title).
   *  Code: { key: 'minor', replaceBooleanWith: 'K' }
   * @param isSubtitleExpandable If set to true, will show the 'expand/collapse' arrow on the cell of this column.
   * @param isMultiple If set to true, will enable each element in the list (<li> element) to support multiple values (i.e. an Array).
   * @param imageKeyFor If set to peoplePlaceholder or null, then if there is no image then people placeholder will be displaying else other placeholder will be displayed(eg: company placeholder)).
   * @param dynamicImageKeyFor is the boolean that holds whether the imageKeyFor is dynamic binded property or text value.
   */
  constructor(imageKey: string, mainTitle?: { keys: Array<string>, routing?: GridLinkParamsModel },
              subTitleKey?: string, titleSubtext?: { key: string, replaceBooleanWith?: string},
              isSubtitleExpandable?: boolean, isMultiple?: boolean, imageKeyFor?:string, dynamicImageKeyFor?: boolean) {
    this.imageKey = imageKey;
    this.imageKeyFor = imageKeyFor;
    this.mainTitle = mainTitle;
    this.subTitleKey = subTitleKey;
    this.titleSubtext = titleSubtext;
    this.isSubtitleExpandable = isSubtitleExpandable;
    this.isMultiple = isMultiple;
    this.dynamicImageKeyFor = dynamicImageKeyFor;
  }
}
