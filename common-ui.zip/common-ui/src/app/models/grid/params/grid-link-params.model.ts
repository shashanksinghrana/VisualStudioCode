import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';

/**
 * The GridLinkParamsModel
 *
 * Model for passing the parameters needed for defining the values in the {@link GridLinkComponent}.
 */
export class GridLinkParamsModel implements IColumnDefParamsModel {
  public field?: string;
  public routeParams?: string;
  public routePre: string;
  public routePost?: string;
  public dynamicRoute?: boolean;
  public showImage?: boolean = false;
  public enableRowEditing?: boolean = false;
  public useDatePickerEditor?: boolean = false;
  public showCarousel?: boolean = false;
  public customStyle:boolean = false;
  public disableLink:boolean=false;

  /**
   * Constructor for the GridLinkParamsModel
   *
   * @param routePre String that specifies the root route to navigate to. This will be the first part of the route.
   * For example: '/deals'.
   * @param routeParams String that specifies the property name to get data from from, to use as a route parameter.
   * For example 'dealId'.
   * @param routePost String that specifies the end route to attach to the end of the route.
   * @param dynamicRoute boolean that specifies dynamic property bind is required from routePreDynamic url text.
   * For example 'summary'
   *  @param showImage boolean that prevents routing and enables downloading a file.
   * For example true/false - default is false
   * @param enableRowEditing boolean that prevents routing and enables row editing for the row.
   * For example true/false - default is false
   * @param useDatePickerEditor boolean that allows use of date picker editor for the cell
   * For example true/false - default is false
   * @param customStyle boolean that allows use of customStyle for the cell data
   * For example true/false - default is false
   ** @param showCarousel boolean that allows use of carousel editor for selecting days
   * For example true/false - default is false
   * The above three params would combine into one route, using examples: '/deals/123456/summary'
   */
  constructor(routePre: string, routeParams?: string, routePost?: string, field?: string, dynamicRoute?: boolean, showImage?: boolean, 
    enableRowEditing?: boolean, useDatePickerEditor?: boolean, showCarousel?: boolean,disableLink?:boolean,customStyle?:boolean) {
    this.routePre = routePre;
    this.routeParams = routeParams;
    this.routePost = routePost;
    this.field = field;
    this.dynamicRoute = dynamicRoute;
    this.showImage = showImage;
    this.enableRowEditing = enableRowEditing;
    this.useDatePickerEditor = useDatePickerEditor;
    this.showCarousel = showCarousel;
    this.disableLink=disableLink;
    this.customStyle=customStyle;
  }
}
