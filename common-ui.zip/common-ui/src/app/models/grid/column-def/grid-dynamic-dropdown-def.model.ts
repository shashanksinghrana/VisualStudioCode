import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { ColumnParamsModel } from '../params/column-params.model';
import { GridDynamicDropdownParamsModel } from '../params/grid-dynamic-dropdown-params.model';


/** The DropdownEditParamsModel
 * Model for creating the inline cell editing params for Dropdown
 */
export class GridDynamicDropdownDefModel extends ColumnDefModel {
  
    /** Constructor for the DropdownEditParamsModel
     * @param name The name of the column to be displayed in the Grid header.
     * @param field The name of the related property that should be displayed in this column.
     * @param colParams The name of the colParams.
     * @param options The Dropdown Options value or [id, value] pair 
     * @param includeIcon boolean value to decide include icon along with dropdown item
     * @param width column width specified in number
     * @param isEditable boolean value to decide the cell is clickable or not
     */
    constructor(name?: string, field?: string, optionsParams?: GridDynamicDropdownParamsModel, 
              colParams?: ColumnParamsModel, width?: number) {
       super(name, field, { name: 'gridDynamicDropdownComponent', params: optionsParams }, colParams);
        this.editable = true;
        this.width = width;
        this.cellEditor = "agSelectCellEditor";
        this.cellEditorOptions = null;
        this.cellEditorParams = null;

        this.cellStyle = function(params) {
          if((params.node.rowIndex % 2) === 0){
            return { 'height': '100%', 'background-color': 'white' };
          } else{
            return { 'height': '100%', 'background-color': '#F5F7FC' };
          }
        }
    };
}
