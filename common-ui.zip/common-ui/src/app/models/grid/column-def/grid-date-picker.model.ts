import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { ColumnParamsModel } from '../params/column-params.model';

/** The GridDatePickerDefModel
 *  Model for creating the inline cell editing params for Datetime Picker
 */
export class GridDatePickerDefModel extends ColumnDefModel {

    /** Constructor for the GridDatePickerDefModel
     * @param name The name of the column to be displayed in the Grid header.
     * @param field The name of the related property that should be displayed in this column.
     * @param dateParams params for the specific column
     * @param colParams The name of the colParams.
     * @param width column width specified in number
     * @param isEditable boolean value to decide the cell is clickable or not
     */
    constructor(name?: string, field?: string, dateParams?: any, colParams?: ColumnParamsModel, width?: number, isEditable?: boolean) {
      super(name, field, { name: '', params: dateParams }, colParams);
      this.editable = isEditable? true : false;
      this.cellEditor = 'datetimepicker';
       this.autoHeight = true;
       this.width = width;
       this.cellStyle = function(params) {
        if((params.node.rowIndex % 2) === 0){
          return { 'height': '100%', 'background-color': 'white', 'white-space': 'normal' };
        }else{
          return { 'height': '100%', 'background-color': '#F5F7FC', 'white-space': 'normal' };
        }
      }
  }
}

