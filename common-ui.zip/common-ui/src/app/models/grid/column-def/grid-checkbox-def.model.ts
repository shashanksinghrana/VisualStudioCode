import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { ColumnParamsModel } from '../../../models/grid/params/column-params.model';
import { GridCheckBoxParamsModel } from '../params/grid-checkbox-params.model';
import { CustomFilterDefModel } from './custom-filter-def.model';

/**
 * The GridCheckBoxDefModel
 *
 * Model for creating a column in the Grid for displaying check boxes.
 *
 * For use with {@link GridCheckBoxDefModel}:
 * To use, plug this into the column definitions of the Grid, and pass appropriate parameters.
 */
export class GridCheckBoxDefModel extends ColumnDefModel {

  /**
   * Constructor for the GridCheckBoxDefModel
   *
   * @param name The name of the column to be displayed in the Grid header.
   * @param field The name of the related property that should be displayed in this column.
   * @param iconParams The GridIconParamsModel for GridIconComponent specific configurations.
   * @param colParams The ColumnParamsModel for configuring additional column properties.
   */
  constructor(name: string, field: string, checkBoxParams: GridCheckBoxParamsModel, colParams?: ColumnParamsModel,
    filter?: CustomFilterDefModel) {
    super(name, field, { name: 'checkBoxComponent', params: checkBoxParams }, colParams, null, false, filter);
    if (colParams.config.editable) {
      this.editable = true;
      this.cellEditor = 'checkBoxEditor';
    }
    this.cellStyle = function (params) {
      if ((params.node.rowIndex % 2) === 0) {
        return { 'text-align': 'center', 'height': '100%', 'background-color': 'white' };
      } else {
        return { 'text-align': 'center', 'height': '100%', 'background-color': '#F5F7FC' };
      }
    };
  }
}
