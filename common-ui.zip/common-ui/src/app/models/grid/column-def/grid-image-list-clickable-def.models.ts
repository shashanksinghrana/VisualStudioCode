import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { GridValueGetters } from '../../../utils/grid/grid-value-getters';
import { GridComparators } from '../../../utils/grid/grid-comparators';
import { ColumnParamsModel } from '../../../models/grid/params/column-params.model';
import { CustomFilterDefModel } from './custom-filter-def.model';
import { GridImageListParamsModel } from '../params/grid-image-list-params.model';
/**
 * The GridListDefModel
 *
 * Model for creating a column in the Grid for displaying expandable lists of data.
 *
 * For use with {@link GridListComponent}:
 * To use, plug this into the column definitions of the Grid, and pass appropriate parameters.
 */
export class GridImageListClickableDefModel extends ColumnDefModel {

  /**
   * Constructor for the GridListDefModel
   *
   * @param name The name of the column to be displayed in the Grid header.
   * @param field The name of the related property that should be displayed in this column.
   * @param iconParams The GridListParamsModel for GridListComponent specific configurations.
   * @param colParams The ColumnParamsModel for configuring additional column properties.
   */
  constructor(name: string, field: string, listParams: GridImageListParamsModel, colParams?: ColumnParamsModel, filter?: CustomFilterDefModel) {
    console.log(listParams);
    super(name, field, { name: 'gridImageListComponent', params: listParams }, colParams, null, false, filter);

    // Gets the value from all relevant fields in order for filtering to work.
    this.valueGetter = (params) => {
      return GridValueGetters.listValueGetter(params.data[listParams.colValue.iterable], listParams);
    };

    // Sets the comparator to use for sorting based on the property name passed through the parameters.
    if (listParams.comparatorValue) {
      this.comparator = (valueA, valueB, nodeA, nodeB) => {
        return GridComparators.propertyValueComparator(
          nodeA.data[listParams.colValue.iterable],
          nodeB.data[listParams.colValue.iterable],
          listParams.comparatorValue
        );
      };
    }

  }
}
