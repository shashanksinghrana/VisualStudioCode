import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { GridImageParamsModel } from '../../../models/grid/params/grid-image-params.model';
import { GridValueGetters } from '../../../utils/grid/grid-value-getters';
import { ColumnParamsModel } from '../params/column-params.model';

/**
 * The GridImageDefModel
 *
 * Model for creating a column in the Grid for displaying images (with title, aka names).
 *
 * For use with {@link GridImageComponent}:
 * To use, plug this into the column definitions of the Grid, and pass appropriate parameters.
 */
export class GridImageDefModel extends ColumnDefModel {

  /**
   * Constructor for the GridImageDefModel
   *
   * @param name The name of the column to be displayed in the Grid header.
   * @param field The name of the related property that should be displayed in this column.
   * @param iconParams The GridImageParamsModel for GridImageComponent specific configurations.
   * @param colParams The ColumnParamsModel for configuring additional column properties.
   */
  constructor(name: string, field: string, imageParams: GridImageParamsModel, colParams?: ColumnParamsModel) {
    super(name, field, { name: 'imageComponent', params: imageParams }, colParams);

    // Gets the value from all relevant fields in order for filtering to work.
    this.valueGetter = (params) => {
      return GridValueGetters.imageValueGetter(params.data, imageParams);
    };
  }
}
