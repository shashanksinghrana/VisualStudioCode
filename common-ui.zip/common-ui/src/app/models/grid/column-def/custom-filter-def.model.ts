export class CustomFilterDefModel {
    public filter: string;
    public filterParams: {
        textFilter: boolean;
        options: any[];
        columnKey: any;
    };
}
