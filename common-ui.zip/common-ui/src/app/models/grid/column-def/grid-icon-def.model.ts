import { GridIconParamsModel } from '../../../models/grid/params/grid-icon-params.model';
import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { ColumnParamsModel } from '../../../models/grid/params/column-params.model';

/**
 * The GridIconDefModel
 *
 * Model for creating a column in the Grid for displaying icons.
 *
 * For use with {@link GridIconComponent}:
 * To use, plug this into the column definitions of the Grid, and pass appropriate parameters.
 */
export class GridIconDefModel extends ColumnDefModel {

  /**
   * Constructor for the GridIconDefModel
   *
   * @param name The name of the column to be displayed in the Grid header.
   * @param field The name of the related property that should be displayed in this column.
   * @param iconParams The GridIconParamsModel for GridIconComponent specific configurations.
   * @param colParams The ColumnParamsModel for configuring additional column properties.
   */
  constructor(name: string, field: string, iconParams: GridIconParamsModel, colParams?: ColumnParamsModel) {
    super(name, field, { name: 'iconComponent', params: iconParams }, colParams);

    if(colParams && colParams.config && colParams.config.editable){
      this.editable = true;
      this.cellEditor = 'iconsEditor';
      this.cellStyle = function(params) {
        if((params.node.rowIndex % 2) === 0){
          return { 'height': '100%', 'background-color': 'white' };
        }else{
          return { 'height': '100%', 'background-color': '#F5F7FC' };
        }
      }
    }
  }
}
