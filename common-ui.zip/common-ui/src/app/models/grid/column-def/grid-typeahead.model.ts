import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { ColumnParamsModel } from '../params/column-params.model';

/** The DropdownEditParamsModel
 * Model for creating the inline cell editing params for Dropdown
 */
export class GridTypeaheadDefModel extends ColumnDefModel {

    /** Constructor for the DropdownEditParamsModel
     * @param name The name of the column to be displayed in the Grid header.
     * @param field The name of the related property that should be displayed in this column.
     * @param colParams The name of the colParams.
     * @param options The options/cofig needed for typeahead on edit mode ie,{ filterType: '', primaryDisplayColumn: '',autofocus:boolean } 
     * @param width column width specified in number
     * @param isEditable boolean value to decide the cell is clickable or not
     */

    constructor(name?: string, field?: string, colParams?: ColumnParamsModel, options?: any, width?: number, isEditable?: boolean) {

        super(name, field, { name: 'gridTypeaheadCellComponent' ,params:options}, colParams);
        this.autoHeight = true;
        this.width = width;
        this.editable = isEditable ? true : false;
        this.cellEditor = "gridTypeaheadEditorComponent";
        this.cellStyle = function (params) {
            // return { 'height': '100%', 'background-color': 'none' };
            if((params.node.rowIndex % 2) === 0){
                return { 'height': '100%', 'background-color': 'white', 'white-space': 'normal' };
              }else{
                return { 'height': '100%', 'background-color': '#F5F7FC', 'white-space': 'normal' };
              }
        };

    };


    //extracting the options/values (JSON array) that is passed from UI
    private extractOptionValues(options) {
        let valueArray = new Array();
        if (null != options && options != undefined) {
            for (const data of options) {
                valueArray.push(data);
            }
        }
        return valueArray;
    }
}
