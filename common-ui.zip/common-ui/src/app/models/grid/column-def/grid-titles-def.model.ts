import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { GridTitlesParamsModel } from '../../../models/grid/params/grid-titles-params.model';
import { GridValueGetters } from '../../../utils/grid/grid-value-getters';
import { GridComparators } from '../../../utils/grid/grid-comparators';
import { GridDataOperations } from '../../../utils/grid/grid-data-operations';
import { ColumnParamsModel } from '../../../models/grid/params/column-params.model';

/**
 * The GridTitlesDefModel
 *
 * Model for creating a column in the Grid for displaying a title with (one to many) subtitles.
 *
 * For use with {@link GridTitlesComponent}:
 * To use, plug this into the column definitions of the Grid, and pass appropriate parameters.
 */
export class GridTitlesDefModel extends ColumnDefModel {

  /**
   * Constructor for the GridTitlesDefModel
   *
   * @param name The name of the column to be displayed in the Grid header.
   * @param field The name of the related property that should be displayed in this column.
   * @param iconParams The GridTitlesParamsModel for GridTitlesComponent specific configurations.
   * @param colParams The ColumnParamsModel for configuring additional column properties.
   */
  constructor(name: string, field: string, titleParams: GridTitlesParamsModel, colParams?: ColumnParamsModel) {
    super(name, field, { name: 'titlesComponent', params: titleParams }, colParams);

    if (colParams && colParams.config && colParams.config.editable) {
      this.editable = true;
      this.cellEditor = 'titlesEditor';
      this.cellStyle = function(params) {
        if ((params.node.rowIndex % 2) === 0) {
          return { 'height': '100%', 'background-color': 'white' };
        } else {
          return { 'height': '100%', 'background-color': '#F5F7FC' };
        }
      };
    }

    // Gets the value from all relevant fields in order for filtering to work.
    this.valueGetter = (params) => {
      return GridValueGetters.titlesValueGetter(params.data, titleParams);
    };

    if (titleParams.mainTitle.keys.length === 1) {
      // Sets the comparator to use for sorting (sorts only by the title - not subtitles).
      this.comparator = (valueA, valueB, nodeA, nodeB) => {
        return GridComparators.stringComparator(
          GridDataOperations.concatenateArrayValuesFromData(nodeA.data, titleParams.mainTitle.keys),
          GridDataOperations.concatenateArrayValuesFromData(nodeB.data, titleParams.mainTitle.keys)
        );
      };
    }
  }

}
