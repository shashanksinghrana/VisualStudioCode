import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { ColumnParamsModel } from '../params/column-params.model';

/** The DropdownEditParamsModel
 * Model for creating the inline cell editing params for Dropdown
 */
export class GridDropdownEditDefModel extends ColumnDefModel {
  
    /** Constructor for the DropdownEditParamsModel
     * @param name The name of the column to be displayed in the Grid header.
     * @param field The name of the related property that should be displayed in this column.
     * @param colParams The name of the colParams.
     * @param options The Dropdown Options value or [id, value] pair 
     * @param includeIcon boolean value to decide include icon along with dropdown item
     * @param width column width specified in number
     * @param isEditable boolean value to decide the cell is clickable or not
     * @param cellParams params for the specific column
     */
    constructor(name?: string, field?: string, colParams?: ColumnParamsModel, options?: any, includeIcon?: boolean, width?: number, isEditable?: boolean, cellParams?: any) {
       super(name, field, { name: '', params: cellParams }, colParams);
        this.editable = isEditable? true : false;
        this.cellEditorOptions = options;
        this.cellEditor = "agSelectCellEditor";
        this.width = width;
        this.cellClass = function(params){
          if(params.colDef.cellRendererParams && params.colDef.cellRendererParams.showValidationBorder){
            if((params.node.rowIndex % 2) === 0){
              return 'c2c-grid-dropdown-editor-even-row c2c-grid-dropdown-editor-error-border';
            }else{
              return 'c2c-grid-dropdown-editor-odd-row c2c-grid-dropdown-editor-error-border';
            }
          }else{
            if((params.node.rowIndex % 2) === 0){
              return 'c2c-grid-dropdown-editor-even-row';
            }else{
              return 'c2c-grid-dropdown-editor-odd-row';
            }
          }
        }
        // this.cellStyle = function(params) {
        //   if((params.node.rowIndex % 2) === 0){
        //     return { 'height': '100%', 'background-color': 'white' };
        //   }else{
        //     return { 'height': '100%', 'background-color': '#F5F7FC' };
        //   }
        // }
        if(includeIcon) {
          this.cellRenderer = "gridDropDownIconCellComponent";
          this.cellEditorParams = {
            values: this.extractOptionValues(options),
            cellRenderer: "gridDropDownIconCellComponent"
           }
        } else {
            this.cellEditorParams = {
            values: this.extractOptionValues(options)
           }
        }
    };

    private extractOptionValues(options) {
      let valueArray = new Array();
      if(null != options && options != undefined) {
        for (const data of options) {
          valueArray.push(data.value);
        }
      }
      return valueArray;
    }
}
