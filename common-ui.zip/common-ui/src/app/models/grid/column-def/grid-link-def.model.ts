import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { GridLinkParamsModel } from '../../../models/grid/params/grid-link-params.model';
import { ColumnParamsModel } from '../../../models/grid/params/column-params.model';
import { CustomFilterDefModel } from './custom-filter-def.model';

/**
 * The GridLinkDefModel
 *
 * Model for creating a column in the Grid for displaying links for routing within the application.
 *
 * For use with {@link GridLinkComponent}:
 * To use, plug this into the column definitions of the Grid, and pass appropriate parameters.
 */
export class GridLinkDefModel extends ColumnDefModel {

  /**
   * Constructor for the GridLinkDefModel
   *
   * @param name The name of the column to be displayed in the Grid header.
   * @param field The name of the related property that should be displayed in this column.
   * @param iconParams The GridLinkParamsModel for GridLinkComponent specific configurations.
   * @param colParams The ColumnParamsModel for configuring additional column properties.
   * @param customStyle The c2c generic style for the  tiltes
   */
  constructor(name: string, field: string, linkParams: GridLinkParamsModel, colParams?: ColumnParamsModel, filter?: CustomFilterDefModel) {
    super(name, field, { name: 'linkComponent', params: linkParams }, colParams, null, false, filter);

    if (colParams && colParams.config && colParams.config.editable) {
      this.editable = true;
      if (linkParams.useDatePickerEditor) {
        this.cellEditor = 'datetimepicker';
        this.cellStyle = function(params) {
          if ((params.node.rowIndex % 2) === 0) {
            return { 'height': '100%', 'background-color': 'white', 'white-space': 'normal' };
          } else {
            return { 'height': '100%', 'background-color': '#F5F7FC', 'white-space': 'normal' };
          }
        };
      } else {
        this.cellEditor = 'linkUploadFileEditor';
        this.cellStyle = function(params) {
          if ((params.node.rowIndex % 2) === 0) {
            return { 'text-align': 'center', 'height': '100%', 'background-color': 'white', 'white-space': 'normal' };
          } else {
            return { 'text-align': 'center', 'height': '100%', 'background-color': '#F5F7FC', 'white-space': 'normal' };
          }
        };
      }
    }
  }
}
