import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { ColumnParamsModel } from '../params/column-params.model';

/** The TextAreaEditParamsModel
 *  Model for creating the inline cell editing params for Large Text /Text Area
 */
export class GridLargeTextEditDefModel extends ColumnDefModel {

    /** Constructor for the TextAreaEditParamsModel
     * @param name The name of the column to be displayed in the Grid header.
     * @param field The name of the related property that should be displayed in this column.
     * @param colParams The name of the colParams.
     * @param width column width specified in number
     * @param isEditable boolean value to decide the cell is clickable or not
     * @param cellParams params for the specific column
     */
    constructor(name?: string, field?: string, colParams?: ColumnParamsModel, width?: number, isEditable?: boolean, cellParams?: any) {
       super(name, field,  { name: '', params: cellParams }, colParams);
       this.editable = isEditable ? true : false;
       this.cellEditor = 'agLargeTextCellEditor';
       // this.cellClass =  "white-space: normal !important;overflow-y: auto;";
       this.cellStyle = function(params) {
        return { 'overflow-y': 'auto', 'white-space': 'normal !important' };
    };
       this.autoHeight = true;
       this.width = width;
    }
}
