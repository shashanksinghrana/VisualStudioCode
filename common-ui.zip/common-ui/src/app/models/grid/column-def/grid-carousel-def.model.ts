import { GridCarouselParamsModel } from '../params/grid-carousel-params.model';
import { ColumnDefModel } from './column-def.model';
import { ColumnParamsModel } from '../params/column-params.model';

/**
 * The GridIconDefModel
 *
 * Model for creating a column in the Grid for displaying icons.
 *
 * For use with {@link GridCarouselDefModel}:
 * To use, plug this into the column definitions of the Grid, and pass appropriate parameters.
 */
export class GridCarouselDefModel extends ColumnDefModel {

  /**
   * Constructor for the GridIconDefModel
   *
   * @param name The name of the column to be displayed in the Grid header.
   * @param field The name of the related property that should be displayed in this column.
   * @param iconParams The GridCarouselParamsModel for GridCarouselDefModel specific configurations.
   * @param colParams The ColumnParamsModel for configuring additional column properties.
   */
  constructor(name: string, field: string, carouselParams: GridCarouselParamsModel, colParams?: ColumnParamsModel) {
    super(name, field, { name: 'daysCarouselComponent', params: carouselParams }, colParams);

    if (colParams && colParams.config && colParams.config.editable) {
      this.editable = true;
      this.cellEditor = 'daysCarouselEditor';
      this.cellStyle = function(params) {
        if ((params.node.rowIndex % 2) === 0) {
          return { 'height': '100%', 'background-color': 'white' };
        } else {
          return { 'height': '100%', 'background-color': '#F5F7FC' };
        }
      };
    }
  }
}
