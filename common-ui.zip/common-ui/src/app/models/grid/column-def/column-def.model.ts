import { ColDef } from 'ag-grid';
import { IColumnDefParamsModel } from '../../../interfaces/grid/icolumn-def-params';
import { GridComparators } from '../../../utils/grid/grid-comparators';
import { GridFormatters } from '../../../utils/grid/grid-formatters';
import { ColumnParamsModel } from '../params/column-params.model';
import { GridDataOperations } from '../../../utils/grid/grid-data-operations';
import { GridValueGetters } from '../../../utils/grid/grid-value-getters';
import { CustomFilterDefModel } from './custom-filter-def.model';

/**
 * The ColumnDefModel
 *
 * Parent Model that handles the creation of column definitions for the Grid Common Component.
 * In order to create a new Grid, you need to define the columns that will display.
 * This is the most important part of the process.
 *
 * This implements ag-grid's ColDef interface. A new property will need to match the name of the
 * corresponding property in the ColDef interface. To see a list of valid column properties, go to
 * ag-grid's {@link https://www.ag-grid.com/javascript-grid-column-properties Column Properties} page.
 */
export class ColumnDefModel implements ColDef {
  cellRenderer?: any;
  cellRendererParams?: any;
  comparator?: any;
  field: string;
  headerName: string;
  hide?: boolean;
  minWidth: number;
  suppressFilter: boolean;
  suppressSorting: boolean;
  tooltip?: any;
  valueFormatter?: any;
  valueGetter?: any;
  width?: number;
  filter?: string;
  filterParams?: any;
  floatingFilterComponent?: any;

  // Changes for Inline cell edit parameter
  cellEditor: any;
  cellEditorParams: any;
  cellEditorOptions: any;
  editable?: any;
  cellClass?: any;
  cellStyle?: {} | ((params: any) => {});
  autoHeight?: any;
  suppressKeyboardEvent?: (params) => boolean;

  // Defaults
  floatingFilterComponentParams = { suppressFilterButton: true, enableServerSideOperations: false, isTextFilterDisabled: false };
  headerTooltip = 'Click to Sort Ascending/Descending';
  icons = {
    sortAscending: '<i class="fa fa-caret-up"/>',
    sortDescending: '<i class="fa fa-caret-down"/>'
  };
  suppressMenu = true;

  /**
   * Constructor for the ColumnDefModel
   *
   * @param name The column name to be displayed on each Grid column.
   * @param field The property the column is tied to. Single string - cannot use dot/bracket notation here.
   * @param customCell The Custom Cell Renderer to use. Defined by specifying a name, and parameters.
   *  The parameters must be a type that implements IColumnDefParamsModel.
   * @param colParams The ColumnParamsModel that describes additional column configurations that aren't handled
   *  by the child models. For example, if you have a specific scenario where you needed to disabled sorting
   *  or filtering on a column, you would configure that through the colParams.
   * @param cellValue Specifies the value that should display in this columns' cells. Used if the 'field' name
   *  doesn't match up with the column name that is needed for sorting/filtering.
   */
  constructor(
    name: string,
    field: string,
    customCell?: { name: string, params?: IColumnDefParamsModel },
    colParams?: ColumnParamsModel,
    cellValue?: string,
    editable?: boolean,
    customFilterDef?: CustomFilterDefModel
  ) {
    this.editable = editable;
    this.headerName = name;
    this.field = field;
    this.floatingFilterComponent = 'floatingFilterComponent';
    if (customFilterDef) {
      this.filter = customFilterDef.filter;
      this.filterParams = customFilterDef.filterParams;
      this.floatingFilterComponentParams = { suppressFilterButton: false, enableServerSideOperations: false, isTextFilterDisabled: true };
      this.suppressMenu = false;
    }
    // Default comparator if one isn't specified
    this.comparator = (valueA, valueB) => {
      return GridComparators.stringComparator(valueA, valueB);
    };

    // Apply custom cell renderers
    if (customCell) {
      this.cellRenderer = customCell.name;
      this.cellRendererParams = customCell.params;
    } else {
      this.tooltip = (params) => {
        return params.valueFormatted ? params.valueFormatted : params.value;
      };
    }

    // Apply custom parameters
    if (colParams) {
      if (colParams.formatter) {
        this.valueFormatter = (params) => {
          const data = GridDataOperations.extractValueFromProperty(params.data, params.colDef.field);
          return GridFormatters.formatterMap[colParams.formatter](data);
        };
      }
      if (colParams.comparator) {
        this.comparator = (valueA, valueB, nodeA, nodeB) => {
          if (colParams.comparator.key) {
            return GridComparators.comparatorMap[colParams.comparator.name](nodeA.data, nodeB.data, colParams.comparator.key);
          } else {
            return GridComparators.comparatorMap[colParams.comparator.name](valueA, valueB);
          }
        };
      }
      if (colParams.valGetter) {
        this.valueGetter = (params) => {
          const data = GridDataOperations.extractValueFromProperty(params.data, params.colDef.field);
          return GridValueGetters.valueGetterMap[colParams.valGetter](data);
        };
      }
      if (colParams.config) {
        this.hide = colParams.config.hide;
        this.suppressFilter = colParams.config.suppressFilter;
        this.suppressSorting = colParams.config.suppressSorting;
        this.headerTooltip = this.suppressSorting ? null : this.headerTooltip;
        this.width = colParams.config.width;
        this.minWidth = this.width ? this.width : 125;
      }
    }

    // Used if column name for sorting/filtering does not match with what should display in the cell.
    if (cellValue) {
      this.valueGetter = (params) => {
        return GridDataOperations.extractValueFromProperty(params.data, cellValue);
      };
    }

    this.suppressKeyboardEvent = function (params) {
      if (params.editing) {
        const evt = params.event;
        const keyCode = evt.keyCode ? evt.keyCode : evt.which;
        const gridShouldDoNothing = params.editing &&
        (keyCode === 40 || keyCode === 39 || keyCode === 37 || keyCode === 13
        || keyCode === 38 || keyCode === 27);
        return gridShouldDoNothing;
      } else {
         return true;
      }
    };
  }
}
