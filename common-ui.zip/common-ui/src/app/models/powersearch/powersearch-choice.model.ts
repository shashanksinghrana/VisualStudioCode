export class PowersearchChoiceModel {
  public data: any[];
  public fieldName: string;
  public isOpen: boolean;
  public title: string;
  public type: string;
  public typeaheadConfig?: {
    endpoint?: string;
    displayName: string;
  };
  public isEditMode?: boolean;

  constructor(
    fieldName: string,
    isOpen: boolean,
    title: string,
    type: string,
    data: any,
    typeaheadConfig?: any,
    isEditMode?: boolean
  ) {
    this.fieldName = fieldName;
    this.isOpen = isOpen;
    this.title = title;
    this.type = type;
    this.data = data;
    this.typeaheadConfig = typeaheadConfig;
    this.isEditMode = isEditMode;
  }
}
