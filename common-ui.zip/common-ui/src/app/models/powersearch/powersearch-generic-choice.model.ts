import { TemplateRef } from "@angular/core";
import { PowersearchChoiceModel } from "./powersearch-choice.model";

export class PowersearchGenericChoiceModel extends PowersearchChoiceModel {

    public genericCardRef: TemplateRef<any>;
  
    constructor(
      fieldName: string,
      isOpen: boolean,
      title: string,
      type: string,
      data: any,
      typeaheadConfig?: any,
      genericCardRef?: TemplateRef<any>
    ) {
      super(fieldName, isOpen, title, type, data, typeaheadConfig);
      this.genericCardRef = genericCardRef;
    }
  }
  
