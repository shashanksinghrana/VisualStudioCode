import { INavbarOptions } from "../interfaces/inavbar-options";

export class NavbarOptions implements INavbarOptions {
    public href     : string;
    public label    : string;
}
