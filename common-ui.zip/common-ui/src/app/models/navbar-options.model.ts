import { INavbarOptions } from "../interfaces/inavbar-options";

export class NavbarOptionsModel implements INavbarOptions {
    public href     : string;
    public label    : string;
}
