import { INavBarHistory } from '../../interfaces/nav-bar/inav-bar-history';

export class NavBarHistoryModel implements INavBarHistory {
  public iconClass?: string;
  public destinationUrl: string;
  public historyLabel: string;
  public source?: string;
}
