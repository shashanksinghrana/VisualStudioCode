/**Add Talent Model */
export class AddTalentModel {
  public party: any = {
    id: null,
    type: 'person',
    images: {
      PRIMARY: []
    },
    names: {
      PRIMARY: [],
      AKA: []
    },
    partyInfo: {
      confidentialInfo: {}
    },
    roles: {
      REPRESENTATIVE: [],
      LOANOUT: [],
      TEAM: [],
      GUARDIAN: [],
      DIRECT_CONTACT: []
    }
  };
}
