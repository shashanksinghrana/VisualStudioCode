import { PartyRoleModel } from '../party-role-model';

export class TeamModel {
  public type: string = 'person';
  public partyRole: PartyRoleModel = new PartyRoleModel();
  public names = {
    PRIMARY: []
  };
  public images = null;
  public contacts = null;
  public partyInfo = null;
  public roles = {
    MEMBER: []
  };
  public talent = null;
  public notes = null;
  public relationId = null;
  public id: number | string = null;
}
