import { LoanoutFormModel } from './../../loanout/loanout-form.model';
import { TeamModel } from './team';
import { MemberModel } from './member';

export class TeamTabModel {
  public teamObjModel: TeamModel;
  public teamNamePrimary: LoanoutFormModel;
  public memberObjMember: MemberModel;
  public memberName: LoanoutFormModel;
}
