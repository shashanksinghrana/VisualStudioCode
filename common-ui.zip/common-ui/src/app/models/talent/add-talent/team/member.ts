import { PartyRoleModel } from '../party-role-model';

export class MemberModel {
  public type: string = 'person';
  public partyRole: PartyRoleModel = new PartyRoleModel();
  public names = {
    MEMBERSHIP: []
  };
  public images = null;
  public contacts = null;
  public partyInfo = null;
  public talent = null;
  public roles = null;
  public notes = null;
  public relationId = null;
  public id: number | string = null;
}
