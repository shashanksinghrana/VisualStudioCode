export class TeamDataModel {
  public teamName: string = '';
  public members: Array<object> = [];
  public showTooltip = false;
  public tooltipValue = '';
  public id: string | number = null;
}
