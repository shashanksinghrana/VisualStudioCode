export class AddTalentImageModel {
  public image = {
    'height': null,
    'width': null,
    'url': null,
    'imageData': null
  };
  public partyImageType = {
    'type': 'IMAGE_TYPE',
    'code': 'PRIMARY',
    'label': 'primary',
    'disabledFlag': null,
    'codeId': null
  };
}
