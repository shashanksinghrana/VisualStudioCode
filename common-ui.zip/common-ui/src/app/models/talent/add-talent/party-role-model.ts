import { PartyRoleTypeModel } from './party-role-type.model';

export class PartyRoleModel {
  public partyRoleType: PartyRoleTypeModel = new PartyRoleTypeModel();
  public verified = null;
  public active = null;
  public primary = null;
}
