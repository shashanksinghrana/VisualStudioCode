import { StatusTalentModel } from './status-talent.model';

export class PartyStudioModel {
  public partyStudioId: number | string = null;
  public studio: number = 3911;
  public notes: string = '';
  public credits: string = '';
  public status: StatusTalentModel = { codeId : null};
}
