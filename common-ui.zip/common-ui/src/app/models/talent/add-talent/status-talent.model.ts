export class StatusTalentModel {
  public codeId: number = null;
}
