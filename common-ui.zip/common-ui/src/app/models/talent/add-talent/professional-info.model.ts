import { OccupationsModel } from '../occupations/occupations.model';
import { PartyStudioModel } from './party-studio-model';
import { GenresModel } from '../genres.model';

export class ProfessionalInfoModel {
  public occupations: OccupationsModel[] = [];
  public genres: GenresModel[] = [];
  public partyStudioAttributes: PartyStudioModel[] = [];
}
