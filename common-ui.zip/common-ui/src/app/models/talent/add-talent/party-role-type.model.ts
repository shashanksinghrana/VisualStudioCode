export class PartyRoleTypeModel {
  public type: string = 'ROLE_TYPE';
  public code: string = 'LOANOUT';
  public label: string = 'loanout';
  public disabledFlag: boolean = null;
  public codeId: number = null;
}
