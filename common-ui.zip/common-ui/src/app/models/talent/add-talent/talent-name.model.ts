export class TalentNameModel {
  public name = {
    first: null,
    entity: null,
    nameId: null
  };
  public nameType = {
    type: null,
    code: null,
    label: null,
    parentId: null,
    displayOrder: null,
  };
}
