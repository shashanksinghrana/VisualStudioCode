export class ConfidentialInfoModel {
  public sagId: string;
  public taxNumber: string;
  public genderPlays: [{}];
  public racePlays: [{}];
  public citizenships: [{}];
  public workEligibilities: [{}];
  public dateOfBirth: string;
  public dateOfDeath: string;
  public relationWithParty: string;
}
