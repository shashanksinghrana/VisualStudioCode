export class PersonalTabModel {
  public citizenshipList: Array<any>;
  public creditsIdField: string;
  public dobField: string;
  public dodField: string;
  public ethnicityList: Array<any>;
  public expiresImStatus: string;
  public genderList: Array<any>;
  public genreList: Array<any>;
  public immStatus: string;
  public loanoutList: Array<any>;
  public notesField: string;
  public occupationList: Array<any>;
  public sagIdField: string;
  public status: any;
  public ssnField: string;
  public typeAheadSelector: string;
}
