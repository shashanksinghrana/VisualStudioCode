import { PartyRoleModel } from './party-role-model';

export class RoleRepresentativeModel {


  public type: string = 'person';
  public partyRole: PartyRoleModel = new PartyRoleModel();
  public names = {
    'PRIMARY': []
  };
  public images = null;
  public contacts = null;
  public partyInfo = null;
  public roles = null;
  public talent = null;
  public notes = null;
  public relationId = null;
  public id: number = null;
}

export class NameModel {

  public name = {
    first: null,
    entity: null,
    middle: null,
    suffix: null,
    fullName: null,
    nameId: null
  };
  public nameType = {
    type: null,
    code: null,
    label: null,
    disabledFlag: null,
    codeId: null
  };

  constructor() {
    this.name = {
      first: null,
      entity: null,
      middle: null,
      suffix: null,
      fullName: null,
      nameId: null
    };
    this.nameType = {
      type: 'NAME_TYPE',
      code: 'PRIMARY',
      label: 'primary',
      disabledFlag: null,
      codeId: null
    };
  }
}

export class PersonType {
  public type: string;
  public partyRole = {
    primary: null
  };
  public id: number = null;
  public occupationWithParent = {
    codeId: null
  };

  constructor() {
    this.type = 'person';
    this.partyRole = {
      primary: true
    };
    this.id = null;
    this.occupationWithParent = {
      codeId: null
    };
  }
}
