export class DropdownFormModel {
  public abbreviation: string = null;
  public id: number = null;
  public sortOrder: number = null;
  public value: string = null;
}
