export class IAddRepForm {
    company: string;
    entity: string;
    first: string;
    occupation: ValueModel;
    phoneNumber: string;
    phoneType: ValueModel;
    primary: boolean;
    repId: number;
    representative: string;
  }

  export class ValueModel {
    id: any;
    value: any;
  }

