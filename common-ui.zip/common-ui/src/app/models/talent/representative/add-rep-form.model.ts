import { ValueModel } from './add-rep.model';

export class AddRepFormModel {
  public company: string = '';
  public entity: string = '';
  public first: string = '';
  public occupation: ValueModel = { value: null, id: null };
  public phoneNumber: string = '';
  public phoneType: ValueModel = { value: null, id: null };
  public primary: boolean = false;
  public repId: number = 0;
  public representative: string = '';
}
