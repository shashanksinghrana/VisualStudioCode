
export class AddRepresentativeModel {

  public partyId: number;
  public firstName: string = '';
  public lastName: string = '';
  public occupations: Array<Occupation> | null = [];
  public phone: Array<Phone> | null = [];
  public companies: Array<Companies> | null = [];
}

export class Assistants {
  relationId: number | string | null;
  parentPartyId: number | string | null;
  partyId: number | string | null;
  primary: boolean;
  name: string | null;
  relationType: string | null;

  constructor() {
    this.relationId = null;
    this.parentPartyId = null;
    this.partyId = null;
    this.primary = false;
    this.name = null;
    this.relationType = null;
  }
}
export class Email {
  id: number | string | null;
  contactId: number | string | null;
  value: string | null;
  primary: boolean;
  typeId: number | string | null;
  type: string | null;

  constructor() {
    this.id = null;
    this.contactId = null;
    this.value = null;
    this.primary = false;
    this.typeId = null;
    this.type = null;
  }
}
export class Phone {
  value: string | null;
  primary: boolean;
  typeId: number | string | null;
  constructor() {
    this.value = null;
    this.primary = true;
    this.typeId = null;
  }
}

export class Occupation {
  occupationId: number | null | string;
  partyId: number | null | string;
  occupationName: string | null;
  constructor() {
    this.occupationId = null;
    this.partyId = null;
    this.occupationName = null;
  }
}

export class Companies {
  partyId: number | null | string;
  companyName: string | null;
  locationId: number | null | null;
  primary: boolean;
  constructor() {
    {
      this.partyId = null;
      this.companyName = null;
      this.locationId = null;
      this.primary = true;
    }
  }
}
