export class OccupationsModel {
  public id: number = null;
  public occupationName = {
    codeId: null
  };
}
