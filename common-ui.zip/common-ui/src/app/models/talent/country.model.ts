export class CountryModel {
  public codeId: number;
}
