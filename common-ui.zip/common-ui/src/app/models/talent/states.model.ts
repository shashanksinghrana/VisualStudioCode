export class StatesModel {
  public codeId: number;
}
