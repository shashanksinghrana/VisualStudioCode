export class AddContactModel {
  public directContactId: number;
  public addresses: Array<
    {
      'addressId': number,
      'addressType': string,
      'city': string,
      'country': string,
      'firstLine': string,
      'locationName': string,
      'secondLine': string,
      'state': string,
      'thirdLine': string,
      'zip': string
    }
    >;
  public email: Array<
    {
      'contactId': number,
      'displayValue': string,
      'id': number,
      'primary': boolean,
      'type': string,
      'typeId': number,
      'value': string
    }
    >;
  public firstName: string;
  public lastName: string;
  public phone: Array<
    {
      'contactId': number,
      'displayValue': string,
      'id': number,
      'primary': boolean,
      'type': string,
      'typeId': number,
      'value': string
    }
    >;
}
