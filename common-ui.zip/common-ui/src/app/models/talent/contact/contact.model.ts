export class ContactModel {
  public type: string = 'person';
  public id: number | string = null;
}
