export class GuardianModel {
  public name = { entity: null };
  public partyId: string;
  public relation: string;
}
