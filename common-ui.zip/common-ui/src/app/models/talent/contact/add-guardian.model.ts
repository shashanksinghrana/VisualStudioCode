import { PartyRoleModel } from '../add-talent/party-role-model';

export class AddGuardianModel {
  public type: string = 'person';
  public id: number | string = null;
  public partyRole: PartyRoleModel = new PartyRoleModel();
  public partyInfo = {
    confidentialInfo: {
      relationWithParty: null
    }
  };
}
