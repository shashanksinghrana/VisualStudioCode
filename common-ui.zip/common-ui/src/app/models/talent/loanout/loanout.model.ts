import { PartyRoleModel } from '../add-talent/party-role-model';
import { CountryModel } from '../country.model';
import { StatesModel } from '../states.model';

export class LoanoutModel {
  public type: string = 'company';
  public partyRole: PartyRoleModel = new PartyRoleModel();
  public names = {
    PRIMARY: []
  };
  public partyInfo = {
    confidentialInfo: {},
    profesionalInfo: {}
  };
  public countryOfIncorporation: CountryModel = { codeId: null };
  public stateOfIncorporation: StatesModel = { codeId: null };
  public id: number | string;
  public relationId: number | string;
}
