export class LoanoutNameModel {
  public name = {
    first: null,
    entity: null,
    nameId: null,
    suffix: null,
    middle: null,
    fullName: null
  };
  public nameType = {
    type: null,
    code: null,
    label: null,
    disabledFlag: null,
    codeId: null,
  };
}
