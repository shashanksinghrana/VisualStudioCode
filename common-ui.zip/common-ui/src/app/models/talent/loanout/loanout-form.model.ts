import { DropdownFormModel } from '../dropdown-form-model';

export class LoanoutFormModel {
  public loanoutCompany: string = null;
  public ein: string = null;
  public freeEIN: string = null;
  public state: DropdownFormModel;
  public country: DropdownFormModel;
  public editableFieldFlags = {};
  public primary: boolean = null;
  public loanoutEditAdded: boolean = true;
  public timeStamp: any;
  public id: number | string = null;
  public relationId: number | string = null;
}
