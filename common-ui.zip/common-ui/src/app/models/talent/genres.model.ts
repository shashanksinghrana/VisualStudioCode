export class GenresModel {
  public codeId: number = null;
}
