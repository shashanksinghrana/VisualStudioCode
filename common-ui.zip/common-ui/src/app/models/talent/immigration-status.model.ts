export class ImmigrationStatusModel {
    public abbreviation: string;
    public expires: string;
    public id: number;
    public sortOrder: number;
    public statusExpire: string;
    public value: string;
    public immigrationId: number;
}
