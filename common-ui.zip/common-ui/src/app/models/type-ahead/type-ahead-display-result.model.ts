import { ITypeAheadDisplayResult } from '../../interfaces/type-ahead/itype-ahead-display-results';

export class TypeAheadDisplayResultModel implements ITypeAheadDisplayResult {

  public filterType?: string;
  public context?: string;
  public metaDataColumns?: {};
  public metaDataResults?: any;
  public noRecordsToReturn: string;
  public primaryDisplayColumn: string;
  public results?: any;
  public secondaryDisplay?: {
    display: string,
    outputDisplay?: string,
    secondaryColumns: Array<string>,
    notAllColumnsRequired?: boolean;
  };
  public service: {
    serviceClass: any,
    get: string
  };
  public defaultMetadataResults?: boolean;
}
