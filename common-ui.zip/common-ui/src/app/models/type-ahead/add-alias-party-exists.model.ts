export class AddAliasModel {
    public name: any = {
        entity : null,
    };
    public partyId: string;
    public createdBy: string;
    public updatedBy: string;
}
