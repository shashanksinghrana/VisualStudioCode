import { IAKA } from "../../../interfaces/type-ahead/aka/iaka";
import { IAddAliasAKA } from "../../../interfaces/type-ahead/aka/iadd-alias-aka";

export class AddAliasAKAModel implements IAddAliasAKA {
  public name: IAKA = {
    entity: null,
    first: null,
    middle: null,
    suffix: null
  };
}