import { IGlobalSearch } from '../../interfaces/global-search/iglobal-search';

export class GlobalSearchModel implements IGlobalSearch {
  public content: Array<
  {
    displayName: string,
    source: string,
    destinationUrl: string,
    iconClass?: string
  }
  >;
  public totalRecordCount: number | string;
  public noRecordSent: number | string;
}
