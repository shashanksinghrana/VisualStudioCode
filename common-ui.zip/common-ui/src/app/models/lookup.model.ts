export class LookupModel {
  public displayOrder: number;
  public id: number;
  public name: string;
  public type: string;

  constructor(
    displayOrder?: number,
    id?: number,
    name?: string,
    type?: string,
  ) {
    this.displayOrder = displayOrder;
    this.id = id;
    this.name = name;
    this.type = type;
  }
}
