export interface ILink {
    linkUrl: string;
    urlParams?: string[];
    params?: string;
    value?: string;
}
