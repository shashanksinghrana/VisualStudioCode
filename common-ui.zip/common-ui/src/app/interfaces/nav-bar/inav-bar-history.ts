export interface INavBarHistory {
  iconClass?: string;
  destinationUrl: string;
  historyLabel: string;
  source?: string;
}
