/**
 * @upper  the uppercase foreign character
 * @lower  the lowercase foreign character
 */
export interface IForeignChars {
    upper : String;
    lower : String;
}