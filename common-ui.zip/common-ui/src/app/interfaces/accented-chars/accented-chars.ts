/**
 * @upper  the uppercase foreign character
 * @lower  the lowercase foreign character
 */
export interface IAccentedChars {
    upper : String;
    lower : String;
}
