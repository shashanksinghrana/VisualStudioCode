export interface IGlobalSearch {
  content: Array<object>;
  totalRecordCount: number | string;
  noRecordSent: number | string;
}
