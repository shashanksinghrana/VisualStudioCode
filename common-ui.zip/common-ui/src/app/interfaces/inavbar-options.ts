export interface INavbarOptions {
    href    : string;
    label   : string;
}
