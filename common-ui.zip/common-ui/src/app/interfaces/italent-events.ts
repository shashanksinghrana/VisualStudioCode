import { Observable } from 'rxjs/Observable';
import { SaveContactModel } from '../models/talent/contact/save-contact.model';
import { GlobalSearchModel } from '../models/global-search/global-search.model';
import { TypeAheadModel } from '../models/type-ahead/type-ahead.model';

export interface ITalentEvents {

    saveTalent: (row: any) => Observable<any>;

    getTalentDetails(id: number): Observable<any>;

    getValidations(data: any): Observable<any>;

    getTabItems(): any[];

    getGenders(): Observable<any>;

    getRaces(): Observable<any>;

    getCountries(): Observable<any>;

    getImmigrationStatus(): Observable<any>;

    getStates(): Observable<any>;

    getOccupation(): Observable<any>;

    getGenre(): Observable<any>;

    getStatus(): Observable<any>;

    getRepType(): Observable<any>;

    getRepPhoneType(): Observable<any>;

    getTalentByID(id: number): Observable<any>;

    getSubTabItems(): any[];

    getRollCallPersonDetail(id: number): Observable<any>;

    getTalentOnly(term: string, recordNumber: string, filterType: string, context: string): Observable<TypeAheadModel[]>;

    save(name: string): Observable<any>;

    saveAlias(data: any): Observable<any>;

    getNames(id: number): Observable<TypeAheadModel[]>;

    getPartyDetails(id: number): Observable<any>;

    getPersonDetail(id: number): Observable<any>;

    getCompany(term: string, recordNumber: string, filterType: string, context: string): Observable<TypeAheadModel[]>;

    saveContact(data: SaveContactModel): Observable<any>;

    getContactOnly(term: string, recordNumber: string, filterType: string, context: string): Observable<TypeAheadModel[]>;

    globalSearch(term: string, recordNumber: string, filterType?: string): Observable<GlobalSearchModel>;

    deleteRelation(relationData: any): Observable<ArrayBuffer>;

    saveRelation(relationData: any): Observable<any>;

    addRepresentativeToRollCall(repData: any): Observable<any>;

    addPersontoRollCallfromTalent(repData: any): Observable<any>;

    navigatePage(path: string): void;

    hasPermission(key: string): boolean;

    getRepDetails(repId: number | string): Observable<any>;

    getPersonData(): any;

    getCompanyDetails(companyId: string): Observable<any>;

    getCompanyDetailsFromDb(companyPartyId): Observable<any>;

    saveParty(tName: any): Observable<any>;

    getStateListFromDb(countryID: string);

    getCompanyData();

    setCompanyData(data: any);

    getUserData(): any;

    getRoutesParams(): any;

    insertUpdatePeopleDetails(data: any): Observable<any>;

    insertUpdateCompanyDetails(data: any): Observable<any>;

    getOptionsList(type): any;

    getDropDownOptionsList(type): any;

    getCountryOptionsList(type): any;

    getMetaDataFields(context): any;

    closeModal(status?: any): void;

    getStudioID(): any;
}
