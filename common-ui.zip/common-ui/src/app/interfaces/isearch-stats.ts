export interface ISearchStats {
    totalRecordsSearched    : number;
    totalReturnTime         : number;
}