export interface IPeople {
    service: {
        serviceClass: any,
        getCompanyDetailsFromDb: string
    };

    peopleTypeAheadService:{
        serviceClass: any,
        getPeopleDetailsFromDb: string
    };
}
