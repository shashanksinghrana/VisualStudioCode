export interface IImageUploader {
    imagePlaceholder: string;
}
