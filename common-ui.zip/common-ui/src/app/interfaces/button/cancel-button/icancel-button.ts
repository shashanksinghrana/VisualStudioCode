export interface ICancelButton {
    modulePrefix: string;
    sourcePage: string;
    requiredAction: string;
    route?: string;
    modal?: object;
    customNavigation?: any
}
