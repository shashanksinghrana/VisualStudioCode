export interface IAddButton {
    modulePrefix: string;
    sourcePage: string;
    requiredAction: string;
    route?: string;
    modal?: string;
    tooltip?: string;
}
