
import { Observable } from 'rxjs/Observable';


export interface INavigateEvents {

  getNavigationItem(moduleName: string): Observable<any>;
}