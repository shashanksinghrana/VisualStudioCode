export interface IAudit {
    enteredDate: string;
    enteredBy: string;
    updatedDate: string;
    updatedBy: string;
}
