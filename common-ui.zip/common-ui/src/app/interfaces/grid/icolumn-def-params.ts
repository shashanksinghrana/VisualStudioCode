import { GridLinkParamsModel } from '../../models/grid/params/grid-link-params.model';
import { ColDef } from 'ag-grid';

/**
 * The IColumnDefParamsModel
 *
 * Interface to be implemented by any column params models.
 */
export interface IColumnDefParamsModel {
  comparator?: { name: string, key?: string };
  comparatorValue?: string;
  config?: ColDef;
  field?: string;
  formatter?: string;
  imageKey?: string;
  isExpandable?: boolean;
  isMultiple?: boolean;
  mainTitle?: { keys: Array<string>, routing?: GridLinkParamsModel };
  routeParams?: string;
  routePost?: string;
  routePre?: string;
  deleteIcon?: { visible: boolean, action?: (row: any) => any, showIconsOnNextLine?:boolean };
  editIcon?: { visible: boolean, action?: (row: any) => any };
  pdfIcon?: { visible: boolean, action?: (row: any) => any };
  saveIcon?: { visible: boolean, action?: (row: any) => any, showIconsOnNextLine?:boolean };
  cancelIcon?: { visible: boolean, action?: (row: any) => any, showIconsOnNextLine?:boolean };
  showImage?: boolean,
  spacingKey?: string;
  subTitleKey?: string;
  showMultipleSubTitle?: boolean,
  enableRowEditing?: boolean,
  titleSubtext?: { key: string, replaceBooleanWith?: string};
  value?: { iterable: string, keys: Array<string>, routing?: GridLinkParamsModel };
  isSubtitleExpandable?: boolean;
  dynamicDropDown?: { options: string, rowIndex?: number };
  checkBox?: { titleKey?:string, showLabel?: boolean, rowIndex?: number };
  useDatePickerEditor?: boolean;
  showDefaultHeightInViewMode?: boolean;
  showDeleteIconInViewMode?: boolean;
  showPdfImage?: boolean;
}
