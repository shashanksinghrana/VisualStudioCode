export interface ITypeAheadDisplayResult {
  filterType?: string;
  context?: string;
  metaDataColumns?: {};
  metaDataResults?: any;
  noRecordsToReturn: string;
  primaryDisplayColumn: string;
  results?: any;
  secondaryDisplay?: {
    display: string,
    outputDisplay?: string,
    secondaryColumns: Array<string>,
    notAllColumnsRequired?: boolean;
  };
  service: {
    serviceClass: any,
    get: string
  };
  defaultMetadataResults?: boolean;
}
