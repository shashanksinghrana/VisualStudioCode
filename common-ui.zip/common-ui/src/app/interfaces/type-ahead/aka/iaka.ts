export interface IAKA {
    entity: string,
    first: string,
    middle: null,
    suffix: null
}