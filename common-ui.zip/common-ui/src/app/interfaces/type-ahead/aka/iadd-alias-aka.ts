import { IAKA } from "../../../interfaces/type-ahead/aka/iaka";

export interface IAddAliasAKA {
    name : IAKA
}