export interface ITypeAheadDisplay{
    agency: string;
    companyName?: string;
    firstName: string;
    isPerson?: boolean;
    entityName: string;
    middleName: string;
    occupation: string;
    partyType: string;
    ssn: string;
    suffix: string;
}
