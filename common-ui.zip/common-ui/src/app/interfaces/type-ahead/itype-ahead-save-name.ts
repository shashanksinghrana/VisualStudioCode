export interface ITypeAheadSaveName{
    first     : string,
    entity    : string,
    middle    : string,
    suffix    : string
}