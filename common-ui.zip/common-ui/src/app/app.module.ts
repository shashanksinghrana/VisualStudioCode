import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from './app-routing.module';
import { ButtonModule } from './modules/elements/button/button.module';
import { FooterModule } from './modules/structural/footer/footer.module';
import { FormModule } from './modules/form/form.module';
import { GridModule } from './modules/elements/grid/grid.module';
import { HeaderModule } from './modules/structural/header/header.module';
import { NameSearchModule } from './modules/name-search/name-search.module';
import { SidebarModule } from './modules/structural/sidebar/sidebar.module';

import { ImageUploaderService } from '../app/services/image-uploader/image.service';

import { AppComponent } from './app.component';
import { HowToComponent } from './c2c-main/how-to/how-to.component';
import { WelcomeComponent } from './c2c-main/welcome/welcome.component';

import { ModalEventService } from './services/events/modal/modal-event.service';
import { TypeAheadEventService } from './services/events/type-ahead/type-ahead-event.service';
import { UrlResolverService } from './services/non-http-data/url-resolver.service';
import { AuditModule } from './modules/elements/audit/audit.module';
import { ImageUploaderModule } from './modules/elements/image-uploader/imageUploader.module';
import { WizardModule } from './modules/structural/wizard/wizard.module';
import { ExampleReactiveFormComponent } from './c2c-main/examples/example-reactive-form/example-reactive-form.component';
import { CommonSharedModule } from './modules/common-shared/common-shared.module';
import { ModalModule } from './modal/modal.module';
import { TypeAheadModule } from './modules/elements/type-ahead/type-ahead.module';
import { CustomListModule } from './modules/elements/custom-list/custom-list.module';
import { TypeAheadService } from './services/http/type-ahead/type-ahead.service';
import { PowersearchModule } from './modules/structural/powersearch/powersearch.module';
import { TextMaskModule } from 'angular2-text-mask';
import { DropDownTypeAheadModule } from './modules/elements/dropdown-typeahead/dropdown-typeahead.module';
import { TypeAheadNameListingModule } from '../app/modules/elements/type-ahead-name-listing/type-ahead-name-listing.module';
import { TypeAheadModalModule } from '../app/forms/type-ahead/type-ahead-modal/type-ahead-modal.module';
import { NavBarEventService } from './services/events/nav-bar/nav-bar-event.service';
import { TalentModule } from './modules/talent/talent.module';
import { NgxMaskModule } from './utils/ngx-mask/ngx-mask.module';
import { FileUploaderModule } from './modules/elements/file-uploader/file-uploader.module';
import { FileUploaderService } from './services/file-uploader/file-uploader.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { UnsaveModalPopUp } from './utils/unsave/unsave-modal';

/**
 * The AppModule
 *
 * The main app module for the Common Library. We do not export anything app-level related.
 * The main purpose of AppModule is to provide a central place to work on Common Components.
 */
@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    HowToComponent,
    ExampleReactiveFormComponent
  ],
  imports: [
    NgxMaskModule.forRoot(),
    TextMaskModule,
    AuditModule,
    BrowserModule,
    HttpClientModule,
    NgbModule.forRoot(),
    FormModule,
    FormsModule,
    ReactiveFormsModule,
    NameSearchModule,
    AppRoutingModule,
    HeaderModule,
    FooterModule,
    SidebarModule.forRoot(),
    GridModule.forRoot(),
    BrowserAnimationsModule,
    ButtonModule,
    ImageUploaderModule,
    DropDownTypeAheadModule,
    WizardModule.forRoot(),
    CommonSharedModule,
    FileUploaderModule,
    ModalModule.forRoot(),
    TypeAheadModule.forRoot(),
    TypeAheadModalModule.forRoot(),
    TypeAheadNameListingModule.forRoot(),
    CustomListModule,
    PowersearchModule.forRoot(),
    TalentModule,
    NgSelectModule
  ],
  providers: [HttpClient, TypeAheadEventService, UrlResolverService, ModalEventService,
    ImageUploaderService, TypeAheadService, NavBarEventService, FileUploaderService, UnsaveModalPopUp],
  bootstrap: [AppComponent]
})
export class AppModule { }
