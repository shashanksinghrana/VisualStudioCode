import { Directive, ElementRef, HostListener } from '@angular/core';
import { SpecialStrings } from '../../enums/characters/special-strings.enum';

@Directive({
  selector: '[einValidator]'
})
export class EinValidatorDirective {

  constructor() { }

  @HostListener("keyup", ["$event"])
    public onKeydown(evt: KeyboardEvent) : void {

        let el : ElementRef = new ElementRef(evt.target);
            el.nativeElement = evt.target
            el.nativeElement.value = this.format(el.nativeElement.value);
    }
  private format(value:string) : string {

    if(value) {
      let val = value.replace(/\D/g, '');
      let newVal = '';
      const sizes = [2, 7];

      for (const i in sizes) {
          if (val.length > sizes[i]) {
            if(i === '0')
              newVal += val.substr(0, sizes[i]) + '-';
            else
              newVal += val.substr(0, sizes[i]);
            val = val.substr(sizes[i]);
          } else
              break;
      }
      if(newVal.length < 10)
        newVal += val;

      return newVal;
    } else {
        return '';
    }
  }
}
