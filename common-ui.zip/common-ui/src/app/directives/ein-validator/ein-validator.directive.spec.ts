import { EinValidatorDirective } from './ein-validator.directive';

describe('EinValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new EinValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
