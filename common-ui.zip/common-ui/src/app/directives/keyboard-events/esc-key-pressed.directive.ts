import { Directive, HostListener, EventEmitter, Output, Input } from '@angular/core';
import { CharKeyCodes } from '../../enums/characters/character-keycodes.enum';

@Directive({
  selector: '[c2cEscKeyPressed]'
})

/**
 * The EscKeyPressedDirective
 * 
 * When the escape key pressed the directive detects the keyup event and 
 * emit its event so that the component can listen it
 */

export class EscKeyPressedDirective {

  /** Input property coming from the Parent */
  @Input() handleEsc: boolean;
  /**Output property sending to the Parent */
  @Output() escKeyPressed: EventEmitter<KeyboardEvent> = new EventEmitter<KeyboardEvent>();
  /**
   * Constructor for EscKeyPressedDirective
   */
  constructor() {
  }

  /**
   * @HostListener decorator
   * 
   * @param evt This function decorator that accepts an evt as an argument
   * 
   * When the events got fired on host element it called the keyEvent function
   */
  @HostListener('document:keyup', ['$event'])
    public keyEvent(evt: KeyboardEvent): void {
     if (this.handleEsc && evt.keyCode === CharKeyCodes.ESCAPE) {
          evt.preventDefault();
          /**
           *  Emits the event
           */
          this.escKeyPressed.emit(evt);
      }
    }

}
