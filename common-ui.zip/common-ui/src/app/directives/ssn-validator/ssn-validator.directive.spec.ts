import { SsnValidatorDirective } from './ssn-validator.directive';

describe('SsnValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new SsnValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
