import {
  Component, Input, ViewChild, ElementRef, HostListener,
  Renderer2, AfterViewChecked, OnInit, Output, EventEmitter, OnChanges, OnDestroy
} from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
import { AuditModel } from '../../../models/audit/audit.model';
import { WizardStatusEnum } from '../../../enums/structural/wizard-status.enum';
import { LookupModel } from '../../../models/lookup.model';

/**
 * The WizardComponent
 *
 * Common Component for handling Wizard flow for creating new data (i.e. deals, deal memos).
 */
@Component({
  selector: 'c2c-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.scss']
})
export class WizardComponent implements OnInit, AfterViewChecked, OnChanges, OnDestroy {

  /** Defines the index of the current page being displayed. */
  public pageIndex: number = 1;

  public isIncomplete: boolean = false;

  /** Defines the current scroll position based on arrow clicks. */
  public scroll: number = 0;

  /** Defines the scroll width of the container holding the wizard tiles. */
  public scrollWidth: number = 0;

  /** Defines the string that will be diplayed under the wizard section. */
  public subTitle: string;

  private _actvateRoute: string;

  public wizardClicked: boolean = false;

  /** Defines the audit data */
  @Input() public audit: AuditModel = Defaults.DEFAULT_WIZARD_AUDIT;

  /** Defines each section that the Wizard will be made up of. */
  @Input() public sections: any[] = Defaults.DEFAULT_WIZARD_SECTIONS;

  @Input() public routerDeatils: any[];

  /** The properties to display under the Wizard. These will be joined into one string separated by pipes. */
  @Input() public subTitles: Array<string> = Defaults.DEFAULT_WIZARD_SUBTITLE;

  /** Defines the value for the page title. Used for configuring the page title to be displayed. */
  @Input() public title: string = Defaults.DEFAULT_WIZARD_TITLE;

  @Output() public pageIndexEvent: EventEmitter<any> = new EventEmitter<any>();

  /** The wizard list element reference. Used to be able to scroll through the element on slide clicks. */
  @ViewChild('wizardList', { read: ElementRef }) public wizardList: ElementRef;

  /**
   * Listens to the window resize event and rechecks if scrolling is necessary for wizard tiles.
   */
  @HostListener('window:resize')
  public onResize(): void {
    if (this.wizardList.nativeElement.scrollWidth === this.wizardList.nativeElement.clientWidth) {
      this.scrollWidth = 0;
      this.scroll = 0;
    } else {
      this.scrollWidth = this.wizardList.nativeElement.scrollWidth - this.wizardList.nativeElement.clientWidth;
    }
  }

  /**
   * Constructor for the WizardComponent
   *
   * @param elRef A reference to a certain element in the DOM. In this case, the WizardComponent.
   * @param renderer Used for safely accessing elements in the DOM.
   */
  constructor(private elRef: ElementRef, private renderer: Renderer2, private router: Router) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this._actvateRoute = event.url;
      }
    });
  }

  /**
   * Angular lifecycle hook for initialization logic. We use it here to set
   * the subTitle string for displaying subtitles under the wizard sections.
   */
  public ngOnInit(): void {
    if (this.subTitles) {
      this.subTitle = this.subTitles.filter(Boolean).join(' | ');
    }
  }

  public ngOnChanges(): void {
    if (this.subTitles) {
      this.subTitle = this.subTitles.filter(Boolean).join(' | ');
    }
    this.wizardClicked = false;
  }

  /**
   * After view init we get the client width and scroll width of the list of wizard tiles.
   * This allows us to determine when to show/hide the right/left arrows.
   */
  public ngAfterViewChecked(): void {
    // The width of the container that has the child element of the wizard section.
    const element: HTMLElement = this.renderer.parentNode(this.elRef.nativeElement);
    let clientWidth = element.offsetWidth;

    if (clientWidth === 0) {
      clientWidth = this.wizardList.nativeElement.clientWidth;
    }

    /**
     * Calculated width of the wizard section based on the width of each tile (175 for middle tiles)
     * times the number of sections in the wizard. We need to subtract 26 due to the first and last tile
     * being 162 px wide (13px offset per).
     */
    const scrollWidth = (175 * this.sections.length) - 26;

    if (scrollWidth === clientWidth) {
      this.scrollWidth = 0;
      this.scroll = 0;
    } else {
      this.scrollWidth = scrollWidth - clientWidth;
    }
    // TODO: Handle current selection better
    this.calcCurrentSection(this.router.url);
     // to toggle the last tab into view ie summary page
     if (!this.wizardClicked) {
      this.toggleCurrentSection(this._actvateRoute);
     }

  }

   // to calculate section for toggle

  public toggleCurrentSection(url: string) {
    if (url && url.indexOf('summary') >= 0) {
      const index = url.indexOf('summary') + 1;
      this.scrollTabintoView(index);
    }

  }

  public ngOnDestroy(): void {
    this.subTitle = null;
  }

  /**
   * Gets the flag class in order to display the status of each Wizard section, and adds the class to the span.
   *
   * @param status The status of the Wizard Section to compare.
   */
  public getStatusClass(section: any): string {
    const status: LookupModel = section.status;
    if (section.page === 'Work Activity') {
      return '';
    }
    if (status) {
      switch (status.name) {
        case WizardStatusEnum.COMPLETE:
          return WizardStatusEnum.COMPLETE_CLASS;
        case WizardStatusEnum.INCOMPLETE:
          return WizardStatusEnum.INCOMPLETE_CLASS;
        case WizardStatusEnum.NOT_APPLICABLE:
          return WizardStatusEnum.NOT_APPLICABLE_CLASS;
        default:
          return '';
      }
    } else if (!status && section.route && this._actvateRoute && this._actvateRoute.includes(section.route)
     && !(this._actvateRoute.includes('workActivity')) && !(this._actvateRoute.includes('namesProjectDetails'))) {
      section.routeActivated = true;
      return WizardStatusEnum.INCOMPLETE_CLASS;
    }
    this.isIncomplete = false;
  }

  public onClick(idx: number, section) {
    this.pageIndex = (idx + 1);
    this.scrollTabintoView(idx);
    // this.pageIndexEvent.emit(section.page);
    if (section) {
      if (section.status === null && section.page) {
        this.getStatusClass(section);
      }
    }
  }

  public calcCurrentSection(url: string) {
    this.sections.forEach((section, index) => {
      if (url.indexOf(section.route) >= 0) {
        this.pageIndex = index + 1;
        this.pageIndexEvent.emit(this.pageIndex);
      }
    });
  }

  /**
   * Scrolls the wizard list tiles all the way to the left position.
   */
  public slideLeft(position?: number) {
    this.wizardClicked = true;
    this.scroll -= (position) ? position : 325;
    if (this.scroll < 0) {
      this.scroll = 0;
    }
    this.wizardList.nativeElement.scrollLeft -= (position) ? position : 325;
  }

  /**
   * Scrolls the wizard list tiles all the way to the right position.
   */
  public slideRight(position?: number) {
    this.scroll += (position) ? position : 325;
    if (this.scroll > this.scrollWidth) {
      this.scroll = this.scrollWidth;
    }
    this.wizardList.nativeElement.scrollLeft += (position) ? position : 325;
  }

  /**
   * Scroll the tab into view
   */
  public scrollTabintoView(idx) {
    if (this.wizardList.nativeElement.scrollWidth === this.wizardList.nativeElement.clientWidth) {
      this.scrollWidth = 0;
      this.scroll = 0;
    } else {
      if (this.wizardList.nativeElement.clientWidth <= (idx * 300)) {
        this.slideRight(300);
      } else {
        this.slideLeft(300);
      }
    }
  }
}
