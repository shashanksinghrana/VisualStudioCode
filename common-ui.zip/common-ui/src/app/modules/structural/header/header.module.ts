import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header.component';
import { BannerComponent } from './banner/banner.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { TypeAheadModule } from '../../.././modules/elements/type-ahead/type-ahead.module';
import { FormModule } from '../../form/form.module';
import { ModalModule } from '../../../modal/modal.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from './../../elements/button/button.module';
import { NavBarEventService } from './../../../services/events/nav-bar/nav-bar-event.service';
import { UnsavedChangesService } from '../../../services/events/modal/unsaved-changes-event/unsaved-changes.service';
import { UnsaveModalPopUp } from '../../../utils/unsave/unsave-modal';
/**
 * The HeaderModule
 *
 * Module that contains the Header for C2C.
 */
@NgModule({
  imports: [
    CommonModule,
    TypeAheadModule,
    FormModule,
    ModalModule.forRoot(),
    NgbModule.forRoot(),
    FormsModule,
    ButtonModule
  ],
  declarations: [
    HeaderComponent,
    BannerComponent,
    NavBarComponent
  ],
  exports: [
    HeaderComponent,
    BannerComponent,
    NavBarComponent
  ]
})
export class HeaderModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: HeaderModule,
      providers: [NavBarEventService, UnsavedChangesService, UnsaveModalPopUp]
    };
  }
}
