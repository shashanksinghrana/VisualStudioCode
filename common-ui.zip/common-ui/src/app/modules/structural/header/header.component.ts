import { Component, Input, Output, EventEmitter, OnInit, ViewContainerRef, ViewChild } from '@angular/core';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
import { TypeAheadDisplayResultModel } from '../../../models/type-ahead/type-ahead-display-result.model';
import { TypeAheadService } from './../../../services/http/type-ahead/type-ahead.service';
import { UnsavedChangesService } from '../../../services/events/modal/unsaved-changes-event/unsaved-changes.service';
import { INavigateEvents } from '../../../interfaces/inavigate-events';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { UnsaveModalPopUp } from '../../../utils/unsave/unsave-modal';
import { ModalUnsavedChangesComponent } from '../../../modal/unsaved-changes/modal-unsaved-changes.component';
/**
 * The HeaderComponent
 *
 * Common Component for holding the C2C Header. Includes the banner (with app name and login controls),
 * and the navigation bar (for navigating between modules).
 */
@Component({
  selector: 'c2c-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [TypeAheadService]
})
export class HeaderComponent implements OnInit {
  /** The Module Name to be displayed in the left-hand navigation item (history dropdown with hamburger icon) */
  @Input() moduleName: string = Defaults.DEFAULT_MODULE_NAME;
  @Input() featureCastingNav: string;
  @Input() talentNav: string;
  @Input() currentUserName: string;
  @Input() scriptTrackerLink: string;
  @Input() hitListLink: string;

  @Input() public displayDataResults: TypeAheadDisplayResultModel;
  @Output() public clickNavigationHeader: EventEmitter<any> = new EventEmitter<any>();
  @Input() navigationServ: INavigateEvents;

  @ViewChild('checkHeaderModal') checkHeaderModal: ModalUnsavedChangesComponent;
  public setPopHeader: boolean = false;
  public setValueHeader: boolean = false;
  public moduleNavigation: string;

  /**
   * Constructor for the HeaderComponent
   */
  navIsClicked(item) {

    this.navigationClicked(item);
    // this.clickNavigationHeader.emit(item);

  }
  constructor(private typeAheadService: TypeAheadService, private unsavedService: UnsavedChangesService, private toastr: ToastsManager, private vRef: ViewContainerRef, private toastOpts: ToastOptions, private unsavedPopup: UnsaveModalPopUp) {
    this.toastr.setRootViewContainerRef(this.vRef);
  }

  ngOnInit() {
    this.unsavedPopup.setvalue.subscribe(res => {
      this.setPopHeader = res && res.showPopup;
    });
  }

  private navigationData(moduleName: string): void {
    this.navigationServ.getNavigationItem(moduleName)
      .subscribe(
        (res) => {
          const result = res['url'];
          if (result === null || result === '') {
            this.toastr.clearAllToasts();
            // setTimeout(() => {
            this.toastr.warning('You do not have permission to this module. Please contact your system administrator for assistance.', null, this.toastOpts.positionClass = 'toast-top-center');
            // });
          } else {

            if (this.setPopHeader) {
              this.unsavedPopup.checkNavigation(result);
              this.moduleNavigation = result;
            }
            else {
              window.location.href = result;
            }

          }
        }
      );
  }

  // closeHeaderPop(evt) {
  //   this.setValueHeader = evt;
  //   if (this.setValueHeader) {
  //     window.location.href = this.moduleNavigation;
  //     this.setValueHeader = false;
  //     this.setPopHeader = false;
  //     this.unsavedPopup.setActivatePopup(this.setPopHeader);
  //   }
  //   else {
  //     this.setValueHeader = true;
  //     this.setPopHeader = true;
  //     this.unsavedPopup.setActivatePopup(this.setPopHeader);
  //   }
  // }

  getCode(value: string) {
    let code: string;
    switch (value) {
      case 'DealPoint':
        code = 'DP';
        break;

      case 'ScriptTracker':
        code = 'ST';
        break;

      case 'HitList':
        code = 'HL';
        break;

      case 'FeatureCasting':
        code = 'FC';
        break;

      case 'Talent':
        code = 'TALENT2';
        break;

      case 'RollCall':
        code = 'RC';
        break;

      case 'Music':
        code = 'MUSIC';
        break;

      case 'Contracts':
        code = 'CONTRACTS';
        break;

      case 'RAID':
        code = 'RAID';
        break;

      case 'FROG':
        code = 'FROG';
        break;

      case 'Focus':
        code = 'FOCUS';
        break;

      default:
        code = 'undefined';
    }
    return code;
  }

  navigationClicked(item: any) {
    const code = this.getCode(item);
    if (code !== 'undefined') {
      this.navigationData(code);
    }
  }


}
