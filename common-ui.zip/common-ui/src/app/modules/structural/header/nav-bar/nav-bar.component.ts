import { Component, OnInit, Input, Output, EventEmitter, HostListener, ViewContainerRef } from '@angular/core';

import { NavBarHistoryModel } from '../../../../models/nav-bar/nav-bar-history.model';
import { NavBarEventService } from '../../../../services/events/nav-bar/nav-bar-event.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr';
import { UnsaveModalPopUp } from '../../../../utils/unsave/unsave-modal';
import { UnsavedChangesService } from '../../../../services/events/modal/unsaved-changes-event/unsaved-changes.service';

/**
 * The NavBarComponent
 *
 * Part of the Header Common Component for displaying the navigation items to all
 * the different Modules within the C2C Application.
 *
 * TODO: Create a Model for the HistoryItem object.
 * TODO: Hook up a link to each navigation item (this will require some discussion).
 */
@Component({
  selector: 'c2c-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {
  public historyItems: NavBarHistoryModel[] = [];
  public navbarItems: { label: string, href: string, class: string }[];
  public modulesItems: { label: string, class: string }[];

  /** The Module Name to be displayed in the left-hand navigation item (history dropdown with hamburger icon) */
  @Input() public moduleName: string;
  @Input() public talentNav: string = '#';
  @Input() public featureCastingNav: string = '#';
  @Input() public scriptTrackerLink: string;
  @Input() public hitListLink: string;
  @Output() public clickNav: EventEmitter<any> = new EventEmitter<any>();
  public setNavPopHeader: boolean = false;
  private navigateItem: any;
  public navigateUrl: any;

  /**
   * Constructor for the NavBarComponent
   */
  constructor(private navBarEventService: NavBarEventService, private toastr: ToastsManager, private vRef: ViewContainerRef,
    private router: Router, private unsavedPopup: UnsaveModalPopUp, private unsavedService: UnsavedChangesService) {
    this.toastr.setRootViewContainerRef(vRef);
    this.navBarEventService.getNavBarHistory().subscribe(history => {
      if (!history.iconClass) {
        const moduleIcon = this.modulesItems.find(element => history.source === element.label);
        history.iconClass = moduleIcon.class;
      }
      this.addHistory(history);
    });
  }

  onClickEvent(item: any) {
    this.clickNav.emit(item.label);
  }
  /**
   * Angular's lifecycle hook for initialization logic. Currently hard-coding the navbarItems and historyItems.
   */
  ngOnInit() {
    this.navbarItems = [
      { label: 'Home', href: '#', class: 'navbar-home' },
      { label: 'ScriptTracker', href: this.scriptTrackerLink, class: 'navbar-pencil' },
      { label: 'HitList', href: this.hitListLink, class: 'navbar-star' },
      { label: 'DealPoint', href: '#', class: 'navbar-handshake' },
      { label: 'Focus', href: '#', class: 'navbar-aperture' },
      { label: 'Talent', href: this.talentNav, class: 'navbar-people' },
      { label: 'RollCall', href: '#', class: 'navbar-contact-card' },
      { label: 'FeatureCasting', href: this.featureCastingNav, class: 'navbar-projector' },
      { label: 'Music', href: '#', class: 'navbar-music' },
      { label: 'Contracts', href: '#', class: 'navbar-agreement' }
      // { label: 'RAID', href: '#', class: '' },
      // { label: 'FROG', href: '#', class: '' }
    ];

    this.modulesItems = [
      { label: 'ST', class: 'navbar-pencil' },
      { label: 'HL', class: 'navbar-star' },
      { label: 'DP', class: 'navbar-handshake' },
      { label: 'TAL', class: 'navbar-people' },
      { label: 'RC', class: 'navbar-contact-card' },
      { label: 'FC', class: 'navbar-projector' },
    ];

    const sessionStorageHistory = JSON.parse(sessionStorage.getItem('NAV_BAR_HISTORY'));
    if (sessionStorageHistory && sessionStorageHistory.length) {
      sessionStorageHistory.forEach(element => {
        this.historyItems.push(element);
      });
    }
    this.unsavedPopup.setvalue.subscribe(res => {
      this.setNavPopHeader = res && res.showPopup;
    });
  }

  private historyLenght(): number {
    return this.historyItems.length;
  }

  public addHistory(history: NavBarHistoryModel, itemClicked?: any): void {
    if (this.setNavPopHeader && itemClicked) {
      this.unsavedPopup.checkNavigation(history.destinationUrl);
      // this.navigateItem = history.destinationUrl
    }
    if (!this.setNavPopHeader && itemClicked) {
      window.location.href = history.destinationUrl;
    }
    if (this.historyLenght() === 0) {
      this.historyItems.push(history);
    } else {
      if (this.historyLenght() === 10) {
        this.historyItems.splice(-1, 1);
        this.historyItems.unshift(history);
      } else {
        this.historyItems.unshift(history);

        // remove the duplicate value
        this.historyItems.forEach((item, index) => {
          if (index !== this.historyItems.findIndex(i => i.destinationUrl === item.destinationUrl)) {
            this.historyItems.splice(index, 1);
          }
        });
      }
    }
    this.setLocalStorageHistory();
  }

  // closeNavPop(evt) {
  //   this.setNavPopHeader = evt;
  //   if (this.setNavPopHeader) {
  //     window.location.href = this.navigateItem;
  //   }
  //   console.log(evt);
  // }

  private histoyNavigateUrl(history: NavBarHistoryModel): void {
    this.addHistory(history);
    this.router.navigateByUrl(history.destinationUrl);
  }

  private setLocalStorageHistory(): void {
    sessionStorage.setItem('NAV_BAR_HISTORY', JSON.stringify(this.historyItems));
  }
}
