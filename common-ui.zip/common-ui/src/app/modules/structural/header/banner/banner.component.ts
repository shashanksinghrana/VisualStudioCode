import { FormGroup, FormControl, AbstractControl } from '@angular/forms';
import { NavBarHistoryModel } from './../../../../models/nav-bar/nav-bar-history.model';
import { NavBarEventService } from './../../../../services/events/nav-bar/nav-bar-event.service';
import { Component, Input, ViewChild, ElementRef, OnInit, TemplateRef, AfterContentChecked, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { Location } from '@angular/common';
import { ModalGenericComponent } from '../../../../modal/generic/modal-generic.component';
import { Observable, Subject } from 'rxjs';
import { debounceTime, merge, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { SpecialStrings } from '../../../../enums/characters/special-strings.enum';
import { of } from 'rxjs/observable/of';
import { NgbTypeaheadConfig, NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { GlobalSearchModel } from '../../../../models/global-search/global-search.model';
import { TypeAheadDisplayResultModel } from '../../../../models/type-ahead/type-ahead-display-result.model';
import { Router } from '@angular/router';
import { UnsaveModalPopUp } from '../../../../utils/unsave/unsave-modal';
/**
 * The BannerComponent
 *
 * Part of the Header Common Component for displaying the login info, and global search bar.
 * TODO: Implement the Typeahead Common Component for the search bar.
 */
@Component({
  selector: 'c2c-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.scss'],
  providers: [NgbTypeaheadConfig]
})

export class BannerComponent implements OnInit, AfterContentChecked {
  private _customModal: ModalGenericComponent;
  private searchTerm: string;
  private _clickDisplayResult: boolean = false;

  @Input()
  set customModal(val: ModalGenericComponent) { this._customModal = val; }
  get customModal(): ModalGenericComponent { return this._customModal; }

  @Input() currentUserName: string = 'Gelena Weissman';
  /**Data configuration for typeAhead display */
  @Input() displayDataResults: TypeAheadDisplayResultModel;

  @ViewChild('logoutModal') public logoutModal: ModalGenericComponent;
  @ViewChild('typeAheadGlobalSearch1') public typeAheadGlobalSearch: ElementRef;
  @ViewChild('rt') tpl: NgbTypeahead;

  /**Subject used to check if typeAhead input has a value */
  public typeAheadFocusSubject: Subject<string> = new Subject<string>();

  /**Show/Hide results when unsubscribing */
  private hideSearchingWhenUnsubscribed = new Observable(() => () => this.isSearching = false);
  public modulesItems: { label: string, class: string }[];
  public noRecordSent: number = 0;
  private itemSelected: any;
  public totalRecordCount: number = 0;
  public typeAheadFooter: any;
  public tAFooterWidth: number;
  public tAFooterRightPos: any;
  public tAFooterHeigth: any;
  /**Property used while searching for results is in progress */
  public isSearching: boolean = false;
  public searchForm: FormGroup;
  public formatter: object = (x: { displayName: string }) => x.displayName;
  public setGlobalFlag: boolean = false;


  /**
   * Constructor for the BannerComponent
   */
  constructor(private typeAheadConfig: NgbTypeaheadConfig,
    private router: Router,
    private navBarEventService: NavBarEventService, private unsavedPopup: UnsaveModalPopUp) { }

  ngOnInit() {
    this.searchForm = new FormGroup({
      'global': new FormControl('Alice')
    });
    this.modulesItems = [
      { label: 'ST', class: 'navbar-pencil' },
      { label: 'HL', class: 'navbar-star' },
      { label: 'DP', class: 'navbar-handshake' },
      { label: 'TALENT2', class: 'navbar-people' },
      { label: 'ROLLCALL2', class: 'navbar-contact-card' },
      { label: 'FC', class: 'navbar-projector' },
    ];
    this.unsavedPopup.setvalue.subscribe(res => {
      this.setGlobalFlag = res && res.showPopup;
    });
  }
  // ngAfterViewInit(): void {
  //   const typeAheadSelector: AbstractControl = this.searchForm.get('global');
  //   typeAheadSelector.valueChanges
  //   .merge(Observable.fromEvent(this.typeAheadGlobalSearch.nativeElement, 'blur'))
  //   .subscribe((change: any) => {

  //   });
  // }

  ngAfterContentChecked(): void {
    if (this.typeAheadGlobalSearch.nativeElement.nextElementSibling) {
      if (this.typeAheadGlobalSearch.nativeElement.nextElementSibling.scrollHeight >
        this.typeAheadGlobalSearch.nativeElement.nextElementSibling.clientHeight) {

        this.tAFooterRightPos = 47;
        this.tAFooterWidth = 16;
        if (!!window['chrome'] && !!window['chrome'].webstore) {
          this.typeAheadFooter = this.typeAheadGlobalSearch.nativeElement.nextElementSibling.offsetHeight - 2;
          this.tAFooterHeigth = 45;
        } else {
          this.typeAheadFooter = this.typeAheadGlobalSearch.nativeElement.nextElementSibling.offsetHeight + 3;
          this.tAFooterHeigth = 40;
        }
      } else {
        if (!!window['chrome'] && !!window['chrome'].webstore) {
          this.typeAheadFooter = this.typeAheadGlobalSearch.nativeElement.nextElementSibling.offsetHeight - 3;
          this.tAFooterHeigth = 43;
        } else {
          this.typeAheadFooter = this.typeAheadGlobalSearch.nativeElement.nextElementSibling.offsetHeight - 2;
          this.tAFooterHeigth = 45;
        }
        this.tAFooterRightPos = 31;
        this.tAFooterWidth = 1;
      }
    }
  }

  public openModal(evt) {
    evt.preventDefault();
    this.logoutModal.open();
  }

  public globalSearch: object = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .merge(this.typeAheadFocusSubject.filter((): boolean => {
        return (this.typeAheadGlobalSearch.nativeElement.value.trim() !== SpecialStrings.EMPTY ||
          this.typeAheadGlobalSearch.nativeElement.value.trim() !== SpecialStrings.EMPTY_OPEN);
      }))
      .distinctUntilChanged()
      .do(() => this.isSearching = true)
      .switchMap(term => this.mapTerm(term)
        .catch(() => {
          // if there's an error in the search
          return of([]);
        }))
      .do(() => {
        return this.isSearching = false;
      })
      .merge(this.hideSearchingWhenUnsubscribed)

  private mapTerm<T>(term: string): Observable<GlobalSearchModel[]> {
    this.searchTerm = term;
    if (term.trim() === SpecialStrings.EMPTY || term.trim() === SpecialStrings.EMPTY_OPEN) {
      this.setTypeAheadFocus();
      return of([]);
    }
    return this.displayDataResults.service.serviceClass[this.displayDataResults.service.get](this.searchTerm,
      String(this.displayDataResults.noRecordsToReturn), this.displayDataResults.filterType)
      .map(res => {
        this.noRecordSent = res.noRecordSent;
        this.totalRecordCount = res.totalRecordCount;
        if (this.noRecordSent == 0) {
          res.content.push({
            displayName: 'No Results Found',
            source: 'TALENT2',
            destinationUrl: '',
            iconClass: 'navbar-people'
          });
        }
        //TAL-3436 Global Search - total result record display - Add an empty result to show dispaly count
        else if (this.noRecordSent > 0) {
          res.content.push({
            displayName: '',
            source: 'TALENT2',
            destinationUrl: '',
            iconClass: ''
          });
        }
        return this.searchResults(res.content);
      });
  }

  private searchResults<T>(resArr: Array<T>): Array<T> {
    if (resArr.length === 0) {
      return [];
    } else {
      resArr.forEach((element, index) => {
        element['position'] = (index + 1);
        const moduleIcon = this.modulesItems.find(module => module.label === element['source']);
        element['iconClass'] = moduleIcon['class'];
      });
      return resArr;
    }

  }

  public selectedItem(evt: any): void {
    if (evt) {
      evt.preventDefault();
    }
    if (!this._clickDisplayResult && evt.item.destinationUrl) {
      const historyItem: NavBarHistoryModel = new NavBarHistoryModel();
      this.itemSelected = evt.item;
      this.typeAheadGlobalSearch.nativeElement.value = SpecialStrings.EMPTY;

      historyItem.destinationUrl = this.itemSelected.destinationUrl;
      historyItem.historyLabel = this.itemSelected.displayName;
      historyItem.iconClass = this.itemSelected.iconClass;

      this.navBarEventService.setNavBarHistory(historyItem);
      this.setTypeAheadFocus();
      if (this.setGlobalFlag) {
        this.unsavedPopup.checkNavigation(this.itemSelected.destinationUrl);
      }
      else {
        window.location.href = this.itemSelected.destinationUrl;
      }

    }
    this._clickDisplayResult = false;
  }

  public setTypeAheadFocus() {
    this.typeAheadGlobalSearch.nativeElement.focus();
  }

  public closeTypeAheadResults(evt: Event, typeaheadInstance): void {
    setTimeout(() => {
      this.typeAheadGlobalSearch.nativeElement.value = this.searchTerm;
    }, 100);
  }
  public cancelRedirection(evt: Event): void {
    this._clickDisplayResult = true;
  }
}
