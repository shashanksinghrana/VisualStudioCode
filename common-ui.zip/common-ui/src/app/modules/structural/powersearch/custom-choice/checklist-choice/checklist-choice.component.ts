import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { PowersearchEventService } from '../../../../../services/events/powersearch/powersearch-event.service';

/**
 * The ChecklistChoiceComponent
 *
 * Child component for generating a choice in the 'Narrow Your Choices' section for displaying a list of checkboxes.
 */
@Component({
  selector: 'c2c-checklist-choice',
  templateUrl: './checklist-choice.component.html',
  styleUrls: ['./checklist-choice.component.scss']
})
export class ChecklistChoiceComponent implements OnInit, OnDestroy {

  public allchecked: FormControl;

  private openListFirstTime: boolean = false;

  /** The name of the form to add this control to. Should probably always be 'powersearchForm' */
  @Input() public formName: FormGroup;

  /** The name of the array to add to the form. Should share the name of the field in the given 'choice' */
  @Input() public formArrayName: string;

  /** Defines the values to be displayed in the checklist.
   *  Ideally these should be of type {@link LookupModel} to be consistent with the application */
  @Input() public options: any[];

  @Input() public isEditMode: boolean;

  public resetData: any;
  @Input('resetData')
  set _resetData(data: any) {
    this.clearFields(data);
  }

  @Output() public isOpenChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  /** Defines whether the 'choice' is expanded or collapsed (collapsed by default) */
  public isOpen: boolean = false;
  @Input('isOpen')
  set _isOpen(open: boolean) {
    this.isOpen = open;
    // Don't reload list again once clicked on list.
    if (open && !this.openListFirstTime) {
      // Wait still option data load
      setTimeout(() => {
        this.openListFirstTime = open;
        const formArr = this.formName.get(this.formArrayName) as FormArray;
        this.initCheckList();
        // open all checked list item when click on list title tab
        if (this.isEditMode) {
         formArr.markAsDirty();
         formArr.markAsTouched();
        } else {
          formArr.markAsPristine();
          formArr.markAsUntouched();
        }
      }, 100);
    }
  }

  public isChecked: boolean = false;
  public isUnchecked: boolean = false;
  private subscriptions: Subscription = new Subscription();
  private initialAllCheck: boolean = true;
  /**
   * Constructor for the ChecklistChoiceComponent
   *
   * @param psEventService Service for handling events related to Powersearch.
   */
  constructor(private psEventService: PowersearchEventService) { }

  /**
   * Angular lifecycle hook for initialization logic.
   * Used here to initialize form controls and to subscribe to events.
   */
  public ngOnInit(): void {
    this.allchecked = new FormControl(this.initialAllCheck);
    this.addSubscriptions();
  }

  private initCheckList(): void {
    const arr = this.formName.get(this.formArrayName) as FormArray;
    if (arr.controls.length !== 0) {
      arr.controls = [];
    }
    this.options.forEach(opt => {
      arr.push(this.buildCriteria(opt));
    });
    this.allchecked.patchValue(this.initialAllCheck);
  }

  private addSubscriptions(): void {
    this.subscriptions.add(
      this.psEventService.getCategoryRemoved().subscribe(fieldName => {
        if (this.formArrayName === fieldName) {
          this.removeAllCriteria(fieldName);
        }
      })
    );
    this.subscriptions.add(
      this.psEventService.getSelectionRemoved().subscribe(event => {
        if (this.formArrayName === event.fieldName) {
          this.removeCriteria(event.fieldName, event.index);
        }
      })
    );
  }

  /**
   * Used for building a new FormGroup for each option in the 'options' array.
   *
   * @param val The value (or option) to get the data from.
   */
  public buildCriteria(val: any): FormGroup {
    const checked = (val.checked === false) ? val.checked : true;
    if (!checked) {
      this.initialAllCheck = false;
    }
    return new FormGroup({
      id: new FormControl(val.id),
      label: new FormControl(val.name),
      value: new FormControl(checked)
    });
  }

  private clearFields(data: any): void {
    if (data && data.reset) {
      this.options.forEach(opt => {
        opt.checked = true;
      });
      this.initialAllCheck = true;
      this.openListFirstTime = false;
    }
  }

  /**
   * Handles the functionality of the 'Select All' checkbox for marking all checkboxes as checked/unchecked.
   */
  public selectAll(): void {
    const criterias = this.formName.get(this.formArrayName) as FormArray;
    criterias.controls.forEach(criteria => {
      criteria.patchValue({ value: this.allchecked.value });
    });
  }

  /* Handle the functionality of the "Select All" checkbox when any check box unceked*/
  public uncheckSelectAll(i): void {
    const criterias = this.formName.get(this.formArrayName) as FormArray;
    criterias.controls.forEach((criteria, index) => {
      if (!criterias.controls[index].value.value) {
        this.isUnchecked = true;
      } else {
        this.isChecked = true;
      }
    });
    if (this.isUnchecked) {
      this.allchecked.patchValue(false);
      this.isUnchecked = false;
    } else if (!this.isUnchecked && this.isChecked) {
      this.allchecked.patchValue(true);
      this.isChecked = false;
    }
  }

  /**
   * Used to remove a item from the 'Your Selections' section as well as unchecking it.
   * Listens to an event from the {@link PowersearchComponent} before removing the item.
   *
   * @param fieldName The name of the field to remove the item from.
   * @param index The index position of the item to remove.
   */
  public removeCriteria(fieldName, index): void {
    const criterias = this.formName.get(fieldName) as FormArray;
    criterias.controls[index].patchValue({ value: false });
    this.allchecked.patchValue(false);
  }

  /**
   * Used to remove all items from a particular category from the 'Your Selections' section as well as setting them all back to checked.
   * Listens to an event from the {@link PowersearchComponent} before removing the items.
   *
   * @param fieldName The name of the field (category) to remove the items from.
   */
  public removeAllCriteria(fieldName): void {
    const criterias = this.formName.get(fieldName) as FormArray;

    criterias.controls.forEach(criteria => {
      criteria.patchValue({ value: true });
    });
    this.allchecked.patchValue(true);
    this.resetFormFields();
  }

  private resetFormFields(): void {
    this.isOpen = false;
    this.isOpenChange.emit(this.isOpen);
    this.clearFields({ reset: true });
    const formArr = this.formName.get(this.formArrayName) as FormArray;
    formArr.markAsPristine();
    formArr.markAsUntouched();
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
