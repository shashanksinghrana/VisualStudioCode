import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormArray, FormControl, FormBuilder, NgForm } from '@angular/forms';
import * as moment_ from 'moment';
import { Subscription } from 'rxjs';
import { PowersearchEventService } from '../../../../../services/events/powersearch/powersearch-event.service';

const moment = moment_;
/**
 * The ChecklistChoiceComponent
 *
 * Child component for generating a choice in the 'Narrow Your Choices' section for displaying status date.
 */
@Component({
  selector: 'c2c-checklist-date',
  templateUrl: './checklist-date.component.html',
  styleUrls: ['./checklist-date.component.scss']
})
export class ChecklistDateComponent implements OnInit, OnDestroy {

  /** The name of the form to add this control to. Should probably always be 'powersearchForm' */
  @Input() public formName: FormGroup;

  /** The name of the array to add to the form. Should share the name of the field in the given 'choice' */
  @Input() public formArrayName: string;

  @Input() public statusData: any;

  @Input() public isEditMode: boolean;

  @Output() public checkStatusValidity: EventEmitter<any> = new EventEmitter<any>();

  @Output() public isOpenChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  /** Defines the values to be displayed in the checklist.
   *  Ideally these should be of type {@link LookupModel} to be consistent with the application */
  public options: any[] = [];

  public dateError: boolean = false;
  public initFirstTime: boolean = false;
  public removeItem: any;
  private subscriptions: Subscription = new Subscription();

  public isChecked: boolean = false;
  public isUnchecked: boolean = false;
  private initialAllCheck: boolean = true;
  public startDate: string;
  public endDate: string;

  public resetData: any;
  @Input('resetData')
  set _resetData(data: any) {
    this.clearFields(data);
  }

  public isOpen: boolean = false;
  @Input('isOpen')
  set _isOpen(open: boolean) {
    this.isOpen = open;
    // Don't reload list again once clicked on list.
    if (open && !this.initFirstTime) {
      // Wait still option load
      setTimeout(() => {
        this.initFirstTime = true;
        const formArr = this.formName.get(this.formArrayName) as FormArray;
        const controls = formArr.controls[0];
        const arr = controls.get('values') as FormArray;
        // this.clearFormArray(arr);
        this.options.forEach(opt => {
          arr.push(this.buildCriteria(opt));
        });
        controls.get('allchecked').patchValue(this.initialAllCheck);
        if (this.isEditMode) {
          formArr.markAsDirty();
          formArr.markAsTouched();
        } else {
          formArr.markAsPristine();
          formArr.markAsUntouched();
        }
      }, 100);
    }
  }

  constructor(private fb: FormBuilder, private psEventService: PowersearchEventService) {
  }

  public ngOnInit(): void {
    this.options = this.statusData['values'];
    if (this.statusData['startDate']) {
      this.startDate = moment(this.statusData['startDate']).format('MM/DD/YYYY');
    }
    if (this.statusData['endDate']) {
      this.endDate = moment(this.statusData['endDate']).format('MM/DD/YYYY');
    }
    this.createFormControl();
    this.addSubscriptions();
  }

  public onChangeDate(date, criteria: any): void {
    const startDate = criteria.get('startDate').value;
    const endDate = criteria.get('endDate').value;
    this.dateError = false;
    this.checkStatusValidity.emit(false);
    if (startDate && endDate) {
      const isAfter = moment(startDate).isAfter(endDate);
      if (isAfter) {
        this.checkStatusValidity.emit(true);
        this.dateError = true;
      }
    }
  }

  private addSubscriptions(): void {
    this.subscriptions.add(
      this.psEventService.getCustomCategoryRemoved().subscribe(
        (response) => {
          if (this.formArrayName === response.field) {
            this.removeCriteria(response);
          }
        })
    );

    this.subscriptions.add(
      this.psEventService.getCategoryRemoved().subscribe(
        (response) => {
          if (this.formArrayName === response) {
            this.removeAllCriteria(response);
          }
        })
    );
  }

  private clearFormArray(formArray: FormArray): void {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  private createFormControl(): void {
    const formArr = this.formName.get(this.formArrayName) as FormArray;
    this.clearFormArray(formArr);
    formArr.push(this.fb.group({
      value: new FormControl(true),
      values: this.fb.array([]),
      startDate: new FormControl(this.startDate),
      endDate: new FormControl(this.endDate),
      allchecked: new FormControl(true)
    }));
  }

  private resetForm(): void {
    this.startDate = null;
    this.endDate = null;
    this.initialAllCheck = true;
    this.createFormControl();
    this.options.forEach(opt => {
      opt.value = true;
    });
  }

  /**
   * Used for building a new FormGroup for each option in the 'options' array.
   *
   * @param val The value (or option) to get the data from.
   */
  public buildCriteria(val: any): FormGroup {
    const checked = (val.value === false) ? val.value : true;
    if (!checked) {
      this.initialAllCheck = false;
    }
    return new FormGroup({
      id: new FormControl(val.id),
      name: new FormControl(val.name),
      value: new FormControl(checked)
    });
  }

  /**
   * Handles the functionality of the 'Select All' checkbox for marking all checkboxes as checked/unchecked.
   */
  public selectAll(): void {
    const criterias = this.formName.get(this.formArrayName) as FormArray;
    const controls = criterias.controls[0];
    const checklistArr = controls.get('values') as FormArray;
    const allCheck = controls.get('allchecked').value;
    checklistArr.controls.forEach(criteria => {
      criteria.patchValue({ value: allCheck });
    });
  }

  /* Handle the functionality of the "Select All" checkbox when any check box unceked*/
  public uncheckSelectAll(i): void {
    const criterias = this.formName.get(this.formArrayName) as FormArray;
    const controls = criterias.controls[0];
    const formValues = criterias.value[0];
    if (formValues) {
      formValues.values.forEach((criteria) => {
        if (!criteria.value) {
          this.isUnchecked = true;
        } else {
          this.isChecked = true;
        }
      });
    }
    if (this.isUnchecked) {
      controls.get('allchecked').patchValue(false);
      this.isUnchecked = false;
    } else if (!this.isUnchecked && this.isChecked) {
      controls.get('allchecked').patchValue(true);
      this.isChecked = false;
    }
  }

  /**
   * Used to remove a item from the 'Your Selections' section as well as unchecking it.
   * Listens to an event from the {@link PowersearchComponent} before removing the item.
   *
   * @param fieldName The name of the field to remove the item from.
   * @param index The index position of the item to remove.
   */
  public removeCriteria(removeItem): void {
    const criterias = this.formName.get(this.formArrayName) as FormArray;
    const controls = criterias.controls[0];
    if (criterias.value && controls) {
      criterias.value[0].values.forEach((criteria, index) => {
        if (criteria.id === removeItem.item.id) {
          const listCriteria = controls.get('values') as FormArray;
          listCriteria.controls[index].patchValue({ value: false });
          controls.get('allchecked').patchValue(false);
          return false;
        }
      });
    }
  }

  /**
   * Used to remove all items from a particular category from the 'Your Selections' section as well as setting them all back to checked.
   * Listens to an event from the {@link PowersearchComponent} before removing the items.
   *
   * @param fieldName The name of the field (category) to remove the items from.
   */
  public removeAllCriteria(fieldName): void {
    const criterias = this.formName.get(fieldName) as FormArray;
    const controls = criterias.controls[0];
    const listCriteria = controls.get('values') as FormArray;
    if (listCriteria) {
      listCriteria.controls.forEach((criteria) => {
        criteria.patchValue({ value: true });
      });
    }
    controls.get('allchecked').patchValue(true);
    this.resetFormFields();
  }

  private clearFields(data: any) {
    if (data && data.reset) {
      this.dateError = false;
      this.checkStatusValidity.emit(false);
      this.resetForm();
      this.initFirstTime = false;
    }
  }

  private resetFormFields(): void {
    this.isOpen = false;
    this.isOpenChange.emit(this.isOpen);
    this.clearFields({ reset: true });
    const formArr = this.formName.get(this.formArrayName) as FormArray;
    formArr.markAsPristine();
    formArr.markAsUntouched();
  }

  public ngOnDestroy(): void {
    // this.resetForm();
    this.subscriptions.unsubscribe();
  }

}
