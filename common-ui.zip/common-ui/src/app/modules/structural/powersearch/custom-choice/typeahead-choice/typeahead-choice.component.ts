import { Observable, Subscription } from 'rxjs';
import { Component, OnInit, Input, OnDestroy, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { FormGroup, FormControl, FormArray } from '@angular/forms';
import { UrlResolverService } from './../../../../../services/non-http-data/url-resolver.service';
import { PowersearchEventService } from '../../../../../services/events/powersearch/powersearch-event.service';
import { TypeAheadDisplayResultModel } from './../../../../../models/type-ahead/type-ahead-display-result.model';
import { PowersearchChoiceModel } from './../../../../../models/powersearch/powersearch-choice.model';
import { EmptyObservable } from 'rxjs/observable/EmptyObservable';

/**
 * The TypeaheadChoiceComponent
 *
 * Child component for generating a choice in the 'Narrow Your Choices' section for displaying a list of typeaheads.
 * TODO: Need to implement the 'Type-ahead' common component instead of using a regular 'input' element.
 */
@Component({
  selector: 'c2c-typeahead-choice',
  templateUrl: './typeahead-choice.component.html',
  styleUrls: ['./typeahead-choice.component.scss']
})
export class TypeaheadChoiceComponent implements OnInit, OnDestroy {

  /** The name of the form to add this control to. Should probably always be 'powersearchForm' */
  @Input() public formName: FormGroup;

  /** The name of the array to add to the form. Should share the name of the field in the given 'choice' */
  @Input() public formArrayName: string;

  /** Defines whether the 'choice' is expanded or collapsed (collapsed by default) */
  @Input() public isOpen: boolean = false;

  /**
     * {configData} Used to read custom typeahead configurations
  */
  @Input() public configData: PowersearchChoiceModel;
  @Input() public displayData: any;
  @Input() public isEditMode: boolean;

  /**
    * {configData} Used to set default typeahead configurations
 */
  public displayDataResults: TypeAheadDisplayResultModel;

  public projectTitle: any;

  private subscriptions = new Subscription();

  @Output() public isOpenChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  /**
   * Constructor for the TypeaheadChoiceComponent
   *
   * @param psEventService Service for handling events related to Powersearch.
   */
  constructor(private psEventService: PowersearchEventService, private httpClient: HttpClient, private urlService: UrlResolverService) { }

  /**
   * Angular lifecycle hook for initialization logic.
   * Used here to initialize form controls and to subscribe to events.
   */
  public ngOnInit(): void {
    this.initTypehead();

    const arr = this.formName.get(this.formArrayName) as FormArray;

    if (this.displayData) {
      if (!arr.controls.length) {
        this.projectTitle = this.displayData;
      }
      while (arr.length) {
        arr.removeAt(0);
      }
      this.displayData.forEach((data, index) => {
        arr.push(this.buildCriteria(data));
        if (data.condition) {
          arr.controls[index].get('condition').setValue(data.condition);
          if (index === (this.displayData.length - 1)) {
            arr.push(this.buildCriteria(''));
          }
        }
        this.setCriteriaValue(data.value, arr.controls[index], index);
      });
      // arr.push(this.buildCriteria(''));
    } else if (this.isEditMode && !this.displayData) {
      while (arr.length) {
        arr.removeAt(0);
      }
      arr.push(this.buildCriteria(''));
    } else if (!arr.length) {
      arr.push(this.buildCriteria(''));
    }

    this.subscriptions.add(this.psEventService.getCategoryRemoved().subscribe(
      (fieldName) => {
        if (this.formArrayName === fieldName) {
          this.removeAllCriteria(fieldName);
        }
      })
    );
    this.subscriptions.add(this.psEventService.getSelectionRemoved().subscribe(
      (event) => {
        if (this.formArrayName === event.fieldName) {
          this.removeCriteria(event.fieldName, event.index);
        }
     })
    );

  }

  public initTypehead() {
    this.displayDataResults = {
      primaryDisplayColumn: (this.configData && this.configData.typeaheadConfig) ?
        this.configData.typeaheadConfig.displayName : 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: [],
        display: ''
      },
      metaDataColumns: {
        BUSINESS_CREATIVE: [],
        PRODUCTION: [],
        CASTING: [],
        default: []
      },
      noRecordsToReturn: '10',
      service: {
        serviceClass: this,
        get: 'getQueryResult'
      }
    };
  }

  /**
   * Used for building a new FormGroup for each typeahead in the list.
   *
   * @param val The value to give to the typeahead.
   */
  public buildCriteria(val: any): FormGroup {
    return new FormGroup({
      'value': new FormControl((typeof (val) === 'string') ? val : val.value),
      'condition': new FormControl(null)
    });
  }

  /**
   * Adds another typeahead to the list when pressing the radio button.
   *
   * @param ref The element reference so we can set the radio button to checked.
   * @param index The index of the current typeahead where the radio button was pressed.
   */
  public addCriteria(ref, index): void {
    const criterias = this.formName.get(this.formArrayName) as FormArray;
    if (index === (criterias.controls.length - 1)) {
      criterias.push(this.buildCriteria(''));
    }
    criterias.controls[index].get('condition').setValue(ref.value);
    ref.checked = true;
  }

  /**
   * Used to remove a item from the 'Your Selections' section. If it's the last one - set value to empty string.
   * Listens to an event from the {@link PowersearchComponent} before removing the item.
   *
   * @param fieldName The name of the field to remove the item from.
   * @param index The index position of the item to remove.
   */
  public removeCriteria(fieldName, index): void {
    const criterias = this.formName.get(fieldName) as FormArray;
    if (criterias && criterias.controls.length !== 1) {
      criterias.removeAt(index);
    } else {
      (criterias) ? criterias.controls[index].patchValue({ value: '' }) : '';
    }
    (criterias) ? criterias.controls[criterias.controls.length - 1].patchValue({ condition: false }) : '';
  }

  /**
   * Used to remove all items from a particular category from the 'Your Selections' section as well as adding a 'blank' one back in.
   * Listens to an event from the {@link PowersearchComponent} before removing the items.
   *
   * @param fieldName The name of the field (category) to remove the items from.
   */
  public removeAllCriteria(fieldName): void {
    const criterias = this.formName.get(fieldName) as FormArray;

    while (criterias.length) {
      criterias.removeAt(0);
    }
    criterias.push(this.buildCriteria(''));
    this.isOpen = false;
    this.isOpenChange.emit(this.isOpen);
  }

  /**
   *
   *
   * {*} event Used to get typed value from typeahead
   * {*} criteria Used to clear typeahead so dependent form will update
   * TypeaheadChoiceComponent
   */
  public onTypeHeadChange(event, criteria): void {
    if (!event.target['value']) {
      criteria.get('value').setValue('');
      this.removeCriteria(event.fieldName, event.index);
    }
  }

  /**
   * Used to set selected typeahead item name to criteria to enable switch and remove button features
   *
   * {*} item The selected typeahead item
   * {*} criteria Used to set selected typeahead item to the active criteria
   */
  public setCriteriaValue(item, criteria, index) {
    if (item !== null) {
      criteria.get('value').setValue({ value: item.typeAheadDisplayName ? item.typeAheadDisplayName : item.title, data: item });
      criteria.get('value').markAsDirty();
    }
  }

  /**
   * Used to get typeahead query result based on dynamic endpoint
   *
   * {string} searchTerm Typeahead search query term
   * {string} recordCount Limit to return records from API (default is 10)
   * {Observable<any>}
   */
  public getQueryResult(searchTerm: string, recordCount: string): Observable<any> {
    if (this.configData.typeaheadConfig) {
      const params = new HttpParams().set('searchTerm', searchTerm).set('recordCount', recordCount);
      return this.httpClient.get(this.urlService.getServiceEndpointUrl(this.configData.typeaheadConfig.endpoint), { params: params })
        .map((res: any[]) => {
          return this.processResponse(res);
        });
    } else {
      return new EmptyObservable();
    }
  }

  /* Define response eteration*/
  public processResponse(response) {
    if (this.configData.typeaheadConfig.endpoint.includes('projectTitles')) {
      return response['_embedded']['projectTitles'];
    } else {
      return response;
    }
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
