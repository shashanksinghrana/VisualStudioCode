import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PowersearchComponent } from './powersearch.component';

describe('PowersearchComponent', () => {
  let component: PowersearchComponent;
  let fixture: ComponentFixture<PowersearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PowersearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PowersearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
