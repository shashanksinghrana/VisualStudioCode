import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PowersearchComponent } from './powersearch.component';
import { FormModule } from '../../form/form.module';
import { ReactiveFormsModule } from '@angular/forms';
import { GridModule } from '../../elements/grid/grid.module';
import { TypeAheadModule } from './../../elements/type-ahead/type-ahead.module';
import { ChecklistChoiceComponent } from './custom-choice/checklist-choice/checklist-choice.component';
import { TypeaheadChoiceComponent } from './custom-choice/typeahead-choice/typeahead-choice.component';
import { PowersearchEventService } from '../../../services/events/powersearch/powersearch-event.service';
import { ModalModule } from '../../../modal/modal.module';
import { ButtonModule } from '../../elements/button/button.module';
import { ChecklistDateComponent } from './custom-choice/checklist-date/checklist-date.component';
/**
 * The PowersearchModule
 *
 * Module that contains the components for Powersearch.
 */
@NgModule({
  imports: [
    CommonModule,
    FormModule,
    ModalModule,
    ReactiveFormsModule,
    GridModule,
    TypeAheadModule.forRoot(),
    ButtonModule
  ],
  declarations: [PowersearchComponent, ChecklistChoiceComponent, TypeaheadChoiceComponent, ChecklistDateComponent],
  exports: [PowersearchComponent]
})
export class PowersearchModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: PowersearchModule,
      providers: [PowersearchEventService]
    };
  }
}
