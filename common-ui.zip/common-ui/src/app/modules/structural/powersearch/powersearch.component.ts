import { Component, OnInit, Input, ViewChild, EventEmitter, Output, OnDestroy } from '@angular/core';
import { DropdownModel } from '../../../models/dropdown/dropdown.model';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { SaveButtonModel } from '../../../models/button/save-button/save-button.model';
import { ColumnDefModel } from '../../../models/grid/column-def/column-def.model';
import { GridPageOptionsModel } from '../../../models/grid/grid-page-options.model';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
import { ModalSaveSearchComponent } from '../../../modal/save-search/modal-save-search.component';
import { PowersearchChoiceModel } from '../../../models/powersearch/powersearch-choice.model';
import { PowersearchEventService } from '../../../services/events/powersearch/powersearch-event.service';
import { GridPaginationModel } from '../../../models/grid/grid-pagination.model';
import { NavBarHistoryModel } from '../../../models/nav-bar/nav-bar-history.model';
import { UrlResolverService } from '../../../services/non-http-data/url-resolver.service';
import { NavBarEventService } from '../../../services/events/nav-bar/nav-bar-event.service';

import { HttpParams } from '@angular/common/http';
import { Subscription } from 'rxjs';
import * as moment_ from 'moment';
const moment = moment_;

/**
 * The PowersearchComponent
 *
 * Common Component for handling Powersearch functionality for advanced database querying.
 */
@Component({
  selector: 'c2c-powersearch',
  templateUrl: './powersearch.component.html',
  styleUrls: ['./powersearch.component.scss']
})
export class PowersearchComponent implements OnInit, OnDestroy {
  public dateRange: FormControl;
  public dateRangeOptions: DropdownModel;
  public isSelectionsExpanded: boolean = false;
  public isInvalidField: boolean = false;
  public disableSearch: boolean = false;
  public showGrid: boolean = false;
  public disableReset: boolean = true;
  public powerSearchForm: FormGroup;
  public prevSavedSearches: FormControl;
  public pagination: any;
  public removeTitle: boolean = false;
  public reportForm: FormControl;
  public reportFormOptions: DropdownModel;
  public dateValuesFromPowerSearch: any = { startDate: 'All', endDate: 'All' };
  public choices: any[] = [];
  public resetData: any = { reset: false };
  private subscriptions: Subscription = new Subscription();
  private statusDateError: boolean = false;
  public columnApi: any;
  private isExpandModeTouched: boolean = false;

  @ViewChild('modalSaveSearchComponent') public ModalSaveSearchComponent: ModalSaveSearchComponent;

  /** Defines each 'choice' in the 'Narrow Your Choices' section based on an array of {@link PowersearchChoiceModel} */
  // @Input() public choices: PowersearchChoiceModel[] = Defaults.DEFAULT_POWERSEARCH_CHOICES;

  @Input('choiceConfig')
  set choiceConfig(config: any) {
    this.choices = config;
  }

  get choiceConfig(): any {
    return this.choices;
  }

  /** Defines the data that will be passed to the Grid when results are found */
  @Input() public resultsData: any[] = [];

  @Input() public isEditMode: boolean;

  /** Defines the column definitions of the results grid */
  @Input() public resultsDefs: ColumnDefModel[] = Defaults.DEFAULT_COL_DEFS_PROJECTS;

  /** Defines the page options (i.e. title, buttons) of the results grid */
  @Input() public resultsPageOptions: GridPageOptionsModel;

  /** Defines the pagination values (i.e. current page, total pages, etc.) of the results grid, for use with server-side pagination */
  @Input() public resultsPagination: GridPaginationModel;

  /** Outputs a event when the user presses the 'Search' button to run a query.
   *  This can be listened to from the implementation side to apply the necessary logic to query the backend for results */
  @Output() public searchEvent: EventEmitter<any> = new EventEmitter<any>();

  /** Defines Save button options modal**/
  @Input() public saveButtonOptions: SaveButtonModel = new SaveButtonModel('TestFC',
    'TestAllProject', 'modal', '', ModalSaveSearchComponent, 'open');

  @Input('setSearchOption')
  set setSearchOption(option: any) {
    if (option) {
      this.prevSavedSearches.patchValue(option);
    }
  }

  @Input('triggerSearch')
  set triggerSearch(searchObj: any) {
    if (searchObj && searchObj.search) {
      this.getSearchResults();
    }
  }

  /* Defines data for report form list */
  @Input() public reportFormOption: any[] = Defaults.DEFAULT_POWERSEARCH_REPORT_FORMS;

  /* Defines data for export as list */
  @Input() public exportOptions: DropdownModel;

  /* Defines input name for save search modal */
  @Input() public saveSearchModalInput: string = '';

  /** Defines whether the power search grid should enable multiple level sorting */
  @Input() public enableMultiColumnSorting: boolean = true;

  /** Outputs a event when the user selects a value from Report Form dropdown.
  *  This can be listened to from the implementation side to apply the necessary logic to query the backend for results */
  @Output() public selectedEventForReportForm: EventEmitter<any> = new EventEmitter<any>();

  /** Outputs a event when the user selects a value from Previous/Saved Search dropdown.
    *  This can be listened to from the implementation side to apply the necessary logic to query the backend for results */
  @Output() public selectedEventForPrevSavedSearchChange: EventEmitter<any> = new EventEmitter<any>();

  /** Outputs Save Search event for saving a Search
    *  This can be listened to from the implementation side to apply the necessary logic to query the backend for results */
  @Output() public saveSearch: EventEmitter<any> = new EventEmitter<any>();

  /** Outputs selected export button option event.
    *  This can be listened to from the implementation side to apply the necessary logic to query the backend for results */
  @Output() public selectedExportOption: EventEmitter<any> = new EventEmitter<any>();

  /** Outputs Delete Search event for deleting a Search
    *  This can be listened to from the implementation side to apply the necessary logic to query the backend for results */
  @Output() public deleteSearch: EventEmitter<any> = new EventEmitter<any>();

  /* Defines data for Previous/Saved Searched Dropdown */
  @Input() public previouslySavedSearchOptions: DropdownModel = new DropdownModel(null, null, null, null,
    Defaults.DEFAULT_POWERSEARCH_PREV_SAVED_SEARCHES);

  /** Outputs Event while opening save search modal for deleting a Search
    *  This can be listened to from the implementation side to apply the necessary logic to query the backend for results */
  @Output() public displaySavedSearchName: EventEmitter<any> = new EventEmitter<any>();
  /**
   * Constructor for the PowersearchComponent
   *
   * @param psEventService Service for handling events related to Powersearch.
   * @param fb Formbuilder class for creating form elements.
   */
  constructor(private psEventService: PowersearchEventService, private fb: FormBuilder,
    private urlResolverService: UrlResolverService, private navBarEventService: NavBarEventService) { }

  /**
   * Angular lifecycle hook for initialization logic.
   * Used here to initialize variables and setup the reactive form.
   */
  public ngOnInit(): void {
    this.showGrid = false;
    const count = this.resultsData ? this.resultsData.length : 0;
    this.dateRangeOptions = new DropdownModel(null, null, null, null, Defaults.DEFAULT_POWERSEARCH_DATE_RANGES);
    this.reportFormOptions = new DropdownModel(null, null, null, null, this.reportFormOption);
    this.resultsPageOptions = new GridPageOptionsModel(true, `Search Results: ${count}
    Items Found`, true, false, false, true, false, false, true, true);
    this.exportOptions = this.exportOptions;
    this.powerSearchForm = this.fb.group({
      'startDate': this.fb.control(this.dateValuesFromPowerSearch.startDate),
      'endDate': this.fb.control(this.dateValuesFromPowerSearch.endDate)
    });
    this.prevSavedSearches = this.fb.control(null);
    this.dateRange = this.fb.control(this.dateRangeOptions.options[4]);
    this.reportForm = this.fb.control(null);
    this.getDateValuesValueChanges();
    this.getResetFormSubscription();
    this.addSubscriptions();
    this.initForm();
  }

  private addSubscriptions(): void {
    this.subscriptions.add(this.powerSearchForm.statusChanges.subscribe(val => {
      this.checkSelection();
      this.checkFormDateValidity();
    }));
  }

  /** This method is used to collapse selection criteria */
  private checkSelection(): void {
    if (!this.isExpandModeTouched) {
      // Wait to still powersearch form status stable
      setTimeout(() => {
        let isExpand = false;
        if (this.choices && this.choices.length) {
          for (let i = 0; i < this.choices.length; i++) {
            // If form change then expand selection no need to check other fields
            const fieldName = this.powerSearchForm.get(this.choices[i].fieldName);
            if (fieldName && fieldName.dirty) {
              this.isExpandModeTouched = true;
              isExpand = true;
              break;
            }
          }
        }
        this.isSelectionsExpanded = isExpand;
      }, 100);
    }
  }

  /**
   * Toggles the expand/collapse of the 'Your Selections' section.
   */
  public expandSelections() {
    this.isSelectionsExpanded = !this.isSelectionsExpanded;
  }

  private checkFormDateValidity(): void {
    if (!this.isInvalidField && !this.statusDateError) {
      const textField = this.powerSearchForm.get('textFields');
      const workActivity = this.powerSearchForm.get('workActivity');
      const compensation = this.powerSearchForm.get('compensation');
      const invalidTextfield = (textField && textField.touched && textField.invalid);
      const invalidWorkActivity = (workActivity && workActivity.touched && workActivity.invalid);
      const invalidCompensation = (compensation && compensation.touched && compensation.invalid);
      if (invalidTextfield || invalidWorkActivity || invalidCompensation) {
        this.disableSearch = true;
      } else {
        this.disableSearch = false;
      }
    } else {
      this.disableSearch = true;
    }
  }

  public checkStatusValidity(isValid: boolean): void {
    this.statusDateError = isValid;
    this.checkFormDateValidity();
  }

  /**
   * Handles the logic for retrieving search results.
   * Currently emits an event that can be listened to on the implementation side.
   */
  public getSearchResults(params?: HttpParams, isRefreshActivity?: boolean) {
    // this.rangeValidation();
    if (!this.isInvalidField || (this.dateRange.value === 'All' || this.dateRange.value.name === 'All')) {
      const formData = this.prepareFormRequest();
      this.searchEvent.emit({ formData: formData, filterParams: params, isRefresh: isRefreshActivity });
      this.showGrid = true;
    }
    this.disableSearch = true;
  }

  /**
   * Handles the initialization of the form to create form elements based off of the 'choices' provided.
   */
  public initForm(): void {
    this.choices.forEach((choice: PowersearchChoiceModel) => {
      if (choice.type === 'checklist' || choice.type === 'typeahead' || choice.type === 'generic'
        || choice.type === 'checklistTextbox' || choice.type === 'statusDate') {
        this.powerSearchForm.addControl(choice.fieldName, this.fb.array([]));
      } else {
        this.powerSearchForm.addControl(choice.fieldName, this.fb.control(null));
      }
    });
  }

  public getDateValuesValueChanges(): void {
    this.psEventService.getOnChangeDateValues().subscribe(
      (value) => {
        this.setDateRange(value);
      }
    );
  }

  /**
   * Sets the value of the 'startDate' field based on the dropdown selected.
   * Used for querying the database on a provided date range.
   */

  public getResetFormSubscription(): void {
    this.subscriptions.add(
      this.psEventService.getResetForm().subscribe(value => {
        this.onChangePrevSavedSearch('');
      })
    );
  }

  /**
   * Sets the start date based on the days value provided.
   *
   * @param days The number of days before today's date.
   */
  private setStartDate(days: number): void {
    const date = new Date();
    date.setDate(date.getDate() - days);
    const startDate = this.removeTimezone(date);
    this.powerSearchForm.get('startDate').patchValue(startDate);
    this.setEndDate();
  }

  private setDateRange(value) {
    const startDate = this.powerSearchForm.get('startDate');
    const endDate = this.powerSearchForm.get('endDate');

    if (value.label === '30') {
      this.dateRange = this.fb.control(this.dateRangeOptions.options[0]);
    } else if (value.label === '60') {
      this.dateRange = this.fb.control(this.dateRangeOptions.options[1]);
    } else if (value.label === '90') {
      this.dateRange = this.fb.control(this.dateRangeOptions.options[2]);
    } else if (value.label === '180') {
      this.dateRange = this.fb.control(this.dateRangeOptions.options[3]);
    } else if (value.label === 'custom') {
      this.dateRange = this.fb.control(this.dateRangeOptions.options[5]);
    } else {
      if (value.startDate === 'All' && value.endDate === 'All') {
        this.dateRange = this.fb.control(this.dateRangeOptions.options[4]);
      }
    }
    startDate.patchValue(value.startDate);
    endDate.patchValue(value.endDate);
  }

  /*
  * Sets the end date to today's date.
  */
  private setEndDate() {
    const date = new Date();
    const endDate = this.removeTimezone(date);
    this.powerSearchForm.get('endDate').patchValue(endDate);
  }

  /**
   * Checks whether a given control has been marked dirty.
   * Used to apply the 'dargenta' colored border to a choice when it's modified.
   *
   * @param fieldName The name of the field to check.
   */
  public isDirty(fieldName: string): boolean {
    return this.powerSearchForm.get(fieldName).dirty;
  }

  /**
   * Removes a category from the 'Your Selections' section, and marks that field pristine again.
   *
   * @param fieldName The name of the category to remove.
   */
  public removeSelectionsCategory(fieldName): void {
    this.psEventService.categoryRemovedEvent(fieldName);
    this.cleanFormControl(fieldName);
    this.removeTitle = true;
    this.disableSearch = false;
  }

  /**
   * Removes a specific item from the given category in the 'Your Selections' section.
   * If it is the last item in a 'typeahead' list, then the field is marked pristine again.
   *
   * @param fieldName The name of the category to remove the item from.
   * @param index The index of the item to remove.
   */
  public removeSelectionsItem(fieldName, index): void {
    if (this.powerSearchForm.get(fieldName).value.length === 1) {
      this.removeSelectionsCategory(fieldName);
      this.disableSearch = false;
    } else {
      this.psEventService.selectionRemovedEvent({ fieldName, index });
      this.disableSearch = false;
    }
  }

  public removeCustomSelectionItem(fieldName, item) {
    const request = { field: fieldName, allRemoved: false, item: item };
    this.psEventService.customCategoryRemovedEvent(request);
    this.disableSearch = false;
  }

  public removeCustomSelectionCategory(fieldName): void {
    const request = { field: fieldName, allRemoved: true };
    this.psEventService.customCategoryRemovedEvent(request);
    this.cleanFormControl(fieldName);
    //  this.removeTitle = true;
    this.disableSearch = false;
  }

  /** This method is used to track by number to improve performance */
  public trackByFn(index): number {
    return index;
  }

  /**
   * Toggles the expand/collapse of a given 'choice' in the 'Narrow Your Choices' section.
   *
   * @param choice The choice to toggle.
   */
  public toggleChoice(choice: PowersearchChoiceModel): void {
    choice.isOpen = !choice.isOpen;
  }

  /* Method to define deal date validation */
  public rangeValidation() {
    const endDate = this.powerSearchForm.controls['endDate'].value;
    const startDate = this.powerSearchForm.controls['startDate'].value;
    this.isInvalidField = true;
    if (startDate && endDate) {
      const isBefore = moment(startDate).isSameOrBefore(endDate);
      if (isBefore) {
        this.isInvalidField = false;
      }
    }
    this.checkFormDateValidity();
  }

  public getDateRangeValueChanges(dateRange: string): void {
    const startDate = this.powerSearchForm.get('startDate');
    const endDate = this.powerSearchForm.get('endDate');
    switch (dateRange) {
      case 'Past 30 Days':
        this.setStartDate(30);
        break;
      case 'Past 60 Days':
        this.setStartDate(60);
        break;
      case 'Past 90 Days':
        this.setStartDate(90);
        break;
      case 'Past 180 Days':
        this.setStartDate(180);
        break;
      case 'All':
        startDate.patchValue('All');
        endDate.patchValue('All');
        break;
      case 'Custom Dates...':
        startDate.patchValue(null);
        endDate.patchValue(null);
        this.rangeValidation();
        break;
      default:
        startDate.patchValue(null);
        endDate.patchValue(null);
        break;
    }
  }

  /*Method to perform on select value*/
  public onChangeDateOpt(event) {
    this.isInvalidField = false;
    this.disableSearch = false;
    this.getDateRangeValueChanges(event.name);
  }

  public onChangeReportForm(event) {
    this.selectedEventForReportForm.emit(event);
  }

  public onChangePrevSavedSearch(event) {
    let name = '';
    this.isExpandModeTouched = false;
    let reset = true;
    if (event) {
      name = event.value ? event.value : (event.name ? event.name : '');
      if (name) {
        reset = false;
      }
    }
    this.saveButtonOptions = new SaveButtonModel('TestFC', 'TestAllProject', 'modal', '', ModalSaveSearchComponent, 'open', name);
    this.resetData = { reset: reset };
    if (reset) {
      this.exportOptions.selection = null;
      this.exportOptions = {...this.exportOptions};
      this.dateRange.patchValue({ value: 'All' });
      this.showGrid = false;
      this.resetForm();
    }
    this.selectedEventForPrevSavedSearchChange.emit(event);
    this.resetPrevSearchData();
  }

  /** Method to handle powersearch form on previouse save search value changes */
  public resetPrevSearchData(): void {
    this.resultsData = [];
    this.choices.forEach((choice) => {
      choice.isOpen = false;
    });
    this.showGrid = false;
    this.powerSearchForm.reset();
    this._markFormPristine(this.powerSearchForm);
    this.resultsPageOptions = new GridPageOptionsModel(true, `Search Results: 0 Items Found`,
      false, false, false, true, false, false, true, true);
  }

  private _markFormPristine(form: FormGroup): void {
    Object.keys(form.controls).forEach(control => {
      form.controls[control].markAsPristine();
    });
  }

  /**
   * Marks a given form control (or entire form if one isn't specified) as untouched/pristine.
   *
   * @param fieldName Optional name of the field to mark.
   */
  public cleanFormControl(fieldName?: string): void {
    if (fieldName) {
      this.powerSearchForm.get(fieldName).markAsPristine();
      this.powerSearchForm.get(fieldName).markAsUntouched();
    } else {
      this.powerSearchForm.markAsPristine();
      this.powerSearchForm.markAsUntouched();
    }
  }

  /**
   * Resets the form back to it's initial state when the 'reset' icon on the Grid is pressed.
   */
  public resetForm(): void {
    Object.keys(this.powerSearchForm.controls).forEach((control) => {
      this.removeSelectionsCategory(control);
    });
    this.resultsData = [];
    // this.powerSearchForm.reset();
    this.choices.forEach((choice) => {
      choice.isOpen = false;
    });
    this.dateRange.patchValue({ value: 'All' });
    this.prevSavedSearches.patchValue('');
    this.reportForm.patchValue('');
    this.displaySavedSearchName.emit('');
    this.showGrid = false;
    this.resultsPageOptions = new GridPageOptionsModel(true, `Search Results: 0 Items Found`,
      true, true, false, true, false, false, true);
    this.onChangeReportForm(null);
  }

  /* Method to remove timezone from date*/
  public removeTimezone(date) {
    let format = null;
    const isValid = moment(date).isValid();
    if (isValid) {
      format = moment.parseZone(date).format('YYYY-MM-DD');
    }
    return format;
  }

  /** Method to add item for history link*/
  public getProjectClicked(evt: any): void {
    let url;
    if (evt.route.endsWith('summary')) {
      url = this.urlResolverService.getServiceEndpointUrl(`#${evt.route}`);
    } else {
      url = this.urlResolverService.getServiceEndpointUrl(`#${evt.route}/performers`);
    }
    const title = evt.subtitle ? `${evt.title} (${evt.subtitle})` : evt.title;
    const historyItem: NavBarHistoryModel = new NavBarHistoryModel();

    historyItem.destinationUrl = url;
    historyItem.historyLabel = title;
    historyItem.iconClass = 'navbar-projector';
    historyItem.source = 'FC';

    this.navBarEventService.setNavBarHistory(historyItem);
  }

  public exportGrid(choice) {
    this.selectedExportOption.emit(choice);
  }

  private prepareFormRequest(): any {
    const request = this.powerSearchForm.value;
    const unionForm = this.powerSearchForm.get('union');
    const billingForm = this.powerSearchForm.get('billing');
    const statusDateForm = this.powerSearchForm.get('statusDate');
    const textFieldsForm = this.powerSearchForm.get('textFields');
    if (unionForm && unionForm.untouched) {
      request['union'] = [];
    }
    if (billingForm && billingForm.untouched) {
      request['billing'] = [];
    }
    if (statusDateForm && statusDateForm.untouched) {
      const status = request['statusDate'][0];
      if (status) {
        status.values = [];
      }
    }
    if (textFieldsForm && textFieldsForm.untouched) {
      const textFields = request['textFields'][0];
      if (textFields) {
        textFields.values = [];
      }
    }
    return request;
  }

  public saveSearchVal(event) {
    const formData = this.prepareFormRequest();
    this.saveSearch.emit({ event: event, formData: formData, dateRange: this.dateRange.value.name });
  }

  public deletePrevSavedSearch(event) {
    this.deleteSearch.emit(event);
  }

  public openSaveSearchModal(event) {
    this.displaySavedSearchName.emit(event);
  }

  public gridready(params) {
    this.columnApi = params.columnApi;
    this.columnApi.getColumn('title').setSort('asc');
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
