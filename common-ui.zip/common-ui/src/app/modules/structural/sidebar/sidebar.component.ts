import { Subscription } from 'rxjs';
import { Component, Input, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { SidebarModel } from '../../../models/sidebar/sidebar.model';
import { SidebarService } from '../../../services/http/sidebar/sidebar.service';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
import { SidebarEventService } from '../../../services/events/structural/sidebar-event.service';
import { Router, NavigationEnd } from '@angular/router';
import { UnsaveModalPopUp } from '../../../utils/unsave/unsave-modal';
import { UnsavedChangesService } from '../../../services/events/modal/unsaved-changes-event/unsaved-changes.service';
import { ModalUnsavedChangesComponent } from '../../../modal/unsaved-changes/modal-unsaved-changes.component';
/**
 * The Sidebar Component
 *
 * Common Component for creating the navigation structure of the Sidebar.
 */
@Component({
  selector: 'c2c-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  providers: [SidebarService, SidebarEventService]
})
export class SidebarComponent implements OnInit, OnDestroy {
  public company: string = 'UST Global Media Services, Inc.';
  public copyright: string = 'Copyright 2019';
  public defaultNavItems: Array<SidebarModel> = Defaults.DEFAULT_NAV_ITEMS;
  public sidebarCollapsed: boolean = false;
  // public version: string = Defaults.DEFAULT_VERSION;
  public subscription = new Subscription();
  public checkPop: boolean = false;
  public setVAlue: boolean = false;
  public navigateItem: any;
  public isExpanded: boolean = false;

  /** The prefix of the module that this sidebar will be used in. */
  @Input() public modulePrefix: string;
  @Input() public versionNumber: string = Defaults.DEFAULT_VERSION;
  @Input() public studioImageURL: string = "assets/images/WarnerBros_transparent.png";

  /** Defines the navigation links in the Sidebar. This needs to be an array of {@link SidebarModel} */
  @Input() public navItems: Array<SidebarModel> = this.defaultNavItems;
  @ViewChild('checkModal') checkModal: ModalUnsavedChangesComponent;
  /**
   * Constructor for the SidebarComponent
   *
   * @param sidebarService The data service for the sidebar.
   */
  constructor(private sidebarService: SidebarService, private sidebarEventService: SidebarEventService, private router: Router,
    private unsavedService: UnsavedChangesService, private unsavePopup: UnsaveModalPopUp) {
  }

  /**
   * Angular lifecycle hook for initialization logic. We use it here to set
   * build version to be displayed in the sidebar footer.
   */
  ngOnInit() {
    this.sidebarService.getVersion(this.modulePrefix).subscribe(
      (data) => {
        this.versionNumber = data.versionNumber;
      }
    );

    this.subscription = this.unsavePopup.setvalue.subscribe(res => {
      this.checkPop = res && res.showPopup;
    });
    this.expandOnLoad();
  }
  
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  /**
   * Action for toggling the expand/collapse of the sidebar.
   */
  public toggleSlideAwayDiv() {
    this.sidebarCollapsed = this.sidebarCollapsed === false ? true : false;
    this.sidebarEventService.sideBarChangeEvent(this.sidebarCollapsed);
  }

  /**
   * Action for expanding a sidebar navigation item. If the sidebar contains nested links,
   * then clicking on them will call this function to show the sub-links.
   *
   * @param navItem The navigation item to expand.
   */
  public expandNavItem(navItem: SidebarModel) {
    if (navItem.route) {
      this.navigateItem = navItem.route;

      if (this.checkPop) {
        this.unsavePopup.checkNavigation(navItem.route);
      } else {
        this.router.navigate(['/' + navItem.route]);
      }

    }
    if (navItem.hasSubItems) {
      this.expandMenu(navItem);
    } else if (navItem.displayOrder % 1 === 0) {
      // Hide other opened menus in case of no submenu for clicked item
      this.hideSubMenus();
    }
  }

  /** This function is used for expand menu based on passed criteria or toggle active menu */
  private expandMenu(navItem, isExpand?: boolean): void {
    const parent: string = navItem.displayOrder.toString().split('.')[0];
    for (const item of this.navItems) {
      if (item.displayOrder.toString().startsWith(`${parent}.`)) {
        if (isExpand !== undefined) {
          item.display = isExpand;
        } else {
          item.display = !item.display;
        }
      }
    }
  }

  /** This function is used to hide all submenus */
  private hideSubMenus(): void {
    for (const navItem of this.navItems) {
      if (navItem.displayOrder % 1 !== 0) {
        navItem.display = false;
      }
    }
  }

  /** This function is used to listen router events and expanding menu based on defined active routes */
  private expandOnLoad(): void {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        for (const item of this.navItems) {
          if (this.getActiveRoutes(item)) {
            this.expandMenu(item, true);
            break;
          }
        }
      }
    });
  }

  public closePop(evt): void {
    this.setVAlue = evt;
    if (this.setVAlue) {
      this.router.navigate(['/' + this.navigateItem]);
      this.setVAlue = false;
      this.checkPop = false;
      this.unsavePopup.setActivatePopup(this.checkPop);
    }
  }

  public getActiveRoutes(item: SidebarModel): boolean {
    const url = this.router.url;
    if (item.activeRoutes) {
      let valid = false;
      item.activeRoutes.forEach((route) => {
        if (url.includes(route)) {
          valid = true;
          return false;
        }
      });
      return valid;
    } else {
      return url.includes(item.route);
    }
  }
}
