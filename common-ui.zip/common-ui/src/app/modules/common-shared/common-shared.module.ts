import { SsnValidatorModule } from './../../directives/ssn-validator/ssn-validator.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModuleWithProviders } from '@angular/compiler/src/core';
import { AutofocusDirective } from '../../directives/focus/auto-focus.directive';
import { EnterKeyClickDirective } from '../../directives/keyboard-events/enter-key-click.directive';
import { EscKeyPressedDirective } from '../../directives/keyboard-events/esc-key-pressed.directive';
import { EinValidatorDirective } from '../../directives/ein-validator/ein-validator.directive';
import { LoadingSpinnerComponent } from '../elements/loading-spinner/loading-spinner/loading-spinner.component';

@NgModule({
  imports: [
    CommonModule,
    SsnValidatorModule
  ],
  declarations: [
    AutofocusDirective,
    EnterKeyClickDirective,
    EscKeyPressedDirective,
    EinValidatorDirective,
    LoadingSpinnerComponent

  ],
  exports: [ AutofocusDirective,
             EnterKeyClickDirective,
             EscKeyPressedDirective,
             EinValidatorDirective,
             LoadingSpinnerComponent]
})
export class CommonSharedModule {

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CommonSharedModule
    };
  }
}
