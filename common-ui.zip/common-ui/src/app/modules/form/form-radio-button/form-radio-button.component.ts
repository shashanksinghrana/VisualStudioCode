import { Component, Input, EventEmitter, Output, forwardRef } from '@angular/core';
import { RadioButtonModel } from '../../../models/radio-button/radio-button.model';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 'c2c-form-radio-button',
  templateUrl: './form-radio-button.component.html',
  styleUrls: ['./form-radio-button.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormRadioButtonComponent),
    multi: true
  }]
})
export class FormRadioButtonComponent implements ControlValueAccessor {

  /** Defines the options for the multi-button radio buttons. */
  @Input() radioOptions: RadioButtonModel = Defaults.DEFAULT_RADIO_BUTTON_OPTIONS;

  /** Flag that determines if radio button should be single. Use if radio buttons are to be included as part of a list. */
  @Input() singleButton: boolean = false;

  /** Defines the options for the single button radio buttons. */
  @Input() public singleButtonOptions: {} = { name: 'optRadio', id: 'radioB' };

  /** Defines whether the single radio button is checked. */
  @Input() isChecked: boolean = false;

  /** Defines whether the single radio button is disabled. */
  @Input() disableControl: boolean = false;

  /** Defines the tabbing sequence setting. */
  @Input() tabIndex;

  /** Defines the index of element. */
  @Input() index: number;

  /** Defines the value of the dropdown to be passed to the reactive form. */
  @Input('value') public _value: any;

  /** Emits event when a the radio button choice is changed. */
  @Output() changedEvent = new EventEmitter<boolean>();

  @Output() multiCheckedEvent = new EventEmitter<boolean>();

  public readonlyToggle: boolean = false;

  /** Fired when any changes to the model are detected */
  public onChange: any = () => { };

  /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
  public onTouched: any = () => { };

  /** Getter for the value property */
  get value() {
    return this._value;
  }

  /** Setter for the value property */
  set value(val) {
    this._value = val;
    this.onChange(val);
    this.onTouched();
    if (val) { this.emitChoiceChangedEvent(val); }
  }

  /**
   * Constructor for the FormRadioButtonComponent
   */
  constructor() { }

  /**
   * OnChanges function that gets called whenever a radio button is selected.
   *
   * @param option The radio option that was clicked.
   */
  public onChanges(option) {
    this.value = option;
    this.multiCheckedEvent.emit(option);
  }

  /**
   * Emits whether or not the radio button is chosen.
   */
  public emitChoiceChangedEvent(val?: any) {
    this.changedEvent.emit(this.isChecked);
  }
  /**
   * Implementation of the registerOnChange function given through the ControlValueAccessor class.
   * Registers the onChange callback to this.onChange().
   *
   * @param fn The callback function.
   */
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Implementation of the registerOnTouched function given through the ControlValueAccessor class.
   * Registers the onTouched callback to this.onTouched().
   *
   * @param fn The callback function.
   */
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }


  /**
   * Implementation of the writeValue function given through the ControlValueAccessor class.
   * Writes the radio button value to the element.
   *
   * @param value The value to write.
   */
  writeValue(value: any): void {
    this.value = value;
  }

  /**
  * Implementation of the setDisabledState function given through the ControlValueAccessor class.
  * Detects when the disabled attribute changes, and sets it accordingly.
  *
  * @param isDisabled The boolean value to set.
  */
  setDisabledState(isDisabled: boolean): void {
    this.readonlyToggle = isDisabled;
  }
}
