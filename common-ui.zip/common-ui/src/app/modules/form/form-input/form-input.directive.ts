import { Directive, HostBinding, ElementRef, Input, OnInit, Renderer2, OnChanges, SimpleChanges, HostListener, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { formatCurrency } from '../../../utils/formatting/currency.format';

/**
 * The FormInputDirective
 *
 * Common directive for displaying a form input box in the UI.
 */
@Directive({
  selector: '[c2cFormInput]',
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormInputDirective),
    multi: true
  }]
})
export class FormInputDirective implements ControlValueAccessor, OnInit, OnChanges {
  public classes: Array<string> = [];
  public currencyAddon: ElementRef;
  public element: HTMLInputElement;

  private hasFocus: boolean = false;

  /** Toggles the currency symbol ($) on and off */
  @Input() public currencyToggle: boolean = false;

  /** Toggles whether the input should have decimal format (#.##) */
  @Input() public decimalToggle: boolean = false;

  /** Toggles whether the input should have spinner (up/down arrows that increase/decrease value) */
  @Input() public spinnerToggle: boolean = false;

  /** Toggles specific 'readonly' class for displaying disabled element as text only (as opposed to being greyed-out) */
  @Input() public toggleReadonlyDisplay: boolean = false;

  /** Toggles whether the input should be displayed in currency format(as opposed to being plain text) */
  @Input() public showCurrencyFormatting: boolean = false;

  /** Toggles whether the input value is right-aligned */
  @Input() public toggleRightAlignment: boolean = false;

  /** Defines the value of the input to be passed to the reactive form. */
  @Input('value') public _value: any;

  /** Fired when any changes to the model are detected */
  public onChange: any = () => { };

  /** Fired when the component is blurred. */
  public onTouched: any = () => { };

  /** Getter for the value property */
  get value() {
    return this._value;
  }

  /** Setter for the value property */
  set value(val) {
    this._value = val;
    this.onChange(val);
    this.onTouched();
  }

  /**
   * The constructor for FormCheckboxDirective
   *
   * @param elRef Gives direct access to the dom.
   * @param renderer Used for safely accessing elements in the DOM.
   */
  constructor (private elRef: ElementRef, private renderer: Renderer2) { }

  /**
   * Gets the native class attribute of the checkbox and returns the necessary classes.
   */
  @HostBinding('class')
  get getClass(): string {
    return this.classes.join(' ');
  }

  /**
   * NgInit built in lifecycle that gets called once the component has been initialized.
   */
  public ngOnInit(): void {
    this.element = this.elRef.nativeElement;
    this.value = this.element.value;
    this.classes.push('form-control');
    this.toggleReadonlyDisplay ? this.classes.push('c2c-readonly-input') : this.classes.push('c2c-input');
    this.appendDecimal();
    this.toggleSpinner(this.spinnerToggle);
    this.setTooltip();
    if (this.toggleRightAlignment) {
      this.renderer.setStyle(this.element, 'text-align', 'right');
    }
  }

  /**
   * NgOnChanges built in lifecycle that gets called whenever changes are made to the component.
   *
   * @param changes The value of the changes being made.
   */
  public ngOnChanges(changes: SimpleChanges): void {
    this.appendDecimal();
    this.toggleSpinner(this.spinnerToggle);
    if (changes.currencyToggle) {
      this.toggleClass(changes.currencyToggle.currentValue);
    }
  }

  /**
   * Toggles the currency symbol on and off by adding/removing necessary CSS classes and HTML.
   *
   * @param toggle The value of the currency symbol toggle.
   */
  public toggleClass(toggle: boolean): void {
    this.renderer.addClass(this.elRef.nativeElement.parentElement, 'input-group');
    this.elRef.nativeElement.insertAdjacentHTML('beforebegin', '<span *ngIf="currencyToggle" class="input-group-addon">$</span>');
    this.currencyAddon = this.elRef.nativeElement.previousSibling;
  }


  /**
   * Listens to blur events and sets the focus to false, and appends decimal if configured to.
   */
  @HostListener('blur')
  public onBlur(): void {
    this.hasFocus = false;
    this.appendDecimal();
  }

  /**
   * Listens to focus events and sets the focus to true.
   */
  @HostListener('focus')
  public onFocus(): void {
    this.hasFocus = true;
  }

  /**
   * Listens to user's input and sets the tooltip to new value.
   */
  @HostListener('input')
  public onInput(): void {
    this.value = this.element.value;
    this.setTooltip();
  }

  /**
   * Formats a number into currency format (i.e. 125.00).
   */
  private appendDecimal(): void {
    if (this.decimalToggle && this.value) {
      if (!this.hasFocus) {
        let formattedValue = this.value;
        const numRgx = /^[0-9.]*$/; 
        // Check number contains comma or not then replace otherwise its affects other functionality
        if (formattedValue && !numRgx.test(this.value)) {
          formattedValue = formattedValue.replace(/,/g, '');
        }
        const floatValue = parseFloat(formattedValue).toFixed(2);
        if (!isNaN(parseFloat(floatValue))) {
          this.value = floatValue;
          this.element.value = formatCurrency(floatValue);
          this.setTooltip();
        } else {
          this.element.value = '';
        }
      }
    }
  }

 /**
   * Toggles the up and down symbol on and off by adding/removing necessary CSS classes and HTML.
   *
   * @param toggle The value of the spinner toggle.
   */
  public toggleSpinner(toggle: boolean): void {
    if (!toggle) {
      this.renderer.removeClass(this.elRef.nativeElement.parentElement, 'spinnerToggle');
    } else {
      this.renderer.addClass(this.elRef.nativeElement.parentElement, 'spinnerToggle');
    }
  }

  /**
   * Sets the tooltip to the value of the input. Triggered whenever the value is changed by the user.
   */
  public setTooltip(): void {
    this.renderer.setAttribute(this.element, 'title', this.value);
  }

  /**
   * Implementation of the writeValue function given through the ControlValueAccessor class.
   * Writes the value of the input.
   *
   * @param value The value to write.
   */
  writeValue(value: any): void {
    this.value = value;
    this.element.value = value;
    this.appendDecimal();
  }

  /**
   * Implementation of the registerOnChange function given through the ControlValueAccessor class.
   * Registers the onChange callback to this.onChange().
   *
   * @param fn The callback function.
   */
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Implementation of the registerOnTouched function given through the ControlValueAccessor class.
   * Registers the onTouched callback to this.onTouched().
   *
   * @param fn The callback function.
   */
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  /**
   * Implementation of the setDisabledState function given through the ControlValueAccessor class.
   * Detects when the disabled attribute changes, and re-calculates the classes based on new disabled value.
   *
   * @param isDisabled The boolean value to set.
   */
  setDisabledState(isDisabled: boolean): void {
    if (isDisabled) {
      this.renderer.setAttribute(this.element, 'disabled', 'true');
      if (this.currencyAddon) {
        this.renderer.addClass(this.currencyAddon, 'c2c-addon-disabled');
      }
      if (this.currencyAddon && this.showCurrencyFormatting && !this.element.value.includes('$')) {
        this.element.value = '$' + this.element.value;
        this.renderer.addClass(this.currencyAddon, 'c2c-dollar-hidden');
      }
    } else {
      this.renderer.removeAttribute(this.element, 'disabled');
      if (this.currencyAddon) {
        this.renderer.removeClass(this.currencyAddon, 'c2c-addon-disabled');
      }
      if (this.currencyAddon && this.showCurrencyFormatting) {
        this.element.value = this.element.value.slice(1);
        this.renderer.removeClass(this.currencyAddon, 'c2c-dollar-hidden');
      }
    }
  }
}
