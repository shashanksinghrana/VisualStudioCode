import { FormInputDirective } from './form-input.directive';

describe('FormInputDirective', () => {
  it('should create an instance', () => {
    const directive = new FormInputDirective();
    expect(directive).toBeTruthy();
  });
});
