import { Component, Input, Output, EventEmitter, HostListener, forwardRef,ViewChild,Renderer2 } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
import { DatePipe } from '@angular/common';
import * as moment_ from 'moment';

declare var $: any;
const moment = moment_;

/**
 * The Jquery DatepickerComponent
 *
 * Common component for displaying pop up datepicker inputs in the UI, which are meant for selecting any dates.
 * We are utilizing the third-party component, {@link https://plugins.jquery.com/datetimepicker/ } for the main functionality.
 *
 */

@Component({
  selector: 'c2c-jqform-datepicker',
  templateUrl: './form-jqdatepicker.component.html',
  styleUrls: ['./form-jqdatepicker.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => FormJQDatepickerComponent), multi: true }, DatePipe
  ],
})

export class FormJQDatepickerComponent implements ControlValueAccessor {

  /** Defines the dateformat in text field after choosing the date */
  @Input() public dateFormat: string = Defaults.DEFAULT_JQ_DATE_FORMAT;

  /** Defines the placeholder text of the datepicker input box. Used for setting custom placeholder text. */
  @Input() public placeholder: string = Defaults.DEFAULT_JQ_INPUT_PLACEHOLDER;

  /** Defines the tabbing sequence setting. */
  @Input() public tabIndex;

  /** Option to show/hide timepicker */
  @Input() public enableTimePicker: boolean = false;

  /** This option is used to show focus on element but not open datepicker for first time */
  @Input() public initialFocus: boolean = false;

  /** Defines the maximum date to show */
  @Input() public maxDateValue: string;

  /** Defines the maximum date to show */
  @Input() public minDateValue: string;

  /** close on selection of date */
  @Input() public closeOnDateSelection: boolean = false;

  /** date selection on enter key */
  @Input() public selectOnEnterFlag : boolean = true;

  /** handles autofocus event */
  @Input() public autoFocus: Boolean = false;

  /** handler onChangeDateTime and emit the on change value */
  @Output() public onChangeDateTimeValue: EventEmitter<any> = new EventEmitter();

  /** handler onBlurEvent and emit the on change value */
  @Output() public onBlurEvent: EventEmitter<any> = new EventEmitter();

  /** handler to change initial focus */
  @Output() public initialFocusChange: EventEmitter<boolean> = new EventEmitter();

  /** Defines the ngModel value of the Datepicker. */
  @Input('value') public _value: any;
   /** Toggles specific 'readonly' class for displaying disabled element as text only (as opposed to being greyed-out) */
  @Input() public toggleReadonlyDisplay: boolean = false;

  @Input('disabledByPermission') public disabledByPermission:boolean=false;

  @ViewChild('datetimepicker') datetimepicker;

  @Input() public setFocusToItself: boolean = false;

  /** Fired when any changes to the model are detected */
  public onChange: any = () => { };

  /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
  public onTouched: any = () => { };

  public selectedValue: string;
  public displayValue: any = '';
  public dpDomId: string;  // dynamic dom id
  public readonlyToggle: boolean = false;
  get value() {
    return this._value;
  }

  /** Setter for the value property */
  set value(val) {
    this.displayValue = val && moment.parseZone(val).format(this.dateFormat);
    this._value = val;
    this.onChange(val);
    this.onTouched();
  }

  constructor(private datePipe: DatePipe,private renderer: Renderer2) {
    this.dpDomId = "dpDom" + Math.floor(Math.random() * 1000) + 1;  // dynamic dom id for each instance of datepicker. 
     $("#"+this.dpDomId).datetimepicker();
  }
  checkValidDate(value) {
    const isValid = moment(value).isValid();
    let date = null;
    if (isValid) {
      date = moment.parseZone(value).format();
    }
    return date;
  }

  reInitializeDatePicker(){
    $("#"+this.dpDomId).datetimepicker({
      format: this.dateFormat,
      step: 1,
      formatDate: 'MM/DD/YYYY',
      formatTime: "hh:mm A",
      validateOnBlur: true,
      defaultSelect: false,
      timepicker: this.enableTimePicker,
      maxDate: this.maxDateValue,
      minDate: this.minDateValue,
      closeOnDateSelect: this.closeOnDateSelection,
      selectOnEnter: this.selectOnEnterFlag, // select date on enterkey press
      // onSelectDate: (selectedDate) => {
      //   this.value = selectedDate;
      //   this.onChangeDateTimeValue.emit(selectedDate);
      // },
      // onChangeDateTime: (dp, $input) => {
      //   this.onChangeDateTimeValue.emit($input.val());
      // },
      onClose: (selectedDate, $input) => {
        if($input.val() != ""){
          var dateReg = /^(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d$/
          var dateSelected = $input.val(); 
          if(dateSelected.match(dateReg)){
            this.value = $input.val();
            this.onChangeDateTimeValue.emit($input.val());
          }else{
            this.value = new Date();
            this.onChangeDateTimeValue.emit(new Date());
          }
            
        }else{
            this.value = "";
            this.onChangeDateTimeValue.emit(this.value);
        }
        $input.datetimepicker('destroy');
      }
    });
    $.datetimepicker.setDateFormatter('moment');
  }

  // Get onchange event when the user add/remove the date manully in the textfield
  dpChange($evt){
    if($evt.target.value === ""){
      this.onChangeDateTimeValue.emit("");
    }else{
      var dateReg = /^(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d$/
      var dateSelected = $evt.target.value; 
      if(dateSelected.match(dateReg)){
        this.value = $evt.target.value;
        this.onChangeDateTimeValue.emit($evt.target.value);
      }else{
        this.value = new Date();
        this.onChangeDateTimeValue.emit(new Date());
      }
    }
  }

  openDatepicker() {
    if (!this.readonlyToggle) {
      this.reInitializeDatePicker();
      // Hiding the datepicker when page load and datepicker as first element with focus 
      if(this.initialFocus) {
        this.initialFocus = false;
        this.initialFocusChange.emit(false);
      } else {
        $("#"+this.dpDomId).datetimepicker('show');
      }
    } 
  }
  blurEvenTrigger(ev) {
    this.onBlurEvent.emit(ev);
  }
  // On clicking esc keyboard button datepicker will be closed
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(evt: KeyboardEvent) {
    $("#"+this.dpDomId).datetimepicker('hide');
  }

  /**
* Implementation of the writeValue function given through the ControlValueAccessor class.
* Writes the dropdown value to the element.
*
* @param value The value to write.
*/
  public writeValue(value: any): void {
    this.value = value;
  }

  /**
 * Implementation of the registerOnChange function given through the ControlValueAccessor class.
 * Registers the onChange callback to this.onChange().
 *
 * @param fn The callback function.
 */
  public registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Implementation of the registerOnTouched function given through the ControlValueAccessor class.
   * Registers the onTouched callback to this.onTouched().
   *
   * @param fn The callback function.
   */
  public registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  public ngOnInit(): void {
    this.renderer.addClass(this.datetimepicker.nativeElement, this.toggleReadonlyDisplay ? 'c2c-readonly-input' : 'c2c-input');
  }

  // @HostListener('blur')
  // public onBlur(): void {
  //   this.value = this.datePipe.transform(this._value, 'MM/dd/yyyy');
  // }

  /**
   * Implementation of the setDisabledState function given through the ControlValueAccessor class.
   * Detects when the disabled attribute changes, and sets it accordingly.
   *
   * @param isDisabled The boolean value to set.
   */
  public setDisabledState(isDisabled: boolean): void {
    this.readonlyToggle = isDisabled;
  }

  /**
   * Implementation of the onEnterKeyPressed function is on the basis of Compensation component in FC module.
   * setting the focus to itself on enter*/
  public onEnterKeyPressed() {
    if (this.setFocusToItself) {
      $("#"+this.dpDomId).datetimepicker('hide');
    }
  }

}
