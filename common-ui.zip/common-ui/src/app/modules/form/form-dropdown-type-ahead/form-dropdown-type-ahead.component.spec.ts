import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormDropdownTypeAheadComponent } from './form-dropdown-type-ahead.component';

describe('FormDropdownTypeAheadComponent', () => {
  let component: FormDropdownTypeAheadComponent;
  let fixture: ComponentFixture<FormDropdownTypeAheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormDropdownTypeAheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormDropdownTypeAheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
