import { SpecialStrings } from './../../../enums/characters/special-strings.enum';
import { Component, ViewChild, Input, EventEmitter, Output, forwardRef, ElementRef } from '@angular/core';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map } from 'rxjs/operators';
import { merge } from 'rxjs/observable/merge';
import { DropdownTypeAheadModel } from '../../../models/dropdown-typeahead/dropdown-typeahead.model';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
/**
 * @author Amit Yogi: Adding ControlValueAccessor to remove No value accesor for fomr Control with unspecified name attribue with three functions
 */
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

declare var $: any;

@Component({
    selector: 'c2c-form-dropdown-type-ahead',
    templateUrl: './form-dropdown-type-ahead.component.html',
    styleUrls: ['./form-dropdown-type-ahead.component.scss'],
    providers: [{
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => FormDropdownTypeAheadComponent),
        multi: true
    }
    ]
})

export class FormDropdownTypeAheadComponent implements ControlValueAccessor {

    public dropDownTemp: any = [];
    public tooltip: string;
    public readonlyToggle: boolean = false;
    model: any;
    @ViewChild('instance') instance: NgbTypeahead;
    focus$ = new Subject<string>();
    click$ = new Subject<string>();

    /** Defines the data for the dropdown. If nothing passed in, the default is used. */
    // @Input() public dropdownOptions: DropdownTypeAheadModel = Defaults.DEFAULT_DROPDOWN_TYPEAHEAD_OPTIONS;

    public dropdownOptions: DropdownTypeAheadModel = Defaults.DEFAULT_DROPDOWN_TYPEAHEAD_OPTIONS;

    @Input('dropdownOptions')
    set _dropdownOptions(dropdownOptions: DropdownTypeAheadModel) {
        if (dropdownOptions) {
            this.tooltip = '';
            this.dropDownTemp = dropdownOptions.options;
            if (this.dropdownOptions.title != null && this.dropdownOptions.title != 'Default Title') {
                this.tooltip = this.dropdownOptions.title;
            }
            if (dropdownOptions.selection === 'value' && dropdownOptions.dropdownValue != null) {
                this.model = dropdownOptions.dropdownValue;
                this.tooltip = dropdownOptions.dropdownValue.value;
            }
            if (typeof dropdownOptions.dropdownValue !== 'string') {
                this.model = dropdownOptions.dropdownValue;
            } else {
                if (dropdownOptions.title !== '' && dropdownOptions.title != null) {
                    setTimeout(() => {
                        this.model = dropdownOptions.options[0];
                    }, 200);
                } else {
                    this.model = '';
                }
            }
        }
    }
    get _dropdownOptions(): DropdownTypeAheadModel {
        return this.dropdownOptions;
    }

    /** Defines the tabbing sequence setting. */
    @Input() public tabIndex;

    /**Background text to display in dropdown typeAhead input field */
    @Input() public placeholderText: string;

    /**Viewchild used for the typeAhead input, used to get to nativeElement items */
    @ViewChild('formDropDownTypeAhead') public typeAheadField: ElementRef;

    /** Defines the value of the dropdown to be passed to the reactive form. */
    @Input('selectedValue') public value: any;

    /** Event emitter for when a value is selected. Can be used to render something else in the UI. */
    @Output() public selectedEvent: EventEmitter<any> = new EventEmitter<any>();
    @Output() public valueEvent = new EventEmitter<any>();
    @Output() public keyPressEvent: EventEmitter<any> = new EventEmitter<any>();

    /** Fired when any changes to the model are detected */
    public onChange: any = () => { };

    /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
    public onTouched: any = () => { };

    /** Getter for the value property */
    get selectedValue() {
        return this.value;
    }

    /** Setter for the value property */
    set selectedValue(val) {
        this.value = val;
        this.onChange(val);
        this.onTouched();
        if (val) { this.emitValue(val); }
    }
    /**
  * If the value has changed, emit a event to communicate to the outside world.
  *
  * @param val The value to emit.
  */
    public click(params, i) {
        // do something with "key" and "value" variables
        // let paramKeyValue = this.dropdownOptions.options.find(x => x.value === params.item);
        this.onChange(params.item);
        this.selectedEvent.emit(params.item);
        this.tooltip = params.item.value;
    }


    /**
* Emits the value of the input text box on model change.
*/
    public emitValue(val?: any) {
        this.typeAheadField.nativeElement.value = val.value;
        this.valueEvent.emit(val);
    }

    public keyPressEventHandler(keyCode) {
        this.keyPressEvent.emit(keyCode);
    }

    // filtering happens here
    formatter = (x: { value: string }) => x.value;

    search = (text$: Observable<string>) => {
        const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
        const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
        const inputFocus$ = this.focus$;
        return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
            map(term => (term === '' ? this.dropDownTemp
                : this.dropDownTemp.filter(v => v.value.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0))
        );
    }
    // customizing focus values based on input
    public focusValue(evt) {
        // setting value to null so that all dropdown values will be displayed
        let a = evt.target.value;
        a = '';
        this.focus$.next(a);
    }
    public aheadKeyup(event) { // dropdown scroll is not moving along with arrow key up/down event - fixed
        const isActive = document.getElementsByClassName('dropdown-item active');
        if (isActive.length > 0) {
            const id = document.getElementsByClassName('dropdown-item active')[0].getAttribute('id');
            const elmnt = document.getElementById(id);
            //  elmnt.scrollIntoView(false);
            const ht = elmnt.parentElement.clientHeight - elmnt.clientHeight;
            elmnt.parentElement.scrollTop = elmnt.offsetTop - ht;
            $('.dropdown-item').css('background', '#fff');
            $('.dropdown-item.active').css('background', '#0275d8');

        }
    }
    public focusValueOnArrowClick(event) {
        setTimeout(() => {
            const element = event.srcElement.previousElementSibling;
            if (element == null) {  // check if its null
                return;
            } else {
                element.focus();
            }

        }, 300);
    }
    writeValue(value: any) {
        if (value !== null) {
            this.value = value;
            this.selectedValue = value;
        } else {
            this.tooltip = '';
            this.typeAheadField.nativeElement.value = SpecialStrings.EMPTY;
        }
    }
    /**
  * Implementation of the registerOnChange function given through the ControlValueAccessor class.
  * Registers the onChange callback to this.onChange().
  *
  * @param fn The callback function.
  */
    registerOnChange(fn) {
        this.onChange = fn;
    }

    /**
     * Implementation of the registerOnTouched function given through the ControlValueAccessor class.
     * Registers the onTouched callback to this.onTouched().
     *
     * @param fn The callback function.
     */
    registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    /**
   * Implementation of the setDisabledState function given through the ControlValueAccessor class.
   * Detects when the disabled attribute changes, and sets it accordingly.
   *
   * @param isDisabled The boolean value to set.
   */
    setDisabledState(isDisabled: boolean): void {
        this.readonlyToggle = isDisabled;
    }
}
