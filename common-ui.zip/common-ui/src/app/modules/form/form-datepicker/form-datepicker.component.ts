import { Component, Input, Output, EventEmitter, forwardRef, ViewChild, HostListener, ElementRef, OnInit, AfterViewInit, Renderer2 } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, NG_VALIDATORS, Validator } from '@angular/forms';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
import { NgbDateStruct, NgbDateAdapter, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateNativeAdapter } from '../../../services/datepicker/ngb-date-native-adapter.service';
import { NgbCustomDateFormatter } from '../../../services/datepicker/ngb-custom-date-formatter.service';

/**
 * The FormDatepickerComponent
 *
 * Common component for displaying pop up datepicker inputs in the UI, which are meant for selecting any dates.
 * We are utilizing the third-party component, {@link https://ng-bootstrap.github.io/#/home ng-bootstrap} for the main functionality.
 *
 * In order to work with Reactive Forms, this component needs to implement the ControlValueAccessor class.
 */
@Component({
  selector: 'c2c-form-datepicker',
  templateUrl: './form-datepicker.component.html',
  styleUrls: ['./form-datepicker.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => FormDatepickerComponent), multi: true },
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => FormDatepickerComponent), multi: true },
    { provide: NgbDateAdapter, useClass: NgbDateNativeAdapter },
    { provide: NgbDateParserFormatter, useClass: NgbCustomDateFormatter }
  ]
})
export class FormDatepickerComponent implements ControlValueAccessor, Validator, OnInit, AfterViewInit {
  public enteredDay: number;
  public enteredMonth: number;
  public isOpen: boolean = false;
  public isValid: boolean = true;
  public readonlyToggle: boolean = false;
  public thisDay: number = new Date().getDate();
  public thisMonth: number = new Date().getMonth() + 1;

  /** Gets access to the 'datepicker' input used for displaying the calendar for date selection. */
  @ViewChild('datePicker') datePicker;

  /** Gets access to the 'valid' value used for checking if the date is valid or not. */
  @ViewChild('valid') validation;

  /** Gets access to the 'datepicker' input for setting focus to the input. */
  @ViewChild('dateInput') dateInput;

  /** Determines whether or not to set the initial focus to this field upon view initialization. */
  @Input() public setFocusToThis: boolean = false;

  /** Defines the placeholder text of the datepicker input box. Used for setting custom placeholder text. */
  @Input() public placeholder: string = Defaults.DEFAULT_INPUT_PLACEHOLDER;

  /** Defines the placement of the datepicker input box.*/
  @Input() public placement: string = 'bottom-left';

  /** Defines the tabbing sequence setting. */
  @Input() public tabIndex;

  /** Specifies validity based on outside conditions */
  @Input() public isInvalid: boolean = false;

  @Input('disabledByPermission') public disabledByPermission:boolean=false;

  /** Toggles specific 'readonly' class for displaying disabled element as text only (as opposed to being greyed-out) */
  @Input() public toggleReadonlyDisplay: boolean = false;

  /** Defines the value of the Datepicker to be passed to the reactive form. */
  @Input('value') public _value: any;

  /* Emite event on date selection */
  @Output() dateSelect = new EventEmitter<any>();

  /** Fired when any changes to the model are detected */
  public onChange: any = () => { };

  /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
  public onTouched: any = () => { };

  /** Getter for the value property */
  get value() {
    return this._value;
  }

  /** Setter for the value property */
  set value(val) {
    this.setValidationStatus();
    this._value = val;
    this.onChange(val);
    this.onTouched();
  }

   /**
   * Constructor for the Generic Datepicker
   *
   * @param elRef Gives direct access to the dom.
   * @param renderer Used for safely accessing elements in the DOM.
   */
  constructor(private elRef: ElementRef, private renderer: Renderer2) { }

  /**
   * NgInit built in lifecycle that gets called once the component has been initialized.
   * Sets the ngModel 'value' to the date passed in to 'value'.
   */
  public ngOnInit(): void {
    this.renderer.addClass(this.dateInput.nativeElement, this.toggleReadonlyDisplay ? 'c2c-readonly-input' : 'c2c-input');
  }

  /**
   * NgAfterViewInit lifecycle hook that gets called after the view has been initialized.
   * Sets the focus of to the specified datepicker if configured to do so.
   */
  public ngAfterViewInit(): void {
    if (this.setFocusToThis) {
      this.dateInput.nativeElement.focus();
    }
  }

  /**
   * HostListener is used to listen for all click events and passes the $event to the function.
   * This is used to check if the user has clicked off the input box / calendar pop up.
   *  The event name recorded by document:click.
   */
  @HostListener('document:click', ['$event.target'])
  public onClick(targetElement: HTMLElement) {
    if (!targetElement) {
      return;
    }
    if (!this.elRef.nativeElement.contains(targetElement)) {
      if (this.isOpen) {
        this.datePicker.close();
        this.onChange(this.value);
      }
      this.isOpen = false;
      this.setValidationStatus();
    } else {
      this.openDatePicker();
      this.isOpen = true;
    }
  }

  /**
   * Listens for 'enter' key press when the datePicker is open and sets the value/validation.
   */
  @HostListener('window:keyup.enter')
  public onEnter() {
    this.onChange(this.value);
    this.setValidationStatus();
  }

  /**
   * Listens to blur events (focus is lost), and runs validation logic.
   */
  @HostListener('blur')
  public onBlur(): void {
    this.setValidationStatus();
  }

  public selectEvent(evt) {
    this.dateSelect.emit(evt);
  }
  /**
   * Opens the DatePicker - called onClick and when 'Enter' is pressed.
   */
  public openDatePicker(): void {
    if (!this.readonlyToggle) {
      this.datePicker.open();
    }
  }

  /**
   * Checks the validation status of the DatePicker control, and sets 'isValid' global variable.
   */
  public setValidationStatus(): void {
    if (this.validation.status === 'INVALID' || this.isInvalid) {
      this.isValid = false;
    } else {
      this.isValid = true;
    }
  }

  /**
   * Used to disable any days not in the current month on the calendar.
   * @param date The current date
   * @param current The current month
   */
  public isDisabled(date: NgbDateStruct, current: {month: number}) {
    return date.month !== current.month;
  }

  /**
   * Implementation of the writeValue function given through the ControlValueAccessor class.
   * Writes the date value to the element.
   *
   * @param value The value to write.
   */
  public writeValue(value: any): void {
    this.value = value !== null ? new Date(value) : null;
  }

  /**
   * Implementation of the registerOnChange function given through the ControlValueAccessor class.
   * Registers the onChange callback to this.onChange().
   *
   * @param fn The callback function.
   */
  public registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Implementation of the registerOnTouched function given through the ControlValueAccessor class.
   * Registers the onTouched callback to this.onTouched().
   *
   * @param fn The callback function.
   */
  public registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  /**
   * Implementation of the setDisabledState function given through the ControlValueAccessor class.
   * Detects when the disabled attribute changes, and sets it accordingly.
   *
   * @param isDisabled The boolean value to set.
   */
  public setDisabledState(isDisabled: boolean): void {
    this.readonlyToggle = isDisabled;
  }

  /**
   * Implementation of the validate function given through the Validator class.
   * If the validation passes, it returns null. If it fails, it will return the defined object.
   */
  public validate(): {[key: string]: any} {
    return (!this.validation.invalid) ? null : { dateParseError: { valid: false } };
  }
}
