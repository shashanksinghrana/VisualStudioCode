import { Component, Input, forwardRef, EventEmitter, Output, DoCheck, OnInit, Renderer2, ViewChild, ElementRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { DropdownModel } from '../../../models/dropdown/dropdown.model';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';

/**
 * The FormDropdownComponent
 *
 * Common component for displaying form dropdowns in the UI.
 *
 * In order to work with Reactive Forms, this component needs to implement the ControlValueAccessor class.
 */
@Component({
  selector: 'c2c-form-dropdown',
  templateUrl: './form-dropdown.component.html',
  styleUrls: ['./form-dropdown.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormDropdownComponent),
    multi: true
  }]
})
export class FormDropdownComponent implements ControlValueAccessor, OnInit, DoCheck {
  public readonlyToggle: boolean = false;

  @ViewChild('dropdownButton') public dropdownButton;

  /** Defines the data for the dropdown. If nothing passed in, the default is used. */
  @Input() public dropdownOptions: DropdownModel = Defaults.DEFAULT_DROPDOWN_OPTIONS;

  @Input() public enableFirstBlank: boolean = false;

  @Input() public isInvalid: boolean = false;

  /* Defines remove item icon*/
  @Input() public removeItemIcon: boolean = false;

  /** Defines the tabbing sequence setting. */
  @Input() public tabIndex;

  /**Define to keep open option panel**/
  @Input() public keepOpen: boolean = this.removeItemIcon;

  /** Toggles specific 'readonly' class for displaying disabled element as text only (as opposed to being greyed-out) */
  @Input() public toggleReadonlyDisplay: boolean = false;

  /** Defines the value of the dropdown to be passed to the reactive form. */
  @Input('value') public _value: any;

  @Input('isFormDisabled') public isFormDisabled: boolean = false;
  /** Event emitter for when a value is selected. Can be used to render something else in the UI. */
  @Output() public selectedEvent: EventEmitter<any> = new EventEmitter<any>();

  /** Event emitter for when value from dropdown list is removed**/
  @Output() public removeElement: EventEmitter<any> = new EventEmitter<any>();

  /** handles autofocus event */
  @Input('autoFocus') public autoFocus: Boolean = false;

  /** Fired when any changes to the model are detected */
  public onChange: any = () => { };

  /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
  public onTouched: any = () => { };

  /** Getter for the value property */
  get value() {
    return this._value;
  }

  /** Setter for the value property */
  set value(val) {
    this._value = val;
    this.onChange(val);
    this.onTouched();
    if (val) { this.emitSelected(val); }
  }

  /**
   * The constructor for FormDropdownComponent
   */
  constructor(private renderer: Renderer2) { }

  public ngOnInit(): void {
    this.renderer.addClass(this.dropdownButton.nativeElement, this.toggleReadonlyDisplay ?
      'c2c-readonly-dropdown-item' : 'c2c-dropdown-item');
      if (this.isFormDisabled && this._value) {
        this._value.autoFocus = false;
      }
  }

  public ngDoCheck(): void {
    if (this.dropdownOptions.options.length) {
      const num = Number.parseInt(this.value);
      if (Number.isInteger(num)) {
        this.value = this.getDropdownOptionById(num);
      }
    }
  }

  public getDropdownOptionById(id) {
    if (this.dropdownOptions.options && this.dropdownOptions.options.length) {
      return this.dropdownOptions.options.find((option) => {
        if (Number.parseInt(option.id)) {
          return Number.parseInt(option.id) === id;
        }
      });
    }
  }

  private setOption(option): void {
    this.dropdownOptions.dropdownValue = option ? option : null;
    this.dropdownOptions.selection = option ? option.value : '';
    this.value = option;
    this.onChange(this.value);
    this.keepOpen = false;
  }

  public clickBlankOption(option): void {
    this.setOption(option);
    this.selectedEvent.emit(option);
  }

  /**
   * Sets the value of the selection option on the value that will be passed through the form.
   *
   * @param option The selected option.
   */
  public selectOption(option) {
    this.setOption(option);
    if (!this.removeItemIcon) { // Condition added to prevent double event triggering while selection
      this.selectedEvent.emit(this.value);
    }
  }

  /**
   * Implementation of the writeValue function given through the ControlValueAccessor class.
   * Writes the dropdown value to the element.
   *
   * @param value The value to write.
   */
  public writeValue(value: any): void {
    this.value = value;
  }

  /**
   * Implementation of the registerOnChange function given through the ControlValueAccessor class.
   * Registers the onChange callback to this.onChange().
   *
   * @param fn The callback function.
   */
  public registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Implementation of the registerOnTouched function given through the ControlValueAccessor class.
   * Registers the onTouched callback to this.onTouched().
   *
   * @param fn The callback function.
   */
  public registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  /**
   * Implementation of the setDisabledState function given through the ControlValueAccessor class.
   * Detects when the disabled attribute changes, and sets it accordingly.
   *
   * @param isDisabled The boolean value to set.
   */
  public setDisabledState(isDisabled: boolean): void {
    this.readonlyToggle = isDisabled;
  }

  /**
   * If the value has changed, emit a event to communicate to the outside world.
   *
   * @param val The value to emit.
   */
  public emitSelected(val: any) {
      this.selectedEvent.emit(val);
    }

  /* Method to remove Item from dropdown list*/
  public emitRemoveEvt($event, opt, index) {
    $event.stopPropagation();
    this.dropdownOptions.options.splice(index, 1);
    this.value = this.dropdownOptions.options;
    this.removeElement.emit(opt);
    this.keepOpen = false;
  }
}
