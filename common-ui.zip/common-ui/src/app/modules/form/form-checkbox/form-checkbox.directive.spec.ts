import { FormCheckboxDirective } from './form-checkbox.directive';

describe('FormCheckboxDirective', () => {
  it('should create an instance', () => {
    const directive = new FormCheckboxDirective();
    expect(directive).toBeTruthy();
  });
});
