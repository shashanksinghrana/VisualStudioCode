import { Component, Input, ViewEncapsulation, Output, EventEmitter, forwardRef, AfterViewInit, Renderer2, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, FormGroup } from '@angular/forms';
import { EditorConfig } from '../../../services/config/editor.config';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { SaveButtonModel } from '../../../models/button/save-button/save-button.model';
import { CancelButtonModel } from '../../../models/button/cancel-button/cancel-button.model';
import { Subscription } from 'rxjs';
import { NoteEventService } from '../../../services/events/form/note-event.service';
import { ModalEditorConfig } from '../../../services/config/modal-editor.config';

/**
 * The Note Component
 *
 * Common component for displaying RTE and plain text note fields in the UI.
 * We are utilizing the third-party component, {@link https://www.tinymce.com/ tinymce} for the RTE functionality.
 *
 * In order to work with Reactive Forms, this component needs to implement the ControlValueAccessor class.
 */
@Component({
  selector: 'c2c-note',
  templateUrl: './note.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./note.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => NoteComponent),
    multi: true
  }]
})
export class NoteComponent implements ControlValueAccessor, AfterViewInit, OnDestroy {

  /** Defines the event passed to emit function. Event is which button in modal was clicked. */
  public event: string;

  /** Options used for the modal window that contains the notes field. */
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-xl'
  };

  private prevValue: string;

  /** Determines whether to open a modal containing the RTE or a plain textarea. */
  @Input() useRTE: boolean = true;

  /** Sets the max length of the note editor. */
  @Input() maxLength: number;

  @Input("disableAddButton") disableAddButton:boolean=false;

  /** Sets the starting number of rows (height) that the text field should be. */
  @Input() rows: string = '6';

  /** Defines the options of the Save Button. Used for configuring the Save Button. */
  @Input() public saveButtonOptions: SaveButtonModel;

  /** Defines the options of the Cancel Button. Used for configuring the Cancel Button. */
  @Input() public cancelButtonOptions: CancelButtonModel;

  /** Defines the default value of the text editor. Used for configuring the default value to be displayed. */
  @Input('value') public _value: string;

  /** Defines the tabbing sequence setting. */
  @Input() public tabIndex;

  public inlineTabIndex;
  public allowedKeys = [8, 37, 38, 39, 40, 46];
  public valueForDisplay;

  

  /** Defines the tooltip text to display when the note icon is hovered. */
  @Input() public tooltip: string;

  // Disables the note input
  @Input("disableInput") public disableInput: boolean=false;

  @ViewChild('popContent') public popContent: ElementRef;

  /** Outputs an event when the save button is clicked. Used to provide the value to the UI. */
  @Output() valueEvent = new EventEmitter<any>();

  /** Fired when any changes to the model are detected */
  public onChange: any = () => { };

  /** Fired when the component is blurred */
  public onTouched: any = () => { };

  /** determines whether to show note editor as a modal or inline. */
   @Input() showModal: boolean = true;

   public keyTabSubscription: Subscription;
  //  public keyTabForModalSubscription: Subscription;
   @ViewChild('editorDiv') public editorDiv: ElementRef;
   public tabClicked: boolean = false;

  /** Getter for the value property */
  get value() {
    return this._value;
  }

  /** Setter for the value property */
  set value(val) {
    this._value = val;
    this.onChange(val);
    this.onTouched();
  }

  /**
   * Constructor for the Note
   *
   * Defines the editorConfig used by the RTE Note.
   *
   * @param editorConfig The configuration used to build the RTE editor in inline view (style/functionality).
   * @param modalEditorConfig The configuration used to build the RTE editor in modal view (style/functionality).
   * @param modalService The service to handle all events related to the Modal.
   * @param renderer Used for safely accessing elements in the DOM.
   */
  constructor(public editorConfig: EditorConfig, public modalEditorConfig: ModalEditorConfig, private modalService: NgbModal, private renderer: Renderer2, public noteEventService: NoteEventService) { }

  /**
   * Called on each keyup typed, and used to determine the max length of the RTE (since the component doesn't support a max-length property
   */
  public onKeyUp(ev): void {
    if (this.useRTE && this.maxLength) {
      let editorConfig;
      if(this.showModal){
        editorConfig = this.modalEditorConfig;
      }else{
        editorConfig = this.editorConfig;
      }
      const content = editorConfig.editor.getBody();
      if (content && content.innerText.length+1 > this.maxLength) {
        if( this.allowedKeys.indexOf(ev.event.keyCode) === -1 )
        {
          ev.event.preventDefault();
          ev.event.stopPropagation();
          editorConfig.editor.setContent(editorConfig.editor.getBody().innerText.substring(0, this.maxLength));
        }
        editorConfig.editor.selection.select(editorConfig.editor.getBody(), true);
        editorConfig.editor.selection.collapse(false);
      }
    }
  }



  /**
   * NgAfterViewInit lifecycle hook that gets called after the view has been initialized.
   * Sets the inner HTML of the popover for displaying RTE values in it.
   */
  public ngAfterViewInit(): void {
    if (this.popContent.nativeElement) {
      this.renderer.setProperty(this.popContent.nativeElement, 'innerHTML', this.value);
    }

    if(this.tabIndex){
      if(this.showModal){
        this.inlineTabIndex = -1;//setting as -1 as in modal view, 2tab were required as both have same tabindex
      }else{
        this.inlineTabIndex = this.tabIndex;
      }
    }

    this.keyTabSubscription = this.noteEventService.getKeyTab()
    .subscribe(e => {
      this.tabClicked = true;
      this.editorDiv.nativeElement.focus();
    });

    // this.keyTabForModalSubscription = this.noteEventService.getKeyTabForModal()
    // .subscribe(e => {
    //   this.tabToSave(e);
    // });
  }

  /**
   * This is called when the Note icon is clicked.
   * Performs the action of opening up the modal window by triggering the event open().
   *
   * @param content The content
   */
  openModal(content) {
    this.modalService.open(content, this.modalOptions);
    if(this.showModal && !this.useRTE){
      setTimeout(() => {
          let textarea = document.getElementById('notes-text-field');
          textarea.focus();
      });
  }
    this.prevValue = this.value;
  }

  /**
   * Implementation of the writeValue function given through the ControlValueAccessor class.
   * Writes the note value to the element.
   *
   * @param value The value to write.
   */
  writeValue(value: any): void {
    this.setTooltipValue(value);
    this.value = value;
  }

  /**
   * Implementation of the registerOnChange function given through the ControlValueAccessor class.
   * Registers the onChange callback to this.onChange().
   *
   * @param fn The callback function.
   */
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Implementation of the registerOnTouched function given through the ControlValueAccessor class.
   * Registers the onTouched callback to this.onTouched().
   *
   * @param fn The callback function.
   */
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  /**
   * Emits the value of the text editor when the save button is clicked.
   *
   * @param event The event being emitted (Either 'SAVE' or 'CANCEL').
   */
  emitValue(event) {
    this.event = event;
    this.value = this.calcValue(this.value);
    this.setTooltipValue(this.value);
    this.valueEvent.emit({ value: this.value, action: event });
  }

  /**
   * Calculates the value of the note. If the user cancels, returns the previous value.
   * Also returns null if a bunch of whitespace or newlines are entered.
   *
   * @param value The current value of the note.
   */
  private calcValue(value): string {
    if (this.event === 'CANCEL') {
      if (this.useRTE && this.prevValue) {
        this.modalEditorConfig.editor.setContent(this.prevValue);
      }
      return this.prevValue;
    } else {
      if (this.useRTE) {
        return !this.modalEditorConfig.editor.getBody().innerText.trim() ? null : value;
      } else {
        return value.trim();
      }
    }
  }

  public focusEditor(){
    if(!this.disableInput && !this.showModal)
    {
      if(!this.tabClicked){
        this.editorConfig.editor.focus();
      }else{
        this.tabClicked = false;
      }
    }
 
  }

  public setTooltipValue(value){
    let dots = "...";
    const doc = (new DOMParser()).parseFromString(value, 'text/html');
    const valueInnerText = doc.body.innerText.trim();
    if(valueInnerText && valueInnerText.length > 36){   
      this.valueForDisplay = valueInnerText.substring(0,36) + dots;
    }else{
      this.valueForDisplay = value;
    }
  }

  public tabToSave(event){
    setTimeout(() => {
      let element = <HTMLElement>document.getElementById('c2c-modal-save-button').children[0];
      element.focus();
    });
  }

  public ngOnDestroy(): void {
    this.keyTabSubscription && this.keyTabSubscription.unsubscribe();
    // this.keyTabForModalSubscription && this.keyTabForModalSubscription.unsubscribe();
  }
}
