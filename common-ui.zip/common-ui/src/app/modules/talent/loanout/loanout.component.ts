import { state } from '@angular/animations';
import { AddTalentModel } from './../../../models/talent/add-talent/add-talent.model';
import { ConfidentialInfoModel } from './../../../models/talent/add-talent/confidential-info.model';
import { LoanoutModel } from './../../../models/talent/loanout/loanout.model';
import { DropdownTypeAheadModel } from './../../../models/dropdown-typeahead/dropdown-typeahead.model';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { DropdownFormModel } from './../../../models/talent/dropdown-form-model';
import { LoanoutFormModel } from './../../../models/talent/loanout/loanout-form.model';
import { AddButtonModel } from './../../../models/button/add-button/add-button.model';
import { DropdownModel } from './../../../models/dropdown/dropdown.model';
import { CancelButtonModel } from './../../../models/button/cancel-button/cancel-button.model';
import { TalentPersistService } from './../../../services/persist/talent-persist.service';
import { ToasterService } from './../../../services/toaster/toaster.service';
import { ITalentEvents } from './../../../interfaces/italent-events';
import { Observable, Observer } from 'rxjs';

@Component({
  selector: 'c2c-talent-loanout',
  templateUrl: './loanout.component.html',
  styleUrls: ['./loanout.component.scss']
})
export class LoanoutComponent implements OnInit {

  public loanoutForm: FormGroup;
  public addLoanoutButtonOps: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Loanout');
  public loanoutDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public stateDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public countryDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);

  public stateDropdownEdit: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public countryDropdownEdit: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);

  public loanoutList: Array<any> = [];
  public disableAddIcon: boolean = false;
  public editRow: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Edit');
  public cancelRow: CancelButtonModel = new CancelButtonModel('Talent', 'Create Talent', '');
  public primaryChecked: boolean = false;
  private tempItemEdited: Array<any>;
  public loanoutListForm: FormGroup;
  public submitted: boolean = false;
  public loanoutExist: boolean = false;
  public einExist: boolean = false;
  public loanoutlistExist: boolean = false;
  public einListExist: boolean = false;
  public einFree: boolean = true;
  public einFreeEdit: boolean = false;
  private stateOptionsOrdered: Array<any> = [];
  public isEditingMode: boolean = false;
  private einTempValue: string = '';
  private einListTempValue: string = '';
  private _loanooutEditList: Array<object> = [];
  public _disabledFieldInputs: boolean = false;
  public componentUpdate: boolean = false;
  private posduplicateItem: number = null;
  public einListErrorMessage: string = '';
  private _objStateCountry: object;
  private isLoanoutUpdated: boolean = false;
  public _hideInputFieldsPii: boolean = false;
  public selectedCountry: any;
  public selectedState: any;

  @Input() talentService: ITalentEvents;

  @Input()
  set disableFieldInput(val: boolean) {
    this._disabledFieldInputs = val;
    if (this._disabledFieldInputs && !this._loanooutEditList) {
      this.disableLoanoutField();
    } else if (!val) {
      this.enableLoanoutField();
    } else {
      this.disableLoanoutField();
    }
  }
  get disableFieldInput(): boolean {
    return this._disabledFieldInputs;
  }

  @Input()
  set hideFieldInput(val: boolean) {
    this._hideInputFieldsPii = val;

  }
  get hideFieldInput(): boolean {
    return this._hideInputFieldsPii;
  }

  @Input()
  set loanoutEditList(list: any) {
    this._loanooutEditList = list;
    if (list && list.length > 0) {
      this.setLoanoutEditList(this._loanooutEditList);
    } else {
      this.loanoutList = [];
    }

  }
  get loanoutEditList(): any {
    return this._loanooutEditList;
  }

  @Input()
  set stateCountry(object: any) {
  }
  get stateCountry(): any {
    return this._objStateCountry;
  }

  @Output() disabledSaveBtn: EventEmitter<any> = new EventEmitter<any>();
  @Output() onFocusRepresentationTab: EventEmitter<any> = new EventEmitter<any>();

  constructor(private talentPersistService: TalentPersistService, private toasterService: ToasterService) {
  }

  ngOnInit() {
    this.loanoutForm = new FormGroup({
      loanoutCompany: new FormControl(null, [Validators.required, this.noWhitespaceValidator]),
      ein: new FormControl(null, {
        validators: [Validators.pattern(/^\d{2}-\d{7}$/), this.checkEinValue],
        updateOn: 'change'
      }),
      freeEIN: new FormControl(null),
      state: new FormControl(null),
      country: new FormControl(null),
      primary: new FormControl(null)
    });

    this.loanoutListForm = new FormGroup({
      loanoutCompanyEdit: new FormControl(null, [Validators.required, this.noWhitespaceValidator]),
      ein: new FormControl(null, {
        validators: [Validators.pattern(/^\d{2}-\d{7}$/), this.checkEinValue],
        updateOn: 'change'
      }),
      freeEIN: new FormControl(null),
      state: new FormControl(null),
      country: new FormControl(null)
    });

    // TODO: remove this as resolver as been implemented
    this.talentService.getStates().subscribe((res) => {
      this.stateOptionsOrdered = res['picklists']['STATES'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      });
      this.stateOptionsOrdered.unshift({ id: null, value: '' });
      this.stateDropdown = new DropdownTypeAheadModel('', '', '', '', this.stateOptionsOrdered);
      this.stateDropdownEdit = new DropdownTypeAheadModel('', '', '', '', this.stateOptionsOrdered);
    }, (err) => {
    });

    // TODO: remove this as resolver as been implemented
    this.talentService.getCountries().subscribe((res) => {
      const countryOptions = res['picklists']['COUNTRIES'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      });
      countryOptions.unshift({ id: null, value: '' });
      this.countryDropdown = new DropdownTypeAheadModel('', '', '', '', countryOptions);
      this.countryDropdownEdit = new DropdownTypeAheadModel('', '', '', '', countryOptions);
    }, (err) => {
    });

    this.disableLoanoutField();
    this.onChange();
  }

  private onChange(): void {
    const loanoutCtrl: AbstractControl = this.loanoutForm.get('loanoutCompany');
    const einCtrl: AbstractControl = this.loanoutForm.get('ein');
    const freeEinCtrl: AbstractControl = this.loanoutForm.get('freeEIN');
    const loanoutListCtrl: AbstractControl = this.loanoutListForm.get('loanoutCompanyEdit');
    const einListCtrl: AbstractControl = this.loanoutListForm.get('ein');
    const freeEinListCtrl: AbstractControl = this.loanoutListForm.get('freeEIN');

    // Check Loanout form changes validations
    loanoutCtrl.valueChanges.subscribe(type => {
      if (this.loanoutExist) {
        this.loanoutExist = false;
      }
    });

    // EIN input watching typing
    einCtrl.valueChanges.debounceTime(10).subscribe(type => {
      this.loanoutForm.get('ein').setValue(this.setEinFormat(type));
      if (this.einExist) {
        this.einExist = false;
      }
      if (this.loanoutExist) {
        this.loanoutExist = false;
      }
      if (!this.loanoutForm.get('ein').hasError('pattern') && !this.loanoutForm.get('ein').hasError('einError') && !this.isEditingMode) {
        this.disableAddIcon = false;
      } else {
        this.disableAddIcon = true;
      }
      this.einTempValue = type;
    });

    freeEinCtrl.valueChanges.subscribe(einValue => {
      this.einTempValue = einValue;
      if (freeEinCtrl.dirty) {
        this.einExist = false;
      }
    });

    // EIN in list inpunt watching typing
    einListCtrl.valueChanges.debounceTime(10).subscribe(einValue => {
      this.loanoutListForm.get('ein').setValue(this.setEinFormat(einValue));
      if (this.einListExist) {
        this.einListExist = false;
      }
      if (this.loanoutlistExist) {
        this.loanoutlistExist = false;
      }
      this.einListTempValue = einValue;
      if (this.loanoutListForm.get('ein').hasError('pattern') && this.loanoutListForm.get('ein').hasError('einError') && !this.einFreeEdit) {
        this.einListErrorMessage = 'Please enter valid EIN number';
        this.loanoutList[this.posduplicateItem].editableFieldFlags.einError = false;
        this.disabledSaveBtn.emit({ field: 'ein', disableBtn: true });
      } else if (this.posduplicateItem !== null && einListCtrl.dirty) {
        this.loanoutList[this.posduplicateItem].editableFieldFlags.einError = false;
        this.disabledSaveBtn.emit({ field: 'ein', disableBtn: false });
        this.einListErrorMessage = '';
      }
      this.disabledSaveBtn.emit({ field: 'ein', disableBtn: false });
    });

    // EIN free input watching typing
    freeEinListCtrl.valueChanges.subscribe(einValue => {
      this.einListTempValue = einValue;
      if (this.posduplicateItem !== null && freeEinListCtrl.dirty) {
        this.loanoutList[this.posduplicateItem].editableFieldFlags.einError = false;
        this.disabledSaveBtn.emit({ field: 'ein', disableBtn: false });
      }
    });

    // Check validation Form List changes
    loanoutListCtrl.valueChanges.subscribe(value => {
      if (this.loanoutlistExist) {
        this.loanoutlistExist = false;
      }
    });
  }

  public onFocusAddButton() {
    this.onFocusRepresentationTab.emit();
  }

  /**
   * This is a adding function that takes loanout values
   * by adding them to list belwo form.
   *
   * @param project The project created or edited.
  */
  public addLoanout(): void {
    const itemAdded = this.loanoutForm.value;
    itemAdded.ein = !itemAdded.ein ? itemAdded.freeEIN : itemAdded.ein;
    itemAdded.freeEIN = !itemAdded.freeEIN ? itemAdded.ein : itemAdded.freeEIN;
    if (this.loanoutForm.valid) {
      if (itemAdded.ein && this.checkLoanoutCompanyEin(itemAdded, ['ein']) === -1) {
        this.einExist = false;
      } else if (itemAdded.ein && this.checkLoanoutCompanyEin(itemAdded, ['ein']) > -1) {
        this.einExist = true;
      }
      if (!this.einExist && this.checkLoanoutCompanyEin(itemAdded, ['loanoutCompany', 'ein']) === -1) {
        this.addLoanoutToList(itemAdded);
      } else if (!this.einExist) {
        this.loanoutExist = true;
      }
    }
  }

  private addLoanoutToList(itemAdded: any): void {
    const loanoutModel: LoanoutFormModel = new LoanoutFormModel();
    loanoutModel.editableFieldFlags = {
      addIcon: false,
      cancelIcon: false,
      disableIcons: false,
      deleteIcon: true,
      displayFields: false,
      editIcon: true,
      radioDisabled: true,
      einError: false
    };
    loanoutModel.loanoutCompany = this.loanoutForm.get('loanoutCompany').value;
    loanoutModel.state = this.checkDropdownsValue(itemAdded.state) ? itemAdded.state : {};
    loanoutModel.country = this.checkDropdownsValue(itemAdded.country) ? itemAdded.country : {};
    loanoutModel.ein = !this.einFree ? this.loanoutForm.get('ein').value : this.loanoutForm.get('freeEIN').value;
    loanoutModel.freeEIN = !this.einFree ? this.loanoutForm.get('ein').value : this.loanoutForm.get('freeEIN').value;
    loanoutModel.primary = this.primaryChecked;
    loanoutModel.timeStamp = new Date();

    if (this.primaryChecked) {
      this.clearPrimaryValues();
    }

    this.primaryChecked = false;
    // const stateOptions = loanoutModel.state;
    // this.stateDropdown = new DropdownTypeAheadModel('', '', '', '', options);
    this.formReset();

    this.loanoutList.push(loanoutModel);

    this.talentPersistService.setLoanoutList(this.loanoutList);

    this.einTempValue = '';
    this.componentUpdate = true;
  }

  formReset() {
    // this.loanoutForm.get('state').setValue({ id: null, value: '' });
    // this.loanoutForm.get('country').setValue({ id: null, value: '' });
    this.loanoutForm.reset();
    this.countryDropdown = new DropdownTypeAheadModel('', '', '', '', this.countryDropdown.options);
    this.stateDropdown = new DropdownTypeAheadModel('', '', '', '', this.stateDropdown.options)
  }

  /**
   * This function checks primary radio button value.
   *
   * @param value true or false.
  */
  public updatePrimaryIndicator(value): void {
    this.primaryChecked = !value;
  }

  /**
   * This function checks primary radio button value.
   *
   * @param index position of what radio btn was changed in list.
  */
  public updatePrimaryList(index: number): void {

    this.loanoutList.forEach((item, i) => {
      if (i === index) {
        item.primary = true;
      } else {
        item.primary = false;
      }
    });
  }

  /**
   * This function edits row clicking edit icon.
   *
   * @param i position of what row will be changed in list.
  */
  public onEdit(i: number): void {
    this.posduplicateItem = i;

    const variable = this.loanoutList[i] && this.loanoutList[i].state && this.loanoutList[i].state.value ? this.loanoutList[i].state.value : null;
    if (variable === null || variable === undefined) {
      this.einFreeEdit = true;
    } else {
      this.einFreeEdit = false;
    }
    this.isEditingMode = true;
    this.loanoutForm.disable();

    this.disableAddIcon = true;
    this.tempItemEdited = JSON.parse(JSON.stringify(this.loanoutList));
    this.stateDropdownEdit = new DropdownTypeAheadModel('', '', '', '', this.stateOptionsOrdered);
    this.loanoutList.forEach((item, index) => {
      if (i === index) {
        item.editableFieldFlags.cancelIcon = true;
        item.editableFieldFlags.addIcon = true;
        item.editableFieldFlags.deleteIcon = false;
        item.editableFieldFlags.editIcon = false;
        item.editableFieldFlags.displayFields = true;
        item.editableFieldFlags.radioDisabled = false;
        setTimeout(() => {
          this.loanoutListForm.patchValue({
            loanoutCompanyEdit: item.loanoutCompany,
            ein: item.ein,
            freeEIN: item.freeEIN,
            state: item.state && item.state.value ? item.state : null,
            country: item.country && item.country.value ? item.country : null
          });
          // this.selectedEditState = this.loanoutListForm.get('state').value;
          // this.selectedEditCountry = this.loanoutListForm.get('country').value;
        }, 100);
      } else {
        item.editableFieldFlags.disableIcons = true;
      }
    });
    this.loanoutListForm.enable();
  }

  /**
   * This function removes row clicking  delete icon in list.
   * Also checking if row deleted is primary to look for more recnet row edited
   * @param i position of what row will be changed in list.
  */
  public onDelete(i: number): void {
    const isPrimary = this.loanoutList[i].primary ? true : false;
    this.loanoutList.splice(i, 1);
    if (this.loanoutList.length > 0 && isPrimary) {
      const lastItem = this.loanoutList.map((item) => item).sort((a, b) => a.timeStamp - b.timeStamp).reverse()[0];
      this.clearPrimaryValues();
      lastItem.primary = true;
    }
    this.componentUpdate = true;
    this.talentPersistService.setLoanoutList(this.loanoutList);
    this.loanoutListForm.markAsDirty();
    this.loanoutListForm.markAsTouched();
  }

  /**
   * This function saves row edited in line by clicking add icon in list.
   *
   * @param i position of what row will be changed in list.
  */
  public onSaveRow(i: number): void {
    this.posduplicateItem = i;
    const formEditValues = this.loanoutListForm.value;
    const einEditValue = formEditValues.ein || formEditValues.freeEIN;

    this.einListExist = false;
    this.loanoutList[i].editableFieldFlags.einError = false;
    this.loanoutList.forEach((itemList, index) => {
      const elementEIN = itemList.ein || itemList.freeEIN;
      if (index !== i && (!this.einListExist || !this.loanoutlistExist)) {
        // Check if loanout EIN is duplicated
        if ((elementEIN && einEditValue) && (elementEIN === einEditValue)) {
          this.einListExist = true;
          this.loanoutList[i].editableFieldFlags.einError = true;
        }
        // Check both loanout name and EIN is duplicated
        if (!this.einListExist) {
          if (elementEIN || einEditValue) {
            if (itemList.loanoutCompany === formEditValues.loanoutCompanyEdit && elementEIN === einEditValue) {
              this.loanoutlistExist = true;
            }
          } else {
            if (itemList.loanoutCompany === formEditValues.loanoutCompanyEdit) {
              this.loanoutlistExist = true;
            }
          }
        }
      }
    });

    if (!this.einListExist && !this.loanoutlistExist) {
      this.disableAddIcon = false;
      this.loanoutList.forEach((item, index) => {
        if (i === index) {
          item.loanoutCompany = this.loanoutListForm.get('loanoutCompanyEdit').value;
          item.ein = !this.einFreeEdit ? this.loanoutListForm.get('ein').value : this.loanoutListForm.get('freeEIN').value;
          item.freeEIN = !this.einFreeEdit ? this.loanoutListForm.get('ein').value : this.loanoutListForm.get('freeEIN').value;
          item.state = this.loanoutListForm.get('state').value;
          item.country = this.loanoutListForm.get('country').value;
          item.editableFieldFlags.cancelIcon = false;
          item.editableFieldFlags.addIcon = false;
          item.editableFieldFlags.deleteIcon = true;
          item.editableFieldFlags.editIcon = true;
          item.editableFieldFlags.displayFields = false;
          item.editableFieldFlags.radioDisabled = true;
          item.editableFieldFlags.einError = false;
          item.timeStamp = new Date();
          item.loanoutEditAdded = true;
        } else {
          item.editableFieldFlags.disableIcons = false;
        }
      });
      this.isEditingMode = false;
      this.loanoutListForm.reset();
      this.loanoutListForm.disable();
      this.loanoutForm.enable();
      this.componentUpdate = true;
      this.talentPersistService.setLoanoutList(this.loanoutList);
      this.disabledSaveBtn.emit({ field: 'ein', disableBtn: false });
      this.isLoanoutUpdated = true;

    } else {
      this.disabledSaveBtn.emit({ field: 'ein', disableBtn: true });
    }
  }

  /**
   * This function cancells inline editing by clicking cancel (x) icon in list.
   *
   * @param i position of what row will be changed in list.
  */
  public onCancel(i: number): void {
    this.disableAddIcon = false;
    this.loanoutList = this.tempItemEdited;
    this.loanoutList.forEach(item => {
      item.timeStamp = new Date(item.timeStamp);
    });
    this.isEditingMode = false;
    this.loanoutListForm.disable();
    this.loanoutForm.enable();
    this.disabledSaveBtn.emit({ field: 'ein', disableBtn: false });
    if (!this.isLoanoutUpdated) {
      this.loanoutListForm.markAsPristine();
      this.loanoutListForm.markAsUntouched();
    }
  }

  /**
   * This function compare and sets If US state is selcted
   * to validate EIN format form.
   *
   * @param state object with state data info.
   * @param formName which FormGroup will be watched
   * @param inputType Values (add or edit) possible values to set what dropdowns will be watched
  */
  public onSelectState(stateSelected: any, formName: string, inputType: string): void {
    if (null !== stateSelected && stateSelected.id && stateSelected.value || (this[formName].get('country').value &&
      this[formName].get('country').value.value === 'United States')) {
      const country = this.countryDropdown.options.find(countryItem => countryItem.value === 'United States');

      this[formName].get('country').patchValue(country);
      this[formName].get('state').patchValue(stateSelected);
      this.setFormatEIN(formName, inputType);

      if (inputType !== 'edit') {
        this.selectedCountry = country;
      }

    } else if (null === stateSelected.id && !stateSelected.value) {
      this.setEINFree(formName, inputType, stateSelected);
    }
  }

  /**
  * This function to set EIN free input
  * to validate EIN format form.
  *
  * @param form fornName which FormGrupo will be watched.
  * @param inputType Values (add or edit) possible values to set what dropdowns will be watched
  * @param state object with state data info optional.
 */
  private setEINFree(form: string, inputType: string, state?: any): void {
    setTimeout(() => {

      if (inputType === 'add') {
        this[form].get('ein').setValue(this.einTempValue);
        this[form].get('ein').disable();
        this[form].get('freeEIN').setValue(this.einTempValue);
      } else {
        this[form].get('ein').setValue(this.einListTempValue);
        this[form].get('ein').disable();
        this[form].get('freeEIN').setValue(this.einListTempValue);
      }
      this[form].get('freeEIN').enable();


      if (inputType === 'add') {
        this.einFree = true;
        this.disableAddIcon = false;
      } else if (inputType === 'edit') {
        this.einFreeEdit = true;
      }
    });

  }

  /**
   * This function to set EIN format input
   * to validate EIN format form.
   *
   * @param form fornName which FormGrupo will be watched.
   * @param inputType Values (add or edit) possible values to set what dropdowns will be watched
  */
  private setFormatEIN(form: string, inputType: string): void {
    setTimeout(() => {
      let einValue;

      if (inputType === 'add') {
        einValue = this.setEinFormat(this.einTempValue);
      } else {
        einValue = this.setEinFormat(this.einListTempValue);
      }
      this[form].get('freeEIN').setValue(einValue);
      this[form].get('freeEIN').disable();

      this[form].get('ein').setValue(einValue);
      this[form].get('ein').enable();

      if (inputType === 'add') {
        this.einFree = false;
      } else if (inputType === 'edit') {
        this.einFreeEdit = false;
      }
    });

  }

  /**
   * This function removes row clicking edit delete icon in list.
   *
   * @param irecord object that will be compare if already exist in list.
   * @param prop array string that contains loanout company name and EIN on what properties will be comprare
  */
  private checkLoanoutCompanyEin(record: any, prop: Array<string>): number {
    let index = -1;
    if (prop.length === 1) {
      this.loanoutList.forEach((element, key) => {
        index = (index === -1 && element[prop[0]] === record[prop[0]]) ? key : index;
      });
    } else {
      this.loanoutList.forEach((element, key) => {
        if (element.ein || record.ein) {
          index = (index === -1 && element[prop[0]] === record[prop[0]] && element[prop[1]] === record[prop[1]]) ? key : index;
        } else {
          index = (index === -1 && element[prop[0]] === record[prop[0]]) ? key : index;
        }
      });
    }

    return index;
  }

  /**
   * This function checks State and Country dropdowns values are null or not.
   * to set appropiated EIN field free or with formar
   * @param values position of what row will be changed in list.
  */
  private checkDropdownsValue(values: any): boolean {
    const validValues = values !== null ? true : false;
    return validValues;
  }

  /**
   * This function chekcs Country dropdowns values are null or not.
   *
   * @param country country dropdown value (onject).
   * @param form form name to check what Form update add form or edit form.
   * @param inputType Add or Edit values this to watch what form will be updated.
  */
  public onSelectCountry(country: any, form: string, inputType: string): void {
    if (inputType !== 'edit') {
      this.selectedCountry = country;
    }
    this[form].get('country').setValue(country);
    if (null !== country.id && country.value === 'United States') {
      this.setStateValue(inputType);
      this.setFormatEIN(form, inputType);

    } else if (null !== country.id && country.value !== 'United States') {
      const emptyState = [{ id: null, value: null }];
      if (inputType === 'add') {
        this.stateDropdown = new DropdownTypeAheadModel('', '', '', '', emptyState);
        this.selectedState = null;
      } else {
        this.stateDropdownEdit = new DropdownTypeAheadModel('', '', '', '', emptyState);

      }
      this[form].get('state').reset();
      this.setEINFree(form, inputType);

    } else if (null === country.id && !country.value) {
      this.setStateValue(inputType);
      this.setEINFree(form, inputType);
      this[form].get('state').setValue({ id: null, value: '' });
    }
  }

  /**
   * This function sets strate dropdown with US states,
   * when state dropdown is empty (adding and editing mode).
   * @param inputType Add or Edit values this to watch what form will be updated.
  */
  private setStateValue(inputType: string): void {
    if (inputType === 'add') {
      this.stateDropdown = new DropdownTypeAheadModel('', '', '', '', this.stateOptionsOrdered);
    } else {
      this.stateDropdownEdit = new DropdownTypeAheadModel('', '', '', '', this.stateOptionsOrdered);
    }
  }

  /**
   * This function checks if varaibel contains whitespace.
   * @param control form control will be checked.
  */
  public noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whiteSpace': true };
  }

  /**
   * This function validator for EIN format
   * @param control form control will be checked.
  */
  public checkEinValue(control: FormControl): { [key: string]: boolean } | null {
    const einReges = /^\d{2}-\d{7}$/;

    if (control.value && !einReges.test(control.value)) {
      return { 'einError': true };
    } else {
      return null;
    }
  }

  /**
   * This functionto set EIN format when changing state or country dropdown
   * @param value EIN format value
  */
  private setEinFormat(value: string): string {

    if (value) {
      let val = value.replace(/\D/g, '');
      let newVal = '';
      const sizes = [2, 7];

      for (const i in sizes) {
        if (val.length > sizes[i]) {
          if (i === '0') {
            newVal += val.substr(0, sizes[i]) + '-';
          } else {
            newVal += val.substr(0, sizes[i]);
          }
          val = val.substr(sizes[i]);
        } else {
          break;
        }
      }
      if (newVal.length < 10) {
        newVal += val;
      }
      if (!this.isEditingMode) {
        this.einTempValue = newVal;
      } else {
        this.einListTempValue = newVal;
      }
      return newVal;
    } else {
      return '';
    }
  }
  /**
   * Functions that clear all primary radio buttons
   */
  private clearPrimaryValues(): void {
    this.loanoutList.forEach((item) => {
      item.primary = false;
    });
  }

  private setLoanoutEditList(itemsList: any): void {
    this.loanoutList = [];
    itemsList = itemsList.sort((a, b) => a.relationId - b.relationId);
    itemsList.forEach(element => {
      let ddModel: DropdownFormModel = new DropdownFormModel();
      let countryObj;
      let stateObj;
      const loaunoutListedit: LoanoutFormModel = new LoanoutFormModel();
      if (element.countryOfIncorporation) {
        countryObj = this.countryDropdown.options.find(country => {
          return country.id === element.countryOfIncorporation.codeId;
        });
      }
      if (element.stateOfIncorporation) {
        stateObj = this.stateDropdown.options.find(state => {
          return state.id === element.stateOfIncorporation.codeId;
        });
      }

      ddModel = countryObj || {};
      loaunoutListedit.country = ddModel;
      ddModel = stateObj || {};
      loaunoutListedit.state = ddModel;
      loaunoutListedit.ein = element.partyInfo.confidentialInfo.taxNumber;
      loaunoutListedit.freeEIN = element.partyInfo.confidentialInfo.taxNumber;
      loaunoutListedit.loanoutCompany = element.names.PRIMARY[0].name.entity;
      loaunoutListedit.loanoutEditAdded = false;
      loaunoutListedit.primary = element.partyRole.primary;
      loaunoutListedit.editableFieldFlags = {
        addIcon: false,
        cancelIcon: false,
        disableIcons: false,
        deleteIcon: true,
        displayFields: false,
        editIcon: true,
        radioDisabled: true,
        einError: false
      };
      loaunoutListedit.id = element.id;
      loaunoutListedit.relationId = element.relationId;
      this.loanoutList.push(loaunoutListedit);
    });
    this.talentPersistService.setLoanoutList(this.loanoutList);

    this.loanoutForm.markAsPristine();
    this.loanoutForm.markAsUntouched();

    this.loanoutListForm.markAsPristine();
    this.loanoutListForm.markAsUntouched();
  }

  private disableLoanoutField(): void {
    if (this.loanoutForm && this.loanoutForm.controls) {
      Object.keys(this.loanoutForm.controls).forEach((field) => {
        if (this._disabledFieldInputs) {
          this.loanoutForm.controls[field].reset();
          this.loanoutForm.controls[field].disable();
        }
      });
      this.isEditingMode = this.disableAddIcon = this._disabledFieldInputs;
      this.primaryChecked = false;
      this.einFree = true;
    }
  }

  private enableLoanoutField(): void {
    setTimeout(() => {
      if (this.loanoutForm) {
        (this._disabledFieldInputs) ? this.loanoutForm.disable() : this.loanoutForm.enable();
        this.isEditingMode = this.disableAddIcon = this._disabledFieldInputs;
      }
    }, 100);
  }

  private isValidEIN(loanoutAdded: any): Observable<any> {
    const loanoutData: LoanoutModel = new LoanoutModel();
    const confidentialInfo: ConfidentialInfoModel = new ConfidentialInfoModel();
    const talentInfo: AddTalentModel = new AddTalentModel();
    const currentTalent = this.talentPersistService.getCurrentTalent();

    talentInfo.party.id = currentTalent.partyId;
    confidentialInfo.taxNumber = loanoutAdded.ein || loanoutAdded.freeEIN;
    loanoutData.partyInfo.confidentialInfo = confidentialInfo;
    talentInfo.party.roles.LOANOUT.push(loanoutData);
    return Observable.create((observer: Observer<any>) => {
      this.talentService.getValidations(talentInfo).subscribe(
        (res) => {
          observer.next(true);
        },
        (err) => {

          if (err.error && err.error.errors) {
            err.error.errors.forEach(element => {
              const errMessage: string = element.detail;
              const field: string = element.field;
              if (field && field.toLocaleUpperCase() === 'EIN') {
                observer.error('ein');
              } else {
                this.toasterService.error(`Error on validation call: ${errMessage}`, 'Opps!');
              }
            });
          }
        });
    });

  }
}
