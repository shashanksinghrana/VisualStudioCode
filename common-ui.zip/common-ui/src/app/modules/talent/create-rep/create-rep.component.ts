import { AccentedCharacterService } from './../../../services/http/accented-character/accented-character.service';
import { PeopleModelDetails } from './../../../models/talent/representative/people.model';
import { PeopleOutputParamsModel } from './../../../models/people/people-output-params.model';
import { TypeAheadDisplayResultModel } from './../../../models/type-ahead/type-ahead-display-result.model';
import { Component, OnInit, ChangeDetectorRef, Input, Output, EventEmitter, ViewContainerRef } from '@angular/core';
import { ToastsManager } from 'ng2-toastr';
import { DropdownModel } from './../../../models/dropdown/dropdown.model';
import { PeopleInputParamsModel } from './../../../models/people/people-input-params.model';
import { TalentPersistService } from './../../../services/persist/talent-persist.service';
import { ToasterService } from './../../../services/toaster/toaster.service';
import { TypeAheadMetaData } from '../../../enums/entity/type-ahead-metadata.enum';
import { UnsaveModalPopUp } from '../../../utils/unsave/unsave-modal';
import { UnsavedChangesService } from './../../../services/events/modal/unsaved-changes-event/unsaved-changes.service';
import { Router } from '@angular/router';

@Component({
  selector: 'c2c-create-rep',
  templateUrl: './create-rep.component.html',
  styleUrls: ['./create-rep.component.scss'],
  providers: [ToasterService, AccentedCharacterService]
})
export class CreateRepComponent implements OnInit {
  public occupationDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public typeDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public phoneDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public emailDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public socialMediaDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public selectStateAddDropdown = new DropdownModel('', '', '', '', []);
  public selectCountryAddDropdown = new DropdownModel('', '', '', '', []);
  public selectTypeAddDropdown = new DropdownModel('', '', '', '', []);
  public companyDropdown = new DropdownModel('', '', '', '', []);
  public locationDropdown = new DropdownModel('', '', '', '', []);
  public entityTypePeople: any = [];
  public entityTypeCompanies: any = [];
  public pickListData: any;
  public peopleData: PeopleModelDetails = new PeopleModelDetails();
  public peopleParamModel: PeopleInputParamsModel;
  public isEdit: boolean = false;
  public repDetailsData: any;
  public repPartyId: any;
  public talentService: any;
  public isDataLoaded: boolean = false;
  public setPopup: boolean = false;
  public loading = false;
  public navigationUrl: any;
  public viewRoute: any;

  @Input() public repId: any;
  @Input() public contactName: any;
  @Input() public targetId: any;
  @Input() public skipEvents: boolean = false;

  @Input('talentService')
  set _talentService(service) {
    this.talentService = service;
    this.getMetaDataForPeople();
    this.getMetaDataCompany();
    this.initTypeahead();
    const params = this.talentService.getRoutesParams();
    if (params) {
      if (params[0].path === 'addTalent') {
        this.setDataonLoad();
        this.loadRouteDetails({ param: null });
      } else {
        this.loadRouteDetails(params);
        if (this.repId) {
          this.getRepData(this.repId);
        } else {
          this.setDataonLoad();
        }
      }
    } else {
      this.setDataonLoad();
    }
  }

  @Output() public personSaved: EventEmitter<any> = new EventEmitter();
  @Output() public personCancel: EventEmitter<any> = new EventEmitter();
  public displayPeopleDataResults: TypeAheadDisplayResultModel;
  public displayCompanyDataResults: TypeAheadDisplayResultModel;
  public displayContactDataResults: TypeAheadDisplayResultModel;

  constructor(public changeDetector: ChangeDetectorRef, private vRef: ViewContainerRef,
    private toasterService: ToasterService, private accentedCharacterService: AccentedCharacterService,
    private talentPersistService: TalentPersistService, private toastr: ToastsManager, private unsavePopup: UnsaveModalPopUp, private unsaveService: UnsavedChangesService, private router: Router) {
    this.toastr.setRootViewContainerRef(vRef);

  }

  ngOnInit() {
    this.unsavePopup.setvalue.subscribe(res => {
      if (res.openModal) {
        console.log("Rep Open ---->");
        this.unsaveService.openModal();
        if (res.url.indexOf("http") >= 0) {
          this.navigationUrl = res.url;
        } else {
          this.viewRoute = res.url;
        }

      }
    });
  }

  getMetaDataForPeople() {
    this.talentService.getMetaDataFields('REPRESENTATIVE').subscribe(response => {
      console.log('METADATA FIELDS FOR PEOPLE: ', response);
      this.displayPeopleDataResults.metaDataColumns['default'] = [TypeAheadMetaData[response[response.length - 2]], TypeAheadMetaData[response[response.length - 1]]];
      this.displayContactDataResults.metaDataColumns['default'] = [TypeAheadMetaData[response[response.length - 2]], TypeAheadMetaData[response[response.length - 1]]];

    });
  }

  getMetaDataCompany() {
    this.talentService.getMetaDataFields('COMPANY').subscribe(response => {
      console.log('METADATA FIELDS FOR PEOPLE COMPANY: ', response);
      this.displayCompanyDataResults.metaDataColumns['default'] = [TypeAheadMetaData[response[response.length - 2]], TypeAheadMetaData[response[response.length - 1]]];;
    });
  }

  private loadRouteDetails(routeParams: any): void {
    if (!this.repId) {
      this.repId = routeParams.param;
    }
  }

  private getRepData(id) {
    this.talentService.getRepDetails(id).subscribe(res => {
      this.setDataonLoad();
    });
  }

  setDataonLoad() {
    if (this.repId) {
      this.isEdit = true;
      this.skipUnsaveModal();
      this.unsavePopup.setActivatePopup(this.setPopup);
      this.peopleData = this.talentService.getPersonData();
    } else {
      this.isEdit = false;
      this.skipUnsaveModal();
      this.unsavePopup.setActivatePopup(this.setPopup);
      this.peopleData = new PeopleModelDetails();
      if (this.contactName) {
        this.peopleData = this.talentService.getPersonData();
        this.peopleData.firstName = this.contactName.firstName || this.contactName.name.firstName;
        this.peopleData.lastName = this.contactName.entityName || this.contactName.name.entity;
        this.peopleData.partyId = this.contactName.partyId;

      }
    }

    // if (!this.peopleData.entityTypeId) {
    //   this.peopleData.entityTypeId = 1279;
    // }

    const companyTypeAheadService = {
      serviceClass: this.talentService,
      serviceAccentedClass: this.accentedCharacterService,
      getCompanyDetailsFromDb: 'getCompanyDetailsFromDb',
      saveParty: 'saveParty',
      saveAlias: 'saveAlias',
      getTalentDetails: 'getTalentDetails',
      getStateListFromDb: 'getStateListFromDb',
      getaccentedCharacters: 'getAccentedChars',
      saveCompanyAlias: 'saveAlias',
      saveCompany: 'saveParty',
      saveLocationCompanies: 'saveLocationCompanies',
      getNames: 'getNames'
    };

    this.getDropdownLookupData();
    const peopleTypeAheadService = {
      serviceClass: this.talentService,
      getPeopleDetailsFromDb: 'getRepDetails'
    };
    this.peopleParamModel = new PeopleInputParamsModel(this.peopleData, this.occupationDropdown,
      this.typeDropdown, this.displayPeopleDataResults,
      this.displayCompanyDataResults, this.locationDropdown, this.entityTypePeople, this.entityTypeCompanies,
      this.phoneDropdown, this.emailDropdown,
      this.socialMediaDropdown, this.displayContactDataResults, this.selectTypeAddDropdown, this.selectStateAddDropdown,
      this.selectCountryAddDropdown, companyTypeAheadService, peopleTypeAheadService);
    this.isDataLoaded = true;
    this.changeDetector.detectChanges();
  }

  private initTypeahead() {

    this.displayPeopleDataResults = {
      filterType: 'CONTACT_ONLY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'teamMembers'],
        display: '`${data.primaryName ?` (alias for ${data.primaryName}) `:` (team of ${data.teamMembers})`}`',
        notAllColumnsRequired: true
      },
      metaDataColumns: {},
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.talentService,
        get: 'getContactOnly'
      }
    };

    this.displayCompanyDataResults = {
      filterType: 'COMPANY_ONLY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`'
      },
      metaDataColumns: {},
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.talentService,
        get: 'getCompany'
      }
    };

    this.displayContactDataResults = {
      filterType: 'CONTACT_ONLY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`'
      },
      metaDataColumns: {},
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.talentService,
        get: 'getContactOnly'
      }
    };
  }

  /** Method to call the lookup services   */
  private getDropdownLookupData() {
    this.occupationDropdown = this.talentService.getDropDownOptionsList('CONTACT_OCCUPATION');
    this.typeDropdown = this.talentService.getDropDownOptionsList('CONTACT_TYPE');
    this.phoneDropdown = this.talentService.getDropDownOptionsList('PHONE_TYPE');
    this.emailDropdown = this.talentService.getDropDownOptionsList('EMAIL');
    this.socialMediaDropdown = this.talentService.getDropDownOptionsList('SOCIAL_MEDIA');
    this.selectStateAddDropdown = this.talentService.getDropDownOptionsList('countrystate/STATES/US');
    this.selectTypeAddDropdown = this.talentService.getDropDownOptionsList('ADDRESS_TYPE');
    this.selectCountryAddDropdown = this.talentService.getCountryOptionsList('countrystate/COUNTRIES');
    this.entityTypePeople = this.talentService.getOptionsList('CONTACT_ENTITY_TYPE');
    this.entityTypeCompanies = null;
  }

  public getEmptyLocationOptions() {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    options.push({
      value: '',
      route: '',
      id: '',
      data: ''
    });
    return dropdownModel;
  }

  public saveEvent(outParams: PeopleOutputParamsModel): void {
    if (null !== outParams && null !== outParams.peopleData && outParams.validPeople !== false) {
      this.peopleData = outParams.peopleData;
      this.peopleData.updatedByApp = 'Talent2';
      const dataSet = this.talentService.getUserData();
      this.peopleData.dataSet = dataSet.masterDataset;
      this.loading = true;
      this.talentService.insertUpdatePeopleDetails(this.peopleData).subscribe(
        (res) => {
          this.toasterService.success('Record Saved', 'Success!');
          if (this.setPopup) {
            this.setPopup = false;
            this.unsavePopup.setActivatePopup(this.setPopup);
          }
          this.repPartyId = res;
          if (this.contactName) {
            setTimeout(() => {
              this.personSaved.emit({ res, targetId: this.targetId });
              if (!this.setPopup) {
                //  this.setPopup = true;
                this.unsavePopup.setActivatePopup(true);
              }
              this.loading = false;
            }, 1000);
          } else if (this.isEdit) {
            setTimeout(() => {
              this.talentService.navigatePage(`/repDetail/${this.repPartyId.partyId}`);
              this.loading = false;
            }, 1000);

          } else {
            setTimeout(() => {
              this.talentService.navigatePage(`/repDetail/${this.repPartyId.partyId}`);
              this.loading = false;
            }, 1000);
          }
        },
        (err) => {
          this.loading = false;
          this.toasterService.error('Internal server error', 'Error!');
        });
    }
  }

  private skipUnsaveModal(): void {
    if (this.skipEvents) {
      this.setPopup = false;
    } else {
      this.setPopup = true;
    }
  }

  public cancelEvent(outParams: PeopleOutputParamsModel): void {
    if (this.contactName) {
      this.personCancel.emit({ outParams });
    } else {
      this.skipUnsaveModal();
      this.unsavePopup.setActivatePopup(this.setPopup);
      if (null !== outParams && null !== outParams.peopleData) {
        if (null === this.repId || undefined === this.repId) {
          this.talentService.navigatePage('/talentRepGrid');
        } else if (this.repId > 0) {
          this.talentService.navigatePage(`/repDetail/${this.repId}`);
        }
      }
      this.setPopup = false;
      this.unsavePopup.setActivatePopup(this.setPopup);
    }
  }

  public closeUnsavePop(evt) {
    console.log("Rep Close ---->");
    if (evt) {
      if (this.navigationUrl) {
        window.location.href = this.navigationUrl;
      } else {
        this.router.navigate([this.viewRoute]);
      }
      this.setPopup = false;
      this.unsavePopup.setActivatePopup(this.setPopup);
    }

  }

}
