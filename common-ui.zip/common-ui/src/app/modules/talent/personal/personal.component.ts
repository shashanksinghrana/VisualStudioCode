import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { Component, OnInit, ViewContainerRef, Input, Output, EventEmitter, ChangeDetectorRef, ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { NgbDatepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { ToastsManager } from 'ng2-toastr';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { DropdownTypeAheadModel } from './../../../models/dropdown-typeahead/dropdown-typeahead.model';
import { AddButtonModel } from './../../../models/button/add-button/add-button.model';
import { PersonalTabModel } from './../../../models/talent/add-talent/personal/personal-tab.model';
import { ImmigrationStatusModel } from './../../../models/talent/immigration-status.model';
import { DropdownFormModel } from './../../../models/talent/dropdown-form-model';
import { AddTalentModel } from './../../../models/talent/add-talent/add-talent.model';
import { ConfidentialInfoModel } from './../../../models/talent/add-talent/confidential-info.model';
import { ToasterService } from './../../../services/toaster/toaster.service';
import { TalentPersistService } from './../../../services/persist/talent-persist.service';
import { ExtractFormValues } from './../../../utils/extract-form-values';
import { ITalentEvents } from './../../../interfaces/italent-events';
import * as moment_ from 'moment';
const moment = moment_;
@Component({
  selector: 'c2c-talent-personal',
  templateUrl: './personal.component.html',
  styleUrls: ['./personal.component.scss'],
  providers: [NgbDatepickerConfig, DatePipe]
})
export class PersonalComponent implements OnInit {

  public personalForm: FormGroup;
  @ViewChild('statusDrop') public statusDrop: any;
  public ssnMaxLength: number = 11;
  public selectedDod: any;
  public selectedDob: any;
  private dropDownObj = {};
  public dateFormat: string = 'MM/DD/YYYY';
  public placeholder: string = '';
  public genderDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public ethnicityDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public citizenshipDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public immigrationStatusDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public statusDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public occupationDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public genreDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);

  public selectedImageValue: any;
  public actualBaseImageURL: any;
  public selectedImageType: any;
  public actualBaseImageType: any;
  public imageOverlayText = 'Talent Image located here';
  public selectedName: any;

  public addGenderButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Gender');
  public addEthnicityButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Ethnicity ');
  public addCitizenButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Citizenship');
  public addImigrationButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Immigration Status');
  public addOccupationButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Occupation');
  public addGenreButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Genre');

  public title: string = 'Talent Create/Edit Page';
  public placeholderDate = 'MM/DD/YYYY';
  public dobMessage: string = '';
  public dodMessage: string = '';
  public dobDodMessage: string = '';
  public expiresMeessage: string = '';
  public sagMessage: string = '';
  public validImmStatus: boolean = true;
  public validStatusExpire: boolean = true;
  public validCitizenLength: boolean = true;
  public validSsn: boolean = true;
  public validSagId: boolean = true;

  public submitted: boolean = false;
  public genderList: Array<object> = [];
  public ethnicityList: Array<object> = [];
  public citizenshipList: Array<object> = [];
  public immigrantStatusList: Array<object> = [];
  public occupationList: Array<object> = [];
  public genreList: Array<object> = [];
  public statusList: object = {};

  public notesMaxMsg: string = '';
  public creditsMaxMsg: string = '';

  public disabledFields: boolean = false;
  public ssn_valid: boolean = true;
  public personalTabValues: PersonalTabModel = new PersonalTabModel();

  private citizenshipSubs: Subscription;
  private timerCitizen: Observable<any>;
  private nonValidation: boolean = true;

  private _sagIdChanged: boolean = false;
  private _ssnChanged: boolean = false;
  private _objStateCountry: object;
  private _hideFields: boolean = false;
  public hidePiiFields: boolean = false;
  public hidePersonalData: boolean = false;
  public selectedStatus: any = null;
  public talentStudioId: any;
  public maxDate = new Date();
  public maxDateValue: string;

  @Input() talentService: ITalentEvents;

  @Input()
  set disableForm(val: boolean) {
    setTimeout(() => {
      if (this.personalForm) {
        (val) ? this.personalForm.disable() : this.personalForm.enable();
      }
    }, 100);
  }

  @Input()
  set disableFormFields(val: boolean) {
    this.hidePiiFields = val;
  }
  get disableFormFields(): boolean {
    return this.hidePiiFields;
  }

  @Input()
  set hidePersonalTab(val: boolean) {
    this.hidePersonalData = val;
  }

  private _personalData: any;
  @Input()
  set personaEditData(list: any) {
    this._personalData = list;
    if (this._personalData) {
      this.talentStudioId = this.talentService.getStudioID();
      this.setFieldsValues();

    }
  }
  get personaEditData(): any {
    return this._personalData;
  }

  @Input()
  set activeTabChanged(val: string) {
    this.extractFormValues();
  }
  @Output() disabledSaveBtn: EventEmitter<any> = new EventEmitter<any>();

  @Input()
  set dropdownValues(object: any) {
  }

  get dropdownValues(): any {
    return this._objStateCountry;
  }

  @Input()
  set hideFields(hide: boolean) {
    this._hideFields = hide;
  }
  get hideFields(): boolean {
    return this._hideFields;
  }

  @Output() dobChange: EventEmitter<any> = new EventEmitter<any>();

  constructor(
    private toasterService: ToasterService,
    private toastr: ToastsManager,
    private vRef: ViewContainerRef,
    private talentPersistService: TalentPersistService,
    public changeDetector: ChangeDetectorRef,
    private dateConfig: NgbDatepickerConfig, private datePipe: DatePipe) {
    this.dateConfig.minDate = { year: 1900, month: 1, day: 1 };
    this.dateConfig.maxDate = { year: 2099, month: 12, day: 31 };
    this.toastr.setRootViewContainerRef(this.vRef);
    this.maxDateValue = this.datePipe.transform(this.maxDate.toDateString(), 'MM/dd/yyyy');
  }

  ngOnInit() {

    this.talentService.getGenders().subscribe((res) => {
      this.genderDropdown = new DropdownTypeAheadModel('', '', '', '', res['picklists']['GENDER'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      }));
      // this.genderDropdown.options = res['picklists']['GENDER'].sort((a, b) => a.sortOrder - b.sortOrder);
    }, (err) => {
    });
    this.talentService.getRaces().subscribe((res) => {
      this.ethnicityDropdown = new DropdownTypeAheadModel('', '', '', '', res['picklists']['RACE'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      }));
      // this.ethnicityDropdown.options = res['picklists']['RACE'].sort((a, b) => a.sortOrder - b.sortOrder);
    }, (err) => {
    });
    this.talentService.getCountries().subscribe((res) => {
      this.citizenshipDropdown = new DropdownTypeAheadModel('', '', '', '', res['picklists']['COUNTRIES'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      }));
      // this.citizenshipDropdown.options = res['picklists']['COUNTRIES'].sort((a, b) => a.sortOrder - b.sortOrder);
    }, (err) => {
    });
    this.talentService.getImmigrationStatus().subscribe((res) => {
      this.immigrationStatusDropdown = new DropdownTypeAheadModel('', '', '', '', res['picklists']['IMMIGRATION_STATUS'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      })
      );
      // this.immigrationStatusDropdown.options = res['picklists']['IMMIGRATION_STATUS'].sort((a, b) => a.sortOrder - b.sortOrder);
    }, (err) => {
    });
    this.talentService.getStatus().subscribe((res) => {
      const response = res['picklists']['TALENT_STATUS'];
      this.statusDropdown = new DropdownTypeAheadModel('', '', '', '', response.sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      })
      );
      // this.statusDropdown.options = res['picklists']['TALENT_STATUS'].sort((a, b) => a.sortOrder - b.sortOrder);
    }, (err) => {
    });
    this.talentService.getOccupation().subscribe((res) => {
      this.occupationDropdown = new DropdownTypeAheadModel('', '', '', '', res['picklists']['STAFF_LEVEL'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      })
      );
      this.setDefaultOccupations(res['picklists']['STAFF_LEVEL']);
    }, (err) => {
    });
    this.talentService.getGenre().subscribe((res) => {
      this.genreDropdown = new DropdownTypeAheadModel('', '', '', '', res['picklists']['GENRE'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      })
      );
      // this.genreDropdown.options = res['picklists']['GENRE'].sort((a, b) => a.sortOrder - b.sortOrder);
    }, (err) => {
    });

    this.personalForm = new FormGroup({
      dropdowns: new FormGroup({
        genderPlays: new FormControl(null),
        ethnicityPlays: new FormControl(null),
        citizenship: new FormControl(null),
        immigrationStatus: new FormControl(null),
        status: new FormControl(null),
        occupation: new FormControl(null),
        genre: new FormControl(null)
      }),
      inputsFields: new FormGroup({
        ssn: new FormControl(null, {
          validators: [Validators.pattern(/^\d{3}-?\d{2}-?\d{4}$/), this.checkSnnValue],
          updateOn: 'change'
        }),
        sagId: new FormControl(null),
        dob: new FormControl(null),
        dod: new FormControl(null),
        expiresImigrationStatus: new FormControl(null),
        credits: new FormControl(''),
        notes: new FormControl('')
      })
    });

    if (this._personalData) {
      this.setFieldsValues();
    }
    this.nonValidation = false;
    this.onChange();
  }

  public listValueChanged(evt: Event): void {
  }

  private setDefaultOccupations(occupations: any[]): void {
    this.talentPersistService.setDefaultOccupation(null);
    if (occupations) {
      occupations.forEach((response) => {
        if (response.value === 'Performer') {
          this.talentPersistService.setDefaultOccupation(response);
          return false;
        }
      });
    }
  }

  public onCreateDateTimeValue(val, formControl) {
    if (val) {
      val = new Date(val);
      const inputControl = `inputsFields.${formControl}`;
      this.personalForm.get(inputControl).patchValue(val);

      const dobField: AbstractControl = this.personalForm.get('inputsFields.dob');
      const expiresImStatus: AbstractControl = this.personalForm.get('inputsFields.expiresImigrationStatus');
      if (!this.nonValidation) {
        this.validateDate(dobField, 'dob');
        this.validateDateFuture(dobField, 'dob');
        this.validateExpiresImmDob(expiresImStatus, dobField);
        this.validateDates();
        this.dobChange.emit(val);
        // this.personalForm.patchValue({ 'dob': dobTemp });
      }
    } else {
      const inputControl = `inputsFields.${formControl}`;
      this.personalForm.get(inputControl).patchValue(val);
      const dobField: AbstractControl = this.personalForm.get('inputsFields.dob');
      const expiresImStatus: AbstractControl = this.personalForm.get('inputsFields.expiresImigrationStatus');
      if (!this.nonValidation) {
        this.validateDate(dobField, 'dob');
        this.validateDateFuture(dobField, 'dob');
        this.validateExpiresImmDob(expiresImStatus, dobField);
        this.validateDates();
        this.dobChange.emit(val);
      }

    }
  }

  public onDodEvent(val, formControl) {
    if (val) {
      val = new Date(val);
      const inputControl = `inputsFields.${formControl}`;
      this.personalForm.get(inputControl).patchValue(val);

      const dodField: AbstractControl = this.personalForm.get('inputsFields.dod');
      if (!this.nonValidation) {
        this.validateDate(dodField, 'dod');
        this.validateDateFuture(dodField, 'dod');
        this.validateDates();
      }
      // dodField.valueChanges.subscribe(val => {
      //   if (!this.nonValidation) {
      //     this.validateDate(dodField, 'dod');
      //     this.validateDateFuture(dodField, 'dod');
      //     this.validateDates();
      //   }
      // });
    } else {
      const inputControl = `inputsFields.${formControl}`;
      this.personalForm.get(inputControl).patchValue(val);

      const dodField: AbstractControl = this.personalForm.get('inputsFields.dod');
      if (!this.nonValidation) {
        this.validateDate(dodField, 'dod');
        this.validateDateFuture(dodField, 'dod');
        this.validateDates();
        // dodField.valueChanges.subscribe(val => {
        //   if (!this.nonValidation) {
        //     this.validateDate(dodField, 'dod');
        //     this.validateDateFuture(dodField, 'dod');
        //     this.validateDates();
        //   }
        // });
      }
    }
  }
  public validateDates() {
    const dobField: AbstractControl = this.personalForm.get('inputsFields.dob');
    const dodField: AbstractControl = this.personalForm.get('inputsFields.dod');
    // if (!this.dobMessage && !this.dodMessage) {
    //   this.validateDobDod(dodField, dobField);
    // }
    if (dobField.value instanceof Date && dodField.value instanceof Date) {
      const ps = new Date();
      if (dobField.value.getTime() < ps.getTime() && dodField.value.getTime() < ps.getTime()) {
        this.validateDobDod(dodField, dobField);
      }
    }
  }

  private onChange(): void {
    const dobField: AbstractControl = this.personalForm.get('inputsFields.dob');
    const dodField: AbstractControl = this.personalForm.get('inputsFields.dod');
    const ssnField: AbstractControl = this.personalForm.get('inputsFields.ssn');
    const sagIdField: AbstractControl = this.personalForm.get('inputsFields.sagId');
    const immStatus: AbstractControl = this.personalForm.get('dropdowns.immigrationStatus');
    const expiresImStatus: AbstractControl = this.personalForm.get('inputsFields.expiresImigrationStatus');
    const creditsIdField: AbstractControl = this.personalForm.get('inputsFields.credits');
    const notesField: AbstractControl = this.personalForm.get('inputsFields.notes');

    /**
     * Extract form values
     * Pass whatever type to the ExtractFormValues
     */
    const extractValues: ExtractFormValues<PersonalTabModel> = new ExtractFormValues(PersonalTabModel);
    this.personalForm.valueChanges.subscribe(val => {
      this.persistPersonalTabValues(extractValues.get(this.personalForm.value));
    });

    // Look when dob field changes
    dobField.valueChanges.subscribe(val => {
      if (!this.nonValidation) {
        this.validateDate(dobField, 'dob');
        this.validateDateFuture(dobField, 'dob');
        this.validateExpiresImmDob(expiresImStatus, dobField);
        if (!this.dobMessage && !this.dodMessage) {
          this.validateDobDod(dodField, dobField);
        }
        this.dobChange.emit(val);
      }
    });
    // Look when dod field changes
    dodField.valueChanges.subscribe(val => {
      if (!this.nonValidation) {
        this.validateDate(dodField, 'dod');
        this.validateDateFuture(dodField, 'dod');
        if (!this.dobMessage && !this.dodMessage) {
          this.validateDobDod(dodField, dobField);
        }
      }
    });
    // Look when SSN field changes
    ssnField.valueChanges.debounceTime(50).subscribe(val => {
      val = this.setSSNFormat(val);
      ssnField.setValue(val);
      if (!this.validSsn) {
        this.validSsn = true;
        this._ssnChanged = false;
        this.disabledSaveBtn.emit({ field: 'ssn', disableBtn: false });

      } else {
        this._ssnChanged = true;
      }
      if (ssnField.hasError('pattern') && ssnField.hasError('ssnError') && this.validSsn) {
        this.disabledSaveBtn.emit({ field: 'ssn', disableBtn: true });
      } else {
        this.disabledSaveBtn.emit({ field: 'ssn', disableBtn: false });
      }
      setTimeout(() => {
        if (ssnField.value && ssnField.hasError('pattern') && ssnField.hasError('ssnError')) {
          this.ssn_valid = false;
        } else {
          this.ssn_valid = true;
        }
      }, 100);
    });
    // Look when SAG ID field changes
    sagIdField.valueChanges.subscribe(val => {
      if (val) {
        if (val.length === 51) {
          this.sagMessage = 'Must be 50 chars or less';
          this.disabledSaveBtn.emit({ field: 'sagId', disableBtn: true });
        } else {
          this.sagMessage = '';
          this.disabledSaveBtn.emit({ field: 'sagId', disableBtn: false });
        }
        this.validSagId = true;
        this._sagIdChanged = true;
      } else {
        if (!this.validSagId) {
          this._sagIdChanged = false;
          this.disabledSaveBtn.emit({ field: 'sagId', disableBtn: false });
        }
        this.validSagId = true;
        this.sagMessage = '';
      }
    });
    // Look when Immigration status dropdown field changes
    immStatus.valueChanges.subscribe(val => {
      if (val) {
        this.validImmStatus = true;
      } else {
        this.validImmStatus = false;
      }
    });
    // Look when expires field changes
    expiresImStatus.valueChanges.subscribe(val => {
      if (!this.nonValidation) {
        this.validateDate(expiresImStatus, 'expires');
        this.validateExpiresImmDob(expiresImStatus, dobField);
        if (!val) {
          this.personalForm.get('dropdowns.immigrationStatus').setValidators([]);
          this.personalForm.get('dropdowns.immigrationStatus').updateValueAndValidity();
        }
      }
    });
    notesField.valueChanges.subscribe(notes => {
      if (notes) {
        // const spaceCount = (notes.split(' ').length - 1);
        // const notesNoSpace = notes.replace(/\s/g, '');
        // const notesTotalLength = notesNoSpace.length + spaceCount;
        var isValidLength: boolean = this.getByteLen(notes);
        if (isValidLength === false) {
          this.notesMaxMsg = 'Must be 3000 chars or less';
          this.disabledSaveBtn.emit({ field: 'notes', disableBtn: true });
        } else {
          this.notesMaxMsg = '';
          this.disabledSaveBtn.emit({ field: 'notes', disableBtn: false });
        }
      } else {
        this.notesMaxMsg = '';
        this.disabledSaveBtn.emit({ field: 'notes', disableBtn: false });
      }
    });
    creditsIdField.valueChanges.subscribe(credits => {
      if (credits) {
        var isValidLength: boolean = this.getByteLen(credits);
        if (isValidLength === false) {
          this.creditsMaxMsg = 'Must be 3000 chars or less';
          this.disabledSaveBtn.emit({ field: 'credits', disableBtn: true });
        } else {
          this.creditsMaxMsg = '';
          this.disabledSaveBtn.emit({ field: 'credits', disableBtn: false });
        }
      } else {
        this.creditsMaxMsg = '';
        this.disabledSaveBtn.emit({ field: 'credits', disableBtn: false });
      }
    });
  }


  // get notes string byte length and limit to 4000
  getByteLen(value: string): boolean {
    var limit = 3000;
    var normal_val = String(value);
    var byteLen = 0;
    for (var i = 0; i < normal_val.length; i++) {
      var c = normal_val.charCodeAt(i);
      byteLen += c < (1 << 7) ? 1 :
        c < (1 << 11) ? 2 :
          c < (1 << 16) ? 3 :
            c < (1 << 21) ? 4 :
              c < (1 << 26) ? 5 :
                c < (1 << 31) ? 6 : Number.NaN;
    }
    if (byteLen > limit) {
      return false;
    } else {
      return true;
    }
  }

  /**
  * This function immigration status and expires date items to list compoenet below dropdown
  *
 */
  public addImigrationStatus(): void {
    if (!this.disabledFields) {
      let statusModel: ImmigrationStatusModel;
      let expire = this.personalForm.get('inputsFields.expiresImigrationStatus').value;
      const status = this.personalForm.get('dropdowns.immigrationStatus').value;

      if (status && !this.expiresMeessage) {
        let statusExpire = '';
        let index = -1;
        // Taking date expire value to be set in object
        statusModel = new ImmigrationStatusModel();
        statusExpire = `${this.personalForm.get('dropdowns.immigrationStatus').value.value}`;
        expire = expire ? new Date(expire).toLocaleDateString() : null;
        statusExpire = expire ? `${statusExpire} expires ${expire}` : statusExpire;

        // Creating Add name modal to pass to list
        statusModel.abbreviation = status.abbreviation;
        statusModel.id = status.id;
        statusModel.sortOrder = status.statusOrder;
        statusModel.value = status.value;
        statusModel.expires = expire;
        statusModel.statusExpire = statusExpire;

        // Check if object selected and createed is in local array
        this.immigrantStatusList.forEach((element, key) => {
          index = (index === -1 && element['id'] === statusModel['id'] && element['expires'] === statusModel['expires']) ? key : index;
        });
        if (index < 0) {
          this.immigrantStatusList.push(statusModel);
        } else {
          this.toasterService.info('The selected record already exists in the list.', 'Duplicate Record');
        }

        this.personalForm.get('inputsFields.expiresImigrationStatus').reset();
        this.personalForm.get('dropdowns.immigrationStatus').reset();
        const options = this.immigrationStatusDropdown.options;
        this.immigrationStatusDropdown = new DropdownTypeAheadModel('', '', '', '', options);
        this.personalForm.get('dropdowns.immigrationStatus').setValidators([]);
        this.personalForm.get('dropdowns.immigrationStatus').updateValueAndValidity();
        this.validImmStatus = true;
      } else if (!status && expire && !this.expiresMeessage) {
        this.validImmStatus = false;
        this.personalForm.get('dropdowns.immigrationStatus').setValidators(Validators.required);
        this.personalForm.get('dropdowns.immigrationStatus').updateValueAndValidity();
      }
    }
  }

  /**
  * This function removes items in list for all list
  * @param list object depending what item will be remove in list
 */
  public removeCustomList(list: any): void {
    let index = -1;
    if (list.listName === 'citizenshipList') {
      this.validCitizenLength = true;
    }
    if (index < 0) {
      this[list.listName].forEach((element, key) => {
        if (list.listName === 'immigrantStatusList') {
          index = (index === -1 && element['id'] === list.item['id'] && element.statusExpire === list.item['statusExpire']) ? key : index;
        } else {
          index = (index === -1 && element['id'] === list.item['id']) ? key : index;
        }
      });
      if (index > -1) {
        this[list.listName].splice(index, 1);
      }
    }
    this.personalForm.markAsDirty();
    this.personalForm.markAsTouched();
  }

  /**
   * This function checks format is valid for datepicker
   * component to display error inline below field.
   * @param date object depending what item will be remove in list
   * @param dateOf sting to look what field will be evaluated
  */
  private validateDate(date: AbstractControl, dateOf: string): any {
    const dateRegex = /^(\d{1,2})(\/)(\d{1,2})(\/)(\d{4})$/;
    let message: string = '';
    if (dateOf === 'dob') {
      this.dobMessage = '';
    } else if (dateOf === 'dod') {
      this.dodMessage = '';
    } else if (dateOf === 'expires') {
      this.expiresMeessage = '';
    }

    if (date.value instanceof Date) {
      if (!dateRegex.test(date.value.toLocaleDateString())) {
        message = 'Please enter a valid date MM/DD/YYYY.';
      }
    } else {
      if (date.value) {
        message = 'Please enter a valid date MM/DD/YYYY.';
      } else {
        message = '';
      }
    }
    if (dateOf === 'dob') {
      this.dobMessage = message;

    } else if (dateOf === 'dod') {
      this.dodMessage = message;
    } else if (dateOf === 'expires') {
      this.expiresMeessage = message;
    }
  }


  private validateDateFuture(date: AbstractControl, dateOf: string): any {

    if (date.value instanceof Date) {
      const ts = new Date();
      if (dateOf === 'dob') {
        this.dobMessage = date.value.getTime() > ts.getTime() ? 'DOB can not be future date.' : '';
      }
      // if (date.value.getTime() > ts.getTime() && dateOf === 'dob') {
      //   this.dobMessage = 'DOB can not be future date.';
      // }
      if (dateOf === 'dod') {
        this.dodMessage = date.value.getTime() > ts.getTime() ? 'DOD can not be future date.' : '';
      }
      // if (date.value.getTime() > ts.getTime() && dateOf === 'dod') {
      //   this.dodMessage = 'DOD can not be future date.';
      // }
    }
  }

  /**
   * This function checks DOB and DOD is after and before to display
   * error message inline.
   * @param date object depending what item will be remove in list
   * @param dateOf sting to look what field will be evaluated
  */
  private validateDobDod(date: AbstractControl, date1: AbstractControl): void {

    // if (!this.dobMessage && !this.dodMessage) {
    if (date.value) {
      if (date1.value) {
        this.dodMessage = date.value.getTime() < date1.value.getTime() ? 'DOD cannot occur before DOB' : '';
      } else {
        this.dobMessage = 'Please enter DOB';
      }
    }
    // }
    if ((date.value instanceof Date) && (date1.value instanceof Date)) {
      this.dobMessage = '';
      if (date.value.getTime() > date1.value.getTime() || date.value.getTime() === date1.value.getTime()) {
        this.dobDodMessage = '';
      }
    } else if (date.value === null && date1.value === null) {
      this.dobMessage = '';
      this.dodMessage = '';
    } else if ((date.value instanceof Date) && date1.value === null) {
      this.dodMessage = '';
      this.dobDodMessage = '';
      this.dobMessage = 'Please enter DOB';
    } else if ((date.value instanceof Date) && !(date1.value instanceof Date)) {
      this.dobDodMessage = '';
    } else if (!(date.value instanceof Date) && date1.value == null) {
      this.dobMessage = '';
    } else if (!(date.value instanceof Date) && (date1.value instanceof Date)) {
      this.dobDodMessage = '';
    }
  }

  /**
   * Function validates Expires data immigrations status before Dob
   * @param dateExpires form control of expire date
   * @param dateDob fomr control for dob
   */
  private validateExpiresImmDob(dateExpires: AbstractControl, dateDob: any): void {
    if ((dateExpires.value instanceof Date) && (dateDob.value instanceof Date)) {
      if (dateExpires.value.getTime() < dateDob.value.getTime() && !this.expiresMeessage) {
        this.expiresMeessage = 'Expires cannot occur before DOB.';
      } else if (dateExpires.value.getTime() >= dateDob.value.getTime()) {
        this.expiresMeessage = '';
      }
    }
    if (dateDob.value == "" || dateDob.value === null) {
      this.expiresMeessage = '';
    }
  }

  /**
   * This function adds items to list depends on what values are passed as parameters
   *
   * @param fControl string name of control will be passed
   * @param listName string list name where items will be added list component and
   * string list that contains list of item to be stored in application
   *
   *
  */
  public addToList(fControl: string, listName: string, dropDownOpt: string): void {

    if (!this.disabledFields) {
      const dropdownControl = `dropdowns.${fControl}`;
      const listData = this.personalForm.get(dropdownControl).value;
      let validationControl = true;
      let index = -1;
      if (listData) {
        if (fControl === 'citizenship') {
          if (this.citizenshipSubs) {
            this.citizenshipSubs.unsubscribe();
          }
          validationControl = this.validateCitizenship();
        }
        if (validationControl) {
          this[listName].forEach((element, key) => {
            index = (index === -1 && element['id'] === listData['id']) ? key : index;
          });
          if (index < 0) {
            this[listName].push(listData);
            this.personalForm.get(dropdownControl).reset();
          } else {
            this.toasterService.info('The selected record already exists in the list.', 'Duplicate Record');
          }
        }
        const options = this[dropDownOpt].options;
        this[dropDownOpt] = new DropdownTypeAheadModel('', '', '', '', options);
        // this.personalForm.get(dropdownControl).patchValue(null);
      }
    }
  }

  public validateCitizenship(): boolean {
    this.validCitizenLength = this.citizenshipList.length < 2 ? true : false;
    if (!this.validCitizenLength) {
      this.timerCitizen = Observable.timer(5000);
      this.citizenshipSubs = this.timerCitizen.subscribe(() => {
        this.validCitizenLength = true;
      });
    }

    return this.validCitizenLength;
  }

  /**
   * This function gets value selected in Status dropdown
   *
   * @param val object selected in Status Dropdown
  */
  public onSelectStatus(val: object): void {
    this.statusList = val;
    this.selectedStatus = val;
    this.personalForm.patchValue({
      'dropdowns.status': this.selectedStatus
    });
  }

  /**
   * function to reset from fields except SSN field
   *
   */
  private clearFormValues(cleanAll?: boolean): void {
    // Reset dropdowns
    Object.keys(this.personalForm.controls.dropdowns['controls']).forEach((field) => {
      this.personalForm.controls.dropdowns['controls'][field].reset();
    });

    // Reset input fields like sag id, dob, dod, expires, notes & credits
    Object.keys(this.personalForm.controls.inputsFields['controls']).forEach((field) => {
      if (field !== 'ssn' && cleanAll) {
        this.personalForm.controls.inputsFields['controls'][field].reset();
      } else if (field === 'ssn' && cleanAll) {
        this.personalForm.controls.inputsFields['controls'][field].reset();
      }  // TODO: to remove this validation to reset all fields when detail view will be implemented
    });
  }

  /**
   * toggleState method to disable the fields after save!!
   *
   */
  public toggleState(): void {
    Object.keys(this.personalForm.controls).forEach((fieldGroup) => {
      if (this.disabledFields) {
        this.personalForm.controls[fieldGroup].disable();
      }
    });
  }
  /**
   * This function validator for EIN format
   * @param control form control will be checked.
  */
  public checkSnnValue(control: FormControl): { [key: string]: boolean } | null {
    const ssnReges = /^\d{3}-?\d{2}-?\d{4}$/;
    if (control.value && !ssnReges.test(control.value)) {
      return { 'ssnError': true };
    } else {
      return null;
    }
  }

  /**
   * This function validator for SSN format
   * @param value ssn value in inoput field in view
  */
  public setSSNFormat(value: string): string {
    if (value) {
      let val = value.replace(/\D/g, '');
      let newVal = '';
      const sizes = [3, 2, 4];

      for (const i in sizes) {
        if (val.length > sizes[i]) {
          if (i !== '2') {
            newVal += val.substr(0, sizes[i]) + '-';
          } else {
            newVal += val.substr(0, sizes[i]);
          }
          val = val.substr(sizes[i]);
        } else {
          break;
        }
      }
      if (newVal.length < 10) {
        newVal += val;
      }
      return newVal;
    } else {
      return '';
    }
  }

  /**
   * This functionto create displayAliasText for talent record
   * @param talent talent object to buld name
  */
  private createDisplayAliasText(talent: any): string {
    return (talent.first ? talent.first + ' ' : '') +
      (talent.middle ? talent.middle + ' ' : '') +
      (talent.entity ? talent.entity : '') +
      (talent.suffix ? ', ' + talent.suffix : '');
  }

  /**
   * Restarting list data and error messages when removing talent record header
   */
  private clearList(): void {
    this.genderList = [];
    this.genreList = [];
    this.ethnicityList = [];
    this.citizenshipList = [];
    this.immigrantStatusList = [];
    this.occupationList = [];
    this.genreList = [];
    // cleaning error messages for date picker
    this.dobDodMessage = '';
    this.dobMessage = '';
    this.dodMessage = '';
    this.expiresMeessage = '';
  }

  private convertDate(date: string): string {
    let newDate = '';
    if (date) {
      const dateArr = date.split('-');
      newDate = dateArr[0] + '/' + dateArr[1] + '/' + dateArr[2];
    }
    return newDate;
  }

  /**
  * This function sets response from service save talent record to all fiuelds
  *
  * @param data object selected in Status Dropdown
 */
  private setFieldsValues(): void {
    let statusObj;

    this.clearList();
    // setting values for sag id, dob and dod from servies
    if (this.personalForm) {
      this.personalForm.reset();
      const dateOfBirth = this._personalData.confidentialInfo.dateOfBirth;
      const dateOfDeath = this._personalData.confidentialInfo.dateOfDeath;
      if (this._personalData.confidentialInfo) {
        this.personalForm.get('inputsFields.sagId').setValue(this._personalData.confidentialInfo.sagId);

      }

      if (this._personalData.confidentialInfo.taxNumber) {
        this.personalForm.get('inputsFields.ssn').setValue(this._personalData.confidentialInfo.taxNumber);
      }
      if (dateOfBirth) {
        this.personalForm.get('inputsFields.dob').setValue(new Date(this.convertDate(dateOfBirth)));
        this.selectedDob = this.personalForm.get('inputsFields.dob').value;
        // this.personalForm.get('inputsFields.dob').setValue(this.convertDate(dateOfBirth));
      }
      if (dateOfDeath) {
        this.personalForm.get('inputsFields.dod').setValue(new Date(this.convertDate(dateOfDeath)));
        this.selectedDod = this.personalForm.get('inputsFields.dob').value;
        // this.personalForm.get('inputsFields.dod').setValue(this.convertDate(dateOfDeath));
      }

      /*
      * TODO: choosing correct data per data retuened are differen arrays
      * studio, notes and credits
      */
      // setting value for status dropdown from service
      if (this._personalData.professionalInfo.partyStudioAttributes && this._personalData.professionalInfo.partyStudioAttributes.length) {
        // const partyArr = this._personalData.professionalInfo.partyStudioAttributes.sort((a, b) => b.partyStudioId - a.partyStudioId)[0];
        const partyArr = this._personalData.professionalInfo.partyStudioAttributes.find(studioDetails => {
          return studioDetails.studio === this.talentStudioId;

        });

        if (partyArr) {
          this.talentPersistService.setPartyStudioId(partyArr.partyStudioId);
          if (partyArr.status) {
            statusObj = this.statusDropdown.options.find(status => {
              return status.id === partyArr.status.codeId;
            });
          }
          this.statusList = this.selectedStatus = statusObj || this.statusList;
          this.personalForm.get('dropdowns.status').setValue(this.selectedStatus);
          // Cleaning notes and credits fields
          this.personalForm.get('inputsFields.notes').reset();
          this.personalForm.get('inputsFields.credits').reset();
          // Setting values from service (Notes & credits)
          this.personalForm.get('inputsFields.notes').setValue(partyArr.notes);
          this.personalForm.get('inputsFields.credits').setValue(partyArr.credits);
        }

      }

      // Populate list below dropdowns gender plays, ethnicity plays, citizenthip,
      // immigrations status with expire date, occupation and genre from service
      if (this._personalData.confidentialInfo.genderPlays && this._personalData.confidentialInfo.genderPlays.length > 0) {
        this.setListItems(this._personalData.confidentialInfo.genderPlays, 'genderList', 'genderDropdown', '');
      }

      if (this._personalData.confidentialInfo.racePlays && this._personalData.confidentialInfo.racePlays.length > 0) {
        this.setListItems(this._personalData.confidentialInfo.racePlays, 'ethnicityList', 'ethnicityDropdown', '');
      }

      if (this._personalData.confidentialInfo.citizenships && this._personalData.confidentialInfo.citizenships.length > 0) {
        this.setListItems(this._personalData.confidentialInfo.citizenships, 'citizenshipList', 'citizenshipDropdown', '');
      }

      if (this._personalData.confidentialInfo.workEligibilities && this._personalData.confidentialInfo.workEligibilities.length > 0) {
        this.setListImmStatusExpire(this._personalData.confidentialInfo.workEligibilities,
          'immigrantStatusList',
          'immigrationStatusDropdown');
      }

      if (this._personalData.professionalInfo.occupations && this._personalData.professionalInfo.occupations.length > 0) {
        this.setListItemsOccupation(this._personalData.professionalInfo.occupations,
          'occupationList', 'occupationDropdown', 'occupationName');
      }

      if (this._personalData.professionalInfo.genres && this._personalData.professionalInfo.genres.length > 0) {
        this.setListItems(this._personalData.professionalInfo.genres, 'genreList', 'genreDropdown', '');
      }

      this.personalForm.markAsPristine();
      this.personalForm.markAsUntouched();
    }

  }
  /**
   * This function set items in list after saving
   * repopulating list for all dropdowns
   * @param items array of objects to populate list.
   * @param listNameObj string to look in scope wht list will get items example genderList.
   * @param listName string to look what list component will receive items belos dropdowns.
   * @param ddModel what dropdown model to lok for options.
   * @param keyValue string value in case response comes with paren porperty and not directly loop for codeId prop.
  */
  private setListItems(items: Array<object>, listName: string, ddModel: string, keyValue?: string) {

    items.forEach(element => {
      let ddFormModel: DropdownFormModel = new DropdownFormModel();
      const ddObj = this[ddModel].options.find(status => {
        let eleToFind;
        if (keyValue && keyValue !== '') {
          eleToFind = element[keyValue]['codeId'];
        } else {
          eleToFind = element['codeId'];
        }
        return status.id === eleToFind;
      });
      if (ddObj) {
        ddFormModel = ddObj;
        this[listName].push(ddFormModel);
      }

    });
  }

  private setListItemsOccupation(items: Array<object>, listName: string, ddModel: string, keyValue?: string) {

    items.forEach(element => {
      let ddFormModel: DropdownFormModel = new DropdownFormModel();
      const ddObj = Object.assign({}, element[keyValue]);
      ddObj['id'] = ddObj['codeId'];
      ddObj['value'] = ddObj['code'];
      delete ddObj.codeId;
      delete ddObj.code;
      if (ddObj) {
        ddFormModel = ddObj;
        this[listName].push(ddFormModel);
      }

    });
  }

  /**
  * This function set items in list after saving for immigration status
  * repopulating list for all dropdowns
  * @param items array of objects to populate list.
  * @param listNameObj string to look in scope wht list will get items example genderList.
  * @param listName string to look what list component will receive items belos dropdowns.
  * @param ddModel what dropdown model to lok for options.
  * TODO: make re-usable with above function setListItems
  */
  private setListImmStatusExpire(items: Array<object>, listName: string, ddModel: string) {
    items.forEach(element => {
      const imStatus: ImmigrationStatusModel = new ImmigrationStatusModel();
      const immStatusObj = this[ddModel].options.find(status => {
        return status.id === element['workEligibilityType'].codeId;
      });
      if (imStatus) {
        imStatus.abbreviation = immStatusObj.abbreviation;
        imStatus.id = immStatusObj.id;
        imStatus.sortOrder = immStatusObj.sortOrder;
        imStatus.value = immStatusObj.value;
        imStatus.statusExpire = `${immStatusObj.value}`;
        imStatus.expires = element['expiryDate'] ? this.setDateFormat(element['expiryDate'], [2, 1, 0]) : element['expiryDate'];
        imStatus.statusExpire = imStatus.expires ? `${immStatusObj.value} expires ${imStatus.expires}` : imStatus.statusExpire;
        imStatus.immigrationId = element['id'];
        this[listName].push(imStatus);
      }
    });
  }
  /**
   * Function that sets date format expected by DB to save information
   * format date base on yyyy-MM-dd
   * @param date date on string format coming as dd-MM-yyyy
   */
  private setDateFormat(date: string, dateOrder: Array<number>): string {
    let dateFormat: string = '';
    let dateArray = [];
    let separator = '-';
    dateArray = date.split('/').reverse();
    if (dateArray.length < 3) {
      dateArray = date.split('-').reverse();
      separator = '/';
    }
    for (let i = 0; i < dateArray.length; i = i + 1) {
      dateArray[i] = this.padZeroDate(dateArray[i]);
    }
    const [year, month, day] = [dateArray[dateOrder[0]], dateArray[dateOrder[1]], dateArray[dateOrder[2]]];
    if (separator === '-') {
      dateFormat = [year, month, day].join(separator);
    } else {
      dateFormat = [month, day, year].join(separator);
    }
    return dateFormat;
  }
  /**
   * Functions that pads zero to day or month when is set as single number
   * when day and month isl ess than 10 adding zero to left of number
   * @param dayNumber day number as string
   */
  private padZeroDate(dayNumber: string): string {
    return dayNumber.length < 2 ? '0' + dayNumber : dayNumber;
  }

  private extractFormValues(): void {
    /**
       * Extract form values
       * Pass whatever type to the ExtractFormValues
       */
    const extractValues: ExtractFormValues<PersonalTabModel> = new ExtractFormValues(PersonalTabModel);

    if (this.personalForm) {
      this.persistPersonalTabValues(extractValues.get(this.personalForm.value));
    }
  }

  // for soft save
  private persistPersonalTabValues(val: any): void {

    const listArray: Array<object> = [
      { key: 'citizenshipList', value: this.citizenshipList },
      { key: 'ethnicityList', value: this.ethnicityList },
      { key: 'genreList', value: this.genreList },
      { key: 'genderList', value: this.genderList },
      { key: 'occupationList', value: this.occupationList },
      { key: 'immigrationStatus', value: this.immigrantStatusList },
      { key: 'statusList', value: this.statusList }
    ];

    let formData: PersonalTabModel = new PersonalTabModel();
    formData = val;

    listArray.forEach(itm => {
      formData[itm['key']] = itm['value'];
    });
    setTimeout(() => {
      this.talentPersistService.setPersonalTabData(formData);
    }, 100);
  }

  public focusOutFunction(evt: FocusEvent) {
    const fieldChanged = evt.currentTarget['id'];
    const talentInfo: AddTalentModel = new AddTalentModel();

    let valueUpdated = false;
    const confidentialInfoTalent: ConfidentialInfoModel = new ConfidentialInfoModel();
    if (fieldChanged === 'sagId' && this._sagIdChanged) {
      confidentialInfoTalent.sagId = evt.currentTarget['value'];
      valueUpdated = true;
    } else if (fieldChanged === 'ssn' && this._ssnChanged &&
      !this.personalForm.get('inputsFields.ssn').hasError('pattern') &&
      !this.personalForm.get('inputsFields.ssn').hasError('ssnError') && this.validSsn) {
      confidentialInfoTalent.taxNumber = evt.currentTarget['value'];
      valueUpdated = true;
    }
    if (valueUpdated) {
      const currentTalent = this.talentPersistService.getCurrentTalent();
      if (currentTalent) {
        talentInfo.party.id = currentTalent.partyId;
        talentInfo.party.partyInfo.confidentialInfo = confidentialInfoTalent;
        this.talentService.getValidations(talentInfo).subscribe(
          (res) => {
            const errorObj = { field: fieldChanged, disableBtn: false };
            this.disabledSaveBtn.emit(errorObj);
          },
          (err) => {
            if (err.error && err.error.errors) {
              err.error.errors.forEach(element => {
                const errMessage: string = element.detail;
                const field: string = element.field;

                if (field && field.toLocaleUpperCase() === 'SSN') {
                  this.validSsn = false;
                  const errorObj = { field: 'ssn', disableBtn: true };
                  this.disabledSaveBtn.emit(errorObj);
                } else if (field && field.toLocaleUpperCase() === 'SAG') {
                  const errorObj = { field: 'sagId', disableBtn: true };
                  this.validSagId = false;
                  this.disabledSaveBtn.emit(errorObj);
                } else {
                  this.toasterService.error(`Error on validation call: ${errMessage}`, 'Opps!');
                }
              });
            }
          });
      }
    }
  }
  // Type-Ahead dropdown
  public onSelectOccupationEvent(selectedVal: any, fControl: string, listName: string): void {
    console.log(`${selectedVal} ${fControl} ${listName}`);
    const ddownControl = `dropdowns.${fControl}`;
    this.personalForm.get(ddownControl).patchValue(selectedVal);
  }

  keyDown(event) {
    if (event.keyCode <= 65 && event.keyCode > 90) {
      event.preventDefault();
      event.returnValue = false;
      event.stopPropagation();
    }
  }
}
