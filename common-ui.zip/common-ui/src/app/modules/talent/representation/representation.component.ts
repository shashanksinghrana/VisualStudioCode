import { TypeAheadModel } from './../../../models/type-ahead/type-ahead.model';
import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { AddRepFormModel } from './../../../models/talent/representative/add-rep-form.model';
import { AddRepresentativeModel, Phone, Occupation, Companies } from './../../../models/talent/representative/add-representative.model';
import { TypeAheadService } from '../../../services/http/type-ahead/type-ahead.service';
import { AddAliasService } from '../../../services/http/type-ahead/aka/add-alias.service';
import { AddButtonModel } from './../../../models/button/add-button/add-button.model';
import { CheckboxModel } from './../../../models/checkbox/checkbox.model';
import { DropdownModel } from './../../../models/dropdown/dropdown.model';
import { TypeAheadDisplayResultModel } from './../../../models/type-ahead/type-ahead-display-result.model';
import { TypeAheadSaveModel } from './../../../models/type-ahead/type-ahead-save.model';
import { AddAliasAKAModel } from './../../../models/type-ahead/aka/add-alias-aka.model';
import { EmptyIfNull } from './../../../utils/strings/empty-if-null';
import { AddAliasModel } from './../../../models/type-ahead/aka/add-alias.model';
import { ModalGenericComponent } from './../../../modal/generic/modal-generic.component';
import { TalentPersistService } from './../../../services/persist/talent-persist.service';
import { ITalentEvents } from './../../../interfaces/italent-events';
import { DropdownTypeAheadModel } from '../../../models/dropdown-typeahead/dropdown-typeahead.model';
import { TypeAheadMetaData } from '../../../enums/entity/type-ahead-metadata.enum';


@Component({
  selector: 'c2c-talent-representation',
  templateUrl: './representation.component.html',
  styleUrls: ['./representation.component.scss'],
  providers: [TypeAheadService, AddAliasService]

})
export class RepresentationComponent implements OnInit {

  @ViewChild('representative') representative: any;
  @ViewChild('company') company: any;
  @Input() talentService: ITalentEvents;
  @Input() public skipEvents: boolean = false;
  @ViewChild('talentRepModal') talentRepModal: ModalGenericComponent;
  @Output() onContactTab: EventEmitter<any> = new EventEmitter<any>();
  @ViewChild('addRepCompanyModal') addRepCompanyModal: any;
  @ViewChild('addRepModal') addRepModal: any;

  public repTabForm: FormGroup;
  public repTabFormList: FormGroup;
  public isCompanyEdit: boolean = false;
  public showCompanyModal: boolean = false;

  public companyName: string = '';
  public hideElement: boolean = true;
  public typeAheadValue: string;
  public typeAheadValueCompany: string;
  public currentIndex: any;
  public repDuplicated: string = '';
  public companyDetails: any;
  public serviceRes: boolean = false;
  public newSelectedCompany: any;
  public phoneKeydownCount: number = 0;
  public mask = ['(', /[0-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  /**Input value coming from Add Talent Compoennet i.e. PartyId of Selected Names */
  // Clean team data when talent names in header have been removed
  @Input()
  set cleanForm(remove: boolean) {
    if (remove) {
      this.repItemAdded = [];
      this.talentPersistService.setRepresentationListData([]);
      this.talentPersistService.setContactGuardianData([]);
    }
  }

  @Input() selectedName: any;
  @Input()
  set disableForm(val: boolean) {

    setTimeout(() => {

      if (this.repTabForm) {
        (val) ? this.repTabForm.disable() : this.repTabForm.enable();
      }
    }, 100);

    setTimeout(() => {

      if (this.repTabFormList) {
        (val) ? this.repTabFormList.disable() : this.repTabFormList.enable();
      }
    }, 100);

  }

  private _repListEdit: Array<object> = [];
  @Input()
  set repListEdit(list: any) {
    this._repListEdit = list;
    if (list && list.length > 0) {
      this.setRepListEdit(this._repListEdit);
    }
  }
  get repListEdit(): any {
    return this._repListEdit;
  }

  public parentPartyId: any;
  public childPartyId: any;
  public contactDetails: any;
  public occupationValue: any;
  public companyPartyId: any;

  public contactTypeList: any;
  public genericModal: ModalGenericComponent;
  public repdataModel: AddRepresentativeModel;
  public repItemAdded: Array<AddRepFormModel> = [];
  public addRepresentativeButton: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Representative');
  public checkboxInput: CheckboxModel = new CheckboxModel('', '', []);
  public partyId: any;
  public partyDetails: any;
  public type: DropdownModel = new DropdownModel('', '', '', '', []);
  public phoneType: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public typeAheadTitleRep: string = 'Name';
  public typeAheadTitleComp: string = 'Company';
  public repPersonName: any;

  public typeAheadModalConfig: any = {
    title: 'Add New Representative name',
    label: 'This is a label',
    showAddAlias: true,
    displayNameAs: true,
    additionalFieldsDisplayed: true,
    typeAheadId: 'personType'
  };

  public typeAheadDataRepService: any;
  public displayDataResults: TypeAheadDisplayResultModel;
  public displayCompanyDataResults: TypeAheadDisplayResultModel;

  public accentedRepModalName = 'talentAccentedModalRep';
  public accentedComModalName = 'talentAccentedModalComp';

  public componentUpdate: boolean = false;

  public contactCompanyModalConfig: any = {
    title: 'Add New Company name',
    label: 'This is a label',
    showAddAlias: false,
    displayNameAs: true,
    allowOnlyOneAlias: true,
    modalName: 'modalCompanyRep',
    typeAheadId: 'repCompanyType'
  };

  public repModalConfig: any = {
    title: 'Add New Rep name',
    label: 'This is a label',
    showAddAlias: false,
    displayNameAs: true,
    allowOnlyOneAlias: true,
    modalName: 'modalRepName',
    typeAheadId: 'personType'
  };
  public isRepEdit: boolean = false;
  constructor(private talentPersistService: TalentPersistService) { }

  ngOnInit() {
    this.initTypeahead();
    this.repTabForm = new FormGroup({
      repId: new FormControl(null, Validators.required),
      first: new FormControl(null),
      entity: new FormControl(null),
      representative: new FormControl(null, Validators.required),
      company: new FormControl(null, Validators.required),
      occupation: new FormControl(null, Validators.required),
      phoneType: new FormControl(null, Validators.required),
      companyPartyId: new FormControl(null, Validators.required),
      phoneNumber: new FormControl(null, Validators.required),
      primary: new FormControl(null, Validators.required),
    });

    this.repTabFormList = new FormGroup({
    });

    this.typeAheadDataRepService = this.talentService;
    this.getRepTypeList();
    this.getPhoneTypeList();
    this.onChange();
    this.getMetaDataForCompany();
    this.getMetaDataForRepresentative();

  }

  getMetaDataForRepresentative() {
    this.talentService.getMetaDataFields('REPRESENTATIVE').subscribe(response => {
      this.displayDataResults.metaDataColumns['default'] = [TypeAheadMetaData[response[response.length - 2]], TypeAheadMetaData[response[response.length - 1]]];

    });
  }

  getMetaDataForCompany() {
    this.talentService.getMetaDataFields('COMPANY').subscribe(response => {
      this.displayCompanyDataResults.metaDataColumns['default'] = [TypeAheadMetaData[response[response.length - 2]], TypeAheadMetaData[response[response.length - 1]]];
    });
  }


  private onChange(): void {
    const repForm: AbstractControl = this.repTabForm.get('representative');
    repForm.valueChanges.subscribe(typeRep => {
      if (typeRep !== null) {
        this.repDuplicated = '';
      }
    });
  }

  onFocusAddButton() {
    this.onContactTab.emit();
  }

  private initTypeahead(): void {
    this.displayDataResults = {
      filterType: 'CONTACT_ONLY',
      context: 'REPRESENTATIVE',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`'
      },
      defaultMetadataResults: true,
      metaDataColumns: {},
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.talentService,
        get: 'getContactOnly'
      }
    };

    this.displayCompanyDataResults = {
      filterType: 'COMPANY_ONLY',
      context: 'COMPANY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`'
      },
      defaultMetadataResults: true,
      metaDataColumns: {},
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.talentService,
        get: 'getCompany'
      }
    };
  }

  public selectedTypeAheadRecord(evt: any, type: string): void {
    this.valueReset();
    if (type === 'representative') {
      this.partyId = evt.partyId;
    } else {
      this.companyPartyId = evt.partyId;
      this.newSelectedCompany = evt.typeAheadDisplayName;
    }
    if (this.selectedName) {
      this.parentPartyId = this.selectedName.partyId;
    }
    if ((this.selectedName && this.parentPartyId !== this.partyId) ||
      (this.selectedName === undefined && this.partyId && type === 'representative')) {
      this.getPartyIdDetails(this.partyId, type, evt.entityName);
    } else {
      if (type === 'representative') {
        this.repTabForm.patchValue({
          'representative': null
        });
      } else {
        this.repTabForm.patchValue({
          'company': evt.entityName
        });
        this.setRepTabDetails('', type, evt.entityName);
      }
    }
  }

  public getPartyIdDetails(id, type?, companyName?): void {
    if (type === 'company') {
      this.setRepTabDetails('', type, companyName);
    } else {
      this.talentService.getPartyDetails(id).subscribe(
        (res) => {
          this.partyDetails = res;
          this.repTabForm.reset();
          this.setRepTabDetails(this.partyDetails, type, '');
        });
    }
  }

  public setRepTabDetails(details, type, companyName): void {
    this.contactDetails = null;
    this.getPrimaryContact();
    this.repTabForm.patchValue({
      occupation: this.getOccupation(details) ? {
        value: this.getOccupation(details).code,
        id: this.getOccupation(details).codeId
      } : null,
      phoneType: this.contactDetails ?
        {
          value: this.contactDetails.partyContactType && this.contactDetails.partyContactType.code ?
            this.contactDetails.partyContactType.code : null,
          id: this.contactDetails.partyContactType && this.contactDetails.partyContactType.codeId ?
            this.contactDetails.partyContactType.codeId : null
        }
        : null,
      phoneNumber: this.contactDetails ? this.contactDetails.contact.address.value : null,
      primary: details.partyRole ? details.partyRole.primary : '',
    });
    if (type === 'representative') {
      let company = null;
      if (details.roles && details.roles.EMPLOYEE.length) {
        if (details.roles.EMPLOYEE.find(emp => emp.partyRole.primary)) {
          let primaryCompany = details.roles.EMPLOYEE.filter(emp => emp.partyRole.primary);
          // company = details.roles.EMPLOYEE.find(emp => emp.partyRole.primary);
          company = primaryCompany[primaryCompany.length - 1];
        } else {
          company = details.roles.EMPLOYEE[details.roles.EMPLOYEE.length - 1];
        }
      }
      this.repTabForm.patchValue({
        repId: details.id,
        first: details.names.PRIMARY[0].name.first,
        entity: details.names.PRIMARY[0].name.entity,
        representative: details.names.PRIMARY[0].name.fullName,
        company: company ? company.names && company.names.PRIMARY[0].name.fullName : '',
        companyPartyId: company ? company.id : ''
      });

      this.representative.typeAheadField.nativeElement.value = details.names.PRIMARY[0].name.fullName;
      this.company.typeAheadField.nativeElement.value = company ? company.names && company.names.PRIMARY[0].name.fullName : '';
    } else {
      const request = {
        company: companyName,
        companyPartyId: this.companyPartyId
      };
      if (this.partyId) {
        request['repId'] = this.partyId;
      }
      this.repTabForm.patchValue(request);
      setTimeout(() => {
        this.company.typeAheadField.nativeElement.value = companyName ? companyName : '';
      }, 200);

    }

  }

  onSelectOccupationEvent(selectedItem, formControl) {
    this.repTabForm.get(formControl).setValue(selectedItem);
  }

  public getPrimaryContact(): void {
    if (this.partyDetails && this.partyDetails.contacts && this.partyDetails.contacts.PHONE) {
      this.partyDetails.contacts.PHONE.forEach(element => {
        if (element.qualifierType && element.qualifierType.code === 'PRIMARY') {
          this.contactDetails = element;
        }
      });
    }
  }

  public getOccupation(details): any {
    if (details && details.partyInfo && details.partyInfo.professionalInfo
      && details.partyInfo.professionalInfo.occupations.length > 0 &&
      details.partyInfo.professionalInfo.occupations[0].occupationName.code) {
      return details.partyInfo.professionalInfo.occupations[0].occupationName;
    } else {
      return '';
    }
  }

  public getRepTypeList(): void {
    this.talentService.getRepType().subscribe(res => {
      this.type = new DropdownModel('', '', '', '', res['picklists']['REP_TYPE'].sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      }));
    }, (err) => {
    });
  }

  public getPhoneTypeList(): void {
    this.talentService.getRepPhoneType().subscribe(res => {
      this.contactTypeList = res;
      this.phoneType = new DropdownModel('', '', '', '', this.contactTypeList.picklists.sort((a, b) => {
        const nameA = a.value.toLowerCase();
        const nameB = b.value.toLowerCase();
        if (nameA < nameB) { return -1; }
        if (nameA > nameB) { return 1; }
        return 0;
      }));
      this.serviceRes = true;
    });
  }

  getPrimaryCompany(companyDetails) {
    let primaryComp = null;
    let comp;
    if (companyDetails.roles && companyDetails.roles.EMPLOYEE.length) {
      if (companyDetails.roles.EMPLOYEE.find(emp => emp.partyRole.primary)) {
        let primaryCompany = companyDetails.roles.EMPLOYEE.filter(emp => emp.partyRole.primary);
        comp = primaryCompany[primaryCompany.length - 1];
      } else {
        comp = companyDetails.roles.EMPLOYEE[companyDetails.roles.EMPLOYEE.length - 1];
      }
    }
    primaryComp = comp ? comp.names && comp.names.PRIMARY[0].name.fullName : ''
    return primaryComp;
  }

  valueReset(){
    this.typeAheadValue = null;
    this.newSelectedCompany = null;
    this.typeAheadValueCompany = null;
  }

  public addRepresentative(): void {
    let comp = null;
    let rep = null;
    if (this.typeAheadValue) {
      rep = this.typeAheadValue;
    }
    else {
      rep = this.partyDetails && this.partyDetails.names && this.partyDetails.names.PRIMARY[0] && this.partyDetails.names.PRIMARY[0].name && this.partyDetails.names.PRIMARY[0].name.fullName;
    }

    if (this.newSelectedCompany) {
      comp = this.newSelectedCompany;
    }
    else if (this.typeAheadValueCompany) {
      comp = this.typeAheadValueCompany;
    }
    else {
      if (this.partyDetails) {
        comp = this.getPrimaryCompany(this.partyDetails);
        if (comp) {
          if (this.repTabForm.value.company == "" || this.repTabForm.value.company == null) {
            comp = this.repTabForm.value.company;
          }
        }
      }

    }
    if (this.repTabForm.value.representative === rep && this.repTabForm.value.company === comp) {
      if (this.repTabForm.value) {
        const itemAdded = this.repTabForm.value;
        this.repdataModel = new AddRepresentativeModel();
        this.repdataModel.partyId = itemAdded.repId;
        this.repdataModel.firstName = itemAdded.first;
        this.repdataModel.lastName = itemAdded.entity;

        const phone = new Phone();
        phone.value = itemAdded.phoneNumber !== undefined ? itemAdded.phoneNumber : null;

        if (itemAdded.phoneType && itemAdded.phoneType.id) {
          phone.typeId = itemAdded.phoneType.id;
        }

        if (phone.typeId) {
          this.repdataModel.phone.push(phone);
        } else {
          this.repdataModel.phone = null;
        }
        const occupation = new Occupation();
        occupation.occupationName = itemAdded.occupation && itemAdded.occupation.value !== undefined ? itemAdded.occupation.value : null;
        if (itemAdded.occupation && itemAdded.occupation.id) {
          occupation.occupationId = itemAdded.occupation.id;
        }

        if (occupation.occupationId) {
          this.repdataModel.occupations.push(occupation);
        } else {
          this.repdataModel.occupations = null;
        }


        const companies = new Companies();
        if (itemAdded.companyPartyId) {
          companies.companyName = itemAdded.company;
          companies.partyId = itemAdded.companyPartyId;
          this.repdataModel.companies.push(companies);
        } else {
          this.repdataModel.companies = null;
        }
        if (itemAdded.repId !== null) {
          this.talentService.addPersontoRollCallfromTalent(this.repdataModel).subscribe(res => {
          });
          const repDuplicated = this.repItemAdded.find(rep => rep.repId === itemAdded.repId);
          if (!repDuplicated) {
            this.repItemAdded.push(itemAdded);
            this.persistRepresentationList();
            this.componentUpdate = true;
            this.repTabForm.reset();

          } else {
            this.repDuplicated = 'Duplicate Rep';

          }
        }
      }
    }
    else {
      if (this.repTabForm.value.representative == null || this.repTabForm.value.representative == '') {
        this.repDuplicated = 'Rep is required';
      } else {
        this.repDuplicated = 'Rep Incorrect';
      }

    }
    this.typeAheadValue = null;
    this.typeAheadValueCompany = null;
    this.newSelectedCompany = null;
  }

  /** Delete the relation Between RollCall and Talent */
  public onDelete(index, data): void {
    this.repItemAdded.splice(index, 1);
    this.componentUpdate = true;
    this.persistRepresentationList();
    this.repTabFormList.markAsDirty();
    this.repTabFormList.markAsTouched();
  }

  editOpenModal(data, i) {
    this.currentIndex = i;
    this.talentService.getRepDetails(data.repId).subscribe(
      (res) => {
        this.openModal({ res });
      });

  }

  public openModal(evt): void {
    if ((evt && evt.res) || (evt && evt.res && evt.event === 'personType')) {
      this.repPersonName = evt.res;
      this.isRepEdit = true;
      this.isCompanyEdit = false;
      this.showCompanyModal = false;
    } else {
      this.isRepEdit = false;
      this.isCompanyEdit = true;
      this.showCompanyModal = true;
    }

    this.talentRepModal.open();
  }

  private setRepListEdit(list: any): void {
    this.repItemAdded = [];
    list.forEach(element => {

      this.talentService.getPartyDetails(element.id).subscribe(
        (res) => {
          const repModel: AddRepFormModel = new AddRepFormModel();
          repModel.repId = element.id;
          if (element.names) {
            repModel.representative = element.names.PRIMARY[0].name.fullName;
            repModel.entity = element.names.PRIMARY[0].name.entity;
            repModel.first = element.names.PRIMARY[0].name.first != null ? element.names.PRIMARY[0].name.first : '';
          }

          if (element.roles) {
            if (element.roles.EMPLOYEE.find(emp => emp.partyRole.primary)){
              let primaryCompany = element.roles.EMPLOYEE.filter(emp => emp.partyRole.primary);
              let company = primaryCompany[primaryCompany.length - 1];
              repModel.company = company ? company.names && company.names.PRIMARY[0].name.fullName : '';
            }else{
              repModel.company = element.roles.EMPLOYEE[element.roles.EMPLOYEE.length - 1].names.PRIMARY[0].name.fullName;
            }
            
          }

          repModel.primary = element.partyRole.primary;
          repModel.occupation = {
            value: element.occupationWithParent ? element.occupationWithParent.code : null,
            id: element.occupationWithParent ? element.occupationWithParent.codeId : null
          };
          if (res.contacts) {
            repModel.phoneNumber = res.contacts.PHONE ? res.contacts.PHONE[0].contact.address.value : '';
            repModel.phoneType = { value: res.contacts.PHONE ? res.contacts.PHONE[0].partyContactType.code : '', id: null };
          }
          this.repItemAdded.push(repModel);
          this.persistRepresentationList();
        });
    });
  }

  // for soft save
  private persistRepresentationList(): void {
    this.talentPersistService.setRepresentationListData(this.repItemAdded);
  }

  /**
   * Function to mark as primary a rep row
   * @param index Position ro without primary checkbox has marked as primary
   */
  public makeAsPrimary(index: number): any {
    this.componentUpdate = true;

    this.repItemAdded[index].primary = !this.repItemAdded[index].primary;
    this.repTabFormList.markAsDirty();
    this.repTabFormList.markAsTouched();
    this.persistRepresentationList();
  }

  saveTypeaheahModal(isEditMode) {
    const vals = this.addRepCompanyModal.addCompanyForm.value;
    vals['typeAheadCurrentName'] = this.addRepCompanyModal.selectedTypeAheadRecord || {};
    if (!vals.aliasCheckbox) {
      this.saveCompanyModal(vals, isEditMode);
    } else {
      this.saveAliasCompanyFunc(vals, isEditMode);
    }
  }

  public saveCompanyModal(cName, edit): void {
    const companyName: TypeAheadSaveModel = new TypeAheadSaveModel();
    companyName.name.entity = cName.companyName;
    companyName.partyType = 'COMPANY';
    companyName.createdBy = 'Melissa Tapie';
    companyName.updatedBy = 'Melissa Tapie';
    companyName.partyId = null;
    this.talentService.save(JSON.stringify(companyName)).subscribe(
      (res) => {
        this.addRepCompanyModal.successCB(res);
        if (this.isCompanyEdit) {
          this.getCreateEditCompany({ res: res, event: 'companyEdit' }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addRepCompanyModal.failureCB(errMessage);
      }
    );
  }

  getCreateEditCompany(res, isEditMode) {
    this.talentService.getCompanyDetails(res.res.partyId).subscribe((data) => {
      if (isEditMode) {
        this.companyDetails = { companyId: res.res.partyId, companyName: this.companyName };
        setTimeout(() => {
          this.openModal({ data, event: res.event });
        }, 200);
      }
    });
  }

  public saveAliasCompanyFunc(cName, edit) {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();
    aliasParty.partyType = 'COMPANY';
    aliasParty.displayName = cName.typeAheadCompany;
    aliasParty.name.entity = cName.typeAheadCompany;
    aliasParty.partyId = (this.addRepCompanyModal.selectedTypeAheadRecord) ? this.addRepCompanyModal.selectedTypeAheadRecord.partyId : null;
    AKA.name.entity = EmptyIfNull.check(cName.aliasCompanyName);
    this.talentService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        this.addRepCompanyModal.successCB(res);
        if (this.isCompanyEdit) {
          this.getCreateEditCompany({ res: res, event: 'companyEdit' }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addRepCompanyModal.failureCB(errMessage);
      }
    );
  }

  onCompanyEdit() {
    this.isCompanyEdit = true;
    this.companyName = this.addRepCompanyModal.addCompanyForm.value.companyName;
    this.saveTypeaheahModal(true);
  }

  public saveNameTalentEvent(evt: TypeAheadModel): void {
    if (evt['typeAheadId'] === 'personType') {
      this.typeAheadValue = this.getFullName(evt['nameAdded']);

      if (this.repTabForm.value) {
        this.repDuplicated = '';
        this.repTabForm.reset();
      }
      this.repTabForm.patchValue({
        repId: evt['nameAdded'].partyId,
        representative: this.typeAheadValue
      });
      this.representative.typeAheadField.nativeElement.value = this.typeAheadValue;
    }

  }

  public saveCompanyNameEvent(evt: TypeAheadModel): void {
    this.typeAheadValueCompany = evt['nameAdded'].typeAheadDisplayName;

    this.repTabForm.patchValue({
      companyPartyId: evt['nameAdded'].partyId,
      company: evt['nameAdded'].typeAheadDisplayName
    });
    this.company.typeAheadField.nativeElement.value = this.typeAheadValueCompany;
  }

  getFullName(item) {
    let name = '';
    name = !this.isEmpty(item.firstName) ? (item.firstName + ' ') : '';
    name = name + (!this.isEmpty(item.middleName) ? (item.middleName + ' ') : '');
    name = name + (!this.isEmpty(item.entityName) ? item.entityName : '');
    name = name + (!this.isEmpty(item.suffix) ? ', ' + item.suffix : '');
    return name;
  }

  isEmpty(str: string) {
    if (str === '' || str === null || str === undefined) {
      return true;
    }
    return false;
  }

  onCompanySaved(event) {
    this.addRepCompanyModal.addCompanyForm.markAsPristine();
    this.isCompanyEdit = false;
    this.showCompanyModal = false;
    this.talentRepModal.close();
    this.closeModalPopup();
    this.repTabForm.patchValue({
      companyPartyId: event.partyId
    });
  }

  onCompanyCancel(event) {
    this.isCompanyEdit = false;
    this.showCompanyModal = false;
    this.talentRepModal.close();
    this.closeModalPopup();
  }

  onPersonSaved(event) {
    if (this.currentIndex !== null && this.currentIndex !== undefined) {
      const item = this.formatGridEditResponse(event.res);
      this.repItemAdded[this.currentIndex] = item;
      this.currentIndex = null;
      this.repTabForm.patchValue({
        repId: event.res.partyId,
      });
      this.isRepEdit = false;
      this.talentRepModal.close();
      this.closeModalPopup();
    }
    else {
      // this.getPartyIdDetails(event.res.partyId, 'respresentative');
      const item: any = this.formatGridEditResponse(event.res);
      if(item.company === ""){
        this.typeAheadValueCompany = null;
      }
      else{
        this.typeAheadValueCompany = item.company;
      }
      this.representative.typeAheadField.nativeElement.value = this.typeAheadValue;
      this.repTabForm.patchValue({
        repId: event.res.partyId,
        company: this.typeAheadValueCompany,
        phoneType: (item.phoneType && item.phoneType.value && item.phoneType.id) ? {
          value: item.phoneType && item.phoneType.value ? item.phoneType.value : null,
          id: item.phoneType && item.phoneType.id ? item.phoneType.id : null
        } : null,
        phoneNumber: item.phoneNumber ? item.phoneNumber : null,
        occupation: (item.occupation && item.occupation.value &&  item.occupation.id) ? {
          value: item.occupation && item.occupation.value ? item.occupation.value : null,
          id: item.occupation && item.occupation.id ? item.occupation.id : null
        } : null
      });
      this.company.typeAheadField.nativeElement.value = this.typeAheadValueCompany;
      this.isRepEdit = false;
      this.talentRepModal.close();
      this.closeModalPopup();
    }
  }
  // closing the popup forcefully, since in some browser the object of the popup is not completely released.
  closeModalPopup() {
    if (!this.skipEvents) {
      var element = document.getElementsByTagName("ngb-modal-backdrop"), index;
      for (index = element.length - 1; index >= 0; index--) {
        element[index].parentNode.removeChild(element[index]);
      }
      var element = document.getElementsByTagName("ngb-modal-window"), index;
      for (index = element.length - 1; index >= 0; index--) {
        element[index].parentNode.removeChild(element[index]);
      }
    }
  }

  onPersonCancel(event) {
    this.isRepEdit = false;
    this.talentRepModal.close();
    this.closeModalPopup();
  }

  formatGridEditResponse(res) {
    const { companies, occupations, lastName, firstName } = res;
    const tempItem = new AddRepFormModel();
    const phone = this.getPhoneObject(res.phone);
    tempItem.company = this.getRepCompanies(companies);
    tempItem.entity = lastName;
    tempItem.first = firstName;
    if (occupations && occupations.length > 0) {
      tempItem.occupation = { value: occupations[occupations.length - 1].occupationName, id: occupations[occupations.length - 1].occupationId };
    }

    tempItem.phoneNumber = phone.value;
    tempItem.phoneType = { value: phone.type, id: phone.id };
    if (this.currentIndex) {
      tempItem.primary = this.repItemAdded[this.currentIndex].primary;
    }

    tempItem.repId = res.partyId;
    let name = lastName;
    if (firstName) {
      name = `${firstName} ` + name;
    }
    tempItem.representative = name;

    return tempItem;
  }

  getRepCompanies(data) {
    let company = '';
    if (data) {
      data.forEach(element => {
        if (element.primary) {
          company = element.companyName;
        }
      });
    }

    return company;
  }

  getPhoneObject(data) {
    let phone = {
      value: '',
      id: '',
      type: ''
    };
    if (data) {
      data.forEach(element => {
        if (element.primary) {
          phone = element;
        }
      });
    }

    return phone;
  }

  onContactEdit(event: TypeAheadModel) {
    this.repPersonName = this.addRepModal.addTalentForm.value.editableFields;
    this.saveTypeaheahPersonModal(true);
  }

  saveTypeaheahPersonModal(isEditMode?: boolean) {
    const vals = this.addRepModal.addTalentForm.value;
    if (!vals.aliasCheckbox) {
      this.saveRepModal(vals, isEditMode);
    } else {
      this.saveRepAliasModal(vals, isEditMode);
    }
  }

  private saveRepModal(vals, isEditMode): void {
    const tName: TypeAheadSaveModel = new TypeAheadSaveModel();
    tName.partyId = null;
    tName.name.entity = vals.editableFields.entityName;
    tName.name.first = vals.editableFields.firstName;

    tName.partyType = 'CONTACT';
    tName.name.middle = vals.editableFields.middleName;
    tName.name.suffix = vals.editableFields.suffix;
    tName.displayName = this.createDisplayName(vals);
    tName.createdBy = 'Melissa Tapie';
    tName.updatedBy = 'Melissa Tapie';

    this.talentService.save(JSON.stringify(tName)).subscribe(
      (partySaved: any) => {
        this.addRepModal.successCB(partySaved);
        if (isEditMode) {
          this.getCreateEditDetails({ res: partySaved, event: 'onContactEdit' }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addRepModal.failureCB(errMessage);
      }
    );
  }

  private saveRepAliasModal(vals, isEditMode): void {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();

    aliasParty.partyType = 'CONTACT';
    aliasParty.partyId = (this.addRepModal.selectedTypeAheadRecord) ? this.addRepModal.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.first = EmptyIfNull.check(vals.editableFields.firstName);
    aliasParty.name.middle = EmptyIfNull.check(vals.editableFields.middleName);
    aliasParty.name.entity = EmptyIfNull.check(vals.editableFields.entityName);
    aliasParty.name.suffix = EmptyIfNull.check(vals.editableFields.suffix);
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(vals));

    AKA.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    AKA.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    AKA.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    AKA.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    this.talentService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
      (partySaved) => {
        this.addRepModal.successCB(partySaved);
        if (isEditMode) {
          this.getCreateEditDetails({ res: partySaved, event: 'onContactEditAlias' }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addRepModal.failureCB(errMessage);
      }
    );
  }

  getCreateEditDetails(partySaved, isEditMode) {
    this.talentService.getRepDetails(partySaved.res.partyId).subscribe(
      (res) => {
        if (isEditMode) {
          setTimeout(() => {
            this.openModal({ res, event: 'personType' });
          }, 200);
        }
      });
  }

  private createDisplayName(vals: any): string {
    return vals.editableFields.entityName + ', ' +
      vals.editableFields.suffix + ', ' +
      vals.editableFields.firstName + ' ' +
      vals.editableFields.middleName;
  }

  public saveAlias(event) {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const vals = this.addRepModal.addTalentForm.value;
    const valEditFields = {
      editableFields: {
        firstName: vals.editableFields && vals.editableFields.firstName ? vals.editableFields.firstName :
          this.addRepModal.addTalentForm.get('editableFields.firstName').value,
        entityName: vals.editableFields && vals.editableFields.entityName ? vals.editableFields.entityName :
          this.addRepModal.addTalentForm.get('editableFields.entityName').value,
        middleName: vals.editableFields && vals.editableFields.middleName ? vals.editableFields.middleName :
          this.addRepModal.addTalentForm.get('editableFields.middleName').value,
        suffix: vals.editableFields && vals.editableFields.suffix ? vals.editableFields.suffix :
          this.addRepModal.addTalentForm.get('editableFields.suffix').value,
      }

    };
    aliasParty.partyType = 'CONTACT';
    aliasParty.partyId = (this.addRepModal.selectedTypeAheadRecord) ? this.addRepModal.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.first = EmptyIfNull.check(valEditFields.editableFields.firstName);
    aliasParty.name.middle = EmptyIfNull.check(valEditFields.editableFields.middleName);
    aliasParty.name.entity = EmptyIfNull.check(valEditFields.editableFields.entityName);
    aliasParty.name.suffix = EmptyIfNull.check(valEditFields.editableFields.suffix);
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(valEditFields));

    const AKA: AddAliasAKAModel = new AddAliasAKAModel();
    AKA.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    AKA.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    AKA.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    AKA.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    this.talentService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        this.addRepModal.successCBAlias(res);
      },
      (err) => {
        const errCode: string = err.error.errors[0].code;
        let message: string = 'Error, Alias did not save';
        if (errCode === 'aka.already.exist') {
          const partyName = EmptyIfNull.check(aliasParty.name.first)
            + ' ' + EmptyIfNull.check(aliasParty.name.middle)
            + ' ' + EmptyIfNull.check(aliasParty.name.entity)
            + ' ' + EmptyIfNull.check(aliasParty.name.suffix);
          message = 'Alias "' + AKA.name.entity.trim() + '" for party "' + partyName.trim() + '" already exists!';
        }
        if (errCode === 'data.already.exist') {
          message = err.error.errors[0].detail;
          this.addRepModal.failureCBAlias(message);
        }
      }
    );
  }

  /**
 * Method to check backspace (evt.keyCode = 8) in Firefox, this is to ignore the space char on back space
 */
  public phoneKeydown(evt) {
    let numIndexBeforeSpace = 3;
    const newPhoneNo = this.repTabForm.get("phoneNumber") ? this.repTabForm.get("phoneNumber").value : null;
    if (evt.keyCode === 8 && evt.target.selectionStart
      && navigator.userAgent.indexOf("Firefox") > -1 && newPhoneNo
      && newPhoneNo.length === numIndexBeforeSpace && this.phoneKeydownCount === 0) {
      evt.target.setSelectionRange(5, 5);
      evt.target.focus();
      this.phoneKeydownCount++;
    }
    //Reset keydownCount based on the length of entered phone number
    if (newPhoneNo && newPhoneNo.length !== numIndexBeforeSpace) {
      this.phoneKeydownCount = 0;
    }
  }

}
