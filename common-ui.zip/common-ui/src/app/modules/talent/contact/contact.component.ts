import { AddAliasModel } from './../../../models/type-ahead/aka/add-alias.model';
import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, AbstractControl, Validators } from '@angular/forms';
import { AddContactModel } from './../../../models/talent/contact/add-contact.model';
import { GuardianModel } from './../../../models/talent/contact/guardian.model';
import { AddButtonModel } from './../../../models/button/add-button/add-button.model';
import { TypeAheadDisplayResultModel } from './../../../models/type-ahead/type-ahead-display-result.model';
import { TypeAheadModel } from './../../../models/type-ahead/type-ahead.model';
import { PeopleInputParamsModel } from './../../../models/people/people-input-params.model';
import { ModalGenericComponent } from './../../../modal/generic/modal-generic.component';
import { TypeAheadSaveModel } from './../../../models/type-ahead/type-ahead-save.model';
import { AddAliasAKAModel } from './../../../models/type-ahead/aka/add-alias-aka.model';
import { EmptyIfNull } from './../../../utils/strings/empty-if-null';
import { TalentPersistService } from './../../../services/persist/talent-persist.service';
import { ITalentEvents } from './../../../interfaces/italent-events';
import { TypeAheadMetaData } from '../../../enums/entity/type-ahead-metadata.enum';

@Component({
  selector: 'c2c-talent-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  public contactTitle: string;
  public formTypeAhead: FormGroup;
  public guardianForm: FormGroup;
  public contact: any;
  public talent: any;
  public fullName: any;
  private _hideFields: boolean = false;

  public talentAsGuardianErrorMessage: string = 'Parent/Guardian cannot be the Talent';
  public guardianFormHasErrors: boolean;
  public guardianAlreadyExists: boolean;
  public guardianAlreadyExistsErrorMessage: string = 'Parent/Guardian already exists in list';
  public addingTalentAsGuardian: boolean;
  public relationMaxCharReached: boolean;
  public relationMaxCharMessage: string = 'Must be 100 characters or less';

  public typeAheadDataService: any;
  public addGuardianButton: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Guardian');
  public typeAheadTitle: string = 'Type Name to search and press Enter';
  public guardianTypeAheadTitle: string = 'NAME';
  public minorTitle: string = 'MINOR - Additional Information Required';
  public addContactButton: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Contact');
  public guardianList: Array<GuardianModel> = [];
  public typeAheadValue: string;
  public typeAheadParentValue: string;
  public peopleParamModel: PeopleInputParamsModel;
  public Edit: boolean = false;
  public isMinorEdit: boolean = false;
  public contactName: any;
  public createEditRepId: any;
  public dataSet: any;
  public talentIsMinor: boolean;
  public currentIndex: any;
  public showHideTitle: boolean;
  @ViewChild('contactTypeAhead') contactTypeAhead: any;

  @ViewChild('createEditContact') createEditContact: ModalGenericComponent;
  @ViewChild('addRepModal') addRepModal: any;
  @ViewChild('addRepGuardianModal') addRepGuardianModal: any;

  @Input() talentService: ITalentEvents;
  @Input() public skipEvents: boolean = false;

  @Input() disableTab: boolean;
  @Output() disableTabChange: EventEmitter<boolean> = new EventEmitter();

  @Input()
  set disableForm(val: boolean) {

    setTimeout(() => {
      if (this.formTypeAhead) {
        (val) ? this.formTypeAhead.disable() : this.formTypeAhead.enable();
      }
    }, 100);

    setTimeout(() => {
      if (this.guardianForm) {
        (val) ? this.guardianForm.disable() : this.guardianForm.enable();
      }
    }, 100);

  }

  @Input()
  set cleanForm(remove: boolean) {
    if (remove) {
      this.contact = new AddContactModel();
    }
  }

  @Input()
  set activeTabChanged(val: string) {
    if (val && val.toUpperCase() === 'CONTACT') {
      this.activeTabIsContact();
    }
  }

  private _guardianList: any;
  @Input()
  set guardianListEdit(list: any) {
    this._guardianList = list;
    if (this._guardianList) {
      this.setFieldsValues();
    }
    else {
      this.showHideTitle = true;
    }
  }
  get guardianListEdit(): any {
    return this._guardianList;
  }

  private _contactId: number;
  @Input()
  set contactId(id: number) {
    this._contactId = id;
    if (this._contactId) {
      this.getPersonDetails(this._contactId);
    }
  }
  get contactId(): number {
    return this._contactId;
  }

  @Input()
  set hideFields(hide: boolean) {
    this._hideFields = hide;
  }
  @Output() onFocusContactTab: EventEmitter<any> = new EventEmitter<any>();

  get hideFields(): boolean {
    return this._hideFields;
  }

  constructor(private talentPersistService: TalentPersistService) { }

  public displayDataResults: TypeAheadDisplayResultModel;
  public typeAheadModalConfigContact: any;
  public typeAheadModalConfigContactGuardian: any;

  public accentedModalName = 'talentAccentedModalContact';

  ngOnInit() {
    this.initTypeahead();
    this.contact = new AddContactModel();

    this.formTypeAhead = new FormGroup({
      contactTypeAheadCtrl: new FormControl('')
    });

    this.guardianForm = new FormGroup({
      guardianTypeAhead: new FormControl('', [
        Validators.required,
        this.talentIsGuardianValidator.bind(this),
        this.guardianExistsValidator.bind(this)]),
      relation: new FormControl('', [
        Validators.required,
        this.maxLengthValidator
      ])
    });

    this.onChange();
    this.getMetaDataForContact();
  }

  getMetaDataForContact() {
    this.talentService.getMetaDataFields('CONTACT').subscribe(response => {
      this.displayDataResults.metaDataColumns['default'] = [TypeAheadMetaData[response[response.length - 2]], TypeAheadMetaData[response[response.length - 1]]];

    });
  }

  private initTypeahead() {
    this.displayDataResults = {
      filterType: 'TALENT_CONTACT',
      context: 'CONTACT',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`',
        // notAllColumnsRequired: true
      },
      // checkTeam: true,
      defaultMetadataResults: true,
      metaDataColumns: {},
      // metaDataColumns: {
      //   BUSINESS_CREATIVE: ['occupation', 'agency'],
      //   PRODUCTION: ['occupation', 'ssnEndChars'],
      //   CASTING: ['agency', 'ssnEndChars'],
      //   default: ['occupation', 'ssnEndChars']
      // },
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.talentService,
        get: 'getContactOnly'
      }
    };

    this.typeAheadModalConfigContact = {
      title: 'Add New Contact name',
      label: 'This is a label',
      showAddAlias: false,
      displayNameAs: true,
      additionalFieldsDisplayed: true,
      modalName: 'modalContactName',
      service: {
        serviceClass: this.talentService,
        serviceSave: 'saveContact'
      },
      typeAheadId: 'contactType'
    };

    this.typeAheadModalConfigContactGuardian = {
      title: 'Add New Parent/Guardian name',
      label: 'This is a label',
      showAddAlias: false,
      displayNameAs: true,
      additionalFieldsDisplayed: true,
      modalName: 'modalContactName',
      service: {
        serviceClass: this.talentService,
        serviceSave: 'saveContact'
      },
      typeAheadId: 'parentType'
    };
  }

  private onChange(): void {
    const typeAheadContact: AbstractControl = this.formTypeAhead.get('contactTypeAheadCtrl');

    typeAheadContact.valueChanges.subscribe(val => {
      if (!val) {
        typeAheadContact.markAsPristine();
        typeAheadContact.markAsUntouched();
      }
    });
  }

  private activeTabIsContact(): void {
    const personalTabData: any = this.talentPersistService.getPersonalTabData();
    if (personalTabData.dob) {
      const birthdate: Date = new Date(personalTabData.dob);
      const timeDiff = Math.abs(Date.now() - birthdate.getTime());
      const age: number = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365.25);
      this.talentIsMinor = age < 18;
    }
  }


  public selectGuardianRecord(evt: any): void {
    const partyId = evt.partyId;
    this.isMinorEdit = true;
  }

  private maxLengthValidator(control: FormControl): object {
    const val: any = control.value;
    if (val && val.length >= 100) {
      return { maxLengthReached: true };
    } else {
      return null;
    }
  }

  private talentIsGuardianValidator(control: FormControl): object {
    const val: FormControl = control.value;
    const talent: any = this.talentPersistService.getCurrentTalent();

    if (val && typeof val === 'object' && val.constructor === Object) {
      if (val.hasOwnProperty('partyId')) {
        if (talent && talent.partyId === val['partyId']) {
          return { talentIsGuardian: true };
        }
      }
    }
    return null;
  }

  private guardianExistsValidator(control: FormControl): object {
    const val: FormControl = control.value;
    if (this.guardianList.length > 0) {
      if (val && typeof val === 'object' && val.constructor === Object) {
        for (let i: number = 0; i < this.guardianList.length; i++) {
          if (val.hasOwnProperty('partyId') && this.guardianList[i]['partyId'] === val['partyId']) {
            return { guardianAlreadyExists: true };
          }
        }
      }
      return null;
    }
  }

  public saveNameTalentEvent(evt: TypeAheadModel): void {
    if (evt['typeAheadId'] === 'contactType') {
      this.contact.directContactId = evt['nameAdded'].partyId;
      this.getPersonDetails(this.contact.directContactId);
      this.persistContact();
    } else {
      this.typeAheadParentValue = evt['nameAdded'].typeAheadDisplayName;
      this.guardianForm.get('guardianTypeAhead').setValue(evt['nameAdded']);
    }
  }

  public addGuardian(evt: Event): void {
    this.showHideTitle = false;
    this.guardianList.push({
      name: {
        entity: this.guardianForm.controls.guardianTypeAhead.value.typeAheadDisplayName ||
          this.guardianForm.controls.guardianTypeAhead.value
      },
      relation: this.guardianForm.controls.relation.value,
      partyId: this.guardianForm.controls.guardianTypeAhead.value.partyId
    });

    this.persistGuardianList();
    this.guardianForm.reset();
  }

  public removeGuardian(index: number, data: any): void {
    this.guardianList.splice(index, 1);
    if (this.guardianList.length === 0) {
      this.showHideTitle = true;
    }
    this.persistGuardianList();
    this.guardianForm.markAsDirty();
    this.guardianForm.markAsTouched();
  }
  public onFocusAddButton() {
    this.onFocusContactTab.emit();
  }

  public selectedTypeAheadRecord(evt: any): void {
    this.getPersonDetails(evt.partyId);
    this.formTypeAhead.markAsDirty();
    this.formTypeAhead.markAsTouched();
  }

  // for soft save
  private persistGuardianList(): void {
    this.talentPersistService.setContactGuardianData(this.guardianList);
  }

  private persistContact(): void {
    this.talentPersistService.setContact(this.contact);
  }

  private setFieldsValues(): void {
    this.guardianList = [];
    if (this._guardianList.length > 0) {
      this.showHideTitle = false;
    }
    this._guardianList.forEach(element => {
      const guardianModel: GuardianModel = new GuardianModel();
      guardianModel.name.entity = element.names.PRIMARY[0].name.fullName;
      guardianModel.partyId = element.id;
      guardianModel.relation = element.partyInfo.confidentialInfo.relationWithParty;
      this.guardianList.push(guardianModel);

    });
    this.persistGuardianList();
  }

  private getPersonDetails(partyId: number): void {
    this.disableTab = true;
    this.disableTabChange.emit(true);
    this.talentService.getRepDetails(partyId).subscribe(
      (res) => {
        if (!this.isMinorEdit) {
          this.contact = new AddContactModel();
          this.contact = res;
          if (this.contact && this.contact.names && this.contact.names.PRIMARY[0].name) {
            this.fullName = this.contact.names.PRIMARY[0].name.fullName;
          }
          this.contact.directContactId = partyId;
          this.persistContact();
        } else {
          this.Edit = true;
          this.isMinorEdit = false;
        }
        this.disableTab = false;
        this.disableTabChange.emit(false);
      },
      (err) => {
      });
  }

  public openGuardianModal(person, i): void {
    this.currentIndex = i;
    this.isMinorEdit = true;
    this.getCreateEditDetails(person, true);
  }

  public openEditContact() {
    const person = { res: this.contact, event: { typeAheadId: 'contactType' } };
    this.getCreateEditDetails(person, true);
  }

  public openModal(evt): void {
    this.Edit = true;
    if (!(evt && evt.res && evt.res.name && evt.res.name.entity)) {
      this.contactName = this.contact;

    } else {
      this.contactName = evt.res;
      this.createEditRepId = evt.event['typeAheadId'];
    } this.createEditContact.open();
  }

  public modalClosedEvent(event) {
    this.Edit = false;
  }

  onContactEdit(event: TypeAheadModel) {
    this.contactName = this.addRepModal.addTalentForm.value.editableFields;
    if (event['typeAheadId'] === 'parentType') {
      this.isMinorEdit = true;
    } else {
      this.isMinorEdit = false;
    }
    this.createEditRepId = event['typeAheadId'];
    this.saveTypeaheahModal(event, true);
  }

  getFullName(item) {
    let name = '';
    name = !this.isEmpty(item.firstName) ? item.firstName : '';
    name = name + ' ' + (!this.isEmpty(item.middleName) ? item.middleName : '');
    name = name + ' ' + (!this.isEmpty(item.entityName) ? item.entityName : '');
    name = name + (!this.isEmpty(item.suffix) ? ', ' + item.suffix : '');
    return name;
  }

  isEmpty(str: string) {
    if (str === '' || str === null || str === undefined) {
      return true;
    }
    return false;
  }

  onPersonSaved(event) {
    if (this.currentIndex !== null && this.currentIndex !== undefined) {
      this.guardianList[this.currentIndex].partyId = event.res.partyId;
      this.guardianList[this.currentIndex].name.entity = event.res.names.PRIMARY[0].name.fullName;
      this.currentIndex = null;
    }


    this.createEditContact.close();
    this.closeModalPopup();

    // TODO disable the sve button on the typeAheadModal
    let name = '';
    name = !this.isEmpty(event.res.firstName) ? event.res.firstName : '';
    name = name + ' ' + (!this.isEmpty(event.res.lastName) ? event.res.lastName : '');
    if (!event.targetId || event.targetId !== 'parentType') {
      this.contact = event.res;
    }
    // this.persistContact();
  }

  onPersonCancel(event) {
    this.Edit = false;
    this.createEditContact.close();
    this.closeModalPopup();
  }

  // closing the popup forcefully, since in some browser the object of the popup is not completely released.
  closeModalPopup() {
    if (!this.skipEvents) {
      var element = document.getElementsByTagName("ngb-modal-backdrop"), index;
      for (index = element.length - 1; index >= 0; index--) {
        element[index].parentNode.removeChild(element[index]);
      }
      var element = document.getElementsByTagName("ngb-modal-window"), index;
      for (index = element.length - 1; index >= 0; index--) {
        element[index].parentNode.removeChild(element[index]);
      }
    }
  }

  saveTypeaheahModal(event, isEditMode) {
    const vals = this.addRepModal.addTalentForm.value;
    if (!vals.aliasCheckbox) {
      this.saveContactModal({ ...vals, event }, isEditMode);
    } else {
      this.saveContactAliasModal({ ...vals, event }, isEditMode);
    }
  }

  private saveContactModal(vals, isEditMode): void {
    const tName: TypeAheadSaveModel = new TypeAheadSaveModel();
    tName.partyId = null;
    tName.name.entity = vals.editableFields.entityName;
    tName.name.first = vals.editableFields.firstName;

    tName.partyType = 'CONTACT';
    tName.name.middle = vals.editableFields.middleName;
    tName.name.suffix = vals.editableFields.suffix;
    tName.displayName = this.createDisplayName(vals);
    tName.createdBy = 'Melissa Tapie';
    tName.updatedBy = 'Melissa Tapie';

    this.talentService.save(JSON.stringify(tName)).subscribe(
      (partySaved: any) => {
        this.addRepModal.successCB(partySaved);
        if (isEditMode) {
          this.getCreateEditDetails({ res: partySaved, event: vals.event }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addRepModal.failureCB(errMessage);
      }
    );
  }

  private saveContactAliasModal(vals, isEditMode): void {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();

    aliasParty.partyType = 'CONTACT';
    aliasParty.partyId = (this.addRepModal.selectedTypeAheadRecord) ? this.addRepModal.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.first = EmptyIfNull.check(vals.editableFields.firstName);
    aliasParty.name.middle = EmptyIfNull.check(vals.editableFields.middleName);
    aliasParty.name.entity = EmptyIfNull.check(vals.editableFields.entityName);
    aliasParty.name.suffix = EmptyIfNull.check(vals.editableFields.suffix);
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(vals));

    AKA.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    AKA.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    AKA.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    AKA.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    this.talentService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
      (partySaved) => {
        this.addRepModal.successCB(partySaved);
        if (isEditMode) {
          this.getCreateEditDetails({ res: partySaved, event: 'aliasGuardian' }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addRepModal.failureCB(errMessage);
      }
    );
  }

  getCreateEditDetails(partySaved, isEditMode) {
    if (partySaved.res.partyId) {
      this.talentService.getRepDetails(partySaved.res.partyId).subscribe(
        (res) => {
          if (isEditMode) {
            this.openModal({ res: partySaved.res, event: partySaved.event });
          }
        });
    }
  }

  private createDisplayName(vals: any): string {
    return vals.editableFields.entityName + ', ' +
      vals.editableFields.suffix + ', ' +
      vals.editableFields.firstName + ' ' +
      vals.editableFields.middleName;
  }

  public saveAlias(event) {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const vals = this.addRepModal.addTalentForm.value;
    const valEditFields = {
      editableFields: {
        firstName: vals.editableFields && vals.editableFields.firstName ?
          vals.editableFields.firstName : this.addRepModal.addTalentForm.get('editableFields.firstName').value,
        entityName: vals.editableFields && vals.editableFields.entityName ?
          vals.editableFields.entityName : this.addRepModal.addTalentForm.get('editableFields.entityName').value,
        middleName: vals.editableFields && vals.editableFields.middleName ?
          vals.editableFields.middleName : this.addRepModal.addTalentForm.get('editableFields.middleName').value,
        suffix: vals.editableFields && vals.editableFields.suffix ?
          vals.editableFields.suffix : this.addRepModal.addTalentForm.get('editableFields.suffix').value,
      }

    };
    aliasParty.partyType = 'CONTACT';
    aliasParty.partyId = (this.addRepModal.selectedTypeAheadRecord) ? this.addRepModal.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.first = EmptyIfNull.check(valEditFields.editableFields.firstName);
    aliasParty.name.middle = EmptyIfNull.check(valEditFields.editableFields.middleName);
    aliasParty.name.entity = EmptyIfNull.check(valEditFields.editableFields.entityName);
    aliasParty.name.suffix = EmptyIfNull.check(valEditFields.editableFields.suffix);
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(valEditFields));

    const AKA: AddAliasAKAModel = new AddAliasAKAModel();
    AKA.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    AKA.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    AKA.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    AKA.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    this.talentService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        this.addRepModal.successCBAlias(res);
      },
      (err) => {
        const errCode: string = err.error.errors[0].code;
        let message: string = 'Error, Alias did not save';
        if (errCode === 'aka.already.exist') {
          const partyName = EmptyIfNull.check(aliasParty.name.first)
            + ' ' + EmptyIfNull.check(aliasParty.name.middle)
            + ' ' + EmptyIfNull.check(aliasParty.name.entity)
            + ' ' + EmptyIfNull.check(aliasParty.name.suffix);
          message = 'Alias "' + AKA.name.entity.trim() + '" for party "' + partyName.trim() + '" already exists!';
        }
        if (errCode === 'data.already.exist') {
          message = err.error.errors[0].detail;
          this.addRepModal.failureCBAlias(message);
        }
      }
    );
  }

}
