import { Component, OnInit, ViewChild, Input, Output, EventEmitter, ViewContainerRef } from '@angular/core';
import { ToastsManager } from 'ng2-toastr';
import { DropdownModel } from './../../../models/dropdown/dropdown.model';
import { CompaniesDetailModel } from './../../../models/company/data-model/companies-detail-model';
import { TypeAheadDisplayResultModel } from './../../../models/type-ahead/type-ahead-display-result.model';
import { CompanyInputParamsModel } from './../../../models/company/company-input-params.model';
import { CompanyOutputParamsModel } from './../../../models/company/company-output-params.model';
import { ToasterService } from './../../../services/toaster/toaster.service';
import { CompanyComponent } from './../../company/company.component';
import { AccentedCharacterService } from './../../../services/http/accented-character/accented-character.service';
import { TypeAheadMetaData } from '../../../enums/entity/type-ahead-metadata.enum';
import { UnsaveModalPopUp } from '../../../utils/unsave/unsave-modal';
import { UnsavedChangesService } from './../../../services/events/modal/unsaved-changes-event/unsaved-changes.service';
import { Router } from '@angular/router';

@Component({
  selector: 'c2c-create-company',
  templateUrl: './create-company.component.html',
  styleUrls: ['./create-company.component.scss'],
  providers: [AccentedCharacterService]
})
export class CreateCompanyComponent implements OnInit {
  public companyParamModel: CompanyInputParamsModel;
  public companyData: CompaniesDetailModel = new CompaniesDetailModel();
  public loading = false;
  public addServiceInitiated: boolean = false;
  public companyEntityTypes: any;
  public occupationDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public typesDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public socialmediaDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public phoneDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public selectCountryDropdown = new DropdownModel('', 'United States', '', '', []);
  public selectStateDropdown = new DropdownModel('', '', '', '', []);
  public pickListData: any;
  public companyId: number;
  public isEdit: boolean = false;
  public entityTypeValue: string;
  public validCompanyName: boolean = true;
  public displayCompanyDataResults: TypeAheadDisplayResultModel;
  public companyTypeAheadService: any;
  public navigationUrl: any
  public viewCompanyRoute: any
  public unsave: boolean = false;

  public companyName: string = '';
  private _cameFrom = '';
  @Input() public companyDetails: any;

  public talentService: any;

  @Input('talentService')
  set _talentService(service) {
    this.talentService = service;
    this.initServices();
  }

  @Output() public companySaved: EventEmitter<any> = new EventEmitter();
  @Output() public companyCancel: EventEmitter<any> = new EventEmitter();

  @ViewChild('companyComponent') companyComponent: CompanyComponent;

  constructor(private toasterService: ToasterService, private toastr: ToastsManager,
    private accentedCharacterService: AccentedCharacterService, private unsavePopup: UnsaveModalPopUp, private unsaveService: UnsavedChangesService, private router: Router, private vRef: ViewContainerRef) {
    this.toastr.setRootViewContainerRef(vRef);
    this.unsavePopup.setvalue.subscribe(res => {
      if (res.openModal) {
        console.log("Company open ---->");
        this.unsaveService.openModal();
        if (res.url.indexOf("http") >= 0) {
          this.navigationUrl = res.url;
        } else {
          this.viewCompanyRoute = res.url;
        }
      }
    });
  }

  ngOnInit() {

  }

  getMetaDataCompany() {
    this.talentService.getMetaDataFields('COMPANY').subscribe(response => {
      console.log('METADATA FIELDS FOR PEOPLE COMPANY: ', response);
      this.displayCompanyDataResults.metaDataColumns['default'] = [TypeAheadMetaData[response[response.length - 2]], TypeAheadMetaData[response[response.length - 1]]];;
    });
  }

  private initServices(): void {
    this.checkRouteParams();
    this.getDropdownLookupData();
    this.getMetaDataCompany();
    this.initTypeahead();
    this.addEditCompany();
  }

  private checkRouteParams() {
    const params = this.talentService.getRoutesParams();
    if (params) {
      if (params[0].path === 'addTalent') {
        if (this.companyDetails) {
          this.companyId = this.companyDetails.companyId;
          this.companyData.displayName = this.companyDetails.companyName;
          this.companyName = this.companyDetails.companyName;
          this._cameFrom = params[0].path;
        }
      } else {
        this.companyId = params.param;
      }
    }
  }

  private initTypeahead(): void {
    this.companyTypeAheadService = {
      serviceClass: this.talentService,
      serviceAccentedClass: this.accentedCharacterService,
      getCompanyDetails: 'getCompanyDetails',
      saveCompany: 'saveParty',
      saveCompanyAlias: 'saveAlias',
      getTalentDetails: 'getTalentDetails',
      getStateListFromDb: 'getStateListFromDb',
      getaccentedCharacters: 'getAccentedChars',
      getNames: 'getNames'
    };

    this.displayCompanyDataResults = {
      filterType: 'COMPANY_ONLY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`'
      },
      metaDataColumns: {
        BUSINESS_CREATIVE: ['occupation', 'agency'],
        PRODUCTION: ['occupation', 'ssnEndChars'],
        CASTING: ['agency', 'ssnEndChars'],
        default: ['occupation', 'ssnEndChars']
      },
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.talentService,
        get: 'getCompany'
      }
    };
  }

  private getDropdownLookupData() {
    this.occupationDropdown = this.talentService.getDropDownOptionsList('COMPANY_OCCUPATION');
    this.typesDropdown = this.talentService.getDropDownOptionsList('COMPANY_TYPE');
    this.socialmediaDropdown = this.talentService.getDropDownOptionsList('SOCIAL_MEDIA');
    this.phoneDropdown = this.talentService.getDropDownOptionsList('PHONE_TYPE');
    this.selectStateDropdown = this.talentService.getDropDownOptionsList('countrystate/STATES/US');
    this.companyEntityTypes = this.talentService.getOptionsList('COMPANY_ENTITY_TYPE');
    this.selectCountryDropdown = this.talentService.getCountryOptionsList('countrystate/COUNTRIES');
  }

  private setCompanyParams(): void {
    this.companyParamModel = new CompanyInputParamsModel(this.displayCompanyDataResults, this.companyData,
      this.companyEntityTypes, this.occupationDropdown, this.typesDropdown, this.socialmediaDropdown,
      this.phoneDropdown, this.selectCountryDropdown, this.selectStateDropdown, this.companyTypeAheadService);
  }

  private addEditCompany() {
    if (this.companyId !== null && this.companyId > 0) {
      this.isEdit = true;
      this.unsave = true;
      this.unsavePopup.setActivatePopup(this.unsave);
      const companyObj = this.talentService.getCompanyData();
      if (!companyObj) {
        this.talentService.getCompanyDetails(this.companyId.toString()).subscribe((data) => {
          this.companyData = data;
          this.entityTypeValue = this.companyData.entityTypeValue;
          this.setCompanyParams();

        });
      } else {
        this.companyData = companyObj;
        this.setCompanyParams();
      }
    } else {
      this.setCompanyParams();
      this.companyId = null;
      this.isEdit = false;
      this.entityTypeValue = 'Company';
    }
  }

  saveCompany(outParams: CompanyOutputParamsModel): void {
    if (null !== outParams && null !== outParams.companyData && outParams.validCompany !== undefined) {
      this.companyData = outParams.companyData;
      this.validCompanyName = outParams.validCompany;
      if (this.validCompanyName && !outParams.validNotes) {
        this.loading = true;
        this.companyData['updatedByApp'] = 'Talent2';
        const dataSet = this.talentService.getUserData();
        this.companyData['dataSet'] = dataSet.masterDataset;
        this.talentService.insertUpdateCompanyDetails(this.companyData).subscribe(
          (res) => {
            this.companyId = res.partyId;
            this.toasterService.success('Record Saved', 'Success!');
            this.unsave = false;
            this.unsavePopup.setActivatePopup(this.unsave);
            if (this._cameFrom === 'addTalent') {
              this.companySaved.emit(res);
              this.loading = false;
            } else if (this.isEdit) {
              setTimeout(() => {
                this.loading = false;
                this.talentService.navigatePage(`/companyDetail/${this.companyId}`);
              }, 2000);

            } else {
              setTimeout(() => {
                this.loading = false;
                this.talentService.navigatePage(`/companyDetail/${this.companyId}`);
              }, 2000);

            }
          },
          (err) => {
            this.loading = false;
            this.toasterService.error('Error on saving Company data.', 'Something Wrong');
          });
      }
    } else {
      this.validCompanyName = false;
    }
  }

  cancelEvent(outParams: CompanyOutputParamsModel): void {
    if (this.companyName) {
      this.companyCancel.emit({ outParams });
    } else {
      if (null !== outParams && null !== outParams.companyData) {
        if (this.companyId === null) {
          this.talentService.navigatePage(`/companyGrid`);
        } else if (this.companyId > 0) {
          this.talentService.navigatePage(`/companyDetail/${this.companyId}`);
        }
      }
    }

  }

  closeUnsavePopUp(evt) {
    console.log("Company Close ---->");
    if (evt) {
      if (this.navigationUrl) {
        window.location.href = this.navigationUrl;
      } else {
        this.router.navigate([this.viewCompanyRoute]);
      }
      this.unsave = false;
      this.unsavePopup.setActivatePopup(this.unsave);
    }
  }
}


