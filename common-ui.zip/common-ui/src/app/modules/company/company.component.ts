import { Component, OnInit, Input, Output, TemplateRef, ElementRef, ViewChild, EventEmitter, SimpleChanges, OnChanges } from '@angular/core';
import { CancelButtonModel } from '../../models/button/cancel-button/cancel-button.model';
import { AddButtonModel } from '../../models/button/add-button/add-button.model';
import { DropdownModel } from '../../models/dropdown/dropdown.model';
import { ModalGenericComponent } from '../../modal/generic/modal-generic.component';
import { ColumnDefModel } from '../../models/grid/column-def/column-def.model';
import { ImageUploaderModel } from '../../models/image-uploader/imageUploader.model';
import { TypeAheadService } from '../../services/http/type-ahead/type-ahead.service';

import { SocialMediaModel } from '../../models/company/data-model/social-media-model';
import { OccupationModel } from '../../models/company/data-model/occupation-model';
import { TypeModel } from '../../models/company/data-model/type-model';
import { PhoneMediaModel } from '../../models/company/data-model/phone-type-model';
import { CompaniesDetailModel } from '../../models/company/data-model/companies-detail-model';
import { CompaniesLocationsModel } from '../../models/company/data-model/company-locations-model';
import { CompanyInputParamsModel } from '../../models/company/company-input-params.model';
import { CompanyOutputParamsModel } from '../../models/company/company-output-params.model';

import { FormGroup, FormControl, AbstractControl, Validators, FormBuilder } from '@angular/forms';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { TypeAheadEventService } from '../../services/events/type-ahead/type-ahead-event.service';
import { TypeAheadDisplayResultModel } from '../../models/type-ahead/type-ahead-display-result.model';
import { GridPageOptionsModel } from '../../models/grid/grid-page-options.model';
import { GridListDefModel } from '../../models/grid/column-def/grid-list-def.model';
import { GridListParamsModel } from '../../models/grid/params/grid-list-params.model';
import { GridIconDefModel } from '../../models/grid/column-def/grid-icon-def.model';
import { GridIconParamsModel } from '../../models/grid/params/grid-icon-params.model';
import { DropdownTypeAheadModel } from '../../models/dropdown-typeahead/dropdown-typeahead.model';
import { TypeAheadSaveModel } from './../../models/type-ahead/type-ahead-save.model';
import { AddAliasModel } from './../../models/type-ahead/aka/add-alias.model';
import { EmptyIfNull } from './../../../app/utils/strings/empty-if-null';
import { AddAliasAKAModel } from './../../models/type-ahead/aka/add-alias-aka.model';
import { TypeAheadModel } from '../../models/type-ahead/type-ahead.model';

declare var $: any;

@Component({
  selector: 'c2c-company-component',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.scss'],
  providers: [TypeAheadService]
})

export class CompanyComponent implements OnInit, OnChanges {
  @ViewChild("myModal") public myModal: TemplateRef<any>;
  @ViewChild('accentedModal') accentedModal: any;
  @ViewChild('typeAheadCompanySelectorID') private typeAheadField: ElementRef;

  //@author Amit Yogi: used it to set companyName value if passed.
  @ViewChild('typeAheadCompanySelectorID') public typeAheadCompanySelectorID: any;
  @ViewChild('addNameCompanyComponentModal') addNameCompanyComponentModal: any;

  @Input() public inputParams: CompanyInputParamsModel;
  @Input() public companyNameDuplicateAlert: boolean = true;

  @Output() public cancelEvent: EventEmitter<CompanyOutputParamsModel> = new EventEmitter<CompanyOutputParamsModel>();
  @Output() public saveEvent: EventEmitter<CompanyOutputParamsModel> = new EventEmitter<CompanyOutputParamsModel>();
  @Output() public onValEdit = new EventEmitter<any>();
  public outputParams: CompanyOutputParamsModel;
  private pageEdited: boolean = true;
  public typeAheadFocus: boolean = true;
  public isAddNew: boolean = false;
  public editSelectedStateId: string;
  public editSelectedCountryId: string;

  public mask: any = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  public phoneRegExMask: any = "\+\d \(\d{3}\) \d{3}-\d{4}";

  public g: ModalGenericComponent;
  public imageUpload: ImageUploaderModel;
  public selectedImageValue: string;
  public companiesId: number;
  public isEdit: boolean = false;
  public validCompanyName: boolean = true;
  public companyTitle: string;
  public occupationDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public typesDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public socialmediaDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public socialmediaDropdownSub: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public addOccupationButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Occupation');
  public addTypeButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Type');
  public addSocialMediaButOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Social Media');
  public LocationaddButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Location');
  public cancelButtonOptions = new CancelButtonModel('', '', '', '');
  public cancelButtonLocOptions: CancelButtonModel;
  public selectedOccupation: any;
  public selectedType: any;
  public selectedSocialMediaType: any;
  public selectedSocialMediaUtlTxt: string;
  public selectedPrimaryFlag: boolean;
  public entityTypeValue: string;
  public companyForm: FormGroup;
  public companyEntityTypes: any[];
  public companyData: CompaniesDetailModel;
  public socialMediaEditMode: boolean;
  public validInputWebsite: boolean;
  public validInputSocialMediaType: boolean;
  public form: FormGroup;
  public COMPANY_ENTITY_TYPE = "COMPANY_ENTITY_TYPE";
  public COMPANY_TXT = 'Company';
  public serviceDelayLoading: boolean = true;
  public disableTypeAheadOpt: boolean = false;
  public locationAction: string = "";
  public focusFirst: boolean = true;
  notes_error_msg: boolean = false;

  // This neesd to be unique in order to open one accented modal wehn we have more than 2 type ahead in same page
  public accentedModalName = 'accentedCommonCompanyModalHeader';
  public selectedName: any;
  private talentSelected: any;
  public choosenDispName: any;
  public listOfAlias: any = [];

  /**Property to show/hide typeAhead in Talent component */
  public showTypeAhead: boolean = false;
  public rollCallModeTitle: string = '';
  public rollCallListNameResult: any;
  /**Property to show/hide addname button */
  public typeAheadAddSameName: boolean = true;
  /**Property to disable DB seaching */
  public disableSearchName: boolean = false;
  public hasNoResultsCallback: boolean = false;

  public listNameTitle: string = 'Click radio button to indicate current name';
  public typeAheadTitle = 'Type name to search and press enter';

  //Changes for Multiple Locations Add
  public gridApi;
  public typeAheadDataService: any;
  public typeAheadModalConfig: any = {
    title: 'Add New Company name',
    label: 'This is a label',
    showAddAlias: false,
    displayNameAs: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'modalRollCallCompanyName',
    hideTypeAhead: true
  };

  // Company Name TypeAhead setup
  public displayCompanyDataResults: TypeAheadDisplayResultModel = {
    filterType: 'COMPANY_ONLY',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'partyType'],
      display: '`(alias for ${data.primaryName})`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'ssnEndChars']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this.typeAheadService,
      get: 'get'
    }
  };

  public addedOccupationJson = { "occupations": [] };
  public addedTypeJson = { "types": [] };
  public addedSocialMediaJson = { "socialMedia": [] };

  //Locations Grid
  public title: string = 'Companies Details'
  public rollCallColDefs: ColumnDefModel[];
  public rollCallData: any[];
  public pageOptions: {};

  //  popup save button validation flags //
  public disableTypeAheadLoc: boolean = true;
  //--------------//

  //Locations Modal
  public selectStateDropdown = new DropdownTypeAheadModel('', '', '', '', []);
  public selectCountryDropdown = new DropdownTypeAheadModel('', 'United States', '', '', []);
  public selectedPhoneType: any;
  public selectedPhoneNumber: string;
  public selectedPrimaryFlagN: boolean;
  public addPhoneButOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Phone');
  public phoneDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public phoneDropdownSub: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public addedPhoneJson = { "phone": [] };
  public phoneJson = {
    "phone": [
      { "id": 1, "value": "work1" },
      { "id": 2, "value": "work2" }
    ]
  }
  public locationPhoneJsonFromDB = { "phone": [] };

  public selectedLocationName: string;
  public selectedAddress: string;
  public selectedAddressSecondLine: string;
  public selectedAddressThirdLine: string;
  public selectedCity: string = "";
  public selectedPostal: number;
  public selectedCountry: any = {
    value: null,
    id: null
  }

  public selectedState: any = {
    value: null,
    id: null
  }

  public selectedlocationPrimary: boolean;
  public primaryLocation: boolean = false;
  public AddLocationsList = { "locations": [] };
  public AddedLocations = { "loc": [] };
  public addedCityJson = { "cities": [] };
  public addedCountryJson = { "countries": [] };
  public PhoneEditMode: boolean = true;
  public isOpen: boolean;
  public locationsId: number;
  public locationAddressObject: object;
  public EditLocationsFlag: boolean = false;
  public EditLocationsRow: any;
  public concatinatedAddress: string;
  public validLocationName: boolean = true;
  public add: boolean = false;
  public validInputPhone: boolean = true;
  public validInputPhoneType: boolean = false;
  public isValidLoca: boolean = false;
  public addedLocationAddressArray = [];
  public existingLocationArray = [];
  public serviceLagFlag: boolean = false;
  public saveNameTalentEvn: any;
  public companyName: string = '';
  public addClearPhone: boolean = false;
  public dataSetValue: number;
  private listTalent: Array<object> = [];
  public oneTimeCall: boolean = true;
  public state: boolean = false;
  public stateCheck: boolean = false;
  public selectedCountryBuffer: string;

  editEvent = new EventEmitter(); // Edit operation in grid
  deleteEvent = new EventEmitter(); // Delete operation in grid

  public primay_location_name: string = "Primary";
  public tempCountryType: any = [];
  public empty_string = "";
  public selectedLocationIndex: number = -1;
  public phoneKeydownCount: number = 0;

  constructor(private fb: FormBuilder, private modalService: NgbModal, public typeAheadService: TypeAheadService,
    private typeAheadEventService: TypeAheadEventService) {

    if (null != this.inputParams && null != this.inputParams.companyData) {
      this.companiesId = this.inputParams.companyData.partyId;
    }

    //Changes for typeahead - START
    this.typeAheadEventService.getitemAddedToList().subscribe(item => {
      console.log("Get Item Added To List", item);
    });

    this.typeAheadEventService.getCurrentItemSelected().subscribe(item => {
      if (item.item && item.listName === 'mainListCompanyComponent') {
        this.validCompanyName = true;
        this.updateTitle(item.item);
      }
    });

    this.typeAheadEventService.getRemoveItemList().subscribe(item => {

      if (item.item && item.item.selectedItemInList) {
        this.talentSelected = {};
      }

      this.oneTimeCall = true;
      this.removeListItem(item.item, item.listName); // Remove typeAhead name

      let delindex = this.listOfAlias.findIndex(i => i.name.nameId == item.item.nameId);
      this.listOfAlias.splice(delindex, 1);
    });
  }

  private updateNames(selectedName: any, avoidNames?: boolean): void {
    if (!avoidNames) {
      this.inputParams.service.serviceClass[this.inputParams.service.getNames](selectedName.partyId).subscribe((data) => {
        this.setNames(data, selectedName);
      });
    }
  }

  private setNames(names: Array<any>, selectedName: any): void {
    this.typeAheadEventService.removeListItems('mainList');
    this.listTalent.splice(0, this.listTalent.length);
    let selectedItem: TypeAheadModel;
    names.forEach((element, index) => {
      const talentListData: TypeAheadModel = new TypeAheadModel();
      talentListData.entityName = element.name.entity;
      talentListData.firstName = element.name.first;
      talentListData.partyId = element.partyId;
      talentListData.nameId = element.name.nameId;
      talentListData.selectedItemInList = this.selectedName.typeAheadDisplayName.trim() === element.displayName.trim();
      talentListData.typeAheadDisplayName = element.displayName;
      if (talentListData.selectedItemInList === true) {
        selectedItem = talentListData;
      }
      this.updateTitle(selectedItem);
      this.listTalent.push(talentListData);
    });

    this.typeAheadEventService.listNameToLook('mainListCompanyComponent');
    this.typeAheadEventService.populateList(this.listTalent);
    this.typeAheadEventService.currentItemSelected({ item: selectedItem, listName: 'mainListCompanyComponent' });
  }

  /**
* This function removes items in list for all list
* @param item object depending what item will be remove in list
*/
  private removeListItem(item: any, listName: string): void {

    let index = -1;
    if (listName === 'mainListCompanyComponent') {
      this.listTalent.forEach((element, key) => {
        index = (index === -1 && element['partyId'] === item['partyId'] &&
          element['typeAheadDisplayName'] === item['typeAheadDisplayName']) ? key : index;
      });
      if (index > -1) {
        this.listTalent.splice(index, 1);
      }
      if (this.listTalent.length === 0) {
        this.companyData.displayName = "";
        this.imageUpload = new ImageUploaderModel("company", null);
        this.companiesId = null;
        this.addedOccupationJson.occupations = null;
        this.addedTypeJson.types = null;
        this.addedSocialMediaJson.socialMedia = null;
        setTimeout(() => {
          this.companyData = new CompaniesDetailModel(null, null, null, null, null, null, null, null, null, null,
            null, null, null, null, null, null, null, null, null, null, null, null);
          this.initialSetUp(this.companyData);
        }, 1500);
      }
    }
    this.typeAheadField['setTypeAheadFocus']();
  }


  /**
  * This function sets response from service save talent record to all fields
  *
  * @param data object selected in Status Dropdown
 */
  private setFieldsValues(data: any): void {
    // Getting data form service for talene current name
    if (this.listTalent.length === 0) {
      data.names.PRIMARY.forEach((element, index) => {
        const talentListData: TypeAheadModel = new TypeAheadModel();
        talentListData.entityName = element.name.entity;
        talentListData.firstName = element.name.first;
        talentListData.middleName = element.name.middle;
        talentListData.suffix = element.name.suffix;
        talentListData.partyId = data.id;
        talentListData.nameId = element.name.nameId;
        talentListData.selectedItemInList = true;
        talentListData.typeAheadDisplayName = element.name.fullName;
        this.listTalent.push(talentListData);
        this.selectedName = talentListData;
        this.typeAheadEventService.currentItemSelected({ item: talentListData, listName: 'mainListCompanyComponent' });
        this.updateTitle(talentListData);
      });

      // Getting data form service for talene current AKAs
      if (data.names.AKA) {
        data.names.AKA.forEach((element, index) => {
          const talentListData: TypeAheadModel = new TypeAheadModel();
          talentListData.entityName = element.name.entity;
          talentListData.firstName = element.name.first;
          talentListData.middleName = element.name.middle;
          talentListData.suffix = element.name.suffix;
          talentListData.partyId = data.id;
          talentListData.nameId = element.name.nameId;
          talentListData.selectedItemInList = false;
          talentListData.typeAheadDisplayName = element.name.fullName;
          this.listTalent.push(talentListData);
        });
      }
      // Populate talent record list with data from service response
      this.typeAheadEventService.listNameToLook('mainListCompanyComponent');
      this.typeAheadEventService.populateList(this.listTalent);
    }
  }

  public selectedCompaniesTypeAheadRecord(evt: any) {
    this.oneTimeCall = true;
    this.onPageEdit();
    this.typeAheadEventService.removeListItems('mainListCompanyComponent');
    this.saveNameTalentEvn = evt;

    this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](this.companiesId).subscribe((data) => {
      this.getAllDisplayNames(data);
      this.setFieldsValues(data['party']);
    });

    this.serviceDelayLoading = true;
    this.inputParams.service.serviceClass[this.inputParams.service.getCompanyDetails](evt.partyId).subscribe((data) => {
      this.companyData = data;
      this.serviceDelayLoading = false;
      this.companiesId = this.companyData.partyId;
      this.initialSetUp(data);
    });

  }

  //Image common component integration
  selectedImage(evt: Event) {
    if (evt == null) {
      this.companyData.deleteImage = true;
      this.onPageEdit();
    } else {
      this.selectedImageValue = evt.toString();
      var actualBase = this.selectedImageValue.substr(23);
      this.companyData.image = actualBase;
      this.companyData.deleteImage = false;
      if (this.selectedImageValue.length > 200) {
        this.onPageEdit();
      }
    }
  }

  public selectedTypeAheadRecord(evt: Event) {
    console.log('Name Search - Selected TypeAhead Record' + evt);
  }

  // Generate random number for appending it in image url to avoid cache issue
  getRandomNumber(i: number) {
    let random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    return random;
  }

  ngOnInit() {

    $(document).on("keydown", "#cancel-button", function (evt) {
      if (evt.keyCode == 13) {
        $("#cancel-button").trigger("click");
      }
    })

    if (null != this.inputParams && null != this.inputParams.companyData) {
      this.initialSetUp(this.inputParams.companyData);
    }
  }

  //Changes for Multiple Locations Add
  public onGridReady(params): void {
    this.gridApi = params.api;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (null != this.inputParams && null != this.inputParams.companyData) {
      this.initialSetUp(this.inputParams.companyData);
    }
  }

  private initialSetUp(companyDataValue: any) {
    this.companyTitle = "";
    this.selectedSocialMediaUtlTxt = "";
    this.validInputWebsite = true;
    this.validInputSocialMediaType = true;

    if (companyDataValue.dataSet != null) {
      this.dataSetValue = companyDataValue.dataSet;
    }

    this.cancelButtonLocOptions = new CancelButtonModel('rollcall', 'createEditCompanies', 'navigate');

    //Changes for Type Ahead Integration - START
    this.form = new FormGroup({
      'typeAheadSelector': new FormControl()
    });

    if (null !== this.inputParams) {
      this.displayCompanyDataResults = this.inputParams.companyTypeAheadOptions;
    }

    // Set Initial value for loading the data
    this.companyData = companyDataValue;
    this.companiesId = this.companyData.partyId;

    if (this.companiesId != null && this.oneTimeCall == true) {
      // Call this to load the typeAhead listing
      this.oneTimeCall = false;
      this.serviceDelayLoading = false;
      this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](this.companiesId).subscribe((data) => {
        this.serviceDelayLoading = false;
        this.getAllDisplayNames(data);
        this.setFieldsValues(data['party']);
      });
    }

    setTimeout(() => {
      this.serviceLagFlag = true;
      this.serviceDelayLoading = false;
    }, 2000);

    if (this.companyData == null) {
      var obj = JSON.parse(sessionStorage.getItem("COMMON_COMPANY_DATA"))
      this.companyData = obj;
    } else {
      sessionStorage.removeItem("COMMON_COMPANY_DATA");
      sessionStorage.setItem("COMMON_COMPANY_DATA", JSON.stringify(this.companyData));
    }

    this.getDropdownLookupData();
    setTimeout(() => {
      this.convertCompanyJsonToModel(companyDataValue);
      if (this.selectCountryDropdown) {
        this.tempCountryType = this.selectCountryDropdown.options;
      }
    }, 1500);

    //Select the input primary radio button as selected when there is no entry in that list
    if ((null != this.addedSocialMediaJson && null != this.addedSocialMediaJson.socialMedia &&
      this.addedSocialMediaJson.socialMedia.length == 0) || null === this.addedSocialMediaJson.socialMedia) {
      this.selectedPrimaryFlag = true;
    }

    //Locations Modal
    this.selectedPhoneNumber = "";
    this.selectedPrimaryFlagN = true;

    //Locations Grid
    this.rollCallColDefs = this.getColumnDefs();
    this.pageOptions = this.getPageOptions();
    if (this.companiesId == null) {
      this.rollCallData = [];
    }
    else {
      if (null != this.companyData) {
        if (this.companyData.locations) {
          //Set the company location to empty json if the json tag is empty and format as [{}]
          if (this.companyData.locations.length == 1 && this.companyData.locations[0]
            && Object.keys(this.companyData.locations[0]).length === 0) {
            this.companyData.locations = [];
          }

          this.rollCallData = this.companyData.locations;
          this.rollCallData.forEach((item1, ForEachindex) => {
            if (item1.name == "Corporate") {
              this.rollCallData.splice(ForEachindex, 1);
            }
            if (item1.phone != "" && item1.phone !== null && item1.phone != undefined) { // for formatted phone number.. "formatPhone" new key added .
              this.rollCallData[ForEachindex].phone.forEach((phoneItme, PhoneEachindex) => {
                var numberOfDigits = phoneItme.value.replace(/[^0-9]/g, "").length
                if (numberOfDigits < 11) {
                  this.rollCallData[ForEachindex].phone[PhoneEachindex].formatPhone = this.formatPhoneNumberNew(phoneItme.value);
                }
                else {
                  // this.rollCallData[ForEachindex].phone[PhoneEachindex].formatPhone = parseInt(phoneItme.value.replace(/[^0-9]/g, ''));
                  this.rollCallData[ForEachindex].phone[PhoneEachindex].formatPhone = phoneItme.value.replace(/[^0-9]/g, '');
                }
              });
            }
            //Set phone to empty json, if phone is 'null' or 'undefined'
            else if (!item1.phone) {
              item1.phone = [];
            }
          });
        }
      }
    }

    if (this.companiesId == null && this.isAddNew == false) {
      this.showTypeAhead = true;
      this.imageUpload = new ImageUploaderModel("company", null);
      this.isEdit = false;
      this.rollCallData = [];
    }
    else {
      if (this.companyData.imageUrl != null) {
        var finalImageURL = this.companyData.imageUrl + "?" + this.getRandomNumber(1);
        this.imageUpload = new ImageUploaderModel("company", finalImageURL);
      } else {
        if (this.isAddNew == false) {
          this.imageUpload = new ImageUploaderModel("company", null);
        }
      }
      this.isEdit = true;
    }

    if (this.companyData.imageUrl != null) {
      var finalImageURL = this.companyData.imageUrl + "?" + this.getRandomNumber(1);
      this.imageUpload = new ImageUploaderModel("company", finalImageURL);
    }
    else {
      if (this.isAddNew == false) {
        this.imageUpload = new ImageUploaderModel("company", null);
      }
    }

  }

  /** Method to add occupation
   * @param evt
   */
  public addOccupation(evt): void {
    if (evt.keyCode === 13 || evt.keyCode === undefined) {
      if (null == this.addedOccupationJson.occupations) {
        this.addedOccupationJson.occupations = [];
      }
      if (null != this.selectedOccupation && null != this.addedOccupationJson.occupations
        && !this.isContains(this.selectedOccupation, this.addedOccupationJson.occupations)) {
        let occupationModel = new OccupationModel(null, this.selectedOccupation.id, this.selectedOccupation.value, this.companiesId);
        this.addedOccupationJson.occupations.push(occupationModel);
      }
      this.selectedOccupation = null;
      this.occupationDropdown.selection = "null";
      var options = this.occupationDropdown.options;
      this.occupationDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      this.occupationDropdown.selection = "value";
      this.occupationDropdown.title = "";
      this.occupationDropdown.dropdownValue = { id: "", value: "" }
    }
  }

  private isContains(item, itemJsonList) {
    var contains = false;
    if (null != item && null != itemJsonList) {
      for (var i = 0; i < itemJsonList.length; i++) {
        if ((null != itemJsonList[i].occupationName && itemJsonList[i].occupationName == item.value)
          || (null != itemJsonList[i].name && itemJsonList[i].name == item.value)) {
          contains = true;
          break;
        }
      }
    }
    return contains;
  }

  /** Method to add type
   * @param evt
   */
  public addType(evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (null == this.addedTypeJson.types) {
        this.addedTypeJson.types = [];
      }
      if (null != this.selectedType && null != this.addedTypeJson.types
        && !this.isContains(this.selectedType, this.addedTypeJson.types)) {
        let typeModel = new TypeModel(null, this.selectedType.id, this.selectedType.value, this.companiesId);
        this.addedTypeJson.types.push(typeModel);
      }
      this.selectedType = null;
      this.typesDropdown.selection = "null";
      var options = this.typesDropdown.options;
      this.typesDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      this.typesDropdown.selection = "value";
      this.typesDropdown.title = "";
      this.typesDropdown.dropdownValue = { id: "", value: "" }
      this.onPageEdit();
    }
  }
  /** Method to add social media type
   * @param evt
   */
  public addSocialMedia(evt): void {
    //Handle input social media's validation
    var itemExists = this.addedSocialMediaJson.socialMedia.find(i => i.addedMedia.id == this.selectedSocialMediaType.id);
    if (!itemExists) {
      this.validateInputWebsiteUrl();

      if (null === this.addedSocialMediaJson.socialMedia) {
        this.addedSocialMediaJson.socialMedia = [];
      }
      if (null != this.selectedSocialMediaUtlTxt && this.selectedSocialMediaUtlTxt.length > 0
        && null != this.selectedSocialMediaType) {
        let socialMediaModel = new SocialMediaModel(null, null,
          this.selectedSocialMediaType != null ? this.selectedSocialMediaType.id : null,
          this.selectedSocialMediaType != null ? this.selectedSocialMediaType.value : null,
          this.selectedSocialMediaUtlTxt, this.selectedPrimaryFlag,
          this.selectedSocialMediaType, true, false);
        //set the other primary flags to false if current selected one is true.
        if (this.selectedPrimaryFlag == true && null != this.addedSocialMediaJson.socialMedia
          && this.addedSocialMediaJson.socialMedia.length > 0) {
          for (const itm of this.addedSocialMediaJson.socialMedia) {
            itm.primary = false;
          }
        }
        //Add newly added row into json list
        this.addedSocialMediaJson.socialMedia.push(socialMediaModel);
        //RESET input values after adding new row
        this.selectedSocialMediaUtlTxt = null;
        this.selectedSocialMediaType = null;
        this.selectedPrimaryFlag = false;
        var options = this.socialmediaDropdown.options;
        this.socialmediaDropdown = new DropdownTypeAheadModel('', '', '', '', options);
        this.socialmediaDropdown.dropdownValue = { id: "", value: "" };
        this.socialmediaDropdown.selection = "value";
        this.socialmediaDropdown.title = "";
        this.onPageEdit();
      }
    }
    else {
      var options = this.socialmediaDropdown.options;
      this.socialmediaDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      this.socialmediaDropdown.dropdownValue = { id: "", value: "" };
      this.socialmediaDropdown.selection = "value";
      this.socialmediaDropdown.title = "";
      this.selectedSocialMediaUtlTxt = null;
      this.selectedSocialMediaType = null;
    }
  }

  /** Method to get the current selected occupation
   * @param selectedVal
   */
  public onSelectOccupationEvent(selectedVal: string): void {
    this.selectedOccupation = selectedVal;
    this.onPageEdit();
  }

  /** Method to get current selected type
   * @param selectedVal
   */
  public onSelectTypeEvent(selectedVal: string): void {
    this.selectedType = selectedVal;
    this.onPageEdit();
  }

  /** Method to get current selected social media type
   * @param selectedVal
   */
  public onSelectSocialMedia(selectedVal: any): void {
    this.selectedSocialMediaType = selectedVal;
    this.onPageEdit();
  }

  /** Method to get selected social media type for selected row
   * @param selectedVal
   */
  public onSelectSocialMediaAddedRow(evt: any, sMediaIndex: number, selectedRow: any): void {
    var itemExists = this.addedSocialMediaJson.socialMedia.find(i => i.addedMedia.id == evt.id);
    if (!itemExists) {
      this.addedSocialMediaJson.socialMedia[sMediaIndex].addedMedia = evt;
      this.addedSocialMediaJson.socialMedia[sMediaIndex].typeId = evt.id;
      this.addedSocialMediaJson.socialMedia[sMediaIndex].type = evt.value;
      if (null != selectedRow && null != selectedRow.addedMedia) {
        selectedRow.typeId = selectedRow.addedMedia.id;
        selectedRow.type = selectedRow.addedMedia.value;
        this.onPageEdit();
      }
    }
  }

  /*
   * Function to modify edited phone data.
   */
  public onSelectPhoneAddedRow(evt: any, phoneIndex: number, selectedRow: any): void {
    var itemExists = this.addedPhoneJson.phone.find(i => i.addedPhone.id == evt.id);
    if (!itemExists) {
      this.addedPhoneJson.phone[phoneIndex].addedPhone = evt;
      this.addedPhoneJson.phone[phoneIndex].typeId = evt.id;
      this.addedPhoneJson.phone[phoneIndex].type = evt.value;
      if (null != selectedRow && null != selectedRow.addedPhone) {
        selectedRow.typeId = selectedRow.addedPhone.id;
        selectedRow.type = selectedRow.addedPhone.value;
        this.onPageEdit();
      }
    }
  }

  /** Method to get current selected social media primary indicator
  * @param selectedVal
  */
  public onSelectPrimaryMedia(selectedVal: boolean): void {
    this.selectedPrimaryFlag = true;
    this.onPageEdit();
  }

  public selectAddedPrimaryMedia(addedSocialMedia: any): void {
    //Set other primary flags to false if current selected one is true.
    if (null != this.addedSocialMediaJson.socialMedia && this.addedSocialMediaJson.socialMedia.length > 0) {
      for (const itm of this.addedSocialMediaJson.socialMedia) {
        itm.primary = false;
      }
    }
    //Set true to current selected radio button
    addedSocialMedia.primary = true;
    this.onPageEdit();
  }

  /** Method to get current selected type
  * @param selectedVal
  */
  public onSelectEntityType(selectedId: number, selectedValue: string): void {
    this.entityTypeValue = selectedValue;
    this.companyData.entityTypeValue = selectedValue;
    this.companyData.entityTypeId = selectedId;
    this.onPageEdit();
  }

  /** Method to delete the selected occupation
   * @param selectedItem
   */

  public deleteOccupation(selectedItem, evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (null != selectedItem) {
        const index: number = this.addedOccupationJson.occupations.indexOf(selectedItem);
        if (index !== -1) {
          this.addedOccupationJson.occupations.splice(index, 1);
        }
        this.onPageEdit();
      }
    }
  }

  // This keypress function prevents alphabetical character.
  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  /**  Method to delete selecte type
   * @param selectedItem
   */

  public deleteType(selectedItem, evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (null != selectedItem) {
        const index: number = this.addedTypeJson.types.indexOf(selectedItem);
        if (index !== -1) {
          this.addedTypeJson.types.splice(index, 1);
        }
        this.onPageEdit();
      }
    }
  }

  /**  Method to delete selected social media
  * @param selectedItem
  */

  public deleteSocialMedia(selectedItem, evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (null != selectedItem) {
        const index: number = this.addedSocialMediaJson.socialMedia.indexOf(selectedItem);
        if (index !== -1) {
          this.addedSocialMediaJson.socialMedia.splice(index, 1);
        }
      }
      //Select the first row as primary when user removes the already existing primary row from list
      if (null != selectedItem && selectedItem.primary && this.addedSocialMediaJson.socialMedia.length > 0) {
        this.addedSocialMediaJson.socialMedia[0].primary = true;
      }
      //Select the input primary radio button as selected when there is no entry in that list
      if (null != this.addedSocialMediaJson && this.addedSocialMediaJson.socialMedia.length == 0) {
        this.selectedPrimaryFlag = true;
      }
      this.onPageEdit();
    }
  }

  /**  Method to edit selected social media
   * @param selectedItem
   */

  public editSocialMedia(selectedItem, evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (null != selectedItem) {

        this.socialmediaDropdownSub.dropdownValue = selectedItem.addedMedia;
        this.socialmediaDropdownSub.selection = "value";
        this.socialmediaDropdownSub.title = selectedItem.addedMedia.value;

        selectedItem.edited = true;
        this.socialMediaEditMode = true;
        this.onPageEdit();
      }
    }
  }

  /**  Method to add editted social media
   * @param selectedItem
   */

  public addEditedSocialMedia(selectedItem, evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (null != selectedItem) {
        if (selectedItem.validWebsite) {
          this.socialMediaEditMode = false;
          selectedItem.edited = false;
        } else {
          this.socialMediaEditMode = true;
          selectedItem.edited = true;
        }
      }
    }
  }

  // unSavedContent - For unSaved changes confirmation
  public openGenericImageModal(unSavedContent) {
    this.modalService.open(unSavedContent);
  }

  public openGenericImageModalCancel(unSavedContent) {
    let modalRef = this.modalService.open(unSavedContent);
    this.TrapFocusDuplicateAlertModal();
    modalRef.result.then((data) => {
      if (data == "proceed") {
        this.onValEdit.emit(false);
      } else {
        this.onValEdit.emit(true);
      }
    }, (reason) => {
      console.log("reason", reason);
    });
  }

  public confirmUnSavedChanges() {
    this.cancelEvent.emit(this.outputParams);
  }

  onCancelEvent(unSavedContent, evt) {
    if (evt.keyCode === 13 || evt.keyCode === undefined) {
      this.outputParams = new CompanyOutputParamsModel(this.companyData);
      // this.pageEdited = true; // Hardcoded 'true' since showing the Unsaved popup irrespective of changes are done or not

      // Code for unsaved changes pop-up.
      if (true == this.pageEdited) {
        this.openGenericImageModalCancel(unSavedContent)
      }
      else {
        this.cancelEvent.emit(this.outputParams);
      }
    }
  }

  onSaveEvent(event): void {
    if (event.keyCode === 13 || event === 18) {
      this.onValEdit.emit(false);
      if (null != this.companyData && null != this.companyData.displayName && this.companyData.displayName.length > 0 && this.notes_error_msg === false) {
        this.validCompanyName = true;
        if (this.isValidCompany()) {
          this.convertCompanyModelToJson();
        }
      }
      else {
        this.validCompanyName = false;
      }
      let nameSchema = this.generateSchema();
      this.companyData.names = nameSchema;

      this.outputParams = new CompanyOutputParamsModel(this.companyData, this.validCompanyName, this.notes_error_msg);
      this.saveEvent.emit(this.outputParams);
    }
    else if (event.keyCode === 9 && event.shiftKey === true) {
      document.getElementById("dummy-grid-text").focus();
    }
  }

  public onSubmit() {
    console.log(this.companyForm);
  }
  public isValidFieldalue(fieldValue: string) {
    return fieldValue.length > 0;
  }

  /**Check whether its a valid company or not */
  public isValidCompany() {
    let isValid = true;
    if (this.validCompanyName && this.validInputWebsite && this.isValidAddedWebsite()) {
      isValid = true;
    } else {
      isValid = false;
    }
    return isValid;
  }

  /**Check whether any social media exists without url */
  public isValidAddedWebsite() {
    let isValid = true;
    if (null != this.addedSocialMediaJson.socialMedia) {
      for (const itm of this.addedSocialMediaJson.socialMedia) {
        if (!itm.validWebsite) {
          isValid = false;
          break;
        }
      }
    }
    return isValid;
  }

  public setCompanyTitle() {
    if (null != this.companyData && null != this.companyData.displayName
      && this.companyData.displayName.length > 0) {
      this.validCompanyName = true;
    } else {
      this.validCompanyName = false;
    }
  }

  public validateWebsiteUrl(selectedItem: any) {
    if (selectedItem.value.length > 0) {
      selectedItem.validWebsite = true;
    } else {
      selectedItem.validWebsite = false;
    }
  }

  public validateInputWebsiteUrl() {
    this.validInputWebsite = true;
    this.validInputSocialMediaType = true;
    if (null != this.selectedSocialMediaType && null != this.selectedSocialMediaType.value
      && (this.selectedSocialMediaUtlTxt == null || this.selectedSocialMediaUtlTxt.length <= 0)) {
      this.validInputWebsite = false;
    }
    else if ((null == this.selectedSocialMediaType || null == this.selectedSocialMediaType.value)
      && (this.selectedSocialMediaUtlTxt != null && this.selectedSocialMediaUtlTxt.length > 0)) {
      this.validInputWebsite = false;
    }
  }

  /** Method to call the lookup services
   */
  private getDropdownLookupData() {
    if (null !== this.inputParams && this.inputParams !== undefined) {
      this.occupationDropdown = this.inputParams.occupationDropdown;
      this.typesDropdown = this.inputParams.typeDropdown;
      this.socialmediaDropdown = this.inputParams.socialMediaTypeDropdown;
      this.socialmediaDropdownSub = this.inputParams.socialMediaTypeDropdown;
      this.companyEntityTypes = this.inputParams.entityTypeOptions;
      this.phoneDropdown = this.inputParams.phoneDropdown
      this.phoneDropdownSub = this.inputParams.phoneDropdown;
      this.selectCountryDropdown = this.inputParams.countryDropdown
      this.selectStateDropdown = this.inputParams.stateDropdown;
    }
  }

  /**  Method to populate company details */
  private convertCompanyJsonToModel(companyDataValue: any) {
    //Set ADD/EDIT mode based on company_id
    if (this.companiesId != null && this.companiesId > 0 && !this.isAddNew) {
      this.isEdit = true;
      this.companyData = companyDataValue
      this.entityTypeValue = this.companyData.entityTypeValue;
      this.convertDetailsEditMode();
    } else {
      this.validCompanyName = true;
      this.companyData.displayName = companyDataValue.displayName;
      this.companiesId = null;
      this.isEdit = false;
      this.entityTypeValue = this.COMPANY_TXT;
      this.setDefaultEntitySelection();
    }
  }

  private setDefaultEntitySelection() {
    if (null !== this.companyEntityTypes && this.companyEntityTypes !== undefined) {
      for (const itm of this.companyEntityTypes) {
        if ((this.companyData.entityTypeId === null || this.companyData.entityTypeId === undefined)
          && itm.value == this.COMPANY_TXT) {
          this.companyData.entityTypeId = itm.id;
          this.companyData.entityTypeValue = itm.value;
        }
      }
    }
  }

  private convertCompanyModelToJson() {
    if (this.companiesId == null) {
      this.setDefaultEntitySelection();
    }
    //Occupation and Type is required only if the selected entity type is Company
    if (this.entityTypeValue == this.COMPANY_TXT) {
      this.companyData.occupations = this.addedOccupationJson.occupations;
      this.companyData.types = this.addedTypeJson.types;
    } else {
      this.companyData.occupations = null;
      this.companyData.types = null;
    }
    //Method to set UI extra attributes to null
    this.setSocialMediaUIAtributesNull();
    this.companyData.socialMedia = this.addedSocialMediaJson.socialMedia;
    this.companyData.dataSet = this.dataSetValue;
    console.info("this.AddedLocations.loc1 ....." + this.AddedLocations.loc);
    if (null != this.AddedLocations.loc && this.AddedLocations.loc.length > 0) {

      this.setLocationPhoneUIAtributesNull();
      //Changes for Multiple Locations Add
      // let addedLocationLength = this.AddedLocations.loc.length;
      // if (this.isEdit) {
      //   for (var i = 0; i < this.companyData.locations.length; i++) {
      //     let existingCompanyLoc = new CompaniesLocationsModel();
      //     if (null != this.companyData.locations[i]) {
      //       existingCompanyLoc = <CompaniesLocationsModel>this.companyData.locations[i];
      //       this.existingLocationArray.push(existingCompanyLoc);
      //     }
      //   }
      //   if (this.AddedLocations.loc != null && this.AddedLocations.loc[addedLocationLength-1].primary) {
      //     for (const itm of this.existingLocationArray) {
      //       if (itm.primary == true) {
      //         itm.primary = false;
      //       }
      //     }
      //   }
      // }

      //Changes for Multiple Locations Add
      if (this.isEdit) {
        for (const addedLoc of this.AddedLocations.loc) {
          this.companyData.locations.push(addedLoc);
        }
      }
      else {
        this.companyData.locations = this.AddedLocations.loc;
      }
    }
    //Changes to set the primary location to last one if nothing is selected with primary
    this.setPrimaryLocationIfNotSelected();
  }

  /**
   * Method to set the primary to last location if nothing is selected with primary
   */
  private setPrimaryLocationIfNotSelected() {
    let primaryExists: boolean = false;
    if (null !== this.companyData.locations && this.companyData.locations !== undefined) {
      for (const companyLocationObj of this.companyData.locations) {
        let companyLoc: CompaniesLocationsModel = <CompaniesLocationsModel>companyLocationObj;
        if (null !== companyLoc && companyLoc.primary) {
          primaryExists = true;
          break;
        }
      }
      if (!primaryExists && (this.companyData.locations.length > 0)) {
        let companyLoc = <CompaniesLocationsModel>this.companyData.locations[this.companyData.locations.length - 1];
        companyLoc.primary = true;
      }
    }
  }

  private convertDetailsEditMode() {
    this.addedOccupationJson.occupations = this.companyData.occupations;
    this.addedTypeJson.types = this.companyData.types;
    this.addedSocialMediaJson.socialMedia = this.companyData.socialMedia;
    if (null !== this.addedSocialMediaJson.socialMedia && this.addedSocialMediaJson.socialMedia.length > 0) {
      for (const itm of this.addedSocialMediaJson.socialMedia) {
        itm.validWebsite = true;
        itm.edited = false;
        itm.addedMedia = { "id": itm.typeId, "value": itm.type }
      }
      this.selectedPrimaryFlag = false;
    } else {
      this.selectedPrimaryFlag = true;
    }
    this.socialMediaEditMode = false;
  }

  // TODO: This function need to be removed
  private setDeaultDetailsAddMode() {
    this.companyData = this.inputParams.companyData;
    if (this.companyData === undefined) {
      this.companyData = new CompaniesDetailModel(null, null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, null, null, null);
    }
  }

  /** Method to set UI extra attributes to null */
  private setSocialMediaUIAtributesNull() {
    if (null != this.addedSocialMediaJson.socialMedia) {
      for (const itm of this.addedSocialMediaJson.socialMedia) {
        itm.validWebsite = true;
        itm.edited = false;
        itm.addedMedia = null;
      }
    }
  }

  /** Method to set UI extra attributes in Location Phone to null */
  private setLocationPhoneUIAtributesNull() {
    if (null != this.AddedLocations.loc) {
      for (const itm of this.AddedLocations.loc) {
        if (null != itm.phone) {
          for (const itmPhone of itm.phone) {
            itmPhone.edited = false;
            itmPhone.addedPhone = null;
          }
        }
      }
    }
  }
  //Locations modal
  public OpenLocationModal() {
    // if(this.selectedState.value===null){
    this.disableTypeAheadLoc = true;
    this.selectedCountryBuffer = "United States"
    this.selectCountryDropdown.title = "United States"
    this.selectCountryDropdown.selection = "value"
    this.locationAction = "Add Location"
    this.validLocationName = true;
    this.validInputPhone = true;
    this.selectStateDropdown.selection = "null"
    // }
    this.addedPhoneJson = { "phone": [] };
    //Select the input primary radio button as selected when there is no entry in that list
    this.selectedPrimaryFlagN = true;
    // this.modalService.open(this.myModal, { centered: true, size: 'lg' });
    this.modalService.open(this.myModal, { centered: true, size: 'lg', backdrop: 'static' });

    //Set default country to United States
    if (this.tempCountryType && this.tempCountryType[0]) {
      let options = this.selectCountryDropdown.options;
      this.selectCountryDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      this.selectCountryDropdown.dropdownValue = this.tempCountryType[0];
      this.selectCountryDropdown.selection = "value"
      this.selectCountryDropdown.title = this.tempCountryType[0].value;
      this.selectedCountry = { "id": this.tempCountryType[0].id, "value": this.tempCountryType[0].value };
    }
    document.getElementById("loc-name loc-name-input").focus();
  }


  /** Method to get current selected social media primary indicator
  * @param selectedVal
  */
  public onSelectPrimaryPhone(selectedVal: boolean): void {
    this.selectedPrimaryFlagN = true;
    this.onPageEdit();
  }

  public selectAddedPrimaryPhone(addedPhone: any): void {
    //Set other primary flags to false if current selected one is true.
    if (null != this.addedPhoneJson.phone && this.addedPhoneJson.phone.length > 0) {
      for (const itm of this.addedPhoneJson.phone) {
        itm.primary = false;
      }
    }
    //Set true to current selected radio button
    addedPhone.primary = true;
    this.onPageEdit();
  }
  public onSelectPhone(selectedVal: string): void {
    this.selectedPhoneType = selectedVal;
    this.onPageEdit();
  }
  //adding phone field
  public addPhone(evt): void {

    if (this.addedPhoneJson.phone != null) {
      var itemExists = this.addedPhoneJson.phone.find(i => i.addedPhone.id == this.selectedPhoneType.id);
    }
    if (!itemExists) {
      if (evt.keyCode === 13 || evt.keyCode === undefined) {
        this.validatInputPhoneNumber("a");
        if (null != this.selectedPhoneNumber && this.selectedPhoneNumber.length > 0
          && null != this.selectedPhoneType) {
          var numberOfDigits = this.selectedPhoneNumber.replace(/[^0-9]/g, "").length
          if (numberOfDigits < 11) {
            var formattedPhoneNumber = this.formatPhoneNumberNew(this.selectedPhoneNumber);

          }
          else {
            var formattedPhoneNumber = this.selectedPhoneNumber
          }
          let phoneModel = new PhoneMediaModel(null, null, this.selectedPhoneType.id, this.selectedPhoneType.value,
            this.selectedPhoneNumber, this.selectedPrimaryFlagN, this.selectedPhoneType, false, true, formattedPhoneNumber);

          //set the other primary flags to false if current selected one is true.
          if (this.selectedPrimaryFlagN == true && null != this.addedPhoneJson.phone
            && this.addedPhoneJson.phone.length > 0) {
            for (const itm of this.addedPhoneJson.phone) {
              itm.primary = false;
            }
          }
          if (null == this.addedPhoneJson || null == this.addedPhoneJson.phone) {
            this.addedPhoneJson.phone = [];
          }
          //Set the primary phone in first position in list
          if (this.selectedPrimaryFlagN) {
            this.addedPhoneJson.phone.splice(0, 0, phoneModel);
          } else {
            this.addedPhoneJson.phone.push(phoneModel);
          }
          this.selectedPhoneNumber = null;
          this.selectedPhoneType = null;
          var options = this.phoneDropdown.options;
          this.phoneDropdown = new DropdownTypeAheadModel('', '', '', '', options);
          this.phoneDropdown.dropdownValue = { id: "", value: "" };
          this.phoneDropdown.selection = "value";
          this.phoneDropdown.title = "";

          // this.phoneDropdown.selection = "null";
          this.selectedPrimaryFlagN = false;
          this.onPageEdit();
        }
      }

    }
    else {
      var options = this.phoneDropdown.options;
      this.phoneDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      this.phoneDropdown.dropdownValue = { id: "", value: "" };
      this.phoneDropdown.selection = "value";
      this.phoneDropdown.title = "";
      this.selectedPhoneNumber = null;
    }
  }
  //delete phone
  public deletePhone(selectedItem): void {
    if (null != selectedItem) {
      const index: number = this.addedPhoneJson.phone.indexOf(selectedItem);
      if (index !== -1) {
        this.addedPhoneJson.phone.splice(index, 1);
      }
    }

    //Select the first row as primary when user removes the already existing primary row from list
    if (null != selectedItem && selectedItem.primary && this.addedPhoneJson.phone.length > 0) {
      this.addedPhoneJson.phone[0].primary = true;
    }
    //Select the input primary radio button as selected when there is no entry in that list
    if (this.addedPhoneJson.phone.length == 0) {
      this.selectedPrimaryFlagN = true;
    }
    this.onPageEdit();
  }

  public OnselectLocationName(selectedVal: string) {
    this.selectedLocationName = selectedVal;
    this.validateAddLocPopup();
  }

  public validateAddLocPopup() {
    if ((this.selectedCity && this.selectedCity.trim() != "")
      || (this.selectedLocationName && this.selectedLocationName.trim() != "")) {
      this.disableTypeAheadLoc = false;
    } else {
      this.disableTypeAheadLoc = true;
    }
  }
  // It returns the formatted Phone number
  public formatPhoneNumber(phoneNumberString: string) {
    var cleaned = ('' + phoneNumberString).replace(/\D/g, '')
    var match = cleaned.match(/^(\d{0,3})(\d{0,3})(\d{0,4})(\d{0,4})$/)
    if (match) {
      if (phoneNumberString.length > 10) {
        var result = '(' + match[1] + ') ' + match[2] + '-' + match[3] + '-' + match[4]
      } else {
        var result = '(' + match[1] + ') ' + match[2] + '-' + match[3]
      }

      if (result.substring(result.length - 1) == "-") {
        result = result.substring(0, result.length - 1);
      }
      return result;
    }
    return null
  }

  // It returns the formatted Phone number as per new requirement in phone formatting
  public formatPhoneNumberNew(phoneNumberString: string) {
    var cleaned = ('' + phoneNumberString).replace(/\D/g, '')
    var match = cleaned.match(/^(\d{0,3})(\d{0,3})(\d{0,4})(\d{0,4})$/)
    if (match) {
      if (phoneNumberString.length > 10) {
        var result = '(' + match[1] + ') ' + match[2] + '-' + match[3]
      } else {
        var result = '(' + match[1] + ') ' + match[2] + '-' + match[3]
      }

      if (result.substring(result.length - 1) == "-") {
        result = result.substring(0, result.length - 1);
      }
      return result;
    }
    return null
  }

  public OnselectAddress(selectedVal: string, type) {
    if (type == "selectedAddress") {
      this.selectedAddress = selectedVal;
    }
    if (type == "selectedAddressSecondLine") {
      this.selectedAddressSecondLine = selectedVal;
    }
    if (type == "selectedAddressThirdLine") {
      this.selectedAddressThirdLine = selectedVal;
    }

  }

  public OnselectPostal(selectedVal: number) {
    this.selectedPostal = selectedVal;
    this.onPageEdit();
  }

  public OnselectCity(selectedVal: string) {
    this.selectedCity = selectedVal;
    this.validateAddLocPopup();
    this.onPageEdit();
  }
  public OnselectPhoneNumber(selectedVal: string) {
    this.selectedPhoneNumber = selectedVal;
    this.validInputPhone = true;
    this.validInputPhoneType = true;
    if (null != this.selectedPhoneType && null != this.selectedPhoneType.value
      && (this.selectedPhoneNumber == null || this.selectedPhoneNumber.length <= 0)) {
      this.validInputPhone = false;
    }
    else if ((null == this.selectedPhoneType || null == this.selectedPhoneType.value)
      && (this.selectedPhoneNumber != null && this.selectedPhoneNumber.length > 0)) {
      this.validInputPhone = false;
    }
  }
  public onSelectPrimaryLocation(val) {

    this.selectedlocationPrimary = val;
    this.onPageEdit();

  }
  public saveLocations(c) {

    if (this.isOpen) {
      this.locationsId = null;
    }
    //setting null to empty fields
    if (this.selectedLocationName == null) {
      this.selectedLocationName = null;
    }
    if (this.selectedAddress == null) {
      this.selectedAddress = null;
    }
    if (this.selectedAddressSecondLine == null) {
      this.selectedAddressSecondLine = null;
    }
    if (this.selectedAddressThirdLine == null) {
      this.selectedAddressThirdLine = null;
    }
    if (this.selectedCity == null) {
      this.selectedCity = null;
    }
    if (this.editSelectedCountryId === undefined) {
      this.editSelectedCountryId = null;
    }
    if (this.editSelectedStateId === undefined) {
      this.editSelectedStateId = null;
    }

    if (this.selectedPostal == null) {
      this.selectedPostal = null;
    }

    if (this.addedPhoneJson == null) {
      this.addedPhoneJson.phone = [];
    }
    if ((this.selectedCountry == null || this.selectedCountry.value == null) && this.selectedCountryBuffer == "United States") {
      this.selectedCountry = {
        value: "United States",
        id: "US"
      }

    }
    if (this.selectedLocationName && this.selectedLocationName.trim() !== "") {
      this.validLocationName = true;
      this.isValidLoca = true;
      if (this.isValidLocation()) {
        this.locationAddressObject = {
          addressId: null,
          locationName: this.selectedLocationName,
          addressType: "ADDRESS",
          firstLine: this.selectedAddress,
          secondLine: this.selectedAddressSecondLine,
          thirdLine: this.selectedAddressThirdLine,
          city: this.selectedCity,
          state: (null != this.selectedState) ? this.selectedState.value : null,
          stateId: (null != this.selectedState) ? this.selectedState.id : null,
          zip: this.selectedPostal,
          countryId: (null != this.selectedCountry) ? this.selectedCountry.id : null,
          country: (null != this.selectedCountry) ? this.selectedCountry.value : null,
        }

        this.selectedAddress = (this.selectedAddress && this.selectedAddress.trim() !== this.empty_string) ? this.selectedAddress : null;
        this.selectedAddressSecondLine = (this.selectedAddressSecondLine && this.selectedAddressSecondLine.trim() !== this.empty_string) ? this.selectedAddressSecondLine : null;
        this.selectedAddressThirdLine = (this.selectedAddressThirdLine && this.selectedAddressThirdLine.trim() !== this.empty_string) ? this.selectedAddressThirdLine : null;

        this.setLocationAddressArray();

        let LocationsModel = new CompaniesLocationsModel(null, this.selectedLocationName, "address", this.concatinatedAddress,
          this.locationAddressObject, this.selectedlocationPrimary, this.addedLocationAddressArray,
          this.addedPhoneJson.phone, null, false);

        //Handle primary check for existing loactions
        if (this.isEdit) {
          if (this.existingLocationArray.length == 0) {
            for (var i = 0; i < this.companyData.locations.length; i++) {
              let existingCompanyLoc = new CompaniesLocationsModel();
              if (null != this.companyData.locations[i]) {
                existingCompanyLoc = <CompaniesLocationsModel>this.companyData.locations[i];
                this.existingLocationArray.push(existingCompanyLoc);
              }
            }
          }
          if (LocationsModel.primary) {
            for (const existingItm of this.existingLocationArray) {
              if (this.EditLocationsFlag == false ||
                (this.EditLocationsFlag == true && !this.existingLocationArray.find(x => (x == this.EditLocationsRow && x == existingItm)))) {
                console.log("in save loc - existing Location Array check - if exclude selected row for edit primary check .." + existingItm.locationName)
                if (existingItm.primary == true) {
                  existingItm.primary = false;
                }
              }
            }
          }
        }
        //Handle primary check for newly added loactions
        if (LocationsModel.primary) {
          for (const addedItm of this.AddedLocations.loc) {
            if (this.EditLocationsFlag == false ||
              (this.EditLocationsFlag == true && !this.AddedLocations.loc.find(x => (x == this.EditLocationsRow && x == addedItm)))) {
              console.log("in save loc - added location check - if exclude selected row for edit primary check " + addedItm.locationName);
              if (addedItm.primary == true) {
                addedItm.primary = false;
              }
            }
          }
        }

        //To Do
        //Edited locations are saved by replacing the respective location from row by fetching index
        if (this.EditLocationsFlag == true) {
          console.log("edit model ONN")
          this.EditLocationsRow.name = this.selectedLocationName;
          this.EditLocationsRow.addressType = "ADDRESS";
          this.EditLocationsRow.address = this.concatinatedAddress;
          this.EditLocationsRow.locationAddress.city = this.selectedCity;
          this.EditLocationsRow.locationAddress.country = this.selectCountryDropdown.dropdownValue;
          this.EditLocationsRow.locationAddress.firstLine = this.selectedAddress;
          this.EditLocationsRow.locationAddress.secondLine = this.selectedAddressSecondLine;
          this.EditLocationsRow.locationAddress.thirdLine = this.selectedAddressThirdLine;
          this.EditLocationsRow.locationAddress.zip = this.selectedPostal;
          this.EditLocationsRow.locationAddress.state = this.selectStateDropdown.dropdownValue;
          this.EditLocationsRow.phone = this.addedPhoneJson.phone;
          this.EditLocationsRow.primary = this.selectedlocationPrimary;
          this.EditLocationsRow.gridLocationAddress = this.addedLocationAddressArray;
          this.EditLocationsRow.locationAddress = this.locationAddressObject;
          // this.EditLocationsRow = LocationsModel;
          //RC-1350 - Update the grid row sequence based on primary location
          if (this.EditLocationsRow.primary) {
            const res1 = this.gridApi.updateRowData({ update: [this.EditLocationsRow] });
            const res2 = this.gridApi.updateRowData({ remove: [this.EditLocationsRow] });
            const res = this.gridApi.updateRowData({ add: [this.EditLocationsRow], addIndex: 0 });
          } else {
            const res = this.gridApi.updateRowData({ update: [this.EditLocationsRow] });
          }

          this.EditLocationsFlag = false;

          //Changes to shrink/expand the row height based on gird list items count
          let gridRowItems = Math.max((this.addedLocationAddressArray) ? this.addedLocationAddressArray.length : 0,
            (this.addedPhoneJson.phone) ? this.addedPhoneJson.phone.length : 0);
          let gridRowHeight = (gridRowItems >= 3) ? 70 : ((gridRowItems == 2) ? 50 : 30)
          if (this.gridApi && this.gridApi.rowModel && this.gridApi.rowModel.rootNode
            && this.gridApi.rowModel.rootNode.allLeafChildren
            && this.gridApi.rowModel.rootNode.allLeafChildren[this.selectedLocationIndex]) {
            this.gridApi.rowModel.rootNode.allLeafChildren[this.selectedLocationIndex].setRowHeight(gridRowHeight);
            this.gridApi.onRowHeightChanged();
          }
        }
        //if a location is added newly in either edit or create mode save locations will happen here
        else {
          this.AddedLocations.loc.push(LocationsModel);
          //RC-1350 - Update the grid row sequence based on primary location
          if (this.gridApi) {
            if (LocationsModel.primary) {
              const res = this.gridApi.updateRowData({ add: [LocationsModel], addIndex: 0 });
            } else {
              const res = this.gridApi.updateRowData({ add: [LocationsModel] });
            }
            if (this.gridApi.rowModel && this.gridApi.rowModel.rootNode) {
              this.gridApi.rowModel.rootNode.dynamicRowAdded = true;
            }
          }
        }
      }
    }
    else {
      this.validLocationName = false;
      this.isValidLoca = false
    }

    //Add Multiple Locations - reset back primary flag to false
    this.selectedlocationPrimary = false;
    this.selectedCountryBuffer = null;
    this.EditLocationsFlag = false;
    this.selectStateDropdown = this.inputParams.stateDropdown;

    //Method to set the primary Phone on top of location's phone list
    this.setPrimaryPhoneOnTop();
    this.onPageEdit();
    setTimeout(() => {
      document.getElementById("loc-grid-add").focus();
    }, 100);
  }

  public cancelWarning() {
    //clearing all fields
    this.selectedCountryBuffer = null;
    this.selectedLocationName = "";
    this.selectedlocationPrimary = false;
    this.primaryLocation = false;
    this.selectedAddress = "";
    this.selectedAddressSecondLine = "";
    this.selectedAddressThirdLine = "";
    this.selectedState = "";
    this.selectedPostal = null;
    this.selectedCity = "";
    this.selectedCountry = null;
    this.validLocationName = true;
    this.selectedPhoneNumber = null;
    this.onPageEdit();
    this.selectStateDropdown = this.inputParams.stateDropdown;
    //set back to db phone values on cancel click
    this.setLocationPhoneWithDBValue();
    this.setStateCountryToEmpty();
  }

  //To Do
  public EditModal(row) {
    this.disableTypeAheadLoc = false;
    this.EditLocationsFlag = true;
    this.validInputPhone = true;
    this.addClearPhone = true;
    this.selectedLocationName = row.data.name;
    this.locationsId = row.data.locationId;
    this.selectedCity = row.data.locationAddress.city;
    this.selectedAddress = row.data.locationAddress.firstLine;
    this.selectedAddressSecondLine = row.data.locationAddress.secondLine;
    this.selectedAddressThirdLine = row.data.locationAddress.thirdLine;

    this.selectedPostal = row.data.locationAddress.zip;
    this.selectCountryDropdown.dropdownValue = { "id": row.data.locationAddress.countryId, "value": row.data.locationAddress.country };
    this.selectedCountryBuffer = row.data.locationAddress.country;

    this.onSetStateEvent(this.selectCountryDropdown.dropdownValue, row.data.locationAddress);

    this.locationPhoneJsonFromDB.phone = this.deepClone(row.data.phone);
    this.addedPhoneJson.phone = Object.assign([], row.data.phone);

    if (null !== this.addedPhoneJson.phone && this.addedPhoneJson.phone !== undefined) {
      for (const itm of this.addedPhoneJson.phone) {
        itm.addedPhone = { "id": itm.typeId, "value": itm.type };
        //Set the phone 'edited flag to false on opening location popup
        itm.edited = false;
      }
    }

    //Set phone dropdown to empty
    this.phoneDropdown.dropdownValue = { "id": null, "value": null };
    this.phoneDropdown.title = "";
    this.phoneDropdown.selection = "null";

    //Select the input primary radio button as selected when there is no entry in that list
    if (null == this.addedPhoneJson || this.addedPhoneJson == undefined
      || (null != this.addedPhoneJson && (null == this.addedPhoneJson.phone || this.addedPhoneJson.phone == undefined))
      || (null != this.addedPhoneJson && null != this.addedPhoneJson.phone && this.addedPhoneJson.phone.length == 0)) {
      this.selectedPrimaryFlagN = true;
    }
    else {
      this.selectedPrimaryFlagN = false;
    }
    this.selectedState = { "id": row.data.locationAddress.stateId, "value": row.data.locationAddress.state }
    this.selectedCountry = { "id": row.data.locationAddress.countryId, "value": row.data.locationAddress.country }

    this.editSelectedStateId = row.data.locationAddress.stateId;
    this.editSelectedCountryId = row.data.locationAddress.countryId;
    this.primaryLocation = row.data.primary;
    this.selectedlocationPrimary = row.data.primary;
    this.EditLocationsRow = row.data;
    this.selectedLocationIndex = row.childIndex;
  }


  public editPhone(selectedItem, index): void {
    if (selectedItem.keyCode === 13 || selectedItem.keyCode === undefined) {

      if (null != selectedItem) {
        this.phoneDropdownSub.dropdownValue = selectedItem.addedPhone;
        this.phoneDropdownSub.selection = "value";
        this.phoneDropdownSub.title = selectedItem.addedPhone.value;
        selectedItem.edited = true;
        this.PhoneEditMode = false;
        if (null !== this.addedPhoneJson.phone[index]) {
          this.addedPhoneJson.phone[index].value = selectedItem.value;
        }
        this.onPageEdit();
      }
    }
  }

  /**  Method to add editted phone
   * @param selectedItem
   */
  public addEditedPhone(selectedItem, index): void {

    if (selectedItem.keyCode === 13 || selectedItem.keyCode === undefined) {
      if (null != selectedItem) {
        if (selectedItem.validPhone === null || selectedItem.validPhone === undefined || selectedItem.validPhone) {
          this.PhoneEditMode = true;
          selectedItem.edited = false;
        } else {
          this.PhoneEditMode = true;
          selectedItem.edited = true;
        }
        if (null !== this.addedPhoneJson.phone[index]) {
          selectedItem.formatPhone = selectedItem.formatPhone.toString();
          var numberOfDigits = selectedItem.formatPhone.replace(/[^0-9]/g, "").length;

          if (numberOfDigits < 11) {
            selectedItem.formatPhone = this.formatPhoneNumberNew(selectedItem.formatPhone);
          }
          else {
            // selectedItem.formatPhone =  parseInt(selectedItem.formatPhone.replace(/[^0-9]/g,''));
            selectedItem.formatPhone = selectedItem.formatPhone.replace(/[^0-9]/g, '');
          }
          this.addedPhoneJson.phone[index].value = selectedItem.formatPhone;
          this.addedPhoneJson.phone[index].formatPhone = selectedItem.formatPhone;
        }

        this.onPageEdit();
      }
    }
  }

  public onSelectStateEvent(selectedVal: string): void {
    this.selectedState = selectedVal;
    //set empty if value removed from typeahead text field
    if (null === this.selectedState || this.selectedState == undefined ||
      (null !== this.selectedState && this.selectedState === "")) {
      this.selectedState = { "id": "", "value": "" };
    }
    this.onPageEdit();
  }

  public onSelectCountryEvent(selectedVal) {
    this.selectedCountry = selectedVal;

    //set empty if value removed from typeahead text field
    if (null === this.selectedCountry || this.selectedCountry == undefined ||
      (null !== this.selectedCountry && this.selectedCountry === "")) {
      this.selectedCountry = { "id": "", "value": "" };
    }
    // Call service for getting states corresponding to selected country.
    if (this.selectedCountryBuffer !== this.selectedCountry.value) {
      this.inputParams.service.serviceClass[this.inputParams.service.getStateListFromDb](this.selectedCountry.id).subscribe((data) => {
        this.selectStateDropdown = new DropdownTypeAheadModel('', '', '', '', []);
        this.selectStateDropdown.action = "rerender"; // set "rerender" for re initialize dropdown with new set of options
        this.selectStateDropdown.options = this.getDropdownOptionsRerender(data); //this.getDropdownOptions(data);
        this.selectedState = { "id": "", "value": "" };
        if (this.stateCheck == true) {
          this.selectStateDropdown.selection = "null"
          this.state = false
          this.stateCheck = false
        }
        else {
          this.selectStateDropdown.selection = "null"
          this.state = true
          this.stateCheck = true
        }

      });
      this.onPageEdit();
    }
    this.selectedCountryBuffer = this.selectedCountry.value
  }

  public onSetStateEvent(selectedVal, selectedAddress) {
    this.selectedCountry = selectedVal;

    //set empty if value removed from typeahead text field
    if (null === this.selectedCountry || this.selectedCountry == undefined ||
      (null !== this.selectedCountry && this.selectedCountry === "")) {
      this.selectedCountry = { "id": "", "value": "" };
    }
    // Call service for getting states corresponding to selected country.
    this.inputParams.service.serviceClass[this.inputParams.service.getStateListFromDb](this.selectedCountry.id).subscribe((data) => {
      this.selectStateDropdown = new DropdownTypeAheadModel('', '', '', '', []);
      this.selectStateDropdown.selection = "value";
      this.selectStateDropdown.options = this.getDropdownOptionsRerender(data); //this.getDropdownOptions(data);
      this.selectStateDropdown.dropdownValue = { "id": selectedAddress.stateId, "value": selectedAddress.state };
      this.selectedState = { "id": selectedAddress.stateId, "value": selectedAddress.state };
      document.getElementById("loc-name loc-name-input").click(); // for FC app dom rendering issue fix
    });
    this.onPageEdit();
    this.selectedCountryBuffer = this.selectedCountry.value
  }

  public getDropdownOptions(data: any) {
    let options: any[] = [];
    let dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    let pickListData: any;
    pickListData = data;
    for (let i = 0; i < Object.keys(pickListData).length; i++) {
      options.push({
        value: pickListData[i].value,
        route: '',
        id: pickListData[i].id,
        data: pickListData[i]
      });
    }
    return dropdownModel;
  }

  public getDropdownOptionsRerender(data: any) {
    let options: any[] = [];
    for (let i = 0; i < Object.keys(data).length; i++) {
      options.push({
        value: data[i].value,
        route: '',
        id: data[i].id,
        data: data[i]
      });
    }
    return options;
  }

  public setLocationTitle() {
    if (null != this.selectedLocationName && this.selectedLocationName.length > 0) {
      this.validLocationName = true;
    } else {
      this.validLocationName = false;
    }
  }

  /**Check whether its a valid location or not */
  public isValidLocation() {
    let isValidLoc = true;
    if (this.validLocationName) {
      isValidLoc = true;
      this.isValidLoca = true;
    } else {
      isValidLoc = false;
    }
    return isValidLoc;
  }

  //closing modal window
  public closeModal(c) {
    if (c.keyCode === undefined) {
      c('Close click');
      this.selectedLocationName = "";
      this.selectedlocationPrimary = false;
      this.primaryLocation = false;
      this.selectedAddress = "";
      this.selectedAddressSecondLine = "";
      this.selectedAddressThirdLine = "";
      this.selectedState = "";
      this.selectedPostal = null;
      this.selectedCity = "";
      this.selectedCountry = null;
      this.validLocationName = true;
      //Add Multiple Locations - reset back primary flag to false
      this.EditLocationsFlag = false;
      this.locationAction = "";
      this.onPageEdit();
      //set back to db phone values on cancel click
      this.setLocationPhoneWithDBValue();
      this.setStateCountryToEmpty();
      setTimeout(() => {
        document.getElementById("loc-grid-add").focus();
      }, 100);
    }
  }

  //closing modal window on click of save
  public DoSave(c, evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      //Changes to replace Location name with City Name
      if (this.selectedLocationName == null
        || (this.selectedLocationName != null && this.selectedLocationName.trim().length === 0)
        || (this.selectedLocationName != null && this.selectedLocationName.trim() == this.primay_location_name)) {
        if (this.selectedCity != null && this.selectedCity.trim().length > 0) {
          this.selectedLocationName = this.selectedCity.trim();
        }
      }
      this.saveLocations(c);

      if (this.isValidLoca) {
        c('Close click');
        this.validLocationName = true;
        this.isValidLoca = true;
        //clearing all fields
        this.selectedLocationName = "";
        this.primaryLocation = false;
        this.selectedAddress = null;
        this.selectedAddressSecondLine = null;
        this.selectedAddressThirdLine = null;
        this.selectedState = null;
        this.selectedPostal = null;
        this.selectedPhoneNumber = null;
        for (const itm of this.addedPhoneJson.phone) {
          itm.addedPhone = { "id": itm.id, "value": "" }
        }
        this.addedPhoneJson.phone = [];
        this.selectedCity = "";
        this.selectedCountry = null;

        this.setStateCountryToEmpty();
      }
      else {
        this.validLocationName = false;
      }
    }
  }

  //checking if the phone input fields are valid
  public validatInputPhoneNumber(evt) {
    if (evt.keyCode !== 9) {
      this.validInputPhone = true;
      this.validInputPhoneType = true;
      if (null != this.selectedPhoneType && null != this.selectedPhoneType.value
        && (this.selectedPhoneNumber == null || this.selectedPhoneNumber.length <= 0)) {
        this.validInputPhone = false;
      }
      else if ((null == this.selectedPhoneType || null == this.selectedPhoneType.value)
        && (this.selectedPhoneNumber != null && this.selectedPhoneNumber.length > 0)) {
        this.validInputPhone = false;
      }
    }
  }

  public validateAddedPhoneNumber(selectedItem: any) {
    if (selectedItem.formatPhone != "" && selectedItem.formatPhone != null) {
      selectedItem.validPhone = true;
    } else {
      selectedItem.validPhone = false;
    }
  }

  public isValidAddedPhone() {
    let isValidLoc = true;
    if (null != this.addedPhoneJson.phone) {
      for (const itm of this.addedPhoneJson.phone) {
        if (!itm.validPhone) {
          isValidLoc = false;
          break;
        }
      }
    }
    return isValidLoc;
  }

  public getColumnDefs(): ColumnDefModel[] {
    return [
      new ColumnDefModel('Location Name', 'name'),
      new GridListDefModel('Phone', 'phone',
        new GridListParamsModel({
          iterable: 'phone',
          keys: ['formatPhone', 'type']
        }, true), { config: { suppressSorting: true } }
      ),
      new GridListDefModel('Address', 'gridLocationAddress',
        new GridListParamsModel({
          iterable: 'gridLocationAddress',
          keys: ['line']
        }, true), { config: { suppressSorting: true } }
      ),

      new ColumnDefModel('City', 'locationAddress.city'),
      new ColumnDefModel('State/Prov', 'locationAddress.state'),
      new ColumnDefModel('Postal Code', 'locationAddress.zip'),
      new ColumnDefModel('Country', 'locationAddress.country'),
      new GridIconDefModel('', null,
        new GridIconParamsModel(
          {
            visible: false, action: (row) => {
              this.CallForDelete(row);
            }
          },
          {
            visible: true, action: (row) => {
              this.CallForEdit(row);
            }
          }
        ),
        { config: { suppressFilter: true, suppressSorting: true, width: 50 } }
      )
    ];
  }
  //To Do
  public CallForEdit(row: object) {
    this.locationAction = "Edit Location";
    this.validLocationName = true;
    this.validInputPhone = true;
    this.EditModal(row);
    this.modalService.open(this.myModal, { centered: true, size: 'lg' });
    document.getElementById("loc-name loc-name-input").focus()
  }

  //To Do
  public CallForDelete(row) {
    this.onPageEdit();

    //If user deletes the existing location
    if (null !== this.companyData.locations && this.companyData.locations != undefined) {
      const existingLocIndex: number = this.companyData.locations.indexOf(row.data);
      if (existingLocIndex > -1) {
        const res2 = this.gridApi.updateRowData({ remove: [row.data] });
        this.companyData.locations.splice(existingLocIndex, 1);
      }
    }

    //If user deletes the newly added locations
    if (null !== this.AddedLocations.loc && this.AddedLocations.loc != undefined) {
      const addedLocIndex: number = this.AddedLocations.loc.indexOf(row.data);
      if (addedLocIndex > -1) {
        const res2 = this.gridApi.updateRowData({ remove: [row.data] });
        this.AddedLocations.loc.splice(addedLocIndex, 1);
      }
    }

    //Changes to handle the primary check box on delete operation.
    //If user delete the primary location, last added/existing location will turn as primary
    if (row.data.primary) {
      if (null != this.AddedLocations.loc && this.AddedLocations.loc.length > 0) {
        this.AddedLocations.loc[this.AddedLocations.loc.length - 1].primary = true;
      } else if (null != this.companyData.locations && this.companyData.locations != undefined &&
        this.companyData.locations.length > 0) {
        let companyLoc = <CompaniesLocationsModel>this.companyData.locations[this.companyData.locations.length - 1];
        companyLoc.primary = true;
      }
    }
  }

  public getPageOptions() {
    return new GridPageOptionsModel(false, null, false, false, false, false, false);
  }

  /*
   * Function to set boolean on page edit
   */
  public onPageEdit() {
    if (false === this.pageEdited) {
      this.pageEdited = true;
    }
    this.onValEdit.emit(this.pageEdited);
  }

  /*
     * Function to save person from typeahead modal.
     * @param { any } event - Event with data of person to be saved.
     */
  public saveCompanyTypeaheadModal(cName) {
    const companyName: TypeAheadSaveModel = new TypeAheadSaveModel();
    companyName.name.entity = cName.formValues.companyName;
    companyName.partyType = 'COMPANY';
    companyName.createdBy = 'Melissa Tapie';
    companyName.updatedBy = 'Melissa Tapie';
    companyName.partyId = null;
    companyName.createdByApp = 'RollCall2';
    companyName.updatedByApp = 'RollCall2';
    companyName.dataSetId = this.dataSetValue;

    this.inputParams.service.serviceClass[this.inputParams.service.saveCompany](JSON.stringify(companyName)).subscribe(
      (res) => {
        this.companyData.partyId = res.partyId;
        // Get Talent Details - Get the list of AKA and Primary name
        this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](this.companiesId)
          .subscribe(
            (data) => {
              this.setFieldsValues(data['party']);
              this.getAllDisplayNames(data);
            },
            (err) => {
              console.log('error', err);
            });
        this.addNameCompanyComponentModal.successCB(res);
        setTimeout(() => {
          let inputField: HTMLElement = <HTMLElement>document.querySelector("#check-address");
          inputField && inputField.focus();
        }, 500);
      },
      (err) => {
        this.serviceDelayLoading = false;
        const errMessage: string = err.error.errors[0].detail;
        this.addNameCompanyComponentModal.failureCB(errMessage);
      }
    );
  }

  private getAllDisplayNames(item: any) {
    if (typeof item.party.names.AKA !== 'undefined') {
      this.listOfAlias = item.party.names.AKA;
      this.listOfAlias.push(item.party.names.PRIMARY[0]);
    } else {
      this.listOfAlias = item.party.names.PRIMARY;
    }
  }

  private getSelectedDisplayNames(item: any) {
    this.choosenDispName = item;
  }

  private generateSchema() {
    let akaList: any = [];
    let schema: any;
    akaList = JSON.parse(JSON.stringify(this.listOfAlias));
    let delindex = akaList.findIndex(i => i.name.nameId == this.choosenDispName.nameId);
    akaList.splice(delindex, 1);
    if (this.listOfAlias != undefined && this.listOfAlias.length > 0) {

      let seletedName = [{
        "name": this.listOfAlias[delindex].name,
        "nameType": {
          "type": "NAME_TYPE",
          "code": "PRIMARY",
          "label": "primary",
          "disabledFlag": null,
          "codeId": null
        }
      }]

      schema = {
        "AKA": akaList,
        "PRIMARY": seletedName
      }
    }
    return schema;
  }

  private updateTitle(item: any): void {

    this.talentSelected = item;

    if (this.talentSelected != undefined || this.talentSelected != null) {
      this.getSelectedDisplayNames(this.talentSelected);
    }

    if (item) {
      this.companyData.displayName = (item.firstName ? item.firstName + ' ' : '') +
        (item.middleName ? item.middleName + ' ' : '') +
        (item.entityName ? item.entityName : '') +
        (item.suffix ? ', ' + item.suffix : '');
    }
    else {
      this.companyData.displayName = '';
    }
  }

  public accentedService(char: any): void {
    this.inputParams.service.serviceAccentedClass[this.inputParams.service.getaccentedCharacters](char).subscribe((data) => {
      this.accentedModal.openAccentedModal(data);
    });
  }

  public saveAliasCompanyFunc(cName) {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();

    aliasParty.partyType = 'COMPANY';
    aliasParty.displayName = cName.typeAheadCurrentName.entityName || cName.formValues.companyName;
    aliasParty.name.entity = cName.typeAheadCurrentName.entityName || cName.formValues.companyName;
    aliasParty.partyId = (cName.typeAheadCurrentName && cName.typeAheadCurrentName.partyId) ? cName.typeAheadCurrentName.partyId : null;

    AKA.name.entity = EmptyIfNull.check(cName.formValues.aliasCompanyName);
    this.inputParams.service.serviceClass[this.inputParams.service.saveCompanyAlias](JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        this.updateNames(res);
        // Get Talent Details
        if (!this.companiesId) {
          this.companiesId = res.partyId;
        }
        this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](this.companiesId)
          .subscribe(
            (data) => {
              this.setFieldsValues(data['party']);
              this.getAllDisplayNames(data);
            },
            (err) => {
              console.log('error', err);
            });
        this.addNameCompanyComponentModal.successCB(res);
      },
      (err) => {
        this.serviceDelayLoading = false;
        const errMessage: string = err.error.errors[0].detail;
        this.addNameCompanyComponentModal.failureCB(errMessage);
      }
    );
  }

  public companySavedName(item: any): void {
    this.onPageEdit();
    this.isAddNew = true;
    this.disableTypeAheadOpt = true;
    this.saveNameTalentEvn = item;
  }
  public tabbingOut(i) {
    document.getElementById("loc-name loc-name-input").focus();
  }

  public tabbingOutCancel(i) {
    if (i.shiftKey != true) {
      setTimeout(() => {
        document.getElementById("loc-name loc-name-input").focus();
      }, 100);
    }
  }

  public tabbingOutLoc(i) {
    if (i.shiftKey == true && i.keyCode == 9) {
      setTimeout(() => {
        document.getElementById("cancel-loc").focus();
      }, 40);
    }
  }

  //On key enter of dropdown-typeahead the value will be added the list
  public addOccupationOnEnterPress(evt) {
    if (evt.key === "Enter") {
      this.addOccupation('1');
    }
  }

  public addTypeOnEnterPress(evt) {
    if (evt.key == "Enter") {
      this.addType('13');
    }
  }

  /**
   * Method to set the primary phone number on top of the list
   */
  setPrimaryPhoneOnTop() {
    if (this.addedPhoneJson.phone) {
      this.addedPhoneJson.phone.forEach((phoneItm, index) => {
        if (phoneItm && phoneItm.primary) {
          this.addedPhoneJson.phone.splice(index, 1);
          this.addedPhoneJson.phone.splice(0, 0, phoneItm);
        }
      });
    }
  }

  /**
   * Set the location phone with db values 
   */
  setLocationPhoneWithDBValue() {
    if (this.EditLocationsRow && this.locationPhoneJsonFromDB) {
      this.EditLocationsRow.phone = this.locationPhoneJsonFromDB.phone;
    }
  }

  /**
   * deep clone an existing array to new
   */
  deepClone(oldArray: Object[]) {
    let newArray: any = [];
    if (oldArray) {
      oldArray.forEach((item) => {
        newArray.push(Object.assign({}, item));
      });
    }
    return newArray;
  }

  public listNamesAdded(evtListName: Array<TypeAheadModel>): void {
    if (evtListName && evtListName.length) {
      this.rollCallModeTitle = 'Edit ';
      this.typeAheadModalConfig.title = "Add Alias";
      this.showTypeAhead = false;
      this.rollCallListNameResult = evtListName;
    }
  }

  public addAliasName(evt: any): void {
    this.typeAheadTitle = 'Enter alias and press enter';
    this.showTypeAhead = true;
    this.typeAheadAddSameName = false;
    this.disableSearchName = true;
    this.hasNoResultsCallback = false;
  }

  public hideTypeAheadHeader(evt: any) {
    this.showTypeAhead = false;
  }

  public TabbingToSave(i) {
    if (i.shiftKey != true && i.keyCode == 9) {
      document.getElementById("company-dummy").focus();
    }
  }

  /**
   * Set State and Country to empty
   */
  public setStateCountryToEmpty() {
    this.selectCountryDropdown.dropdownValue = { "id": null, "value": null };
    this.selectCountryDropdown.title = "";
    this.selectCountryDropdown.selection = "null";

    this.selectStateDropdown.dropdownValue = { "id": null, "value": null };
    this.selectStateDropdown.title = "";
    this.selectStateDropdown.selection = "null";

    this.selectedState = { "id": null, "value": null };
    this.selectedCountry = { "id": null, "value": null };
  }

  /**
   * Method to set the location address as 'line' array
   */
  public setLocationAddressArray() {
    if (this.selectedAddress && this.selectedAddressSecondLine && this.selectedAddressThirdLine) {
      this.addedLocationAddressArray = [
        {
          "line": this.selectedAddress
        },
        {
          "line": this.selectedAddressSecondLine
        },
        {
          "line": this.selectedAddressThirdLine
        }
      ]
    } else if (this.selectedAddress && this.selectedAddressSecondLine) {
      this.addedLocationAddressArray = [
        {
          "line": this.selectedAddress
        },
        {
          "line": this.selectedAddressSecondLine
        }
      ]
    } else if (this.selectedAddress && this.selectedAddressThirdLine) {
      this.addedLocationAddressArray = [
        {
          "line": this.selectedAddress
        },
        {
          "line": this.selectedAddressThirdLine
        }
      ]
    } else if (this.selectedAddressSecondLine && this.selectedAddressThirdLine) {
      this.addedLocationAddressArray = [
        {
          "line": this.selectedAddressSecondLine
        },
        {
          "line": this.selectedAddressThirdLine
        }
      ]
    } else if (this.selectedAddress) {
      this.addedLocationAddressArray = [
        {
          "line": this.selectedAddress
        }
      ]
    } else if (this.selectedAddressSecondLine) {
      this.addedLocationAddressArray = [
        {
          "line": this.selectedAddressSecondLine
        }
      ]
    } else if (this.selectedAddressThirdLine) {
      this.addedLocationAddressArray = [
        {
          "line": this.selectedAddressThirdLine
        }
      ]
    } else {
      this.addedLocationAddressArray = [];
    }

  }

  /**
  * Method to check backspace (evt.keyCode = 8) in Firefox, this is to ignore the space char on back space
  */
  public phoneKeydown(evt) {
    let numIndexBeforeSpace = 3;
    if (evt.keyCode === 8 && evt.target.selectionStart
      && navigator.userAgent.indexOf("Firefox") > -1 && this.selectedPhoneNumber
      && this.selectedPhoneNumber.length === numIndexBeforeSpace && this.phoneKeydownCount === 0) {
      evt.target.setSelectionRange(5, 5);
      evt.target.focus();
      this.phoneKeydownCount++;
    }
    //Reset keydownCount based on the length of entered phone number
    if (this.selectedPhoneNumber && this.selectedPhoneNumber.length !== numIndexBeforeSpace) {
      this.phoneKeydownCount = 0;
    }
  }


  /** Focus trap inside unsaved chnages alert . author rahul 
 **/
  TrapFocusDuplicateAlertModal() {
    const allBackgroundElements = document.querySelectorAll('.container, [tabindex="0"]')
    const tickBtn = document.getElementById('c2c-unsaved-changes-button-modal-ok')
    const closeBtn = document.getElementById('c2c-unsaved-changes-button-modal-cancel')
    //listen for keydown. Check for target of the event.
    document.addEventListener('keydown', (e) => {
      if (e.target === closeBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          tickBtn.focus()
        } else if (e.keyCode === 9) {
          e.preventDefault();
          tickBtn.focus()
        }
      } else if (e.target === tickBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          closeBtn.focus()
        } else if (e.keyCode === 9) {
          e.preventDefault();
          closeBtn.focus()
        }
      }
    })
  }
  // get notes string byte length and limit to 4000
  getByteLen(event) {
    // Force string type
    var limit = 4000;
    var normal_val = String(event.target.value);
    var byteLen = 0;
    for (var i = 0; i < normal_val.length; i++) {
        var c = normal_val.charCodeAt(i);
        byteLen += c < (1 <<  7) ? 1 :
                   c < (1 << 11) ? 2 :
                   c < (1 << 16) ? 3 :
                   c < (1 << 21) ? 4 :
                   c < (1 << 26) ? 5 :
                   c < (1 << 31) ? 6 : Number.NaN;
    }
    if(byteLen > limit){
      this.notes_error_msg = true;
    }else{
      this.notes_error_msg = false;
    }
  }

}
