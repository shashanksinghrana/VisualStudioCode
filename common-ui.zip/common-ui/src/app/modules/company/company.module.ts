import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { GridModule } from '../../modules/elements/grid/grid.module';
import { FormModule } from '../../modules/form/form.module';
import { ModalModule } from '../../modal/modal.module';
import { ButtonModule } from '../../modules/elements/button/button.module';
import { TypeAheadModule } from '../../modules/elements/type-ahead/type-ahead.module';
import { TypeAheadModalModule } from '../../forms/type-ahead/type-ahead-modal/type-ahead-modal.module';
import { TypeAheadNameListingModule } from '../../modules/elements/type-ahead-name-listing/type-ahead-name-listing.module';
import { ImageUploaderModule } from '../../modules/elements/image-uploader/imageUploader.module';
import { ImageUploaderService } from '../../services/image-uploader/image.service';
import { CompanyComponent } from '../../modules/company/company.component';

import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { DropDownTypeAheadModule } from '../../modules/elements/dropdown-typeahead/dropdown-typeahead.module'
import { NgxMaskModule } from '../../utils/ngx-mask/ngx-mask.module';

/**
 * The CreateEditCompaniesModule
 *
 * Module that contains all Create/Edit Companies related components.
 */
@NgModule({
  imports: [
    NgxMaskModule.forRoot(),
    TextMaskModule,
    CommonModule,
    ModalModule,
    ButtonModule,
    FormModule,
    FormsModule,
    GridModule.forRoot(),
    ReactiveFormsModule,
    TypeAheadModule.forRoot(),
    ModalModule.forRoot(),
    TypeAheadModalModule.forRoot(),
    TypeAheadNameListingModule.forRoot(),
    ImageUploaderModule,
    NgbModule,
    DropDownTypeAheadModule
  ],
  declarations: [CompanyComponent],
  exports: [
    CompanyComponent, TextMaskModule
  ],
  providers: [ImageUploaderService]
})
export class CompanyModule { }
