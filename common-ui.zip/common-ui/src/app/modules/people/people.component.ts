import { Component, OnInit, ElementRef, ViewChild, Input, Output, EventEmitter, TemplateRef } from '@angular/core';
import { TypeAheadDisplayResultModel } from '../../models/type-ahead/type-ahead-display-result.model';
import { TypeAheadEventService } from './../../services/events/type-ahead/type-ahead-event.service';
import { FormGroup, FormControl, AbstractControl, Validators, ValidatorFn, ValidationErrors } from '@angular/forms';
import { TypeAheadService } from '../../services/http/type-ahead/type-ahead.service';
import { TypeAheadModel } from '../../models/type-ahead/type-ahead.model';
import { CancelButtonModel } from './../../models/button/cancel-button/cancel-button.model';
import { AddButtonModel } from './../../models/button/add-button/add-button.model';
import { DropdownModel } from './../../models/dropdown/dropdown.model';
import { ImageUploaderModel } from './../../models/image-uploader/imageUploader.model';
import { CreateEditPeopleService } from './create-edit-people.service';
import { DatePipe } from '@angular/common';
import { NgbCustomDateFormatter } from './../../services/datepicker/ngb-custom-date-formatter.service';
import { NgbDateStruct, NgbDateAdapter, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { PeopleCompanyLocationsModel } from './../../models/people/data-model/people-company-locations-model';
import { PeopleAddressModel } from './../../models/people/data-model/people-address-model';
import { PeopleInputParamsModel } from './../../models/people/people-input-params.model';
import { PeopleOutputParamsModel } from './../../models/people/people-output-params.model';
import { TypeAheadSaveModel } from './../../models/type-ahead/type-ahead-save.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DropdownTypeAheadModel } from '../../models/dropdown-typeahead/dropdown-typeahead.model';
import { EmptyIfNull } from './../../../app/utils/strings/empty-if-null';
import { AddAliasModel } from './../../models/type-ahead/aka/add-alias.model';
import { AddAliasAKAModel } from './../../models/type-ahead/aka/add-alias-aka.model';
import { CompaniesLocationsModel } from '../../models/company/data-model/company-locations-model';
import { PhoneMediaModel } from '../../models/company/data-model/phone-type-model';
import { CompaniesDetailModel } from '../../models/company/data-model/companies-detail-model';

declare var $: any;

@Component({
  selector: 'c2c-people-component',
  templateUrl: './people.component.html',
  styleUrls: ['./people.component.scss'],
  providers: [DatePipe, CreateEditPeopleService, TypeAheadService,
    { provide: NgbDateParserFormatter, useClass: NgbCustomDateFormatter }
  ]
})

export class PeopleComponent implements OnInit {
  @ViewChild('typeAheadCompanySelectorId') typeAheadCompanySelectorId: any;
  @ViewChild('typeAheadCompanySelectorHeader') typeAheadCompanySelectorHeader: any;
  @ViewChild('typeAheadAsstSelectorHeader') typeAheadAsstSelectorHeader: any;
  
  @ViewChild('typeAheadPeopleModalSave') typeAheadModal: any;
  @ViewChild('typeAheadPeopleAssistantModalSave') typeAheadAssistantModal: any;
  @ViewChild("myLocationModal") public myLocationModal: TemplateRef<any>;

  @ViewChild('accentedModal') accentedModal: any;
  @ViewChild('typeAheadPeopleSelectorID') private typeAheadField: ElementRef;
  @ViewChild('addNameCompanyComponentModal') addNameCompanyComponentModal: any;
  @ViewChild('assistantAccentedModal') private assistantAccentedModal: any;

  @Input() inputParams: PeopleInputParamsModel;
  @Input() public peopleNameDuplicateAlert: boolean = true;
  @Input() public companyNameDuplicateAlert: boolean = true;
  @Input() public AssistantNameDuplicateAlert: boolean = true;

  @Output() public cancelEvent: EventEmitter<PeopleOutputParamsModel> = new EventEmitter<PeopleOutputParamsModel>();
  @Output() public saveEvent: EventEmitter<PeopleOutputParamsModel> = new EventEmitter<PeopleOutputParamsModel>();
  @Output() public onValEdit = new EventEmitter<any>();
  public outputParams: PeopleOutputParamsModel;

  public mask = ['(', /[0-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];

  public imageUpload: ImageUploaderModel;
  public selectedImageValue: string;
  private pageEdited: boolean = true;

  public newCompanyLocationId: number;
  public newCompanyName: string = null;
  public newCompanyAddress: string = null;
  public newCompanyLocation: any = null;
  public companyList: Array<any> = [];
  public companyDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public selectedCompanyPartyId: number;
  public addedCompany: boolean = false;

  public selectedAsstPartyId: number;
  public addedAssistant: boolean = false;
  public focusFirst: boolean = true;

  companyForm = new FormGroup({
    compName: new FormControl(''),
    compLocation: new FormControl(''),
    compAddress: new FormControl('')
  });

  public loading = false;
  public dobMinDate = { year: 1950, month: 1, day: 1 };
  public dobMaxDate = { year: 2018, month: 1, day: 1 };
  public dobValidationResultMsg: string = "Enter a valid date";
  public form: FormGroup;
  private peopleId: number = 0;
  public isEdit: boolean = false;
  public newPhoneNo: string = '';
  public newEmail: string = '';
  public newSMedia: string = '';
  public typeAheadDataService: any;
  public occupationList: Array<any> = [];
  public typeList: Array<any> = [];
  public phoneList: Array<any> = [];
  public eMailList: Array<any> = [];
  public sMediaList: Array<any> = [];
  public assistantList: Array<any> = [];
  public phoneType: any = '';
  public editedPhonetype: any = '';
  public emailType: any = '';
  public editedemailType: any = '';
  public socialmediaType: any = '';
  public editedsocialmediaType: any = '';
  public newAssistant: string = null;
  public newAsstData: any = null;
  public selectedtype: any = '';
  public neveremailStatus: boolean = true;
  public occupationSelected: any = '';
  public peopleNotes: string = '';
  public peopletitle: string = '';
  public peopleName: string = '';
  public dob: any;
  public dobTemp: any

 //  popup save button validation flags //
  public disableTypeAheadSave: boolean = true;
  public disableTypeAheadLoc: boolean = true;
 //--------------//

  public countryTyped: string = '';
  public stateTyped: string = '';
  public typeTyped: string = '';

  public choosenDispName : any;
  public listOfAlias : any = [];

  // This needs to be unique in order to open one accented modal when we have more than 2 type ahead in same page
  public accentedModalName = 'talentAccentedPeopleComponent';

  public tempDob: any = null;
  public validDOB: boolean = true;

  dob_final: any;
  ocupationmodel: any = ''
  name_error_msg: boolean = false;
  notes_error_msg: boolean = false;
  typelist_error_msg: boolean = false;

  public recordtype: string;
  public phonePrimaryradio: boolean = true;
  public emailPrimaryradio: boolean = true;
  public sMediaPrimaryradio: boolean = true;
  public assistantPrimaryRadio: boolean = true;
  public show_phone_null_errormsg: boolean = false;
  public peopleData: any = [];
  public typeAheadFocus: boolean = true;

  public partyId: number;
  public addedOccupationJson = { "occupations": [] };
  public addedTypeJson = { "types": [] };
  public addedSocialMediaJson = { "socialMedias": [] };
  public saveNameTalentEvn: any;
  public selectedDisplayName: string = null;
  public validPeopleName: boolean = true;

  public selectedPhoneType: any;
  public selectedPhoneNumber: string;
  public selectedPrimaryFlagN: boolean;
  public addPhoneButOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Phone');
  public addedPhoneJson = { "phone": [] };
  public locationsId: number;
  public isOpen: boolean;
  public selectedLocationName: string;
  public selectedAddressFirstLine: string = '';
  public selectedAddressSecondLine: string = '';
  public selectedAddressThirdLine: string = '';
  public editSelectedStateId: string;
  public editSelectedCountryId: string;
  public selectedLocationCity: string = '';
  public selectedPostal: string = "";
  public selectedCountryBuffer:string;
  public validLocationName: boolean = true;
  public isValidLoca: boolean = false;
  public locationAddressObject: object;
  public addedLocationAddressArray = [];
  public selectedlocationPrimary: boolean;
  public concatinatedAddress: string;
  public existingLocationArray = [];
  public validInputPhone: boolean = true;
  public validInputPhoneType: boolean = false;
  public AddedLocations = { "loc": [] };
  public locationFlag: any;
  public flagI = 0;
  public selectedLocationCountry: any = {
    value: null,
    id: null
  }

  public selectedLocationState: any = {
    value: null,
    id: null
  }

  public serviceDelayLoading: boolean = true

  public typeAheadModalCompanyConfig: any = {
    title: 'Add New Company name',
    label: 'This is a label',
    showAddAlias: false,
    displayNameAs: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'modalRollCallCompanyName',
    hideTypeAhead: true
  };

  public typeAheadModalConfig: any = {
    title: 'Add New Person name',
    label: 'This is a label',
    showAddAlias: false,
    displayNameAs: true,
    additionalFieldsDisplayed: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'modalRollCallHeaderName',
    hideTypeAhead: true
  };

  public typeAheadModalAssistantConfig: any = {
    title: 'Add New Assistant name',
    label: 'This is a label',
    showAddAlias: false,
    displayNameAs: true,
    additionalFieldsDisplayed: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'modalRollCallAssistantHeader',
    hideTypeAhead: true
  };

  public cancelButtonOptions: CancelButtonModel;
  public businessPersonalradio: any = [];

  public occupationDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);

  public typeDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public phoneDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public phoneDropdownSub: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public phoneDropdownForPopup: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);

  public emailDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public socialMediaDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public emailDropdownSub: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public socialMediaDropdownSub: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);

  public addOccupationButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Occupation');
  public addTypeButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Type');
  public addPhoneButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Phone');
  public addAssistantButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Assistant');
  public addAddressButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Address');
  public addEmailButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Email');
  public addsocialMediaButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Social Media');
  public addCompanyOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add Company')
  public disabledSave: boolean = true;
  public companyEntityTypes: any[];

  public actualBaseImageURL: string;
  //Address grid
  public selectStateAddDropdown = new DropdownTypeAheadModel('', '', '', '', []);
  public selectCountryAddDropdown = new DropdownTypeAheadModel('', 'United States', '', '', []);
  public selectTypeAddDropdown = new DropdownTypeAheadModel('', '', '', '', []);
  public pickListData: any;
  public selectedAddress: string;
  public selectedCity: string;
  public selectedZip: string;
  public selectedCountry: any = {
    value: null,
    id: null
  }
  public selectedState: any;
  public selectedAddressType: any = {
    value: null,
    id: null
  }
  public addedAddressList: any = { "address": [] };
  public selectedPrimaryAddFlag;
  public validAddress: boolean = true;
  public addDisableFlag: boolean = false;
  public addressId: number;
  public locName: string = null;
  public companiesId: number;
  public companiesDisplayName: string;
  public listContact: Array<object> = [];
  public isAddNew: boolean = false;
  private listTalent: Array<object> = [];
  public oneTimeCall: boolean = true;
  public locationAction: string = "";
  public companyData: CompaniesDetailModel;
  public selectedName: any;
  private talentSelected: any;
  public isCompanyEdit: boolean = false;
  public tempAddressType: any = [];
  public tempCountryType: any = [];

  // Data for initial load
  public peopleParamModel: PeopleInputParamsModel;
  public peopleDummyData: any; //PeopleModel;

  //Handle address and company location's actions
  public companyLocAdd: boolean = false;
  public companyLocEdit: boolean = false;
  public companyLocAddInEdit: boolean = false; // /Add new location in company loc edit mode if NO location exists already
  public addressLocAdd: boolean = false;
  public addressLocEdit: boolean = false;
  public primaryLocation: boolean = false;
  public selectedAddressIndex: number = -1;
  public formCompanyTypeAhead: FormGroup;  

  //RC-1382 - Company location address edit changes
  public selectedCompanyLocAddress: any;
  public selectedCompanyPrimary: boolean;
  public companyLocEditDropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public selectedCompanyIndex: number = -1;
  public resetRequired: boolean = true;
  public companyDropdownEmpty: boolean = false;
  public companyLocSelectOnEdit: boolean = false;
  public companyAddLocationEdit: boolean = false;

  public selectedCompanyForEdit: any;

  public closeDropdown = false;

  /**Property to show/hide typeAhead in Talent component */
  public showTypeAhead: boolean = false;
  public rollCallModeTitle: string = '';
  public rollCallListNameResult: any;
  /**Property to show/hide addname button */
  public typeAheadAddSameName: boolean = true;
  /**Property to disable DB seaching */
  public disableSearchName: boolean = false;
  public hasNoResultsCallback: boolean = false;
  
  public listNameTitle: string = 'Click radio button to indicate current name';
  public typeAheadTitle = 'Type name to search and press enter';

  public locationPhoneJsonFromDB = { "phone": [] };
  public primay_location_name: string = "Primary";

  //Changes to introduce Address Type in Input section
  public selectedInputAddressType: any = {
    value: null,
    id: null
  }
  public inputAddrTypeDropdown = new DropdownTypeAheadModel('', '', '', '', []);

  public occupationJson = {
    "occupations": [
      { "id": 1, "value": "occupation1" },
      { "id": 2, "value": "occupation2" },
      { "id": 3, "value": "occupation3" },
      { "id": 4, "value": "occupation4" },
      { "id": 5, "value": "occupation5" },
      { "id": 6, "value": "occupation6" },
      { "id": 7, "value": "occupation7" }
    ]
  }
  public typeJson = {
    "types": [
      { "id": 1, "value": "type1" },
      { "id": 2, "value": "type2" },
      { "id": 3, "value": "type3" },
      { "id": 4, "value": "type4" },
      { "id": 5, "value": "type5" }
    ]
  }
  public entityTypeJson = {
    "entityTypes": [
      { "id": 1121, "value": "Business", "abbreviation": "Business" },
      { "id": 1122, "value": "Personal", "abbreviation": "Personal" }
    ]
  }

  public entityTypeCompaniesJson = {
    "entityTypes": [
      { "id": 1084, "value": "Company", "abbreviation": "Company" },
      { "id": 1085, "value": "Film Project", "abbreviation": "Film Project" },
      { "id": 1086, "value": "TV Series", "abbreviation": "TV Series" }
    ]
  }

  public socialMediaJson = {
    "socialMedias": [
      { "id": 1, "value": "media1" },
      { "id": 2, "value": "media2" },
      { "id": 3, "value": "media3" },
      { "id": 4, "value": "media4" },
      { "id": 5, "value": "media5" }
    ]
  }
  public phoneJson = {
    "phones": [
      { "id": 1, "value": "phone1" },
      { "id": 2, "value": "phone2" },
      { "id": 3, "value": "phone3" },
      { "id": 4, "value": "phone4" },
      { "id": 5, "value": "phone5" }
    ]
  }


  public companyJson = {
    "companies": [
      { "id": 1, "value": "comp1" },
      { "id": 2, "value": "comp2" },
      { "id": 3, "value": "comp3" },
      { "id": 4, "value": "comp4" },
      { "id": 5, "value": "comp5" }
    ]
  }


  public countryJson = {
    "countries": [
      { "id": 1, "value": "country1" },
      { "id": 2, "value": "country2" },
      { "id": 3, "value": "country3" },
      { "id": 4, "value": "country4" },
      { "id": 5, "value": "country5" }
    ]
  }

  public addressJson = {
    "address": [
      { "id": 1, "value": "address1" },
      { "id": 2, "value": "address2" },
      { "id": 3, "value": "address3" },
      { "id": 4, "value": "address4" },
      { "id": 5, "value": "address5" }
    ]
  }

  public stateJson = {
    "states": [
      { "id": 0, "value": "" },
      { "id": 1, "value": "state1" },
      { "id": 2, "value": "state2" },
      { "id": 3, "value": "state3" },
      { "id": 4, "value": "state4" },
      { "id": 5, "value": "state5" }
    ]
  }

  public emailJson = {
    "email": [
      { "id": 0, "value": "" },
      { "id": 1, "value": "email1" },
      { "id": 2, "value": "email2" },
      { "id": 3, "value": "email3" },
      { "id": 4, "value": "email4" },
      { "id": 5, "value": "email5" }

    ]
  }

  public emptyPeoplJsonData = {
    "partyId": null, "firstName": null, "lastName": null, "imageURL": null, "image": null, "createdBy": null, "createdDate": null, "createdTime": null,
    "updatedBy": null, "updatedDate": null, "updatedTime": null, "businessPersonal": "Business", "entityTypeId": null, "dob": null, "neverEmail": false,
    "notes": null, "types": null, "addresses": null, "officeAddress": null, "homeAddress": null, "socialMedia": null, "deleteImage": false, "dataSet": null, "title": null, "AKA": null,
    "phone": null, "email": null, "occupations": null, "assistants": null, "companies": null
  }

  // People Name TypeAhead setup
  public displayPeopleDataResults: TypeAheadDisplayResultModel = {
    filterType: 'CONTACT_ONLY',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'partyType'],
      display: '`${data.primaryName ?` (alias for ${data.primaryName}) `:` (team of ${data.teamMembers})`}`',
      notAllColumnsRequired: true
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'ssnEndChars']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this.typeAheadService,
      get: 'get'
    }
  };

  // Assistant TypeAhead setup
  public displayAssistantDataResults: TypeAheadDisplayResultModel = {
    filterType: 'CONTACT_ONLY',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'partyType'],
      display: '`(alias for ${data.primaryName})`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'ssnEndChars']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this.typeAheadService,
      get: 'get'
    }
  };

  // Company TypeAhead setup
  public displayCompanyDataResults: TypeAheadDisplayResultModel = {
    filterType: 'COMPANY_ONLY',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'partyType'],
      display: '`(alias for ${data.primaryName})`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'ssnEndChars']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this.typeAheadService,
      get: 'get'
    }
  };

  public countryDropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, this.countryJson.countries);
  public stateDropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, this.stateJson.states);
  public state: boolean = false;
  public stateCheck: boolean = false;

  public peopleComponentForm = new FormGroup({
    dobTemp: new FormControl('')
  });

  public maxDate = new Date();
  public maxDateValue: string;
  public phoneKeydownCount: number = 0;
  public errortoastermessage:string="";


  constructor(private typeAheadEventService: TypeAheadEventService, public typeAheadService: TypeAheadService,
    public CreateEditPeopleService: CreateEditPeopleService, private datePipe: DatePipe, private modalService: NgbModal) {
    var peoplJsonData = { "partyId": 1979476, "firstName": "Diane", "lastName": "Hardy", "imageURL": "http://dev.concept2alize.com/rc/dev/talent/party/1979476/image", "image": null, "createdBy": "default", "createdDate": "09/17/2018", "createdTime": "14:42", "updatedBy": "default", "updatedDate": "09/17/2018", "updatedTime": "14:42", "businessPersonal": "Personal", "entityTypeId": 1122, "dob": "03/01/1983", "neverEmail": false, "notes": "A laudantium pariatur ea velit consequatur earum. Est molestias quibusdam ducimus sapiente. Labore quaerat aut omnis velit fugiat.", "types": [{ "id": 3620, "name": "Packaging", "typeId": 36, "partyId": 1979476 }], "addresses": [{ "addressId": 3088, "locationName": null, "addressType": "Vacation", "firstLine": "1322 Shepherd Heights", "secondLine": null, "thirdLine": null, "city": "Cairo", "state": "Virginia", "zip": "80204", "country": "USA", "primary": true }], "officeAddress": { "addressId": 2960, "locationName": "Castelbianco HQ", "addressType": null, "firstLine": "Ap #247-5924 Ridiculus Road", "secondLine": "Aptent Road", "thirdLine": null, "city": "Kearny", "state": "Alabama", "zip": "96219", "country": "USA", "primary": null }, "homeAddress": null, "socialMedia": [{ "id": 1040884, "contactId": 2293, "value": "#DianeHardy", "primary": true, "typeId": 1108, "type": "Facebook", "displayValue": "#DianeHardy - Facebook*" }], "deleteImage": false, "dataSet": null, "title": "Global Executive", "AKA": null, "phone": [{ "id": 1131558, "contactId": 2292, "value": "(802) 043-2112", "primary": true, "typeId": 1178, "type": "Home/Fax", "displayValue": "(802) 043-2112 - Home/Fax*" }], "email": [{ "id": 1040883, "contactId": 2291, "value": "bmosley@ma1lbox.com", "primary": true, "typeId": 1061, "type": "Home 2", "displayValue": "bmosley@ma1lbox.com - Home 2*" }], "occupations": [{ "id": 1704165, "occupationId": 271, "partyId": 1979476, "occupationName": "Supervising Producer" }], "assistants": [{ "relationId": 1396517, "parentPartyId": 1979476, "partyId": 1714639, "name": "SA, ERNESTINA", "primary": true, "relationType": null, "_links": { "self": { "href": "http://localhost:4200/rc/dev/talent/rollcall/person/1714639" } } }], "companies": [{ "partyId": 1979185, "companyName": "20th Century Fox Pictures", "locationId": 1893, "partyRelationId": 1396518, "primary": true, "location": { "addressId": 2960, "locationName": "Castelbianco HQ", "addressType": null, "firstLine": "Ap #247-5924 Ridiculus Road", "secondLine": "Aptent Road", "thirdLine": null, "city": "Kearny", "state": "Alabama", "zip": "96219", "country": "USA", "primary": null }, "_links": { "self": { "href": "http://localhost:4200/rc/dev/talent/rollcall/company/1979185" } } }] }

    let partyId = 1979476;
    let firstName = "Diane";
    let lastName = "Hardy";
    let imageURL = "http://dev.concept2alize.com/rc/dev/talent/party/1979476/image";
    let image = null;
    let createdBy = "default";
    let createdDate = "09/17/2018";
    let createdTime = "14:42";
    let updatedBy = "default";
    let updatedDate = "09/17/2018";
    let updatedTime = "14:42";
    let businessPersonal = "Business";
    let entityTypeId = 1121;
    let dob = "03/01/1983";
    let neverEmail = false;
    let notes = "A laudantium pariatur ea velit consequatur earum.";
    let types = [{ "id": 3620, "name": "Packaging", "typeId": 36, "partyId": 1979476 }];
    let addresses = [{ "addressId": 3088, "locationName": null, "addressType": "Vacation", "firstLine": "1322 Shepherd Heights", "secondLine": null, "thirdLine": null, "city": "Cairo", "state": "Virginia", "zip": "80204", "country": "USA", "primary": true }];
    let officeAddress = { "addressId": 2960, "locationName": "Castelbianco HQ", "addressType": null, "firstLine": "Ap #247-5924 Ridiculus Road", "secondLine": "Aptent Road", "thirdLine": null, "city": "Kearny", "state": "Alabama", "zip": "96219", "country": "USA", "primary": null };
    let homeAddress = null;
    let socialMedia = [{ "id": 1040884, "contactId": 2293, "value": "#DianeHardy", "primary": true, "typeId": 1108, "type": "Facebook", "displayValue": "#DianeHardy - Facebook*" }];
    let deleteImage = false;
    let dataSet = null;
    let title = "Global Executive";
    let AKA = null;
    let phone = [{ "id": 1131558, "contactId": 2292, "value": "(802) 043-2112", "primary": true, "typeId": 1178, "type": "Home/Fax", "displayValue": "(802) 043-2112 - Home/Fax*" }];
    let email = [{ "id": 1040883, "contactId": 2291, "value": "bmosley@ma1lbox.com", "primary": true, "typeId": 1061, "type": "Home 2", "displayValue": "bmosley@ma1lbox.com - Home 2*" }];
    let occupations = [{ "id": 1704165, "occupationId": 271, "partyId": 1979476, "occupationName": "Supervising Producer" }];
    let assistants = [{ "relationId": 1396517, "parentPartyId": 1979476, "partyId": 1714639, "name": "SA, ERNESTINA", "primary": true, "relationType": null, "_links": { "self": { "href": "http://localhost:4200/rc/dev/talent/rollcall/person/1714639" } } }];
    let companies = [{ "partyId": 1979185, "companyName": "20th Century Fox Pictures", "locationId": 1893, "partyRelationId": 1396518, "primary": true, "location": { "addressId": 2960, "locationName": "Castelbianco HQ", "addressType": null, "firstLine": "Ap #247-5924 Ridiculus Road", "secondLine": "Aptent Road", "thirdLine": null, "city": "Kearny", "state": "Alabama", "zip": "96219", "country": "USA", "primary": null }, "_links": { "self": { "href": "http://localhost:4200/rc/dev/talent/rollcall/company/1979185" } } }];

    this.peopleDummyData = peoplJsonData;

    let occupationDropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, this.occupationJson.occupations);
    let typeDropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, this.typeJson.types);
    let socialMediaDropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, this.socialMediaJson.socialMedias);
    let phoneDropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, this.phoneJson.phones);
    let addressDropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, this.addressJson.address);
    let emailDropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, this.emailJson.email);

    let entityTypeOptions = this.entityTypeJson.entityTypes;

    let entityCompaniesTypeOptions = this.entityTypeCompaniesJson.entityTypes;

    this.inputParams = new PeopleInputParamsModel(peoplJsonData, occupationDropdownModel, typeDropdownModel, this.displayPeopleDataResults,
      this.displayCompanyDataResults, occupationDropdownModel, entityTypeOptions, entityCompaniesTypeOptions, phoneDropdownModel, emailDropdownModel,
      socialMediaDropdownModel, this.displayAssistantDataResults, addressDropdownModel, this.stateDropdownModel, this.countryDropdownModel, null, null);

    if (this.peopleId == null) {
      this.isEdit = false;
      this.cancelButtonOptions = new CancelButtonModel('', '', '', '');
    }
    else {
      this.isEdit = true;
      this.showTypeAhead = true;
      this.cancelButtonOptions = new CancelButtonModel('', '', '', '');
    }

    this.typeAheadEventService.getitemAddedToList().subscribe(item => {
      if (item.listName === "AssistantMainList") {
        this.assistantList.push(item.item);
      }
    });

    this.typeAheadEventService.getRemoveItemList().subscribe(item => {

      if (item.item && item.item.selectedItemInList) {
        this.talentSelected = {};
      }

      this.oneTimeCall = true;
      this.removeListItem(item.item, item.listName); // Remove typeAhead values

      let delindex  = this.listOfAlias.findIndex(i => i.name.nameId == item.item.nameId);
      this.listOfAlias.splice(delindex, 1);
    });

    this.typeAheadEventService.getCurrentItemSelected().subscribe(item => {
      if (item.item && item.listName === 'mainListPeopleComponent') {
        this.disabledSave = false;
        this.peopleName = item.item.typeAheadDisplayName;
        this.name_error_msg = false;
        this.updateTitle(item.item);
      }
    });

    //Select the input primary radio button as selected when there is no entry in that list
    if (null != this.addedAddressList && this.addedAddressList.address.length == 0) {
      this.selectedPrimaryAddFlag = true;
    }
    this.maxDateValue = this.datePipe.transform(this.maxDate.toDateString(), 'MM/dd/yyyy'); // Prevent to select future date, since its a DOB
  }

  // TODO: This need to bew removed
  private updateNames(selectedName: any, avoidNames?: boolean): void {
      if (!avoidNames) {
        this.inputParams.service.serviceClass[this.inputParams.service.getNames](selectedName.partyId).subscribe((data) => {
          this.setNames(data, selectedName);
        });
      }
  }

  private setNames(names: Array<any>, selectedName: any): void {
    this.typeAheadEventService.removeListItems('mainList');
    this.listTalent.splice(0, this.listTalent.length);
    let selectedItem: TypeAheadModel;
    names.forEach((element, index) => {
      const talentListData: TypeAheadModel = new TypeAheadModel();
      talentListData.entityName = element.name.entity;
      talentListData.firstName = element.name.first;
      talentListData.partyId = element.partyId;
      talentListData.nameId = element.name.nameId;
      talentListData.selectedItemInList = this.selectedName.typeAheadDisplayName.trim() === element.displayName.trim();
      talentListData.typeAheadDisplayName = element.displayName;
      if (talentListData.selectedItemInList === true) {
        selectedItem = talentListData;
      }
      this.updateTitle(selectedItem);
      this.listTalent.push(talentListData);
    });

    this.typeAheadEventService.listNameToLook('mainListPeopleComponent');
    this.typeAheadEventService.populateList(this.listTalent);
    this.typeAheadEventService.currentItemSelected({ item: selectedItem, listName: 'mainListPeopleComponent' });
  }

  /**
  * This function removes items in list for all list
  * @param item object depending what item will be remove in list
 */
  private removeListItem(item: any, listName: string): void {

    if (item.listName == "AssistantMainList") {
      this.assistantList.forEach((item1, ForEachindex) => {
        if (item.partyId == item1.partyId) {
          this.assistantList.splice(ForEachindex, 1);
        }
      });
    }

    let index = -1;
    if (listName === 'mainListPeopleComponent') {
      this.listTalent.forEach((element, key) => {
        index = (index === -1 && element['partyId'] === item['partyId'] &&
          element['typeAheadDisplayName'] === item['typeAheadDisplayName']) ? key : index;
      });
      if (index > -1) {
        this.listTalent.splice(index, 1);
      }
      if (this.listTalent.length === 0) {
        this.disabledSave = true;
        this.peopleName = ""
        this.peopleId = null;
        this.imageUpload = new ImageUploaderModel("people", null);
        this.loadPeopleData(this.emptyPeoplJsonData);
      }
    }
    this.typeAheadField['setTypeAheadFocus']();
  }

  /**
  * This function sets response from service save talent record to all fields
  *
  * @param data object selected in Status Dropdown
  */
  private setFieldsValues(data: any): void {
    // Getting data form service for talene current name
    if (this.listTalent.length === 0) {
      data.names.PRIMARY.forEach((element, index) => {
        const talentListData: TypeAheadModel = new TypeAheadModel();
        talentListData.entityName = element.name.entity;
        talentListData.firstName = element.name.first;
        talentListData.middleName = element.name.middle;
        talentListData.suffix = element.name.suffix;
        talentListData.partyId = data.id;
        talentListData.nameId = element.name.nameId;
        talentListData.selectedItemInList = true;
        talentListData.typeAheadDisplayName = element.name.fullName;
        this.listTalent.push(talentListData)
        this.selectedName = talentListData;
        this.typeAheadEventService.currentItemSelected({ item: talentListData, listName: 'mainListPeopleComponent' });
        this.updateTitle(talentListData);
      });

      // Getting data form service for talene current AKAs
      if (data.names.AKA) {
        data.names.AKA.forEach((element, index) => {
          const talentListData: TypeAheadModel = new TypeAheadModel();
          talentListData.entityName = element.name.entity;
          talentListData.firstName = element.name.first;
          talentListData.middleName = element.name.middle;
          talentListData.suffix = element.name.suffix;
          talentListData.partyId = data.id;
          talentListData.nameId = element.name.nameId;
          talentListData.selectedItemInList = false;
          talentListData.typeAheadDisplayName = element.name.fullName;
          this.listTalent.push(talentListData);
        });
      }
      // Populate talent record list with data from service response
      this.typeAheadEventService.listNameToLook('mainListPeopleComponent');
      this.typeAheadEventService.populateList(this.listTalent);
    }
  }

  // unSavedContent - For unSaved changes confirmation
  public openGenericImageModal(unSavedContent) {
    this.modalService.open(unSavedContent);
  }

  public openGenericImageModalCancel(unSavedContent){
    let modalRef = this.modalService.open(unSavedContent);
    this.TrapFocusDuplicateAlertModal();
    modalRef.result.then((data) => {
        if(data == "proceed"){
          this.onValEdit.emit(false);
        }else{
          this.onValEdit.emit(true);
        }
      }, (reason) => {
        console.log("reason", reason);
      });
  }

  //Image common component integration
  selectedImage(evt: Event) {
    if (evt == null) {
      this.onPageEdit();
      this.actualBaseImageURL = "deleted";
    } else {
      this.selectedImageValue = evt.toString()
      this.actualBaseImageURL = this.selectedImageValue.substr(23);
      if (this.selectedImageValue.length > 200) {
        this.onPageEdit();
      }
    }
  }

  public validateCompany() {
    var itemExists: boolean;
    if (this.newCompanyName != '') {
      if (this.newCompanyName) {
        itemExists = this.companyList.find(i => i.partyId == this.selectedCompanyPartyId);
      }
    }
    return itemExists;
  }
  public dobBlurEvent(evt){
    var dateReg = /^\d{2}([./-])\d{2}\1\d{4}$/
    var dateSelected = evt.target.value;
    var CurrentDate = new Date();
    var GivenDate = new Date(dateSelected);
    if(dateSelected.match(dateReg)){
        if(GivenDate > CurrentDate){
            this.validDOB = false;
            this.dobValidationResultMsg = "Date Of Birth cannot be a future date.";
        }else{
            this.validDOB = true;
        }
    }else{
        if(dateSelected == ""){
            this.validDOB = true;
        }else{
            this.validDOB = false;
            this.dobValidationResultMsg = "Enter a valid date.";
        }
        
    }
  }
  public validateDOB(evt) {
    // var date = event;
    this.dobTemp = this.datePipe.transform(evt, 'MM/dd/yyyy'); 
    // if (date) {
    //   if ((date.day) && (date.month) && (date.year)) {
    //     if (date.year <= this.dobMaxDate.year) {
    //       if (date.year == this.dobMaxDate.year) {
    //         if (date.month <= this.dobMaxDate.month) {
    //           if (date.month == this.dobMaxDate.month) {
    //             if (date.day <= this.dobMaxDate.day) {
    //               this.validDOB = true;
    //               this.dobValidationResultMsg = "Enter a valid date.";
    //             }
    //             else {
    //               this.validDOB = false;
    //               this.dobValidationResultMsg = "Date Of Birth cannot be a future date.";
    //             }
    //           }
    //           else {
    //             this.validDOB = true;
    //             this.dobValidationResultMsg = "Enter a valid date.";
    //           }
    //         }
    //         else {
    //           this.validDOB = false;
    //           this.dobValidationResultMsg = "Date Of Birth cannot be a future date.";
    //         }
    //       }
    //       else {
    //         this.validDOB = true;
    //         this.dobValidationResultMsg = "Enter a valid date.";
    //       }
    //     }
    //     else {
    //       this.validDOB = false;
    //       this.dobValidationResultMsg = "Date Of Birth cannot be a future date.";
    //     }
    //   }
    //   else {
    //     this.validDOB = false;
    //     this.dobValidationResultMsg = "Enter a valid date.";
    //   }
    // } else {
    //   this.validDOB = true;
    //   this.dobValidationResultMsg = "Enter a valid date.";
    // }

  }

  public formatDateSet() {
    this.dob = this.datePipe.transform(this.dobTemp, 'MM/dd/yyyy');
  }


  // Generate random number for appending it in image url to avoid cache issue
  getRandomNumber(i: number) {
    let random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    return random;
  }

  ngOnInit() {

    $(document).on("keydown", "#cancel-button", function (evt) {
      if (evt.keyCode == 13) {
        $("#cancel-button").trigger("click");
      }
    })

    this.formCompanyTypeAhead = new FormGroup({
      typeAheadSelector_company: new FormControl('')
    });

    this.serviceDelayLoading = true;
    this.loadPeopleData(this.inputParams.peopleData);
    setTimeout(() => {
    var elmnt = document.getElementById("addEditPeopleCard");
    elmnt.scrollTop = 0;
    }, 500);
    this.onChange(); // TypeAhead changes notify in this method
  }

  private onChange():  void  {
    //company/project typeAhead onchange functionality goes here
    const typeAheadSelector_company:  AbstractControl  =  this.formCompanyTypeAhead.get('typeAheadSelector_company');
    typeAheadSelector_company.valueChanges.subscribe(val  =>  {
      if(val === ""){
        this.clearLocation(); // reset the location change
      }
    });
  } 

  loadPeopleData(peopleDataValue: any) {

    this.getDropdownLookupData();

    if (null !== this.inputParams) {
      this.displayPeopleDataResults = this.inputParams.peopleTypeAheadOptions
      this.displayCompanyDataResults = this.inputParams.companyTypeAheadOptions;
      this.displayAssistantDataResults = this.inputParams.assistantTypeAheadOptions;
    }

    if ((null !== this.inputParams) && (null !== this.inputParams.peopleData)) {
      this.peopleId = this.inputParams.peopleData.partyId;
    }
    this.businessPersonalradio = this.inputParams.entityTypeOptions;
    console.log("this.businessPersonalradio", this.businessPersonalradio);

    this.setDobMaxMonth();
    if (this.peopleId != undefined || peopleDataValue != null) {
      //  Getting data from service to display in edit
      this.peopleId = peopleDataValue.partyId;
      this.peopleData = peopleDataValue;

      if (this.peopleId != null && this.oneTimeCall == true) {
        // Call this to load the typeAhead listing
        this.oneTimeCall = false;
        this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](this.peopleId)
          .subscribe(
            (data) => {
              this.serviceDelayLoading = false;
              this.getAllDisplayNames(data);
              this.setFieldsValues(data['party']);
            },
            (err) => {
              console.log('error', err);
            });
      }

      if (this.peopleId == null || this.peopleId == undefined){
        this.serviceDelayLoading = false;
      }
      
      // This condition is to avoid data lose while refresh the screen
      if (this.peopleData.length === 0) {

        var obj = JSON.parse(sessionStorage.getItem("COMMON_PEOPLE_DATA"))
        this.peopleData = obj;
        this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](this.peopleData.partyId)
        .subscribe(
          (data) => {
            this.serviceDelayLoading = false;
            this.getAllDisplayNames(data);
            this.setFieldsValues(data['party']);
          },
          (err) => {
            console.log('error', err);
          });

        this.mappingEditPerson();


      } else {
        sessionStorage.removeItem("COMMON_PEOPLE_DATA");
        sessionStorage.setItem("COMMON_PEOPLE_DATA", JSON.stringify(this.peopleData));
        this.mappingEditPerson();
      }
    }
    else {
      this.imageUpload = new ImageUploaderModel("people", null);
    }

    this.form = new FormGroup({
      'typeAheadPeopleSelector': new FormControl(),
      'typeAheadAsstSelector': new FormControl(),
      'typeAheadCompanySelector': new FormControl()
    });

    this.peopleData = this.inputParams.peopleData;

    setTimeout(() => {
      this.tempCountryType = this.selectCountryAddDropdown.options;
      if(this.tempCountryType && this.tempCountryType[0]) {
        this.selectCountryAddDropdown.dropdownValue = this.tempCountryType[0].value;
        this.selectCountryAddDropdown.selection = "value";
        this.selectCountryAddDropdown.title = this.tempCountryType[0].value;
      }   
      this.tempAddressType = this.selectTypeAddDropdown.options;
      if(this.tempAddressType && this.tempAddressType[0]) {
        this.selectTypeAddDropdown.dropdownValue = this.tempAddressType[0].value;
        this.selectTypeAddDropdown.selection = "value";
        this.selectTypeAddDropdown.title = this.tempAddressType[0].value;
      }
    }, 2000);
  }

  mappingEditPerson() {
    if (this.peopleData.imageURL != null) {
      this.imageUpload = new ImageUploaderModel("people", this.peopleData.imageURL + "?" + this.getRandomNumber(1));
    } else {
      if (this.isAddNew == false) {
        this.imageUpload = new ImageUploaderModel("people", null);
      }
    }

    this.setCompanyList();

    this.partyId = this.peopleData.partyId;
    var editdata_response = this.CreateEditPeopleService.createEditJson(this.peopleData.email, this.peopleData.phone, this.peopleData.occupations, this.peopleData.assistants, this.peopleData.socialMedia, this.peopleData.types)
    this.occupationList = editdata_response.occupationslist;
    this.phoneList = editdata_response.phonelist;
    this.typeList = editdata_response.typelist;
    this.eMailList = editdata_response.emaillist;
    this.sMediaList = editdata_response.socialmedia;
    this.assistantList = editdata_response.assistants;
    this.peopleNotes = this.peopleData.notes;
    this.peopletitle = this.peopleData.title;

    this.addedAddressList.address = this.peopleData.addresses;
    if (this.addedAddressList.address != null) {
      this.selectedPrimaryAddFlag = false;
    }
    // @author Amit Yogi: No need to check the peopleId if we are extracting data from people Data
    /**
     * I am  passing first Name and Last Name to add a new Person but I don't have peopleId which is null in my case so Its break my condition*/
    if (this.peopleData.partyId) {
      if (this.peopleData.firstName == null && this.peopleData.lastName != null) {
        this.peopleName = this.peopleData.lastName;
      } else if (this.peopleData.firstName != null && this.peopleData.lastName == null) {
        this.peopleName = this.peopleData.firstName;
      } else {
        this.peopleName = this.peopleData.firstName + ' ' + this.peopleData.lastName;
      }
    }

    if (this.peopleId != undefined) {
      if (this.phoneList.length > 0) {
        this.phonePrimaryradio = false;
      }
      if (this.eMailList.length > 0) {
        this.emailPrimaryradio = false;
      }
      if (this.sMediaList.length > 0) {
        this.sMediaPrimaryradio = false;
      }
      if (this.assistantList.length > 0) {
        this.assistantPrimaryRadio = false;
      }
    } else {
      this.phonePrimaryradio = true;
      this.emailPrimaryradio = true;
      this.sMediaPrimaryradio = true;
      this.assistantPrimaryRadio = true;
    }

    if ((null !== this.peopleData.entityTypeId) && (undefined !== this.peopleData.entityTypeId)) {
      this.recordtype = this.peopleData.entityTypeId;
    }

    this.dob = this.peopleData.dob;
    this.dobTemp = this.peopleData.dob;
    this.loading = false;
  }

  /*
   * Function to set max value for DOB date picker.
   *
   */
  private setDobMaxMonth() {
    var today = new Date();
    var maxMonth = today.getUTCMonth() + 1;
    var maxDay = today.getUTCDate();
    var maxYear = today.getUTCFullYear();
    this.dobMaxDate = { year: maxYear, month: maxMonth, day: maxDay };
  }

  // This keypress function prevents alphabetical character.
  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

      //delete phone
  public deletePhone(selectedItem): void {
    if (null != selectedItem) {
      const index: number = this.addedPhoneJson.phone.indexOf(selectedItem);
      if (index !== -1) {
        this.addedPhoneJson.phone.splice(index, 1);
      }
    }

    //Select the first row as primary when user removes the already existing primary row from list
    if (null != selectedItem && selectedItem.primary && this.addedPhoneJson.phone.length > 0) {
      this.addedPhoneJson.phone[0].primary = true;
    }
    //Select the input primary radio button as selected when there is no entry in that list
    if (null != this.addedPhoneJson && this.addedPhoneJson.phone.length == 0) {
      this.selectedPrimaryFlagN = true;
    }
    this.onPageEdit();
  }

  /** Method to call the lookup services   */
  private getDropdownLookupData() {
    if ((null !== this.inputParams) && (undefined !== this.inputParams)) {
      setTimeout(() => {
       
      this.occupationDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.occupationDropdown.options);
      this.typeDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.typeDropdown.options);
      this.companyDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.companyDropdown.options);
      this.phoneDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.phoneDropdown.options);
      this.phoneDropdownForPopup = new DropdownTypeAheadModel('', '', '', '', this.inputParams.phoneDropdown.options);
      this.phoneDropdownSub = new DropdownTypeAheadModel('', '', '', '', this.inputParams.phoneDropdown.options);
      this.emailDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.emailDropdown.options);
      this.emailDropdownSub = new DropdownTypeAheadModel('', '', '', '', this.inputParams.emailDropdown.options);
      this.socialMediaDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.socialMediaDropdown.options);
      this.socialMediaDropdownSub = new DropdownTypeAheadModel('', '', '', '', this.inputParams.socialMediaDropdown.options);
      this.selectCountryAddDropdown = new DropdownTypeAheadModel('', '', this.inputParams.selectCountryAddDropdown.options[0], 'value', this.inputParams.selectCountryAddDropdown.options);
      this.selectStateAddDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.selectStateAddDropdown.options);
      this.selectTypeAddDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.selectTypeAddDropdown.options);
      this.companyEntityTypes = this.inputParams.entityCompaniesTypeOptions;
      this.inputAddrTypeDropdown = new DropdownTypeAheadModel('', '', '', '', this.inputParams.selectTypeAddDropdown.options);
      this.inputAddrTypeDropdown.selection = "value";
      this.inputAddrTypeDropdown.dropdownValue = this.inputParams.selectTypeAddDropdown.options[0];

      // this.recordtype = this.inputParams.entityTypeOptions[0].id;
      if ((null !== this.peopleData.entityTypeId) && (undefined !== this.peopleData.entityTypeId)) {
        this.recordtype = this.peopleData.entityTypeId;
      }else{
        this.recordtype = this.inputParams.entityTypeOptions[0].id;
      }
      
      }, 2000);
    }
  }

  public selectedTypeAheadRecord(evt: Event) {
    this.saveNameTalentEvn = evt;
  }

  public saveNameTalentEvent(evn: any) {
    this.isAddNew = true;
    this.saveNameTalentEvn = evn;
  }

  public accentedService(char: any): void {
    this.inputParams.service.serviceAccentedClass[this.inputParams.service.getaccentedCharacters](char).subscribe((data) => {
      this.accentedModal.openAccentedModal(data);
    });
  }
  public assistantAccentedService(char: any): void {
    this.inputParams.service.serviceAccentedClass[this.inputParams.service.getaccentedCharacters](char).subscribe((data) => {
      this.assistantAccentedModal.openAccentedModal(data);
    });
  }
  

  public saveTypeaheadAssistantModal(event: any) {
    this.disabledSave = false;
    this.loading = true;
    this.onPageEdit();
    let tName: TypeAheadSaveModel = new TypeAheadSaveModel();
    let vals = this.typeAheadAssistantModal.addTalentForm.value;
    // assign values
    tName.partyId = null;

    tName.name.entity = vals.editableFields.entityName;
    tName.name.first = vals.editableFields.firstName;

    tName.partyType = "CONTACT";
    tName.createdByApp = "RollCall2";
    tName.updatedByApp = "RollCall2";
    tName.dataSetId = this.peopleData.dataSet;
    tName.name.middle = vals.editableFields.middleName;
    tName.name.suffix = vals.editableFields.suffix;
    tName.displayName = this.createDisplayName(vals);
    tName.createdBy = 'Melissa Tapie';
    tName.updatedBy = 'Melissa Tapie';

    if (null !== this.inputParams) {
      if (null !== this.inputParams.service) {
        this.inputParams.service.serviceClass[this.inputParams.service.saveParty](JSON.stringify(tName)).subscribe(
          (res) => {
            let firstName = (res.name.first != null) ? res.name.first : "";
            this.loading = false;
            setTimeout(() => {
              this.typeAheadAsstSelectorHeader.typeAheadField.nativeElement.value = firstName + " " + res.name.entity;
          }, 500);
            this.selectedAsstPartyId = res.partyId;
            this.newAssistant = firstName + " " + res.name.entity;
            this.newAsstData = res;
            this.typeAheadAssistantModal.successCB(res);
            setTimeout(() => {
              document.getElementById("add-assistant-id").focus()   
              }, 200);
          },
          (err) => {
            this.loading = false;
            // const errMessage: string=err.error.errors[0].detail;
            // const errMessage: string = 'Error, Alias could not be saved';
            // this.typeAheadAssistantModal.failureCB(errMessage);
            this.errortoastermessage=err.error.errors[0].detail
            $('<div class="errorToastDiv" id="error-id-toast"  style=" width: 31%;z-index:1;position: absolute;top: 0;margin-left: 38%;border: 0;background-color: #bd362f;padding: 10px 10px 10px 25px;background-position: 15px center;background-repeat: no-repeat;background-size: 24px;box-shadow: 0 0 12px #999;color: #fff;border-radius: 3px;"><div><button type="button" class="close errorButtonChange" style="background-color: transparent !important;color: #fff;    font-weight: 500;opacity: .8;"aria-label="Close"  (click)="errorToasterClose()"><span aria-hidden="true" class="styleSpan">&times;</span></button><p class="pErrorTab">' + this.errortoastermessage + '</p></div></div>').insertAfter('.modal-header');
            setTimeout(() => {
              $('#error-id-toast').remove();
             }, 1800);
          }
        );
      }
    }
  }

  public saveTypeaheadModal(event: any) {
    this.loading = true;
    this.disabledSave = false;
    this.onPageEdit();
    let tName: TypeAheadSaveModel = new TypeAheadSaveModel();
    let vals = this.typeAheadModal.addTalentForm.value;
    // assign values
    tName.partyId = null;

    tName.name.entity = vals.editableFields.entityName;
    tName.name.first = vals.editableFields.firstName;

    tName.partyType = "CONTACT";
    tName.createdByApp = "RollCall2";
    tName.updatedByApp = "RollCall2";
    tName.dataSetId = this.peopleData.dataSet;
    tName.name.middle = vals.editableFields.middleName;
    tName.name.suffix = vals.editableFields.suffix;
    tName.displayName = this.createDisplayName(vals);
    tName.createdBy = 'Melissa Tapie';
    tName.updatedBy = 'Melissa Tapie';

    if (null !== this.inputParams) {
      if (null !== this.inputParams.service) {
        this.inputParams.service.serviceClass[this.inputParams.service.saveParty](JSON.stringify(tName)).subscribe(
          (res) => {
            this.peopleId = res.partyId;

            // Get Talent Details - Get the list of AKA and Primary name
            this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](this.peopleId)
            .subscribe(
              (data) => {
                this.loading = false;
                // this.setFieldsValues(data['party']);
                this.getAllDisplayNames(data);            
              },
              (err) => {
                console.log('error', err);
              });

            this.typeAheadModal.successCB(res);
            setTimeout(() => {
              document.getElementById("title-id").focus()   
              }, 250);

          },
          (err) => {
            this.loading = false;
            const errMessage: string = err.error.errors[0].detail;
            this.typeAheadModal.failureCB(errMessage);
          }
        );
      }
    }
  }

  // Ratheesh
  private getAllDisplayNames(item: any){
    console.log("getSelectedDisplayNames item", item);
    if(typeof item.party.names.AKA !== 'undefined'){
      this.listOfAlias = item.party.names.AKA;
      this.listOfAlias.push(item.party.names.PRIMARY[0]);
    }else{
      this.listOfAlias = item.party.names.PRIMARY;
    }
    
    console.log('list', this.listOfAlias);
  }

  private getSelectedDisplayNames(item: any){
    console.log("getSelectedDisplayNames item", item);
    this.choosenDispName = item;
  }
  private generateSchema(){
    let akaList:any = [];
    let schema : any;
    akaList = JSON.parse(JSON.stringify(this.listOfAlias));
    console.log("only alias", akaList);
    let delindex  = akaList.findIndex(i => i.name.nameId == this.choosenDispName.nameId);
    console.log("del index", delindex);
    akaList.splice(delindex, 1);
    if (this.listOfAlias != undefined && this.listOfAlias.length > 0) {
      console.log("this.listOfAlias[delindex].name", this.listOfAlias[0].name);
      console.log("this.listOfAlias[delindex]", this.listOfAlias[delindex]);
      console.log("this.listOfAlias[delindex].name", this.listOfAlias[delindex].name);

      let seletedName = [{
            "name": this.listOfAlias[delindex].name,
            "nameType": {
              "type": "NAME_TYPE",
              "code": "PRIMARY",
              "label": "primary",
              "disabledFlag": null,
              "codeId": null
            }
          }]

        schema = {
            "AKA" : akaList,
            "PRIMARY" : seletedName
          }
         
          console.log("on rasio click", schema);
    }
    return schema;

  }

  // Ratheesh
  private updateTitle(item: any): void {

    this.talentSelected = item;

    console.log("talentSelected", this.talentSelected);

    if(this.talentSelected != undefined || this.talentSelected != null){
      this.getSelectedDisplayNames(this.talentSelected);
    }

    if (item) {
      this.peopleName = (item.firstName ? item.firstName + ' ' : '') +
        (item.middleName ? item.middleName + ' ' : '') +
        (item.entityName ? item.entityName : '') +
        (item.suffix ? ', ' + item.suffix : '');
    } 
    else {
      this.peopleName = '';
    }
  }

  private createDisplayName(vals: any): string {
    return vals.editableFields.entityName + ', ' +
      vals.editableFields.suffix + ', ' +
      vals.editableFields.firstName + ' ' +
      vals.editableFields.middleName;
  };

  public saveAliasPeople(event: any){
    this.loading = true;
    this.onPageEdit();
    const aliasParty: AddAliasModel = new AddAliasModel();
    let vals = this.typeAheadModal.addTalentForm.value;
    const valEditFields = {
      editableFields: {
        firstName: vals.editableFields && vals.editableFields.firstName ? vals.editableFields.firstName : this.typeAheadModal.addTalentForm.get('editableFields.firstName').value,
        entityName: vals.editableFields && vals.editableFields.entityName ? vals.editableFields.entityName : this.typeAheadModal.addTalentForm.get('editableFields.entityName').value,
        middleName: vals.editableFields && vals.editableFields.middleName ? vals.editableFields.middleName : this.typeAheadModal.addTalentForm.get('editableFields.middleName').value,
        suffix: vals.editableFields && vals.editableFields.suffix ? vals.editableFields.suffix : this.typeAheadModal.addTalentForm.get('editableFields.suffix').value,
        // ssn: vals.editableFields && vals.editableFields.ssn ? vals.editableFields.ssn :  this.addTalentForm.get('editableFields.ssn').value
      }

    }
    aliasParty.partyType = "CONTACT";
    aliasParty.partyId = (this.typeAheadModal.selectedTypeAheadRecord) ? this.typeAheadModal.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.first = EmptyIfNull.check(valEditFields.editableFields.firstName);
    aliasParty.name.middle = EmptyIfNull.check(valEditFields.editableFields.middleName);
    aliasParty.name.entity = EmptyIfNull.check(valEditFields.editableFields.entityName);
    aliasParty.name.suffix = EmptyIfNull.check(valEditFields.editableFields.suffix);
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(valEditFields));

    const AKA: AddAliasAKAModel = new AddAliasAKAModel();
    AKA.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    AKA.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    AKA.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    AKA.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    this.inputParams.service.serviceClass[this.inputParams.service.saveAlias](JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        // this.updateNames(res);
        // Get Talent Details
        if(!this.peopleId) {
          this.peopleId = res.partyId;
        }
        this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](this.peopleId)
        .subscribe(
          (data) => {
            this.loading = false;
            // this.setFieldsValues(data['party']);
            this.getAllDisplayNames(data);
          },
          (err) => {
            console.log('error', err);
          });
        this.typeAheadModal.successCBAlias(res);
        setTimeout(() => {
          document.getElementById("title-id").focus()   
          }, 250);
      },
      (err) => {
        this.loading = false;
        const errCode: string = err.error.errors[0].code;
        let message: string = 'Error, Alias did not save';
        if (errCode === 'aka.already.exist') {
          const partyName = EmptyIfNull.check(aliasParty.name.first)
            + ' ' + EmptyIfNull.check(aliasParty.name.middle)
            + ' ' + EmptyIfNull.check(aliasParty.name.entity)
            + ' ' + EmptyIfNull.check(aliasParty.name.suffix);
          message = 'Alias "' + AKA.name.entity.trim() + '" for party "' + partyName.trim() + '" already exists!';
        }
        if (errCode === 'data.already.exist' || errCode === 'invalid.partyId.input') {
          message = err.error.errors[0].detail;
          this.typeAheadModal.failureCBAlias(message);
        }
      }
    )
  }
  
  public saveAlias(event: any) {
    this.onPageEdit();
    const aliasParty: AddAliasModel = new AddAliasModel();
    let vals = this.typeAheadModal.addTalentForm.value;
    const valEditFields = {
      editableFields: {
        firstName: vals.editableFields && vals.editableFields.firstName ? vals.editableFields.firstName : this.typeAheadModal.addTalentForm.get('editableFields.firstName').value,
        entityName: vals.editableFields && vals.editableFields.entityName ? vals.editableFields.entityName : this.typeAheadModal.addTalentForm.get('editableFields.entityName').value,
        middleName: vals.editableFields && vals.editableFields.middleName ? vals.editableFields.middleName : this.typeAheadModal.addTalentForm.get('editableFields.middleName').value,
        suffix: vals.editableFields && vals.editableFields.suffix ? vals.editableFields.suffix : this.typeAheadModal.addTalentForm.get('editableFields.suffix').value,
        // ssn: vals.editableFields && vals.editableFields.ssn ? vals.editableFields.ssn :  this.addTalentForm.get('editableFields.ssn').value
      }

    }
    aliasParty.partyType = "CONTACT";
    aliasParty.partyId = (this.typeAheadModal.selectedTypeAheadRecord) ? this.typeAheadModal.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.first = EmptyIfNull.check(valEditFields.editableFields.firstName);
    aliasParty.name.middle = EmptyIfNull.check(valEditFields.editableFields.middleName);
    aliasParty.name.entity = EmptyIfNull.check(valEditFields.editableFields.entityName);
    aliasParty.name.suffix = EmptyIfNull.check(valEditFields.editableFields.suffix);
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(valEditFields));

    const AKA: AddAliasAKAModel = new AddAliasAKAModel();
    AKA.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    AKA.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    AKA.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    AKA.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    this.inputParams.service.serviceClass[this.inputParams.service.saveAlias](JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        this.typeAheadModal.successCBAlias(res);
      },
      (err) => {
        this.loading = false;
        const errCode: string = err.error.errors[0].code;
        let message: string = 'Error, Alias did not save';
        if (errCode === 'aka.already.exist') {
          const partyName = EmptyIfNull.check(aliasParty.name.first)
            + ' ' + EmptyIfNull.check(aliasParty.name.middle)
            + ' ' + EmptyIfNull.check(aliasParty.name.entity)
            + ' ' + EmptyIfNull.check(aliasParty.name.suffix);
          message = 'Alias "' + AKA.name.entity.trim() + '" for party "' + partyName.trim() + '" already exists!';
        }
        if (errCode === 'data.already.exist' || errCode === 'invalid.partyId.input') {
          message = err.error.errors[0].detail;
          this.typeAheadModal.failureCBAlias(message);
        }
      }
    )
  }

    /*
     * Function to save company from typeahead modal.
     * @param { any } event - Event with data of person to be saved.
    */
    public saveCompanyTypeaheadModal(cName) {
      this.oneTimeCall = true;
      this.disabledSave = true;
      this.loading = true;
      const companyName: TypeAheadSaveModel = new TypeAheadSaveModel();
      if(cName != undefined){
        companyName.name.entity = cName.formValues.companyName;
      }else{
        companyName.name.entity = this.addNameCompanyComponentModal.addCompanyForm.value.companyName;
      }
      companyName.partyType = 'COMPANY';
      companyName.createdBy = 'Melissa Tapie';
      companyName.updatedBy = 'Melissa Tapie';
      companyName.partyId = null;
      companyName.createdByApp = 'RollCall2';
      companyName.updatedByApp = 'RollCall2';
      companyName.dataSetId = this.peopleData.dataSet;

      this.newCompanyLocationId = null;
      this.newCompanyLocation = { "value": null };

      this.companyDropdown.dropdownValue = {"id": "", "value":""};
      this.companyDropdown.selection = "value";
      this.companyDropdown.title = "";
      this.companyDropdown.options = [];  
    
      this.inputParams.service.serviceClass[this.inputParams.service.saveCompany](JSON.stringify(companyName)).subscribe(
        (res) => {
          this.locationFlag = res;
          this.loading = false;
          this.newCompanyName = res.displayName;
          this.selectedCompanyPartyId = res.partyId;
          setTimeout(() => {
            this.typeAheadCompanySelectorHeader.typeAheadField.nativeElement.value = res.displayName;
            if (cName != undefined) {
                this.addCompanyList();
            }
          }, 500);
          this.addNameCompanyComponentModal.successCB(res);
          if(this.isCompanyEdit == true){
            this.isCompanyEdit = false; // To indentify the edit location through typeAhead
            this.getCreateEditLocation({ res: res });
          }
 
        },
        (err) => {
          this.loading = false;
          //TAL-3511:making changes in error message displayed ,as it was not working in talent create edit page. Due to existance of multiple parent modals triggered from people component  the error popup was not coming. 
          this.errortoastermessage=err.error.errors[0].detail
          $('<div class="errorToastDiv" id="error-id-toast"  style=" width: 31%;z-index:1;position: absolute;top: 0;margin-left: 38%;border: 0;background-color: #bd362f;padding: 10px 10px 10px 25px;background-position: 15px center;background-repeat: no-repeat;background-size: 24px;box-shadow: 0 0 12px #999;color: #fff;border-radius: 3px;"><div><button type="button" class="close errorButtonChange" style="background-color: transparent !important;color: #fff;    font-weight: 500;opacity: .8;"aria-label="Close"  (click)="errorToasterClose()"><span aria-hidden="true" class="styleSpan">&times;</span></button><p class="pErrorTab">' + this.errortoastermessage + '</p></div></div>').insertAfter('.modal-header');
          setTimeout(() => {
            $('#error-id-toast').remove();
           }, 1800);

        }
      );

      //Set focus to company location dropdown
      //this.setFocusCompanyLocationDropDown();
      //clear location popup values
      this.clearLocationPopupValues();
      this.resetAllLocationFlags();
      setTimeout(() => {
        document.getElementById("add-company-id").focus()   
        }, 1000);
      // this.typeAheadCompanySelectorHeader['setTypeAheadFocus']();
    }

    onCompanyEdit(event) {
      this.addedPhoneJson = { "phone": [] };
      this.isCompanyEdit = true;
      this.saveCompanyTypeaheadModal(undefined);
    }

    getCreateEditLocation(res) {
      this.companiesId = res.res.partyId;
      this.companiesDisplayName = res.res.displayName;
      this.locationAction = res.res.displayName;
  
      this.phoneDropdownForPopup.dropdownValue = {"id":null, value:""};
      this.phoneDropdownForPopup.selection = "null";
      this.phoneDropdownForPopup.title = "";
      this.modalService.open(this.myLocationModal, { centered: true, size: 'lg', backdrop: 'static' });
      this.companyAddLocationEdit = true;

      this.setPrimaryLocationName();
      this.settingsForAddNewLoc();

      setTimeout(() => {
      document.getElementById("loc-name loc-name-input").focus();
        }, 2000);
      
    }

  //closing modal window
  public closeModal(c) {
    if (c.keyCode === undefined) {
      c('Close click');
      if(this.addressLocAdd==true||this.addressLocEdit==true) {
        setTimeout(() => {
          document.getElementById("edit-address").focus();       
          }, 200);
        }
      //clear location popup values
      this.clearLocationPopupValues();
      //set back to db phone values on cancel click
      this.setLocationPhoneWithDBValue();
      this.clearCompanyLocationDropDown();
      this.onPageEdit();
      this.resetSelectedCompany();
      this.oneTimeCall = false;
    }
  }

    //closing modal window on click of save
    public DoSave(c,evt) {
      if (evt.keyCode === undefined||evt.keyCode === 13) {
        this.saveLocations(c);
        if(evt.keyCode === 13){
          setTimeout(() => {
            c('Close click');          
            }, 400); 
        } 
        else{
          setTimeout(() => {
            c('Close click');          
            }, 200);    
        }
          if(this.addressLocAdd==true||this.addressLocEdit==true) {
            setTimeout(() => {
              document.getElementById("edit-address").focus();       
              }, 200);
            }else if(this.companyLocAdd == true || this.companyAddLocationEdit == true){
              setTimeout(() => {
              document.getElementById("cmpLocationDrpDwn1").focus();
               }, 200);  
            }
          if(this.resetRequired) {
            this.validLocationName = true;
            // clearing all fields
            this.clearLocationPopupValues();
  
            // RC-1382 - Company location address edit changes
            if(!this.companyLocAdd && !this.companyAddLocationEdit) {
              this.clearLocation();
            }
            setTimeout(() => {
                this.resetLocationFlags();
            }, 500);
          }
        this.disableTypeAheadSave = true;
        this.disableTypeAheadLoc = true; 
      }
    }

    public cancelWarning() {
      //clearing all fields
      this.selectedCountryBuffer=null;
      this.validLocationName = true;
      //clear location popup values
      this.clearLocationPopupValues();
      //set back to db phone values on cancel click
      this.setLocationPhoneWithDBValue();

      this.onPageEdit();
      this.selectStateAddDropdown = this.inputParams.selectStateAddDropdown;
      if(!this.companyLocAdd && !this.companyAddLocationEdit) {
        this.clearLocation();
      }
      if(this.companyLocAdd) {
        this.clearCompanyLocationDropDown();
      }
      this.resetAllLocationFlags();
    }

    public saveLocations(c) {

      if (this.isOpen) {
        this.locationsId = null;
      }
      //setting null to empty fields
      if (this.selectedLocationName == null) {
        this.selectedLocationName = null;
      }
      if (this.selectedAddressFirstLine == null) {
        this.selectedAddressFirstLine = null;
      }
      if (this.selectedAddressSecondLine == null) {
        this.selectedAddressSecondLine = null;
      }
      if (this.selectedAddressThirdLine == null) {
        this.selectedAddressThirdLine = null;
      }
      if (this.selectedLocationCity == null) {
        this.selectedLocationCity = null;
      }
      if (this.editSelectedCountryId === undefined) {
        this.editSelectedCountryId = null;
      }
      if (this.editSelectedStateId === undefined) {
        this.editSelectedStateId = null;
      }
  
      if (this.selectedPostal == null) {
        this.selectedPostal = null;
      }
  
      if (this.addedPhoneJson == null) {
        this.addedPhoneJson.phone = [];
      }
      if((this.selectedLocationCountry==null||this.selectedLocationCountry.value==null)&& this.selectedCountryBuffer=="United States"){
        this.selectedLocationCountry= {
          value: "United States",
          id: "US"
        }
  
      }

      //Method to set the location name with city name if location name is empty or 'Primary'
      this.selectedLocationName = this.replaceLocationWithCityName(this.selectedLocationName);
      if (this.selectedLocationName && this.selectedLocationName.trim() !== "") {
        this.validLocationName = true;
        this.isValidLoca = true;
        if (this.isValidLocation()) {
          this.locationAddressObject = {
            addressId: null,
            locationName: this.selectedLocationName,
            addressType: null,
            addressTypeId: null,
            firstLine: this.selectedAddressFirstLine,
            secondLine: this.selectedAddressSecondLine,
            thirdLine: this.selectedAddressThirdLine,
            city: this.selectedLocationCity,
            state: (null != this.selectedLocationState) ? this.selectedLocationState.value : null,
            stateId: (null != this.selectedLocationState) ? this.selectedLocationState.id : null,
            zip: this.selectedPostal,
            countryId: (null != this.selectedLocationCountry) ? this.selectedLocationCountry.id : null,
            country: (null != this.selectedLocationCountry) ? this.selectedLocationCountry.value : null,
          }

          this.AddedLocations.loc = [];
  
          let locationsModel = new CompaniesLocationsModel(null, this.selectedLocationName, null, null,
            this.locationAddressObject, this.primaryLocation, null,
            this.addedPhoneJson.phone, null, false);
  
          this.AddedLocations.loc.push(locationsModel);
        }
      }
      else {
        this.validLocationName = false;
        this.isValidLoca = false
      }
      //Add Multiple Locations - reset back primary flag to false
      this.selectedlocationPrimary = false;
      this.selectedCountryBuffer=null;
      this.selectStateAddDropdown = this.inputParams.selectStateAddDropdown;
      
      if(this.oneTimeCall == true){
        this.oneTimeCall = false;
        this.saveLocationServiceCall();
      }
      this.onPageEdit();

      // 1302-Changes for People - Address Edit 
      if(this.addressLocAdd) {
        let AddressModel = new PeopleAddressModel(null,
          null,
          this.selectedAddressType != null ? this.selectedAddressType.value : null,
          this.selectedAddressType != null ? this.selectedAddressType.id : null,
          this.selectedAddressFirstLine,
          this.selectedAddressSecondLine, this.selectedAddressThirdLine,
          this.selectedLocationCity,
          this.selectedLocationState != null ? this.selectedLocationState.value : null,
          this.selectedLocationState != null ? this.selectedLocationState.id : null,
          this.selectedPostal,
          this.selectedCountry != null ? this.selectedCountry.value : null,
          this.selectedCountry != null ? this.selectedCountry.id : null,
          this.primaryLocation,
          true);
        //Add newly added row into json list
        if (this.addedAddressList.address == null || this.addedAddressList.address == undefined) {
          this.addedAddressList.address = [];
        }

        if(!this.emptyAddress(AddressModel)) {
          //set the primary to the first item in the list
          if(this.primaryLocation) {
            //1st parm -> index, 2nd param -> delete count, 3rd param -> Item
            this.addedAddressList.address.splice(0, 0, AddressModel); 
            //If selected address is primary = true , set the other address' to non-primary
            //Primary will be in 0 index , so iterate from index = 1 to end
            for (let index = 1; index < this.addedAddressList.address.length; index++) {
              if(null != this.addedAddressList.address[index]) {
                this.addedAddressList.address[index].primary = false;
              }
            }
          } else {
            this.addedAddressList.address.push(AddressModel);
          }
        }
      }
      //Address edit flow
      if(this.addressLocEdit) {
        if (null != this.addedAddressList && this.addedAddressList.address != null && this.addedAddressList.address != undefined 
            && this.addedAddressList.address.length > 0 && this.selectedAddressIndex >= 0
            && this.addedAddressList.address[this.selectedAddressIndex] != null) {

              this.addedAddressList.address[this.selectedAddressIndex].addressType = this.selectedAddressType != null ? this.selectedAddressType.value : null;
              this.addedAddressList.address[this.selectedAddressIndex].addressTypeId = this.selectedAddressType != null ? this.selectedAddressType.id : null;
              this.addedAddressList.address[this.selectedAddressIndex].firstLine =  this.selectedAddressFirstLine;
              this.addedAddressList.address[this.selectedAddressIndex].secondLine =  this.selectedAddressSecondLine;
              this.addedAddressList.address[this.selectedAddressIndex].thirdLine =  this.selectedAddressThirdLine;
              this.addedAddressList.address[this.selectedAddressIndex].city =  this.selectedLocationCity;
              this.addedAddressList.address[this.selectedAddressIndex].state =  this.selectedLocationState != null ? this.selectedLocationState.value : null; 
              this.addedAddressList.address[this.selectedAddressIndex].stateId =  this.selectedLocationState != null ? this.selectedLocationState.id : null; 
              this.addedAddressList.address[this.selectedAddressIndex].country =  this.selectedCountry != null ? this.selectedCountry.value : null; 
              this.addedAddressList.address[this.selectedAddressIndex].countryId =   this.selectedCountry != null ? this.selectedCountry.id : null;
              this.addedAddressList.address[this.selectedAddressIndex].zip =  this.selectedPostal;
              this.addedAddressList.address[this.selectedAddressIndex].primary =  this.primaryLocation;

              //If selected address is primary = true , set the other address' to non-primary
              if(this.primaryLocation) {
                for (let index = 0; index < this.addedAddressList.address.length; index++) {
                  if(index != this.selectedAddressIndex &&  null != this.addedAddressList.address[index]) {
                    this.addedAddressList.address[index].primary = false;
                  }
                }
                //set the primary to the fist item in the list 
                let editAddress = this.addedAddressList.address[this.selectedAddressIndex];
                this.addedAddressList.address.splice(this.selectedAddressIndex, 1);
                this.addedAddressList.address.splice(0, 0, editAddress); 
              }
        }
      }

      // RC-1382 - Company location address edit changes
      let selectCompanyIdInEditMode = this.getSelectedCompanyIdEditMode();
      if(this.companyLocEdit) {
        if (null != this.companyList && this.companyList != undefined
            && this.companyList.length > 0 && this.selectedCompanyIndex >= 0
            && this.companyList[this.selectedCompanyIndex] != null) {
        
            let selectLocationAddress: any;
            var locationName: string;
            var locationId: number;
            if(this.newCompanyLocation && this.newCompanyLocation.data && this.newCompanyLocation.data.locationAddress) {
              locationName = this.replaceLocationWithCityName(this.newCompanyLocation.data.locationAddress.locationName);
              locationId = this.newCompanyLocation.data.locationId;
            } 
            selectLocationAddress = this.createLocationAddressObject(locationName, this.primaryLocation);

            let locationsModel = new CompaniesLocationsModel(locationId, locationName, null, null,
                  selectLocationAddress, this.primaryLocation, null, this.addedPhoneJson.phone, null, false);
            
            if(selectCompanyIdInEditMode && selectCompanyIdInEditMode > 0) {
              this.editCompanyLocationServiceCall(locationsModel, this.companyList[this.selectedCompanyIndex].partyId);
            }
        }
      }
      if(this.companyLocAdd || this.companyLocAddInEdit) {
        let selectLocationAddress = this.createLocationAddressObject(this.selectedLocationName, this.primaryLocation);
        let locationsModel = new CompaniesLocationsModel(null, this.selectedLocationName, null, null,
                selectLocationAddress, this.primaryLocation, null, this.addedPhoneJson.phone, null, false);

        if(selectCompanyIdInEditMode && selectCompanyIdInEditMode > 0) {
          this.editCompanyLocationServiceCall(locationsModel, selectCompanyIdInEditMode); 
        } else {
          this.editCompanyLocationServiceCall(locationsModel, this.selectedCompanyPartyId); 
        }
      }
      //Method to set the primary Phone on top of people page list
      this.setPrimaryPhoneOnTop();
    }

    /** 1302-Changes for People - Address Edit */
    private resetLocationFlags() {
      this.companyLocEdit = false;
      this.addressLocAdd = false;
      this.addressLocEdit = false;
      this.companyLocAddInEdit = false;
    }

    private resetAllLocationFlags() {
      this.companyLocAdd  = false;
      this.companyLocEdit = false;
      this.addressLocAdd = false;
      this.addressLocEdit = false;
      this.companyLocAddInEdit = false;
    }

    /** Method to check addess is empty or not */
    private emptyAddress(addressModel: PeopleAddressModel) {
      return !addressModel.addressType && !addressModel.firstLine 
          && !addressModel.secondLine && !addressModel.thirdLine 
          && !addressModel.city && !addressModel.state 
          && !addressModel.country && !addressModel.zip;
    }

  public saveLocationServiceCall() {
    console.log("this.AddedLocations.loc", this.AddedLocations.loc);
    this.loading = true;
    this.companyData = new CompaniesDetailModel(null, null, null, null, null, null, null, null, null,
      null, null, null, null, null, null, null, null, null, null, null, null, null);

    this.companyData.locations = this.AddedLocations.loc[0];

    this.inputParams.service.serviceClass[this.inputParams.service.saveLocationCompanies](this.companyData.locations, this.companiesId).
    subscribe((res) => {
        
        this.inputParams.service.serviceClass[this.inputParams.service.getCompanyDetailsFromDb](this.companiesId).subscribe((data) => {
          var options = this.getLocationDropdownOptionsRerender(data);
          this.companyDropdown = new DropdownTypeAheadModel('', '', '', '', options);
  
          if(this.companyDropdown && this.companyDropdown.options && this.companyDropdown.options.length > 0) {
            this.companyDropdown.dropdownValue = this.companyDropdown.options[0];
            this.companyDropdown.selection = "value";
            this.companyDropdown.title = this.companyDropdown.options[0].value;
            this.onSelectCompanyLocation(this.companyDropdown.options[0],'company');
          }
          if(this.companyAddLocationEdit){
              this.addCompanyList();   
          }
          this.companyAddLocationEdit = false;
          this.loading = false;
        });
      },
      (err) => {
        console.log("Error saving location for the companies", err);
        this.loading = false;
      }
    );
  }

  public getLocationDropdownOptions(data: any) {
    let options: any[] = [];
    let pickListData: any;
    let dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    if (data) {
        pickListData = data;
        if (pickListData) {
            for (let i = 0; i < Object.keys(pickListData).length; i++) {
                options.push({
                    value: pickListData[i].name,
                    route: '',
                    id: pickListData[i].locationId,
                    data: pickListData[i]
                });
            }
        }
    }
    return dropdownModel;
}

public getDropdownListOptions(data: any) {
  let options: any[] = [];
  let pickListData: any;
  if (data) {
      pickListData = data;
      if (pickListData) {
          for (let i = 0; i < Object.keys(pickListData).length; i++) {
              options.push({
                  value: pickListData[i].name,
                  route: '',
                  id: pickListData[i].locationId,
                  data: pickListData[i]
              });
          }
      }
  }
  return options;
}

  private setDefaultEntitySelection() {
    if (null !== this.companyEntityTypes && this.companyEntityTypes !== undefined) {
      for (const itm of this.companyEntityTypes) {
        if ((this.companyData.entityTypeId === null || this.companyData.entityTypeId === undefined)
          && itm.value == "Company") {
          this.companyData.entityTypeId = itm.id;
          this.companyData.entityTypeValue = itm.value;
        }
      }
    }
  }

    public OnselectPhoneNumber(selectedVal: string) {
      this.selectedPhoneNumber = selectedVal;
      this.validInputPhone = true;
      this.validInputPhoneType = true;
      if (null != this.selectedPhoneType && null != this.selectedPhoneType.value
        && (this.selectedPhoneNumber == null || this.selectedPhoneNumber.length <= 0)) {
        this.validInputPhone = false;
      }
      else if ((null == this.selectedPhoneType || null == this.selectedPhoneType.value)
        && (this.selectedPhoneNumber != null && this.selectedPhoneNumber.length > 0)) {
        this.validInputPhone = false;
      }
    }

    public onSelectPhone(selectedVal: string): void {
      this.selectedPhoneType = selectedVal;
      this.onPageEdit();
    }

  //adding phone field
  public addLocationPhone(evt): void {
    if (evt.keyCode == 9 && evt.shiftKey == true) {
      setTimeout(() => {
        let inputField: HTMLElement = <HTMLElement>document.querySelector("#inputPrimaryPhoneId");
        inputField && inputField.focus();
      }, 2);
    }
    if (evt.keyCode === 13 || evt.keyCode === undefined) {
      this.validatInputPhoneNumber("a");
      if (this.addedPhoneJson.phone != null) {
        var itemExists = this.addedPhoneJson.phone.find(i => i.typeId == this.selectedPhoneType.id);
      }
      if (!itemExists) {
        if(this.selectedPhoneNumber == ""){
          (<HTMLInputElement>document.getElementById("phone-dropdown-id-one")).value = "";
        }
        var numberOfDigits = this.selectedPhoneNumber.replace(/[^0-9]/g, "").length
        if (null != this.selectedPhoneNumber && this.selectedPhoneNumber.length > 0
          && null != this.selectedPhoneType) {
          if (numberOfDigits < 11) {
            this.selectedPhoneNumber = this.formatPhoneNumber(this.selectedPhoneNumber);
          }
          let phoneModel = new PhoneMediaModel(null, null, this.selectedPhoneType.id, this.selectedPhoneType.value,
            this.selectedPhoneNumber, this.selectedPrimaryFlagN, this.selectedPhoneType, false, true, this.selectedPhoneNumber);
          //set the other primary flags to false if current selected one is true.
          if (this.selectedPrimaryFlagN == true && null != this.addedPhoneJson.phone
            && this.addedPhoneJson.phone.length > 0) {
            for (const itm of this.addedPhoneJson.phone) {
              itm.primary = false;
            }
          }
          if (null == this.addedPhoneJson || null == this.addedPhoneJson.phone) {
            this.addedPhoneJson.phone = [];
          }
          //RC-1382 - Company location address edit changes
          //Set the primary phone in first position in list
          if (this.selectedPrimaryFlagN) {
            this.addedPhoneJson.phone.splice(0, 0, phoneModel);
          } else {
            this.addedPhoneJson.phone.push(phoneModel);
          }
          this.selectedPhoneNumber = null;
          this.selectedPhoneType = { "id": null, "value": null };

          var options = this.phoneDropdown.options;
          this.phoneDropdown = new DropdownTypeAheadModel("", "", "", "", options);
          this.phoneDropdown.dropdownValue = { "id": "", "value": "" };
          this.phoneDropdown.title = "";
          this.phoneDropdown.selection = "value";

          this.selectedPrimaryFlagN = false;
          this.onPageEdit();
        }
      }
      else {
        this.selectedPhoneNumber = null;
        this.selectedPhoneType = null;

        var options = this.phoneDropdown.options;
        this.phoneDropdown = new DropdownTypeAheadModel("", "", "", "", options);
        this.phoneDropdown.dropdownValue = { "id": "", "value": "" };
        this.phoneDropdown.title = "";
        this.phoneDropdown.selection = "value";
      }
    }
  }

  public editPhone(selectedItem, index): void {
    if (selectedItem.keyCode === 13 || selectedItem.keyCode === undefined) {
      if (null != selectedItem && selectedItem.addedPhone) {
        this.phoneDropdownForPopup.dropdownValue = selectedItem.addedPhone;
        this.phoneDropdownForPopup.selection = "value";
        this.phoneDropdownForPopup.title = selectedItem.addedPhone.value;
        selectedItem.edited = true;
        if (this.addedPhoneJson.phone[index]) {
          this.addedPhoneJson.phone[index].value = selectedItem.value;
        }
        this.onPageEdit();
      }
    }
  }

  
  /**  Method to add editted phone
   * @param selectedItem
   */
  public addEditedPhone(selectedItem, index): void {
    if (selectedItem.keyCode === 13 || selectedItem.keyCode === undefined) {
      if (null != selectedItem) {
        if (selectedItem.validPhone === null || selectedItem.validPhone === undefined || selectedItem.validPhone) {
          selectedItem.edited = false;
        } else {
          selectedItem.edited = true;
        }
        var numberOfDigits = selectedItem.value.replace(/[^0-9]/g, "").length
        if (numberOfDigits < 11) {
          selectedItem.value = this.formatPhoneNumber(selectedItem.value);
        }
        else {
          // selectedItem.value = parseInt(selectedItem.value.replace(/[^0-9]/g, ''));
          selectedItem.value = selectedItem.value.replace(/[^0-9]/g, '');
        }

        if (this.addedPhoneJson.phone[index]) {
          this.addedPhoneJson.phone[index].value = selectedItem.value;
        }
        this.onPageEdit();
      }
    }
  }


  //checking if the phone input fields are valid
  public validatInputPhoneNumber(evt) {
    if (evt.keyCode == 9 && evt.shiftKey == false) {
      setTimeout(() => {
        let inputField: HTMLElement = <HTMLElement>document.querySelector("#inputPrimaryPhoneId");
        inputField && inputField.focus();
      }, 2);
    }
    if (evt.keyCode !== 9) {
      this.validInputPhone = true;
      this.validInputPhoneType = true;
      if (null != this.selectedPhoneType && null != this.selectedPhoneType.value
        && (this.selectedPhoneNumber == null || this.selectedPhoneNumber.length <= 0)) {
        this.validInputPhone = false;
      }
      else if ((null == this.selectedPhoneType || null == this.selectedPhoneType.value)
        && (this.selectedPhoneNumber != null && this.selectedPhoneNumber.length > 0)) {
        this.validInputPhone = false;
      }
    }
  }


  // public phoneTabbOut(evt){
  //   if (evt.keyCode == 9 &&evt.shiftKey==false) {
  //     document.getElementById("phone-dropdown-id-one").focus();
  //   }
  //   else if(evt.keyCode == 9 &&evt.shiftKey==true){
  //     setTimeout(() => {
  //     document.getElementById("phone-dropdown-id-one").focus();        
  //     }, 100);
  //   }
  // }
    /*
   * Function to modify edited phone data.
   */
  public onSelectPhoneAddedRow(evt: any, phoneIndex: number, selectedRow: any): void {
    var itemExists = this.addedPhoneJson.phone.find(i => i.addedPhone.id == evt.id);
    if (!itemExists) {
      this.addedPhoneJson.phone[phoneIndex].addedPhone = evt;
      this.addedPhoneJson.phone[phoneIndex].typeId = evt.id;
      this.addedPhoneJson.phone[phoneIndex].type = evt.value;
      if (null != selectedRow && null != selectedRow.addedPhone) {
        selectedRow.typeId = selectedRow.addedPhone.id;
        selectedRow.type = selectedRow.addedPhone.value;
        this.onPageEdit();
      }
    }
  }

  public onSelectPrimaryPhone(selectedVal: boolean): void {
    this.selectedPrimaryFlagN = true;
    this.onPageEdit();
  }

  /**Check whether its a valid location or not */
  public isValidLocation() {
    let isValidLoc = true;
    if (this.validLocationName) {
      isValidLoc = true;
      this.isValidLoca = true;
    } else {
      isValidLoc = false;
    }
    return isValidLoc;
  }

  public OnselectPostal(selectedVal: string){
    this.selectedPostal = selectedVal;
    this.onPageEdit();
    this.addressModelInputChanges();
  }

  public OnselectLocationName(selectedVal: string) {
    this.selectedLocationName = selectedVal;
    this.validateAddLocPopup();
  }

  public OnselectAddress(selectedVal: string, type) {
    if (type == "selectedAddress") {
      this.selectedAddress = selectedVal;
    }
    if (type == "selectedAddressSecondLine") {
      this.selectedAddressSecondLine = selectedVal;
    }
    if (type == "selectedAddressThirdLine") {
      this.selectedAddressThirdLine = selectedVal;
    }
    this.addressModelInputChanges();
  }

    //people company-address popup tabbing fixes in create/edit scenarios
    public tabbingOut(i) {
      document.getElementById("loc-name loc-name-input").focus();
    }

    public TabbingOutFromNotes(i){
      if(i.shiftKey!=true&&i.keyCode==9){
          document.getElementById("company-900").focus();  
      }
    }

  public tabbingOutCancel(i) {
    if (i.shiftKey != true) {
      setTimeout(() => {
        if (this.addressLocEdit == true || this.addressLocAdd == true) {
          document.getElementById("dummy-text").focus();
        }
        else if (this.companyLocEdit  ==  true) {
          document.getElementById("dummy-text").focus();
        }
        else {
          document.getElementById("loc-name loc-name-input").focus();
        }
      }, 50);
    }
  }

  public focusCheckBox(i) {
    if (i.keyCode == 9 && i.shiftKey == false) {
      if (this.addressLocEdit == true || this.addressLocAdd == true || this.companyLocEdit  ==  true) {
        setTimeout(() => {
          let inputField: HTMLElement = <HTMLElement>document.querySelector("#check-address");
          inputField && inputField.focus();
        }, 20);
      }
    }
    else if (i.keyCode == 9 && i.shiftKey == true) {
      setTimeout(() => {
        document.getElementById("cancel-loc").focus();
      }, 100);
    }
  }

  public focusTypeAddress(i) {
    if (i.keyCode == 9 && i.shiftKey == true) {
      if (this.addressLocEdit == true || this.addressLocAdd == true || this.companyLocEdit  ==  true) {
        setTimeout(() => {
          document.getElementById("dummy-text-two").focus();
        }, 20);
      }
    }
  }

  public tabbingOutLoc(i) {
    if (i.shiftKey == true && i.keyCode == 9) {
      setTimeout(() => {
        document.getElementById("cancel-loc").focus();
      }, 40);
    }
  }

  // public tabbingOutPhone(i) {
    // if (i.shiftKey == false) {
    //   setTimeout(() => {
    //     document.getElementById("phone-dropdown-id-one").focus();
    //   }, 40);
    // }
  // }

  public companySavedName(item: any): void {
    this.onPageEdit();
    this.saveNameTalentEvn = item;
  }

  public selectedCompanyTypeAheadRecord(evt: any) {
    this.loading = true;
    this.newCompanyAddress = null; // Location-> address empty
    this.selectedCompanyPartyId = evt.partyId;
    this.newCompanyName = evt.typeAheadDisplayName;
    this.locationAction = this.newCompanyName;

    //RC-1382 - Company location address edit changes
    this.newCompanyLocationId = null;
    this.newCompanyLocation = { "value": null };
    this.selectedCompanyLocAddress = null;

    this.inputParams.service.serviceClass[this.inputParams.service.getCompanyDetailsFromDb](this.selectedCompanyPartyId).subscribe((data) => {
      var options = this.getLocationDropdownOptionsRerender(data);
      this.companyDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      this.loading = false;
      if(this.companyDropdown && this.companyDropdown.options && this.companyDropdown.options.length > 0) {
        this.companyDropdown.dropdownValue = this.companyDropdown.options[0];
        this.companyDropdown.selection = "value";
        this.companyDropdown.title = this.companyDropdown.options[0].value;
        this.onSelectCompanyLocation(this.companyDropdown.options[0],'company');
      }  
    });
    this.onPageEdit();
  }

  public selectedPeopleTypeAheadRecord(evt: any) {
    this.disabledSave = false;
    this.oneTimeCall = true;
    this.onPageEdit();
    this.typeAheadEventService.removeListItems('mainListPeopleComponent');
    this.saveNameTalentEvn = evt;

    this.inputParams.service.serviceClass[this.inputParams.service.getTalentDetails](evt.partyId).subscribe((data) => {
      this.getAllDisplayNames(data);
      this.setFieldsValues(data['party']);
    });

    this.loading = true;
    this.inputParams.peopleTypeAheadService.serviceClass[this.inputParams.peopleTypeAheadService.getPeopleDetailsFromDb](evt.partyId).subscribe((data) => {
      this.loading = false;
      this.loadPeopleData(data);
    });
  }

  // function to get the selected the dropdown type for phone email and social media
  onSelectType(value, type) {
    if (type == 'phone') {
      this.phoneType = value;
    } else if (type == 'email') {
      this.emailType = value;
    } else if (type == 'socialmedia') {
      this.socialmediaType = value;
    } else if (type = 'type2') {
      this.selectedtype = value;
    }
    else {
      this.occupationSelected = value;
    }
    this.onPageEdit();
  }

  // function to get the selected the dropdown type for phone email and social media
  onSelectCompanyLocation(value, type) {
    if (type == 'company') {
      if (value) {
        this.newCompanyLocation = value;
        //RC-1382 - Company location address edit changes
        this.selectedCompanyLocAddress = !value.locationAddress ? value.locationAddress : null;
        this.addedPhoneJson.phone = !value.phone ? value.phone : null;

        if (value.data) {
          var address = value.data.address;
          var locationId = value.data.locationId;
          if (address) {
            this.newCompanyAddress = address;
          }
          else {
            this.newCompanyAddress = null;
          }
          if (locationId) {
            this.newCompanyLocationId = locationId;
          }
          else {
            this.newCompanyLocationId = null;
            this.newCompanyLocation = { "value": null };
          }
        }
      }
      else {
        this.newCompanyLocation = { "value": null };
        this.newCompanyAddress = null;
      }
    }
    this.onPageEdit();
  }

  // function to get the value from occupation deopdown
  onSelectOcupation(value) {
    this.occupationSelected = value;
    this.onPageEdit();
  }

  //function is to perform adding phone number more to be displayed downwards when cliking add button
  addPhone(evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if(this.newPhoneNo == ""){
        (<HTMLInputElement>document.getElementById("peoplePhoneTxtDivInput")).value = "";
      }
      var numberOfDigits = this.newPhoneNo.replace(/[^0-9]/g, "").length
      var trimUnderScore = this.newPhoneNo.replace(/_/g, '');
      this.newPhoneNo = trimUnderScore.replace(/(^-)|(-$)/g, "");
      if (this.newPhoneNo.trim() != "" && this.phoneType != '') {
        let itemExists;
        if (this.newPhoneNo) {
          itemExists = this.phoneList.find(i => i.no == this.newPhoneNo);
        }
        if (this.phoneType.value != "Other") { // Supports only type "Other" which can be add multiple
          itemExists = this.phoneList.find(i => i.type.id == this.phoneType.id);
        }

        if (!itemExists) {
          if (this.phonePrimaryradio == true) {
            if (this.phoneList.length > 0) {
              this.phoneList.forEach((item, ForEachindex) => {
                item.primary = false;
              });
            }
          }
          if (numberOfDigits < 11) {
            this.newPhoneNo = this.formatPhoneNumber(this.newPhoneNo);
          }
          this.phoneList.push({ 'no': this.newPhoneNo, 'disabled': true, 'primary': this.phonePrimaryradio, 'type': this.phoneType, contactId: '' });
          this.phonePrimaryradio = false;
        }
        this.newPhoneNo = '';
        this.phoneType = '';
        var options = this.phoneDropdown.options;
        this.phoneDropdown = new DropdownTypeAheadModel("", "", "", "", options);
        this.phoneDropdown.dropdownValue = { "id": "", "value": "" };
        this.phoneDropdown.title = "";
        this.phoneDropdown.selection = "value";
        this.onPageEdit();
        setTimeout(() => {
          document.getElementById("dummy-phone-text").focus();
        }, 300);
      }
    }
  }

  //function is to perform adding email more to be displayed downwards when cliking add button
  addEmail(evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (this.newEmail.trim() != '' && this.emailType != '') {
        let itemExists;
        if (this.newEmail) {
          itemExists = this.eMailList.find(i => i.eMail == this.newEmail);
        }
        if (this.emailType.value != "Other") { // Supports only type "Other" which can be add multiple
          itemExists = this.eMailList.find(i => i.type.id == this.emailType.id);

        }

        if (!itemExists) {
          if (this.emailPrimaryradio == true) {
            if (this.eMailList.length > 0) {
              this.eMailList.forEach((item, ForEachindex) => {
                item.primary = false;
              });
            }
          }
          this.eMailList.push({ 'eMail': this.newEmail, 'disabled': true, 'primary': this.emailPrimaryradio, 'neveremail': this.neveremailStatus, 'type': this.emailType, contactId: '' });
          this.emailPrimaryradio = false;
        }
        this.newEmail = '';
        this.emailType = '';
        var options = this.emailDropdown.options;
        this.emailDropdown = new DropdownTypeAheadModel("", "", "", "", options);
        this.emailDropdown.dropdownValue = {"id": "", "value": ""};
        this.emailDropdown.title = "";
        this.emailDropdown.selection = "value";
        this.onPageEdit();
        setTimeout(() => {
          document.getElementById("dummy-social-text").focus();
         }, 300);
      }
    }
  }

  /*
   * function to perform adding social media to be displayed downwards when clicking add button.
   */
  addSocialMedia(evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (this.newSMedia.trim() != '' && this.socialmediaType != '') {
        let itemExists;
        if (this.newSMedia) {
          itemExists = this.sMediaList.find(i => i.address == this.newSMedia);
        }
        if (this.socialmediaType.value != "Other") { // Supports only type "Other" which can be add multiple
          itemExists = this.sMediaList.find(i => i.type.id == this.socialmediaType.id);

        }

        if (!itemExists) {
          if (this.sMediaPrimaryradio == true) {
            if (this.sMediaList.length > 0) {
              this.sMediaList.forEach((item, ForEachindex) => {
                item.primary = false;
              });
            }
          }
          this.sMediaList.push({ 'address': this.newSMedia, 'disabled': true, 'primary': this.sMediaPrimaryradio, 'type': this.socialmediaType, contactId: '' });
          this.sMediaPrimaryradio = false;
        }
        this.newSMedia = '';
        this.socialmediaType = '';
        var options = this.socialMediaDropdown.options;
        this.socialMediaDropdown = new DropdownTypeAheadModel("", "", "", "", options);
        this.socialMediaDropdown.dropdownValue = {"id": "", "value": ""};
        this.socialMediaDropdown.title = "";
        this.socialMediaDropdown.selection = "value";
        this.onPageEdit();
      }
    }
  }

  /*
   * Function to set company list on edit.
   */
  setCompanyList() {
    this.companyList = [];
    if (this.peopleData.companies) {
      var compList = this.peopleData.companies;
      compList.forEach((item, ForEachindex) => {
        var locationName = null;
        var partyId = null;
        var companyName = null;
        var locationId = null;
        var primary = null;
		    //RC-1382 - Company location address edit changes 
        var companyPrimary: boolean;
        var locationPrimary: boolean;
        var addr: string = null;
        if (item.partyId) {
          partyId = item.partyId;
        }

        if (item.locationId) {
          locationId = item.locationId;
        }

        if (item.companyName) {
          companyName = item.companyName;
        }

        if (null != item.primary) {
          primary = item.primary;
		      companyPrimary = item.primary;
        }

        //RC-1382 - Company location address edit changes 
        if (item.location) {
          locationPrimary = item.location.primary;
        }

        let locationAddedPhoneJson = this.setCompanyLocationPhone(item.phone);
        
        let peopleCompanyLocationModel = new PeopleCompanyLocationsModel(partyId, companyName, 
          locationId, item.location, null, locationAddedPhoneJson.phone, locationPrimary, companyPrimary);
        this.companyList.push(peopleCompanyLocationModel);

        if(partyId) { 
          this.inputParams.service.serviceClass[this.inputParams.service.getCompanyDetailsFromDb](partyId).subscribe((data) => {
            setTimeout(() => {
              peopleCompanyLocationModel.locationDropDownList = this.getDropdownListOptions(data);
            }, 1000);   
          });
        }  
      });
    }
    //RC-1382 - Company location address edit changes
    this.selectedCompanyPrimary = (this.companyList && this.companyList.length > 0) ? false : true;
  }

  /*
   * Function to order the company list
   * Make primary the last entry
   */
  orderCompanyList() {
    var itemExists = this.companyList.find(i => i.primary == true);
    if (itemExists) {
      this.companyList.splice(this.companyList.indexOf(itemExists), 1);
      this.companyList.push({ 'name': itemExists.name, 'location': itemExists.location, 'address': itemExists.address, 'companyId': itemExists.companyId, 'locationId': itemExists.locationId, 'primary': itemExists.primary });
    }
  }

  public onLocationValueEvent(event){
    if(event == ""){
      this.newCompanyAddress = null;
      this.newCompanyLocation = { "value": null };
      this.newCompanyLocationId = null;
    } 
    //RC-1382 - Company location address edit changes 
    this.companyLocDropDownEmpty(event);
  }
  public valueEventOnchangeWithScroll(event){
    let i = 0;
    if(this.flagI == 0){

    }else{
      setTimeout(() => {
        var objDiv = document.getElementById("addEditPeopleCard");
        objDiv.scrollTop = objDiv.scrollHeight;
      }, 1000);
    }
    this.flagI = this.flagI + 1;
     
  }
  /** RC-1382 - Company location address edit changes 
   * @param event  */
  public onCompanyLocKeyPress(event) {
    if(event.keyCode === 13 && this.companyDropdownEmpty && this.selectedCompanyPartyId){
 
      this.modalService.open(this.myLocationModal, { centered: true, size: 'lg', backdrop: 'static' });
      setTimeout(() => {
      document.getElementById("loc-name loc-name-input").focus();        
      }, 40);
      // this.disableTypeAheadLoc = this.selectedLocationName ? false: true;
      this.validateAddLocPopup();
      this.resetLocationFlags();
      this.companyLocAdd = true;
      this.locationAction = this.newCompanyName;
      this.setPrimaryLocationName();
      this.settingsForAddNewLoc();
    }
    this.companyDropdownEmpty = false;
  }

  //function is to perform adding company/project to be displayed downwards when cliking add button
  public addCompany(evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      this.addCompanyList();
    }
  }

  public addCompanyList(){
    if ((this.newCompanyName != '') && (this.newCompanyName != null)) {
      let itemExists = this.validateCompany();
      if (!itemExists) {
        this.addedCompany = false;
        this.addToCompanyList();
      }
      else {
        this.companyList.splice(this.companyList.indexOf(itemExists), 1);
        this.addToCompanyList();
      }
      // this.setPrimaryCompany();
      this.typeAheadCompanySelectorHeader.clearTypeAheadField();
      this.newCompanyName = null;
      this.selectedCompanyPrimary = false;
      this.clearLocation();
    }
    this.onPageEdit(); // Indicate edit occured for unsaved changes.
  }

  public clearLocation(){

    this.newCompanyAddress = null;
    this.newCompanyLocationId = null;
    this.newCompanyLocation = { "value": null };

    this.companyDropdown = new DropdownTypeAheadModel('', '', '', '', []);
    this.companyDropdown.dropdownValue = {"id":"", "value":""};
    this.companyDropdown.selection = "value";
    this.companyDropdown.title = "";

    this.typeAheadCompanySelectorHeader.clearTypeAheadField();
    this.selectedCompanyPartyId = null;

    this.companyLocEditDropdown = new DropdownTypeAheadModel('', '', '', '', []);
    this.companyLocEditDropdown.selection = "null";
    this.companyLocEditDropdown.options = [];
    this.companyLocEditDropdown.title = "";
    this.companyLocEditDropdown.dropdownValue = { "id": "", "value": "" };

    this.state = false;
    this.stateCheck = false;

    this.setFocusCompanyLocationDropDown();
  }

  public clearCompanyLocationDropDown() {
    this.newCompanyLocation = { value: null, id: null };
    this.newCompanyLocationId = null;
    this.companyDropdown.dropdownValue = {"id":"", "value":""};
    this.companyDropdown.selection = "value";
    this.companyDropdown.title = "";
    this.setFocusCompanyLocationDropDown();
  }

  /*
   * Function to add items to companylist
   */
  public addToCompanyList() {
    var location: any = { "value": null };
    var locationId = null;
    this.selectedCompanyLocAddress = null;
    this.addedPhoneJson.phone = [];

    if (null != this.newCompanyLocation) {
      location = this.newCompanyLocation;
    }
    if (undefined != this.newCompanyLocationId) {
      locationId = this.newCompanyLocationId;
    }

     //RC-1382 - Company location address edit changes 
    // this.companyList.push({ 'name': this.newCompanyName, 'location': location, 'address': this.newCompanyAddress, 'companyId': this.selectedCompanyPartyId, 'locationId': locationId, 'primary': true });
    
    if(location && location.data ) {
      if(location.data.locationAddress) {
        this.selectedCompanyLocAddress = location.data.locationAddress;
      }
      if(location.data.phone) {
        this.addedPhoneJson.phone = [...location.data.phone];
      }
    }

    //Set the existing records to non-primary if newly adding one is primary
    if(this.selectedCompanyPrimary && this.companyList && this.companyList.length > 0) {
      this.companyList.forEach((item, ForEachindex) => {
        item.primaryCompany = false;
      });
    }
    //Set location name to Primary on add company (add button), if there is no location exists
    this.selectedCompanyLocAddress = this.setPrimaryLocationOnAddCompanyList();
    let peopleCompanyLocationModel = new PeopleCompanyLocationsModel(this.selectedCompanyPartyId, this.newCompanyName, 
                        locationId, this.selectedCompanyLocAddress,
                        this.companyDropdown.options, this.addedPhoneJson.phone, 
                        this.primaryLocation, this.selectedCompanyPrimary);
    this.companyList.push(peopleCompanyLocationModel);
  }

  /* //RC-1382 - Company location address edit changes 
   * Function to set primary company
   */
  private setPrimaryCompany() {
    if(this.companyList && this.companyList.length > 0) {
      this.companyList.forEach((item, ForEachindex) => {
        item.primaryCompany = false;
      });
      this.companyList[0].primaryCompany = true;
    } else {
      this.selectedCompanyPrimary = true;
    }
  }

  addType(evt) {
    if (evt.keyCode === 13 || evt.keyCode === undefined) {
      if (this.selectedtype != '') {
        this.typelist_error_msg = false;

        let itemExists;
        if (this.selectedtype) {
          itemExists = this.typeList.find(i => i.name == this.selectedtype.value);
        }
        if (!itemExists) {
          this.typeList.push({ 'name': this.selectedtype.value, 'disabled': true, 'primary': true, 'type': this.selectedtype, partyId: '' });
        }
      }
      this.selectedtype = '';
      var options = this.typeDropdown.options;
      this.typeDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      this.typeDropdown.selection = "value";
      this.typeDropdown.title = "";
      this.typeDropdown.dropdownValue = {id: "", value: ""}
      this.onPageEdit();
    }
  }

  addOcptn(evt) {
    if (evt.keyCode === 13 || evt.keyCode === undefined) {
      if (this.occupationSelected != '') {
        let itemExists;
        itemExists = this.occupationList.find(i => i.value == this.occupationSelected.value);
        if (!itemExists) {
          this.occupationList.push({ "id": '', "value": this.occupationSelected.value, occupationId: this.occupationSelected.id, partyId: '', occupationName: this.occupationSelected.value });
        }
      }
      this.ocupationmodel = '';
      this.occupationSelected = '';
      var options = this.occupationDropdown.options;
      this.occupationDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      this.occupationDropdown.selection = "value";
      this.occupationDropdown.title = "";
      this.occupationDropdown.dropdownValue = {id: "", value: ""}
      this.onPageEdit();
    }
  }

  // constructAKANames(){
  //   this.AKAList.push({"names":{"first":firstName, "entity":entityName, "nameId": nameId}, "nameType":{"TypeId": "NAME_TYPE", "code":"AKA", "label":"aka", "parentId":null, "displayOrder": null}});
  // }

  // function to get the EDITED selected the dropdown value edited type for phone email and social media
  onSelectEditType(value, editedtype, index) {
    if (editedtype == 'phone') {
      this.editedPhonetype = value;
    } else if (editedtype == 'email') {
      this.editedemailType = value;
    } else if (editedtype == 'socialmedia') {
      this.editedsocialmediaType = value;
    }
    this.onPageEdit();
  }

  // edit phone enable disable--the editing function
  Editcliked(value, index, type, evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (type == 'phone') {
        this.phoneDropdownSub.dropdownValue = value.type;
        this.phoneDropdownSub.selection = "value";
        this.phoneDropdownSub.title = value.type.value;
        this.phoneList[index].disabled = !this.phoneList[index].disabled;
      } else if (type == 'email') {
        this.emailDropdownSub.dropdownValue = value.type;
        this.emailDropdownSub.selection = "value";
        this.emailDropdownSub.title = value.type.value;
        this.eMailList[index].disabled = !this.eMailList[index].disabled;
      } else if (type == 'socialmedia') {
        this.socialMediaDropdownSub.dropdownValue = value.type;
        this.socialMediaDropdownSub.selection = "value";
        this.socialMediaDropdownSub.title = value.type.value;
        this.sMediaList[index].disabled = !this.sMediaList[index].disabled;
      }
      this.onPageEdit();
    }
  }

  //save edited values to exsisting array
  perform_addeditedValue(value, index, type, evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (type == 'phone') {
        var numberOfDigits = value.no.toString().replace(/[^0-9]/g,"").length
        if(numberOfDigits<11){
          value.no= this.formatPhoneNumber(value.no);
        }
        else{
          value.no =  value.no.toString().replace(/[^0-9]/g,'');
        }
        this.phoneList[index] = value;
        if (this.editedPhonetype != '') {
          var itemExists = this.phoneList.find(i => i.type.id == this.editedPhonetype.id);
          var indx = this.phoneList.indexOf(itemExists);
          if ((indx === index) || (-1 == indx)) {
          
            this.phoneList[index].type = this.editedPhonetype;
            this.phoneList[index].typeId = this.editedPhonetype.id;
          }
        }
        this.phoneList[index].disabled = !this.phoneList[index].disabled;

      } else if (type == 'email') {
        this.eMailList[index] = value;
        if (this.editedemailType != '') {
          var itemExists = this.eMailList.find(i => i.type.id == this.editedemailType.id);
          var indx = this.eMailList.indexOf(itemExists);
          if ((indx === index) || (-1 == indx)) {
            this.eMailList[index].type = this.editedemailType;
            this.eMailList[index].typeId = this.editedemailType.id;
          }
        }
        this.eMailList[index].disabled = !this.eMailList[index].disabled;
      } else if (type == 'socialmedia') {
        this.sMediaList[index] = value;
        if (this.editedsocialmediaType != '') {
          var itemExists = this.sMediaList.find(i => i.type.id == this.editedsocialmediaType.id);
          var indx = this.sMediaList.indexOf(itemExists);
          if ((indx === index) || (-1 == indx)) {
            this.sMediaList[index].type = this.editedsocialmediaType;
            this.sMediaList[index].typeId = this.editedsocialmediaType.id;
          }
        }
        this.sMediaList[index].disabled = !this.sMediaList[index].disabled;
      }
      this.onPageEdit();
    }
  }

  //  binding the value while cliking the business or personal radio button
  perform_onChange_business_personal(value) {
    this.recordtype = value;
  }

  // format dob date in mm/dd/yyyy
  public verifyValidDate(value) {
    this.dob = this.datePipe.transform(value, "MM/dd/yyyy");
  }

  onCancelEvent(unSavedContent, evt) {
    // if (unSavedContent.keyCode === 13 || unSavedContent.keyCode === undefined) {
    if (evt.keyCode === 13 || evt.keyCode === undefined) {
      this.outputParams = this.perform_create_new_people();
     // this.pageEdited = true; // Hardcoded 'true' since showing the Unsaved popup irrespective of changes are done or not
      
      // Code for unsaved changes pop-up.
      if (true == this.pageEdited) {
        this.openGenericImageModalCancel(unSavedContent)
      }
      else {
        this.cancelEvent.emit(this.outputParams);
      }
    }
  }

  public confirmUnSavedChanges() {
    this.cancelEvent.emit(this.outputParams);
  }

  onSaveEvent(event): void {
    if (event.keyCode === 13 || event === 18) {
      this.onValEdit.emit(false);
      this.outputParams = this.perform_create_new_people();
      this.saveEvent.emit(this.outputParams); // Emit the success output params
    }
    else if(event.keyCode === 9 && event.shiftKey==true){
      setTimeout(() => {
        document.getElementById("notes-id").focus();  
        }, 5);
    }
  }


  // CREATE NEW PEOPLE SAVE BUTTON CLICK FUNCTION GOES HERE
  perform_create_new_people(): any {
    // this.formatDate();
    this.formatDateSet();
    // this.peopleData.dob = this.dob;
    let schema = this.generateSchema();
    this.checkAssistantList();
    if (this.recordtype == '') {
      this.businessPersonalradio.forEach((item, index) => {
        if (item.value == 'Business') {
          this.recordtype = item.id;
        }
      });
    }

    if (this.actualBaseImageURL != null) {
      this.peopleData.image = this.actualBaseImageURL;
    }
    else {
      this.peopleData.image = null;
    }
    var response = this.CreateEditPeopleService.CreateJson(this.peopleData.dataSet, this.peopleId, this.peopleData.image, this.peopleData.createdBy, this.peopleData.createdDate, this.peopleData.createdTime, this.peopleData.updatedBy, this.peopleData.updatedDate, this.peopleData.updatedTime, this.addedAddressList.address, this.peopleData.officeAddress, this.peopleData.homeAddress, this.peopleData.AKA, this.peopleData.companies, this.peopleName, this.dob, this.recordtype, this.peopletitle, this.occupationList, this.typeList, this.phoneList, this.eMailList, this.sMediaList, this.assistantList, this.peopleNotes, this.companyList, schema);
    console.log('People JSON for the web service:', response);

    if ((response.status == false) || (this.validDOB == false) || (this.addedCompany == true)) {
      this.validPeopleName = false
      if (response.messege == "please type your name") {
        this.name_error_msg = true;
      }
      if (response.messege == "please select atleast one type") {
        this.typelist_error_msg = true;
      }
    }
    else if (this.notes_error_msg === true) {
      this.validPeopleName = false;
    } else {
      // Get the request params for the post operation
      this.validPeopleName = true
      console.log("People Data Final JSON: ", response.createdJson[0]);
    }

    this.outputParams = new PeopleOutputParamsModel(response.createdJson[0], this.validPeopleName);
    return this.outputParams;
  }

  //REMOVING THE DATA FROM ARRAY WHEN CLICKING REMOVE MINUS BUTTON IN EVERT FIELD
  perform_removeCliked(index, fieldname, evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (fieldname == 'occupation') {
        this.occupationList.splice(index, 1);
      } else if (fieldname == 'type') {
        this.typeList.splice(index, 1);

      } else if (fieldname == 'phone') { // Phone Condition goes here...
        if (this.phoneList.length > 0) {
          if (this.phoneList[index].primary == true && index != 0) {
            this.phoneList[index - 1].primary = true;
          } else if (this.phoneList[index].primary == false && index != 0 && this.phoneList.length>1) {
          }else if(this.phoneList[index].primary == true && index == 0 && this.phoneList.length>1){
            this.phoneList[index + 1].primary = true;
          }else if(this.phoneList[index].primary == true && index == 0 && this.phoneList.length==1){
            this.phonePrimaryradio = true;
          } else if (this.phoneList.length == 0) {
            this.phonePrimaryradio = true;
          }
        } else {
          this.phonePrimaryradio = true;
        }
        this.phoneList.splice(index, 1);

      } else if (fieldname == 'eMail') { // Email Condition goes here...
        if (this.eMailList.length > 0) {
          if (this.eMailList[index].primary == true && index != 0) {
            this.eMailList[index - 1].primary = true;
          } else if (this.eMailList[index].primary == false && index != 0 && this.eMailList.length>1) {
          }else if(this.eMailList[index].primary == true && index == 0 && this.eMailList.length>1){
            this.eMailList[index + 1].primary = true;
          }else if(this.eMailList[index].primary == true && index == 0 && this.eMailList.length==1){
            this.emailPrimaryradio = true;
          } else if (this.eMailList.length == 0) {
            this.emailPrimaryradio = true;
          }
        } else {
          this.emailPrimaryradio = true;
        }
        this.eMailList.splice(index, 1);

      } else if (fieldname == 'sMedia') { // Social Media Condition goes here...
        if (this.sMediaList.length > 0) {
          if (this.sMediaList[index].primary == true && index != 0) {
            this.sMediaList[index - 1].primary = true;
          } else if (this.sMediaList[index].primary == false && index != 0 && this.sMediaList.length>1) {
          }else if(this.sMediaList[index].primary == true && index == 0 && this.sMediaList.length>1){
            this.sMediaList[index + 1].primary = true;
          }else if(this.sMediaList[index].primary == true && index == 0 && this.sMediaList.length==1){
            this.sMediaPrimaryradio = true;
          } else if (this.sMediaList.length == 0) {
            this.sMediaPrimaryradio = true;
          }
        } else {
          this.sMediaPrimaryradio = true;
        }
        this.sMediaList.splice(index, 1);

      } else if (fieldname == 'assistant') {
        var itemToDelete = this.assistantList[index];
        this.assistantList.splice(index, 1);
        if (true == itemToDelete.primary) {
          this.assistantList[0].primary = true;
        } else {
          //this.assistantPrimaryRadio = true;
        }

        if (0 == this.assistantList.length) {
          this.assistantPrimaryRadio = true;
        }

      } else if (fieldname == 'company') {
        var itemToDelete = this.companyList ? this.companyList[index] : null;
        this.companyList.splice(index, 1);
        if (itemToDelete && itemToDelete.primaryCompany) {
          this.setPrimaryCompany();
        }
      }

      this.onPageEdit();
    }
  }

  //function to perform when clicking the PRIMARY radio button while addinga new phone,email,social media,assiatant
  perform_onChange_primary_radio(value, fieldname) {

    if (fieldname == 'phone') {
      this.phonePrimaryradio = true;
    }
    else if (fieldname == 'email') {
      this.emailPrimaryradio = true;
    }
    else if (fieldname == 'sMedia') {
      this.sMediaPrimaryradio = true;
    }
    else if (fieldname == 'assistant') {
      this.assistantPrimaryRadio = true;
      if (this.assistantList.length > 0) {
        this.assistantList.forEach((item, ForEachindex) => {
          item.primary = false;
        });
      }
    }
    this.onPageEdit();
  }

  //function to perform EDIT - when clicking the PRIMARY radio button IN ALREDY ADDED  phone,email,social media,assiatant
  perform_onChange_primary_radio_edit(data, index, fieldname) {
    if (fieldname == 'phone') {
      if (data.primary == false) {
        this.phoneList[index].primary = true;
      } else if (data.primary == true) {
        this.phoneList[index].primary = false;
      }
      this.phoneList.forEach((item, ForEachindex) => {
        if (ForEachindex != index) {
          item.primary = false;
        }
      });
    } else if (fieldname == 'email') {
      if (data.primary == false) {
        this.eMailList[index].primary = true;
      } else if (data.primary == true) {
        this.eMailList[index].primary = false;
      }
      this.eMailList.forEach((item, ForEachindex) => {
        if (ForEachindex != index) {
          item.primary = false;
        }
      });
    } else if (fieldname == 'socialmedia') {
      if (data.primary == false) {
        this.sMediaList[index].primary = true;
      } else if (data.primary == true) {
        this.sMediaList[index].primary = false;
      }
      this.sMediaList.forEach((item, ForEachindex) => {
        if (ForEachindex != index) {
          item.primary = false;
        }
      });
    } else if (fieldname == 'assistant') {
      if (data.primary == false) {
        this.assistantList[index].primary = true;
      } else if (data.primary == true) {
        this.assistantList[index].primary = false;
      }
      this.assistantList.forEach((item, ForEachindex) => {
        if (ForEachindex != index) {
          item.primary = false;
        }
      });
    }
    this.onPageEdit();
  }

  //Address Grid starts here
  public onSelectAddressType(selectedVal: any): void {
    this.selectedAddressType = selectedVal;
    this.onPageEdit();
  }

  public onSelectCityEvent(selectedVal: any): void {
    this.selectedCity = selectedVal;
  }

  public OnselectCity(selectedVal: string) {
    this.selectedLocationCity = selectedVal;
    this.validateAddLocPopup();
    this.onPageEdit();
    this.addressModelInputChanges();
  }
  public validateAddLocPopup(){
    if((this.selectedLocationCity && this.selectedLocationCity.trim() != "") 
      || (this.selectedLocationName && this.selectedLocationName.trim() != "")){
      this.disableTypeAheadLoc = false;
    }else{
       this.disableTypeAheadLoc = true;
    }
  }

  public onSelectStateEvent(selectedVal: any): void {
    this.selectedState = selectedVal;
    this.onPageEdit();
  }

  public onSelectState(selectedVal: any): void{
    this.selectedLocationState = selectedVal;
    this.onPageEdit();
  }

  public onSelectZipEvent(selectedVal: any): void {
    this.selectedZip = selectedVal;
  }

// Onchange event -> address popup fields.. for save button validation purpose//
  public addressModelInputChanges(){
    if((this.selectedAddressFirstLine != '' || this.selectedAddressSecondLine != '' || this.selectedAddressThirdLine != '' || this.selectedLocationCity != '' || this.selectedPostal != "" || this.countryTyped != '' || this.stateTyped != '') && (this.typeTyped != '')){
      this.disableTypeAheadSave = false;
    }else{
      this.disableTypeAheadSave = true;
    }
  }
  public onTypeCountry(typedVal: any): void {
     this.countryTyped = typedVal;
     this.addressModelInputChanges();
  }
  public onTypeState(typedVal: any): void {
     this.stateTyped = typedVal;
     this.addressModelInputChanges();
  }
  
  public onTypeType(typedVal: any): void {
     this.typeTyped = typedVal;
     this.addressModelInputChanges();
  }

  public onSelectCountry(selectedVal: any): void {

    this.selectedCountry = selectedVal;
    this.selectedLocationCountry = selectedVal;

    if (this.selectedCountry.id != null) {
      this.loading = true;
      // Call service for getting states corresponding to selected country
      this.inputParams.service.serviceClass[this.inputParams.service.getStateListFromDb](this.selectedCountry.id).subscribe((data) => {
        this.loading = false;
        this.selectStateAddDropdown = new DropdownTypeAheadModel('', '', '', '', []);
        this.selectStateAddDropdown.selection = "value";
        this.selectStateAddDropdown.options = this.getDropdownOptionsRerender(data);   //this.getDropdownOptions(data);
        this.selectedState = null;
        this.selectedLocationState = { value: null, id: null };
        if (this.stateCheck == true) {
          this.state = false
          this.stateCheck = false
        }
        else {
          this.state = true
          this.stateCheck = true
        }
      });
    }
    this.onPageEdit();
  }

  public onSetState(selectedVal: any, selectedAddress: any): void {
  
    this.selectedCountry = selectedVal;
    this.selectedLocationCountry = selectedVal;
    this.loading = true;

      // Call service for getting states corresponding to selected country
      this.inputParams.service.serviceClass[this.inputParams.service.getStateListFromDb](this.selectedCountry.id).subscribe((data) => {
        this.loading = false;
        this.selectStateAddDropdown = new DropdownTypeAheadModel('', '', '', '', []);
        this.selectStateAddDropdown.selection = "value";
        this.selectStateAddDropdown.options = this.getDropdownOptionsRerender(data);   //this.getDropdownOptions(data);
        this.selectStateAddDropdown.dropdownValue = { "id": selectedAddress.stateId, "value": selectedAddress.state };
        this.selectedState = { "id": selectedAddress.stateId, "value": selectedAddress.state };;
        if (this.stateCheck == true) {
          this.state = false
          this.stateCheck = false
        }
        else {
          this.state = true
          this.stateCheck = true
        }
      });
    this.onPageEdit();
  }
  

  public getDropdownOptions(data: any) {
    let options: any[] = [];
    let dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    let pickListData: any;
    pickListData = data;
    for (let i = 0; i < Object.keys(pickListData).length; i++) {
      options.push({
        value: pickListData[i].value,
        route: '',
        id: pickListData[i].id,
        data: pickListData[i]
      });
    }
    return dropdownModel;
  }

  public getDropdownOptionsRerender(data: any) {
    let options: any[] = [];
    for (let i = 0; i < Object.keys(data).length; i++) {
      options.push({
        value: data[i].value,
        route: '',
        id: data[i].id,
        data: data[i]
      });
    }
    return options;
  }

  public onSelectPrimaryAddMedia(selectedVal: boolean): void {
    this.selectedPrimaryAddFlag = true;
    this.onPageEdit();
  }

  public addAddress(evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      this.countryTyped = "flag";
      this.typeTyped = "flag";
      this.addressModelInputChanges();
      // this.disableTypeAheadSave = true;
      var flagEditNew = true;
      //Handle  validation
      var statusFlag = this.validateAddress();
      if (statusFlag == true && null != this.selectedAddressType) {
        var itemExists: any;

        if (this.addedAddressList.address != null) {
          var itemExists = this.addedAddressList.address.find(i => i.addressType == this.selectedAddressType.value);
        }
        if (!itemExists) {
          var flagEditNew = true;
          //for create and edit scenarios
          if (this.peopleId == null || flagEditNew == true) {
            this.addressId = null;
          }
        }

        //REST input values after adding new row
        this.selectedAddress = null;
        this.selectedAddressType = '';
        this.selectTypeAddDropdown.selection = "null"
        this.selectStateAddDropdown.selection = "null"
        this.selectCountryAddDropdown.selection = "null"
        this.inputAddrTypeDropdown.selection = "null"
        this.selectedCity = null;
        this.selectedCountry = '';
        this.selectedState = '';
        this.selectedZip = null;
        this.selectedtype = [];
      }
      else {
        this.validAddress = false;
        setTimeout(() => {
          this.validAddress = true;
        }, 1000);
      }

      this.selectStateAddDropdown.dropdownValue = { "id": "", "value": "" };
      this.selectStateAddDropdown.title = "";
      this.selectStateAddDropdown.selection = "null";

      this.selectedCountryBuffer="United States"
      if(this.tempCountryType[0]) {
        this.selectCountryAddDropdown.dropdownValue = this.tempCountryType[0].value;
        this.selectCountryAddDropdown.selection = "value"
        this.selectCountryAddDropdown.title=this.tempCountryType[0].value;
        this.selectedCountry = { "id": this.tempCountryType[0].id, "value": this.tempCountryType[0].value };
        this.selectedLocationCountry = { "id": this.tempCountryType[0].id, "value": this.tempCountryType[0].value };
      }

      // 1302-Changes for People - Address Edit 
      this.resetLocationFlags();
      this.addressLocAdd = true;
      this.locationAction = "Add Address";
      this.modalService.open(this.myLocationModal, { centered: true, size: 'lg', backdrop: 'static' });
        setTimeout(() => {
          document.getElementById("dummy-text").focus();
         }, 300);

      //Changes to introduce Address Type in Input section
      if(this.selectedInputAddressType) {
        let options = this.selectTypeAddDropdown.options;
        this.selectTypeAddDropdown = new DropdownTypeAheadModel('', '', '', '', options);
        if(this.selectedInputAddressType.id == "" || this.selectedInputAddressType.id == null){
          this.selectTypeAddDropdown.dropdownValue = this.selectTypeAddDropdown.options[0];
          this.selectedAddressType = this.selectTypeAddDropdown.options[0];
        }else{
          this.selectTypeAddDropdown.dropdownValue = { "id": this.selectedInputAddressType.id, "value": this.selectedInputAddressType.value };
          this.selectedAddressType = { id: this.selectedInputAddressType.id, route: "", value: this.selectedInputAddressType.value }
        }
        this.selectTypeAddDropdown.selection = "value";
        this.selectTypeAddDropdown.title = this.selectedInputAddressType.value;
      }
      this.primaryLocation = this.selectedPrimaryAddFlag;
      this.onPageEdit();
    }
  }

  public validateAddress() {
    if ((this.selectedAddressType !== undefined)  || (null != this.selectedAddressType && null != this.selectedAddressType.value)) {
      if (this.selectedAddress == null) {
        if (this.selectedCity == null) {
          if (this.selectedState == null || this.selectedState == undefined || this.selectedState == "") {
            if (this.selectedZip == null) {
              if (this.selectedCountry == null || this.selectedCountry == undefined || this.selectedState == "") {
                var validAddress = false
              }
              else {
                return validAddress = true;
              }
            }
            else {
              return validAddress = true;
            }
          }
          else {
            return validAddress = true;
          }
        }
        else {
          return validAddress = true;
        }
      }
      else {
        return validAddress = true;
      }
    }
    return validAddress;
  }

  public onDeleteAddressGrid(i: number, evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      if (this.addedAddressList.address.length > 1) {
        if (this.addedAddressList.address[i].primary == true) {
          this.addedAddressList.address[0].primary = true;
        }
        if (i == 0) {
          this.addedAddressList.address[1].primary = true;
        }
      }
      else {
        this.selectedPrimaryAddFlag = true;
      }
      this.addedAddressList.address.splice(i, 1);
      this.onPageEdit();
    }
  }

  public selectedAsstTypeAheadRecord(evt: any) {
    this.loading = true;
    this.selectedAsstPartyId = evt.partyId;
    this.newAssistant = evt.typeAheadDisplayName;
    this.newAsstData = evt;
    this.loading = false;
    this.onPageEdit();
  }

  // 1302-Changes for People - Address Edit 
  public onEditAddress(selectedAddress: any, index: number, evt): void {
    if (evt.keyCode === undefined || evt.keyCode === 13) {
      this.disableTypeAheadSave = false;
      this.addressLocEdit = true;
      this.companyLocEdit = false;
      this.selectedAddressIndex = index;
      this.modalService.open(this.myLocationModal, { centered: true, size: 'lg', backdrop: 'static' });
      setTimeout(() => {
        document.getElementById("dummy-text").focus();
       }, 300);
      this.selectTypeAddDropdown.selection = "null";
      this.selectTypeAddDropdown.title = "";
 
      if(null != selectedAddress) {
        let options = this.selectTypeAddDropdown.options;
        this.selectTypeAddDropdown = new DropdownTypeAheadModel('', '', '', '', options);
        this.selectTypeAddDropdown.dropdownValue = { "id": selectedAddress.addressTypeId, "value": selectedAddress.addressType };
        this.selectTypeAddDropdown.selection = "value";
        this.selectTypeAddDropdown.title = selectedAddress.addressType;

        this.selectedAddressType = { id: selectedAddress.addressTypeId, route: "", value: selectedAddress.addressType }
        this.selectedAddressFirstLine = selectedAddress.firstLine;
        this.selectedAddressSecondLine = selectedAddress.secondLine;
        this.selectedAddressThirdLine = selectedAddress.thirdLine;
        this.selectedLocationCity = selectedAddress.city;
        this.selectedLocationState = { "id": selectedAddress.stateId, "value": selectedAddress.state }
        this.selectedPostal = selectedAddress.zip;
        this.selectedLocationCountry = { "id": selectedAddress.countryId, "value": selectedAddress.country }

        this.countryTyped = selectedAddress.country;
        this.stateTyped = selectedAddress.state;
        this.typeTyped = selectedAddress.addressType;

        this.selectCountryAddDropdown.dropdownValue = { "id": selectedAddress.countryId, "value": selectedAddress.country };
        this.selectCountryAddDropdown.title = "selectedAddress.country";
        this.selectCountryAddDropdown.selection = "value";
        this.onSetState(this.selectCountryAddDropdown.dropdownValue, selectedAddress);   
        
        this.selectedCountry = { "id": selectedAddress.countryId, "value": selectedAddress.country }
        this.primaryLocation = selectedAddress.primary;
        this.locationAction = "Edit Address";
      }

      // if (this.addedAddressList.address.length > 1) {
      //   if (this.addedAddressList.address[i].primary == true) {
      //     this.addedAddressList.address[0].primary = true;
      //   }
      //   if (i == 0) {
      //     this.addedAddressList.address[1].primary = true;
      //   }
      // }
      // else {
      //   this.selectedPrimaryAddFlag = true;
      // }
      // this.addedAddressList.address.splice(i, 1);
      this.onPageEdit();
    }
  }

  // function is to perform adding assistant to assistant list.
  public addAssistant(evt) {
    if (evt.keyCode === undefined || evt.keyCode === 13 || evt.keyCode === 6) {
      if ((this.newAssistant != '') && (this.newAssistant != null)) {
        let itemExists = this.validateAssistant();
        if (!itemExists) {
          this.addedAssistant = false;
          this.addToAssistantList();
        }
        this.typeAheadAsstSelectorHeader.clearTypeAheadField();
        this.newAssistant = null;
        this.selectedAsstPartyId = null;
        this.assistantPrimaryRadio = false;
        this.newAsstData = null;
      }
    }
  }

  public validateAssistant() {
    var itemExists: boolean;
    if (this.newAssistant != '') {
      if (this.newAssistant) {
        itemExists = this.assistantList.find(i => i.name == this.newAssistant);
      }
    }
    return itemExists;
  }

  public addToAssistantList() {
    if (this.assistantPrimaryRadio == true) {
      if (this.assistantList.length > 0) {
        this.assistantList.forEach((item, ForEachindex) => {
          item.primary = false;
        });
      }
    }
    this.assistantList.push({ 'name': this.newAssistant, 'disabled': true, 'primary': this.assistantPrimaryRadio, partyId: this.selectedAsstPartyId });
  }

  // Check for primary and if not found, set the first assistant as primary.
  public checkAssistantList() {
    var primaryExists = this.assistantList.find(i => i.primary == true);
    if ((!primaryExists) && (1 <= this.assistantList.length)) {
      this.assistantList[0].primary = true;
    }
  }

  /*
   * Function to set boolean on page edit */
  public onPageEdit() {
    if (false === this.pageEdited) {
      this.pageEdited = true;
    }
    this.onValEdit.emit(this.pageEdited);
  }
  public removeDisplayName() {
    this.selectedDisplayName = null;
  }

  // public openDate(evt) {
  //   if (evt.keyCode === 9) {
  //     this.d3.close()
  //   }

  // }
  
  //On key enter of dropdown-typeahead the value will be added the list
public addOccupationOnEnterPress(evt){
  if(evt.key==="Enter"){
    this.addOcptn('13');
  }
}
public addTypeOnEnterPress(evt){
  if(evt.key=="Enter"){
    this.addType('13');
  }
}

// public dobOnFocus(event){
//   this.d3.open(); 
//   // document.getElementById("dobDatePicker").focus();
//   let myContainer = <HTMLElement> document.querySelector(".dropdown-menu.show");
//   myContainer.focus();

// }


// RC-1382 - Company location address edit changes
public onEditCompanyLocation(selectedCompany: any, index: number, evt): void {
  if (evt.keyCode === undefined || evt.keyCode === 13) {

    this.companyLocEdit = true;
    this.selectedCompanyIndex = index;
    this.disableTypeAheadLoc = false;
    this.modalService.open(this.myLocationModal, { centered: true, size: 'lg', backdrop: 'static' });
    setTimeout(() => {
      document.getElementById("dummy-text").focus();
    }, 300);
    // document.getElementById("loc-name loc-name-input").focus();

    if(selectedCompany) {
      if(selectedCompany.locationDropDownList) {
        let dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, selectedCompany.locationDropDownList);
        this.companyLocEditDropdown = dropdownModel;
      }
      if(selectedCompany.locationDropDownList && selectedCompany.locationDropDownList.length > 0) {
        this.companyLocAddInEdit = false;
        if(selectedCompany.addedLocation) {
          this.selectedAddressFirstLine = selectedCompany.addedLocation.firstLine;
          this.selectedAddressSecondLine = selectedCompany.addedLocation.secondLine;
          this.selectedAddressThirdLine = selectedCompany.addedLocation.thirdLine;
          this.selectedLocationCity = selectedCompany.addedLocation.city;
          this.selectedLocationState = { "id": selectedCompany.addedLocation.stateId, "value": selectedCompany.addedLocation.state }
          this.selectedPostal = selectedCompany.addedLocation.zip;
          this.selectedLocationCountry = { "id": selectedCompany.addedLocation.countryId, "value": selectedCompany.addedLocation.country }
          this.selectedCountry = { "id": selectedCompany.addedLocation.countryId, "value": selectedCompany.addedLocation.country }
          this.primaryLocation = selectedCompany.addedLocation.primary;
          
          this.selectCountryAddDropdown.dropdownValue = { "id": selectedCompany.addedLocation.countryId, "value": selectedCompany.addedLocation.country };
          this.selectCountryAddDropdown.title = selectedCompany.addedLocation.country;
          this.selectCountryAddDropdown.selection = "value";
          this.onSetState(this.selectCountryAddDropdown.dropdownValue, selectedCompany.addedLocation);
          
          this.selectedCountry = { "id": selectedCompany.addedLocation.countryId, "value": selectedCompany.addedLocation.country };
  
          if(this.companyLocEditDropdown && this.companyLocEditDropdown.options) {
            this.companyLocEditDropdown.options.forEach((companyLocOption, index) => {
              if(companyLocOption && 
                companyLocOption.id == selectedCompany.locationId && companyLocOption.value == selectedCompany.addedLocation.locationName) {
                  this.newCompanyLocation = companyLocOption;
                  return false;
                }
              });
          } 
          this.companyLocEditDropdown.selection = "value";
          this.companyLocEditDropdown.dropdownValue = this.newCompanyLocation;
          this.companyLocEditDropdown.title = selectedCompany.addedLocation.locationName;
        }
  
        // this.locationPhoneJsonFromDB = selectedCompany.addedPhone.map(e => ({ ... e }));
        this.locationPhoneJsonFromDB.phone  = this.deepClone(selectedCompany.addedPhone);
        this.addedPhoneJson.phone  = Object.assign([], selectedCompany.addedPhone);
        
        if (null !== this.addedPhoneJson.phone && this.addedPhoneJson.phone !== undefined) {
          for (const itm of this.addedPhoneJson.phone) {
            itm.addedPhone = { "id": itm.typeId, "value": itm.type }
            //Set the phone 'edited flag to false on opening location popup
            itm.edited = false;
          }
        } 
        if(!this.addedPhoneJson.phone 
          || (this.addedPhoneJson.phone && this.addedPhoneJson.phone.length === 0)){
          this.selectedPrimaryFlagN = true;
        } else {
          this.selectedPrimaryFlagN = false;
        }
        this.selectedPhoneNumber = "";
      } 
      //Add New Location flow if there is no location exist for a company in Edit location mode:-
      else if(!selectedCompany.locationDropDownList 
        || (selectedCompany.locationDropDownList && selectedCompany.locationDropDownList.length <= 0)){
          this.companyLocEdit = false;
          this.disableTypeAheadLoc = false;
          this.companyLocAddInEdit = true;
          this.addedPhoneJson.phone  = Object.assign([], this.addedPhoneJson.phone);
          this.setPrimaryLocationName();
          this.settingsForAddNewLoc();
      }

      this.phoneDropdown.dropdownValue = {"id": "", "value": ""};
      this.phoneDropdown.title = "";
      this.phoneDropdown.selection = "value";

      this.locationAction = selectedCompany.companyName;
      this.selectedCompanyForEdit = selectedCompany;
    }
    this.onPageEdit();
  }
}

/**
 * RC-1382 - Company location address edit changes
 * onSelectEditCompanyLocation
 * @param value 
 * @param type 
 */
onSelectEditCompanyLocation(value, type) {
    if (value && value.data && value.data.locationAddress) {     
      this.selectedAddressFirstLine =  value.data.locationAddress.firstLine;
      this.selectedAddressSecondLine = value.data.locationAddress.secondLine;
      this.selectedAddressThirdLine = value.data.locationAddress.thirdLine;
      this.selectedLocationCity = value.data.locationAddress.city;
      if( value.data.locationAddress.stateId && value.data.locationAddress.state) {
        this.selectedLocationState = { "id": value.data.locationAddress.stateId, "value": value.data.locationAddress.state }
      } else {
        this.selectedLocationState = { value: null, id: null };
      }
      if( value.data.locationAddress.countryId && value.data.locationAddress.country) {
        this.selectedLocationCountry = { "id": value.data.locationAddress.countryId, "value": value.data.locationAddress.country }
      } else {
        this.selectedLocationCountry = { value: null, id: null };
      }
      this.selectedPostal = value.data.locationAddress.zip;

      if( value.data.locationAddress.countryId && value.data.locationAddress.country) { 
        let opt = this.selectCountryAddDropdown.options;
        this.selectCountryAddDropdown = new DropdownTypeAheadModel('', '', '', '', opt);
        this.selectCountryAddDropdown.dropdownValue = { "id": value.data.locationAddress.countryId, "value": value.data.locationAddress.country };
        this.selectCountryAddDropdown.title = value.data.locationAddress.country;
        this.selectCountryAddDropdown.selection = "value";
      } else {
        let opt = this.selectCountryAddDropdown.options;
        this.selectCountryAddDropdown = new DropdownTypeAheadModel('', '', '', '', opt);
        this.selectCountryAddDropdown.dropdownValue = { "id": "", "value": "" };
        this.selectCountryAddDropdown.title = "";
        this.selectCountryAddDropdown.selection = "value";
      }
      if( value.data.locationAddress.stateId && value.data.locationAddress.state) {
        let opt = this.selectStateAddDropdown.options;
        this.selectStateAddDropdown = new DropdownTypeAheadModel('', '', '', '', opt);
        this.selectStateAddDropdown.dropdownValue = { "id": value.data.locationAddress.stateId, "value": value.data.locationAddress.state };
        this.selectStateAddDropdown.title = value.data.locationAddress.state;
         this.selectStateAddDropdown.selection = "value";
      } else {
        let opt = this.selectStateAddDropdown.options;
        this.selectStateAddDropdown = new DropdownTypeAheadModel('', '', '', '', opt);
        this.selectStateAddDropdown.dropdownValue = { "id": "", "value": "" };
        this.selectStateAddDropdown.title = "";
        this.selectStateAddDropdown.selection = "value";
      }
      this.primaryLocation = value.data.locationAddress.primary ? true : false;
      this.addedPhoneJson.phone = value.data.phone ? value.data.phone : null;
      this.newCompanyLocation = value;
      this.companyLocSelectOnEdit = true;
    }
  this.onPageEdit();
}
 /**
  * RC-1382 - Company location address edit changes
  * Service call for edit company location
  * @param locationsModel 
  */
  editCompanyLocationServiceCall(locationsModel: CompaniesLocationsModel, companyId: number) {
      this.resetRequired = false;
      if(this.companyLocAdd) {
        this.resetRequired = true;
      }
      this.loading = true;
      if(this.companyLocAdd || (this.companyLocEdit && locationsModel.locationId > 0) || this.companyLocAddInEdit) {
        this.inputParams.service.serviceClass[this.inputParams.service.saveLocationCompanies](locationsModel, companyId).
        subscribe((res) => {
            //Set the locationId if new location is created
            if(locationsModel.locationId == null || locationsModel.locationId <= 0) {
              locationsModel.locationId = (res && res.locationId) ? res.locationId : null;
            }
            this.inputParams.service.serviceClass[this.inputParams.service.getCompanyDetailsFromDb](companyId).subscribe((data) => {
              setTimeout(() => {

                if(this.companyLocEdit || this.companyLocAddInEdit) {
                  if(this.companyList[this.selectedCompanyIndex]) {
                    this.companyList[this.selectedCompanyIndex].locationDropDownList = this.getDropdownListOptions(data);
                  }
                  
                } else if(this.companyLocAdd) {
                  this.companyDropdown = new DropdownTypeAheadModel('', '', '', '', []);
                  this.companyDropdown.options = this.getLocationDropdownOptionsRerender(data);
                  this.companyDropdown.selection = "value";
                  if(this.companyDropdown && this.companyDropdown.options && this.companyDropdown.options.length > 0) {
                    // this.companyDropdown.dropdownValue = this.companyDropdown.options[0];
                    // this.companyDropdown.selection = "value";
                    // this.companyDropdown.title = this.companyDropdown.options[0].value;
                    // this.onSelectCompanyLocation(this.companyDropdown.options[0],'company');
                    // this.closeDropdown = true;

                    var newDataSet = {
                        id: res.locationId,
                        value: res.name,
                        route:"",
                        data: res
                    }
                    newDataSet.data.address = res.locationAddress.country;
                    this.companyDropdown.dropdownValue = {"id": res.locationId,"value": res.name}
                    this.companyDropdown.selection = "value";
                    this.companyDropdown.title = res.name;
                    this.newCompanyLocation={"id": res.locationId,"value": res.name}
                    this.newCompanyLocationId=res.locationId;
                    this.onSelectCompanyLocation(newDataSet, 'company')
                    this.closeDropdown = true;
                    this.addCompanyList();
                    setTimeout(() => {
                        this.closeDropdown = false;
                    }, 500);

                  }
                  this.companyLocAdd = false;
                }
                this.loading = false;
              }, 100);   
            });
            console.log("addLocation respones..." + res);
            if(this.companyLocEdit || this.companyLocAddInEdit) {
              if(this.companyList[this.selectedCompanyIndex]) {
                this.companyList[this.selectedCompanyIndex].locationId = locationsModel.locationId;
                this.companyList[this.selectedCompanyIndex].addedLocation = this.createLocationAddressObject(locationsModel.name, this.primaryLocation);
                this.companyList[this.selectedCompanyIndex].addedPhone =  this.addedPhoneJson.phone;
              }
              console.log(this.addedPhoneJson.phone);
            }
            this.resetRequired = true;
            this.clearLocationPopupValues();
          },
          (err) => {
            console.log("Error editting company location for people", err);
            this.loading = false;
            this.resetRequired = false;
          }
        );
      }
      
  }

  /**
   * RC-1382 - Company location address edit changes
   * Method to check whether the company location dropdown is empty or not
   */
  companyLocDropDownEmpty (enteredTxt: any) { 
    this.companyDropdownEmpty = true;
    if(enteredTxt && typeof enteredTxt === 'string') {
      this.selectedLocationName = enteredTxt.trim();
    } 
    if(!enteredTxt && this.companyDropdown && this.companyDropdown.options) {
      this.companyDropdownEmpty = false;
    }
    else if(this.companyDropdown && this.companyDropdown.options) {
      if(typeof enteredTxt === 'string' && enteredTxt) {
        this.companyDropdown.options.forEach((optionItem, index) => {
          if(optionItem && optionItem.value && optionItem.value.toLowerCase().indexOf(enteredTxt.toLowerCase()) > -1) {
            this.companyDropdownEmpty = false;
            this.selectedLocationName = "";
            return;
          } 
        });
      } else if(typeof enteredTxt !== 'string'){
        this.companyDropdownEmpty = false;
      }
    }
    return this.companyDropdownEmpty;
  }

  /**
   * RC-1382 - Company location address edit changes
   * Method to create a Location Address Object
   * @param locationName 
   */
  createLocationAddressObject(locationName: String, primary: boolean, defaultCountry?: String) {
    if(defaultCountry === "AddDefaultCountry"){
      this.selectedLocationCountry= {
        value: "United States",
        id: "US"
      }
    }
    var selectLocationAddress = {
      addressId: null,
      locationName: locationName,
      addressType: null,
      addressTypeId: null,
      firstLine: this.selectedAddressFirstLine,
      secondLine: this.selectedAddressSecondLine,
      thirdLine: this.selectedAddressThirdLine,
      city: this.selectedLocationCity,
      state: (null != this.selectedLocationState) ? this.selectedLocationState.value : null,
      stateId: (null != this.selectedLocationState) ? this.selectedLocationState.id : null,
      zip: this.selectedPostal,
      countryId: (null != this.selectedLocationCountry) ? this.selectedLocationCountry.id : null,
      country: (null != this.selectedLocationCountry) ? this.selectedLocationCountry.value : null,
      primary: primary,
    }
    return selectLocationAddress;
  }

  public onLocationEditValueEvent(eventTxt){
    if(!this.companyLocSelectOnEdit) {
      this.companyLocAdd = false;
      this.companyDropdownEmpty = true;   
      if(this.companyLocEditDropdown && this.companyLocEditDropdown.options) {
        if(typeof eventTxt === 'string' && eventTxt) {
          this.companyLocEditDropdown.options.forEach((optionItem, index) => {
            if(optionItem.value.toLowerCase().indexOf(eventTxt.toLowerCase()) > -1) {
              this.companyDropdownEmpty = false;
              this.selectedLocationName = "";
              return;
            } 
          });
        }
      }
      // this.disableTypeAheadLoc = eventTxt ? false : true;
      this.validateAddLocPopup();
      if(!eventTxt || this.companyDropdownEmpty) {
        this.cancelWarning();
        this.selectedLocationName = eventTxt;
        this.companyLocEdit = true;
        this.companyLocAddInEdit = true;
  
        this.selectCountryAddDropdown.dropdownValue = { "id": "", "value": "" };
        this.selectCountryAddDropdown.title = "";
        this.selectCountryAddDropdown.selection = "null";
        this.selectStateAddDropdown.dropdownValue = { "id": "", "value": "" };
        this.selectStateAddDropdown.title = "";
        this.selectStateAddDropdown.selection = "null";
      }
    } 
    this.companyLocSelectOnEdit = false;
  }

  public onSelectCompanyPrimary(selectedVal: boolean): void {
    this.selectedCompanyPrimary = true;
    this.onPageEdit();
  }

  public onSelectCompanyPrimaryRow(company: any): void {
    //Set other primary flags to false if current selected one is true.
    if (this.companyList && this.companyList.length > 0) {
      for (const companyItem of this.companyList) {
        companyItem.primaryCompany = false;
      }
    }
    company.primaryCompany = true;
    this.onPageEdit();
  }

  // It returns the formatted Phone number
  public formatPhoneNumber(phoneNumberString: string) {
    var cleaned = ('' + phoneNumberString).replace(/\D/g, '')
    var match = cleaned.match(/^(\d{0,3})(\d{0,3})(\d{0,4})(\d{0,4})$/)
    if (match) {
      if (phoneNumberString.length > 10) {
        var result = '(' + match[1] + ') ' + match[2] + '-' + match[3] + '-' + match[4]
      } else {
        var result = '(' + match[1] + ') ' + match[2] + '-' + match[3]
      }

      if (result.substring(result.length-1) == "-")
      {
        result = result.substring(0, result.length-1);
      }
      return result;
    }
    return null
  }


  /**
   * Method to set Focus to Company Location DropDown
   */
 setFocusCompanyLocationDropDown(): void {
  setTimeout(() => {
    if (this.stateCheck == true) {
      this.state = false;
      this.stateCheck = false;
    }
    else {
      this.state = true;
      this.stateCheck = true;
    }
  }, 4000);
}

/**
 * Method to set Company Location Phone list to PhoneMediaModel array
 */
setCompanyLocationPhone(addedPhoneArray: any) {
  let locationAddedPhoneJson = { "phone": [] };
  if (addedPhoneArray && addedPhoneArray.length > 0) {
      for (const itm of addedPhoneArray) {
        let addedPhoneItem = { "id": itm.typeId, "value": itm.type };
        var formattedPhoneNumber = this.formatPhoneNumber(itm.value);
        let phoneModel = new PhoneMediaModel(itm.id, itm.contactId, itm.typeId, itm.type,
              itm.value, itm.primary, addedPhoneItem, false, true, formattedPhoneNumber);
        locationAddedPhoneJson.phone.push(phoneModel);
      }
    }  
    return locationAddedPhoneJson;
  }

  /**
   * Method to set the primary phone to added row on edit mode
   */
  public onSelectPrimaryPhoneRow(selectedVal: boolean, selectedPhone: any): void {
    if (this.addedPhoneJson && this.addedPhoneJson.phone) {
      for (const itm of this.addedPhoneJson.phone) {
        itm.primary = false;
      }
    }
    if(selectedPhone) {
      selectedPhone.primary = true;
    }
    this.onPageEdit();
  }

  /**
   * Method to set the primary phone number on top of the list
   */
  setPrimaryPhoneOnTop() {
    if(this.addedPhoneJson.phone) {
      this.addedPhoneJson.phone.forEach((phoneItm, index) => {
        if(phoneItm && phoneItm.primary) {
          this.addedPhoneJson.phone.splice(index, 1);
          this.addedPhoneJson.phone.splice(0, 0, phoneItm); 
        }
      });
    }
  }

  /**
   * Method to clear location popup values
   */
  clearLocationPopupValues() {
    this.selectedLocationName = "";
    this.selectedlocationPrimary = false;
    this.primaryLocation = false;
    this.selectedAddressFirstLine = "";
    this.selectedAddressSecondLine = "";
    this.selectedAddressThirdLine = "";
    this.selectedLocationState = { value: null, id: null };
    this.selectedPostal = "";
    this.selectedLocationCity = "";
    this.selectedLocationCountry = { value: null, id: null };
    this.validLocationName = true;
    //Add Multiple Locations - reset back primary flag to false
    // 1302-Changes for People - Address Edit 
    this.selectedAddressType = { value: null, id: null };
    this.selectedCountry = { value: null, id: null };
    this.selectedPhoneNumber = "";
    if (this.addedPhoneJson.phone) {
      for (const itm of this.addedPhoneJson.phone) {
        itm.addedPhone = { "id": itm.id, "value": "" }
      }
      this.addedPhoneJson.phone = [];
    }
    this.locationAction = "";

    this.selectedLocationState = { "id": "", "value": "" };
    this.selectedLocationCountry = { "id": "", "value": "" };
    this.selectedCountry = { "id": "", "value": "" };
    this.newCompanyLocation =  { "id": "", "value": "" };
    
    this.selectCountryAddDropdown.dropdownValue = { "id": "", "value": "" };
    this.selectCountryAddDropdown.title = "";
    this.selectCountryAddDropdown.selection = "value";

    this.selectStateAddDropdown.dropdownValue = { "id": "", "value": "" };
    this.selectStateAddDropdown.title = "";
    this.selectStateAddDropdown.selection = "value";

    this.companyLocEditDropdown.dropdownValue = { "id": "", "value": "" };
    this.companyLocEditDropdown.title = "";
    this.companyLocEditDropdown.selection = "value";

    this.phoneDropdown.dropdownValue = { "id": "", "value": "" };
    this.phoneDropdown.title = "";
    this.phoneDropdown.selection = "value";

    this.phoneDropdownForPopup.dropdownValue = { "id": "", "value": "" };
    this.phoneDropdownForPopup.title = "";
    this.phoneDropdownForPopup.selection = "value";

    this.selectedPrimaryFlagN = false;
    this.setDefaultInputAddressDetails();
  }
  

  public getLocationDropdownOptionsRerender(data: any) { // re render dropdownoptions 
    let options: any[] = [];

    if (data) {
      for (let i = 0; i < Object.keys(data).length; i++) {
        options.push({
          value: data[i].name,
          route: '',
          id: data[i].locationId,
          data: data[i]
        });
      }
      return options;
    }else{
      return options;
    }
  }

  public listNamesAdded(evtListName: Array<TypeAheadModel>): void {
    if (evtListName && evtListName.length) {
      this.rollCallModeTitle = 'Edit ';
      this.typeAheadModalConfig.title = "Add Alias";
      this.showTypeAhead = false;
      this.rollCallListNameResult = evtListName;
    }
  }

  public addAliasName(evt: any): void {
    this.typeAheadTitle = 'Enter alias and press enter';
    this.showTypeAhead = true;
    this.typeAheadAddSameName = false;
    this.disableSearchName = true;
    this.hasNoResultsCallback = false;
  }

  public hideTypeAheadHeader(evt: any) {
    this.showTypeAhead = false;
  }

	
  /**
   * deep clone an existing array to new
   */
  deepClone(oldArray: Object[]) {
    let newArray: any = [];
    if(oldArray) {
      oldArray.forEach((item) => {
        newArray.push(Object.assign({}, item));
      });
    }
    return newArray;
  }

  /**
   * Set the location phone with db values 
   */
  setLocationPhoneWithDBValue() {
    if(this.selectedCompanyIndex > -1 &&  this.companyList &&  this.companyList.length > 0 && 
      this.companyList[this.selectedCompanyIndex]) {
        this.companyList[this.selectedCompanyIndex].addedPhone =  this.locationPhoneJsonFromDB.phone;
    }
  }

  /**
   * Method to set location name to Primary if there is no other location exists.
   * Handle it for 1. Location add/edit from company quick add popup
   * 2. Location quick add from location dropdown enter key
   * If selected loc name is empty/null/undefined
   */
  setPrimaryLocationName() {
    if(!this.selectedLocationName || 
      (this.selectedLocationName && this.selectedLocationName.trim().length === 0)) {
      if(this.companyAddLocationEdit) {
        this.selectedLocationName = this.primay_location_name;
        this.disableTypeAheadLoc = false;
      }
      else if((this.companyLocAdd && 
        (!this.companyDropdown || (this.companyDropdown && !this.companyDropdown.options) ||
        (this.companyDropdown && this.companyDropdown.options && this.companyDropdown.options.length === 0))) 
        || this.companyLocAddInEdit) {
          this.selectedLocationName = this.primay_location_name;
          this.disableTypeAheadLoc = false;
      }
    }
  }

  /**
   * Method to set location name to Primary on add company (add button), if there is no location exists
   */
  private setPrimaryLocationOnAddCompanyList() {
    if(!this.selectedCompanyLocAddress 
      || (this.selectedCompanyLocAddress && !this.selectedCompanyLocAddress.locationName)) {
        this.selectedCompanyLocAddress = this.createLocationAddressObject(this.primay_location_name, false, "AddDefaultCountry",);
    }
    return this.selectedCompanyLocAddress;
  }

  /**
   * Method to replace the 'Primary' or Empty location name with the City name if entered
   */
  replaceLocationWithCityName(locationName: string) {
    if(!locationName 
      || (locationName != null && locationName.trim().length === 0)
      || (locationName != null && locationName.trim() === this.primay_location_name ))  {
        if(this.selectedLocationCity && this.selectedLocationCity.trim().length > 0) {
          locationName = this.selectedLocationCity.trim();
        }       
    }
    return locationName;
  }

  //Address Type select input area (address section)
  public onSelectInputAddressType(selectedVal: any): void {
    this.selectedInputAddressType = selectedVal;
    this.onPageEdit();
  }

  /**
   * Method to set Default Input address details
   */
  private setDefaultInputAddressDetails() {
    //Set default Address Type to 'Home'
    if(this.inputAddrTypeDropdown && this.selectTypeAddDropdown.options) {
      let options = this.inputAddrTypeDropdown.options;
      this.inputAddrTypeDropdown = new DropdownTypeAheadModel('', '', '', '', options);
      
      if(this.inputAddrTypeDropdown.options) {
        this.inputAddrTypeDropdown.dropdownValue = this.inputAddrTypeDropdown.options[0];
        this.inputAddrTypeDropdown.selection = "value";
        this.inputAddrTypeDropdown.title = this.inputAddrTypeDropdown.options[0].value;
        this.selectedInputAddressType = { id: this.inputAddrTypeDropdown.options[0].id, route: "", value: this.inputAddrTypeDropdown.options[0].value };
      }
    }
    //Select the input primary radio button as selected when there is no entry in that list
    if (!this.addedAddressList 
      || (this.addedAddressList && !this.addedAddressList.address) 
      || (this.addedAddressList && this.addedAddressList.address && this.addedAddressList.address.length === 0)) {
      this.selectedPrimaryAddFlag = true;
    } else {
      this.selectedPrimaryAddFlag = false;
    }
  }

  public onChangeInputAddrType(typedVal: any): void {
    // console.log("typedVal.." + typedVal);
 }

 /**
  * Method to check backspace (evt.keyCode = 8) in Firefox, this is to ignore the space char on back space
  */
public phoneKeydown(evt) {
  let numIndexBeforeSpace = 3;
  if(evt.keyCode === 8 && evt.target.selectionStart 
     && navigator.userAgent.indexOf("Firefox") > -1 && this.selectedPhoneNumber 
     && this.selectedPhoneNumber.length === numIndexBeforeSpace && this.phoneKeydownCount === 0) {
   evt.target.setSelectionRange(5, 5);
   evt.target.focus();
   this.phoneKeydownCount ++; 
  }
  //Reset keydownCount based on the length of entered phone number
  if( this.selectedPhoneNumber && this.selectedPhoneNumber.length !== numIndexBeforeSpace) {
   this.phoneKeydownCount = 0;
  }
 }
 public phoneKeydownMain(evt){
  let numIndexBeforeSpace = 3;
  if(evt.keyCode === 8 && evt.target.selectionStart 
     && navigator.userAgent.indexOf("Firefox") > -1 && this.newPhoneNo 
     && this.newPhoneNo.length === numIndexBeforeSpace && this.phoneKeydownCount === 0) {
   evt.target.setSelectionRange(5, 5);
   evt.target.focus();
   this.phoneKeydownCount ++; 
  }
  //Reset keydownCount based on the length of entered phone number
  if( this.newPhoneNo && this.newPhoneNo.length !== numIndexBeforeSpace) {
   this.phoneKeydownCount = 0;
  }
 }

  /**
  * Method to do the settings for adding new locations, Primary settings, check box, default country settings etc.
  */
 public settingsForAddNewLoc(){
  this.selectedPrimaryFlagN = true;
  if(this.tempCountryType[0]) {
    let opt = this.selectCountryAddDropdown.options;
    this.selectCountryAddDropdown = new DropdownTypeAheadModel('', '', '', '', opt);

    this.selectCountryAddDropdown.dropdownValue = this.tempCountryType[0];
    this.selectCountryAddDropdown.selection = "value"
    this.selectCountryAddDropdown.title=this.tempCountryType[0].value;
    this.selectedCountry = { "id": this.tempCountryType[0].id, "value": this.tempCountryType[0].value };
    this.selectedLocationCountry = { "id": this.tempCountryType[0].id, "value": this.tempCountryType[0].value };
    let selectedAddress = {stateId:"", state:""};
    this.onSetState(this.selectCountryAddDropdown.dropdownValue, selectedAddress);
  }
}
  /** Method to get the selected company id edit company OR add new location in edit mode */
  private getSelectedCompanyIdEditMode() {
    let selectedCompanyId = null;
    if(this.companyLocEdit || this.companyLocAddInEdit) {
      if (this.companyList && this.companyList.length > 0 && this.selectedCompanyIndex >= 0
        && this.companyList[this.selectedCompanyIndex] != null) {
          selectedCompanyId =  this.companyList[this.selectedCompanyIndex].partyId;
      }
    }
    return selectedCompanyId;
  }

  /**
   * Method to add new Location in company-location edit flow, if there is already locations exists
   */
  public addNewExtraLocationInEdit() {
    this.companyLocEdit = false;
    this.companyLocAddInEdit = true;
    this.clearLocationPopupValues();
    this.addedPhoneJson.phone = Object.assign([], this.addedPhoneJson.phone);
    this.settingsForAddNewLoc();
    this.locationAction = this.selectedCompanyForEdit.companyName;
    this.disableTypeAheadLoc = true;
  }

  private resetSelectedCompany() {
    this.selectedCompanyIndex = -1;
    this.selectedCompanyForEdit = null;
  }

    /** Focus trap inside duplicate alert popup is the popup is available. author rahul 
   **/
  TrapFocusDuplicateAlertModal() {
    const allBackgroundElements = document.querySelectorAll('.container, [tabindex="0"]')
    const tickBtn = document.getElementById('c2c-unsaved-changes-button-modal-ok')
    const closeBtn = document.getElementById('c2c-unsaved-changes-button-modal-cancel')
    //listen for keydown. Check for target of the event.
    document.addEventListener('keydown', (e) => {
      if (e.target === closeBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          tickBtn.focus()
        } else if (e.keyCode === 9) {
          e.preventDefault();
          tickBtn.focus()
        }
      } else if (e.target === tickBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          closeBtn.focus()
        }else if (e.keyCode === 9) {
          e.preventDefault();
          closeBtn.focus()
        }
      }
    })
  }
  // get notes string byte length and limit to 4000
  getByteLen(event) {
    // Force string type
    var limit = 4000;
    var normal_val = String(event.target.value);
    var byteLen = 0;
    for (var i = 0; i < normal_val.length; i++) {
        var c = normal_val.charCodeAt(i);
        byteLen += c < (1 <<  7) ? 1 :
                   c < (1 << 11) ? 2 :
                   c < (1 << 16) ? 3 :
                   c < (1 << 21) ? 4 :
                   c < (1 << 26) ? 5 :
                   c < (1 << 31) ? 6 : Number.NaN;
    }
    console.log("byteLen: ", byteLen);
    if(byteLen > limit){
      this.notes_error_msg = true;
    }else{
      this.notes_error_msg = false;
    }
  }
}
