import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DropdownModel } from './../../models/dropdown/dropdown.model';
import 'rxjs/add/operator/map';

@Injectable()
export class CreateEditPeopleService {
    savePeopleData: any = '';
    status: boolean = false;
    deleteImage: boolean = false;
    messege: string = '';
    newOccupationList: any = [];
    newTypeList: any = [];
    newphoneList: any = [];
    neweMailList: any = [];
    newsMediaList: any = [];
    AssistantListz: any = [];

    // modified data for editing saving array
    OccupationList: any = [];
    PhoneList: any = [];
    TypeList: any = [];
    eMailList: any = [];
    sMediaList: any = [];
    AssistantList: any = [];
    companyList: any = [];
    lastname: any;
    firstname: any;

    data_response: any = [];

    constructor(private http: HttpClient) { }

    CreateJson(dataSet, peopleId, image, createdBy, createdDate, createdTime, updatedBy, updatedDate, updatedTime, addresses, officeAddress, homeAddress, AKA, companies, peopleName, dob, people_account_type, peopletitle, occupationList, typeList, phoneList, eMailList, sMediaList, assistantList, peopleNotes, companyList, selectedNameSchema) {

        this.newOccupationList = [];
        this.newTypeList = [];
        this.newphoneList = [];
        this.neweMailList = [];
        this.newsMediaList = [];
        this.AssistantListz = [];
        this.companyList = [];
        if (peopleName == '') {
            this.status = false;
            this.messege = 'please type your name';
            this.data_response = '';
        }
        else {
            var newOccupationList = this.perform_createJsonOccupationList(occupationList);
            var newTypeList = this.perform_createJsonTypeList(typeList);
            var newphoneList = this.perform_createJsonphoneList(phoneList);
            var neweMailList = this.perform_createJsoneMailList(eMailList);
            var newsMediaList = this.perform_createJsonsMediaList(sMediaList);
            var newAssistantList = this.perform_createJsonAssistantList(assistantList);
            this.perform_createJsonCompanyList(companyList);

            this.data_response = this.CreateDataArray(dataSet, peopleId, image, createdBy, createdDate, createdTime, updatedBy, updatedDate, updatedTime, addresses, officeAddress, homeAddress, AKA, this.companyList, peopleName, dob, people_account_type, peopletitle, peopleNotes, selectedNameSchema);
            this.status = true;
            this.messege = "JSON created successfully";
        }

        var data = { 'createdJson': this.data_response, 'status': this.status, 'messege': this.messege };
        return data;
    }


    //function to crete json for OCCUPATION LIST list  as same as to call the web service
    perform_createJsonOccupationList(mainOccupationList) {
        if (mainOccupationList != null) {
            mainOccupationList.forEach((item, index) => {
                if (item.partyId == '') {
                    this.newOccupationList.push({ id: '', occupationId: item.occupationId, partyId: '', occupationName: item.value });
                } else {
                    this.newOccupationList.push({ id: item.id, occupationId: item.occupationId, partyId: item.partyId, occupationName: item.occupationName });
                }

            });
            return this.newOccupationList
        }

    }

    //function to crete json for TYPE LIST   as same as to call the web service
    perform_createJsonTypeList(mainTypeList) {
        if (mainTypeList != null) {
            mainTypeList.forEach((item, index) => {
                if (item.partyId == '') {
                    if (this.newTypeList.findIndex(x => x.id == item.type.id) == -1) {
                        this.newTypeList.push({ id: '', typeId: item.type.id, partyId: '', name: item.name });
                    }
                } else {
                    this.newTypeList.push({ id: item.id, typeId: item.typeId, partyId: item.partyId, name: item.name });
                }

            });
            return this.newTypeList
        }

    }

    //function to crete json for PHONE LIST  as same as to call the web service
    perform_createJsonphoneList(mainphoneList) {
        if (mainphoneList != null) {
            mainphoneList.forEach((item, index) => {
                if (item.contactId == '') {
                    if (this.newphoneList.findIndex(x => x.value == item.no) == -1) {
                        this.newphoneList.push({ id: '', contactId: '', value: item.no, primary: item.primary, typeId: item.type.id, type: item.type.value });
                    }
                } else {
                    this.newphoneList.push({ id: item.id, contactId: item.contactId, value: item.no, primary: item.primary, typeId: item.typeId, type: item.type.value });
                }
            });
            return this.newphoneList
        }
    }

    //function to crete json for EMAIL LIST   as same as to call the web service
    perform_createJsoneMailList(maineMailList) {
        if (maineMailList != null) {
            maineMailList.forEach((item, index) => {
                if (item.contactId == '') {
                    if (this.neweMailList.findIndex(x => x.value == item.eMail) == -1) {
                        this.neweMailList.push({ id: '', contactId: '', primary: item.primary, typeId: item.type.id, type: item.type.value, value: item.eMail });
                    }
                } else if (item.contactId != '') {
                    this.neweMailList.push({ id: item.id, contactId: item.contactId, primary: item.primary, typeId: item.type.id, type: item.type.value, value: item.eMail });
                }

            });
            return this.neweMailList
        }
    }
    //function to crete json for SOCIAL MEDIA LIST   as same as to call the web service
    perform_createJsonsMediaList(mainsMediaList) {
        if (mainsMediaList != null) {
            mainsMediaList.forEach((item, index) => {
                if (item.contactId == '') {
                    if (this.newsMediaList.findIndex(x => x.value == item.address) == -1) {
                        this.newsMediaList.push({ id: '', contactId: '', primary: item.primary, typeId: item.type.id, type: item.type.value, value: item.address });
                    }
                } else if (item.contactId != '') {
                    this.newsMediaList.push({ id: item.id, contactId: item.contactId, primary: item.primary, typeId: item.type.id, type: item.type.value, value: item.address });
                }

            });
            return this.newsMediaList;
        }
    }

    //function to crete json for ASSISTANT LIST   as same as to call the web service
    perform_createJsonAssistantList(mainAssistantList) {
        if (mainAssistantList != null) {
            mainAssistantList.forEach((item, index) => {
                if (item.partyId == '') {
                    if (this.AssistantListz.findIndex(x => x.name == item.name) == -1) {
                        this.AssistantListz.push({ relationId: '', parentPartyId: '', partyId: item.partyId, primary: item.primary, name: item.typeAheadDisplayName });
                    }
                } else if (item.partyId != '') {
                    this.AssistantListz.push({ relationId: item.relationId, parentPartyId: item.parentPartyId, partyId: item.partyId, primary: item.primary, name: item.name });
                }
            });
            return this.AssistantListz;
        }
    }

    //Creating JSON with all Details that are manipulated in this whole service
    CreateDataArray(dataSet, peopleId, image, createdBy, createdDate, createdTime, updatedBy, updatedDate, updatedTime, addresses, officeAddress, homeAddress, AKA, companies, peopleName, dob, people_account_type, peopletitle, peopleNotes, selectedNameSchema) {
        this.firstname = null;
        this.lastname = peopleName;
        if (/\s/.test(peopleName)) {
            let stringToSplit = peopleName;
            var peopleName = stringToSplit.split(" ");
            this.lastname = peopleName[1];
            this.firstname = peopleName[0];
        }
        if (peopleName.indexOf(',') > -1) {
            let stringToSplit = peopleName;
            var peopleName = peopleName.split(',')
            this.lastname = peopleName[0];
            this.firstname = peopleName[1]
        }
        if (peopleName.indexOf(', ') > -1) {
            let stringToSplit = peopleName;
            var peopleName = peopleName.split(', ')
            this.lastname = peopleName[0];
            this.firstname = peopleName[1]
        }
        if (this.firstname == undefined) {
            this.firstname = null;
        } else if (this.lastname == undefined) {
            this.lastname = null;
        }

        if (image === "deleted") {
            image = null
            this.deleteImage = true
        } else {
            this.deleteImage = false

            if (image != null) {
                // TODO: Temporary solution, this need to be removed
                if (image.length < 200) {
                    image = null
                }
            }
        }

        this.savePeopleData = [
            {
                "partyId": peopleId,
                "firstName": this.firstname,
                "lastName": this.lastname,
                "image": image,
                "deleteImage": this.deleteImage,
                "dataSet": dataSet,
                "createdBy": createdBy,
                "createdDate": createdDate,
                "createdTime": createdTime,
                "updatedBy": updatedBy,
                "updatedDate": updatedDate,
                "updatedTime": updatedTime,
                "businessPersonal": null,
                "entityTypeId": people_account_type,
                "dob": dob,
                "notes": peopleNotes,
                "types": this.newTypeList,
                "addresses": addresses,
                "officeAddress": officeAddress,
                "homeAddress": homeAddress,
                "title": peopletitle,
                "AKA": AKA,
                "phone": this.newphoneList,
                "email": this.neweMailList,
                "occupations": this.newOccupationList,
                "assistants": this.AssistantListz,
                "companies": companies,
                "socialMedia": this.newsMediaList,
                "names": selectedNameSchema
            }
        ]

        return this.savePeopleData;
    }

    //geting the people detail data got from webservice using peopleid  as same as to diaplay in UI 
    createEditJson(email, phone, occupations, assistants, socialmedia, types) {
        this.OccupationList = [];
        this.PhoneList = [];
        this.TypeList = [];
        this.eMailList = [];
        this.sMediaList = [];
        this.AssistantList = [];

        var occupationslist = this.perform_createEditJsonOccupationList(occupations);
        var phonelist = this.perform_createEditJsonPhoneList(phone);
        var typelist = this.perform_createEditJsonTypeList(types);
        var emaillist = this.perform_createEditJsoneMailList(email);
        var socialmedia = this.perform_createEditJsonsMediaList(socialmedia);
        var assistants = this.perform_createEditJsonAssistantList(assistants);
        var data = { occupationslist: occupationslist, phonelist: phonelist, typelist: typelist, emaillist: emaillist, socialmedia: socialmedia, assistants: assistants };
        return data
    }

    //function to create json for OCCUPATION LIST list as same as to diaplay in UI 
    perform_createEditJsonOccupationList(mainOccupationList) {
        if (mainOccupationList != null) {
            mainOccupationList.forEach((item, index) => {
                this.OccupationList.push({ mainid: item.id, id: item.id, occupationId: item.occupationId, partyId: item.partyId, occupationName: item.occupationName, value: item.occupationName });
            });
            return this.OccupationList
        } else {
            return this.OccupationList = [];
        }

    }

    //function to create json for PHONE LIST EDIT as same as to diaplay in UI 
    perform_createEditJsonPhoneList(mainphoneList) {
        if (mainphoneList != null) {
            mainphoneList.forEach((item, index) => {
                this.PhoneList.push({ id: item.id, contactId: item.contactId, typeId: item.typeId, no: item.value, 'disabled': true, primary: item.primary, 'type': { id: item.typeId, value: item.type, route: "", data:{abbreviation: null, id: item.typeId, sortOrder: 1, typeName: "PHONE_TYPE", value: item.type} } }
                );
            });
            return this.PhoneList
        } else {
            return this.PhoneList = [];
        }

    }

    //function to create json for TYPE LIST EDIT as same as to diaplay in UI 
    perform_createEditJsonTypeList(maintypeList) {
        if (maintypeList != null) {
            maintypeList.forEach((item, index) => {
                this.TypeList.push({ id: item.id, typeId: item.typeId, partyId: item.partyId, name: item.name, 'disabled': true, 'type': item.name });
            });
            return this.TypeList
        } else {
            return this.TypeList = [];
        }
    }

    //function to create json for EMAIL LIST EDIT  as same as to diaplay in UI 
    perform_createEditJsoneMailList(mainemailList) {
        if (mainemailList != null) {
            mainemailList.forEach((item, index) => {
                this.eMailList.push({ 'eMail': item.value, 'disabled': true, id: item.id, contactId: item.contactId, primary: item.primary, typeId: item.typeId, value: item.value, type: { id: item.typeId, value: item.type, route: "" } });

            });
            return this.eMailList
        } else {
            return this.eMailList = [];
        }
    }

    //function to create json for SOCIAL MEDIA LIST EDIT  as same as to diaplay in UI 
    perform_createEditJsonsMediaList(socialmediaList) {
        if (socialmediaList != null) {
            socialmediaList.forEach((item, index) => {
                this.sMediaList.push({ 'address': item.value, 'disabled': true, id: item.id, contactId: item.contactId, primary: item.primary, value: item.value, type: { id: item.typeId, value: item.type, route: "" } });
            });
            return this.sMediaList;
        } else {
            return this.sMediaList = [];
        }
    }

    //function to create json for assistantList   as same as to diaplay in UI 
    perform_createEditJsonAssistantList(assistantList) {
        if (assistantList != null) {
            assistantList.forEach((item, index) => {
                this.AssistantList.push({ disabled: true, relationId: item.relationId, parentPartyId: item.parentPartyId, partyId: item.partyId, primary: item.primary, name: item.name });
            });
            return this.AssistantList
        } else {
            return this.AssistantList = [];
        }

    }

    /* 
     * Function to create json for company list 
     */
    perform_createJsonCompanyList(companyListData) {
        var companyListJson: any = [];
        if (companyListData != null) {
            companyListData.forEach((item, index) => {
                 //RC-1382 - Company location address edit changes
                // companyListJson.push({ partyId: item.companyId, locationId: item.locationId, primary: item.primary });
                companyListJson.push({ partyId: item.partyId, locationId: item.locationId, primary: item.primaryCompany });
          
            });
            this.companyList = companyListJson;
        } else {
            this.companyList = [];
        }
    }
}
