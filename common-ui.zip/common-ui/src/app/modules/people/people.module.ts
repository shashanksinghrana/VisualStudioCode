import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { CommonModule } from '@angular/common';
import { ModalModule } from '../../modal/modal.module';
import { PeopleComponent } from './people.component';
import { FormModule } from './../../modules/form/form.module';
import { ButtonModule } from './../../modules/elements/button/button.module';
import { ImageUploaderModule } from './../../modules/elements/image-uploader/imageUploader.module';
import { ImageUploaderService } from './../../services/image-uploader/image.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import { TypeAheadModule } from './../elements/type-ahead/type-ahead.module';
import { TypeAheadNameListingModule } from './../elements/type-ahead-name-listing/type-ahead-name-listing.module';
import { TypeAheadModalModule } from './../../forms/type-ahead/type-ahead-modal/type-ahead-modal.module';
import { CreateEditPeopleService } from './create-edit-people.service';
import { DropDownTypeAheadModule } from '../../modules/elements/dropdown-typeahead/dropdown-typeahead.module';
import { NgxMaskModule } from '../../utils/ngx-mask/ngx-mask.module';

/**
 * The CreateEditPeopleModule
 *
 * Module that contains all Create/Edit People related components.
 */
@NgModule({
  imports: [
    TextMaskModule,
    NgxMaskModule.forRoot(),
    TypeAheadModule.forRoot(),
    ModalModule.forRoot(),
    TypeAheadModalModule.forRoot(),
    TypeAheadNameListingModule.forRoot(),
    CommonModule,
    ButtonModule,
    FormModule,
    ReactiveFormsModule,
    FormsModule,
    ImageUploaderModule,
    NgbModule,
    DropDownTypeAheadModule
  ],
  declarations: [PeopleComponent],
  providers: [ImageUploaderService, CreateEditPeopleService],
  exports: [PeopleComponent, TextMaskModule]
})

export class PeopleModule { }

