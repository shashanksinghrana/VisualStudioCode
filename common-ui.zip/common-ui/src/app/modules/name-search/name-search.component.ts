import { Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import { TypeAheadService } from '../../services/http/type-ahead/type-ahead.service';
import { TypeAheadDisplayResultModel } from '../../models/type-ahead/type-ahead-display-result.model';

@Component({
  selector: 'c2c-name-search',
  templateUrl: './name-search.component.html',
  styleUrls: ['./name-search.component.scss'],
  providers: [TypeAheadService]
})

export class NameSearchComponent implements OnInit {

  @ViewChild('typeAhead') typeAhead: ElementRef;

  public typeAheadDataService: any;
  public title: string = 'Type Name to Search and Press Enter';
  public displayString: string;

  constructor(private typeAheadService: TypeAheadService ) { }

  public displayDataResults: TypeAheadDisplayResultModel = {
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'teamMembers'],
      display: '`${data.primaryName ?` (alias for ${data.primaryName}) `:` (team of ${data.teamMembers})`}`',
      notAllColumnsRequired: true
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'ssnEndChars']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this.typeAheadService,
      get: 'get'
    }
  };

  public typeAheadModalConfig: any = {
    title: 'Add New Talent name ',
    label: 'This is a label',
    showAddAlias: true,
    displayNameAs: true,
    additionalFieldsDisplayed: true,
    modalName: 'typeAheadName'
  };

  public saveNameTalentEvn: any;

  ngOnInit() {
    // service needed for typeAhead data
   this.typeAheadDataService = this.typeAheadService;

  }

  public noSearchResultsReturned(evt?: Event): void {
  }

  public selectedTypeAheadRecord(evt: Event): void {
  }

  public typeAheadReturnResults(evt: Event): void {

  }

  public saveNameTalentEvent(evn: any) {
    this.saveNameTalentEvn = evn;
  }
}
