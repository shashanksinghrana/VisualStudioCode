import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NameSearchComponent } from './name-search.component';
import { TypeAheadModule } from '../elements/type-ahead/type-ahead.module';
import { FormModule } from '../form/form.module';
import { ModalModule } from '../../modal/modal.module';

import { TypeAheadNameListingModule } from '../elements/type-ahead-name-listing/type-ahead-name-listing.module';
import { TypeAheadModalModule } from './../../forms/type-ahead/type-ahead-modal/type-ahead-modal.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ModalModule.forRoot(),
    TypeAheadModule.forRoot(),
    TypeAheadNameListingModule.forRoot(),
    TypeAheadModalModule.forRoot(),
    FormModule,
  ],
  declarations: [
    NameSearchComponent,
  ]
})
export class NameSearchModule { }
