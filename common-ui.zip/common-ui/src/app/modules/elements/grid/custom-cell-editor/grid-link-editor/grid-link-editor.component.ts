import { Component, HostBinding, Output, EventEmitter } from '@angular/core';
import { ICellEditorAngularComp } from "ag-grid-angular";

@Component({
    selector: 'c2c-grid-link-editor',
    templateUrl: './grid-link-editor.component.html',
    styleUrls: ['./grid-link-editor.component.scss']
})
export class GridLinkEditorComponent implements ICellEditorAngularComp  {
    private value: any;
    private params: any;
    private titlesArray: string;

    @Output() uploadFileEvent: EventEmitter<object> = new EventEmitter<object>();

    /** 
     * 
     * @param params (expecting value)
     */
    agInit(params): void {
        this.params = params;
        this.value = params.value;
    }

    getValue(): any {
        return this.value;
    }

    uploadFile(file){
        this.value = file;
        this.uploadFileEvent.emit(file);
    }
}