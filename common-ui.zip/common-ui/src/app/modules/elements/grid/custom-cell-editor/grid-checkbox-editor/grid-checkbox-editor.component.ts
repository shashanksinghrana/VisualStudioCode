import { Component, HostBinding } from '@angular/core';
import { ICellEditorAngularComp } from 'ag-grid-angular';

@Component({
    selector: 'c2c-grid-checkbox-editor',
    templateUrl: './grid-checkbox-editor.component.html',
    styleUrls: ['./grid-checkbox-editor.component.scss']
})
export class GridCheckBoxEditorComponent implements ICellEditorAngularComp  {
    private params: any;
    private titlesArray: string;
    public value: any;
    /**
     *
     * @param params (expecting value)
     */
    agInit(params): void {
        this.params = params;
        this.value = params.value;
    }

    getValue(): any {
        return this.value;
    }

    /**
    * Returns the classes for the checkbox based on edit mode
    */
   getReadOnlyClass() {
    let cssClasses = '';
    if (this.value) {
        cssClasses = 'c2c-input-checkboxes-checked c2c-input';
    }
    return cssClasses;
    }

    onClick(event) {
     this.value = !this.value;
    }

     /**Method to check box on click of enter key */
   checkOnKeyDown(event: any): void {
    const checkBox = <HTMLInputElement>document.getElementById('c2c-grid-checkboxes');
    const isChecked = checkBox.checked;
    const keyCode = event.keyCode ? event.keyCode : event.which;
    if (keyCode === 13) {
       if (isChecked) {
        this.value = !this.value;
       } else {
        this.value = !this.value;
       }
    }
   }
}
