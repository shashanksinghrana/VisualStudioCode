import { Component } from '@angular/core';
import { ICellEditorAngularComp } from 'ag-grid-angular';
import { CancelButtonModel } from '../../../../../models/button/cancel-button/cancel-button.model';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';

@Component({
    selector: 'c2c-grid-icons-editor',
    templateUrl: './grid-icons-editor.component.html',
    styleUrls: ['./grid-icons-editor.component.scss']
})
export class GridIconsEditorComponent implements ICellEditorAngularComp  {
    private event;
    private params: any;
    public value: any;
    public currentRow: any;
    public rowIndex: number;
    public saveIcon: { visible: boolean, action?: () => any, showIconsOnNextLine?: boolean};
    public cancelIcon: { visible: boolean, action?: () => any, showIconsOnNextLine?: boolean };
    public deleteIcon: { visible: boolean, action?: () => any, showIconsOnNextLine?: boolean };
    public cancelButtonOptions = new CancelButtonModel('', '', '', '');
    public showIconsOnNextLine: boolean = true;
    public hideInputField: boolean = false;
    public placeHolderText: string = '';

    constructor(private gridEventService: GridEventService) { }
    /**
     *
     * @param params (expecting value)
     */
    agInit(params): void {
        this.params = params;
        this.value = params.value;
        this.placeHolderText = params.column.colDef.cellRendererParams.placeHolderText;
        this.currentRow = params.node;
        this.saveIcon = params.column.colDef.cellRendererParams.saveIcon;
        this.cancelIcon = params.column.colDef.cellRendererParams.cancelIcon;
        this.deleteIcon = params.column.colDef.cellRendererParams.deleteIcon;
        this.rowIndex = params.rowIndex;

        if ((this.saveIcon && this.saveIcon.showIconsOnNextLine) ||
            (this.cancelIcon && this.cancelIcon.showIconsOnNextLine) ||
            (this.deleteIcon && this.deleteIcon.showIconsOnNextLine)) {
            this.showIconsOnNextLine = true;
        } else {
            this.showIconsOnNextLine = false;
        }

        if (params.column.colDef.field === '' || params.column.colDef.headerName === '') {
            this.hideInputField = true;
        } else {
            this.hideInputField = false;
        }
        
        if (!params.column.colDef.cellRendererParams.showDefaultHeightInViewMode) {
            params.node.setRowHeight(50);
            this.gridEventService.onRowHeightChangeForEditExpandEvent('expand');
        }
    }

    getValue(): any {
        return this.value;
    }

   /**
   * Performs the given click action passed in. This is a generic function set on each individual button for dynamic capabilities.
   *
   * @param fn The callback action (defined in {@link GridIconParamsModel}) to be performed on the button. Also passes
   *  the current row for doing operations on the row data.
   */
    public performAction(fn: (row) => any): void {
        fn(this.currentRow);
    }

    public performActionOnKeyDown(fn: (row) => any, evt): void {
        const key = evt.keyCode ? evt.keyCode : evt.which;
           if (key === 39 || key === 37) { // return;
              event.stopPropagation();
           } else if (key === 13) {
             fn(this.currentRow);
          }
    }

    /** Method to handle keyDown event in Input field */
    public checkInputOnKeyDown(evt): any {
        const key =  evt.keyCode ?  evt.keyCode : evt.which;
         if (key === 13) {
            event.stopPropagation();
        }
    }

    getClass() {
        if (!this.showIconsOnNextLine) {
            return 'pull-left width-88';
        }
    }
}