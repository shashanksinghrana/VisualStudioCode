import { Component, HostBinding, ElementRef, ViewChild, AfterViewInit  } from '@angular/core';
import { ICellEditorAngularComp } from 'ag-grid-angular';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';

@Component({
    selector: 'c2c-grid-titles-editor',
    templateUrl: './grid-titles-editor.component.html',
    styleUrls: ['./grid-titles-editor.component.scss']
})
export class GridTitlesEditorComponent implements ICellEditorAngularComp {
    public value: any;
    private params: any;
    private creditedAs: string;
    private pKAValue: string;
    @ViewChild('focus') focus: ElementRef;
    constructor(private gridEventService: GridEventService) { }

    /**
     *
     * @param params (expecting value)
     */
    agInit(params): void {
        this.params = params;
        this.value = params.value;
        if (!Array.isArray(this.value[0])) {
            this.value[0] = [this.value[0]];
        }
        this.pKAValue = this.value[1];
        this.creditedAs = this.value[2];
        let paramLength = this.value.length;

        if (!params.node.data.pka) {
            paramLength = this.value.length;
            this.value = [this.value[0], null, this.value[1]];
            this.pKAValue = params.node.data.pka;
            this.creditedAs = this.value[1];
        }

        params.node.setRowHeight((paramLength * 20) + 60);
        this.gridEventService.onRowHeightChangeForEditExpandEvent('expand');

    }

    ngAfterViewInit() {
        // Auto focus set to input box
        setTimeout(() => this.focus.nativeElement.focus());
    }

    getValue(): any {
        const subTitles = this.params.node.data.subTitles;
        if (subTitles && subTitles.length > 0) {
            subTitles.forEach(element => {
                element['Credited As'] = this.value[2].trim();
            });
        } else {
            this.params.node.data['subTitles'] = [];
            this.params.node.data.subTitles.push({
                'Credited As': this.value[2]
            });
        }
        this.value = this.value[0][0].split(' ')[0];
        return this.value;
    }

}
