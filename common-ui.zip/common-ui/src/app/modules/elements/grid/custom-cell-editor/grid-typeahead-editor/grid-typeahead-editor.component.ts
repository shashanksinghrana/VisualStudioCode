import { Component, HostBinding, ViewChild, ViewContainerRef, ElementRef, Renderer2 } from '@angular/core';
import { ICellEditorAngularComp } from 'ag-grid-angular';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';
import { FormGroup, FormBuilder, FormControl, AbstractControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { TypeAheadDisplayResultModel } from '../../../../../models/type-ahead/type-ahead-display-result.model';
import { TypeAheadService } from '../../../../../services/http/type-ahead/type-ahead.service';


@Component({
    selector: 'grid-typeahead-editor',
    templateUrl: './grid-typeahead-editor.component.html',
    styleUrls: ['./grid-typeahead-editor.component.scss'],
    providers: [TypeAheadService]
})
export class GridTypeaheadEditorComponent implements ICellEditorAngularComp {
    @ViewChild('typeAhead') typeAhead: ElementRef;
    @ViewChild('typeAheadSelector') typeAheadSelector: any;

    public typeAheadDataService: any;
    public title: string = 'Type Name to Search and Press Enter';
    public displayString: string;
    public value: any;
    private params: any;
    public formTypeAhead: FormGroup;
    public cellWidth: string;
    public oldvalue: any;
    public typeAheadFocus: boolean = true;
    public textField: boolean = false;
    public textLimit: number = 1000;
    public invalid: boolean = false;
    public FocusInputField: boolean = false;

    constructor(private gridEventService: GridEventService,
        private typeAheadService: TypeAheadService) {
    }


    /**
        Typeahd configurtion
    */
    public displayDataResults: TypeAheadDisplayResultModel = {
        filterType: '',
        primaryDisplayColumn: '',
        secondaryDisplay: {
            secondaryColumns: [''],
            display: '``',
            notAllColumnsRequired: false
        },
        metaDataColumns: {
            default: ['', '']
        },
        noRecordsToReturn: '10',
        service: {
            serviceClass: this.typeAheadService,
            get: 'get'
        }
    };

    /**
     *
     * @param params (expecting id ,typeAheadDisplayName pair)
     */
    agInit(params): void {
        this.textField = params['column'].colDef.cellRendererParams.textField;
        this.textLimit = params['column'].colDef.cellRendererParams.textLimit;
        if (this.textField == false) {
            this.displayDataResults.filterType = params['column'].colDef.cellRendererParams.filterType;
            this.displayDataResults.primaryDisplayColumn = params['column'].colDef.cellRendererParams.primaryDisplayColumn;
            this.displayDataResults.metaDataColumns['default'] = params['column'].colDef.cellRendererParams.metaDataColumns;
        }
        this.params = params;
        this.value = params.value;
        this.FocusInputField = params.cellStartedEdit;
        this.formTypeAhead = new FormGroup({
            typeAheadSelector: new FormControl(''),
            textFieldSelector: new FormControl('')
        });
        this.oldvalue = params.value;
        this.gridEventService.onRowHeightChangeForEditExpandEvent('expand');
        this.cellWidth = params.column.actualWidth - 5 + 'px';
        this.onChange();
    }

    /**
       returning the value which is seleted,if it is null then the exsiting value is returned
    */
    getValue(): any {
        if (this.textField == true) {
            var returnValue = this.formTypeAhead.controls.textFieldSelector.value;
            return returnValue;
        } else {
            if (this.value != '') {
                return this.value;
            } else {
                return this.oldvalue
            }
        }
    }

    /**
       Displaying typeahead as a poup ie,outside/overlayed over the grid
    */
    isPopup(): boolean {
        if (this.textField == true) {
            return false;
        } else {
            return true;
        }
    }

    /**
        triggering configuration on component initialized
    */
    ngOninit() {
        this.typeAheadDataService = this.typeAheadService;
    }

    /**
        triggering configaration after typeahead view initialized
    */
    ngAfterViewInit() {
        if (this.textField == false) {
            this.typeAheadSelector.typeAheadField.nativeElement.value = this.value['typeAheadDisplayName'];
            if (this.params['column'].colDef.cellRendererParams.autofocus == true) {
                var focusTypeahead = this.typeAheadSelector.typeAheadField.nativeElement;
                setTimeout(() => {
                    focusTypeahead.focus();
                }, 200)
            }
        } else {
            this.formTypeAhead['controls'].textFieldSelector.setValue(this.value);
            setTimeout(() => {
                var textField = document.getElementById('text-field');
                textField.setAttribute('maxlength', this.textLimit.toString());
                if (this.FocusInputField == true) {
                    textField.focus();
                }
            }, 200)
            if (this.params.column.colDef.cellRendererParams && this.params.column.colDef.cellRendererParams.showValidationBorder) {
                this.invalid = true;
            } else {
                this.invalid = false;
            }
        }

    }

    /**
    *On change function to dectect the typeahaed changes
    */
    private onChange(): void {
        //talent typeahaed onchange functionality goes here
        const typeAheadSelector: AbstractControl = this.formTypeAhead.get('typeAheadSelector');
        typeAheadSelector.valueChanges.subscribe(val => {

        });
    }



    /**
        On select of TypeAheadRecord
    */
    public selectedTypeAheadRecord(evt: Event): void {
        this.value = { id: evt['partyId'], typeAheadDisplayName: evt['typeAheadDisplayName'], selectedData: evt }
    }


}
