import { Component, HostBinding, ViewChild, ViewContainerRef, ElementRef, Renderer2 } from '@angular/core';
import { ICellEditorAngularComp } from 'ag-grid-angular';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';
import { FormGroup, FormBuilder, FormControl, AbstractControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { DropdownTypeAheadModel } from '../../../../../models/dropdown-typeahead/dropdown-typeahead.model';


@Component({
    selector: 'grid-typeahead-dropdown-editor',
    templateUrl: './grid-typeahead-dropdown-editor.component.html',
    styleUrls: ['./grid-typeahead-dropdown-editor.component.scss'],
    providers: []
})
export class GridTypeaheadDropdownEditorComponent implements ICellEditorAngularComp {
    public options:any;
    public dropdownData: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
    public cellWidth: string;
    public oldvalue: any;
    private params: any;
    public value: any;
    public formTypeAhead: FormGroup;
    // @ViewChild('typeAheadSelector') typeAheadSelector: any;
    @ViewChild('dropdown-typeahead-grid') someInput: ElementRef;

    constructor(private gridEventService: GridEventService) {
    }

    /**
     *
     * @param params (expecting id ,value pair)
     */
    agInit(params): void {
        this.params = params;
        this.options=params['column'].colDef.cellRendererParams.StatusOptions;
        this.gridEventService.onRowHeightChangeForEditExpandEvent('expand');
        this.cellWidth = params.column.actualWidth - 5 + 'px';
        this.formTypeAhead = new FormGroup({
            typeAheadSelector: new FormControl(''),
        });
    }

    /**
       returning the value which is seleted,if it is null then the exsiting value is returned
    */
    getValue(): any {
        if (this.value != '' && this.value != undefined) {
            return this.value;
        } else  {
            return this.oldvalue
        }
    }

    /**
       Displaying typeahead as a poup ie,outside/overlayed over the grid
    */
    isPopup(): boolean {
        return true;
    }

    /**
        triggering configuration on component initialized
    */
    ngOninit() {

    }

    /**
        triggering configaration after typeahead dropdown view initialized
    */
    ngAfterViewInit() {
        this.dropdownData=new DropdownTypeAheadModel('', '', '', '', this.options);
        this.dropdownData.dropdownValue =  this.params.value;
        this.dropdownData.selection = "value";
        this.oldvalue = this.params.value;
        if (this.params['column'].colDef.cellRendererParams.autofocus == true) {
            setTimeout(() => {
                var b=<HTMLElement>document.querySelector('.ng-select-container input');
                b.focus();
            }, 100)
        }
    }


    /**
        On select of TypeAhead Dropdown Record
    */
    public selectedTypeAheadDropdownRecord(evt: Event): void {
        this.value = evt;
    }


}
