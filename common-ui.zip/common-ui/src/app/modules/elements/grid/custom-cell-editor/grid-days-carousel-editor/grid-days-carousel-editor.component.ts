import { Component, AnimationPlayer, ViewChild, ElementRef } from '@angular/core';
import { AnimationBuilder, AnimationFactory, animate, style } from '@angular/animations';
import { ICellEditorAngularComp } from 'ag-grid-angular';
import * as moment_ from 'moment';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';

const moment = moment_;
/**
 * The GridDaysCarouselEditorComponent
 *
 * Grid Cell Editor that handles the display of day selector in the Grid during edit mode.
 */
@Component({
    selector: 'c2c-grid-days-carousel-editor',
    templateUrl: './grid-days-carousel-editor.component.html',
    styleUrls: ['./grid-days-carousel-editor.component.scss']
})
export class GridDaysCarouselEditorComponent implements ICellEditorAngularComp  {
    private params: any;
    private value: any;
    private currentRow: any;
    private rowIndex: number;
    private saveIcon: { visible: boolean, action?: () => any, showIconsOnNextLine?: boolean };
    private cancelIcon: { visible: boolean, action?: () => any, showIconsOnNextLine?: boolean };
    private deleteIcon: { visible: boolean, action?: () => any, showIconsOnNextLine?: boolean };
    public showIconsOnNextLine: boolean = true;
    public listOfItems: any[];
    public offset: number;
    private animationPlayed : boolean = false;
    private animationPrevPlayed : boolean = false;
    public disablePrevButton: boolean = true;
    public disableNextButton: boolean = false;
    public carouselWidth;

    private player : AnimationPlayer;
    private itemWidth : number = 32;
    private noOfDaysSelected: number = 0;
    private currentSlide = 0;
    public width: number;
    public startAnimation: boolean = false;
    @ViewChild('carousel') private carousel : ElementRef;

    constructor(private builder : AnimationBuilder, private gridEventService: GridEventService) { }
    /**
     *
     * @param params (expecting value)
     */
    agInit(params): void {
      this.params = params;
      this.offset = this.params.node.offset ? this.params.node.offset : 0;

      if (params.value) {
        this.value = params.value;
      }
      this.listOfItems = this.value ? this.value : [];

      if((params.node.data.startDate !== "") && (params.node.data.finishDate !== "")){
        this.listOfItems = params.node.data.workWeekDays;
      }
      this.carouselWidth = (this.listOfItems.length * 100);
      this.width = (7 * 30)+12;

      if(this.offset !== 0){
        this.disablePrevButton = false;
      }
  
      let totalOffset = (this.listOfItems.length*this.itemWidth - (7*this.itemWidth));
      if(this.offset === totalOffset){
        this.disableNextButton = false;
      }
      
      let cellRendererParams = params.column.colDef.cellRendererParams
      this.currentRow = params.node;
      this.deleteIcon = cellRendererParams.deleteIcon;
      this.saveIcon = cellRendererParams.saveIcon;
      this.cancelIcon = cellRendererParams.cancelIcon;
      this.rowIndex = params.rowIndex;

      if ((this.saveIcon && this.saveIcon.showIconsOnNextLine) ||
        (this.cancelIcon && this.cancelIcon.showIconsOnNextLine) ||
        (this.deleteIcon && this.deleteIcon.showIconsOnNextLine)) {
        this.showIconsOnNextLine = true;
      } else {
        this.showIconsOnNextLine = false;
      }

      params.node.setRowHeight(50);
      this.gridEventService.onRowHeightChangeForEditExpandEvent('expand');
    }

    getValue(): any {
      return this.value;
    }

     /**
   * Performs the given click action passed in. This is a generic function set on each individual button for dynamic capabilities.
   *
   * @param fn The callback action (defined in {@link GridIconParamsModel}) to be performed on the button. Also passes
   *  the current row for doing operations on the row data.
   */
  public performAction(fn: (row) => any): void {
    fn(this.currentRow);
  }

    /**
   * Performs the action on next button click
   *
   */
  next() {
    this.params.node.selectedIndex = "";
    this.animationPlayed = true;
    this.disablePrevButton = false;
    if( this.currentSlide + 1 === this.listOfItems.length ) return;

    this.currentSlide = (this.currentSlide + 1) % this.listOfItems.length;
  
    let offset = this.calculateOffset();
    
    this.params.node.currentSlide = this.currentSlide;

    const myAnimation : AnimationFactory = this.buildAnimation(offset);
    this.player = myAnimation.create(this.carousel.nativeElement);    
    this.player.play();

    let totalOffset = (this.listOfItems.length*this.itemWidth - (7*this.itemWidth));
    if(offset === totalOffset){
      this.disableNextButton = true;
    }
  }

  private buildAnimation( offset ) {
    return this.builder.build([
      animate('250ms ease-in', style({ transform: `translateX(-${offset}px)` }), )
    ]);
  }

    /**
   * Performs the action on prev button click
   *
   */
  prev() {
    this.params.node.selectedIndex = "";
    if(!this.animationPlayed || this.animationPrevPlayed){
      if((this.offset !== 0)){
        if(this.currentSlide === 0 && !this.disablePrevButton){
          this.currentSlide = this.params.node.currentSlide;
        }
      }
    }    
    this.animationPrevPlayed = true;
    this.disableNextButton = false;
   
    if( this.currentSlide === 0 ) return;
    this.currentSlide = ((this.currentSlide - 1) + this.listOfItems.length) % this.listOfItems.length;
    let offset = this.calculateOffset();
  
    const myAnimation : AnimationFactory = this.buildAnimation(offset);
    this.player = myAnimation.create(this.carousel.nativeElement);
    this.player.play();

    if((offset === 0)){
      this.disablePrevButton = true;
    }
  }

    /**
   * Performs the action when user clicks on the dates - thereby selecting or unselecting the dates
   *
   */
  onChangeSelection(index){
    let item = this.listOfItems[index];

    item.isDaySelected = !item.isDaySelected;

    // if(item.isWeekend){//commenting as weekend deselection is not required
    //   item.isDaySelected = true;
    //   item.isWeekend = !item.isWeekend;
    // }else{
    //   item.isDaySelected = !item.isDaySelected;
    // }

    this.listOfItems.forEach(element => {
      // if(element.isDaySelected && !element.isWeekend){//commenting as weekend deselection is not required
        if(element.isDaySelected){
        this.noOfDaysSelected++;
      }
    });

    if(this.params.node.selectedIndex){
      if((this.params.node.selectedIndex !== index)){
        this.params.node.currentSlide = this.currentSlide;
      }
    }else{      
      this.params.node.selectedIndex = index;
      this.params.node.currentSlide = this.currentSlide;
    }
    this.params.node.offset = this.calculateOffset();
   
    this.offset = this.params.node.offset;
   
    this.params.node.data.days = this.noOfDaysSelected;
    this.params.api.stopEditing();

    this.params.api.startEditingCell({
      rowIndex: this.rowIndex,
      colKey: 'days'
    });
  }

    /**
   * Calculates the offset by which the carousel is to be moved based on the currentSlide and Prev Offset value
   *
   */
  calculateOffset(){
    if(this.animationPlayed){
      if(!this.params.node.offset){
        return this.currentSlide  * this.itemWidth;
      }else{
        let offset = this.params.node.offset + (this.currentSlide  * this.itemWidth);
        return offset;
      }
    }else if(this.animationPrevPlayed){
      return this.currentSlide  * this.itemWidth;
    }else{
      if(this.params.node.offset){
        return this.params.node.offset;
      }
    }
  }

  /**Method to handle keyDown event on buttons*/
  public performActionOnKeyDownEvt(fn: (row) => any, evt): void {
    const key = evt.keyCode ? evt.keyCode : evt.which;
       if (key === 39 || key === 37) { // return;
          event.stopPropagation();
       } else if (key === 13) {
         fn(this.currentRow);
      }
  }
}
