import { Component, Input, Output, OnInit, OnDestroy, ViewChild, ElementRef, EventEmitter } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ColDef } from 'ag-grid';
import { GridEventService } from '../../../services/events/grid/grid-event.service';
import { Subscription } from 'rxjs/Subscription';
import { GridListComponent } from './custom-cells/grid-list/grid-list.component';
import { GridListClickableComponent } from './custom-cells/grid-list-clickable/grid-list-clickable.component';
import { GridImageComponent } from './custom-cells/grid-image/grid-image.component';
import { GridTitlesComponent } from './custom-cells/grid-titles/grid-titles.component';
import { GridIconComponent } from './custom-cells/grid-icon/grid-icon.component';
import { GridLinkComponent } from './custom-cells/grid-link/grid-link.component';
import { GridFloatingFilterComponent } from './custom-other/grid-floating-filter/grid-floating-filter.component';
import { GridLoadingOverlayComponent } from './custom-other/grid-loading-overlay/grid-loading-overlay.component';
import { AddButtonModel } from '../../../models/button/add-button/add-button.model';
import { GridPageOptionsModel } from '../../../models/grid/grid-page-options.model';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
import { SaveButtonModel } from '../../../models/button/save-button/save-button.model';
import { GridServerSideParamsModel } from '../../../models/grid/grid-server-side-params.model';
import { GridPaginationModel } from '../../../models/grid/grid-pagination.model';
import { GridCellEditOutParamModel } from '../../../models/grid/grid-cell-edit-out-param.model';
import { GridDropDownIconCellComponent } from './custom-cells/grid-dropdown-icon/grid-dropdown-icon.component';
import { GridDynamicDropDownComponent } from './custom-cells/grid-dynamic-dropdown/grid-dynamic-dropdown.component';
import { GridCheckBoxCellComponent } from './custom-cells/grid-checkbox/grid-checkbox.component';
import { DropdownModel } from '../../../models/dropdown/dropdown.model';
import { GridCheckBoxEditorComponent } from './custom-cell-editor/grid-checkbox-editor/grid-checkbox-editor.component';
import { GridLinkEditorComponent } from './custom-cell-editor/grid-link-editor/grid-link-editor.component';
import { GridIconsEditorComponent } from './custom-cell-editor/grid-icons-editor/grid-icons-editor.component';
import { GridTitlesEditorComponent } from './custom-cell-editor/grid-titles-editor/grid-titles-editor.component';
import { GridDaysCarouselComponent } from './custom-cells/grid-days-carousel/grid-days-carousel.component';
import { GridTypeaheadCellComponent } from './custom-cells/grid-typeahead/grid-typeahead.component';
import { GridTypeaheadEditorComponent } from './custom-cell-editor/grid-typeahead-editor/grid-typeahead-editor.component';
import { GridTypeaheadDropdownEditorComponent } from './custom-cell-editor/grid-typeahead-dropdown-editor/grid-typeahead-dropdown-editor.component';
import { GridTypeaheadDropdownCellComponent } from './custom-cells/grid-typeahead-dropdown/grid-typeahead-dropdown.component';
import { GridDaysCarouselEditorComponent } from './custom-cell-editor/grid-days-carousel-editor/grid-days-carousel-editor.component';
import { ColumnFilterComponent } from './custom-filter/column-filter/column-filter.component';
import { PowersearchEventService } from '../../../services/events/powersearch/powersearch-event.service';
import { GridImageListComponent } from './custom-cells/grid-image-list-clickable/grid-image-list-clickable.component';

declare var $: any;
declare var require: any;
/**
 * The Grid Component
 *
 * Common component for displaying grids in the UI, which are meant for large/complex data structures.
 * We are utilizing the third-party component, {@link https://www.ag-grid.com ag-grid} for the main functionality.
 *
 * For an example of the Grid Component in use, see the All Projects grid in Feature Casting.
 */
@Component({
  selector: 'c2c-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss']
})
export class GridComponent implements OnInit, OnDestroy {
  public disableNavigationBack: boolean;
  public disableNavigationForward: boolean;
  public frameworkComponents;
  public gridApi;
  public gridColumnApi;
  public lbRecordCount: number;
  public isPaginationHidden: boolean = false;
  public disabled: boolean = false;
  public lbTotalPages: number;
  public lbCurrentPage: number;
  public lbFirstRowOnPage: number;
  public lbLastRowOnPage: number;
  public loadingOverlayComponent: string;
  public noDataOverlay: string;
  public paginationPageSize: number;
  public isEnterKeyPressed: boolean = false;
  public isReportOptionSelected: boolean = false;
  public enableExportButton: boolean = false;
  private subscriptions: Subscription = new Subscription();
  public focusAfterAttached : any;
  private addRowSubscription: Subscription;
  private dataParams: GridServerSideParamsModel = new GridServerSideParamsModel();
  private defaultColDefs = Defaults.DEFAULT_COL_DEFS_TALENT;  // -------------------------------------
  // private defaultColDefs = Defaults.DEFAULT_COL_DEFS_PROJECTS;
  // private defaultColDefs = Defaults.DEFAULT_COL_DEF_TRACKING;
  
  private defaultPageOptions = Defaults.DEFAULT_PAGE_OPTIONS;
  private defaultPagination = Defaults.DEFAULT_PAGINATION;
  private defaultPaginationEnabled: boolean = true;
  private defaultRowData = Defaults.DEFAULT_ROW_DATA_TALENT.content;  // --------------------------------
  // private defaultRowData = Defaults.DEFAULT_ROW_DATA_PROJECTS;
  // private defaultRowData = Defaults.DEFAULT_ROW_DATA_TRACKING.content;

  private defaultRowHeight: number = 30;
  private expandSubscription: Subscription;
  private filterChangedSubscription: Subscription;
  private fitColumnsSubscription: Subscription;
  private isRefreshed: boolean = false;
  private isFiltersVisible: boolean = true;
  private refreshGridSubscription: Subscription;
  private clickEventSubscription: Subscription;
  private exportGridSubscription: Subscription;
  public enableRowEditingEventSubscription: Subscription;
  private downloadFileEventSubscription: Subscription;
  private onRowHeightChangeForEditExpandEventSubscription: Subscription;
  private downloadPdfFileSubscription: Subscription;
  public components;

  /********** Rowstyle  highlight ********/
  @Input() public gridOptions: any;
  /********** Rowstyle highlight ********/
  
  /************* Defines Inline Edit ************/
  private cellEditOutParams: GridCellEditOutParamModel = new GridCellEditOutParamModel();
  /** Outputs an event when the cell is editted. Used by the client to do server-side filtering */
  @Output() cellValueChanged: EventEmitter<object> = new EventEmitter<object>();
  @Output() cellClicked: EventEmitter<object> = new EventEmitter<object>();
  @Output() cellFocused: EventEmitter<object> = new EventEmitter<object>();
  /************* Defines Inline Edit ************/
  @Output() gridReady: EventEmitter<object> = new EventEmitter<object>();

  /** Defines the options of the Add Button. Used for configuring the type of action the button should do. */
  @Input() public addButtonOptions: AddButtonModel = new AddButtonModel('TestFC', 'TestAllProject', 'row','', '', 'Add');
  @Input() public saveButtonOptions: SaveButtonModel = new SaveButtonModel('TestFC', 'TestAllProject', 'row');

  /** Defines the columns in a Grid. If needed, you can create an Object Literal and use it to set the ColDef properties.
   * However, if possible, you should create a list of {@link ColumnDefModel} and define your columns there. */
  @Input() public columnDefs: ColDef[] = this.defaultColDefs;

  /** Provides customization for the Grid for setting buttons and title. Use {@link GridPageOptionsModel} to customize these features. */
  @Input() public pageOptions: GridPageOptionsModel = this.defaultPageOptions;

  /** Sets the data of the Grid. Any valid JSON would work for row data. Getting the data to display correctly
   * requires setting up the {@link ColumnDefModel} correctly, and passing the right parameters. */
  @Input() public rowData: any[] = this.defaultRowData;

  /** Sets the values of the bottom paginator of the Grid. This is required to be set for server-side pagination */
  @Input() public pagination: GridPaginationModel = this.defaultPagination;

  /** Enable or disable the pagination of the Grid */
  @Input() public paginationEnabled: boolean = this.defaultPaginationEnabled;

  /** Defines whether the Grid should use Server-side operations or not. */
  @Input() public enableServerSideOperations: boolean = false;

  /** Defines whether to show/hide the grid by passing a boolean value */
  @Input() public showGrid: boolean = true;

  /** Defines the options to show in export as dropdown */
  @Input() public exportOptions: DropdownModel = Defaults.GRID_EXPORT_AS_OPTIONS;

  /** Defines whether to enable cell editing in grid by clicking a cell */
  @Input() public singleClickEdit: boolean = true;

  /** Defines whether edititng is for row/cell */
  @Input() public editType: string = '';

  /** Defines whether edititng should be stopped when focus moves out of grid */
  @Input() stopEditingWhenGridLosesFocus: boolean = true;

  /** Defines whether edititng should not be enable at all on single/double click grid */
  @Input() suppressClickEdit: boolean = false;

  @Input() suppressCellSelection: boolean = true;

  /** Defines whether the Grid should enable multiple level sorting */
  @Input() public enableMultiColumnSorting: boolean = false;

  /** Outputs an event when the data is refreshed. Used to provide extra logic if needed. */
  @Output() refreshGridData: EventEmitter<string> = new EventEmitter<string>();

  /** Outputs an event when the data is sorted. Used by the client to do server-side sorting */
  @Output() sortChanged: EventEmitter<object> = new EventEmitter<object>();

  /** Outputs an event when the data is filtered. Used by the client to do server-side filtering */
  @Output() filterChanged: EventEmitter<object> = new EventEmitter<object>();

  /** Outputs an event when the data is sorted. Used by the client to do server-side pagination */
  @Output() paginationChanged: EventEmitter<object> = new EventEmitter<object>();

  /** Outputs an event when the 'reset' arrow button is pressed */
  @Output() resetEvent: EventEmitter<any> = new EventEmitter<any>();

  /** Outputs an event when some link in grid is pressed */
  @Output() clickLinkEvent: EventEmitter<any> = new EventEmitter<any>();

  /** Outputs an event when the data is exported. Used to provide extra logic if needed. */
  @Output() exportGridData: EventEmitter<string> = new EventEmitter<string>();

  /** Outputs an event when the data is exported. Used to provide extra logic if needed. */
  @Output() openModalFromPowerSearch: EventEmitter<string> = new EventEmitter<string>();

  /** Outputs an event when the titles column is clicked. Used to provide extra logic if needed. */
  @Output() enableRowEditing: EventEmitter<string> = new EventEmitter<string>();

  /** Outputs an event when the attachment column is clicked. Used to provide extra logic if needed. */
  @Output() downloadFileEvent: EventEmitter<object> = new EventEmitter<object>();

  /** Outputs an event on click of PDF icon on the grid. Used to provide extra logic if needed. */
  @Output() onPdfIconClickEvent: EventEmitter<object> = new EventEmitter<object>();

  /** Outputs an event when the add row button is clicked. Used to provide extra logic if needed. */
  @Output() addRowEvent: EventEmitter<object> = new EventEmitter<object>();

   /** Outputs an event when the add row button is clicked. Used to provide extra logic if needed. */
   @Output() rowEditingStopped: EventEmitter<object> = new EventEmitter<object>();

  /** Gets access to the 'pageSize' dropdown used for setting the amount of rows displayed. */
  @ViewChild('pageSize') public pageSize: ElementRef;


  /** Gets access to the 'pageNumber' input used for setting the page number to navigate to. */
  @ViewChild('pageNumber') public pageNumber: ElementRef;

  /**
   * Constructor for the Grid
   *
   * Defines the frameworkComponents (custom cell renderers) used in the Grid.
   * Subscribes to any events happening within the Grid.
   *
   * @param gridEventService The service to handle all events related to the Grid.
   */
  constructor(private gridEventService: GridEventService, private psEventService: PowersearchEventService,) { }

  public ngOnInit(): void {
    /** Custom Cell Renderers tied to this Grid. Add new ones here. */
    this.addSubscriptions();
    this.frameworkComponents = {
      imageComponent: GridImageComponent,
      listComponent: GridListComponent,
      listclickableComponent: GridListClickableComponent,
      titlesComponent: GridTitlesComponent,
      iconComponent: GridIconComponent,
      linkComponent: GridLinkComponent,
      floatingFilterComponent: GridFloatingFilterComponent,
      loadingOverlayComponent: GridLoadingOverlayComponent,
      gridDropDownIconCellComponent: GridDropDownIconCellComponent,
      gridDynamicDropdownComponent: GridDynamicDropDownComponent,
      checkBoxComponent: GridCheckBoxCellComponent,
      checkBoxEditor: GridCheckBoxEditorComponent,
      linkUploadFileEditor: GridLinkEditorComponent,
      titlesEditor: GridTitlesEditorComponent,
      iconsEditor: GridIconsEditorComponent,
      columnFilter: ColumnFilterComponent,
      daysCarouselComponent: GridDaysCarouselComponent,
      daysCarouselEditor: GridDaysCarouselEditorComponent,
      gridTypeaheadCellComponent: GridTypeaheadCellComponent,
      gridTypeaheadEditorComponent: GridTypeaheadEditorComponent,
      gridTypeaheadDropdownCellComponent: GridTypeaheadDropdownCellComponent,
      gridTypeaheadDropdownEditorComponent: GridTypeaheadDropdownEditorComponent,
      gridImageListComponent: GridImageListComponent
    };
    this.disabled = false;

    this.components = { datetimepicker: getDatePicker()};
    this.paginationPageSize = this.pagination && this.pagination.size ? this.pagination.size : 25;

    this.columnDefs.forEach((col) => {
      col.floatingFilterComponentParams.enableServerSideOperations = this.enableServerSideOperations;
    });

    this.loadingOverlayComponent = 'loadingOverlayComponent';
    this.noDataOverlay = '<span class="ag-overlay-loading-center">No Records Found</span>';
    this.exportOptions = Defaults.GRID_EXPORT_AS_OPTIONS;

    this.expandSubscription = this.gridEventService.getExpandEvent()
      .subscribe(value => {
        this.setRowHeight(value);
      });

    this.addRowSubscription = this.gridEventService.getAddRowEvent()
      .subscribe(value => {
        console.log(`Event [${value}] has been triggered.`);
        // this.addRow();//uncomment to see working of addrow else handle the emitted event: addRowEvent inside corresponding application
        this.addRowEvent.emit(this.gridApi);
      });

    this.refreshGridSubscription = this.gridEventService.getRefreshGridEvent()
      .subscribe(value => {
        this.refresh();
      });

    this.fitColumnsSubscription = this.gridEventService.getColumnsFitEvent()
      .subscribe(value => {
        this.fitColumnsSize();
      });

    this.filterChangedSubscription = this.gridEventService.getFilterChanged()
      .subscribe(filter => {
        this.onFilterChanged(filter);
      });

    this.clickEventSubscription = this.gridEventService.getClickItem()
      .subscribe(value => {
        this.clickLinkEvent.emit(value);
      });

    this.exportGridSubscription = this.gridEventService.getExportGridEvent()
      .subscribe(value => {
        this.export(value);
      });
    this.enableRowEditingEventSubscription = this.gridEventService.getEnableRowEditingEvent()
      .subscribe(value => {
        this.enableRowEditing.emit(value);
        this.suppressCellSelection = false;
      });

    this.downloadFileEventSubscription = this.gridEventService.getDownloadFileEvent()
      .subscribe(value => {
        this.downloadFileEvent.emit(value);
      });

    this.onRowHeightChangeForEditExpandEventSubscription = this.gridEventService.getOnRowHeightChangeForEditExpandEvent()
      .subscribe(value => {
        this.detectHeightChange();
      });
  }

  private addSubscriptions(): void {
    this.subscriptions.add(this.psEventService.getReportFormDetails().subscribe(res => 
      {
        this.enableExportButton = res;
    }))

    this.downloadPdfFileSubscription = this.gridEventService.getDownloadPdfFile()
      .subscribe(value => {
        this.onPdfIconClickEvent.emit(value);
      });
  }

  /**
   * This is called when the Grid has been initialized.
   * Mostly used for adjusting the size based off of the data given.
   *
   * @param params The params being passed from the Grid.
   */
  public onGridReady(params): void {
    this.isPaginationHidden = false;
    this.disabled = true;
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    setTimeout(() => {
      params.api.sizeColumnsToFit();
    }, 200);

    this.detectHeightChange();
    this.setPaginationVariables();

    window.addEventListener('resize', function () {
      setTimeout(function () {
        params.api.sizeColumnsToFit();
      });
    });
    this.tabToNextCell = this.tabToNextCell.bind(this);
    this.gridReady.emit(params);
  }

  /** Method to handle tabbing */
  public tabToNextCell(params): any {
    const previousCell = params.previousCellDef;
    const nextCellRowIndex = params.nextCellDef ? params.nextCellDef.rowIndex : '';
    const allColumns = params.previousCellDef.column.columnApi.getAllColumns();
    const firstColumn = allColumns[0];
    const lastColumn = allColumns[allColumns.length - 1];
    const editorCheck = allColumns[allColumns.length - 1].colDef.cellEditor;

    //Code changes for handling Default Tabbing in Cell Editing (RC - Callsheet Inline Cell Edit)
    var cellRenderParams =  (params && params.nextCellDef && params.nextCellDef.column
                            && params.nextCellDef.column.colDef) ?
                            params.nextCellDef.column.colDef.cellRendererParams : null;
    var cellRenderer =  (params && params.nextCellDef && params.nextCellDef.column
      && params.nextCellDef.column.colDef && params.nextCellDef.column.colDef.cellRenderer) ?
      params.nextCellDef.column.colDef.cellRenderer : null;
                            
    if((cellRenderParams && cellRenderParams.defaultTabbing) || 
      (cellRenderer === "imageComponent") ||
      (cellRenderer === "gridDynamicDropdownComponent"  && cellRenderParams 
      && cellRenderParams.dynamicDropDown && cellRenderParams.dynamicDropDown.defaultTabbing )) {
        const result = {
          rowIndex: nextCellRowIndex,
          column: params.nextCellDef.column,
          floating: params.nextCellDef.floating
        };
        return result;
    }  
    else if (params.editing && !params.backwards && (editorCheck === 'daysCarouselEditor' || editorCheck === 'iconsEditor')) {
      const iconEditorList = document.getElementsByClassName('c2c-grid-cell-editor-icons');
      if (iconEditorList.length ) {
        const iconList = iconEditorList[0].children;
        const lastIconInCell = iconList[iconList.length - 1];
        if (lastIconInCell.children[0].className === document.activeElement.className) { 
          const result = {
            rowIndex: previousCell.rowIndex,
            column: firstColumn,
            floating: previousCell.floating
          };
          if (result.column.colId === 'firstName' && lastColumn.colId === 'billingStatusNote') {
            let element = document.getElementById('c2c-grid-title-input');
            setTimeout(() => element.focus());//manually setting focus for billing grid
          }else{
            return result;
          }
        }
      }
    } 
  }

  /**
   * Angular's onDestroy method provided to do an cleanup work necessary.
   * In this case, clear the grid properties, and unsubscribe to all events.
   */
  public ngOnDestroy(): void {
    this.columnDefs = null;
    this.gridApi = null;
    this.pageOptions = null;
    this.rowData = null;
    this.subscriptions.unsubscribe();
    this.addRowSubscription && this.addRowSubscription.unsubscribe();
    this.expandSubscription && this.expandSubscription.unsubscribe();
    this.refreshGridSubscription && this.refreshGridSubscription.unsubscribe();
    this.sortChanged && this.sortChanged.unsubscribe();
    this.filterChanged && this.filterChanged.unsubscribe();
    this.filterChangedSubscription && this.filterChangedSubscription.unsubscribe();
    this.paginationChanged && this.paginationChanged.unsubscribe();
    this.exportGridSubscription && this.exportGridSubscription.unsubscribe();
    this.enableRowEditingEventSubscription && this.enableRowEditingEventSubscription.unsubscribe();
    this.downloadFileEventSubscription && this.downloadFileEventSubscription.unsubscribe();
    this.onRowHeightChangeForEditExpandEventSubscription && this.onRowHeightChangeForEditExpandEventSubscription.unsubscribe();
    this.downloadPdfFileSubscription && this.downloadPdfFileSubscription.unsubscribe();

    /** Defines Inline Edit - unsubscribe **/
    this.cellValueChanged && this.cellValueChanged.unsubscribe();
    this.clickEventSubscription && this.clickEventSubscription.unsubscribe();
    this.gridReady && this.gridReady.unsubscribe();
  }

  
  /**
   * Adds a new row to the Grid. Triggered with the Add (plus) icon is pressed.
   */
  public addRow(): void {
    const newItem = this.createNewRowData();
    const res = this.gridApi.updateRowData({ add: [newItem] });
  }

  /**
   * Data to insert into Grid.
   * TODO: Make this dynamic.
   */
  public createNewRowData(): any {
    const newData = this.rowData[0];
    return newData;
  }

  /**
   * Sets the height of the current row that is getting expanded.
   * This is triggered when a user clicks on the expand/collapse icon (double arrow) in the grid.
   *
   * @param expandEvent The Object Literal expand event containing expand information.
   */
  public setRowHeight(expandEvent): void {
    const currentRow = this.gridApi.getDisplayedRowAtIndex(expandEvent.index);
    if (expandEvent.state) {
      this.gridApi.getDisplayedRowAtIndex(expandEvent.index).setRowHeight(currentRow.minHeight);
    } else {
      this.gridApi.getDisplayedRowAtIndex(expandEvent.index).setRowHeight(Math.max(currentRow.maxHeight, expandEvent.height));
    }
    this.detectHeightChange();
  }

  /**
   * Grid event to re-render row heights after they have been changed.
   */
  public detectHeightChange(): void {
    if (this.gridApi) {
      this.gridApi.onRowHeightChanged();
    }
  }

  /**
   * Event to handle when the viewport of the Grid changes (i.e. grid size, page change, etc.).
   */
  public onViewportChanged(): void {
    this.setPaginationVariables();
    this.detectHeightChange();
  }

  /**
   * Event to handle when the Grid size changes. Specifically for when the sidebar is collapsed, or the window size changes.
   */
  public onGridSizeChanged(): void {
    if (this.gridApi) {
      this.gridApi.sizeColumnsToFit();
    }
  }

  /**
   * Event to handle when the rendered rows change. Updates the pagination variables and resizes the height.
   */
  public onRowDataChanged(event): void {
    this.gridApi = event.api;
    this.setPaginationVariables();
    this.detectHeightChange();
    this.gridApi.sizeColumnsToFit()
  }

  /**
   * Handles the initial value/state of the pagination bar at the bottom of the Grid.
   * Gets called everytime the viewport of the grid changes (i.e. user changes the page).
   */
  public setPaginationVariables(): void {
    if (!this.pagination) {
      return;
    }

    if (this.gridApi) {
      this.lbCurrentPage = this.enableServerSideOperations ? (this.pagination.number + 1) : (this.gridApi.paginationGetCurrentPage() + 1);
      this.lbTotalPages = this.enableServerSideOperations ? this.pagination.totalPages : this.gridApi.paginationGetTotalPages();
      this.lbRecordCount = this.enableServerSideOperations ? this.pagination.totalElements : this.gridApi.paginationGetRowCount();
      this.lbFirstRowOnPage = this.enableServerSideOperations
        ? (this.pagination.size * this.pagination.number + 1)
        : (this.gridApi.paginationGetPageSize() * this.gridApi.paginationGetCurrentPage() + 1);

      if (this.lbTotalPages === this.lbCurrentPage) {
        this.lbLastRowOnPage = this.lbRecordCount;
      } else {
        this.lbLastRowOnPage = this.enableServerSideOperations
          ? (this.lbCurrentPage * this.pagination.size)
          : (this.gridApi.paginationGetPageSize() * (this.gridApi.paginationGetCurrentPage() + 1));
      }

      if (this.isRefreshed) {
        setTimeout(() => {
          if (this.pageSize) {
            this.pageSize.nativeElement.value = 25;
          }
          this.isRefreshed = false;
        }, 500);
      }
      /** it's to persist the last updated value of the page  */
      if (this.enableServerSideOperations) {
        this.dataParams.page = {
          number: this.pagination.number,
          size: this.pagination.size
        }
        setTimeout(() => {
          if (this.pageSize) {
            this.pageSize.nativeElement.value = this.pagination.size;
          }
        }, 100);
      }
    }
    this.disableNavigationBack = (this.lbCurrentPage === 1) ? true : false;
    this.disableNavigationForward = (this.lbCurrentPage === this.lbTotalPages) ? true : false;
  }

  /**
   * Action to go to the first page of the Grid.
   */
  public onBtFirst(): void {
    if (this.enableServerSideOperations) {
      this.onPaginationChanged(0);
    } else {
      this.gridApi.paginationGoToFirstPage();
    }
  }

  /**
   * Action to go to the last page of the Grid.
   */
  public onBtLast(): void {
    if (this.enableServerSideOperations) {
      this.onPaginationChanged(this.pagination.totalPages - 1);
    } else {
      this.gridApi.paginationGoToLastPage();
    }
  }

  /**
   * Action to go to the next page of the Grid.
   */
  public onBtNext(): void {
    if (this.enableServerSideOperations) {
      this.onPaginationChanged(this.pagination.number + 1);
    } else {
      this.gridApi.paginationGoToNextPage();
    }
  }

  /**
   * Action to go to the previous page of the Grid.
   */
  public onBtPrevious(): void {
    if (this.enableServerSideOperations) {
      this.onPaginationChanged(this.pagination.number - 1);
    } else {
      this.gridApi.paginationGoToPreviousPage();
    }
  }

  /**
   * Event to handle when the Grid page size changes (amount of rows displayed on each page).
   */
  public onPageSizeChanged(): void {
    const size = this.pageSize.nativeElement.value;
    this.paginationPageSize = Number(size);
    if (this.enableServerSideOperations) {
      this.onPaginationChanged(0, size);
    } else {
      this.gridApi.paginationSetPageSize(Number(size));
      this.setPaginationVariables();
    }
    // this.setPaginationVariables();
  }

  /**
   * Event to handle when the Grid page number changes (current page on the paginator).
   */
  public onPageNumberChanged(): void {
    const value = this.pageNumber.nativeElement.value;
    this.onBtJumpToPage(value);
  }

  /**
   * Action to go to the specified page number of the Grid.
   *
   * @param pageNumber The page number to navigate to.
   */
  public onBtJumpToPage(pageNumber: number): void {
    const number = pageNumber > this.pagination.totalPages ? this.pagination.totalPages : pageNumber;
    // this.lbCurrentPage = number;
    if (number > 0) {
      this.pageNumber.nativeElement.value = number;
      this.lbCurrentPage = this.pageNumber.nativeElement.value;
    } else {
      this.pageNumber.nativeElement.value = 1;
      this.lbCurrentPage = this.pageNumber.nativeElement.value;
    }
    if (this.enableServerSideOperations) {
      this.onPaginationChanged(number - 1);
    } else {
      this.gridApi.paginationGoToPage(pageNumber - 1);
    }
  }

  /**
   * Listens for filter events and emits a event to the client for server-side filtering.
   *
   * @param filter The filter Object Literal that defines the column being filtered, and the filter text.
   */
  public onFilterChanged(filter?: { col: string, value: string }) {
    if (this.enableServerSideOperations && filter !== null) {
      if (this.gridApi) {
        this.gridApi.showLoadingOverlay();
      }
      if (!this.dataParams.filter) {
        this.dataParams.filter = [];
      }
      if (this.dataParams.filter.length) {
        let updated: boolean = false;
        this.dataParams.filter.forEach((f) => {
          if (f.col === filter.col) {
            f.text = filter.value;
            updated = true;
          }
        });
        if (!updated) {
          this.dataParams.filter.push({ 'col': filter.col, 'text': filter.value });
        }
      } else {
        this.dataParams.filter.push({ 'col': filter.col, 'text': filter.value });
      }
      this.dataParams.page = {
        number: 0,
        size: this.pagination.size
      };
      if (this.isRefreshed) {
        this.dataParams.page = {
          'number': 0,
          'size': 25
        }
        this.dataParams.filter = [];
      }
      this.filterChanged.emit(this.setHttpParams(this.dataParams));
    } else {
      this.setPaginationVariables();
      if (this.gridApi.getDisplayedRowCount() === 0) {
        this.gridApi.showNoRowsOverlay();
      } else {
        this.gridApi.hideOverlay();
      }
    }
  }

  /**
   * Listens for sort events and emits a event to the client for server-side sorting.
   * Also adjusts the row heights when a sort has been activated.
   */
  public onSortChanged(): void {
    if (this.enableServerSideOperations) {
        this.gridApi.showLoadingOverlay();
        let dataExists = false;
        let titleSort: any = {colId: 'title', sort: 'asc'};
        let sortModel = this.gridApi.getSortModel();
        if(this.enableMultiColumnSorting){
          if(sortModel.length > 2){//limiting multi-level sorting to a maximum of 2columns i.e. default column + 1
            sortModel.splice(1, 1);//replaces the last sorted column with the latest
            this.gridApi.setSortModel(sortModel);
            sortModel = this.gridApi.getSortModel();
          }
          if(this.dataParams.multiColumnSort && this.dataParams.multiColumnSort.length > 0 && sortModel && sortModel.length > 0){
            dataExists = this.dataParams.multiColumnSort.some(function(mSortElm){
              if(mSortElm['col'] === "title"){
                titleSort =  { 
                  colId : mSortElm['col'],
                  sort: mSortElm['direction'].toLowerCase()
                }
              }
              return ((mSortElm['col'] === sortModel[0]['colId']) && (mSortElm['direction'].toLowerCase() === sortModel[0]['sort']));
            });
          }

          if (!dataExists && sortModel.length && sortModel.length<2) {//prevent infinite sorting loop as we are calling setSortModel below
            this.dataParams.multiColumnSort = [];
            let index = sortModel.filter(sort => (sort.colId === "title" && (sort.sort === "asc" || sort.sort === "desc")));
            if(index.length === 0){
              sortModel.unshift(titleSort);
            }
            this.gridApi.setSortModel(sortModel);
            sortModel.forEach(sortElm => {
              this.dataParams.multiColumnSort.push({
                'col': sortElm.colId, 
                'direction':sortElm.sort.toUpperCase()
              });
            });
          } 
          // else {
          //   this.dataParams.multiColumnSort = [];
          //   this.dataParams.sort = null;
          // }
        }else{
          if (sortModel.length) {
            this.dataParams.sort = { 'col': sortModel[0].colId, 'direction': sortModel[0].sort.toUpperCase() };
          } else {
            this.dataParams.sort = null;
          }
        }
        if (this.isRefreshed) {
          this.dataParams.page = {
            'number': 0,
            'size': 25
          }
          this.dataParams.filter = [];
        }
        this.sortChanged.emit(this.setHttpParams(this.dataParams));
    } else {
      // Commented this line by Subhakar after checked with all the team.
      //Changes to handle dynamically added row which is not yet saved in db (Rollcall fix).
      // let dynamicRowAdded: boolean = false;
      // dynamicRowAdded = (this.gridApi && this.gridApi.rowModel 
      //   && this.gridApi.rowModel.rootNode && this.gridApi.rowModel.rootNode.dynamicRowAdded) ? true : false;
      // if(!dynamicRowAdded) {
      //     this.rowData = JSON.parse(JSON.stringify(this.rowData).replace(/null/g, '""'));
      // }
    }
    this.detectHeightChange();
  }

  /**
   * Listens for pagination events and emits a event to the client for server-side pagination
   *
   * @param number  The page number to set.
   * @param size The page size to set.
   */
  public onPaginationChanged(number: number, size?: number): void {
    this.gridApi.showLoadingOverlay();
    this.dataParams.page = {
      'number': number,
      'size': size ? size : this.pagination.size
    };
    this.paginationChanged.emit(this.setHttpParams(this.dataParams));
  }

  /**
   * Sets the HttpParams object for sending to the back-end in order to perform server-side operations.
   *
   * @param dataParams The GridServerSideParamsModel to get the sort/filter/pagination data from.
   */
  public setHttpParams(dataParams: GridServerSideParamsModel): HttpParams {
    let httpParams = new HttpParams();

    if (dataParams.multiColumnSort) {
      dataParams.multiColumnSort.forEach(sortElm => {
        httpParams = httpParams.append('multiColumnSort', sortElm.col + ':' + sortElm.direction);
      });
    }
    if (dataParams.sort) {
      httpParams = httpParams.append('sort', dataParams.sort.col + ',' + dataParams.sort.direction);
    }
    if (dataParams.filter && dataParams.filter.length) {
      dataParams.filter.forEach((filter) => {
        httpParams = httpParams.append(filter.col, filter.text);
      });
    }
    if (dataParams.page) {
      httpParams = httpParams.append('page', dataParams.page.number.toString());
      httpParams = httpParams.append('size', dataParams.page.size.toString());
    }
    return httpParams;
  }

  /**
  * Handles the export event
  */
  export(choice?: any) {
    // TO DO
    if (choice) {
      this.exportGridData.emit(choice);
    }
  }

  openModal(event) {
    this.openModalFromPowerSearch.emit(event);
  }

  onRowEditingStopped(event) {
    this.detectHeightChange();
    this.rowEditingStopped.emit(event);
    this.suppressCellSelection = true;
  }

  /**
   * Handles the refresh event, and clears all filters/sorts.
   */
  public refresh(): void {
    this.isRefreshed = true;
    // if(this.isRefreshed) {
    //   this.pageSize.nativeElement.selectedIndex = 0;
    // }
    if (!this.enableServerSideOperations) {
      this.gridApi.paginationGoToFirstPage();
    }
    this.gridApi.setSortModel(null);
    this.refreshGridData.emit('refreshGridData');
    this.gridApi.refreshCells();
  }

  public fitColumnsSize(): void {
    this.gridApi.sizeColumnsToFit();
  }


  newData: any = [];

  perform_onCellClicked(cellData) {
    // console.log(cellData);
  }

  setdata() {
    // this.gridOptions.api.setRowData(this.rowData);
    // this.rowData = this.newData;
  }

   /*******************************INLINE EDIT CHANGES ********************************/
  /**  @param params - to expose cell value change event to caller
  */
 onCellValueChanged(params) {
  var selectedColum = (null != params && null != params.column) ? params.column.getId() : null;
  var selectedRowIndex = null != params ? params.rowIndex : null;
  var newValue = null != params ? params.newValue : null;
  var oldValue = null != params ? params.oldValue : null;
  if (null != params && null != params.colDef) {
    var newOptionRow = this.lookupOptionRow(params.colDef.cellEditorOptions, newValue);
    if (null != newOptionRow && newOptionRow != undefined) {
      var newOptionId = newOptionRow.id;
    }
  }
  var newRowData = null != params ? params.data : null;
  this.cellEditOutParams.setParams(selectedColum, selectedRowIndex, newValue,
    newOptionId, newRowData, oldValue, newOptionRow, params);
  this.cellValueChanged.emit(this.cellEditOutParams);
}

/**
 * @param options Method to get the dropdown option id which is selected
 * @param name
 */
public lookupOptionKey(options, name) {
  if (null != options && null != name) {
    for (const data of options) {
      if (null != data && name == data.value) {
        return data.id;
      }
    }
  }
}

/**
 * @param options Method to get the dropdown option row json which is selected
 * @param name
 */
public lookupOptionRow(options, name) {
  if (null != options && null != name) {
    for (const data of options) {
      if (null != data && name == data.value) {
        return data;
      }
    }
  }
}

/**  @param params - to expose cell click event to caller */
onCellClicked(params) {
  this.handleDeleteIconDisplay(params);
  this.handleDynamicDropdownDisplay(params);
  this.cellClicked.emit(params);
}

onCellFocused(params) {
  this.handleDeleteIconDisplay(params);
  this.handleDynamicDropdownDisplay(params);
}

/**
 * @param params Method to handle delete icon display on row selection
 */
public handleDeleteIconDisplay(params) {
  if ((null != params.colDef && params.colDef != undefined && params.colDef.editable)
    || (null != params.column && params.column.colDef.editable) && null != params.columnApi.columnController.allDisplayedColumns) {
    for (const column of params.columnApi.columnController.allDisplayedColumns) {
      if (null != column && column != undefined && column.colDef.cellRenderer == "iconComponent" && null != column.colDef.cellRendererParams.deleteIcon) {
        if (column.colDef.cellRendererParams.deleteIcon.displayOnCellEdit) {
          column.colDef.cellRendererParams.deleteIcon.visible = true;
          column.colDef.cellRendererParams.deleteIcon.selectedRowIndex = params.rowIndex;
        }
      }
    }
  }
}

/**Row click event */
onRowClicked(params) {
  if (params != null) {
    this.handleDynamicDropdownDisplay(params);
  }
}

/**Mouse over event */
onCellMouseOver(params) {
  if (params != null) {
    this.handleDynamicDropdownDisplay(params);
  }
}

/**Cell Editing Started event */
onCellEditingStarted(params) {
  if (params != null) {
    this.handleDynamicDropdownDisplay(params);
  }
}

/**
 * @param params Method to handle the dynamic dropdown display on each row
 */
public handleDynamicDropdownDisplay(params) {
  if (null != params.columnApi && null != params.columnApi.columnController.allDisplayedColumns) {
    for (const column of params.columnApi.columnController.allDisplayedColumns) {
      if (null != column && column != undefined
        && column.colDef.cellRenderer == "gridDynamicDropdownComponent"
        && null != column.colDef.cellRendererParams.dynamicDropDown
        && params != undefined && params.data != undefined) {
        column.colDef.cellRendererParams.dynamicDropDown.rowIndex = params.rowIndex;
        let options = params.data[column.colDef.cellRendererParams.dynamicDropDown.options];
        column.colDef.cellEditor = "agSelectCellEditor";
        column.colDef.cellEditorOptions = options;
        column.colDef.cellEditorParams = {
          values: this.extractOptionValues(options),
        }
        // this.gridOptions.api.refreshView();
        // this.gridApi.refreshCells(params);
      }
    }
  }
}

/**
 * @param options Method to extract dropdown option values
 */
private extractOptionValues(options) {
  let valueArray = new Array();
  if (null != options && options != undefined) {
    for (const data of options) {
      valueArray.push(data.value);
    }
  }
  return valueArray;
}
/********************************INLINE EDIT CHANGES END *****************************/

/**
 * Toggles show/hide of the floating filters on the Grid.
 */
public toggleGridFilters(): void {
  this.isFiltersVisible = !this.isFiltersVisible;
  this.gridEventService.filterToggledEvent(this.isFiltersVisible);
  if (!this.isFiltersVisible) {
    this.gridApi.setFloatingFiltersHeight(0);
  } else {
    this.gridApi.setFloatingFiltersHeight(25);
  }
}

/**
 * Emits the 'resetEvent' event emitter to apply logic for resetting the Grid.
 */
public resetGrid(): void {
  this.resetEvent.emit();
  this.disabled = false;
  this.isPaginationHidden = true;
}
}

/**
* Changes for Date time picker inside ag-grid cell - jQuery call for date time picker
*/
function getDatePicker() {
 
var moment = require('moment');
function datetimepicker() { }
datetimepicker.prototype.init = function (params) {
  this.params = params;
  this.focusAfterAttached = params.cellStartedEdit;
  this.eInput = document.createElement('input');
  this.eInput.setAttribute('id', this.params.column.colId);
  $(this.eInput).removeClass().addClass('form-control grid-date-picker');//adding c2c style guid css changes to grid-datepicker
  // To Do: need to remove this value after validation confirmation
  params.value === 'Select' ? this.eInput.value = '' : this.eInput.value = params.value;
  if (params.column.colDef.cellRendererParams && params.column.colDef.cellRendererParams.useDatePickerEditor) {
    this.useDatePickerEditor = true;
  } else {
    this.useDatePickerEditor = false;
  }
  if (!this.useDatePickerEditor){
    $(this.eInput).datetimepicker({
      format: 'MM/DD/YYYY hh:mm A',
      step: 1,
      formatDate: 'MM/DD/YYYY',
      formatTime: "hh:mm A",
      validateOnBlur: true,
      selectOnEnter: true,
      // value: getFormattedDate(new Date(this.dateOfCall), this.dateOfCall),
      // value: "10/05/2018 01:30 PM"

      onClose: (selectedDate, $input) => {
        $input.datetimepicker('destroy');
      }
    });
    this.showValidation();
  } else {
    $(this.eInput).datetimepicker({
        format: 'MM/DD/YYYY',
        step: 1,
        formatDate: 'MM/DD/YYYY',
        defaultSelect: false,
        validateOnBlur: false,//no autocorrect on invalid regex
        selectOnEnter: true,
        dateonly: true,
        timepicker: false,
        closeOnDateSelect	: true,
        onSelectDate: (date, inst) => {
          this.showValidation();
          this.getDateRangeForCarousal();
        },
        onEnterPress: (date, inst) => {
          this.showValidation();
          this.getDateRangeForCarousal();
        }
    }); 
    $(this.eInput).on("keyup",  (e) => {
      this.showValidation();//for validation to trigger in case of row editing
    });
  }
  $.datetimepicker.setDateFormatter('moment');

  function getFormattedDate(date, dateValue) {
    var regexp = new RegExp("^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/(?:[0-9][0-9])?[0-9][0-9] ([0-1][0-9]|[2][0-3]):([0-5][0-9]) (AM|PM)$");
    if (dateValue != undefined && regexp.test(dateValue)) {
      var amPMFormat = dateValue.substring(dateValue.length - 2, dateValue.length);
      var year = date.getFullYear();
      var month = (date.getMonth() + 1).toString();
      var formatedMonth = (month.length === 1) ? ("0" + month) : month;
      var day = date.getDate().toString();
      var formatedDay = (day.length === 1) ? ("0" + day) : day;
      var hour: any;
      if (date.getHours() < 12) {
        hour = (date.getHours() + 1).toString();
      } else if (date.getHours() === 12) {
        hour = 1;
      } else {
        hour = (date.getHours()).toString();
      }
      var formatedHour = (hour.length === 1) ? ("0" + hour) : hour;
      var minute = date.getMinutes().toString();
      var formatedMinute = (minute.length === 1) ? ("0" + minute) : minute;
      var formattedDateStr = formatedMonth + "/" + formatedDay + "/" + year + " " +
        formatedHour + ":" + formatedMinute + " " + amPMFormat;
      return formattedDateStr;
    }
  }
};
datetimepicker.prototype.getGui = function () {
  return this.eInput;
};
datetimepicker.prototype.afterGuiAttached = function () {
  if (!this.useDatePickerEditor) {
    this.eInput.focus();
    this.eInput.select();
  } else if (this.focusAfterAttached) {
    this.eInput.focus();
    this.eInput.select();
  }
  this.showBorder(); 
};
datetimepicker.prototype.showBorder = function () {
  if (this.params.column.colDef.cellRendererParams && this.params.column.colDef.cellRendererParams.showValidationBorder){
    $(this.eInput).css('border', '1px solid #FB2E12');
  } else {
    $(this.eInput).css('border', '');
  }
}
datetimepicker.prototype.getValue = function () {
  return this.eInput.value;
};
datetimepicker.prototype.destroy = function () { 
  // $(this.eInput).datetimepicker('hide');
};
datetimepicker.prototype.isPopup = function () {
  return false;
};
datetimepicker.prototype.focusIn = function() {
  const eInput = this.getGui();
  eInput.focus();
  eInput.select();
};
datetimepicker.prototype.focusOut = function() {
  console.log('datetimepicker.focusOut()');
};
datetimepicker.prototype.getDateRangeForCarousal = function () {
    const cellRendererParams = this.params.column.colDef.cellRendererParams;
    if (cellRendererParams && cellRendererParams.showCarousel) {
      cellRendererParams.showValidationBorder = false;
      if (this.params.column.colId === 'startDate') {
        this.params.node.columnApi.columnController.allDisplayedColumns[1].colDef.cellRendererParams.showValidationBorder = false;
      } else if (this.params.column.colId === 'finishDate') {
        this.params.node.columnApi.columnController.allDisplayedColumns[0].colDef.cellRendererParams.showValidationBorder = false;
      }
      this.getDifference();
    }
};
datetimepicker.prototype.getDifference = function () {
  let startDate, finishDate, nextColKey;
  if (this.params.column.colId === 'startDate') {
    startDate = this.eInput.value;
   } else {
    startDate = this.params.eGridCell.parentNode.children[0].childNodes[0].value;
  }

  if (this.params.column.colId === 'finishDate') {
    finishDate = this.eInput.value;
  } else {
    finishDate = this.params.eGridCell.parentNode.children[1].childNodes[0].value;
  }

  if(this.params.column.colId === 'startDate' || this.params.column.colId === 'finishDate'){
    nextColKey = this.params.eGridCell.nextSibling.getAttribute('col-id');
  }

  let difference = 0;

  let start = moment(startDate);
  const finish = moment(finishDate);

  let businessDays = [];
  let isWeekend = false;

  while (start.isSameOrBefore(finish,'day')) {
    if (start.day()!=0 && start.day()!=6){
      isWeekend = false;
    } else {
      isWeekend = true;
    }

    businessDays.push({
      'day': start.date(),
      'dates': start.format('MM/DD/YYYY'),
      'isWeekend': isWeekend,
      'isDaySelected': true,
      'isWeekendHist': isWeekend
    });

    difference++;
    // if (!isWeekend) {//commenting as weekend deselection is not required
    //   difference++;
    // }
    start.add(1, 'd');
  }

  this.params.node.data.days = !isNaN(difference) ? difference : 0;
  this.params.api.stopEditing();
  this.params.node.data.workWeekDays = businessDays;

  this.params.api.startEditingCell({
    rowIndex: this.params.rowIndex,
    colKey: 'days'
  });

  if(nextColKey === 'days'){
    let daysCarouselSaveButton = <HTMLElement>document.getElementById('c2c-save-button');
    setTimeout(() => daysCarouselSaveButton.focus());//manually setting focus to save button 
  } else if(nextColKey === 'finishDate'){
    let finishDateCell = <HTMLElement>this.params.eGridCell.nextSibling;
    setTimeout(() => finishDateCell.focus());
  }
};

datetimepicker.prototype.showValidation = function () {    
    var regexp;
    if(!this.useDatePickerEditor) {
      regexp = new RegExp("^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/(?:[0-9][0-9])?[0-9][0-9] ([0-1][0-9]|[2][0-3]):([0-5][0-9]) (AM|PM)$");   
    } else {
      regexp = new RegExp("(^Select$)|^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/(?:[0-9][0-9])?[0-9][0-9]$");
    }

    this.validFormat = true;
    let valueForTest;

    if(!this.useDatePickerEditor){
      if(this.params && this.params.value){
        valueForTest = this.params.value;
      }
    }else{
      valueForTest = $(this.eInput).val();//value for keydown event
    }
   
    if(valueForTest) {
      this.validFormat = regexp.test(valueForTest);
    }

    if (!this.validFormat) { 
      this.params.column.colDef.cellRendererParams.showValidationBorder = true;
    } else {
      this.params.column.colDef.cellRendererParams.showValidationBorder = false;
    }
    
    this.showBorder();
};
return datetimepicker;
}

