import { Component } from '@angular/core';
import { IFilterAngularComp } from 'ag-grid-angular';
import { IDoesFilterPassParams, IFilterParams, RowNode } from 'ag-grid';

@Component({
    selector: 'c2c-column-filter',
    templateUrl: './column-filter.component.html',
    styleUrls: ['./column-filter.component.scss']
})
export class ColumnFilterComponent implements IFilterAngularComp {

    private criteriaText: string;
    private params: IFilterParams;
    public textFilter: boolean = false;
    public isSelectAll: boolean = true;
    public options: any[] = [];
    private columnKey: any;
    private dataOptions: any = { allRecords: false, isPresent: false };
    private valueGetter: (rowNode: RowNode) => any;

    /** This is used to show the filter icon in the header. If true, the filter icon will be shown. */
    public isFilterActive(): boolean {
        return true;
    }

    /** Gets the filter state for storing */
    public getModel() {
        return '';
    }

    /** Restores the filter state. */
    public setModel(): void {
        this.isSelectAll = true;
        this.changeAll();
    }

    /** The grid will ask each active filter, in turn, whether each row in the grid passes. If any
     filter fails, then the row will be excluded from the final set. The method is provided a
     params object with attributes node (the rodNode the grid creates that wraps the data) and data
     (the data object that you provided to the grid for that row). */
    public doesFilterPass(params: IDoesFilterPassParams): boolean {
        if (this.textFilter) {
            return this.filterByText(params.data);
        } else {
            return this.filterByDataPresent(params.data);
        }
    }

    /** This is the ag grid initialize method to peroform our own custom logic */
    public agInit(params): void {
        this.params = params;
        this.valueGetter = params.valueGetter;
        this.textFilter = params.textFilter;
        this.columnKey = params.columnKey;
        if (params.options) {
            this.options = params.options;
            this.prepareOptions(true);
        }
    }

    private prepareCriteria(): void {
        if (this.textFilter) {
            this.criteriaText = this.buildText();
        } else {

        }
        this.params.filterChangedCallback();
    }

    /** This method is used to reset filter option externally when you refresh grid */
    public setOptions(): void {
        this.isSelectAll = true;
        this.changeAll();
    }

    /** This method is used to get all text box criteria */
    public changeAll(): void {
        this.dataOptions.allRecords = true;
        this.prepareOptions(this.isSelectAll);
        this.prepareCriteria();
    }

    /** This method is used to filter option */
    public changeOption(): void {
        let checked = true;
        let unCheckAll = true;
        this.options.forEach(option => {
            if (option.checked) {
                unCheckAll = false;
                this.dataOptions.isPresent = option.value;
            } else {
                checked = false;
            }
        });
        if (checked || unCheckAll) {
            this.dataOptions.allRecords = true;
        } else {
            this.dataOptions.allRecords = false;
        }
        this.isSelectAll = checked;
        this.prepareCriteria();
    }

    /** This method is used to track by number to improve performance */
    public trackByFn(index): number {
        return index;
    }

    /** This method is used to prepare for all or unselect all */
    private prepareOptions(checked: boolean): void {
        this.options.forEach(option => {
            option.checked = checked;
        });
    }

    /** This method is used to concat multiple checkbox options to filter grid */
    private buildText(): string {
        let text = '';
        this.options.forEach(option => {
            if (option.checked) {
                if (text) {
                    text = text + '_' + option.value;
                } else {
                    text = option.value;
                }
            }
        });
        return text;
    }

    /** This method is used to filter by multiple checboxes option or multiple text values */
    private filterByText(params): boolean {
        // make sure each word passes separately with concatanation of underscore, ie search for option1_option2
        let passed = false;
        const valueGetter = this.valueGetter;
        let value = '';
        if (Array.isArray(this.columnKey)) {
            this.columnKey.forEach(key => {
                if (params[key]) {
                    value = value + params[key];
                }
            });
        } else {
            value = params[this.columnKey];
        }
        if (value) {
            value = value.toLowerCase();
            this.criteriaText.toLowerCase().split('_').forEach(function (filterWord) {
                if (value.indexOf(filterWord) >= 0) {
                    passed = true;
                    return false;
                }
            });
        }
        return passed;
    }

    /** This method is used to check data present in row or not */
    private filterByDataPresent(params: any): boolean {
        // In this criteria filter columnKey should be string
        if (this.dataOptions.allRecords) {
            return true;
        } else {
            if (this.dataOptions.isPresent) {
                return params[this.columnKey] ? true : false;
            } else {
                return params[this.columnKey] ? false : true;
            }
        }
    }

}
