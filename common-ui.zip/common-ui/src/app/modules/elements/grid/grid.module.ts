import { NgModule, ModuleWithProviders } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AgGridModule } from 'ag-grid-angular/main';
import { GridComponent } from './grid.component';
import { GridIconComponent } from './custom-cells/grid-icon/grid-icon.component';
import { GridLinkComponent } from './custom-cells/grid-link/grid-link.component';
import { GridImageComponent } from './custom-cells/grid-image/grid-image.component';
import { GridListComponent } from './custom-cells/grid-list/grid-list.component';
import { GridTitlesComponent } from './custom-cells/grid-titles/grid-titles.component';
import { GridLoadingOverlayComponent } from './custom-other/grid-loading-overlay/grid-loading-overlay.component';
import { GridEventService } from '../../../services/events/grid/grid-event.service';
import { ButtonModule } from '../../elements/button/button.module';
import { CommonSharedModule } from '../../common-shared/common-shared.module';
import { GridFloatingFilterComponent } from './custom-other/grid-floating-filter/grid-floating-filter.component';
import { GridDropDownIconCellComponent } from './custom-cells/grid-dropdown-icon/grid-dropdown-icon.component';
import { GridDynamicDropDownComponent } from './custom-cells/grid-dynamic-dropdown/grid-dynamic-dropdown.component';
import { GridCheckBoxCellComponent } from './custom-cells/grid-checkbox/grid-checkbox.component';
import { FormModule } from './../../../modules/form/form.module';
import { GridCheckBoxEditorComponent } from './custom-cell-editor/grid-checkbox-editor/grid-checkbox-editor.component';
import { GridLinkEditorComponent } from './custom-cell-editor/grid-link-editor/grid-link-editor.component';
import { FileUploaderModule } from '../file-uploader/file-uploader.module';
import { GridTitlesEditorComponent } from './custom-cell-editor/grid-titles-editor/grid-titles-editor.component';
import { GridIconsEditorComponent } from './custom-cell-editor/grid-icons-editor/grid-icons-editor.component';
import { ToasterService } from '../../../services/toaster/toaster.service';
import { FileUploaderService } from '../../../services/file-uploader/file-uploader.service';
import { GridListClickableModule } from './custom-cells/grid-list-clickable/grid-list-clickable.module';
import { GridDaysCarouselComponent } from './custom-cells/grid-days-carousel/grid-days-carousel.component';
import { GridTypeaheadCellComponent } from './custom-cells/grid-typeahead/grid-typeahead.component';
import { GridTypeaheadEditorComponent  } from './custom-cell-editor/grid-typeahead-editor/grid-typeahead-editor.component';
import { TypeAheadModule } from '../../elements/type-ahead/type-ahead.module';
import { GridTypeaheadDropdownCellComponent } from '../grid/custom-cells/grid-typeahead-dropdown/grid-typeahead-dropdown.component';
import { GridTypeaheadDropdownEditorComponent } from '../grid/custom-cell-editor/grid-typeahead-dropdown-editor/grid-typeahead-dropdown-editor.component';
import { DropDownTypeAheadModule } from '../../elements/dropdown-typeahead/dropdown-typeahead.module';
import { PowersearchEventService } from '../../../services/events/powersearch/powersearch-event.service';
import { GridDaysCarouselEditorComponent } from './custom-cell-editor/grid-days-carousel-editor/grid-days-carousel-editor.component';
import { ColumnFilterComponent } from './custom-filter/column-filter/column-filter.component';
import { GridImageListComponent } from './custom-cells/grid-image-list-clickable/grid-image-list-clickable.component';
/**
 * The GridModule
 *
 * Module that contains all Grid related components.
 * Add new Cell Renderers to the import 'AgGridModule.withComponents' array.
 */
@NgModule({
  declarations: [
    GridComponent,
    GridImageComponent,
    GridListComponent,
    GridTitlesComponent,
    GridIconComponent,
    GridLinkComponent,
    GridLoadingOverlayComponent,
    GridFloatingFilterComponent,
    GridDropDownIconCellComponent,
    GridDynamicDropDownComponent,
    GridCheckBoxCellComponent,
    GridCheckBoxEditorComponent,
    GridLinkEditorComponent,
    GridTitlesEditorComponent,
    GridIconsEditorComponent,
    GridDaysCarouselComponent,
    GridDaysCarouselEditorComponent,
    GridTypeaheadCellComponent,
    GridImageListComponent,
    GridTypeaheadEditorComponent,
    GridTypeaheadDropdownCellComponent,
    GridTypeaheadDropdownEditorComponent,
    ColumnFilterComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    TypeAheadModule.forRoot(),
    ReactiveFormsModule,
    AgGridModule.withComponents([
      GridImageComponent,
      GridListComponent,
      GridTitlesComponent,
      GridIconComponent,
      GridLinkComponent,
      GridLoadingOverlayComponent,
      GridFloatingFilterComponent,
      GridDropDownIconCellComponent,
      GridDynamicDropDownComponent,
      GridCheckBoxCellComponent,
      GridCheckBoxEditorComponent,
      GridLinkEditorComponent,
      GridTitlesEditorComponent,
      GridIconsEditorComponent,
      GridListClickableModule,
      GridDaysCarouselComponent,
      GridDaysCarouselEditorComponent,
      GridTypeaheadCellComponent,
      GridImageListComponent,
      GridTypeaheadEditorComponent,
      GridTypeaheadDropdownCellComponent,
      GridTypeaheadDropdownEditorComponent,
      ColumnFilterComponent
    ]),
    RouterModule,
    ButtonModule,
    FormModule,
    CommonSharedModule,
    FileUploaderModule,
    DropDownTypeAheadModule
  ],
  exports: [
    GridComponent
  ]
})
export class GridModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: GridModule,
      providers: [GridEventService, ToasterService, FileUploaderService, PowersearchEventService]
    };
  }
}
