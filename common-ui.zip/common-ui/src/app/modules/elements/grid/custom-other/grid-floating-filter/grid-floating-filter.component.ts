import { Component } from '@angular/core';
import { IFloatingFilter, SerializedTextFilter, IFloatingFilterParams, Constants } from 'ag-grid';
import { Subject } from 'rxjs/Subject';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';

/**
 * Implementation of the Grid's floating filter change detection.
 */
export interface GridFloatingFilterChange {
  model: SerializedTextFilter;
}

/**
 * Implementation of the Grid's floating filter params. Passes params to the custom filter given from the Grid.
 */
export interface GridFloatingFilterParams extends IFloatingFilterParams<SerializedTextFilter, GridFloatingFilterChange> {
  enableServerSideOperations: boolean;
  isTextFilterDisabled?: boolean;
}

/**
 * The GridFloatingFilterComponent
 *
 * Custom Grid floating filter component that is used for filtering each column in the Grid.
 * Handles both client-side and server-side filtering.
 */
@Component({
  selector: 'c2c-grid-floating-filter',
  templateUrl: './grid-floating-filter.component.html',
  styleUrls: ['./grid-floating-filter.component.scss']
})
export class GridFloatingFilterComponent implements IFloatingFilter<SerializedTextFilter, GridFloatingFilterChange, GridFloatingFilterParams> {
  public colId: string;
  public filterValue: string;
  public filtersOn: boolean = true;
  public isServerSide: boolean;
  public params: GridFloatingFilterParams;

  private subject: Subject<string> = new Subject();
  private isRefreshed: boolean = false;
  public isTextFilterDisabled: boolean = false;

  /**
   * Constructor for the GridFloatingFilterComponent
   *
   * @param gridEventService The service to handle all events related to the Grid.
   */
  constructor(private gridEventService: GridEventService) { }

  /**
   * Ag-grid event for doing any initialization logic on the custom filter.
   *
   * @param params The GridFloatingFilterParams to pass to the custom filter.
   */
  agInit(params: GridFloatingFilterParams): void {
    this.params = params;
    this.colId = params.column.getColId();
    this.isServerSide = params.enableServerSideOperations;

    // Disable text filter in case of other custom filter apply
    if (params.isTextFilterDisabled) {
      this.isTextFilterDisabled = params.isTextFilterDisabled;
    }

    this.subject.debounceTime(500).subscribe((searchText) => {
      this.gridEventService.filterChangedEvent({ col: this.colId, value: searchText });
    });

    this.gridEventService.getRefreshGridEvent().subscribe(
      () => {
        this.isRefreshed = true;
        this.clearFilter();
      }
    );

    this.gridEventService.getFilterToggled().subscribe(
      (isFiltersVisible) => {
        this.filtersOn = isFiltersVisible;
      }
    );
  }

  /**
   * Change listener that get called whenever the value of the custom filter changes.
   *
   * @param code The key code captured from the event. If the code is a tab (or shift-tab), then it call the subject.
   */
  public filterChanged(code?: string): void {

    // prevent filtering on tabbing
    if (code && (code.toUpperCase() === 'TAB' || code.toUpperCase() === 'SHIFTLEFT')) {
      return;
    }

    if (this.isServerSide) {
      this.subject.next(this.filterValue);
    } else {
      this.params.onFloatingFilterChanged({ model: this.buildModel() });
    }
  }

  /**
   * Clears the filter back to empty string with the 'x' is pressed.
   */
  public clearFilter(): void {
    this.filterValue = '';
    if (!this.isRefreshed) {
      this.filterChanged();
    } else {
      this.filterChanged();
      this.isRefreshed = false;
    }
  }

  /**
   * Builds the model to be used by filter when performing client-side filtering.
   */
  public buildModel(): SerializedTextFilter {
    if (this.filterValue === '') {
      return null;
    }

    return {
      filterType: 'text',
      type: 'contains',
      filter: this.filterValue
    };
  }

  /**
   * Implementation of the 'onParentModelChanged' function in the Grid.
   *
   * @param parentModel The parent model passed from the Grid.
   */
  public onParentModelChanged(parentModel: SerializedTextFilter): void {
    if (!parentModel) {
      this.filterValue = null;
    } else {
      this.filterValue = parentModel.filter;
    }
  }

}
