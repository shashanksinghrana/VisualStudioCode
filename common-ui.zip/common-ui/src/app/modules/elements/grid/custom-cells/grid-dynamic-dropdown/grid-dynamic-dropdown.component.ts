import { Component } from '@angular/core';
import { GridDataOperations } from '../../../../../utils/grid/grid-data-operations';
import { GridDropdownEditDefModel } from '../../../../../models/grid/column-def/grid-dropdown-edit-def.model';

@Component({
    selector: 'c2c-grid-dynamic-dropdown',
    templateUrl: './grid-dynamic-dropdown.component.html',
    styleUrls: ['./grid-dynamic-dropdown.component.scss']
})
export class GridDynamicDropDownComponent {
    public value: any;

    /** Expecting Option in [id, value] format
     *
     */
    agInit(params): void {
        this.value = params.value;
        if (null != params && null != params.colDef && params.colDef !== undefined) {
        //    let options = params.data[params.dynamicDropDown.options];
           const options = params.node.data[params.dynamicDropDown.options];
            if (null != options && options !== undefined
                && params.dynamicDropDown.rowIndex === params.rowIndex) {
                    params.colDef.cellEditor = 'agSelectCellEditor';
                    params.colDef.cellEditorOptions = options;
                    params.colDef.cellEditorParams = {
                        values: this.extractOptionValues(options),
                    };
            }
        }
    }
    private extractOptionValues(options) {
        const valueArray = new Array();
        if (null != options && options !== undefined) {
          for (const data of options) {
            valueArray.push(data.value);
          }
        }
        return valueArray;
    }
}
