import { Component, Renderer2, ElementRef } from '@angular/core';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';
import { GridDataOperations } from '../../../../../utils/grid/grid-data-operations';

/**
 * The GridListComponent
 *
 * Grid Cell Renderer that handles the display of lists (with optional expand/collapse arrow) in the Grid.
 */
@Component({
  selector: 'c2c-grid-list',
  templateUrl: './grid-list.component.html',
  styleUrls: ['./grid-list.component.scss']
})
export class GridListComponent {
  public data: any;
  public enableCollapse: boolean = false;
  public isCollapsed: boolean = true;
  public showAsExpanded: boolean = false;
  public custStyle: boolean = false;
  public dummyLink: boolean = false;
  public destinationUrl: boolean = false;
  public redirectTo: string = '';
  public FirstCell: boolean = false;
  public nameSeparatorStyle: boolean = false;
  public showPdfImage: boolean = false;
  public params: any;

  private compareArr: any[];
  private isMultiple: boolean = false;
  private maxHeight: number;
  private minHeight: number;
  private totalHeight: number;

  /**
   * Constructor for the GridListComponent
   *
   * @param gridEventService The service to handle all events related to the Grid.
   * @param elRef A reference to a certain element in the DOM. In this case, the list.
   * @param renderer Used for safely accessing elements in the DOM.
   */
  constructor(private gridEventService: GridEventService,
    private elRef: ElementRef,
    private renderer: Renderer2) { }

  /**
   * Ag-grid event for doing any initialization logic on the Cell Renderer.
   * Calculates each value to be displayed, calculates the row height, and sets the routing (if configured).
   *
   * @param params The params passed in from the ag-grid event. This contains information on the Grid,
   *  including the data and parameters from the ListParamsModel.
   */
  public agInit(params: any): void {
    this.params = params;
    setTimeout(() => {
      this.enableCollapse = params.isExpandable;
    }, 100);
    /**
     * The style change for the text
     */
    if (params.custStyle == true) {
      this.custStyle = params.custStyle;
    } else {
      this.custStyle = false;
    }
    /**
 * The style change for the text like dummy link bold
 */
    if (params.dummyLink == true) {
      this.dummyLink = params.dummyLink;
    } else {
      this.dummyLink = false;
    }
    /**
 * The style change for the text for bold destinaliton url
 */
    if (params.destinationUrl == true) {
      this.destinationUrl = params.destinationUrl;
      this.redirectTo = params.redirectTo;
    }
    /**
     * To detemine weather it is first cell/not in grid to change the style
     */
    if (params.FirstCell == true) {
      this.FirstCell = params.FirstCell;
    } else {
      this.FirstCell = false;
    }

    /**
 * To detemine weather name seaprator style is needed or not ie,boolean true/false 
 */
    if (params.nameSeparatorStyle == true) {
      this.nameSeparatorStyle = params.nameSeparatorStyle;
    } else {
      this.nameSeparatorStyle = false;
    }

    if (params.colDef.cellRendererParams.showPdfImage) {
      this.showPdfImage = true;
    }

    this.showAsExpanded = params.showAsExpanded ? params.showAsExpanded : false;
    this.isMultiple = params.isMultiple;

    if (params.spacingKey) {
      this.compareArr = GridDataOperations.extractValueFromProperty(params.data[params.colValue.iterable], params.spacingKey);
    }

    if (this.nameSeparatorStyle && this.params.data[params.colValue.iterable] != null) {
      this.SetNameSeaparateValue(this.params.data[params.colValue.iterable]);
    } else {
      this.data = this.formatDataToDisplay(
        GridDataOperations.concatenateArrayValuesFromData(params.data[params.colValue.iterable], params.colValue.keys, this.isMultiple)
      );
    }



    if (this.data.length > 1 && !this.showAsExpanded) {
      const height = GridDataOperations.calculateHeightOfColumn(params);
      const listHeight = this.data.length > 2 ? 70 : 50;
      this.minHeight = Math.max(height, listHeight);
      params.node.minHeight = this.minHeight;
      params.node.setRowHeight(this.minHeight);

      this.maxHeight = (this.data.length * 20) + 10;
      params.node.maxHeight = Math.max(this.maxHeight, this.totalHeight);
    }

    if (this.showAsExpanded) {
      let dataHeight = (this.data.length * 20) + 10;
      let height = Math.max(40, dataHeight);//40 is the minimum height for titles column i.e. projectTitle column in powersearch grid
      params.node.setRowHeight(height);
    }

    if (params.colValue.routing) {
      const routeParams = GridDataOperations.extractValueFromProperty(params.data[params.colValue.iterable], params.colValue.routing.routeParams);

      if (routeParams) {
        this.data.forEach((element, index) => {
          if (Array.isArray(routeParams[index])) {
            routeParams.splice(index, 1);
          }
          element.route = GridDataOperations.buildRoute(
            params.colValue.routing.routePre,
            routeParams[index],
            params.colValue.routing.routePost
          );
        });
      }
    }
  }


  private SetNameSeaparateValue(value) {
    this.data = value;
  }

  public open() {
    if (this.redirectTo! = '' && this.destinationUrl == true) {
      window.location.href = this.redirectTo;
    }
  }


  /**
   * Checks the length of the data to determine if the expand/collapse icon needs to display or not.
   * If the length is less than three, the arrow does not need to display.
   */
  public isCorrectLength(): boolean {
    if (this.data) {
      let height = 0;
      this.data.forEach(element => {
        element.height = parseInt(element.height, 10);
        height = element.height + height;
      });
      if (this.minHeight >= 110) {
        return this.data.length > 5;
      } else {
        return this.data.length > 3 || height > 60;
      }
    }
  }

  /**
   * Gets the index of the row being expanded (with Renderer2) and emits an event for expanding.
   */
  public toggleState(): void {
    const parent = this.renderer.parentNode(this.elRef.nativeElement);
    const grandparent = this.renderer.parentNode(parent);
    this.isCollapsed = !this.isCollapsed;

    this.gridEventService.expandEvent({
      index: grandparent.getAttribute('row-index'),
      state: this.isCollapsed,
      height: Math.max((this.totalHeight + 10), this.maxHeight)
    });
  }


  /**
   * Calculates and formats the data to be displayed on each list item. Loops through each key and adds the
   * data at data[key] and adds to the string to be displayed. This way we can add as many properties as we need displayed.
   *
   * @param data The list data to iterate over.
   */
  private formatDataToDisplay(data) {
    const formattedData = [];
    this.totalHeight = 0;
    if (data) {
      if (!this.isMultiple) {
        data.forEach((el, index) => {
          let liHeight = 20;

          if (this.compareArr) {
            if (this.compareArr.length > 1 && this.compareArr[index] && this.compareArr[index].length > 0) {
              liHeight = this.compareArr[index].length * 20;
            }
          }

          const liHeightPx = String(liHeight) + 'px';
          const elVal = el ? el.trim() : '';
          formattedData.push({ value: elVal, height: liHeightPx });
          this.totalHeight += liHeight;
        });
      } else {
        data.forEach(element => {
          if (Array.isArray(element) && element.length) {
            if (element.length) {
              element.forEach((el) => {
                formattedData.push({ value: el, height: '20px' });
                this.totalHeight += 20;
              });
            } else {
              formattedData.push({ value: '', height: '20px' });
              this.totalHeight += 20;
            }
          } else {
            formattedData.push({ value: '', height: '20px' });
            this.totalHeight += 20;
          }
        });
      }
    }
    return formattedData;
  }

  public clickEventTitle(data: any): void {
    this.gridEventService.clickItemEvent({ title: data.value, route: data.route });
  }

  public downloadFile(item) {
    this.gridEventService.downloadPdfFile(item, this.params);
  }
}
