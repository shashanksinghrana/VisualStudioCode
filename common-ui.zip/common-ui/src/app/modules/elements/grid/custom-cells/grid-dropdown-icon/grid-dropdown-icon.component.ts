import { Component } from '@angular/core';
import { INoRowsOverlayAngularComp } from 'ag-grid-angular';

@Component({
    selector: 'c2c-grid-dropdown-icon',
    templateUrl: './grid-dropdown-icon.component.html',
    styleUrls: ['./grid-dropdown-icon.component.scss']
})
export class GridDropDownIconCellComponent implements INoRowsOverlayAngularComp {
    public iconSource: string;
    public value: any;

    /** Expecting Option in [id, value, icon] format
     *
     * @param params
     */
    agInit(params): void {
        this.value = params.value;
        if (params && params.colDef) {
            const iconName = this.getIconName(params.colDef.cellEditorOptions, params.value);
            if (iconName) {
                this.iconSource = `${iconName}`;
            }
        }
    }

    public getIconName(options, name) {
        if (null != options && null != name) {
            for (const data of options) {
                if (null != data && name === data.value) {
                    return data.icon;
                }
            }
        }
    }
}
