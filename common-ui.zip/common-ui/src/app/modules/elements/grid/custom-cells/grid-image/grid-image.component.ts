import { Component, ElementRef, Renderer2 } from '@angular/core';
import { GridDataOperations } from '../../../../../utils/grid/grid-data-operations';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';

/**
 * The GridImageComponent
 *
 * Grid Cell Renderer that handles the display of images in the Grid.
 */
@Component({
  selector: 'c2c-grid-image',
  templateUrl: './grid-image.component.html',
  styleUrls: ['./grid-image.component.scss']
})
export class GridImageComponent {
  public image: any;
  public imageFor: any;
  public route: string;
  public subTitles: Array<string>;
  public title: string;
  public firstTitle: string;
  public lastTitle: string;

  public titleArr: Array<string> = [];
  public titleSubtext: string;
  public fullName: string;

  public enableCollapse: boolean = false;
  public isCollapsed: boolean = true;

  private isMultiple: boolean = false;
  private maxHeight: number;
  private minHeight: number;
  private totalHeight: number;
  public callsheetStatus: string;
  /**
   * Constructor for the GridImageComponent
   */
  constructor(private gridEventService: GridEventService,
    private elRef: ElementRef,
    private renderer: Renderer2) { }

  /**
   * Ag-grid event for doing any initialization logic on the Cell Renderer.
   * Calculates each value to be displayed, calculates the row height, and sets the routing (if configured).
   *
   * @param params The params passed in from the ag-grid event. This contains information on the Grid,
   *  including the data and parameters from the ImageParamsModel.
   */
  agInit(params: any) {
    this.enableCollapse = params.isSubtitleExpandable;
    params.mainTitle.keys.forEach((key) => {
      this.titleArr.push(GridDataOperations.extractValueFromProperty(params.data, key));
    });

    this.title = GridDataOperations.concatenateStringValuesFromData(params.data, params.mainTitle.keys);
    this.firstTitle = (this.titleArr[0] !== undefined && this.titleArr[0] !== null) ? this.titleArr[0] : "";
    this.lastTitle = (this.titleArr[1] !== undefined && this.titleArr[1] !== null) ? this.titleArr[1] : "";

    this.subTitles = this.formatDataToDisplay(GridDataOperations.extractValueFromProperty(params.data, params.subTitleKey));
    this.image = GridDataOperations.extractValueFromProperty(params.data, params.imageKey);
    this.fullName = this.getFullName();

    if (params.titleSubtext) {
      if (!params.titleSubtext.replaceBooleanWith) {
        this.titleSubtext = GridDataOperations.extractValueFromProperty(params.data, params.titleSubtext.key);
      } else {
        this.titleSubtext = GridDataOperations.extractValueFromProperty(params.data, params.titleSubtext.key)
          ? params.titleSubtext.replaceBooleanWith
          : null;
      }
    }

    this.maxHeight = (this.subTitles.length * 20) + 10;
    this.callsheetStatus=params.imageKeyFor;
    if(this.callsheetStatus==="callsheet"){
      params.node.minHeight = params.height ? params.height : 65;
    }
    else{
      params.node.minHeight = params.height ? params.height : 110;
    }
    params.node.setRowHeight(GridDataOperations.calculateHeightOfColumn(params));

    if (this.subTitles.length > 1) {
      const height = GridDataOperations.calculateHeightOfColumn(params);
      const listHeight = this.subTitles.length > 2 ? 70 : 50;
      this.minHeight = Math.max(height, listHeight);
      params.node.minHeight = this.minHeight;
      params.node.setRowHeight(this.minHeight);

      this.maxHeight = (this.subTitles.length * 20) + 10;
      params.node.maxHeight = Math.max(this.maxHeight, this.totalHeight);
    }

    if (params.mainTitle.routing) {
      //To check whehter the dynamic routing property or text value
      if(params.mainTitle.routing.dynamicRoute) {
        this.route = GridDataOperations.buildRoute(
          params.data[params.mainTitle.routing.routePre],
          params.data[params.mainTitle.routing.routeParams],
          params.mainTitle.routing.routePost
        );
      } else {
        this.route = GridDataOperations.buildRoute(
          params.mainTitle.routing.routePre,
          params.data[params.mainTitle.routing.routeParams],
          params.mainTitle.routing.routePost
        );
      }
    }


    if (!this.image) {
      this.imageFor = params.imageKeyFor;
       //To check whehter the dynamic image key placeholder property or text value
      if(params.dynamicImageKeyFor && null != params.imageKeyFor && params.imageKeyFor != undefined) {
        this.imageFor = params.data[params.imageKeyFor];
      }
      if (this.imageFor == "peoplePlaceholder" || this.imageFor == undefined || this.imageFor == null) {
        this.image = './assets/images/no-image.png'; // set default image to people placeholder
      } else {
        this.image = './assets/images/company_placeholder.png'; // set default image to company placeholder
      }
    }
    else {
      if(params.imageKeyFor != "callsheet"){
        this.image = this.image + "?" + this.getRandomNumber(1);
      }
    }
  }

  // Generate random number for appending it in image url to avoid cache issue
  getRandomNumber(i: number) {
    let random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    return random;
  }

  getFullName() {
    let temp = '';
    this.titleArr.forEach((item) => {
      if ((item !== undefined && item !== null)) {
        if(temp) {
          temp = temp + ' ' + item;
        } else {
          temp = item;
        }
        // temp = temp.trim();
      }

    })

    return temp;
  }


  /**
   * Checks the length of the data to determine if the expand/collapse icon needs to display or not.
   * If the length is less than three, the arrow does not need to display.
   */
  public isCorrectLength(): boolean {
    if (this.subTitles) {
      if (this.minHeight >= 110) {
        return this.subTitles.length > 4;
      } else {
        return this.subTitles.length > 3;
      }
    }
  }

  /**
  * Calculates and formats the data to be displayed on each list item. Loops through each key and adds the
  * data at data[key] and adds to the string to be displayed. This way we can add as many properties as we need displayed.
  *
  * @param data The list data to iterate over.
  */
  private formatDataToDisplay(data) {
    const formattedData = [];
    this.totalHeight = 0;

    if (!this.isMultiple && data) {
      data.forEach((el, index) => {
        let liHeight = 20;

        if (this.subTitles) {
          if (this.subTitles.length > 1 && this.subTitles[index] && this.subTitles[index].length > 0) {
            liHeight = this.subTitles[index].length * 20;
          }
        }

        const liHeightPx = String(liHeight) + 'px';
        const elVal = el ? el.trim() : '';
        formattedData.push({ value: elVal, height: liHeightPx });
        this.totalHeight += liHeight;
      });
    } else if (data) {
      data.forEach(element => {
        if (Array.isArray(element) && element.length) {
          if (element.length) {
            element.forEach((el) => {
              formattedData.push({ value: el, height: '20px' });
              this.totalHeight += 20;
            });
          } else {
            formattedData.push({ value: '', height: '20px' });
            this.totalHeight += 20;
          }
        } else {
          formattedData.push({ value: '', height: '20px' });
          this.totalHeight += 20;
        }
      });
    }

    return formattedData;
  }

  /**
   * Gets the index of the row being expanded (with Renderer2) and emits an event for expanding.
   */
  public toggleState(): void {
    const parent = this.renderer.parentNode(this.elRef.nativeElement);
    const grandparent = this.renderer.parentNode(parent);
    const titleHeight = parent.firstElementChild.children[0].children[1].offsetHeight;
    this.isCollapsed = !this.isCollapsed;

    this.gridEventService.expandEvent({
      index: grandparent.getAttribute('row-index'),
      state: this.isCollapsed,
      height: Math.max((this.totalHeight + 10 + titleHeight), this.maxHeight)
    });
  }

  public clickEventTitle(): void {
    this.gridEventService.clickItemEvent({title: this.fullName, subtitle: this.titleSubtext, route: this.route});
  }

}
