import { Component, Renderer2, ElementRef, Output, EventEmitter } from '@angular/core';
import { GridEventService } from '../../../../../services/events/grid/grid-event.service';
import { GridDataOperations } from '../../../../../utils/grid/grid-data-operations';

/**
 * The GridListComponent
 *
 * Grid Cell Renderer that handles the display of lists (with optional expand/collapse arrow) in the Grid.
 */
@Component({
  selector: 'c2c-grid-list-clickable',
  templateUrl: './grid-list-clickable.component.html',
  styleUrls: ['./grid-list-clickable.component.scss']
})
export class GridListClickableComponent {

  @Output() ChangeStatus:  EventEmitter<string> = new EventEmitter<string>();
  // @Output() ChangeStatus= new EventEmitter<string>();



  public data: any;
  public enableCollapse: boolean = false;
  public isCollapsed: boolean = true;

  private compareArr: any[];
  private isMultiple: boolean = false;
  private maxHeight: number;
  private minHeight: number;
  private totalHeight: number;
  MainArrayData: any = [];
  showloader: boolean;
  clikedIndex: any;


  /**
   * Constructor for the grid-list-clickableComponent
   *
   * @param gridEventService The service to handle all events related to the Grid.
   * @param elRef A reference to a certain element in the DOM. In this case, the list.
   * @param renderer Used for safely accessing elements in the DOM.
   */
  constructor(private gridEventService: GridEventService,
    private elRef: ElementRef,
    private renderer: Renderer2) { }

  /**
   * Ag-grid event for doing any initialization logic on the Cell Renderer.
   * Calculates each value to be displayed, calculates the row height, and sets the routing (if configured).
   *
   * @param params The params passed in from the ag-grid event. This contains information on the Grid,
   *  including the data and parameters from the ListParamsModel.
   */
  public agInit(params: any): void {
    if (params.value.length !== 0) {
      this.MainArrayData.push(params.data.recipients);
    }
    this.enableCollapse = params.isExpandable;
    this.isMultiple = params.isMultiple;

    if (params.spacingKey) {
      this.compareArr = GridDataOperations.extractValueFromProperty(params.data[params.colValue.iterable], params.spacingKey);
    }

    this.data = this.formatDataToDisplay(
      GridDataOperations.concatenateArrayValuesFromData(params.data[params.colValue.iterable], params.colValue.keys)
    );


    if (this.data.length > 1) {
      const height = GridDataOperations.calculateHeightOfColumn(params);
      const listHeight = this.data.length > 2 ? 70 : 50;
      this.minHeight = Math.max(height, listHeight);
      params.node.minHeight = this.minHeight;
      params.node.setRowHeight(this.minHeight);

      this.maxHeight = (this.data.length * 20) + 10;
      params.node.maxHeight = Math.max(this.maxHeight, this.totalHeight);
    }

    if (params.colValue.routing) {
      const routeParams = GridDataOperations.extractValueFromProperty(params.data[params.colValue.iterable], params.colValue.routing.routeParams);

      if (routeParams) {
        this.data.forEach((element, index) => {
          element.route = GridDataOperations.buildRoute(
            params.colValue.routing.routePre,
            routeParams[index],
            params.colValue.routing.routePost
          );
        });
      }
    }
  }

  /**
   * Checks the length of the data to determine if the expand/collapse icon needs to display or not.
   * If the length is less than three, the arrow does not need to display.
   */
  public isCorrectLength(): boolean {
    if (this.minHeight >= 110) {
      return this.data.length > 5;
    } else {
      return this.data.length > 3;
    }
  }

  /**
   * Gets the index of the row being expanded (with Renderer2) and emits an event for expanding.
   */
  public toggleState(): void {
    const parent = this.renderer.parentNode(this.elRef.nativeElement);
    const grandparent = this.renderer.parentNode(parent);
    this.isCollapsed = !this.isCollapsed;

    this.gridEventService.expandEvent({
      index: grandparent.getAttribute('row-index'),
      state: this.isCollapsed,
      height: Math.max((this.totalHeight + 10), this.maxHeight)
    });
  }


  /**
   * Calculates and formats the data to be displayed on each list item. Loops through each key and adds the
   * data at data[key] and adds to the string to be displayed. This way we can add as many properties as we need displayed.
   *
   * @param data The list data to iterate over.
   */
  private formatDataToDisplay(data) {
    const formattedData = [];
    this.totalHeight = 0;

    if (data) {
      if (!this.isMultiple) {
        data.forEach((el, index) => {
          let liHeight = 20;
          if (this.compareArr) {
            if (this.compareArr.length > 1 && this.compareArr[index] && this.compareArr[index].length > 0) {
              liHeight = this.compareArr[index].length * 20;
            }
          }
          const liHeightPx = String(liHeight) + 'px';
          const elVal = el ? el.trim() : '';
          // foreach is to set the status for each user from the json data got from web service
          this.MainArrayData.forEach((item, recipientsIndex) => {
            formattedData.push({ value: elVal, height: liHeightPx, status: item[index].permission });
          });
          this.totalHeight += liHeight;
        });
      } else {
        data.forEach(element => {
          if (Array.isArray(element) && element.length) {
            if (element.length) {
              element.forEach((el) => {
                formattedData.push({ value: el, height: '20px' });
                this.totalHeight += 20;
              });
            } else {
              formattedData.push({ value: '', height: '20px' });
              this.totalHeight += 20;
            }
          } else {
            formattedData.push({ value: '', height: '20px' });
            this.totalHeight += 20;
          }
        });
      }
    }
    return formattedData;
  }

  // calling the web service to revoke the permision of user and chainging the status
  perform_revoke_permission(val, clickedIndex) {
    this.ChangeStatus.emit('val');
  }

}
