import { Component} from '@angular/core';

/**
 * The GridDaysCarouselComponent
 *
 * Grid Cell Renderer that handles the display of day selector in the Grid. Please note that there is no view mode for the same.
 */
@Component({
  selector: 'c2c-grid-days-carousel',
  templateUrl: './grid-days-carousel.component.html',
  styleUrls: ['./grid-days-carousel.component.scss']
})
export class GridDaysCarouselComponent {
  agInit(params): void {
    params.node.setRowHeight(30);//resetting height to default in view mode.
  }
}
