import { Component } from '@angular/core';
import { INoRowsOverlayAngularComp } from 'ag-grid-angular';
@Component({
    selector: 'grid-typeahead-dropdown',
    templateUrl: './grid-typeahead-dropdown.component.html',
    styleUrls: ['./grid-typeahead-dropdown.component.scss']
})
export class GridTypeaheadDropdownCellComponent {
    public value: any ;

    /** Expecting Option in [id, value] format
     *
     * @param params
     */

    agInit(params): void {
            this.value = params.value;
    }

}
