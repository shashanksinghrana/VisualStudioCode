import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { GridDataOperations } from '../../../../../utils/grid/grid-data-operations';

@Component({
    selector: 'c2c-grid-checkbox',
    templateUrl: './grid-checkbox.component.html',
    styleUrls: ['./grid-checkbox.component.scss']
})
export class GridCheckBoxCellComponent implements ICellRendererAngularComp  {
    public toggleEditMode: boolean = false;
    public titlesArray: string;
    public value: any;
    public showLabel: boolean = false;

    /**
     *
     * @param params (expecting titleKey, toggleEditMode & showLabel)
     */
    public agInit(params): void {
        this.value = params.value;
        if (params.checkBox.titleKey) {
            const prop = GridDataOperations.extractValueFromProperty(params.data, params.checkBox.titleKey);
            if (prop && prop.length > 0) {
                let str = '';
                prop.forEach(item => {
                    str += this.wrapText(item);
                });
                this.titlesArray = str;
            }
        }

        if (params.checkBox.toggleEditMode) {
            this.toggleEditMode = true;
        }
        if (params.checkBox.showLabel) {
            this.showLabel = true;
        }
    }

    /** This method is used to split large html string to multiline and showing text content */
    private wrapText(str: string): string {
        const output = [];
        if (str) {
            const len = 50;
            let curr = len;
            let prev = 0;
            while (str[curr]) {
                if (str[curr++] === ' ') {
                    const line = str.substring(prev, curr) + '&#13;';
                    output.push(line);
                    prev = curr;
                    curr += len;
                }
            }
            const breakline = str.substring(prev) + '&#13;';
            output.push(breakline);
        }
        let content = output.join('');
        // convert html string to text
        if (content && content.length > 0) {
            const elem = document.createElement('div');
            elem.innerHTML = content;
            content = elem.textContent;
        }
        return content;
    }

    public refresh(params: any): boolean {
        return false;
    }

    /**
    * Returns the classes for the checkbox based on edit mode
    */
    public getReadOnlyClass() {
        let cssClasses = '';
        if (this.value) {
            cssClasses = 'c2c-input-checkboxes-checked';
        }
        this.toggleEditMode ? (cssClasses += ' c2c-input') : (cssClasses += ' c2c-readonly');
        return cssClasses;
    }

    /**
    * Returns the classes for the checkbox based on edit mode
    */
   public addLineBreakForTitles(titles) {
    return titles.join('\n');
   }
}
