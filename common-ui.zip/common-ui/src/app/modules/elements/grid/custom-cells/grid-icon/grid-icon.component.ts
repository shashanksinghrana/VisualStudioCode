import { Component } from '@angular/core';

/**
 * The GridIconComponent
 *
 * Grid Cell Renderer that is used for displaying icons in the Grid.
 */
@Component({
  selector: 'c2c-grid-icon',
  templateUrl: './grid-icon.component.html',
  styleUrls: ['./grid-icon.component.scss']
})
export class GridIconComponent {
  public value: any;
  public currentRow: any;
  public rowIndex: number;
  public deleteIcon: { visible: boolean, action?: () => any, displayOnCellEdit?:boolean, selectedRowIndex?: number, showIconsOnNextLine?:boolean };
  public editIcon: { visible: boolean, action?: () => any };
  public pdfIcon: { visible: boolean, action?: () => any };
  public showDeleteIconInViewMode: boolean = true;
  /**
   * Constructor for the GridIconComponent
   */
  constructor() { }

  /**
   * Ag-grid event for doing any initialization logic on the Cell Renderer.
   *
   * @param params The params passed in from the ag-grid event. This contains information on the Grid,
   *  including the data and parameters from the GridIconComponent.
   */
  public agInit(params: any): void {
    if(params.value){
      this.value = params.value;
    }
    this.currentRow = params.node;
    this.deleteIcon = params.deleteIcon;
    this.editIcon = params.editIcon;
    this.pdfIcon = params.pdfIcon;
    this.rowIndex = params.rowIndex;

    if(params.colDef.cellRendererParams.showDeleteIconInViewMode === undefined){
      this.showDeleteIconInViewMode = true;
    }else{
      if(params.colDef.cellRendererParams.showDeleteIconInViewMode){
        this.showDeleteIconInViewMode = true;
      }else{
        this.showDeleteIconInViewMode = false;
      }
    }
    
    if((params.colDef.cellRendererParams.showDefaultHeightInViewMode !== undefined) && !(params.colDef.cellRendererParams.showDefaultHeightInViewMode)){
      params.node.setRowHeight(30);
    }
  }

  /**
   * Performs the given click action passed in. This is a generic function set on each individual button for dynamic capabilities.
   *
   * @param fn The callback action (defined in {@link GridIconParamsModel}) to be performed on the button. Also passes
   *  the current row for doing operations on the row data.
   */
  public performAction(fn: (row) => any): void {
    fn(this.currentRow);
  }
}
