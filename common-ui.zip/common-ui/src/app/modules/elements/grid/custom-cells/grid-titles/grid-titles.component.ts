import { GridEventService } from './../../../../../services/events/grid/grid-event.service';
import { Component } from '@angular/core';
import { GridDataOperations } from '../../../../../utils/grid/grid-data-operations';

/**
 * The GridTitlesComponent
 *
 * Grid Cell Renderer that handles the display of Titles and Subtitles in the Grid.
 * An example of use, would be the project title/aka names column of the All Project Grid in FC.
 */
@Component({
  selector: 'c2c-grid-titles',
  templateUrl: './grid-titles.component.html',
  styleUrls: ['./grid-titles.component.scss']
})
export class GridTitlesComponent {
  public route: string;
  public subTitles;
  public title;
  public showMultipleSubTitle: boolean  = false;
  public params: any;
  public disable:boolean=false;

  /**
   * Constructor for the GridTitlesComponent
   */
  constructor(private gridEventService: GridEventService) { }

  /**
   * Ag-grid event for doing any initialization logic on the Cell Renderer.
   * Calculates each value to be displayed, calculates the row height, and sets the routing (if configured).
   *
   * @param params The params passed in from the ag-grid event. This contains information on the Grid,
   *  including the data and parameters from the TitlesParamsModel.
   */
  agInit(params: any): void {
    this.params = params;
    this.title = GridDataOperations.concatenateArrayValuesFromData(params.data, params.mainTitle.keys);
    if(params.disableLinks)
    {
      this.disable=params.disableLinks;
    }
   
    if(params.showMultipleSubTitle){
      this.showMultipleSubTitle = params.showMultipleSubTitle;
      let subTitleArr = GridDataOperations.extractValueFromProperty(params.data, params.subTitleKey);
      this.subTitles = subTitleArr ? subTitleArr[0] : subTitleArr;
    }else{
      this.subTitles = this.formatSubtitles(GridDataOperations.extractValueFromProperty(params.data, params.subTitleKey));
    }

    if (params.mainTitle.routing) {
      this.route = GridDataOperations.buildRoute(
        params.mainTitle.routing.routePre,
        params.data[params.mainTitle.routing.routeParams],
        params.mainTitle.routing.routePost
      );
    }

    if (this.subTitles) {
      if(this.showMultipleSubTitle){
        params.node.setRowHeight((Object.keys(this.subTitles).length*20) + 20);
      }else{
        params.node.setRowHeight(40);
      }
    }else{
      params.node.setRowHeight(30);
    }
    
  }

  /**
   * Takes an array of strings and converts into single string with semi-colons appended between each item.
   *
   * @param titles An array of strings to iterate over.
   */
  formatSubtitles(titles) {
    let str = '';
    titles.forEach(title => {
      str += title;
      if (titles[titles.length - 1] !== title) {
        str += '; ';
      }
    });
    return str;
  }

  /**
   * Iterates over Object properties for displaying in HTML
   *
   * @param obj An Object
   */
  objectKeys(obj) {
    return Object.keys(obj);
  }

  onClickTitle(evt): any {
    if (!this.params.enableRowEditing) {
      this.gridEventService.clickItemEvent({title: this.title, route: this.route, param: this.params});
    } else {
      this.gridEventService.enableRowEditingEvent(this.params);
    }
  }
}
