import { Component } from '@angular/core';
import { INoRowsOverlayAngularComp } from 'ag-grid-angular';
@Component({
    selector: 'grid-typeahead',
    templateUrl: './grid-typeahead.component.html',
    styleUrls: ['./grid-typeahead.component.scss']
})
export class GridTypeaheadCellComponent {
    public value: any ;
    public typeaheadStatus:boolean;

    /** Expecting Option in [id, value] format
     *
     * @param params
     */

    agInit(params): void {
        var textFieldStatus = params.column.colDef['cellRendererParams'].textField;
        if(textFieldStatus == true){
            this.typeaheadStatus = false;
            this.value = params.value;
        }else{
            this.typeaheadStatus = true;
            this.value = params.value;
        }
    }

}
