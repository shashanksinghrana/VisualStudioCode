import { GridEventService } from './../../../../../services/events/grid/grid-event.service';
import { Component } from '@angular/core';
import { GridDataOperations } from '../../../../../utils/grid/grid-data-operations';

/**
 * The GridLinkComponent
 *
 * Grid Cell Renderer that converts given data to a link for navigation purposes.
 */
@Component({
  selector: 'c2c-grid-link',
  templateUrl: './grid-link.component.html',
  styleUrls: ['./grid-link.component.scss']
})
export class GridLinkComponent {
  public route: string;
  public routeParams: string;
  public value: string;
  public anchor: boolean = false;
  public params : any;
  public newLink: string;
  public showAttachIcon: boolean = false;
  public enableRowEditing: boolean = false;
  public customStyle:boolean = false;
  public disabled:boolean=false;

  /**
   * Constructor for the GridLinkComponent
   */
  constructor(private gridEventService: GridEventService) { }

  /**
   * Ag-grid event for doing any initialization logic on the Cell Renderer.
   * Calculates the values to display and the route of the link.
   *
   * @param params The params passed in from the ag-grid event. This contains information on the Grid,
   *  including the data and parameters from the GridLinkComponent.
   */
  agInit(params: any) {
    this.params = params;
    if(params.disableLink)
    {
      this.disabled=params.disableLink
    }
    this.enableRowEditing = params.enableRowEditing;
    this.routeParams = GridDataOperations.extractValueFromProperty(params.data, params.routeParams);
    if (params.data.destinationUrl) {
      if (params.data.destinationUrl.indexOf('http') >= 0) {
        this.anchor = true;
        this.newLink = params.data.destinationUrl;
        if(params.customStyle == true){
          this.customStyle = true;
        }
      }
    }
    //this.routeParams = GridDataOperations.extractValueFromProperty(params.data, params.routeParams);
    else {
      this.route = GridDataOperations.buildRoute(params.routePre, this.routeParams, params.routePost);
    }



    if (params.field) {
      this.value = GridDataOperations.extractValueFromProperty(params.data, params.field);
    } else {
      this.value = params.value;
    }

    if(params.showImage){
      this.showAttachIcon = true;
    }
  }

  open() {
    window.location.href = this.newLink;
  }

  public clickEventTitle(): void {
    if(this.params.colDef.cellRendererParams.routePre !== 'enableEditing'){
      this.gridEventService.clickItemEvent({title: this.value, route: this.route, param: this.params});
    }else{
      this.gridEventService.enableRowEditingEvent(this.params);
    }
  }

  public downloadFile(event): void {
    this.gridEventService.downloadFileEvent(this.params);
  }
}
