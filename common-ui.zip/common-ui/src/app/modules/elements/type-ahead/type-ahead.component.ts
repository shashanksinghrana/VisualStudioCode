import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  Renderer2,
  ViewChild,
  ElementRef,
  forwardRef,
  AfterViewInit
} from '@angular/core';
import {
  FormGroup,
  FormControl,
  AbstractControl,
  ControlValueAccessor,
  NG_VALUE_ACCESSOR
} from '@angular/forms';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/merge';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/operator/filter';
import { NgbTypeaheadConfig, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { TypeAheadModel } from '../../../models/type-ahead/type-ahead.model';
import { TypeAheadEventService } from '../../../services/events/type-ahead/type-ahead-event.service';
import { TypeAheadDisplayModel } from '../../../models/type-ahead/type-ahead-display';
import { AccentedLetters } from '../../../enums/characters/accented-letters.enum';
import { CharKeyCodes } from '../../../enums/characters/character-keycodes.enum';
import { LastCommaWins } from '../../../utils/formatting/last-comma-wins.format';
import { formatSSN } from '../../../utils/formatting/ssn.format';
import { UserRole } from '../../../enums/entity/user-role.enum';
import { SpecialStrings } from '../../../enums/characters/special-strings.enum';
import { removeWhitespace } from '../../../utils/strings/remove-whitespace';
import { TypeAheadDisplayResultModel } from '../../../models/type-ahead/type-ahead-display-result.model';
import { TypeAheadPersistService } from '../../../services/persist/type-ahead/type-ahead-persist.service';
import { ModalGenericComponent } from '../../../modal/generic/modal-generic.component';
import { TypeAheadMetaData } from '../../../enums/entity/type-ahead-metadata.enum';
declare var $: any;

@Component({
  selector: 'c2c-type-ahead',
  templateUrl: './type-ahead.component.html',
  styleUrls: ['./type-ahead.component.scss'],
  /**
   * NG_VALUE_ACCESSOR for allowing the typeAhead to work with reactive forms
   * Other pieces to this:
   *  getter/setter for the value property
   *  public onTouched: any = () => { };
      public writeValue(obj: any): void { this.value = obj; }
      public registerOnChange(fn: any): void { this.onChange = fn; }
      public registerOnTouched(fn: any): void { this.onTouched = fn; }
      public setDisabledState?(isDisabled: boolean): void {  this.disabledTypeAhead = isDisabled; }
   */
  providers: [NgbTypeaheadConfig,
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TypeAheadComponent),
      multi: true
    }]
})

export class TypeAheadComponent implements OnInit, AfterViewInit, ControlValueAccessor {

  private _accentedCharacter: string;
  private _listName: string;
  public _value: any;
  public temp_value: any;
  private searchTerm: string;
  public secondaryDisplayArray: Array<string> = [];
  public titles: Array<string> = [];
  private _typeAheadModalConfig: any;
  private _dataTypeResults: string = 'PERSON';
  public typeaheadTitle: string = '';
  public typeAheadReturnData: any;
  /**Duplicate modal element refenece  */
  @ViewChild('duplicateModal') duplicateModal: ElementRef;
  private modalRef: NgbModalRef;

  /**Property used to remove focus when you set data in typeahed  */
  @Input() removeFocus: boolean = false;

  /**Property to setup data type for TypeAhead results (Talent, Company)  */
  @Input()
  set dataTypeResults(type: string) {
    if (type) {
      this._dataTypeResults = type.toLocaleUpperCase();
      if (!this.removeFocus) {
        this.clearTypeAheadField();
      }
    }
  }
  get dataTypeResults(): string { return this._dataTypeResults; }

  /**Data configuration for typeAhead display */
  @Input() public displayDataResults: TypeAheadDisplayResultModel;
  /**Parent module containing the typeAhead */
  @Input() public parentModule: string;
  /**Background text to display in typeAhead input field */
  @Input() public placeholderText: string;
  /**Initial text to display in typeAhead input field */
  @Input() public initialText: string;
  /**Service needed to return typeAhead results */
  @Input() public service: any;
  /**Shows/Hides accented character icon */
  @Input() public toggleAccentedCharacterIcon: boolean = false;
  /**When using the add name modal */
  @Input() public toggleAddNameModal: boolean = false;
  /**Shows/Hides add as same button */
  @Input() public toggleAddSameNameButton: boolean = false;
  /**Shows/Hides clear button */
  @Input() public toggleClearButton: boolean = false;
  /**When using a custom modal */
  @Input() public toggleCustomModal: boolean = false;
  /**Show/Hide loading spinner */
  @Input() public toggleLoadingSpinner: boolean = false;
  /**When selecting one result and populating the typeAhead input with that value */
  @Input() public toggleSingleRecord: boolean = false;
  /**Show/Hide Search Icon */
  @Input() public toggleSearchIcon: boolean;
  /**When adding selected result to list */
  @Input() public addToList: boolean = false;
  /**Quick add Modal will not be open when the user hit tab or enter */
  @Input() public isQuickAddModal: boolean = false;
  /**Modal being used when toggleCustomModal is set to true */
  @Input() public customModal: ModalGenericComponent;
  @Input() public hasNoResultsCallback: boolean;
  /**To disable the typeAhead */
  @Input('disabledTypeAhead') public disabledTypeAhead: boolean = false;
  /**Defines the name of the field to display in the typeahead (when the field name is something other than 'typeAheadDisplayName') */
  @Input() public singleFieldDisplayName: string = 'typeAheadDisplayName';
  /**Defines when the 'invalid' class should be set on the typeahead (for validation) */
  @Input() public isInvalid: boolean = false;
  /** Defines the tabbing sequence setting. */
  @Input() public tabIndex;
  /** Toggles specific 'readonly' class for displaying disabled element as text only (as opposed to being greyed-out) */
  @Input() public toggleReadonlyDisplay: boolean = false;

  /**Toggel specific 'highlight' class for displaying disable typeahead text in blue color */
  @Input() public toggelTextColor: boolean = false;

  @Input() public disableNotification: string = ''

  @Input() public setFocus: boolean = false;
  /**Title that shows above the typeAhead */
  @Input() public title: string;

  @Input() public titleWithClasses: boolean;
  /** handles focusFirst event */
  @Input() public focusFirst: Boolean = true;

  /**listName represents the list to populate selected results */
  @Input()
  set listName(val: string) { this._listName = removeWhitespace(val); }
  get listName(): string { return this._listName; }
  /**typeAheadModalConfig represents the add name modal to open and config  */
  @Input()
  set typeAheadModalConfig(config: any) { this._typeAheadModalConfig = config; }
  get typeAheadModalConfig(): any { return this._typeAheadModalConfig; }
  /**accentedModalName represents the accented modal to open*/
  @Input() accentedModalName: string = '';
  /**typeAheadId represents the value name to handle modals for one componente instance (acented characted and add new name modals)  */
  @Input() typeAheadId: string = '';

  /**For setting value from parent component */
  @Input()
  set updateValue(val: string) {
    this.typeAheadField.nativeElement.value = val;
  }
  // TAL-2347
  @Input() addEditMode: boolean = false;
  @Input() disableSearchName: boolean = false;
  // @Input() hideTypeAhead: boolean = false;
  @Input() duplicatedErrorMessage: string = '';
  @Input() dataResultNameSearch: Array<TypeAheadModel> = [];
  @Input("autoFocus") autoFocus: Boolean = false
  @Output() closeTypeAhead: EventEmitter<any> = new EventEmitter();
  @Input() confirmDuplicateName: Boolean = false;

  /**To display the duplicate entry alert if user slects an exsisitng entry */
  @Input() DuplicateAlert: Boolean = false;
  /**To display the duplicate entry alert if user clicks only ADDASNEW button no enter or tab  */
  @Input() DuplicateAlertOnAddasnew: Boolean = false;
  /**To display the duplicate entry alert mesage if the duplicate alert @input is true */
  @Input() DuplicateMessage: string = "The name already exists. Do you want to proceed?";

  @Output() confirmDuplicateNameEvent: EventEmitter<any> = new EventEmitter();

  /**Event emitted when no search results are found */
  @Output() public noSearchResultsReturned: EventEmitter<TypeAheadDisplayModel> = new EventEmitter();
  /**Event emitted when a typeAhead result is selected */
  @Output() public selectedTypeAheadRecord: EventEmitter<TypeAheadModel> = new EventEmitter();
  /**Event emitted to pass all returned search results */
  @Output() public typeAheadReturnResults: EventEmitter<any> = new EventEmitter();
  @Output() public valueEvent = new EventEmitter<string>();
  /**Viewchild used for the typeAhead input, used to get to nativeElement items */
  @ViewChild('typeAheadField') public typeAheadField: ElementRef;

  /**Getter for accented character(s) */
  public get accentedCharacter(): string { return this._accentedCharacter; }
  /**Setter for accented character(s) */
  public set accentedCharacter(val: string) { this._accentedCharacter = val; }
  /** Getter for the value property */
  public get value(): any { return this._value; }
  /** Setter for the value property */
  public set value(val: any) {

    if (this._value !== val) {
      this._value = val;
      this.onChange(val);
      this.onTouched();
    }
  }

  public emittedValue: string;
  /**Property used to enable accented character icon while typing in typeAhead input  */
  public hasAccentedCharacters: boolean;
  /**Property to check if results are returned */
  private hasReturnedResults: boolean;
  /**Property used while searching for results is in progress */
  public isSearching: boolean = false;
  /**Property used when search fails*/
  public searchFailed: boolean = false;
  public typeAheadHasValue: boolean;
  private enableClearbtn: boolean;

  /**Time between key presses before search is ran */
  private debounceTime: number = 0;
  /**Subject used to check if typeAhead input has a value */
  public typeAheadFocusSubject: Subject<string> = new Subject<string>();
  /**Subscribe to event for replacing standard character with accented one */
  private accentedCharacterSubscription: Subscription;
  /** Property to show error message when local duplicated is found */
  public duplicatedLocalSearchFlag: boolean = false;
  /**Subscribe to event when user role type is changed */
  private filterSubscription: Subscription;
  /**Show/Hide results when unsubscribing */
  private hideSearchingWhenUnsubscribed = new Observable(() => () => this.isSearching = false);
  /**Main reactive form */
  public typeAheadForm: FormGroup;
  /**Array for storing metadata strings */
  private metaDataArray: Array<string> = [];
  /** function to convert a given value into a string to display in the input field */
  public formatter: object = (x: { typeAheadDisplayName: string }) => x[this.singleFieldDisplayName];

  constructor(
    private typeAheadEventService: TypeAheadEventService,
    private typeAheadConfig: NgbTypeaheadConfig,
    private renderer: Renderer2,
    private typeAheadPersistService: TypeAheadPersistService,
    private TypeaheadmodalService: NgbModal) {

    // To enable auto suggestion for the searched text being copied to textfield enable it as true
    typeAheadConfig.showHint = false;

    this.accentedCharacterSubscription = this.typeAheadEventService.getAccentedCharacterReplacement()
      .subscribe(response => {
        if (response.modalName === this.accentedModalName && this.typeAheadId === response.componentId) {
          this.charToForeignChar(response.item);
        }
      });
  }

  /**
     * Emits the value of the input text box on model change.
     */
  public emitValue() {
    this.valueEvent.emit(this.value);
  }

  /** searches for typeAhead results
   * @param text observable of string returned when typing in the typeAhead input
  */
  public nameSearch: object = (text: Observable<string>) => text
    .debounceTime(this.debounceTime)
    .merge(this.typeAheadFocusSubject.filter((): boolean => {
      return (this.typeAheadField.nativeElement.value.trim() !== SpecialStrings.EMPTY ||
        this.typeAheadField.nativeElement.value.trim() !== SpecialStrings.EMPTY_OPEN);
    }))// when focused and value exists
    .distinctUntilChanged()
    .do(() => this.isSearching = true)
    .switchMap(term => this.mapTerm(term)
      .do(txt => this.searchFailed = false)
      .catch(() => {
        // if there's an error in the search
        if (this.disableNotification !== '') {
          this.searchFailed = false
        }
        else
          this.searchFailed = true;
        return of([]);
      })
    )
    .do(() => {
      return this.isSearching = false;
    })
    .merge(this.hideSearchingWhenUnsubscribed)

  /**
   * Map/Convert returned observable of results
   * @param term searched vale from typeAhead input
   */
  private mapTerm<T>(term: string): Observable<T[]> {
    this.searchTerm = term;

    if (term.trim() === SpecialStrings.EMPTY || term.trim() === SpecialStrings.EMPTY_OPEN) {
      this.setTypeAheadFocus();
      return of([]);
    }

    //
    /**
     * service for getting typeAheaad results
     * passed in to @Input() 'service'
     * this will run once per keystroke, so backend needs to handle this
     */
    if (!this.disableSearchName) {
      return this.displayDataResults.service.serviceClass[this.displayDataResults.service.get](this.searchTerm,
        String(this.displayDataResults.noRecordsToReturn), this.displayDataResults.filterType, this.displayDataResults.context)
        .map(res => {
          if (this.displayDataResults.service.get === 'getContactOnly') {
            // remove team
            const tempRes = [];
            res.forEach(element => {
              if (!element.isPartyTeam) {
                tempRes.push(element);
              }
            });
            res = tempRes;
          }
          return this.searchResults(res);
        });
    } else {
      this.hasReturnedResults = true;
      return of([]);
    }

  }

  ngOnInit() {
    this.typeAheadForm = new FormGroup({ typeAheadField: new FormControl() });

    if (this.disabledTypeAhead) {
      this.typeAheadForm.controls.typeAheadField.disable();
    }

    this.renderer.addClass(this.typeAheadField.nativeElement, this.toggleReadonlyDisplay ? 'c2c-readonly-input' : 'c2c-input');
    this.onChange();

    this.typeAheadEventService.getDuplicateNameConfimedEvent().subscribe(value => {
      this.openAddAsNewModal(value);
    });
  }

  public ngAfterViewInit(): void {
    if (this.setFocus) {
      this.setTypeAheadFocus();
    }
    if (this.initialText) {
      this.typeAheadField.nativeElement.value = this.initialText ? this.initialText : '';
    }
  }

  /** This method is used to set typeahead title when text is overflow and not visible*/
  private setTypeaheadTitle(): void {
    const elem = this.typeAheadField.nativeElement;
    if (elem) {
      if (elem.scrollWidth > elem.clientWidth) {
        this.typeaheadTitle = elem.value;
      } else {
        this.typeaheadTitle = '';
      }
    }
  }

  /** Fired when any changes to the model are detected */
  public onChange: any = () => {
    const typeAheadField: AbstractControl = this.typeAheadForm.controls.typeAheadField;

    // listen for typeAhead changes
    typeAheadField.valueChanges.subscribe(val => {
      this.setTypeaheadTitle();
      this.checkForAccentedLetters(val);
      this.typeAheadHasValue = this.doesTypeAheadHaveValue();
      this.enableClearbtn = this.doesTypeAheadHaveValue();;
      // TAL-2347
      this.duplicatedLocalSearchFlag = false;
    });
  }

  /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
  public onTouched: any = () => { };
  public writeValue(obj: any): void {
    this.value = obj;
    if (this.toggleSingleRecord) {
      this.typeAheadForm.get('typeAheadField').setValue(obj);
      if (obj != "") {
        this.enableClearbtn = true;
      }
    }
  }

  public registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  public registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  public setDisabledState?(isDisabled: boolean): void {
    this.disabledTypeAhead = isDisabled;
    this.disabledTypeAhead ? this.typeAheadForm.controls.typeAheadField.disable() : this.typeAheadForm.controls.typeAheadField.enable();
  }

  /**
   * @param results returned results from the ng-template in type-ahead.component.html
   */
  public resultsFromTemplate<T>(data: T): T {
    // set the object of returned data
    this.displayDataResults.results = data;
    let str: any = String(data[this.displayDataResults.primaryDisplayColumn]);

    const colKeysArr: Array<string> = this.displayDataResults.secondaryDisplay.secondaryColumns;
    let count: number = 0;
    // Create secondary display string, based off secondaryColumns set in TypeAheadDisplayResultModel
    Object.keys(data).forEach(() => {
      for (let i = 0; i < colKeysArr.length; i++) {
        if (this.toggleSecondaryDisplay()) {
          if (data[colKeysArr[i]] !== null && count < 1) {
            str += eval(this.displayDataResults.secondaryDisplay.display);
            count++;
          }
        }
      }
    });
    return str;
  }

  /**
   * Show/Hide secondary display if secondaryColumns are not 'null'
   */
  public toggleSecondaryDisplay(): boolean {
    const colKeysArr: Array<string> = this.displayDataResults.secondaryDisplay.secondaryColumns;
    let show: boolean = true;

    Object.keys(this.displayDataResults.results).forEach((key, index, arr) => {
      for (let i = 0; i < colKeysArr.length; i++) {
        if (this.displayDataResults.results[colKeysArr[i]] === null) {
          show = show && false;
        } else {
          if (this.displayDataResults.secondaryDisplay.notAllColumnsRequired) {
            show = true;
            break;
          }
          show = show && true;
        }
      }
    });
    return show;
  }

  public onBlur(event) {
    this.typeAheadHasValue = this.doesTypeAheadHaveValue();
    this.enableClearbtn = this.doesTypeAheadHaveValue();
  }

  /**
   * Listen for keyup events
   * @param evt keyboard event
   */
  public onKeyDown(evt: KeyboardEvent): void {

    if (this.isQuickAddModal === false) {
      if (this.hasReturnedResults === undefined || this.searchTerm.trim() === SpecialStrings.EMPTY) {
        return;
      }

      if (evt.keyCode === CharKeyCodes.LEFT_ARROW || evt.keyCode === CharKeyCodes.UP_ARROW ||
        evt.keyCode === CharKeyCodes.RIGHT_ARROW || evt.keyCode === CharKeyCodes.DOWN_ARROW) {
        this.checkForAccentedLetters(this.typeAheadField.nativeElement.value);
      }

      // Added TAB keydown to open quick add
      if ((evt.keyCode === CharKeyCodes.ENTER || evt.keyCode === CharKeyCodes.TAB || evt.keyCode === undefined) && this.typeAheadField.nativeElement.value.length) {
        if (this.hasReturnedResults) {
          if (evt.keyCode !== CharKeyCodes.TAB) {
            evt.preventDefault();
          }
          if (!this.hasNoResultsCallback && !this.addEditMode) {
            if (this.listName) {
              this.typeAheadEventService.listNameToLook(this.listName);
            }
          } else if (!this.hasNoResultsCallback && this.addEditMode) {
            // FC-3910 Duplicate title modal popup should open
            if (this.confirmDuplicateName && evt.keyCode === CharKeyCodes.ENTER) {
              this.confirmDuplicateNameEvent.emit();
            }
            if (!this.duplicatedLocalSearchFlag && !this.confirmDuplicateName) {
              evt.preventDefault(); // prevent the tabbing focus on close button
              evt.stopPropagation();
              this.searchLocalDuplicated(this.typeAheadField.nativeElement.value);
            }
          }
        } else {
          evt.preventDefault();
          evt.stopPropagation();
          this.openModal(this.typeAheadField.nativeElement.value);
        }
      }

    }
  }

  public onMouseUp(evt: MouseEvent): void {
    this.checkForAccentedLetters(this.typeAheadField.nativeElement.value);
  }

  // open addName for searched text.
  public openModal(seachedValue: string): void {
    if (!this.toggleAddNameModal && this.toggleCustomModal) {
      this.customModal.open();
      return;
    }
    if (this._typeAheadModalConfig && this._dataTypeResults === 'PERSON') {
      this._typeAheadModalConfig['modalOpen'] = true;
      this.typeAheadEventService.setModalConfig(this._typeAheadModalConfig);
    } else if (this._typeAheadModalConfig && this._dataTypeResults === 'COMPANY') {
      this._typeAheadModalConfig['modalOpen'] = true;
      this.typeAheadEventService.setModalCompanyConfig(this._typeAheadModalConfig);
    }

    let dataToSend: TypeAheadDisplayModel = new TypeAheadDisplayModel();
    if (this._dataTypeResults === 'PERSON') {
      dataToSend = LastCommaWins.parseData(seachedValue);
    } else {
      dataToSend.entityName = seachedValue;
    }
    this.typeAheadField.nativeElement.blur();
    this.clearTypeAheadField();
    this.typeAheadHasValue = this.doesTypeAheadHaveValue();
    this.enableClearbtn = this.doesTypeAheadHaveValue();
    if (this.hasNoResultsCallback) {
      this.noSearchResultsReturned.emit(dataToSend);
    } else {
      if (this.listName) {
        this.typeAheadEventService.listNameToLook(this.listName);
      }

      if (this._dataTypeResults === 'PERSON') {
        this.typeAheadEventService.typeAheadNoResults(dataToSend);
      } else {
        this.typeAheadEventService.typeAheadCompanyNoResults(dataToSend);
      }

    }
  }

  /** This method is used to explicitly disable button when record added */
  public setTypeaheadBtnDisable(isDisable: boolean): void {
    this.typeAheadHasValue = isDisable;
  }
  // emit selected event and pass the selected object+
  /**
   * NOTE: May need to look at updating this funtion for highlight use
   */
  public selectedItem(evt: Event): void {

    evt.preventDefault();
    // this.clearTypeAheadField(); // removed this, it prevents doesTypeAheadHaveValue() to execute.
    // this.typeAheadHasValue = this.doesTypeAheadHaveValue();
    this.enableClearbtn = true;
    //duplicate alert @input is true by default false,then below function will work to show the duplicate popup
    if (this.DuplicateAlert == true && this.DuplicateAlertOnAddasnew == false) {
      setTimeout(() => {
        this.modalRef = this.TypeaheadmodalService.open(this.duplicateModal);
        this.TrapFocusDuplicateAlertModal();
        document.getElementById("c2c-delete-confirmation-button-modal-cancel").focus();
      }, 80)
      this.temp_value = evt['item'];
      this.typeAheadForm.get('typeAheadField').setValue(this.temp_value);
    } else {
      this.value = evt['item'];
      // emit service event that will be listened by other components
      this.selectedTypeAheadRecord.emit(this.value);
      // selecting a single record, update typeAhead field with selected value
      if (this.toggleSingleRecord) {
        this.typeAheadForm.get('typeAheadField').setValue(this.value);
        //enabling clear button if toggle single record is true
        this.enableClearbtn = true;
        return;
      }

      try {
        if (!this.hasNoResultsCallback) {
          if (this.listName) {
            this.typeAheadEventService.listNameToLook(this.listName);
          }
        }

      } catch (err) {
        throw err;
      } finally {
        this.typeAheadForm.reset();
        this.clearTypeAheadField();
      }
    }

  }

  private emitSelectedRecord(): void {
    this.selectedTypeAheadRecord.emit(this.value);
  }

  /**
   * Returned data mapped from search
   * @param resArr returned data
   */
  private searchResults<T>(resArr: Array<T>): Array<T> {
    if (resArr.length === 0) {
      this.hasReturnedResults = false;
      this.noSearchResultsReturned.emit(null);
    } else {
      if (this.displayDataResults.metaDataColumns && Object.keys(this.displayDataResults.metaDataColumns).length) {
        this.displayDataResults.results = resArr.map(res => this.displaySearchResultMetadata(res));
      } else {
        console.error('MetaDataColums is not defined, please set it up: ', this.displayDataResults);
      }
      this.hasReturnedResults = true;
      this.typeAheadReturnResults.emit(resArr);
      this.typeAheadReturnData = resArr;
      return resArr;
    }
  }

  /**
   * watch for letters that have accented characters
   * @param val typed character value from typeAhead input field
   */
  private checkForAccentedLetters(val: string): void {

    const currPos = this.typeAheadField.nativeElement.selectionEnd;
    this.hasAccentedCharacters = false;

    if (!val || typeof val !== 'string') {
      return;
    }

    const currChar: string = val.charAt(currPos - 1);

    for (const char in AccentedLetters) {
      if (!Number(char) && char === currChar.toUpperCase()) {
        this.hasAccentedCharacters = true;
        this.accentedCharacter = char;
        break;
      } else {
        this.hasAccentedCharacters = false;
        this.accentedCharacter = null;
      }
    }

  }

  public clearTypeAheadValues(evt?: MouseEvent, clearnBtn?: HTMLElement): void {
    if (evt) {
      evt.preventDefault();
    }
    setTimeout(() => {
      this.clearTypeAheadField();
      this.typeAheadEventService.clearTypeAheadFields();
      this.typeAheadForm.get('typeAheadField').setValue(SpecialStrings.EMPTY);
    }, 1);
  }

  // add searched Name again.
  public addSameNameValues(): void {

    if (this.confirmDuplicateName) {
      this.confirmDuplicateNameEvent.emit();
    } else {
      //RC 1710 
      if (this.DuplicateAlert == true && this.typeAheadReturnData) {
        if (this.typeAheadReturnData.findIndex(x => x.typeAheadDisplayName.toLowerCase() == this.typeAheadField.nativeElement.value.toLowerCase()) != -1) {
          this.modalRef = this.TypeaheadmodalService.open(this.duplicateModal);
          this.TrapFocusDuplicateAlertModal();
          document.getElementById("c2c-delete-cofirmation-button-modal-ok").focus();
        } else {
          this.openAddAsNewModal();
        }
      } else {
        this.openAddAsNewModal();
      }
    }
  }

  public openAddAsNewModal(modalData?: any) {
    if (modalData) {
      this._typeAheadModalConfig = modalData.config;
      this._dataTypeResults = modalData.type;
    }
    if (this._typeAheadModalConfig && this._dataTypeResults === 'PERSON') {
      this._typeAheadModalConfig['modalOpen'] = true;
      this.typeAheadEventService.setModalConfig(this._typeAheadModalConfig);
    } else if (this._typeAheadModalConfig && this._dataTypeResults === 'COMPANY') {
      this._typeAheadModalConfig['modalOpen'] = true;
      this.typeAheadEventService.setModalCompanyConfig(this._typeAheadModalConfig);
    }
    this.openModal(this.typeAheadField.nativeElement.value);
  }



  public clearTypeAheadField(): void {
    this.typeaheadTitle = "";
    this.typeAheadField.nativeElement.value = SpecialStrings.EMPTY;
    this.setTypeAheadFocus();
    this.checkForAccentedLetters(SpecialStrings.EMPTY);
  }

  public openAccentedCharacterModal(): void {
    this.typeAheadEventService.openAccentedCharacterModal({
      item: this.accentedCharacter,
      modalName: this.accentedModalName,
      componentId: this.typeAheadId
    });
  }

  // replaces the last character of the typeAhead with an accented character, if applicaple
  private charToForeignChar(val: string): void {
    const currPos = this.typeAheadField.nativeElement.selectionStart;
    const typeAheadVal: string = this.typeAheadField.nativeElement.value;
    const updatedVal: string = typeAheadVal.substr(0, currPos - 1) + val + typeAheadVal.substr(currPos);
    this.typeAheadField.nativeElement.value = updatedVal;

    // emit service event that will be emited once user selets an accent char
    this.valueEvent.emit(updatedVal);

    this.setTypeAheadFocus();
    this.typeAheadField.nativeElement.setSelectionRange(currPos, currPos);

    this.nameSearch = Observable.of(updatedVal);
    this.duplicatedLocalSearchFlag = false;
  }

  // set metada to display in search result based on user role
  private displaySearchResultMetadata<T>(user: T): T {
    this.metaDataArray = [];

    this.displayDataResults.metaDataColumns['default'].forEach(element => {
      if (element === 'ssnEndChars') {
        this.checkNullEmptyMetaData(user[element], true);
      } else {
        this.checkNullEmptyMetaData(user[element], false);
      }

    });
    return this.createMetaData(user);
  }

  private createMetaData(user: any): any {
    return user['metaData'] = this.concatMetaDataResult();
  }

  private checkNullEmptyMetaData(value: string, ssn: boolean): void {
    let metaString: string;
    metaString = value ? `${value} ` : SpecialStrings.EMPTY;
    if (ssn && metaString) {
      metaString = formatSSN(metaString, true);
    }
    if (metaString) {
      metaString = ` | ${metaString}`;
    }
    if (metaString) {
      this.metaDataArray.push(metaString);
    }
  }

  private concatMetaDataResult(): string {
    let metaData: string = SpecialStrings.EMPTY;
    this.metaDataArray.forEach((value) => {
      metaData = `${metaData}${value}`;
    });
    return metaData;
  }

  public setTypeAheadFocus() {
    this.typeAheadField.nativeElement.focus();
  }

  private doesTypeAheadHaveValue(): boolean {
    const value: string = this.typeAheadField.nativeElement.value;
    const hasFocus = $(this.typeAheadField.nativeElement).is(':focus');
    return value.trim() !== SpecialStrings.EMPTY && hasFocus;
  }
  // TAL-2347
  private searchLocalDuplicated(dataToSearch: any): void {
    const namesList = [];
    let typeAheadNameEntered = [];
    let countNameData = 0;
    // Split name list, separating by comma and space
    this.dataResultNameSearch.forEach(ele => {
      namesList.push(ele.typeAheadDisplayName.trim().toUpperCase().split(/[\s,]+/));
    });
    // Spliting name entered to local search
    typeAheadNameEntered = (this.typeAheadField.nativeElement.value.trim().toUpperCase().split(/[\s,]+/));
    // Removing qoutes
    typeAheadNameEntered.forEach((ele, index) => {
      if (ele === '') {
        typeAheadNameEntered.splice(index, 1);
      }
    });

    countNameData = typeAheadNameEntered.length;

    // Searching for duplicated names
    for (let index = 0; index < namesList.length; index++) {
      let countDupData = 0;
      if (countNameData === namesList[index].length) {
        for (let indexI = 0; indexI < typeAheadNameEntered.length; indexI++) {
          if (namesList[index].includes(typeAheadNameEntered[indexI].toUpperCase())) {
            // Romivng name found
            const namePosDup = namesList[index].findIndex(name => name === typeAheadNameEntered[indexI].toUpperCase());
            namesList[index][namePosDup] = '';
            countDupData = countDupData + 1;
          }
        }
      }
      if (countNameData === countDupData) {
        this.duplicatedLocalSearchFlag = true;
        break;
      }
    }
    if (!this.duplicatedLocalSearchFlag) {
      this.openModal(this.typeAheadField.nativeElement.value);
    } else {
      console.log('Data duplicated', dataToSearch);
    }
  }

  public closeTypeAheadEvent(): void {
    this.closeTypeAhead.emit({ message: 'Hide TypeAhead' });
  }
  public duplicateClosed: boolean = false;

  /** Function when clicking the cancel/ok button in the duplicate confirmation modal. author rahul RC1710
  **/
  public close(evt?: any): void {
    if (evt == 'OK') {
      this.modalRef.close();
      setTimeout(() => {
        this.openModal(this.typeAheadField.nativeElement.value);
      }, 10)
    } else {
      this.modalRef.close();
      this.typeAheadHasValue = true;
      this.enableClearbtn = true;
      // this.duplicateClosed = true;
      setTimeout(() => {
        this.setTypeAheadFocus();
        if (typeof this.value == 'object' && this.temp_value) {
          this.typeAheadField.nativeElement.setSelectionRange(this.temp_value.typeAheadDisplayName.length, this.temp_value.typeAheadDisplayName.length);
        }
      }, 10)
    }
  };
  /** Function when when focusing the typeahead textbox. author rahul 
   **/
  onFocusTypeahead($event) {
    if (this.duplicateClosed == false) {
      this.typeAheadFocusSubject.next($event);
    } else {
      this.duplicateClosed = false;
      this.typeAheadFocusSubject.next(' ');
    }
  }

  /** Function when clicking close on duplicate confirmation popup the appending and emiting the selected value from suggestion. author rahul 
   **/
  TypeaheadWriteValue() {
    this.value = this.temp_value;

    // emit service event that will be listened by other components
    this.selectedTypeAheadRecord.emit(this.value);

    if (this.toggleSingleRecord) {
      this.typeAheadForm.get('typeAheadField').setValue(this.value);
      this.enableClearbtn = true;
      return;
    }
    try {
      if (!this.hasNoResultsCallback) {
        if (this.listName) {
          this.typeAheadEventService.listNameToLook(this.listName);
        }
      }
    } catch (err) {
      throw err;
    } finally {
      this.typeAheadForm.reset();
      this.clearTypeAheadField();
    }
  }

  /** Focus trap inside duplicate alert popup is the popup is available. author rahul 
   **/
  TrapFocusDuplicateAlertModal() {
    const allBackgroundElements = document.querySelectorAll('.container, [tabindex="0"]')
    const tickBtn = document.getElementById('c2c-delete-cofirmation-button-modal-ok')
    const closeBtn = document.getElementById('c2c-delete-confirmation-button-modal-cancel')
    //listen for keydown. Check for target of the event.
    document.addEventListener('keydown', (e) => {
      if (e.target === closeBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          tickBtn.focus()
        } else if (e.keyCode === 9) {
          e.preventDefault();
          tickBtn.focus()
        }
      } else if (e.target === tickBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          closeBtn.focus()
        }else if (e.keyCode === 9) {
          e.preventDefault();
          closeBtn.focus()
        }
      }
    })
  }

}
