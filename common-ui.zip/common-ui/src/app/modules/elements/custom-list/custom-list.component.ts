import { Component, OnInit, Input, EventEmitter, Output, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { CustomListEventService } from '../../../services/events/custom-list/custom-list.service';


import { removeWhitespace } from '../../../utils/strings/remove-whitespace';

@Component({
  selector: 'c2c-custom-list',
  templateUrl: './custom-list.component.html',
  styleUrls: ['./custom-list.component.scss'],
  providers: [CustomListEventService,
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CustomListComponent),
      multi: true
    }]
})
export class CustomListComponent implements OnInit, ControlValueAccessor {

  private _listNameId: string = '';
  private _itemSelected: any;
  private _listItems: Array<any> = [];
  public _value: any;

  @Input() public showRadioBnt: boolean = false;
  @Input() public disableButtons: boolean = false;
  @Input() public shoeEditBtn: boolean = false;
  @Input() public showDeleteBtn: boolean = false;
  @Input() public radioBtnOpt: object = {name: 'customList', id: 'radioBtnList'};
  @Input() public itemValue: string = '';
  @Input() public tooltipValue: string = '';
  @Input() public listType: string = 'vertical';

  @Input()
  set listItems(items: Array<any>) {
    this._listItems = items;
    this.value = items;
  }
  get listItems(): Array<any> { return this._listItems; }

  @Input()
  set listNameId(val: string) { this._listNameId = removeWhitespace(val); }
  get listNameId(): string { return this._listNameId; }

  @Output() deleteItemChanged: EventEmitter<any> = new EventEmitter<any>();
  @Output() selectItemChanged: EventEmitter<any> = new EventEmitter<any>();

  /** Getter for the value property */
  public get value(): any { return this._value; }
  /** Setter for the value property */
  public set value(val: any) {
      this._value = val;
      this.onChange(val);
      this.onTouched();
  }

  constructor() {  }

  ngOnInit() {
  }

  /** Fired when any changes to the model are detected */
  public onChange: any = (k) => {
  }

  /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
  public onTouched: any = () => { };
  public writeValue(obj: any): void {
    this.value = obj;
    }

  public registerOnChange(fn: any): void {
    this.onChange = fn;
    }
  public registerOnTouched(fn: any): void {
    this.onTouched = fn;
    }

  public selectItemList(itemIndex: number): void {

    this.listItems.forEach((element, i) => {
      if (i === itemIndex) {
          element.selectedItemInList = true;
          this._itemSelected = element;
      } else {
        element.selectedItemInList = false;
      }
    });
    this.selectItemChanged.emit({item: this._itemSelected, listName: this._listNameId, position: itemIndex});
  }

  public deleteItemList(itemIndex: any): void {
    this.deleteItemChanged.emit({item: itemIndex, listName: this._listNameId});
  }
}
