import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ButtonModule } from '../button/button.module';
import { FormModule } from '../../form/form.module';

import { CustomListComponent } from './custom-list.component';


@NgModule({
  imports: [
    CommonModule,
    ButtonModule,
    FormModule
  ],
  declarations: [CustomListComponent],
  exports: [CustomListComponent]
})
export class CustomListModule { }
