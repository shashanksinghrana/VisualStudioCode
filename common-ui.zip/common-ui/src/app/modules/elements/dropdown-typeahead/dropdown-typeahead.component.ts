import { Component, ViewChild, Input, EventEmitter, Output, forwardRef, ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map } from 'rxjs/operators';
import { merge } from 'rxjs/observable/merge';
import { DropdownTypeAheadModel } from '../../../models/dropdown-typeahead/dropdown-typeahead.model';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';
/**
 * @author Amit Yogi: Adding ControlValueAccessor to remove No value accesor for fomr Control with unspecified name attribue with three functions
 */
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

declare var $: any;

@Component({
    selector: 'c2c-dropdown-typeahead',
    templateUrl: './dropdown-typeahead.component.html',
    styleUrls: ['./dropdown-typeahead.component.css'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => DropdownTypeAheadComponent),
            multi: true
        }
    ]
})

export class DropdownTypeAheadComponent implements ControlValueAccessor, OnChanges {

    public dropDownTemp: any = [];
    public tooltip: string;
    public groupByCategory = "typeName";
    model = { id: null, value: null };
    focus$ = new Subject<string>();
    click$ = new Subject<string>();
    /**Background text to display in dropdown typeAhead input field */
    @Input() public placeholderText: string = "Select";
    @Input() public isGroupBy: any = false; // for grouping
    @Input() public focusFirst: any = false; // for highlighting first option
    /** Defines the data for the dropdown. If nothing passed in, the default is used. */
    // @Input() public dropdownOptions: DropdownTypeAheadModel = Defaults.DEFAULT_DROPDOWN_TYPEAHEAD_OPTIONS;
    

    public dropdownOptions: DropdownTypeAheadModel = Defaults.DEFAULT_DROPDOWN_TYPEAHEAD_OPTIONS;
    @ViewChild('selectr') public typeAheadField;
    @Input('dropdownOptions')
    set _dropdownOptions(dropdownOptions: DropdownTypeAheadModel) {
        if (dropdownOptions) {
            if (this.isGroupBy == true || this.isGroupBy == "true") {
                this.groupByCategory = "";
            }
            this.model = null;
            this.tooltip = '';
            this.dropDownTemp = dropdownOptions.options;
            if (dropdownOptions.title != null && dropdownOptions.title != "" && dropdownOptions.title != "Default Title") {
                this.tooltip = dropdownOptions.title;
            } else {
                this.tooltip = this.placeholderText;
            }
            if (dropdownOptions.selection === 'value' && dropdownOptions.dropdownValue != null) {
                if (dropdownOptions.dropdownValue.id != "") {
                    this.model = dropdownOptions.dropdownValue;
                    this.tooltip = dropdownOptions.dropdownValue.value;
                } else {
                    this.model = null;
                }

            }
            if (typeof dropdownOptions.dropdownValue !== 'string' && dropdownOptions.dropdownValue != null) {
                if (dropdownOptions.dropdownValue.id != "") {
                    this.model = dropdownOptions.dropdownValue;
                } else {
                    this.model = null;
                }
            } else {
                if (dropdownOptions.title !== '' && dropdownOptions.title != null) {
                } else {
                    this.model = null;
                }
            }
        } else {
        }
    }
    public closeDropdown  = false;
    @Input('closeDropdown')
    set _closeDropdown(closeDropdown) {
        if(closeDropdown){
            // console.log(this.typeAheadField);
            this.typeAheadField.isOpen = false;
            closeDropdown = false;
        }
    }

    /** Option to add custom option */
    @Input() public customOption: boolean = false;
    @Input() public addCustomText: string = "Add item"; // you can change the add tag label


    @Input() public dropdownPosition: string = "auto";
    @Input() public clearable: boolean = true;


    /** Defines the tabbing sequence setting. */
    @Input() public tabIndex;



    /** Defines the value of the dropdown to be passed to the reactive form. */
    @Input('selectedValue') public value: any;

    /** Event emitter for when a value is selected. Can be used to render something else in the UI. */
    @Output() public selectedEvent: EventEmitter<any> = new EventEmitter<any>();
    @Output() public valueEvent = new EventEmitter<string>();
    @Output() public changeValueEvent = new EventEmitter<string>();
    @Output() public keyPressEvent: EventEmitter<any> = new EventEmitter<any>();

    /** Fired when any changes to the model are detected */
    public onChange: any = () => { };

    /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
    public onTouched: any = () => { };

    /** Getter for the value property */
    // get value() {
    //     return this._value;
    // }

    // set value(val) {
    //     debugger;
    //     this._value = val;
    //     this.model = this._value;
    //     this.onChange(val);
    //     this.onTouched();
    //     if (val) { this.emitValue(val); }
    // }

    public emitValue(val?: any) {
        this.typeAheadField.nativeElement.value = val.value;
        this.valueEvent.emit(val);
    }

    /**
* If the value has changed, emit a event to communicate to the outside world.
*
* @param val The value to emit.
*/
    public click(params, i) {
        // do something with "key" and "value" variables
        // let paramKeyValue = this.dropdownOptions.options.find(x => x.value === params.item);
        this.onChange(params.item);
        this.selectedEvent.emit(params.item);
        this.tooltip = params.item.value;
    }
    /**
    *For handling null change for tooltip
    */
    public changeModel() {
        this.selectedEvent.emit(this.model);
        if (this.model) {
            this.tooltip = this.model.value;
        }

    }


    public writeValue() {
    }

    public registerOnChange() {

    }
    public registerOnTouched() {

    }
    // Required to update the model value
    ngOnChanges(changes: SimpleChanges) {
        if (changes.value && changes.value.currentValue !== changes.value.previousValue) {
            this.model = this.model !== changes.value.currentValue ? changes.value.currentValue : this.model;
            if (this.model) {
                this.tooltip = this.model.value; // tool tip text
            }

        }
    }

    public selectOnSearch(event) {
        let val = event.target.value;
        this.keyPressEvent.emit(event);
        if (val == "") {
            if (this.model != null) {
                val = this.model.value;
            }
        }
        this.changeValueEvent.emit(val);
    }
    public selectOnBlur() { }
    public selectOnClose() { }
    public selectOnClear() { }

    public selectOnScroll() { }
    public selectOnScrollToEnd() { }

    customSearchFn(term: string, item: any) {
        if (item && item.value) {
            const name = item && item.value.toLocaleLowerCase();
            const searchKey = term.toLocaleLowerCase();
            const a = new RegExp('^' + searchKey + '.*$');
            return name.match(a);
        } else {
            return false;
        }
    }
}
