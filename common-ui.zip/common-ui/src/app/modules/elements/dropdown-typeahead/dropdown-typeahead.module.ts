import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DropdownTypeAheadComponent } from './dropdown-typeahead.component';
import { FormModule } from '../../../modules/form/form.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
    imports: [
        CommonModule, 
        FormModule,
        NgSelectModule,
        CommonModule,
        FormsModule, 
        ReactiveFormsModule
    ],
    declarations: [DropdownTypeAheadComponent],
    exports: [DropdownTypeAheadComponent],

})

export class DropDownTypeAheadModule { }
