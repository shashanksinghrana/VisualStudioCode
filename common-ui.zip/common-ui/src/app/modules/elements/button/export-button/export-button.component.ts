import { Component, Input } from '@angular/core';
import { GridEventService } from '../../../../services/events/grid/grid-event.service';
import { Defaults } from '../../../../c2c-main/common-library-defaults.const';
import { DropdownModel } from '../../../../models/dropdown/dropdown.model';
/**
 * The RefreshButtonComponent
 *
 * Common component for displaying refresh buttons in the UI, which are meant to refresh a grid (or something else) to get latest data.
 */
@Component({
  selector: 'c2c-export-button',
  templateUrl: './export-button.component.html',
  styleUrls: ['./export-button.component.scss']
})
export class ExportButtonComponent {

  /**
   * Defines the data for the dropdown. If nothing passed in, the default is used.
   */
  @Input() public dropdownOptions: DropdownModel =  Defaults.DEFAULT_EXPORT_AS;
  /**
   * Constructor for the ExportButtonComponent
   *
   * @param gridEventService The service to handle all events related to the Grid.
   */
  constructor(private gridEventService: GridEventService) { 
    this.dropdownOptions.selection = '';
  }

  /**
   * Fires when an option is chosen. Action depends on data passed by implementing module.
   *
   *
   * @param choice The user's choice upon clicking an option.
   */
  public exportGrid(choice): void {
    if(choice){
      this.dropdownOptions.dropdownValue = choice;
      this.dropdownOptions.selection = choice.value;
	  this.gridEventService.exportGridEvent(choice.value);
    }
  }
}
