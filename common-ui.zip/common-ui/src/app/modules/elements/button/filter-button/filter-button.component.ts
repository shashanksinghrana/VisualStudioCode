import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'c2c-filter-button',
  templateUrl: './filter-button.component.html',
  styleUrls: ['./filter-button.component.scss']
})
export class FilterButtonComponent implements OnInit {

  @Input() public isFilterOn: boolean = true;

  /** Defines the tooltip text to display when the edit icon is hovered. */
  @Input() public tooltip: string = 'Toggle Filters';

  constructor() { }

  ngOnInit() {
  }

  public toggleFilter(): void {
    this.isFilterOn = !this.isFilterOn;
  }

}
