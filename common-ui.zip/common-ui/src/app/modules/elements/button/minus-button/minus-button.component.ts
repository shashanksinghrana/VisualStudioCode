import { Component, Input } from '@angular/core';
/**
 * The MinusButtonComponent
 *
 * Common component for displaying (-) buttons in the UI, which is meant for deleting or removing items.
 */
@Component({
  selector: 'c2c-minus-button',
  templateUrl: './minus-button.component.html',
  styleUrls: ['./minus-button.component.scss']
})
export class MinusButtonComponent {

  /** Defines the tabbing sequence setting. */
  @Input() public tabIndex;

  /** Defines the title for the minus button. */
  @Input() public title;

  /**
   * Constructor for the MinusButtonComponent
   */
  constructor() { }

}
