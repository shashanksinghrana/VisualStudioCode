import { Component, Input } from '@angular/core';
import { GridEventService } from '../../../../services/events/grid/grid-event.service';

/**
 * The RefreshButtonComponent
 *
 * Common component for displaying refresh buttons in the UI, which are meant to refresh a grid (or something else) to get latest data.
 */
@Component({
  selector: 'c2c-refresh-button',
  templateUrl: './refresh-button.component.html',
  styleUrls: ['./refresh-button.component.scss']
})
export class RefreshButtonComponent {

  @Input() public refreshButtonOptions: RefreshButtonComponent;

  /**
   * Constructor for the RefreshButtonComponent
   *
   * @param gridEventService The service to handle all events related to the Grid.
   */
  constructor(private gridEventService: GridEventService) { }

  /**
   * Calls the refreshGridEvent on the gridEventService to refresh the grid.
   */
  refreshGrid() {
    this.gridEventService.refreshGridEvent();
  }

}
