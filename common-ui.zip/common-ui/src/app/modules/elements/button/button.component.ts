import { Component, OnInit } from '@angular/core';
import { AddButtonModel } from '../../../models/button/add-button/add-button.model';

@Component({
  selector: 'c2c-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent implements OnInit {

  public addButtonOptions: AddButtonModel = new AddButtonModel('com', null, null, null, null, 'Add Button');

  constructor() { }

  ngOnInit() {
  }

}
