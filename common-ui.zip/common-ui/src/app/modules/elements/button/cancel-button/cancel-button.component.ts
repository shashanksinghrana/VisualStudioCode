import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { CancelButtonModel } from '../../../../models/button/cancel-button/cancel-button.model';
import { GridEventService } from '../../../../services/events/grid/grid-event.service';

/**
 * The CancelButtonComponent
 *
 * Common component for displaying (x) buttons in the UI, which is meant to run 1 of 3 actions.
 * Actions: cancel edits on grid, navigate to a different page (navigate), close modal window (modal).
 *  *
 * For an example of the CancelButtonComponent in use, see RTE modal on Notes.
 */
@Component({
  selector: 'c2c-cancel-button',
  templateUrl: './cancel-button.component.html',
  styleUrls: ['./cancel-button.component.scss']
})
export class CancelButtonComponent {

  /** Defines the options of the cancel Button. Used for configuring the type of action the button should do. */
  @Input() public cancelButtonOptions: CancelButtonModel;

  /** Outputs an event when the cancel button is clicked. Used to provide extra logic if needed. */
  @Output() addRow = new EventEmitter<string>();

  /** Defines the tabbing sequence setting. */
  @Input() public tabIndex;


  /**
   * Constructor for the CancelButtonComponent
   *
   * @param router The router to handle all navigation.
   * @param gridEventService The service to handle all events related to the Grid.
   */
  constructor(private router: Router, private gridEventService: GridEventService) { }

  /**
   * This is called when the button is clicked. It determines the necessary
   * action to perform based on the action set in 'cancelButtonModel'.
   */
  public performAction(): void {
    if (this.cancelButtonOptions && this.cancelButtonOptions.requiredAction) {
      switch (this.cancelButtonOptions.requiredAction) {
        case 'navigate':
          this.navigate(this.cancelButtonOptions.route);
          break;
        case 'modal':
          this.closeModal(this.cancelButtonOptions.modal);
          break;
        case 'row':
          this.gridEventService.refreshGridEvent();
          break;
      }
    }
  }

  public navigate(route: string): void {
    if (this.cancelButtonOptions.customNavigation) {
      this.cancelButtonOptions.customNavigation();
    }
    else {
      this.router.navigate([route]);
    }

  }

  // TODO: Implement opening specified modal window based on module and sourcePage using GridEventService.
  public closeModal(modal: object) {
  }
}
