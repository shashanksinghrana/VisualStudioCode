import { Component } from '@angular/core';

/**
 * The ResetButtonComponent
 *
 * Common component for displaying reset buttons in the UI, which are meant to resetting a form (or something else) to its original value.
 */
@Component({
  selector: 'c2c-reset-button',
  templateUrl: './reset-button.component.html',
  styleUrls: ['./reset-button.component.scss']
})
export class ResetButtonComponent {

  /**
   * Constructor for the ResetButtonComponent
   */
  constructor() { }

}
