import { Component, Input  } from '@angular/core';
import { Router } from '@angular/router';

/**
 * The BackButtonComponent
 *
 * Common component for displaying (<) buttons in the UI, which is meant to navigate back a page.
 */
@Component({
  selector: 'c2c-back-button',
  templateUrl: './back-button.component.html',
  styleUrls: ['./back-button.component.scss']
})
export class BackButtonComponent {

   /** Defines the route that the back button will navigate to. Used for setting the desired route. */
  @Input() private route: string;

  /**
   * Constructor for the BackButtonComponent
   *
   * @param router The router to handle all navigation.
   */
  constructor(private router: Router) { }

  /**
   * This is called when the back icon is clicked. Using the router, it navigates to the desired
   * page using the 'route' variables value.
   */
  public performAction(): void {
    if (this.route) {
      this.router.navigate([this.route]);
    }
  }

}
