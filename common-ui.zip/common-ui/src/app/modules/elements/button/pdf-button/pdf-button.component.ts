import { Component } from '@angular/core';

/**
 * The PdfButtonComponent
 *
 * Handles the PDF button.
 */
@Component({
  selector: 'c2c-pdf-button',
  templateUrl: './pdf-button.component.html',
  styleUrls: ['./pdf-button.component.scss']
})
export class PdfButtonComponent {

  /**
   * Constructor for the PdfButtonComponent
   */
  constructor() { }

}
