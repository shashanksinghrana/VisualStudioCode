import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

/**
 * The Continue Button Component
 *
 * Common component for displaying (>) buttons in the UI, which is meant to run navigate to next (and sometimes save).
 */
@Component({
  selector: 'c2c-continue-button',
  templateUrl: './continue-button.component.html',
  styleUrls: ['./continue-button.component.scss']
})
export class ContinueButtonComponent {

   /** Defines the route that the continue button will navigate to. Used for setting the desired route. */
  @Input() private route: string;

  /**
   * Constructor for the ContinueButtonComponent
   *
   * @param router The router to handle all navigation.
   */
  constructor(private router: Router) { }

  /**
   * This is called when the continue icon is clicked. Using the router, it navigates to the desired
   * page using the 'route' variables value.
   */
  public performAction() {
    if (this.route) {
      this.router.navigate([this.route]);
    }
  }

}
