import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImageUploaderComponent } from './imageUploader.component';
import { ModalModule } from '../../../modal/modal.module';
import { ImageCropperModule } from '../../../modules/elements/image-uploader/image-cropper/image-cropper.module';

@NgModule({
  imports: [
    ModalModule,
    CommonModule,
    ImageCropperModule
  ],
  declarations: [ImageUploaderComponent],
  exports: [ImageUploaderComponent],
  
})

export class ImageUploaderModule { }
