
import { Component, Input, Output, ElementRef, TemplateRef, ViewChild, EventEmitter, forwardRef } from '@angular/core';
import { ImageUploaderModel } from '../../../models/image-uploader/imageUploader.model';
import { Defaults } from '../../../c2c-main/common-library-defaults.const';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ImageUploaderService } from '../../../services/image-uploader/image.service';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

/**
 * The image uploader Component
 *
 * Common component for user to upload image with ability to crop and preview
 * which will be used in create/Edit actions.
 *
 * For an example of the Image uploader Component in use, see the common-ui Home page..
 */
@Component({
    selector: 'c2c-imageUploader',
    templateUrl: './imageUploader.component.html',
    styleUrls: ['./imageUploader.component.scss'],

    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => ImageUploaderComponent),
            multi: true
        }
    ]
})

export class ImageUploaderComponent implements ControlValueAccessor {

    private _imageUpload: ImageUploaderModel = Defaults.DEFAULT_IMAGEUPLOADER;
    /** Defines the values need for the image uploader.*/
    /** @Input imageUpload is for defining the image type eg:) people, company, poster (Default is people)*/
    /** @Output selectedImage emit the base64 format of the selected image -> You can send it to the server for saving the image*/
    @Input()
    set imageUpload(settings: ImageUploaderModel) {
        if (settings) {
            this._imageUpload = settings;
            this.settingImage();
        }
    }
    get imageUpload(): ImageUploaderModel { return this._imageUpload; }
    @Output() selectedImage = new EventEmitter<string>();
    @Input() overlay_text: string = 'Click to add image';
    title = 'app';
    imageChangedEvent: any = '';
    croppedImage: any = '';
    _profileImage: any = '';
    height: number;
    width: number;
    imageSize: number;
    imageType: string;
    filetype_status: any;
    imagevalidated_status: any;
    aspectRatioValue: any = 3 / 4;

    public isAspectRatioMaintained: boolean = true;
    // Below code is used to get the html template which have the id=content
    @ViewChild('content') private content: TemplateRef<any>;
    /** Defines the value of the Datepicker to be passed to the reactive form. */

    /** Fired when any changes to the model are detected */
    public onChange: any = () => { };

    /** Fired when the component is blurred. TODO: This currently doesn't work - need to figure out why and fix it */
    public onTouched: any = () => { };

    /** Getter for the value property */
    get profileImage() {
        return this._profileImage;
    }

    /** Setter for the value property */
    set profileImage(val) {
        this._profileImage = val;
        this.onChange(val);
        this.onTouched();
        // if (val) {
        //   this.selectedImage.emit(val);
        // }
    }

    constructor(private modalService: NgbModal,
        private ImageUploaderService: ImageUploaderService,
        private element: ElementRef) {

    }

    // content2 - For delete confirmation
    public openGenericImageModal(content2) {
        this.modalService.open(content2);
    }

    public modalClosedEvent(event) {
        if (event === 'OKAY') {
            this.perform_submit_croppedImage('delete_image'); // Trigger delete function
        }
    }

    public confirmDelete() {
        this.perform_submit_croppedImage('delete_image'); // Trigger delete function
    }

    public ngOnInit(): void {
        this.settingImage();
    }

    private settingImage(): void {
        if (this._imageUpload.imagePlaceholder === 'people') {
            this.profileImage = './assets/images/no-image.png';
            this.overlay_text = 'Click to add image';
            this.aspectRatioValue = 3 / 4; // for rectilinear cropper and image selection
        } else {
            this.profileImage = './assets/images/company_placeholder_new.png';
            this.isAspectRatioMaintained = false;
            this.aspectRatioValue = 4 / 4; // for square cropper and image selection
        }
        if (this._imageUpload.actualImageURL != null) {
            this.profileImage = this._imageUpload.actualImageURL;
            this.overlay_text = 'Click to replace image';
        }
    }

    fileChangeEvent(event: any): void {
        const filetype_status = this.ImageUploaderService.isValidImageType(event.target.files[0].type);
        this.filetype_status = filetype_status;
        if (filetype_status.status === false) {
            alert(filetype_status.msg);
        } else {
            this.imageSize = event.target.files[0].size;
            this.imageType = event.target.files[0].type;
            this.imageChangedEvent = event;
        }
        const target = event.target || event.srcElement;
        setTimeout(() => {
            target.value = '';
        }, 1000);
    }

    deleteImage(content2) {
        this.openGenericImageModal(content2);
    }

    imageCropped(image: string) {
        this.croppedImage = image;
    }

    imageLoaded() {
        // show cropper
    }

    loadImageFailed() {
        // show message
    }

    // popup modal open functionality - For cropping
    openpopup(content) {
        this.modalService.open(content, { centered: true });
    }

    perform_submit_croppedImage(value?: any) {
        if (value === 'delete_image') {
            if (this._imageUpload.imagePlaceholder === 'people') {
                this.profileImage = './assets/images/no-image.png';
            } else {
                this.profileImage = null;
                this.profileImage = './assets/images/company_placeholder_new.png';
            }
            this.croppedImage = null;
            this.selectedImage.emit(this.croppedImage);
            this.overlay_text = 'Click to add image';
        } else {
            // Cropping
            this.profileImage = this.croppedImage;
            this.selectedImage.emit(this.croppedImage);
            this.overlay_text = 'Click to replace image';
        }
    }

    onImageLoad(event) {
        const path = event.path || (event.composedPath && event.composedPath());
        if (!path || !event.path) { // Firefox browser fix
            event = event || window.event;
            this.imagevalidated_status = this.ImageUploaderService.validate(this.imageSize, event.srcElement.height, event.srcElement.width);
            if (this.imagevalidated_status.status === false) {
                alert(this.imagevalidated_status.msg);
            }
            if (((event.target.src.substr(0, 14) === 'data:image/png') || (event.target.src.substr(0, 14) === 'data:image/jpg') || (event.target.src.substr(0, 15) === 'data:image/jpeg')) && this.imagevalidated_status.status === true) {
                this.openpopup(this.content);
            }

        } else { // Other browser
            if (this.filetype_status.status === true) {
                this.height = event.path[0].height;
                this.width = event.path[0].width;
                this.imagevalidated_status = this.ImageUploaderService.validate(this.imageSize, this.height, this.width);
                if (this.imagevalidated_status.status === true) {
                    this.openpopup(this.content);
                } else {
                    alert(this.imagevalidated_status.msg);
                }
            }
        }
    }

    changeListner(event) {
        const reader = new FileReader();
        const image = this.element.nativeElement.querySelector('.image');
        reader.onload = function (e: any) {
            const src = e.target.result;
            image.src = src;
        };
        reader.readAsDataURL(event.target.files[0]);
        this.fileChangeEvent(event);
    }

    /**
  * Implementation of the writeValue function given through the ControlValueAccessor class.
  * Writes the dropdown value to the element.
  *
  * @param value The value to write.
  */
    writeValue(value: any) {
        if (value !== null) {
            this._imageUpload = value;

        }
    }

    /**
   * Implementation of the registerOnChange function given through the ControlValueAccessor class.
   * Registers the onChange callback to this.onChange().
   *
   * @param fn The callback function.
   */
    registerOnChange(fn) {
        this.onChange = fn;
    }

    /**
     * Implementation of the registerOnTouched function given through the ControlValueAccessor class.
     * Registers the onTouched callback to this.onTouched().
     *
     * @param fn The callback function.
     */
    registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }
}
