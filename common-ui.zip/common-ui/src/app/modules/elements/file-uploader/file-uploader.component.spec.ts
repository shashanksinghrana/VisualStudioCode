import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalStack } from '@ng-bootstrap/ng-bootstrap/modal/modal-stack';
import { RouterTestingModule } from '@angular/router/testing';
import { FileUploaderComponent } from './file-uploader.component';

describe('FileUploaderComponent', () => {
  let component: FileUploaderComponent;
  let fixture: ComponentFixture<FileUploaderComponent>;

  beforeEach(async(() => {
    // const spy = jasmine.createSpyObj('GridApi', ['onRowHeightChanged']);

    TestBed.configureTestingModule({
      declarations: [
       FileUploaderComponent
      ],
      imports: [
        CommonModule,
        FormsModule,
        FileUploaderComponent,
        RouterTestingModule
      ],
      providers: [
        NgbModal,
        NgbModalStack
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileUploaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   fixture.detectChanges();
  //   expect(component).toBeTruthy();
  // });

  // it('grid API is not available', () => {
  //   expect(component.gridApi).not.toBeTruthy();
  // });

  // it('grid API is available on `detectChanges`', () => {
  //   fixture.detectChanges();
  //   expect(component.gridApi).toBeTruthy();
  // });

  // it('should return default height', () => {
  //   const height = component.calcHeight(expandEvent, expandEventData);
  //   expect(height).toEqual(70);
  // });

  // it('should return expanded height', () => {
  //   expandEvent.state = false;
  //   const height = component.calcHeight(expandEvent, expandEventData);
  //   expect(height).toEqual(130);
  // });

  // it('should return image height', () => {
  //   expandEvent.image = true;
  //   expandEvent.state = true;
  //   const height = component.calcHeight(expandEvent, expandEventData);
  //   expect(height).toEqual(110);
  // });

  // it('should set the row height', () => {
  //   // let currentRow = new RowNode();
  //   // currentRow.setRowHeight(70);
  //   fixture.detectChanges();
  //   component.setRowHeight(expandEvent);
  //   expect(gridApiSpy.onRowHeightChanged.calls.count())
  //     .toBe(1, 'spy method was called once');
  // });
});
