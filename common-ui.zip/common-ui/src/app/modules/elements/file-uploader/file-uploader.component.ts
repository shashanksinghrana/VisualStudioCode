
import { Component, Output, EventEmitter, ViewContainerRef, forwardRef, ViewChild, ElementRef } from '@angular/core';
import { FileUploaderService } from '../../../services/file-uploader/file-uploader.service';
import { ToasterService } from '../../../services/toaster/toaster.service';
import { ToastsManager } from 'ng2-toastr';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

/**
 * The file uploader Component
 *
 * Common component for user to upload file
 *
 * For an example of the File uploader Component in use, see the common-ui Home page..
 */
@Component({
    selector: 'c2c-file-uploader',
    templateUrl: './file-uploader.component.html',
    styleUrls: ['./file-uploader.component.scss'],
    providers: [
      {
          provide: NG_VALUE_ACCESSOR,
          useExisting: forwardRef(() => FileUploaderComponent),
          multi: true
      }
  ]
})

export class FileUploaderComponent {
  public showLabel: boolean = false;
  public fileToUpload: File = null;

  @Output() uploadFileEvent: EventEmitter<object> = new EventEmitter<object>();
  @ViewChild('fileupload') public fileupload: ElementRef;

    constructor(private fileUploaderService: FileUploaderService,
                private toasterService: ToasterService,
                private toastr: ToastsManager,
                private vRef: ViewContainerRef) {
      this.toastr.setRootViewContainerRef(vRef);
    }

    triggerClick(event): void {
      const el: HTMLElement = this.fileupload.nativeElement as HTMLElement;
      el.click();
    }

    handleFileInput(event) {
      let files : FileList = event.target.files;
      if(this.validatedUploadedFile(files.item(0))){
        this.fileToUpload = files.item(0);//if multiple iterate over the items
        let self = this;
        this.convertToBase64(this.fileToUpload).then(function(result: any) {
          let convertedFileToUpload: any = {'name': '', 'data': ''};
          convertedFileToUpload['name'] = self.fileToUpload.name;
          convertedFileToUpload['data'] = result.split(',')[1];
          self.uploadFileEvent.emit(convertedFileToUpload);
        });
      }
    }

    convertToBase64(file){
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
      });
    }

    validatedUploadedFile(file){
      let fileSize = this.fileUploaderService.validate(file);
      let fileType = this.fileUploaderService.isValidFileType(file.name.split('.')[1]);
      if(!fileSize.status){
        this.toasterService.error(fileSize.msg, 'Error');
        return false;
      }

      if(!fileType.status){
        this.toasterService.error(fileType.msg, 'Error');
        return false;
      }
      return true;
    }
}
