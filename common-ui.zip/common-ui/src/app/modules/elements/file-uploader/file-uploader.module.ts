import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileUploaderComponent } from './file-uploader.component';
import { ModalModule } from '../../../modal/modal.module';

/**
 * The FileUploaderModule
 *
 * Module that contains all File Upload related components.
 */
@NgModule({
  imports: [
    ModalModule,
    CommonModule
  ],
  declarations: [FileUploaderComponent],
  exports: [FileUploaderComponent],
  
})
export class FileUploaderModule { }
