import { Component, Input, OnDestroy, EventEmitter, Output, TemplateRef, ViewChild, ContentChildren, QueryList } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs/Subscription';
import { ApplicableNotApplicableService } from '../../services/events/modal/modal-applicable-notapplicable.service';
import { RadioButtonModel } from '../../models/radio-button/radio-button.model';
import { Defaults } from '../../c2c-main/common-library-defaults.const';

@Component({
    selector: 'c2c-modal-applicable-notapplicable',
    templateUrl: './modal-applicable-notapplicable.component.html',
    styleUrls: ['./modal-applicable-notapplicable.component.scss']
})
export class ModalApplicableNotApplicableComponent implements OnDestroy {

    /** Defines the event passed to emit function. Event is which button in modal was clicked. */
    public event: string;
    public inputRequired: boolean = true;
    /** Defines Option for modal window */
    private modalOptions: NgbModalOptions = {
        backdrop: 'static',
        keyboard: false,
        size: 'lg'
    };

    /** Defines each 'choice' in the 'Narrow Your Choices' section based on an array of  */
    @Input() public applicableRadioOptions: RadioButtonModel = Defaults.APPLICABLE_NOT_APPLICABLE_RADIO_OPTIONS;

    /** Defines tab index **/
    @Input() public tabIndex;

    /** Defines value for Delete Icon to display for testing purspective only **/
    @Input() public displayDeleteIcon: boolean = true;

    /* Defines Disable OK button state*/
    @Input() public disableBtn: boolean;

    /** Outputs an event when the any radio button is clicked.*/
    @Output() applicableConfVal = new EventEmitter<any>();
    
    /** Outputs an event when the OK button is clicked. Used to provide extra logic if needed. */
    @Output() applicableModalClosedEvent = new EventEmitter<any>();


    private openModalSubscription: Subscription;
    private closeModalSubscription: Subscription;
    public modal: NgbModalRef;

    /** The content of the modal to be displayed when opened. */
    @ViewChild('applicableNotApplicableModal') applicableNotApplicableModal: TemplateRef<any>;
    @ContentChildren(ModalApplicableNotApplicableComponent) genericModalChildren: QueryList<ModalApplicableNotApplicableComponent>;

    constructor(private modalService: NgbModal, private applicableService: ApplicableNotApplicableService) {
        this.openModalSubscription = this.applicableService.onOpenModal()
            .subscribe(value => {
                this.modal = this.modalService.open(this.applicableNotApplicableModal, this.modalOptions);
            });
        this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
        this.closeModalSubscription = this.applicableService.onCloseModal()
            .subscribe(value => {
                this.modal.close();
            });
    }

    ngOnInit() {
        this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
    }

    /** Function to Open modal. **/
    public openModal() {
        this.applicableService.openModal();
    }

    /** Function to Close modal. **/
    public close(evt?: Event): void {
        this.modal.close();
        this.applicableModalClosedEvent.emit(evt);
        this.inputRequired = true;
        this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
    };

    /**
    * Emits the event when any radio option is checked.
    *
    * @param event checked radio option event is emitted.
    */
    emitEvent(event) {
      if (!this.inputRequired && event) {
          this.modal.close();
          this.applicableModalClosedEvent.emit(event);
          this.inputRequired = true;
          this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
      }
    }

    public onRadioChange(event) {
        if (this.inputRequired && event) {
            this.inputRequired = false;
            this.applicableConfVal.emit(event);
            this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
        }
        else {
            this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
        }
    }

    ngOnDestroy() {
        this.applicableConfVal.unsubscribe();
        this.applicableModalClosedEvent.unsubscribe();
        this.openModalSubscription.unsubscribe();
        this.closeModalSubscription.unsubscribe();
    }
}