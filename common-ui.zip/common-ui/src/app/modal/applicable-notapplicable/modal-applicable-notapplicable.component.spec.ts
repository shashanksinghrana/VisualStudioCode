import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalApplicableNotApplicableComponent } from './modal-applicable-notapplicable.component';

describe('ModalApplicableNotApplicableComponent', () => {
  let component: ModalApplicableNotApplicableComponent;
  let fixture: ComponentFixture<ModalApplicableNotApplicableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalApplicableNotApplicableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalApplicableNotApplicableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
