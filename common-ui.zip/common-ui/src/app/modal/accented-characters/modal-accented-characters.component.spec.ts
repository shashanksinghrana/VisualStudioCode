import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalAccentedCharactersComponent } from './modal-accented-characters.component';
import { AutofocusDirective } from '../../directives/focus/auto-focus.directive';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalStack } from '@ng-bootstrap/ng-bootstrap/modal/modal-stack';
import { TypeAheadEventService } from '../../services/events/type-ahead/type-ahead-event.service';
import { AccentedCharacterService } from '../../services/non-http-data/accented-character.service';
import { Renderer2 } from '@angular/core';

describe('ModalAccentedCharactersComponent', () => {
  let component: ModalAccentedCharactersComponent;
  let fixture: ComponentFixture<ModalAccentedCharactersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[NgbModule],
      declarations: [ ModalAccentedCharactersComponent,AutofocusDirective ],
      providers:[NgbModalStack,TypeAheadEventService,AccentedCharacterService,Renderer2]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalAccentedCharactersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it(`should create`, async(inject([NgbModal,TypeAheadEventService,AccentedCharacterService,Renderer2],
  //   ( modalService              : NgbModal,
  //     typeAheadEventService     : TypeAheadEventService,
  //     accentedCharacterService  : AccentedCharacterService,
  //     renderer                  : Renderer2) => {
  //     expect(component).toBeTruthy();
  // })));
});
