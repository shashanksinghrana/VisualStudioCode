import { Component, ViewChild, TemplateRef, Renderer2, OnDestroy, ElementRef, Input, EventEmitter, Output } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs/Subscription';
import { AccentedCharacterService } from '../../services/http/accented-character/accented-character.service';
import { TypeAheadEventService } from '../../services/events/type-ahead/type-ahead-event.service';
import { AccentedCharsModel } from '../../models/accented-chars/accented-chars.model';

@Component({
  selector: 'c2c-modal-accented-characters',
  templateUrl: './modal-accented-characters.component.html',
  styleUrls: ['./modal-accented-characters.component.scss'],
  providers: [AccentedCharacterService]
})
export class ModalAccentedCharactersComponent implements OnDestroy {

  @ViewChild('modal') genericModal: TemplateRef<any>;
  @ViewChild('focusTest') focusTest: ElementRef;
  public isFirst: ElementRef;

  public accentedCharacters: AccentedCharsModel[];
  private bsModal: NgbModalRef;
  private modalOpen: boolean;
  private subscription: Subscription;
  private emmitterComponent: any;
  @Input() callAccentedApi: boolean = false;
  @Output() accentedService = new EventEmitter<any>();

  @Input() modalName: string = '';
  private _accentedChars: AccentedCharsModel[] = [];
  @Input()
  set accentedCharsValues(vals: AccentedCharsModel[]) {
    this._accentedChars = vals;
    if (this.callAccentedApi && (vals && vals.length)) {
      this.openAccentedModal(this._accentedChars);
    }
  }
  get accentedCharsValues(): AccentedCharsModel[] { return this._accentedChars; }

  constructor(private modalService: NgbModal,
              private typeAheadEventService: TypeAheadEventService,
              private accentedCharacterService: AccentedCharacterService,
              private renderer: Renderer2) {

    this.subscription = this.typeAheadEventService.getAccentedCharacters()
      .subscribe(response => {
        if (response.modalName === this.modalName) {
          this.openModal(response.item);
          this.emmitterComponent = response.componentId;
        }
      });
   }

  public close(): void {
    this.modalOpen = false;
    this.bsModal.close();
  }

  public selectedCharacter(evt: MouseEvent): void {

    const btn: HTMLElement = evt.currentTarget as HTMLElement;
    const char: string = btn.innerText;

    this.typeAheadEventService.replaceWithAccentedCharacter({
      item: char.trim(),
      modalName: this.modalName,
      componentId: this.emmitterComponent});
    this.close();
  }

  private openModal(accentedCharacterToSearch: string): void {
    if (this.callAccentedApi) {
      this.accentedService.emit(accentedCharacterToSearch);
    } else {
      this.accentedCharacterService.getAccentedChars(accentedCharacterToSearch).subscribe(
        (res) => {
          this.openAccentedModal(res);
        }
      );
    }
  }

  public openAccentedModal(chars: AccentedCharsModel[]): void {
    this.accentedCharacters = chars;
    setTimeout(() => {
      this.open(this.genericModal);
      this.modalOpen = true;
    }, 100);
  }

  private open(modal: TemplateRef<any>): void {

    if (this.modalOpen) {
      return;
    }
    this.bsModal = this.modalService.open(modal, {
      backdrop: 'static',
      windowClass: 'modal-position',
      keyboard: false
      });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
