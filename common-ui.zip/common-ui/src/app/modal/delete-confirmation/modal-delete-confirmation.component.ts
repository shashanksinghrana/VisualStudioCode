import { Component, Input, OnDestroy, EventEmitter, Output, TemplateRef, ViewChild, AfterContentInit, ContentChildren, QueryList, Renderer2, HostListener } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs/Subscription';
import { DeleteConfirmationService } from '../../services/events/modal/delete-confirmation.service';

@Component({
  selector: 'c2c-modal-delete-confirmation',
  templateUrl: './modal-delete-confirmation.component.html',
  styleUrls: ['./modal-delete-confirmation.component.scss']
})
export class ModalDeleteConfirmationComponent implements OnDestroy {

  /** Defines the event passed to emit function. Event is which button in modal was clicked. */
  public event: string;

  /** Defines Option for modal window */
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg'
  };

  /** Defines value for Input field as required **/
  @Input() public inputRequired: boolean = true;

  /** Defines tab index **/
  @Input() public tabIndex;

  /** Defines value for Delete Icon to display for testing purspective only **/
  @Input() public displayDeleteIcon: boolean = true;

  /** Defines Input field value **/
  inputVal: any;

  /* Defines Disable OK button state*/
  @Input() public disableBtn: boolean;

  /** Outputs an event when the OK button is clicked. Used to provide extra logic if needed. */
  @Output() deleteConfVal = new EventEmitter<any>();

  private openModalSubscription: Subscription;
  private openModalSubscription_small: Subscription;
  private closeModalSubscription: Subscription;
  public modal: NgbModalRef;


  /** The content of the modal to be displayed when opened. */
  @ViewChild('deleteModalContent') deleteModalContent: TemplateRef<any>;
  @ContentChildren(ModalDeleteConfirmationComponent) genericModalChildren: QueryList<ModalDeleteConfirmationComponent>;

  constructor(private modalService: NgbModal, private deleteConfService: DeleteConfirmationService, private renderer: Renderer2) {
    this.openModalSubscription = this.deleteConfService.onOpenModal()
      .subscribe(value => {
        this.modal = this.modalService.open(this.deleteModalContent, this.modalOptions);

        setTimeout(() => {
          let inputElement = this.renderer.selectRootElement('#delete-confirmation-input');
          inputElement.focus();
        }, 100);
      });

    this.openModalSubscription_small = this.deleteConfService.onOpenModal_small()
      .subscribe(value => {
        this.modal = this.modalService.open(this.deleteModalContent);
      });

    this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
    this.closeModalSubscription = this.deleteConfService.onCloseModal()
      .subscribe(value => {
        this.modal.close();
      });
  }

  public enterClicked(evt, event) {
    this.emitEvent(event);
    this.modal.close();
    evt.stopPropagation();
  }

  ngOnInit() {
    this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
  }

  /** Function to Opens modal. **/
  public openModal() {
    this.deleteConfService.openModal();
    this.inputVal = '';
  }

  /** Function to Close modal. **/
  public close(evt?: any): void {
    this.deleteConfVal.emit(evt);
    this.modal.close();
    this.inputVal = '';
  };

  /**
  * Emits the event when the ok button is clicked.
  *
  * @param event The event being emitted ('OK').
  */
  emitEvent(event) {
    this.event = event;
    if (this.inputRequired && this.inputVal && this.inputVal.toLowerCase() === 'yes') {
      this.deleteConfVal.emit({ value: this.inputVal, action: event });
      this.modal.close();
      this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
      this.inputVal = '';
    } else if (!this.inputRequired) {
      this.deleteConfVal.emit({ value: this.inputVal, action: event });
      this.modal.close();
      this.inputVal = '';
    } else {
      this.inputRequired ? this.disableBtn = true : this.disableBtn = false;
    }
  }

  checkInput() {
    if (this.inputVal) {
      if (this.inputRequired && this.inputVal.toLowerCase() === 'yes') {
        this.disableBtn = false;
      } else if (!this.inputRequired) {
        this.disableBtn = false;
      } else {
        this.disableBtn = true;
      }
    }
  }

  ngOnDestroy() {
    this.deleteConfVal.unsubscribe();
    this.openModalSubscription.unsubscribe();
    this.openModalSubscription_small.unsubscribe();
    this.closeModalSubscription.unsubscribe();
  }
}
