import { Component, Input, Output, ViewChild, OnDestroy, Renderer2, EventEmitter } from '@angular/core';
import { NgbModal, NgbActiveModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs/Subscription';
import { UnsavedChangesService } from '../../services/events/modal/unsaved-changes-event/unsaved-changes.service';

/**
 * The Unsaved Changes Component
 *
 * Handles the "unsaved changes" modal that will appear when a user navigates away from the current page without saving
 */
@Component({
  selector: 'c2c-modal-unsaved-changes',
  templateUrl: './modal-unsaved-changes.component.html',
  styleUrls: ['./modal-unsaved-changes.component.scss']
})
export class ModalUnsavedChangesComponent implements OnDestroy {

  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    windowClass: 'modal-unsaved'
  };
  private subscriptions: Subscription = new Subscription();
  public modal: NgbModalRef;
  public activeModal: NgbActiveModal

  /** Sets the value to be used to either display a button to activate modal or not. */
  @Input() public showBtn: boolean = true;
  @Input() public customClass: any = "";

  @Output() public unsavedModalClosedEvent: EventEmitter<any> = new EventEmitter<any>();

  /** The content of the modal to be displayed when opened. */
  @ViewChild('content') private content: any;

  /**
   * Constructor for the unsaved changes component
   *
   * Defines the frameworkComponents (custom cell renderers) used in the Grid.
   * Subscribes to any events happening within the Grid.
   *
   * @param modalService The Bootstrap NGB Modal service.
   */
  constructor(private modalService: NgbModal, private unsavedChangesService: UnsavedChangesService, private renderer: Renderer2, ) {
    this.subscriptions.add(
      this.unsavedChangesService.onOpenModal()
        .subscribe(value => {
          this.renderer.addClass(document.body, 'modal-unsaved');
          this.modal = this.modalService.open(this.content, this.modalOptions);
          this.TrapFocusUnsavedAlertModal();
        })
    );
    this.subscriptions.add(
      this.unsavedChangesService.onCloseModal()
        .subscribe(value => {
          this.renderer.removeClass(document.body, 'modal-unsaved');
          this.modal.close();
        })
    );
  }

  /**
   * Opens modal.
   */
  openModal() {
    this.unsavedChangesService.openModal();
  }

  /**
   * Fires when a user clicks either the check mark or X icon in the modal.
   * @param value Value of button clicked. Check Mark passes true (confirm) and X
   * pass false (cancel).
   */
  close(value: boolean) {
    this.unsavedModalClosedEvent.emit(value);
    this.unsavedChangesService.closeModal(value);
    const modal = document.querySelector('ngb-modal-window');
    modal && modal.parentNode.removeChild(modal);
    const modalBackground = document.querySelector('ngb-modal-backdrop');
    modalBackground && modalBackground.parentNode.removeChild(modalBackground);
    // this.dismissModal(value);
  }

  dismissModal(val) {
    // if (val === false) {
    this.activeModal.dismiss(val);
    // }
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(document.body, 'modal-unsaved');
    this.subscriptions.unsubscribe();
  }

  /** Focus trap inside duplicate alert popup is the popup is available. 
**/
  TrapFocusUnsavedAlertModal() {
    const allBackgroundElements = document.querySelectorAll('.container, [tabindex="0"]')
    const tickBtn = document.getElementById('c2c-unsaved-changes-button-modal-ok')
    const closeBtn = document.getElementById('c2c-unsaved-changes-button-modal-cancel')
    //listen for keydown. Check for target of the event.
    document.addEventListener('keydown', (e) => {
      if (e.target === closeBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          tickBtn.focus()
        } else if (e.keyCode === 9) {
          e.preventDefault();
          tickBtn.focus()
        }
      } else if (e.target === tickBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          closeBtn.focus()
        } else if (e.keyCode === 9) {
          e.preventDefault();
          closeBtn.focus()
        }
      }
    })
  }


}
