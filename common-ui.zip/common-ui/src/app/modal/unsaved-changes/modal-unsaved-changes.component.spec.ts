import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalUnsavedChangesComponent } from './modal-unsaved-changes.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalStack } from '@ng-bootstrap/ng-bootstrap/modal/modal-stack';

describe('ModalUnsavedChangesComponent', () => {
  let component: ModalUnsavedChangesComponent;
  let fixture: ComponentFixture<ModalUnsavedChangesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalUnsavedChangesComponent ],
      providers: [NgbModal, NgbModalStack]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalUnsavedChangesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
