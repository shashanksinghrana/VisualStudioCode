import {
  Component, OnDestroy, TemplateRef, ViewChild, ViewEncapsulation,
  Input, ContentChildren, QueryList, Output, EventEmitter
} from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs/Subscription';
import { ModalEventService } from '../../services/events/modal/modal-event.service';
import { TypeAheadEventService } from '../../services/events/type-ahead/type-ahead-event.service';
import { TypeAheadModel } from '../../models/type-ahead/type-ahead.model';

@Component({
  selector: 'c2c-modal-generic',
  templateUrl: './modal-generic.component.html',
  styleUrls: ['./modal-generic.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class ModalGenericComponent implements OnDestroy {

  private _showHeader: boolean = false;
  private _showFooter: boolean = false;
  private _showYesButton: boolean = false;
  private _showCancelButton: boolean = false;
  private _showOkButton: boolean = false;
  @Input() public title: string;
  @Input() public size: string = 'lg';
  @Input() public showCheckIcon = true;

  @Input('openModal')
  set openModal(val: boolean) {
    if (val === undefined) { return; }

    if (val) { this.open(); }
    else { this.close(); }
  }

  @Input('showHeader')
  set showHeader(val: boolean) {
    if (val === undefined) {
      return;
    }

    // Input returns a typeof string, so convert
    this._showHeader = new Boolean(val).valueOf();
  }

  get showHeader(): boolean {
    return this._showHeader;
  }

  @Input('showFooter')
  set showFooter(val: boolean) {
    if (val === undefined) {
      return;
    }

    // Input returns a typeof string, so convert
    this._showFooter = new Boolean(val).valueOf();
  }

  get showFooter(): boolean {
    return this._showFooter;
  }

  @Input('showCancelButton')
  set showCancelButton(val: boolean) {
    if (val === undefined) {
      return;
    }

    // Input returns a typeof string, so convert
    this._showCancelButton = new Boolean(val).valueOf();
  }

  get showCancelButton(): boolean {
    return this._showCancelButton;
  }



  @Input('showOkButton')
  set showOkButton(val: boolean) {
    if (val === undefined) {
      return;
    }

    // Input returns a typeof string, so convert
    this._showOkButton = new Boolean(val).valueOf();
  }

  get showOkButton(): boolean {
    return this._showOkButton;
  }


  @Output() public modalClosedEvent: EventEmitter<any> = new EventEmitter<any>();

  @Input()
  set showYesButton(val: boolean) {
    if (val === undefined) {
      return;
    }
    this._showYesButton = val;
  }
  get showYesButton(): boolean {
    return this._showYesButton;
  }

  @ViewChild('modalContent') modalContent: TemplateRef<any>;
  @ContentChildren(ModalGenericComponent) genericModalChildren: QueryList<ModalGenericComponent>;

  private bsModal: NgbModalRef;
  public formData: TypeAheadModel;
  private modalClose: Subscription;
  // private modalOpen: Subscription;

  constructor(
    private modalService: NgbModal,
    private modalEventService: ModalEventService,
    private typeAheadEventService: TypeAheadEventService
  ) {
    // this.modalClose = this.modalEventService
    //   .onCloseModal()
    //   .subscribe(item => {
    //     this.close(item)
    //   });


    // this.modalOpen = this.typeAheadEventService.getTypeAheadNoResults()
    //   .subscribe((item) => {
    //     this.open()
    //   });
  }

  public ngOnDestroy(): void {
    // this.modalOpen.unsubscribe();
    // this.modalClose.unsubscribe();
  }


  public close(evt?: any): void {
    if (this.bsModal) {
      this.bsModal.close();
      this.modalClosedEvent.emit(evt);
    }
  }

  public open(): void {
    this.bsModal = this.modalService.open(this.modalContent, this.setPopupOpts());
  }

  public processLogout() {
    sessionStorage.removeItem('NAV_BAR_HISTORY');
    this.bsModal.close();
    window.location.href = './saml/logout';
  }

  private setPopupOpts(): object {
    return {
      backdrop: 'static',
      size: this.size,
      windowClass: 'modal-position',
      keyboard: false
    };
  }

  public onTab(evt) {
    if (evt.which == 9) {
      let element = document.getElementById('c2cCheckIcon');
      let span = <HTMLElement>element;
      setTimeout(() => span.focus());
    }
  }
}
