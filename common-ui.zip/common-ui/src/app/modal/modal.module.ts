import { NgModule, ModuleWithProviders } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgbModalStack } from '@ng-bootstrap/ng-bootstrap/modal/modal-stack';
import { ModalEventService } from '../services/events/modal/modal-event.service';
import { ModalUnsavedChangesComponent } from './unsaved-changes/modal-unsaved-changes.component';
import { TypeAheadEventService } from '../services/events/type-ahead/type-ahead-event.service';
import { CommonSharedModule } from '../modules/common-shared/common-shared.module';
import { SaveSearchService } from '../services/events/modal/modal-save-search.service';
import { UnsavedChangesService } from '../services/events/modal/unsaved-changes-event/unsaved-changes.service';
import { DeleteConfirmationService } from '../services/events/modal/delete-confirmation.service';
import { ApplicableNotApplicableService } from '../services/events/modal/modal-applicable-notapplicable.service';
import { ModalGenericComponent } from './generic/modal-generic.component';
import { ModalSaveSearchComponent } from './save-search/modal-save-search.component';
import { ModalDeleteConfirmationComponent } from './delete-confirmation/modal-delete-confirmation.component';
import { ModalAccentedCharactersComponent } from './accented-characters/modal-accented-characters.component';
import { ModalApplicableNotApplicableComponent } from './applicable-notapplicable/modal-applicable-notapplicable.component'
import { FormModule } from '../modules/form/form.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FormModule,
    CommonSharedModule.forRoot()
  ],
  declarations: [
    ModalGenericComponent,
    ModalSaveSearchComponent,
    ModalAccentedCharactersComponent,
    ModalUnsavedChangesComponent,
    ModalDeleteConfirmationComponent,
    ModalApplicableNotApplicableComponent
  ],
  exports: [
    ModalGenericComponent,
    ModalSaveSearchComponent,
    ModalAccentedCharactersComponent,
    ModalUnsavedChangesComponent,
    ModalDeleteConfirmationComponent,
    ModalApplicableNotApplicableComponent
  ]
})
export class ModalModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ModalModule,
      providers: [
        TypeAheadEventService,
        NgbModalStack,
        ModalEventService,
        SaveSearchService,
        DeleteConfirmationService,
        ApplicableNotApplicableService,
        UnsavedChangesService
      ]
    }
  }
}
