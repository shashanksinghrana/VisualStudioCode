import { Component, Input, OnDestroy , EventEmitter, Output, TemplateRef, ViewChild, AfterContentInit, ContentChildren, QueryList } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs/Subscription';
import { SaveSearchService } from '../../services/events/modal/modal-save-search.service';

@Component({
  selector: 'c2c-modal-save-search',
  templateUrl: './modal-save-search.component.html',
  styleUrls: ['./modal-save-search.component.scss']
})
export class ModalSaveSearchComponent implements OnDestroy{

  /** Defines the event passed to emit function. Event is which button in modal was clicked. */
  public event: string;

  /** Defines Option for modal window */
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-custom-size'
  };

  /** Defines tab index **/
  @Input() public tabIndex;
  
  /** Outputs an event when the OK button is clicked. Used to provide extra logic if needed. */
  @Output() saveSearchVal = new EventEmitter<any>();

  /** Defines Input field value **/
  @Input() inputVal : any;

  private openModalSubscription: Subscription;
  private closeModalSubscription: Subscription;
  public modal: NgbModalRef;
  public disableBtn : boolean = true;


  /** The content of the modal to be displayed when opened. */
  @ViewChild('saveSearchModal') saveSearchModal: TemplateRef<any>;
  @ContentChildren(ModalSaveSearchComponent) genericModalChildren : QueryList<ModalSaveSearchComponent>;

  constructor(private modalService: NgbModal, private saveSearchService: SaveSearchService) {
    this.openModalSubscription = this.saveSearchService.onOpenModal()
      .subscribe(value => {
        this.inputVal = value;
        if(this.inputVal){
          this.disableBtn = false;
        }
        this.modal = this.modalService.open(this.saveSearchModal, this.modalOptions);
      });
    this.closeModalSubscription = this.saveSearchService.onCloseModal()
      .subscribe(value => {
        this.modal.close();
      });
  }

  ngOnInit() {   }

  /** Function to Open modal. **/
  public openModal() {
    this.saveSearchService.openModal();
    this.inputVal = '';
  }

  /** Function to Close modal. **/
  public close(evt?:any) : void {
    this.saveSearchVal.emit(evt);
    this.disableBtn = true;
    this.modal.close();
    this.inputVal = '';
  };

   /**
   * Emits the event when the ok button is clicked.
   *
   * @param event The event being emitted ('OK').
   */
  emitEvent(event) {
    if(this.inputVal != " "){
      this.saveSearchVal.emit({value: this.inputVal, action: event });
      this.modal.close();
      this.inputVal = '';
      this.disableBtn = true;
    }
  }

  /* Method to check input value */
  public checkInput(){
    this.inputVal ? this.disableBtn = false : this.disableBtn = true;
  }

  ngOnDestroy() {
    this.saveSearchVal.unsubscribe();
    this.openModalSubscription.unsubscribe();
    this.closeModalSubscription.unsubscribe();
  }
}
