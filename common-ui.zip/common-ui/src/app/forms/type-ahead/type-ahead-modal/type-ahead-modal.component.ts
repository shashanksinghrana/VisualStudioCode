import {
  Component, OnInit, TemplateRef, ViewChild, ViewContainerRef, ViewChildren, EventEmitter,
  QueryList, Renderer2, ElementRef, HostListener, Input, OnDestroy, AfterViewInit, Output,
} from '@angular/core';

import { NgForm, FormControl, FormGroup, Validators, AbstractControl, ValidationErrors, PatternValidator } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalRef, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';

import { take } from 'rxjs/operator/take';
import { Subscription } from 'rxjs/Subscription';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';

import { ToasterService } from '../../../services/toaster/toaster.service';
import { TypeAheadSaveModel } from '../../../models/type-ahead/type-ahead-save.model';
import { AddAliasService } from '../../../services/http/type-ahead/aka/add-alias.service';
import { TypeAheadService } from '../../../services/http/type-ahead/type-ahead.service';
import { TypeAheadEventService } from '../../../services/events/type-ahead/type-ahead-event.service';
import { TypeAheadDisplayModel } from '../../../models/type-ahead/type-ahead-display';
import { TypeAheadPersistService } from '../../../services/persist/type-ahead/type-ahead-persist.service';
import { EmptyIfNull } from '../../../utils/strings/empty-if-null';
import { CharKeyCodes } from '../../../enums/characters/character-keycodes.enum';
import { TypeAheadModel } from '../../../models/type-ahead/type-ahead.model';
import { AddAliasModel } from '../../../models/type-ahead/aka/add-alias.model';

import { EntityTypes } from '../../../enums/entity/entity-types.enum';
import { AddAliasAKAModel } from '../../../models/type-ahead/aka/add-alias-aka.model';
import { ModalEventService } from '../../../services/events/modal/modal-event.service';
import { concatMap } from 'rxjs/operator/concatMap';
import { TypeAheadDisplayResultModel } from '../../../models/type-ahead/type-ahead-display-result.model';
import { AccentedCharsModel } from '../../../models/accented-chars/accented-chars.model';

// const occupationsConst: Array<string> = ['Actor', 'Director', 'Producer', 'Writer'];
// const occupationDefault: string = occupationsConst[0];
const _title: string = 'Default Modal Title';
const _label: string = 'Entered name does not exist, would you like to add this name?';
const _showAddAlias: boolean = true;
const _displayNameAs: boolean = true;
const _additionFieldsDisplayed: boolean = true;
const _allowOnlyOneAlias: boolean = false;
const _checkAsAlias: boolean = false;
const _partyType: string = 'Talent';
const _serviceClass: string = null;
const _serviceSave: string = null;
const _typeAheadId: string = null;
const _hideTypeAhead: boolean = false;

@Component({
  selector: 'c2c-type-ahead-modal',
  templateUrl: './type-ahead-modal.component.html',
  styleUrls: ['./type-ahead-modal.component.scss'],
  providers: [TypeAheadService, ToastsManager, ToasterService, AddAliasService]
})

export class TypeAheadModalComponent implements OnInit, AfterViewInit, OnDestroy {

  public isModalOpen: boolean = false;
  public isSaving: boolean;
  public showAliasCurrentName: boolean;
  public showAddName: boolean = true;
  public showAlias: boolean;
  public showCloseMessage: boolean;
  public showCurrentNameError: boolean;
  public ssnHasErrors: boolean;
  public roleIsPerson: boolean = true;
  public disabledTypeAhead: boolean = false;

  public appName: string = '';
  public typeAheadName: string = '';
  private bsModalCloseResult: string;
  private userRoleType: string;

  public ssnMaxLength: number = 11;

  public addTalentForm: FormGroup;
  private bsModal: NgbModalRef;
  private noResultsSubscription: Subscription;

  // public occupations: Array<string> = occupationsConst;
  public noResultsValues: TypeAheadModel;
  protected selectedTypeAheadRecord: TypeAheadModel;
  public typeAheadDataService: any;
  private _fullRecordRouterLink: string;

  public currentDisplayData: TypeAheadDisplayModel;

  private modalTypeAheaRef: ElementRef;
  @ViewChild('modalTypeAhead') modalTypeAhead: ElementRef;
  @ViewChild('submitBtn') submitBtn: ElementRef;
  @ViewChild('aliasentityName') aliasentityName: ElementRef;

  private entityNameRef: ElementRef;
  @ViewChildren('entityName') public formViewChildren: QueryList<ElementRef>;
  @ViewChild('addTalentModal') public noResultsForm: TemplateRef<any>;
  // @Input() public userRole: string;

  // Pass the input function to have the custom save for Modal
  @Input() public modalSave: Function;
  @Input() public modalSaveAlias: Function;
  @Input() public isTalent: boolean = true;
  /** This input is added to disable alias field.*/
  @Input() public aliasFieldDisabled: boolean = false;
  @Input() clearTypeAheadValue: boolean = true;
  @Input() focusTypeAhead: boolean = true;
  @Output() modalSaved = new EventEmitter<any>();
  @Output() modalSavedAlias = new EventEmitter<any>();
  @Output() onEditButton: EventEmitter<any> = new EventEmitter();
  @Output() onCancel = new EventEmitter<any>();

  public typeAheadModalConfig: Object = {
    title: _title,
    label: _label,
    showAddAlias: _showAddAlias,
    displayNameAs: _displayNameAs,
    additionalFieldsDisplayed: _additionFieldsDisplayed,
    allowOnlyOneAlias: _allowOnlyOneAlias,
    checkAsAlias: _checkAsAlias,
    partyType: _partyType,
    service: {
      serviceClass: _serviceClass,
      serviceSave: _serviceSave
    },
    typeAheadId: _typeAheadId,
    hideTypeAhead: _hideTypeAhead
  };

  @Input() public typeAheadModalService: any;
  // @Input() public allowOnlyOneAlias: boolean = false;

  @Input()
  set fullRecordRouterLink(val: string) { this._fullRecordRouterLink = val; }
  get fullRecordRouterLink(): string { return this._fullRecordRouterLink; }

  // private _checkAsAlias: boolean = false;
  // @Input()
  // set checkAddAsAlias(val: boolean) { this._checkAsAlias = val; }
  // get checkAddAsAlias(): boolean { return this._checkAsAlias; }

  private _modalName: string = '';
  @Input()
  set modalName(val: string) {
    this._modalName = val;

  }
  get modalName(): string { return this._modalName; }

  @Input() public fullRecordParams: string;

  private aliasSelecteData: any;

  @Output() saveNameTalentEvent: EventEmitter<any> = new EventEmitter<any>();

  @Input() editButton: boolean = false;
  @Input() listForCurrentName: string = '';
  /**Data configuration for typeAhead display */
  @Input() public typeAheadDisplayDataResults: TypeAheadDisplayResultModel = {
    filterType: 'TALENT_CONTACT',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'teamMembers'],
      display: '`${data.primaryName ?` (alias for ${data.primaryName}) `:` (team of ${data.teamMembers})`}`',
      notAllColumnsRequired: true
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'ssnEndChars']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this.typeAheadService,
      get: 'get'
    }
  };
  /** TAL-3199 Clarification */
  @Input() ownAccentedModalApi: boolean = false;
  @Output() accentedModalCharEvent: EventEmitter<any> = new EventEmitter<any>();

  public accentedModalCharsVal: AccentedCharsModel[] = [];
  @Input()
  set setAccentedModalChars(vals: AccentedCharsModel[]) {

    if (this.ownAccentedModalApi && (vals && vals.length)) {
      this.accentedModalCharsVal = vals;
    }
  }
  get setAccentedModalChars(): AccentedCharsModel[] { return this.accentedModalCharsVal; }

  constructor(private modalService: NgbModal,
    private typeAheadEventService: TypeAheadEventService,
    protected typeAheadService: TypeAheadService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    protected toasterService: ToasterService,
    private typeAheadPersistService: TypeAheadPersistService,
    private renderer: Renderer2,
    protected addAliasService: AddAliasService,
    private modalEventService: ModalEventService,
    private router: Router) {

    this.noResultsSubscription = this.typeAheadEventService.getTypeAheadNoResults()
      .subscribe(item => this.typeAheadNoResultsFound(item));

    this.typeAheadEventService.getModalConfig().subscribe(config => {
      if (config['modalName'] === this._modalName) {
        this.typeAheadModalConfig = config;
        if (this.typeAheadModalConfig['modalName'] === this._modalName) {
          if (!this.typeAheadModalConfig['allowOnlyOneAlias']) {
            return;
          }
          if (this.aliasSelecteData) {
            this.disabledTypeAhead = true;
          } else {
            this.disabledTypeAhead = false;
          }
        }
      }
    });

    this.toaster.setRootViewContainerRef(vcr);

    /**Setting the context of this */
    this.successCB = this.successCB.bind(this);
    this.failureCB = this.failureCB.bind(this);
  }



  ngAfterViewInit() {
    this.formViewChildren.changes.subscribe((child: QueryList<any>) => {
      this.entityNameRef = child.first;
    });

    this.typeAheadEventService.getCurrentItemSelected().subscribe(item => {
      if (this.listForCurrentName === item.listName) {
        this.aliasSelecteData = item.item;
      }
    });
  }

  ngOnInit() {

    // service needed for typeAhead data
    this.typeAheadDataService = this.typeAheadService;

    this.addTalentForm = new FormGroup({
      dropdowns: new FormGroup({
        // occupation: new FormControl(occupationDefault)
      }),
      aliasCheckbox: new FormControl(false),
      editableFields: new FormGroup({
        firstName: new FormControl(null),
        entityName: new FormControl(null, { updateOn: 'change', validators: [this.noWhiteSpaceValidator, Validators.required] }),
        middleName: new FormControl(null),
        suffix: new FormControl(null)
      }),
      aliasFields: new FormGroup({
        aliasFirstName: new FormControl(null),
        aliasentityName: new FormControl(null, { updateOn: 'change', validators: [this.noWhiteSpaceValidator, Validators.required] }),
        aliasMiddleName: new FormControl(null),
        aliasSuffix: new FormControl(null),
        typeAhead: new FormControl(null)
      })
    });
    this.onChanges();
    this.TrapFocusDuplicateAlertModal()
  }

  ngOnDestroy() {
    this.noResultsSubscription.unsubscribe();
  }

  /**Remove whitespace from last name formControls
   * This should be more dynamic
   */
  public trimWhiteSpace(control: FormControl, form?: FormGroup): void {
    this.addTalentForm.controls.aliasFields['controls'].aliasentityName.setValue(
      this.removespace(this.addTalentForm.controls.aliasFields['controls'].aliasentityName.value)
    );

    this.addTalentForm.controls.editableFields['controls'].entityName.setValue(
      this.removespace(this.addTalentForm.controls.editableFields['controls'].entityName.value)
    );
  }

  private removespace(val: string): string {
    return val.trim();
  }

  private noWhiteSpaceValidator(cntrl: FormControl) {
    const isWhiteSpace: boolean = (cntrl.value || '').trim().length === 0;
    const isValid = !isWhiteSpace;

    return isValid ? null : { 'whitespace': true };
  }

  // no results from the typeAhead search. Emitted event comes from typeAhead component class
  public noTypeAheadResultsFromMainForm(val: TypeAheadDisplayModel) {
    if (val) {
      this.showAliasCurrentName = true;
      setTimeout(() => {
        // have to do this to get the reference
        this.setFieldFocus(this.entityNameRef);

        const noResultsFromAliasSearch: TypeAheadModel = new TypeAheadModel();
        noResultsFromAliasSearch.entityName = val.entityName;
        noResultsFromAliasSearch.firstName = val.firstName;
        noResultsFromAliasSearch.middleName = val.middleName;
        noResultsFromAliasSearch.suffix = val.suffix;

        // this.addTalentForm.controls.editableFields['controls'].ssn.enable();
        // this.addTalentForm.controls.dropdowns.get('occupation').enable();
        this.updateAddNameFields(noResultsFromAliasSearch);
      }, 100);
    }
  }

  public enterKey(evt: KeyboardEvent): void {
    if (evt.keyCode !== CharKeyCodes.ENTER) {
      return;
    }
    // this.save(evt); @subhakar disabled this action, causing issue during tabbing
  }

  public save(evt: Event): void {
    if (this.addTalentForm.invalid || this.isSaving) {
      if (this.showAlias && (this.addTalentForm.controls.editableFields['controls'].entityName.invalid
        || this.addTalentForm.controls.aliasFields['controls'].aliasentityName.invalid)) {

        this.showCurrentNameError = true;
        setTimeout(() => {
          this.setFieldFocus(this.entityNameRef);
        }, 100);
        return;
      } else {
        return;
      }
    }

    this.showCurrentNameError = false;
    this.saveData(this.addTalentForm.value, this.showAlias);
    this.addTalentForm.disable();
    this.isSaving = true;
    // trigger the event
    // this.modalSaved.emit()
  }

  public closeTypeaheadModal(): void {
    this.bsModal.dismiss('close');
  }

  public closeModal() {
    this.resetForm();
    if (this.bsModal) {
      this.bsModal.dismiss('close');
    }
    if (this.focusTypeAhead) {
      this.renderer.selectRootElement('#typeAheadField').focus();
    }
    if (this.clearTypeAheadValue) {
      this.renderer.selectRootElement('#typeAheadField').value = '';
    }
    this.typeAheadModalConfig['modalOpen'] = false;
    this.accentedModalCharsVal = [];
    this.modalEventService.closeModal(true);
    // this.typeAheadEventService.addToListChangeEvent(true);

  }

  public showCloseMessageFun(): string {
    if (this.showCloseMessage) {
      return 'block';
    } else {
      return 'none';
    }
  }

  public openCloseConfirmation() {
    // this.showCloseMessage = !this.addTalentForm.pristine || this.addTalentForm.dirty;
    this.showCloseMessage = this.addTalentForm.dirty;

    if (!this.showCloseMessage) {
      this.resetForm();
      this.closeModal();
    }

    // angular is stupid and makes setting focus difficult, so have to do this junk
    window.setTimeout(() => {
      const elem = document.getElementById('continueCancelBtn');
      if (elem) {
        elem.focus();
      }
    }, 100);
  }

  public closeConfirmationYes() {
    this.resetForm();
    this.closeModal();
    this.onCancel.emit();
  }

  public closeConfirmationNo() {
    this.showCloseMessage = false;
  }

  // set properties and open modal
  private open(modal: TemplateRef<any>, nameObj: any): void {
    let modalServ;
    if (this.typeAheadModalConfig['modalName'] === this._modalName && this.typeAheadModalConfig['modalOpen']) {
      if (this.isModalOpen) {
        return;
      }
      this.isModalOpen = true;
      this.bsModal = modalServ = this.modalService.open(modal, {
        size: 'lg',
        backdrop: 'static',
        windowClass: 'modal-position',
        keyboard: false
      });
      // this.typeAheadEventService.addToListChangeEvent(false);
      this.addTalentForm.enable();
    }
  }

  public escKeyPressed(event) {
    this.openCloseConfirmation();
  }

  /** This method is used to enable and disable alias field */
  private setAliasFieldDisabled(): void {
    if (this.aliasFieldDisabled) {
      const editableCtrl = this.addTalentForm.controls.editableFields['controls'];
      if (this.showAlias) {
        editableCtrl.entityName.disable();
        editableCtrl.firstName.disable();
        editableCtrl.middleName.disable();
        editableCtrl.suffix.disable();
      } else {
        editableCtrl.entityName.enable();
        editableCtrl.firstName.enable();
        editableCtrl.middleName.enable();
        editableCtrl.suffix.enable();
      }
    }
  }

  // Output() event when item is selected from typeAhead
  public modalTypeAheadSelectedItem(val: TypeAheadModel): void {
    this.setAliasFieldDisabled();
    this.showAliasCurrentName = true;
    this.selectedTypeAheadRecord = val;
    this.updateAddNameFields(val);

    setTimeout(() => {
      // have to do this to get the reference
      this.setFieldFocus(this.entityNameRef);
      // this.disableSSnOccupation(true);

    }, 100);
  }

  public clearTypeAhead(): void {
    this.resetAddNameFields();
    // this.disableSSnOccupation(false);
    this.showAliasCurrentName = false;
  }

  // toggle alias fields
  public addAsAlias(evt: Event): void {
    this.showAlias = !this.showAlias;
    const aliasCtrl = this.addTalentForm.controls.aliasFields['controls'];
    const editableCtrl = this.addTalentForm.controls.editableFields['controls'];
    if (this.showAlias) {
      this.showCurrentNameError = true;
      this.showAddName = false;
      aliasCtrl.aliasFirstName.setValue(editableCtrl.firstName.value);
      aliasCtrl.aliasentityName.setValue(editableCtrl.entityName.value);
      aliasCtrl.aliasMiddleName.setValue(editableCtrl.middleName.value);
      aliasCtrl.aliasSuffix.setValue(editableCtrl.suffix.value);
      aliasCtrl.aliasentityName.setValidators([Validators.required]);
      this.setEmptyEditFields();
    } else {
      this.showAddName = true;
      this.showAliasCurrentName = false;
      editableCtrl.firstName.setValue(aliasCtrl.aliasFirstName.value);
      editableCtrl.entityName.setValue(aliasCtrl.aliasentityName.value);
      editableCtrl.middleName.setValue(aliasCtrl.aliasMiddleName.value);
      editableCtrl.suffix.setValue(aliasCtrl.aliasSuffix.value);
      aliasCtrl.aliasentityName.setValidators([]);
      this.setAliasFieldDisabled();
      this.setEmptyAliasFields();
    }
    this.addTalentForm.markAsDirty();
  }

  private onChanges(): void {
    const firstName: AbstractControl = this.addTalentForm.controls.editableFields['controls'].firstName;
    const entityName: AbstractControl = this.addTalentForm.controls.editableFields['controls'].entityName;
    const middleName: AbstractControl = this.addTalentForm.controls.editableFields['controls'].middleName;
    const suffix: AbstractControl = this.addTalentForm.controls.editableFields['controls'].suffix;
    // const companyName: AbstractControl = this.addTalentForm.controls.companyName;
    // const ssn: AbstractControl = this.addTalentForm.controls.editableFields['controls'].ssn;
    // const occupation: AbstractControl = this.addTalentForm.controls.dropdowns.get('occupation');

    // listen for form changes
    this.addTalentForm.valueChanges.subscribe(val => {
      this.typeAheadEventService.displayData(this.displayNameData(val));
    });
  }

  // build display name data
  private displayNameData(val: any): TypeAheadDisplayModel {
    const displayData: TypeAheadDisplayModel = new TypeAheadDisplayModel();
    const firstNameEdit = val.editableFields && val.editableFields.firstName ? val.editableFields.firstName : this.addTalentForm.get('editableFields.firstName').value;
    const entityNameEdit = val.editableFields && val.editableFields.entityName ? val.editableFields.entityName : this.addTalentForm.get('editableFields.entityName').value;
    const middleEdit = val.editableFields && val.editableFields.middleName ? val.editableFields.middleName : this.addTalentForm.get('editableFields.middleName').value;
    const suffixEdit = val.editableFields && val.editableFields.suffix ? val.editableFields.suffix : this.addTalentForm.get('editableFields.suffix').value;
    // let ssnEdit = val.editableFields && val.editableFields.ssn ? val.editableFields.ssn :  this.addTalentForm.get('editableFields.ssn').value;

    // displayData.companyName = val.companyName;
    displayData.firstName = !this.showAlias ? firstNameEdit : val.aliasFields.aliasFirstName;
    displayData.isPerson = this.roleIsPerson;
    displayData.entityName = !this.showAlias ? entityNameEdit : val.aliasFields.aliasentityName;
    displayData.middleName = !this.showAlias ? middleEdit : val.aliasFields.aliasMiddleName;

    displayData.partyType = val.partyType;
    // displayData.ssn = ssnEdit;
    displayData.suffix = !this.showAlias ? suffixEdit : val.aliasFields.aliasSuffix;
    if (this.showAlias) {
      if (val.editableFields) {
        displayData.primaryName = this.createDisplayAliasText(val.editableFields);
      } else {
        const buildEditFields: TypeAheadDisplayModel = new TypeAheadDisplayModel;
        buildEditFields.firstName = firstNameEdit;
        buildEditFields.entityName = entityNameEdit;
        buildEditFields.middleName = middleEdit;
        buildEditFields.suffix = suffixEdit;
        displayData.primaryName = this.createDisplayAliasText(buildEditFields);
      }

    }
    this.currentDisplayData = displayData;
    return displayData;
  }

  // this switch allows us to turn on and off the field's required validator
  private disableEnableSwitch(companyName: AbstractControl, entityName: AbstractControl): void {

    if (this.roleIsPerson) {
      // companyName.disable();
      entityName.enable();
      // this.title = 'Confirm/Edit Name';
    } else {
      entityName.disable();
      const firstName: AbstractControl = this.addTalentForm.controls.editableFields['controls'].firstName;
      const middleName: AbstractControl = this.addTalentForm.controls.editableFields['controls'].middleName;

      // this.buildCompanyNameString({ firstName: firstName.value, middleName: middleName.value, entityName: entityName.value });
      // companyName.enable();
    }
  }

  // EventEmitter when no typeAhead results are found, from main form
  private typeAheadNoResultsFound(item: TypeAheadModel): void {
    const displayData: TypeAheadDisplayModel = new TypeAheadDisplayModel();
    this.open(this.noResultsForm, item);
    this.noResultsValues = item;
    this.showAlias = this.typeAheadModalConfig['checkAddAsAlias'];

    if (this.showAlias && this.aliasSelecteData) {
      this.updateAddNameFields(this.aliasSelecteData);
      this.selectedTypeAheadRecord = this.aliasSelecteData;
      this.addTalentForm.controls.aliasCheckbox.setValue(true);
      this.addTalentForm.controls.aliasCheckbox.disable();
      this.disabledTypeAhead = true;
    } else {
      this.showAlias = false;
      this.updateAddNameFields(item);
    }
    this.updateAliasFields(item);
    // this.buildCompanyNameString(item);

    if (this.showAlias && this.aliasSelecteData) {
      this.addTalentForm.controls.editableFields.get('firstName').disable();
      this.addTalentForm.controls.editableFields.get('entityName').disable();
      this.addTalentForm.controls.editableFields.get('middleName').disable();
      this.addTalentForm.controls.editableFields.get('suffix').disable();
      // this.addTalentForm.controls.editableFields['controls'].ssn.disable();
      // this.addTalentForm.controls.dropdowns.get('occupation').disable();
    }

    // c2c-type-ahead-display values when show alias is checked bydefualt
    if (this.showAlias) {
      this.currentDisplayData.entityName = item.entityName;
      this.currentDisplayData.firstName = item.firstName;
      this.currentDisplayData.middleName = item.middleName;
      this.currentDisplayData.suffix = item.suffix;

      // alias
      displayData.entityName = this.aliasSelecteData.entityName;
      displayData.firstName = this.aliasSelecteData.firstName;
      displayData.middleName = this.aliasSelecteData.middleName;
      displayData.suffix = this.aliasSelecteData.suffix;
      this.currentDisplayData.primaryName = this.createDisplayAliasText(displayData);
    }
  }

  // create company name from other values
  private buildCompanyNameString(item: any): void {
    const companyName: string = EmptyIfNull.check(item.firstName) + ' ' +
      EmptyIfNull.check(item.middleName) + ' ' +
      EmptyIfNull.check(item.entityName);

    this.addTalentForm.controls.companyName.setValue(companyName);
  }

  private updateAddNameFields(val: TypeAheadModel): void {

    // set values for add name fields
    this.userRoleType = this.typeAheadPersistService.getUserRole();

    this.addTalentForm.controls.editableFields['controls'].firstName.setValue(val.firstName);
    this.addTalentForm.controls.editableFields['controls'].entityName.setValue(val.entityName);
    this.addTalentForm.controls.editableFields['controls'].middleName.setValue(val.middleName);
    this.addTalentForm.controls.editableFields['controls'].suffix.setValue(val.suffix);


    // dirty flag doesn't get set when auto populating, so forcing it here.
    this.addTalentForm.markAsDirty();
  }

  private updateAliasFields(val: TypeAheadModel): void {

    // set values for alias fields
    this.addTalentForm.controls.aliasFields['controls'].aliasFirstName.setValue(val.firstName);
    this.addTalentForm.controls.aliasFields['controls'].aliasentityName.setValue(val.entityName);
    this.addTalentForm.controls.aliasFields['controls'].aliasMiddleName.setValue(val.middleName);
    this.addTalentForm.controls.aliasFields['controls'].aliasSuffix.setValue(val.suffix);

    // dirty flag doesn't get set when auto populating, so forcing it here.
    this.addTalentForm.markAsDirty();
  }

  protected resetForm(): void {
    this.typeAheadEventService.displayData(true);
    this.showCloseMessage = false;
    this.roleIsPerson = true;
    this.isModalOpen = false;
    this.isSaving = false;
    this.showAlias = false;
    this.showAddName = true;
    this.showAliasCurrentName = false;
    // reset these values back to their defaults
    this.resetAddNameFields();
    // this.addTalentForm.controls.dropdowns['controls'].occupation.setValue(occupationDefault);
    this.typeAheadEventService.clearTypeAheadFields();
    this.selectedTypeAheadRecord = null;
  }

  private resetAliasFields() {
    this.addTalentForm.controls.aliasFields.reset();
  }

  private resetAddNameFields() {
    this.addTalentForm.controls.editableFields.reset();
  }

  private resetSingleControl(val: AbstractControl): void {
    val.setValue(null);
  }


  private showConfirmationMessage(): void {
    this.toaster.custom('<span style="color: red">Are you sure you want to cancel?</span>', 'Cancel Confirmation',
      { enableHTML: true, showCloseButton: true, positionClass: 'toast-top-center' });
  }

  private setFieldFocus(ele: ElementRef) {
    if (!ele) {
      return;
    }

    ele.nativeElement.focus();
  }

  // save function called from TypeAheadModalComponet.ts
  public saveData(vals: any, saveAlias: boolean): void {

    /**This can be used when we need to change the service to do the save, such as when
     * creating a new contact
     */
    // if (this.typeAheadModalConfig['service']['serviceClass']) {
    //   this.configSave(vals);
    //   return;
    // }
    if (this.isTalent === true) {
      if (!saveAlias) {
        // this.modalSaved.emit();
        this.saveTypeAheadName(vals);
      } else {
        // this.modalSavedAlias.emit();
        this.saveAliass(vals);
      }
    } else {
      if (!saveAlias) {
        this.modalSaved.emit();
        // this.saveTypeAheadName(vals);
      } else {
        // Editable field is nou updating properly in main control so taking seprately and passing
        const request = this.addTalentForm.value;
        request.editableFields = this.addTalentForm.get('editableFields').value;
        this.modalSavedAlias.emit(request);
        // this.saveAliass(vals);
      }
    }
  }

  // save alias(AKA)
  private saveAliass(vals: any): void {
    const aliasParty: AddAliasModel = new AddAliasModel();

    const valEditFields = {
      editableFields: {
        firstName: vals.editableFields && vals.editableFields.firstName ? vals.editableFields.firstName : this.addTalentForm.get('editableFields.firstName').value,
        entityName: vals.editableFields && vals.editableFields.entityName ? vals.editableFields.entityName : this.addTalentForm.get('editableFields.entityName').value,
        middleName: vals.editableFields && vals.editableFields.middleName ? vals.editableFields.middleName : this.addTalentForm.get('editableFields.middleName').value,
        suffix: vals.editableFields && vals.editableFields.suffix ? vals.editableFields.suffix : this.addTalentForm.get('editableFields.suffix').value,
        // ssn: vals.editableFields && vals.editableFields.ssn ? vals.editableFields.ssn :  this.addTalentForm.get('editableFields.ssn').value
      }

    };
    aliasParty.partyType = this.entityType();
    aliasParty.partyId = (this.selectedTypeAheadRecord) ? this.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.first = EmptyIfNull.check(valEditFields.editableFields.firstName);
    aliasParty.name.middle = EmptyIfNull.check(valEditFields.editableFields.middleName);
    aliasParty.name.entity = EmptyIfNull.check(valEditFields.editableFields.entityName);
    aliasParty.name.suffix = EmptyIfNull.check(valEditFields.editableFields.suffix);
    // aliasParty.occupation = this.addTalentForm.controls.dropdowns.get('occupation').value;
    // aliasParty.ssn = EmptyIfNull.check(valEditFields.editableFields.ssn);
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(valEditFields));

    const AKA: AddAliasAKAModel = new AddAliasAKAModel();
    AKA.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    AKA.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    AKA.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    AKA.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);
    // AKA.name.entity = this.createAliasName(vals);
    if (this.modalSaveAlias) {
      this.modalSaveAlias(JSON.stringify([aliasParty, AKA]), this.successCBAlias, this.failureCBAlias);
    } else {
      this.addAliasService.save(JSON.stringify([aliasParty, AKA])).subscribe(
        (res) => {
          this.sendNewNameToList(res);
          this.saveNotification(true, this.notificationMessage('Alias: ' + AKA.name.entity + ' saved', 'Success!'));
        },
        (err) => {
          const errCode: string = err.error.errors[0].code;
          let message: string = 'Alias did not save';
          if (errCode === 'aka.already.exist') {
            const partyName = EmptyIfNull.check(aliasParty.name.first)
              + ' ' + EmptyIfNull.check(aliasParty.name.middle)
              + ' ' + EmptyIfNull.check(aliasParty.name.entity)
              + ' ' + EmptyIfNull.check(aliasParty.name.suffix);
            message = 'Alias "' + AKA.name.entity.trim() + '" for party "' + partyName.trim() + '" already exists!';
          }
          if (errCode === 'data.already.exist') {
            message = err.error.errors[0].detail;
          }
          if (errCode === 'invalid.partyId.input') {
            message = err.error.errors[0].detail;
          }
          this.saveNotification(false, this.notificationMessage(message, 'Oops!'));
          // this.failureCBAlias(message);

        }
      );
    }
  }

  public successCBAlias = (res) => {
    this.sendNewNameToList(res);
    this.saveNotification(true, this.notificationMessage('Alias:  saved', 'Success!'));
  }
  public failureCBAlias = (message) => {
    this.saveNotification(false, this.notificationMessage(message, 'Oops!'));
  }

  // save typeAhead name
  private saveTypeAheadName(vals: any): void {
    const tName: TypeAheadSaveModel = new TypeAheadSaveModel();
    tName.partyId = null;

    if (this.roleIsPerson) {
      tName.name.entity = vals.editableFields.entityName;
      tName.name.first = vals.editableFields.firstName;
    }
    // else {
    //   tName.name.entity = vals.editableFields.companyName;
    // }


    tName.partyType = this.entityType();
    tName.name.middle = vals.editableFields.middleName;
    tName.name.suffix = vals.editableFields.suffix;
    // tName.ssn = vals.editableFields.ssn;
    // tName.occupation = this.addTalentForm.controls.dropdowns.get('occupation').value;
    tName.displayName = this.createDisplayName(vals);
    tName.createdBy = 'Melissa Tapie';
    tName.updatedBy = 'Melissa Tapie';
    tName.createdByApp = 'Talent2';
    tName.updatedByApp = 'Talent2';
    const dataSet = this.typeAheadPersistService.getUserData();
    if (dataSet) {
      tName.dataSetId = dataSet.masterDataset;
    }
    // pass the custom api for save
    // if (this.modalSave) {
    //   this.modalSave(JSON.stringify(tName), this.successCB, this.failureCB);
    // } else {
    this.typeAheadDataService.save(JSON.stringify(tName)).subscribe(
      (res) => {

        this.successCB(res);
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        const field: string = err.error.errors[0].field;

        if (field && field.toUpperCase() === 'SSN') {
          this.saveNotification(false, this.notificationMessage(errMessage, 'Oops!'));
        } else {
          this.failureCB(errMessage);
        }
      });
    // }
  }

  // success Callback
  public successCB = (res) => {
    this.sendNewNameToList(res);
    this.saveNotification(true, this.notificationMessage('Name saved', 'Success'));
    // if (this.editButton) {
    //   this.onEditButton.emit();
    // }
  }

  // failure Callback
  public failureCB = (errMessage) => {
    this.saveNotification(false, this.notificationMessage(errMessage, 'Oops!'));
  }

  private createDisplayName(vals: any): string {
    return vals.editableFields.entityName + ', ' +
      vals.editableFields.suffix + ', ' +
      vals.editableFields.firstName + ' ' +
      vals.editableFields.middleName;
  }

  // create alias name
  private createAliasName(vals: any): string {
    const alias: string = EmptyIfNull.check(vals.aliasFields.aliasFirstName) + ' ' +
      EmptyIfNull.check(vals.aliasFields.aliasMiddleName) + ' ' +
      EmptyIfNull.check(vals.aliasFields.aliasentityName) + ((vals.aliasFields.aliasSuffix) ? ', ' : '') +
      EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    return alias;
  }

  // return entity type
  private entityType(): string {
    if (this.typeAheadModalConfig['partyType'] === 'Contact') {
      return EntityTypes.CONTACT.toUpperCase();
    }
    if (this.roleIsPerson) {
      return EntityTypes.TALENT.toUpperCase();
    } else {
      return EntityTypes.COMPANY.toUpperCase();
    }
  }

  // create save notification message
  private notificationMessage(message: string, title: string): object {
    return {
      message: message,
      title: title
    };
  }

  // save notification with toaster
  private saveNotification(success: boolean, message: object): void {
    if (success) {
      this.toasterService.success(message['message'], message['title']);
      setTimeout(() => {
        this.closeModal();
      }, 100);
    } else {
      this.toasterService.error(message['message'], message['title']);
      this.addTalentForm.enable();
      this.isSaving = false;
    }
  }

  private setEmptyEditFields() {
    this.addTalentForm.controls.editableFields['controls'].firstName.setValue('');
    this.addTalentForm.controls.editableFields['controls'].entityName.setValue('');
    this.addTalentForm.controls.editableFields['controls'].middleName.setValue('');
    this.addTalentForm.controls.editableFields['controls'].suffix.setValue('');
  }

  private setEmptyAliasFields() {
    this.addTalentForm.controls.aliasFields['controls'].aliasFirstName.setValue('');
    this.addTalentForm.controls.aliasFields['controls'].aliasentityName.setValue('');
    this.addTalentForm.controls.aliasFields['controls'].aliasMiddleName.setValue('');
    this.addTalentForm.controls.aliasFields['controls'].aliasSuffix.setValue('');
  }

  private createDisplayAliasText(val: TypeAheadDisplayModel): string {
    return (val.firstName || '') + ' ' +
      (val.middleName || '') + ' ' +
      (val.entityName || '') +
      (val.suffix ? ', ' + val.suffix : '');
  }

  private sendNewNameToList(val: any): void {

    const selectedName: TypeAheadModel = new TypeAheadModel();
    selectedName.entityName = val['name'].entity;
    selectedName.firstName = val['name'].first;
    selectedName.middleName = val['name'].middle;
    selectedName.partyId = val['partyId'];
    selectedName.suffix = val['name'].suffix;
    selectedName.typeAheadDisplayName = val['displayName'] || val['name'].entity;
    selectedName.nameId = val['name'].nameId;

    if (this.typeAheadModalConfig['typeAheadId']) {
      this.saveNameTalentEvent.emit({ nameAdded: selectedName, typeAheadId: this.typeAheadModalConfig['typeAheadId'] });
    } else {
      this.saveNameTalentEvent.emit(selectedName);
    }
  }

  public goToFullRecordPage() {
    this.closeModal();
    if (this.fullRecordParams) {
      const routeParam = this[this.fullRecordParams];
      // , { queryParams: {fullRecordParam: queryParams}}
      this.router.navigate([this._fullRecordRouterLink, routeParam]);
    } else {
      this.router.navigate([this._fullRecordRouterLink]);
    }

  }

  public edit() {
    if (this.addTalentForm.invalid) {
      if (this.showAlias && (this.addTalentForm.controls.editableFields['controls'].entityName.invalid
        || this.addTalentForm.controls.aliasFields['controls'].aliasentityName.invalid)) {
        this.showCurrentNameError = true;
        this.setFieldFocus(this.entityNameRef);
        return;
      }
    }

    this.showCurrentNameError = false;
    if (this.typeAheadModalConfig['typeAheadId']) {
      this.onEditButton.emit({ typeAheadId: this.typeAheadModalConfig['typeAheadId'] });
    } else {
      this.onEditButton.emit();
    }

  }

  public accentedModalService(char: any): void {
    this.accentedModalCharEvent.emit(char);
  }

    /** Focus trap inside duplicate alert popup is the popup is available. author rahul 
   **/
  TrapFocusDuplicateAlertModal() {
    // const allBackgroundElements = document.querySelectorAll('.container, [tabindex="0"]')
    var tickBtn = document.getElementById('firstelement')
    var closeBtn = document.getElementById('lastelement')
    document.addEventListener('keydown', (e) => {
      if(document.getElementById('firstelement')){
        tickBtn = document.getElementById('firstelement')
      }else{
        tickBtn = document.getElementById('element-two')
      }
      closeBtn = document.getElementById('lastelement')
      if (document.getElementById("continueCancelBtn")) {
          tickBtn = document.getElementById('continueCancelBtn');
          closeBtn = document.getElementById('lastelement');
      }
      if (e.target === closeBtn) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          tickBtn.focus()
        } else if (e.keyCode === 9) {
          e.preventDefault();
          tickBtn.focus()
        }
      }
    })
  }

}

