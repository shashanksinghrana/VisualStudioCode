import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
  OnDestroy,
  ElementRef,
  Output,
  EventEmitter,
  ViewContainerRef,
  Input,
  AfterViewInit,
  Renderer2
} from '@angular/core';
import { Subscription } from 'rxjs';

import { TypeAheadEventService } from './../../../../services/events/type-ahead/type-ahead-event.service';
import { TypeAheadModel } from '../../../../models/type-ahead/type-ahead.model';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalEventService } from '../../../../services/events/modal/modal-event.service';
import { CharKeyCodes } from '../../../../enums/characters/character-keycodes.enum';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { TypeAheadDisplayModel } from '../../../../models/type-ahead/type-ahead-display';
import { TypeAheadPersistService } from '../../../../services/persist/type-ahead/type-ahead-persist.service';
import { EmptyIfNull } from '../../../../utils/strings/empty-if-null';
import { TypeAheadDisplayResultModel } from '../../../../models/type-ahead/type-ahead-display-result.model';
import { TypeAheadService } from '../../../../services/http/type-ahead/type-ahead.service';
import { ToasterService } from '../../../../services/toaster/toaster.service';
import { ToastsManager } from 'ng2-toastr';
import { TypeAheadSaveModel } from '../../../../models/type-ahead/type-ahead-save.model';
import { AddAliasAKAModel } from '../../../../models/type-ahead/aka/add-alias-aka.model';
import { AddAliasService } from '../../../../services/http/type-ahead/aka/add-alias.service';
import { AddAliasModel } from '../../../../models/type-ahead/aka/add-alias.model';
import { AccentedCharsModel } from './../../../../models/accented-chars/accented-chars.model';

const _title: string = 'Add New Company name';
const _showAddAlias: boolean = true;
const _displayNameAs: boolean = true;
const _allowOnlyOneAlias: boolean = false;
const _checkAddAsAlias: boolean = false;
const _typeAheadId: string = null;
const _hideTypeAhead: boolean = false;

@Component({
  selector: 'c2c-type-ahead-company-modal',
  templateUrl: './type-ahead-company-modal.component.html',
  styleUrls: ['./type-ahead-company-modal.component.scss'],
  providers: [TypeAheadService, ToastsManager, ToasterService, AddAliasService]
})
export class TypeAheadCompanyModalComponent implements OnInit, OnDestroy, AfterViewInit {

  private bsModal: NgbModalRef;
  private noResultsSubscription: Subscription;
  public showCloseMessage: boolean;
  public addCompanyForm: FormGroup;
  public isModalOpen: boolean = false;
  public isSaving: boolean  = false;
  public showAliasCurrentName: boolean;
  public showAddName: boolean = true;
  public showAlias: boolean;
  public roleIsPerson: boolean = true;
  public disabledTypeAhead: boolean = false;
  public currentDisplayData: TypeAheadDisplayModel;
  private userRoleType: string;
  protected selectedTypeAheadRecord: TypeAheadModel;
  public noResultsValues: TypeAheadModel;
  public typeAheadDataService: any;
  private entityNameRef: ElementRef;
  private _companySaveRes: object;
  public showCurrentNameError: boolean;
  @ViewChild('addCompanyModal') noResultsForm: TemplateRef<any>;

  @Output() saveCompanyNameEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() modalSaved = new EventEmitter<any>();
  @Output() modalSavedAlias = new EventEmitter<any>();

  @Input() modalName: string = '';
  @Input() editButton: boolean = false;
  @Input() listForCurrentName: string = '';
  @Input() clearTypeAheadValue: boolean = true;
  @Input() focusTypeAhead: boolean = true;
  @Output() onEditButton: EventEmitter<any> = new EventEmitter();
  @Output() onCancelModal = new EventEmitter<any>();

  @Input() fieldName: string = 'Company';

  public typeAheadCompanyModalConfig: Object = {
    title: _title,
    showAddAlias: _showAddAlias,
    displayNameAs: _displayNameAs,
    allowOnlyOneAlias: _allowOnlyOneAlias,
    checkAddAsAlias: _checkAddAsAlias,
    typeAheadId: _typeAheadId,
    hideTypeAhead: _hideTypeAhead
  };

  @Input() public typeAheadDisplayDataResults: TypeAheadDisplayResultModel = {
    filterType: 'COMPANY_ONLY',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'partyType'],
      display: '`(alias for ${data.primaryName})`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'ssnEndChars']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this.typeAheadService,
      get: 'getCompany'
    }
  };
  private aliasSelecteData: any;
  /** TAL-3199 Clarification */
  @Input() ownAccentedModalApi: boolean = false;
  @Output() accentedModalCharEvent: EventEmitter<any> = new EventEmitter<any>();

  public accentedModalCharsVal: AccentedCharsModel[] = [];
  @Input()
  set setAccentedModalChars(vals: AccentedCharsModel[]) {

    if (this.ownAccentedModalApi && (vals && vals.length)) {
      this.accentedModalCharsVal = vals;
    }
  }
  get setAccentedModalChars(): AccentedCharsModel[] { return this.accentedModalCharsVal; }
  constructor(private typeAheadEventService: TypeAheadEventService,
    private modalService: NgbModal,
    protected typeAheadService: TypeAheadService,
    private modalEventService: ModalEventService,
    private typeAheadPersistService: TypeAheadPersistService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    protected addAliasService: AddAliasService,
    protected toasterService: ToasterService,
    private renderer: Renderer2) {

    this.toaster.setRootViewContainerRef(vcr);

    this.successCB = this.successCB.bind(this);
    this.failureCB = this.failureCB.bind(this);

    this.noResultsSubscription = this.typeAheadEventService.getTypeAheadCompanyNoResults()
      .subscribe(item => {
        this.typeAheadNoResultsFound(item);
      });

    this.typeAheadEventService.getModalCompanyConfig().subscribe(config => {
      if (config['modalName'] === this.modalName) {
        this.typeAheadCompanyModalConfig = config;
        if (this.typeAheadCompanyModalConfig['modalName'] === this.modalName) {
          if (!this.typeAheadCompanyModalConfig['allowOnlyOneAlias']) {
            return;
          }
          if (this.aliasSelecteData && this.typeAheadCompanyModalConfig['checkAddAsAlias']) {
            this.disabledTypeAhead = true;
          } else {
            this.disabledTypeAhead = false;
          }
        }
      }
    });
  }


  ngOnInit() {
    // service needed for typeAhead data
    this.typeAheadDataService = this.typeAheadService;

    this.addCompanyForm = new FormGroup({
      aliasCheckbox: new FormControl(false),
      companyName: new FormControl(null, { updateOn: 'blur',
                                           validators: [this.noWhiteSpaceValidator, Validators.required, Validators.maxLength(100)] }),
      aliasCompanyName: new FormControl(null, { updateOn: 'blur',
                                                validators: [this.noWhiteSpaceValidator, Validators.required, Validators.maxLength(100)] }),
      typeAheadCompany: new FormControl(null)
    });
    this.onChanges();
    this.TrapFocusDuplicateAlertModal();
  }

  ngAfterViewInit() {
    this.typeAheadEventService.getCurrentItemSelected().subscribe(item => {
      if (this.listForCurrentName === item.listName) {
        this.aliasSelecteData = item.item;
      }
    });
  }

  ngOnDestroy() {
    this.noResultsSubscription.unsubscribe();
  }

  private onChanges(): void {

    const companyName: AbstractControl = this.addCompanyForm.get('companyName');

    // listen for form changes
    this.addCompanyForm.valueChanges.subscribe(val => {
      this.typeAheadEventService.displayData(this.displayNameData(val));
    });
  }
  // build display name data
  private displayNameData(val: any): TypeAheadDisplayModel {
    const displayData: TypeAheadDisplayModel = new TypeAheadDisplayModel();
    const companyNameEdit = val.companyName ? val.companyName : this.addCompanyForm.get('companyName').value;

    displayData.companyName = !this.showAlias ? val.companyName : val.aliasCompanyName;
    displayData.isPerson = false;

    if (this.showAlias) {
      if (val.companyName) {
        displayData.primaryName = val.companyName;
      } else if (val.typeAheadCompany && val.typeAheadCompany.entityName) {
        displayData.primaryName = val.typeAheadCompany.entityName;
      } else {
        displayData.primaryName = companyNameEdit;
      }

    }
    this.currentDisplayData = displayData;
    return displayData;
  }

  // EventEmitter when no typeAhead results are found, from main form
  private typeAheadNoResultsFound(item: TypeAheadModel): void {
    const displayData: TypeAheadDisplayModel = new TypeAheadDisplayModel();
    this.open(this.noResultsForm, item);
    this.noResultsValues = item;
    this.showAlias = this.typeAheadCompanyModalConfig['checkAddAsAlias'] || false;

    if (this.showAlias && this.aliasSelecteData) {
      this.selectedTypeAheadRecord = this.aliasSelecteData;
      this.addCompanyForm.controls.aliasCheckbox.setValue(true);
      this.addCompanyForm.controls.aliasCheckbox.disable();
      this.updateAliasFields(item);
      this.buildCompanyNameString(this.aliasSelecteData);
      this.addCompanyForm.get('companyName').disable();
      this.updateAddNameFields(this.aliasSelecteData);
      this.disabledTypeAhead = true;
      displayData.companyName = item.entityName;
      displayData.primaryName = this.aliasSelecteData.entityName;
      this.currentDisplayData = displayData;
    } else {
      this.showAlias = false;
      this.updateAddNameFields(item);
      this.updateAliasFields(item);
    }
  }

  // no results from the typeAhead search. Emitted event comes from typeAhead component class
  public noTypeAheadResultsFromMainForm(val: TypeAheadDisplayModel) {
    if (val) {
      this.showAliasCurrentName = true;
      setTimeout(() => {
        // have to do this to get the reference
        this.setFieldFocus(this.entityNameRef);

        const noResultsFromAliasSearch: TypeAheadModel = new TypeAheadModel();
        noResultsFromAliasSearch.entityName = val.entityName;
        this.updateAddNameFields(noResultsFromAliasSearch);
      }, 100);
    }
  }

  public clearTypeAhead(): void {
    this.resetAddNameFields();
    this.showAliasCurrentName = false;
  }

  private updateAliasFields(val: TypeAheadModel): void {

    // set values for alias fields
    this.addCompanyForm.get('aliasCompanyName').setValue(val.entityName);

    // dirty flag doesn't get set when auto populating, so forcing it here.
    this.addCompanyForm.markAsDirty();
  }

  private updateAddNameFields(val: TypeAheadModel): void {
    // set values for add name fields
    this.userRoleType = this.typeAheadPersistService.getUserRole();

    this.addCompanyForm.get('companyName').setValue(val.entityName);

    // dirty flag doesn't get set when auto populating, so forcing it here.
    this.addCompanyForm.markAsDirty();
  }

  // create company name from other values
  private buildCompanyNameString(item: any): void {
    this.addCompanyForm.get('companyName').setValue(item.entityName);
  }

  private open(modal: TemplateRef<any>, nameObj: any): void {
    if (this.typeAheadCompanyModalConfig['modalName'] === this.modalName && this.typeAheadCompanyModalConfig['modalOpen']) {
      if (this.isModalOpen) {
        return;
      }
      this.isModalOpen = true;
      this.bsModal = this.modalService.open(modal, {
        size: 'lg',
        backdrop: 'static',
        windowClass: 'modal-position',
        keyboard: false
      });
      this.addCompanyForm.enable();
    }
  }

  public closeModal() {
    this.resetForm();
    this.bsModal.dismiss('close');
    if (this.focusTypeAhead) {
      this.renderer.selectRootElement('#typeAheadField').focus();
    }
    if (this.clearTypeAheadValue) {
      this.renderer.selectRootElement('#typeAheadField').value = '';
    }
    this.typeAheadCompanyModalConfig['modalOpen'] = false;
    this.accentedModalCharsVal = [];
    this.modalEventService.closeModal(true);
  }

  public showCloseMessageFun(): string {
    if (this.showCloseMessage) {
      return 'block';
    } else {
      return 'none';
    }
  }

  public openCloseConfirmation() {
    this.showCloseMessage = !this.addCompanyForm.pristine || this.addCompanyForm.dirty;
    this.showCloseMessage = this.addCompanyForm.dirty;

    if (!this.showCloseMessage) {
      this.resetForm();
      this.closeModal();
    }

    // angular is stupid and makes setting focus difficult, so have to do this junk
    window.setTimeout(() => {
      const elem = document.getElementById('continueCancelBtn');
      if (elem) {
        elem.focus();
      }
    }, 100);
  }

  public closeConfirmationYes() {
    this.resetForm();
    this.closeModal();
    this.onCancelModal.emit();
  }

  public closeConfirmationNo() {
    this.showCloseMessage = false;
  }

  public enterKey(evt: KeyboardEvent): void {
    if (evt.keyCode !== CharKeyCodes.ENTER) {
      return;
    }
  }

  private noWhiteSpaceValidator(cntrl: FormControl) {
    const isWhiteSpace: boolean = (cntrl.value || '').trim().length === 0;
    const isValid = !isWhiteSpace;

    return isValid ? null : { 'whitespace': true };
  }

  public escKeyPressed(event) {
    this.openCloseConfirmation();
  }

  /**Remove whitespace from last name formControls
   * This should be more dynamic
   */
  public trimWhiteSpace(control: FormControl, form?: FormGroup): void {
    this.addCompanyForm.controls.aliasFields['controls'].aliasentityName.setValue(
      this.removespace(this.addCompanyForm.controls.aliasFields['controls'].aliasentityName.value)
    );

    this.addCompanyForm.controls.editableFields['controls'].entityName.setValue(
      this.removespace(this.addCompanyForm.controls.editableFields['controls'].entityName.value)
    );
  }

  private removespace(val: string): string {
    return val.trim();
  }

  // toggle alias fields
  public addAsAlias(evt: Event): void {
    this.showAlias = !this.showAlias;

    if (this.showAlias) {
      this.showAddName = false;
      this.addCompanyForm.get('aliasCompanyName').setValue(this.addCompanyForm.get('companyName').value);
      this.setEmptyEditFields();
    } else {
      this.showAddName = true;
      this.showAliasCurrentName = false;
      this.addCompanyForm.get('companyName').setValue(this.addCompanyForm.get('aliasCompanyName').value);
      this.setEmptyAliasFields();
    }
    this.addCompanyForm.markAsDirty();
  }

  private setEmptyEditFields() {
    this.addCompanyForm.get('companyName').setValue('');
  }

  private setEmptyAliasFields() {
    this.addCompanyForm.get('aliasCompanyName').setValue('');
  }

  protected resetForm(): void {
    this.typeAheadEventService.displayData(true);
    this.showCloseMessage = false;
    this.roleIsPerson = true;
    this.isModalOpen = false;
    this.isSaving = false;
    this.showAlias = false;
    this.showAddName = true;
    this.showAliasCurrentName = false;
    // reset these values back to their defaults
    this.resetAddNameFields();
    this.typeAheadEventService.clearTypeAheadFields();
    this.selectedTypeAheadRecord = null;
  }

  private resetAddNameFields() {
    this.addCompanyForm.reset();
  }

  // Output() event when item is selected from typeAhead
  public modalTypeAheadSelectedItem(val: TypeAheadModel): void {
    this.showAliasCurrentName = true;
    this.selectedTypeAheadRecord = val;
    this.updateAddNameFields(val);

    setTimeout(() => {
      // have to do this to get the reference
      this.setFieldFocus(this.entityNameRef);
    }, 100);
  }

  private setFieldFocus(ele: ElementRef) {
    if (!ele) {
      return;
    }
    ele.nativeElement.focus();
  }

  public save(evt: Event): void {
   
    if (!this.addCompanyForm.get('aliasCompanyName').value) {
      this.addCompanyForm.get('aliasCompanyName').disable();
    }
    if (this.addCompanyForm.invalid || this.isSaving) {
      if (this.showAlias && (this.addCompanyForm.get('companyName').invalid
        || this.addCompanyForm.get('aliasCompanyName').invalid)) {

        this.showCurrentNameError = true;
        setTimeout(() => {
          this.setFieldFocus(this.entityNameRef);
        }, 100);
        return;
      } else {
      //TAL-3546:Unable to save Company name after modifying it in Add as New pop-up
      //commenting the return not to seize excecution in above scenario.
      // return;
      }
    }
    this.showCurrentNameError = false;
    const companyData = {
      formValues: this.addCompanyForm.value,
      typeAheadCurrentName: this.selectedTypeAheadRecord || {}
    };
    this.isSaving = true;
    this.addCompanyForm.disable();
    this.saveCompany(companyData, this.showAlias);
  }

  private saveCompany(vals: any, aliasName: boolean): void {
    if (!aliasName) {
      this.modalSaved.emit(vals);
    } else {
      this.modalSavedAlias.emit(vals);
    }
  }

  // success Callback
  public successCB(res) {
    this.sendNewNameToList(res);
    this.saveNotification(true, this.notificationMessage('Name saved', 'Success'));
  }

  // failure Callback
  public failureCB(errMessage) {
    this.saveNotification(false, this.notificationMessage('Error, ' + errMessage, 'Oops!'));
  }

  private sendNewNameToList(val: any): void {
    const selectedName: TypeAheadModel = new TypeAheadModel();

    selectedName.entityName = val['name'].entity;
    selectedName.partyId = val['partyId'];
    selectedName.typeAheadDisplayName = val['displayName'] || val['name'].entity;
    selectedName.nameId = val['name'].nameId;

    if (this.typeAheadCompanyModalConfig['typeAheadId']) {
      this.saveCompanyNameEvent.emit({ nameAdded: selectedName, typeAheadId: this.typeAheadCompanyModalConfig['typeAheadId'] });
    } else {
      this.saveCompanyNameEvent.emit(selectedName);
    }
  }

  // create save notification message
  private notificationMessage(message: string, title: string): object {
    return {
      message: message,
      title: title
    };
  }

  // save notification with toaster
  private saveNotification(success: boolean, message: object): void {
    if (success) {
      this.toasterService.success(message['message'], message['title']);
      setTimeout(() => {
        this.closeModal();
      }, 100);
    } else {
      this.toasterService.error(message['message'], message['title']);
      if (this.aliasSelecteData) {
        this.addCompanyForm.enable();
      }
      this.isSaving = false;
    }
  }

  public edit() {
    if (this.addCompanyForm.invalid) {
      if (this.showAlias && (this.addCompanyForm.get('companyName').invalid || this.addCompanyForm.get('aliasCompanyName').invalid)) {
        this.showCurrentNameError = true;
        this.setFieldFocus(this.entityNameRef);
        return;
      }
    }
    this.showCurrentNameError = false;
    this.onEditButton.emit();

  }

  public accentedModalService(char: any): void {
    this.accentedModalCharEvent.emit(char);
  }


    /** Focus trap inside duplicate alert popup is the popup is available. author rahul 
   **/
  TrapFocusDuplicateAlertModal() {
    // const allBackgroundElements = document.querySelectorAll('.container, [tabindex="0"]')
    if(document.getElementById("lastelement-alias")){
      var lastelement = document.getElementById('lastelement-alias')
    }else{
      var lastelement = document.getElementById('lastelement')
    }
    
    var firstelement = document.getElementById('firstelement')
    document.addEventListener('keydown', (e) => {
      if(document.getElementById('firstelement')){
        firstelement = document.getElementById('firstelement')
      }else{
        firstelement = document.getElementById('element-two')
      }
      if(document.getElementById("lastelement-alias")){
        var lastelement = document.getElementById('lastelement-alias')
      }else{
        var lastelement = document.getElementById('lastelement')
      }
      if (document.getElementById("continueCancelBtn")) {
        firstelement = document.getElementById('continueCancelBtn');
          // closeBtn = document.getElementById('firstelement');
      }
      if (e.target === lastelement) {
        if (e.shiftKey && e.keyCode === 9) {
          e.preventDefault()
          firstelement.focus()
        } else if (e.keyCode === 9) {
          e.preventDefault();
          firstelement.focus()
        }
      } 
      // else if (e.target === tickBtn) {
      //   if (e.shiftKey && e.keyCode === 9) {
      //     e.preventDefault()
      //     closeBtn.focus()
      //   }else if (e.keyCode === 9) {
      //     e.preventDefault();
      //     closeBtn.focus()
      //   }
      // }
    })
  }
}
