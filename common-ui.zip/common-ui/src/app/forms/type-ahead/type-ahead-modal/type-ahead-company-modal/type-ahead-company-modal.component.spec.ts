import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TypeAheadCompanyModalComponent } from './type-ahead-company-modal.component';

describe('TypeAheadCompanyModalComponent', () => {
  let component: TypeAheadCompanyModalComponent;
  let fixture: ComponentFixture<TypeAheadCompanyModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TypeAheadCompanyModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TypeAheadCompanyModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
