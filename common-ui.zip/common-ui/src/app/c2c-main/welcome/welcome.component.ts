import { Component, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalEventService } from '../../services/events/modal/modal-event.service';
import { DeleteConfirmationService } from '../../services/events/modal/delete-confirmation.service';
import { ModalGenericComponent } from '../../modal/generic/modal-generic.component';
import { ModalDeleteConfirmationComponent }  from '../../modal/delete-confirmation/modal-delete-confirmation.component';
import { ModalApplicableNotApplicableComponent } from '../../modal/applicable-notapplicable/modal-applicable-notapplicable.component';
import { ApplicableNotApplicableService } from '../../services/events/modal/modal-applicable-notapplicable.service';

/**
 * The Welcome Component
 *
 * This is just a component for displaying links to each Common Component.
 * The links help provide a sandbox for creating/editing/and demoing components.
 */
@Component({
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent {
  public content: string = 'Test content';

  /** Components list for creating links to each component */
  public structuralComponents: Object[] = [
    {title: 'Header', link: 'header'},
    {title: 'PowerSearch', link: 'powersearch'},
    {title: 'Sidebar', link: 'sidebar'},
    {title: 'Wizard', link: 'wizard/1/nameProjectDetails'}
  ];

  public elementComponents: Object[] = [
    {title: 'Audit', link: 'audit'},
    {title: 'Buttons', link: 'buttons'},
    {title: 'Grid', link: 'grid'},
    {title: 'Image Uploader', link: 'imageUploader'},
    {title: 'File Uploader', link: 'fileUploader'},
    {title: 'Loading Spinner', link: 'loadingSpinner'},
    {title: 'Type Ahead', link: 'typeAhead'},
    {title: 'People', link: 'people'},
    {title: 'Companies', link: 'companies'},
    {title: 'Talent', link: 'talent'}
  ];

  public formComponents: Object[] = [
    {title: 'Checkbox', link: 'checkbox'},
    {title: 'JQDatepicker', link:'formJQDatepickerComponent'},
    {title: 'Datepicker', link: 'datepicker'},
    {title: 'Datepicker (Reactive)', link: 'datepicker-reactive'},
    {title: 'Dropdown', link: 'dropdown'},
    {title: 'Dropdown (Reactive)', link: 'dropdown-reactive'},
    {title: 'Input', link: 'input'},
    {title: 'Label', link: 'label'},
    {title: 'Note', link: 'note'},
    {title: 'Radio', link: 'radioButton'},
    {title: 'Dropdown-TypeAhead', link: 'dropdDownTypeAhead'}
  ];

  @ViewChild('genericModal') public genericModal: ModalGenericComponent;
  @ViewChild('deleteConfirmationModal') public deleteConfModal: ModalDeleteConfirmationComponent;
  @ViewChild('applicableNotApplicableModal') public applicableNotApplicableModal: ModalApplicableNotApplicableComponent;

  /**
   * Constructor for the WelcomeComponent.
   */
  constructor(private modalService: NgbModal, private modalEventService: ModalEventService, private deleteEventService : DeleteConfirmationService, private applicableService: ApplicableNotApplicableService ) { }

  public openModal(content) {
    this.modalService.open(content);
  }

  public openGenericModal() {
    this.genericModal.open();
  }

  public modalClosedEvent(event) {
  }

  public openDeleteConfirmationModal(){
    this.deleteEventService.openModal();
  }

  public openApplicableNotApplicableModal() {
    this.applicableService.openModal();
  }

}
