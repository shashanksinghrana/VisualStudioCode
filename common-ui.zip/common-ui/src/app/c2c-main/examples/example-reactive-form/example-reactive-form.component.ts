import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HttpParams, HttpClient } from '@angular/common/http';
import { RadioButtonModel } from '../../../models/radio-button/radio-button.model';
import { DropdownModel } from '../../../models/dropdown/dropdown.model';
import { TypeAheadDisplayResultModel } from '../../../models/type-ahead/type-ahead-display-result.model';
import { UrlResolverService } from '../../../services/non-http-data/url-resolver.service';
import { LookupModel } from '../../../models/lookup.model';

@Component({
  selector: 'c2c-example-reactive-form',
  templateUrl: './example-reactive-form.component.html',
  styleUrls: ['./example-reactive-form.component.scss']
})
export class ExampleReactiveFormComponent implements OnInit {
  public exampleForm: FormGroup;
  public radioOptions: RadioButtonModel =
    new RadioButtonModel('thisRadioTitle', [
      {title: 'Male', checkedByDefault: false, disabled: false, showTitle: true},
      {title: 'Female', checkedByDefault: false, disabled: false, showTitle: true}
    ]);
  public dropdownOptions: DropdownModel = new DropdownModel('', '', '', '', []);

  public displayLastNameData: TypeAheadDisplayResultModel = {
    primaryDisplayColumn: 'lastName',
    secondaryDisplay: {
      secondaryColumns: [],
      display: ''
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: [],
      PRODUCTION: [],
      CASTING: [],
      default: []
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getLastNameTypeahead'
    }
  };

  private disabled: boolean = false;

  constructor(private fb: FormBuilder, private http: HttpClient, private urlResolverService: UrlResolverService) { }

  public ngOnInit(): void {
    const lookupType = new LookupModel(4, 4, 'Product Owner', 'POSITION');

    this.dropdownOptions.options = [
      new LookupModel(1, 1, 'Business Analyst', 'POSITION'),
      new LookupModel(2, 2, 'Quality Assurance', 'POSITION'),
      new LookupModel(3, 3, 'Software Engineer', 'POSITION'),
      new LookupModel(4, 4, 'Product Owner', 'POSITION'),
    ];

    this.exampleForm = this.fb.group({
      'firstName': this.fb.control('Test', Validators.required),
      'lastName': this.fb.control(null, Validators.required),
      'dob': this.fb.control(null, Validators.required),
      'active': this.fb.control(true),
      'notes': this.fb.control(null),
      'rate': this.fb.control(50950, Validators.required),
      'gender': this.fb.control('male'),
      'position': this.fb.control(lookupType)
    });
  }

  public onSubmit(): void {
    if (this.exampleForm.valid) {
      alert('Form was successfully submitted!');
    } else {
      this.validateFormFields(this.exampleForm);
    }
  }

  public toggleState(): void {
    Object.keys(this.exampleForm.controls).forEach((field) => {
      if (this.disabled) {
        this.exampleForm.controls[field].enable();
      } else {
        this.exampleForm.controls[field].disable();
      }
    });
    this.disabled = !this.disabled;
  }

  public isInvalid(field): boolean {
    return this.exampleForm.get(field).invalid && this.exampleForm.get(field).touched;
  }

  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  public selectedLastName(event) {
  }

  public getLastNameTypeahead(searchTerm: string, returnedRecordCount: string) {
    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', returnedRecordCount);
    return this.http.get('http://dev.concept2alize.com/fc/dev1/fc/api/typeAhead/productionCompanies', {params: params})
      .map((res: any[]) => {
        return this.lastNameData();
      });
  }


  private lastNameData() {
    return [
      {
        'partyId': 1632338,
        'partyType': 'TALENT',
        'firstName': 'Ian',
        'lastName': 'Grody',
        'entityName': 'Ian Grody',
        'ssnEndChars': '0886',
        'occupation': null,
        'agency': null,
        'typeAheadDisplayName': 'Grody, Ian',
        'primaryName': null
      },
      {
        'partyId': 1494335,
        'partyType': 'TALENT_AKA',
        'firstName': 'Bob E.',
        'lastName': 'Bailey',
        'entityName': 'Bailey, Bob E.',
        'ssnEndChars': '9091',
        'occupation': null,
        'agency': null,
        'typeAheadDisplayName': 'Bailey, Bob E.',
        'primaryName': 'Bob E. Bailey'
      },
      {
        'partyId': 1518096,
        'partyType': 'TALENT_AKA',
        'firstName': 'Shan Daniel',
        'lastName': 'Hurst',
        'entityName': 'Hurst, Shan Daniel',
        'ssnEndChars': '5488',
        'occupation': null,
        'agency': null,
        'typeAheadDisplayName': 'Hurst, Shan Daniel',
        'primaryName': 'Shan Daniel Hurst'
      },
      {
        'partyId': 1519243,
        'partyType': 'TALENT',
        'firstName': 'Kim',
        'lastName': 'Jee-woon',
        'entityName': 'Kim Jee-woon',
        'ssnEndChars': '2911',
        'occupation': null,
        'agency': null,
        'typeAheadDisplayName': 'Jee-woon, Kim',
        'primaryName': null
      },
      {
        'partyId': 1599472,
        'partyType': 'TALENT',
        'firstName': 'Jeff',
        'lastName': 'Peters',
        'entityName': 'Jeff Peters',
        'ssnEndChars': '6273',
        'occupation': null,
        'agency': null,
        'typeAheadDisplayName': 'Peters, Jeff',
        'primaryName': null
      }
    ];
  }
}
