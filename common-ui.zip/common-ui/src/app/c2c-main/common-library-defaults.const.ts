import { ColumnDefModel } from '../models/grid/column-def/column-def.model';
import { GridPageOptionsModel } from '../models/grid/grid-page-options.model';
import { SidebarModel } from '../models/sidebar/sidebar.model';
import { AuditModel } from '../models/audit/audit.model';
import { ImageUploaderModel } from '../models/image-uploader/imageUploader.model';
import { DropdownModel } from '../models/dropdown/dropdown.model';
import { RadioButtonModel } from '../models/radio-button/radio-button.model';
import { CheckboxModel } from '../models/checkbox/checkbox.model';
import { GridImageParamsModel } from '../models/grid/params/grid-image-params.model';
import { GridLinkParamsModel } from '../models/grid/params/grid-link-params.model';
import { GridImageDefModel } from '../models/grid/column-def/grid-image-def.model';
import { GridListDefModel } from '../models/grid/column-def/grid-list-def.model';
import { GridListParamsModel } from '../models/grid/params/grid-list-params.model';
import { GridLinkDefModel } from '../models/grid/column-def/grid-link-def.model';
import { GridTitlesDefModel } from '../models/grid/column-def/grid-titles-def.model';
import { GridTitlesParamsModel } from '../models/grid/params/grid-titles-params.model';
import { GridIconDefModel } from '../models/grid/column-def/grid-icon-def.model';
import { GridIconParamsModel } from '../models/grid/params/grid-icon-params.model';
import { GridPaginationModel } from '../models/grid/grid-pagination.model';
import { GridServerSideParamsModel } from '../models/grid/grid-server-side-params.model';
import { WizardStatusEnum } from '../enums/structural/wizard-status.enum';
import { LookupModel } from '../models/lookup.model';
import { PowersearchChoiceModel } from '../models/powersearch/powersearch-choice.model';
import { GridCheckBoxDefModel } from '../models/grid/column-def/grid-checkbox-def.model';
import { GridCheckBoxParamsModel } from '../models/grid/params/grid-checkbox-params.model';
import { GridCarouselDefModel } from '../models/grid/column-def/grid-carousel-def.model';
import { GridCarouselParamsModel } from '../models/grid/params/grid-carousel-params.model';
import { GridDropdownEditDefModel } from '../models/grid/column-def/grid-dropdown-edit-def.model';
import { GridLargeTextEditDefModel } from '../models/grid/column-def/grid-large-text-edit-def.model';
import { GridDateTimePickerDefModel } from '../models/grid/column-def/grid-datetime-picker.model';
import { GridDynamicDropdownDefModel } from '../models/grid/column-def/grid-dynamic-dropdown-def.model';
import { GridDynamicDropdownParamsModel } from '../models/grid/params/grid-dynamic-dropdown-params.model';
import { GridTypeaheadDefModel } from '../models/grid/column-def/grid-typeahead.model';
import { GridTypeaheadDropdownDefModel } from '../models/grid/column-def/grid-typeahead-dropdown-def.model';
// @dynamic

/**
 * The Common Library Defaults
 *
 * Defaults for the Common Components in the library.
 * This is just test data, and should not be exported with the package.
 */
export class Defaults {
  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                  The Sidebar Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_NAV_ITEMS: Array<SidebarModel> = [
    new SidebarModel('HOME', 1.0, 'testLink1', true),
    new SidebarModel('TEST SUB LINK', 1.1, 'testSubLink', false),
    new SidebarModel('TALENT', 2.0, 'testLinkTwo', true),
    new SidebarModel('REPRESENTATION', 3.0, 'testLinkThree', true),
    new SidebarModel('POWER SEARCH', 4.0, 'testLinkFour', true),
    new SidebarModel('REPORTS', 5.0, 'testLinkThree', true)
  ];

  public static readonly DEFAULT_VERSION: string = '1.0.2-DEFAULT';

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                   The Header Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_MODULE_NAME: string = 'C2C Common';

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                  The Form Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_INPUT_PLACEHOLDER: string = 'C2C Input Placeholder';
  public static readonly DEFAULT_LABEL_VALUE: string = 'C2C Label';

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                  The JQuery form datepicker Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_JQ_INPUT_PLACEHOLDER: string = 'MM/DD/YYYY';
  public static readonly DEFAULT_JQ_DATE_FORMAT: string = 'MM/DD/YYYY';

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                  The Audit Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_AUDIT: AuditModel =
    new AuditModel('2018-05-05T14:08:00', 'C2CEnterUser', '2018-12-25T20:20:10', 'C2CUpdateUser');

  public static readonly DEFAULT_WIZARD_AUDIT: AuditModel =
    new AuditModel(null, null, '2018-01-01T01:01:01', 'C2CUpdateUser');

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                  The Image Uploader Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_IMAGEUPLOADER: ImageUploaderModel =
    new ImageUploaderModel('people', null);

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                   The Dropdown Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_DROPDOWN_OPTIONS: DropdownModel =
    new DropdownModel('', 'Default Title', '', '', [
      { value: 'Default Choice 1', route: '' },
      { value: 'Default Choice 2', route: '' },
      { value: 'Default Choice 3', route: '' }
    ]);

  /*
    /*
 * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
 *                   The Dropdown Type Ahead Defaults
 * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
 */
  public static readonly DEFAULT_DROPDOWN_TYPEAHEAD_OPTIONS: DropdownModel =
    new DropdownModel('', 'Default Title', '', '', [
      { value: 'Default Choice 1', route: '' },
      { value: 'Default Choice 2', route: '' },
      { value: 'Default Choice 3', route: '' }
    ]);

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                   The Radio Button Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_RADIO_BUTTON_OPTIONS: RadioButtonModel =
    new RadioButtonModel('thisRadioTitle', [
      { title: 'Option 1', checkedByDefault: false, disabled: false, showTitle: true },
      { title: 'Option 2', checkedByDefault: false, disabled: false, showTitle: true },
      { title: 'Option 3', checkedByDefault: false, disabled: false, showTitle: true },
      { title: 'checked by default', checkedByDefault: true, disabled: false, showTitle: true },
      { title: 'disabled by default', checkedByDefault: false, disabled: true, showTitle: true }
    ]);

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                   The Checkbox Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_CHECKBOX_OPTIONS: CheckboxModel =
    new CheckboxModel('thisId', 'thisName', [
      { value: 'v1', label: 'Value 1', checked: false, showTitle: true },
      { value: 'v2', label: 'Value 2', checked: false, showTitle: true },
      { value: 'v3', label: 'Value 3', checked: false, showTitle: true },
      { value: 'v4', label: 'Value 4 (checked by default)', checked: true, showTitle: true }
    ]);

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                  The Form List Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */

  public static readonly DEFAULT_LIST_HEADERS: Array<string> = ['Production Company', 'Union', 'Signatory', 'Title', 'Primary'];

  public static readonly DEFAULT_DATA_ELEMENTS: any[] = [
    {
      productionCompany: { type: 'input', value: 'Test 1' },
      union: { type: 'dropdown', value: 'Union' },
      signatory: { type: 'dropdown', value: 'John Doe' },
      title: { type: 'dropdown', value: 'Test Title 1' },
      primary: { type: 'radio', value: true }
    },
    {
      productionCompany: { type: 'input', value: 'Test 2' },
      union: { type: 'dropdown', value: 'Union' },
      signatory: { type: 'dropdown', value: 'John Doe' },
      title: { type: 'dropdown', value: 'Test Title 2' },
      primary: { type: 'radio', value: true }
    },
    {
      productionCompany: { type: 'input', value: 'Test 3' },
      union: { type: 'dropdown', value: 'Union' },
      signatory: { type: 'dropdown', value: 'John Doe' },
      title: { type: 'dropdown', value: 'Test Title 3' },
      primary: { type: 'radio', value: true }
    },
  ];

  public static readonly DEFAULT_DATA_OBJECT: any = {
    productionCompany: { type: 'input', value: 'Test 4' },
    union: { type: 'dropdown', value: 'Non-union' },
    signatory: { type: 'dropdown', value: 'Jane Doe' },
    title: { type: 'dropdown', value: 'Test Title 4' },
    primary: { type: 'radio', value: true }
  };

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                   The Wizard Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_WIZARD_TITLE: string = 'C2C Wizard Title';

  public static readonly DEFAULT_WIZARD_SUBTITLE: Array<string> = ['Title Project', '01/01/2018', 'Performer Name'];

  public static readonly DEFAULT_WIZARD_SECTIONS: any = [
    {
      page: 'Names / Project Details', status: new LookupModel(null,
        null,
        WizardStatusEnum.COMPLETE,
        'WIZARD_INDICATOR'), route: 'nameProjectDetails'
    },
    {
      page: 'Opening Paragraph', status: new LookupModel(null,
        null,
        WizardStatusEnum.COMPLETE,
        'WIZARD_INDICATOR'), route: 'openingParagraph'
    },
    { page: 'Loanout', status: new LookupModel(null, null, WizardStatusEnum.COMPLETE, 'WIZARD_INDICATOR'), route: 'loanout' },
    { page: 'Term', status: new LookupModel(null, null, WizardStatusEnum.NOT_APPLICABLE, 'WIZARD_INDICATOR'), route: 'term' },
    {
      page: 'Notices and Payments', status: new LookupModel(null,
        null,
        WizardStatusEnum.NOT_APPLICABLE,
        'WIZARD_INDICATOR'), route: 'noticesPayments'
    },
    { page: 'Guarantee', status: new LookupModel(null, null, WizardStatusEnum.INCOMPLETE, 'WIZARD_INDICATOR'), route: 'guarantee' },
    { page: 'Perqs', status: new LookupModel(), route: 'perqs' },
    { page: 'Other Terms', status: null, route: 'otherTerms' },
    { page: 'Fixed Compensation', status: new LookupModel(), route: 'fixedCompensation' },
    { page: 'Contingent Compensation', status: new LookupModel(), route: 'contingentCompensation' },
    { page: 'Credit', status: new LookupModel(), route: 'credit' },
    { page: 'Summary', status: new LookupModel(), route: 'summary' },
  ];

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                   The Powersearch Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */
  public static readonly DEFAULT_POWERSEARCH_UNIONS: any[] = [
    new LookupModel(1, 41, 'SAG', 'UNION'),
    new LookupModel(2, 42, 'UMEA', 'UNION'),
    new LookupModel(3, 43, 'EQUITY', 'UNION'),
    new LookupModel(4, 44, 'BAFTA', 'UNION'),
    new LookupModel(5, 45, 'AFTRA', 'UNION'),
    new LookupModel(6, 46, 'ABRA CADABRA', 'UNION'),
    new LookupModel(7, 47, 'NON-UNION', 'UNION'),
    new LookupModel(8, 48, 'ACTRA', 'UNION'),
    new LookupModel(9, 49, 'AZTRA', 'UNION'),
  ];

  public static readonly DEFAULT_POWERSEARCH_CHOICES: PowersearchChoiceModel[] = [
    new PowersearchChoiceModel('projectTitle', false, 'Project Title', 'typeahead', null),
    new PowersearchChoiceModel('union', false, 'Union', 'checklist', Defaults.DEFAULT_POWERSEARCH_UNIONS),
    new PowersearchChoiceModel('performer', false, 'Performer', 'typeahead', null),
    new PowersearchChoiceModel('billing', false, 'Billing', 'typeahead', null),
    new PowersearchChoiceModel('compensation', false, 'Compensation', 'typeahead', null)
  ];

  public static readonly DEFAULT_POWERSEARCH_DATE_RANGES: LookupModel[] = [
    new LookupModel(1, 1, 'Past 30 Days', 'POWERSEARCH_DATE_RANGE'),
    new LookupModel(2, 2, 'Past 60 Days', 'POWERSEARCH_DATE_RANGE'),
    new LookupModel(3, 3, 'Past 90 Days', 'POWERSEARCH_DATE_RANGE'),
    new LookupModel(4, 4, 'Past 180 Days', 'POWERSEARCH_DATE_RANGE'),
    new LookupModel(5, 5, 'All', 'POWERSEARCH_DATE_RANGE'),
    new LookupModel(6, 6, 'Custom Dates...', 'POWERSEARCH_DATE_RANGE')
  ];

  public static readonly DEFAULT_POWERSEARCH_PREV_SAVED_SEARCHES: LookupModel[] = [
    new LookupModel(1, 1, 'Example Saved Search 1', 'POWERSEARCH_SAVED_SEARCH'),
    new LookupModel(2, 2, 'Example Saved Search 2', 'POWERSEARCH_SAVED_SEARCH'),
    new LookupModel(3, 3, 'Example Saved Search 3', 'POWERSEARCH_SAVED_SEARCH')
  ];

  public static readonly DEFAULT_POWERSEARCH_REPORT_FORMS: LookupModel[] = [
    new LookupModel(1, 1, 'Example Report Form 1', 'POWERSEARCH_REPORT_FORM'),
    new LookupModel(2, 2, 'Example Report Form 2', 'POWERSEARCH_REPORT_FORM'),
    new LookupModel(3, 3, 'Example Report Form 3', 'POWERSEARCH_REPORT_FORM')
  ];

  public static readonly DEFAULT_EXPORT_AS: DropdownModel =
    new DropdownModel('', '', '', '', [
      { value: '', route: '', disabled: false },
      { value: 'PDF', route: '', disabled: false },
      { value: 'Excel', route: '', disabled: false },
      { value: 'Word', route: '', disabled: false }
    ]);

  public static readonly GRID_EXPORT_AS_OPTIONS: DropdownModel =
    new DropdownModel('', '', '', '', [
      { value: '', route: '', disabled: false },
      { value: 'PDF', route: '', disabled: true },
      { value: 'Excel', route: '', disabled: false },
      { value: 'Word', route: '', disabled: true }
    ]);

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *                   The Grid Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */

  public static readonly APPLICABLE_NOT_APPLICABLE_RADIO_OPTIONS: RadioButtonModel =
    new RadioButtonModel('thisRadioTitle', [
      { title: 'Skip and complete later?', checkedByDefault: false, disabled: false, showTitle: true },
      { title: 'Not Applicable', checkedByDefault: false, disabled: false, showTitle: true }
    ]);

  /*
   * ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
   *         The APPLICABLE NOT APPLICABLE Defaults
   * ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
   */

  public static readonly DEFAULT_PAGINATION: GridPaginationModel = new GridPaginationModel(0, 25, null, null);

  public static readonly DEFAULT_DATA_PARAMS: GridServerSideParamsModel = new GridServerSideParamsModel(
    { col: 'representativeType', direction: 'ASC' },
    [{ col: 'representativeName', text: 'a' }],
    { number: 2, size: 25 }
  );

  public static readonly DEFAULT_PAGE_OPTIONS: GridPageOptionsModel = new GridPageOptionsModel(
    true,
    'Default title',
    true,
    true,
    true,
    true,
    true,
    true,
    true
  );

  public static readonly DEFAULT_COL_DEFS_TALENT: ColumnDefModel[] = [
    new GridImageDefModel('Name', 'name',
      new GridImageParamsModel('image', {
        keys: ['firstName', 'middleName', 'lastName'],
        routing: new GridLinkParamsModel('/talent', 'partyId', 'summary')
      }, 'akaNames', { key: 'minor', replaceBooleanWith: 'K' }, true, null),
      { comparator: { name: 'propertyValueComparator', key: 'lastName' } }
    ),
    // new GridListDefModel('Projects', 'projectName',
    //   new GridListParamsModel({
    //     iterable: 'projects',
    //     keys: ['projectName']
    //   }, true, null, null, 'projectName'),
    // ),
    // new ColumnDefModel('ID #', 'ssn', null, { comparator: { name: 'numberComparator' }, formatter: 'ssnFormatter' }),
    new GridListDefModel('Representative', 'representative',
      new GridListParamsModel({
        iterable: 'representatives',
        keys: ['firstName', 'lastName']
      }, null, null, 'talents', 'lastName')
    ),
    new GridLinkDefModel('Company', 'company',
      new GridLinkParamsModel('/companyDetail', 'company.id', '', 'company.name')
    ),
    // new GridListDefModel('Company', 'company',
    //   new GridListParamsModel({
    //     iterable: 'representatives',
    //     keys: ['company.name']
    //   }, null, null, null, 'company.name')
    // ),
    new GridListDefModel('Talent', 'talentName',
      new GridListParamsModel({
        iterable: 'representatives',
        keys: ['talents.firstName', 'talents.lastName']
      }, null, null, null, null),
    ),
    new GridListDefModel('Agency', 'agencyName',
      new GridListParamsModel({
        iterable: 'representatives',
        keys: ['representatives.agencyName']
      }, false, true, null, 'performer.agencyName'),
      null,
      {
        filter: 'columnFilter', filterParams: {
          textFilter: false,
          columnKey: 'Agency',
          options: [
            { text: 'Attachment', value: true, checked: true },
            { text: 'No Attachment', value: false, checked: true }
          ]
        }
      }
    ),
    new GridIconDefModel('Icons', null,
      new GridIconParamsModel(
        { visible: true, action: () => { alert('Delete works!'); } },
        { visible: true, action: () => { alert('Edit works!'); } }
      ),
      { config: { suppressFilter: true, suppressSorting: true, width: 50 } }
    ),
    new GridCarouselDefModel('Carousel', null,
      new GridCarouselParamsModel(
        { visible: true, action: () => { alert('Delete works!'); } },
        { visible: true, action: () => { alert('Edit works!'); } }
      ),
      { config: { suppressFilter: true, suppressSorting: true, width: 450 } }
    ),
    new GridCheckBoxDefModel('Main Title', 'mainTitle',
      new GridCheckBoxParamsModel(
        { titleKey: 'billingText', showLabel: false, toggleEditMode: false }
      ),
      {
        comparator: { name: 'booleanComparator' },
        config: {
          width: 150, suppressFilter: true
        }
      },
    )
  ];

  public static readonly DEFAULT_ROW_DATA_TALENT: any =
    {
      'currentPageNumber': 1,
      'currentPageSize': 5,
      'pageSize': 5,
      'totalPages': 2,
      'totalRecords': 10,
      'content': [
        {
          'partyId': 123,
          'firstName': 'Leonardo',
          'middleName': 'William',
          'lastName': 'DiCaprio',
          'minor': false,
          'company': null,
          'mainTitle': true,
          'billingText': [
            'Guaranteed billing in the end titles to appear as',
            'Guaranteed billing on a separate card, in the main titles (if any), size equal to all other cast members receiving credit on a separate card.',
            'Guaranteed billing on a separate card, in the main titles (if any), in last position among cast members receiving credit, to read "and'
          ],
          'akaNames': [
            'Leo DiCaprio 1',
            'Leo DiCaprio 2',
            'Leo DiCaprio 3',
            'Leo DiCaprio 4',
            'Leo DiCaprio 5',
            'Leo DiCaprio 6',
            'Leo DiCaprio 7',
            'Leo DiCaprio 8',

          ],
          'image': 'https://upload.wikimedia.org/wikipedia/commons/2/25/Leonardo_DiCaprio_2014.jpg',
          'projects': [
            {
              'id': 1,
              'projectName': 'The Revenant'
            },
            {
              'id': 1,
              'projectName': 'Live By Night'
            },
            {
              'id': 1,
              'projectName': 'The Wolf of Wall Street'
            },
            {
              'id': 1,
              'projectName': 'The Great Gatsby'
            },
            {
              'id': 1,
              'projectName': 'Red Riding Hood'
            },
            {
              'id': 1,
              'projectName': 'The Titanic'
            },
            {
              'id': 1,
              'projectName': 'Inception'
            },
            {
              'id': 1,
              'projectName': 'The Departed'
            }
          ],
          'ssn': '4325',
          'representatives': [
            {
              'id': 1,
              'firstName': 'Rick',
              'lastName': 'Yourn',
              'company': {
                'id': 1,
                'name': 'LBI Entertainment'
              },
              'talents': [
                {
                  'id': 375443,
                  'firstName': 'Shannon',
                  'lastName': 'Bruns'
                },
                {
                  'id': 375443,
                  'firstName': 'Wayne',
                  'lastName': 'Bruns'
                },
                {
                  'id': 375443,
                  'firstName': 'Big Bear',
                  'lastName': 'Crazy-Person'
                }
              ],
              'agencyName': ['ROW6', 'ROW6', 'ROW99']
            },
            {
              'id': 2,
              'firstName': 'Uncle',
              'lastName': 'Grandpa',
              'company': {
                'id': 2,
                'name': 'Make Believe Studio'
              },
              'talents': [
                {
                  'id': 375443,
                  'firstName': 'Donnie',
                  'lastName': 'Smackface'
                }
              ],
              'agencyName': ['ROW2', 'ROW2A', 'ROW2B']
            }
          ]
        },
        // {
        //     'partyId': 124,
        //     'firstName': 'Scott',
        //     'middleName': 'Clint',
        //     'lastName': 'Diggs',
        //     'minor': true,
        //     'akaNames': [
        //     ],
        //     'image': 'http://images2.fanpop.com/images/photos/2700000/Taye-Diggs-taye-diggs-2709366-1923-2560.jpg',
        //     'projects': [
        //         {
        //             'id': 1,
        //             'projectName': 'Empire'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Murder in the First'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Opening Night'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'NCIS'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Rosewood'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Rosewood'
        //         }
        //     ],
        //     'ssn': '5467',
        //     'representatives': [
        //         {
        //             'id': 1,
        //             'firstName': 'Tom',
        //             'lastName': 'Bradenton',
        //             'company': {
        //                 'id': 1,
        //                 'name': 'GRC Creative'
        //             }
        //         },
        //         {
        //             'id': 1,
        //             'firstName': 'Rick',
        //             'lastName': 'Yourn',
        //             'company': {
        //                 'id': 1,
        //                 'name': 'LBI Entertainment'
        //             }
        //         },
        //         {
        //             'id': 1,
        //             'firstName': 'Sam',
        //             'lastName': 'Tavitz',
        //             'company': {
        //                 'id': 1,
        //                 'name': 'Gavern Entertainment'
        //             }
        //         },
        //         {
        //             'id': 1,
        //             'firstName': 'Alec',
        //             'lastName': 'Nimitz',
        //             'company': {
        //                 'id': 1,
        //                 'name': 'GRC Creative'
        //             }
        //         },
        //         {
        //             'id': 1,
        //             'firstName': 'Tim',
        //             'lastName': 'O\'Leary',
        //             'company': {
        //                 'id': 1,
        //                 'name': 'GRC Creative'
        //             }
        //         },
        //         {
        //             'id': 1,
        //             'firstName': 'Luke',
        //             'lastName': 'Ovitz',
        //             'company': {
        //                 'id': 3,
        //                 'name': 'Creative Artists Agency'
        //             }
        //         },
        //         {
        //             'id': 1,
        //             'firstName': 'Tom',
        //             'lastName': 'Bradenton',
        //             'company': {
        //                 'id': 1,
        //                 'name': 'GRC Creative'
        //             }
        //         },
        //     ]
        // },
        // {
        //     'partyId': 125,
        //     'firstName': 'Maggie',
        //     'middleName': 'Jane',
        //     'lastName': 'Gyllenhaal',
        //     'minor': false,
        //     'akaNames': null,
        //     'image': 'http://amominredhighheels.com/wp-content/uploads/2008/07/maggie_gyllenhaal.jpg',
        //     'projects': [
        //         {
        //             'id': 1,
        //             'projectName': 'The Deuce'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': ''
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Home'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'The New Empress'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Beauty Mark'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'The Dark Knight'
        //         }
        //     ],
        //     'ssn': '6644',
        //     'representatives': [
        //         {
        //             'id': 1,
        //             'firstName': 'Sam',
        //             'lastName': 'Tavitz',
        //             'company': {
        //                 'id': 1,
        //                 'name': 'Gavern Entertainment'
        //             }
        //         }
        //     ]
        // },
        // {
        //     'partyId': 126,
        //     'firstName': 'Kirsten',
        //     'middleName': null,
        //     'lastName': 'Dunst',
        //     'minor': false,
        //     'akaNames': null,
        //     'image': 'https://ia.media-imdb.com/images/M/MV5BMTQ3NzkwNzM1MV5BMl5BanBnXkFtZTgwMzE2MTQ3MjE@._V1_UY317_CR12,0,214,317_AL_.jpg',
        //     'projects': [
        //         {
        //             'id': 1,
        //             'projectName': 'The Bell Jar'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Midnight Special'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Porlandia'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Upside Down'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Melancholia'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Spider Man 1'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Spider Man 2'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Spider Man 3'
        //         }
        //     ],
        //     'ssn': '3987',
        //     'representatives': [
        //         {
        //             'id': 1,
        //             'firstName': 'Alec',
        //             'lastName': 'Nimitz',
        //             'company': {
        //                 'id': 1,
        //                 'name': 'GRC Creative'
        //             }
        //         }
        //     ]
        // },
        // {
        //     'partyId': 127,
        //     'firstName': 'Andy',
        //     'middleName': 'Arturo',
        //     'lastName': 'Garcia',
        //     'minor': false,
        //     'akaNames': [
        //         'Andrés Arturo García Menéndez'
        //     ],
        //     'image': 'http://www.independent.org/images/bios_hirez/garcia_andy_700.jpg',
        //     'projects': [
        //         {
        //             'id': 1,
        //             'projectName': 'What about Love'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'Max Steel'
        //         },
        //         {
        //             'id': 1,
        //             'projectName': 'The Pink Panther 2'
        //         }
        //     ],
        //     'ssn': '1243',
        //     'representatives': [
        //         {
        //             'id': 1,
        //             'firstName': 'Luke',
        //             'lastName': 'Ovitz',
        //             'company': {
        //                 'id': 3,
        //                 'name': 'Creative Artists Agency'
        //             }
        //         }
        //     ]
        // }
      ]
    };

  public static readonly DEFAULT_COL_DEFS_ROLLCALL: ColumnDefModel[] = [
    new GridImageDefModel('Name', 'name',
      new GridImageParamsModel('image', {
        keys: ['firstName', 'lastName'],
        routing: new GridLinkParamsModel('/people', 'partyId', 'summary')
      }, null, { key: 'designation' }), { comparator: { name: 'propertyValueComparator', key: 'lastName' } }
    ),
    new ColumnDefModel('Title', 'title'),
    new GridLinkDefModel('Company', 'company.companyName',
      new GridLinkParamsModel('/company', 'company.partyId', 'summary')
    ),
    new GridListDefModel('Contact', 'contacts',
      new GridListParamsModel({
        iterable: 'contacts',
        keys: ['type', 'name']
      }, true), { config: { suppressSorting: true } }
    )
  ];

  public static readonly DEFAULT_ROW_DATA_ROLLCALL: any = {
    '_embedded': {
      'people': [
        {
          'partyId': 3486743,
          'firstName': 'Bryan',
          'lastName': 'Lourd',
          'title': 'Executive Producer',
          'designation': 'Business',
          'image': '/api/party/3486743/image',
          'contacts': [
            {
              'id': 1,
              'type': 'Home:',
              'name': '454.545.9535',
              'primary': 'Y'
            },
            {
              'id': 2,
              'type': 'Cell:',
              'name': '354.545.9536',
              'primary': 'N'
            }
          ],
          'company': {
            'partyId': 3486885,
            'companyName': 'Creative Artists Agency (CAA LA)'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486743'
            }
          }
        },
        {
          'partyId': 3486744,
          'firstName': 'Jon',
          'lastName': 'Huddle',
          'title': 'Personal',
          'designation': 'Business',
          'image': '/api/party/3486744/image',
          'contacts': [
            {
              'id': 1,
              'type': 'Home:',
              'name': '354.545.9535',
              'primary': 'Y'
            }
          ],
          'company': {
            'partyId': 3486939,
            'companyName': 'UTA'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486744'
            }
          }
        },
        {
          'partyId': 3486745,
          'firstName': 'Joel',
          'lastName': 'Lubin',
          'title': 'Director',
          'designation': 'Personal',
          'image': null,
          'contacts': [],
          'company': {
            'partyId': 3486885,
            'companyName': 'Creative Artists Agency (CAA LA)'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486745'
            }
          }
        },
        {
          'partyId': 3486746,
          'firstName': 'Bernadine',
          'lastName': 'Brandis',
          'title': 'Producer',
          'designation': 'Business',
          'image': '/api/party/3486746/image',
          'contacts': [],
          'company': {
            'partyId': 3486945,
            'companyName': 'Walt Disney Pictures'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486746'
            }
          }
        },
        {
          'partyId': 3486747,
          'firstName': 'Eric',
          'lastName': 'Garfinkel',
          'title': 'Producer',
          'designation': 'Personal',
          'image': '/api/party/3486747/image',
          'contacts': [
            {
              'id': 1,
              'type': 'Home:',
              'name': 'egarf@wb.com',
              'primary': 'Y'
            }
          ],
          'company': {
            'partyId': 3486934,
            'companyName': 'The Gersh Agency'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486747'
            }
          }
        },
        {
          'partyId': 3486748,
          'firstName': 'Warren',
          'lastName': 'Zavala',
          'title': 'Executive Producer',
          'designation': 'Personal',
          'image': '/api/party/3486748/image',
          'contacts': [],
          'company': {
            'partyId': 3486944,
            'companyName': 'WME Entertainment'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486748'
            }
          }
        },
        {
          'partyId': 3486749,
          'firstName': 'Theresa',
          'lastName': 'Peters',
          'title': 'Screenwriter',
          'designation': 'Business',
          'image': '/api/party/3486749/image',
          'contacts': [
            {
              'id': 1,
              'type': 'Business:',
              'name': '532.121.7792',
              'primary': 'Y'
            },
            {
              'id': 1,
              'type': 'Business:',
              'name': 'theresa.peters@sonypictures.com',
              'primary': 'N'
            }
          ],
          'company': {
            'partyId': 3486940,
            'companyName': 'United Talent Agency (UTA LA)'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486749'
            }
          }
        },
        {
          'partyId': 3486750,
          'firstName': 'David',
          'lastName': 'Shapira',
          'title': 'Director',
          'designation': null,
          'image': '/api/party/3486750/image',
          'contacts': [],
          'company': {
            'partyId': 3486887,
            'companyName': 'David Shapira & Associates'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486750'
            }
          }
        },
        {
          'partyId': 3486751,
          'firstName': 'Axelle',
          'lastName': 'Sibiril-LeFebvre',
          'title': 'Executive Producer',
          'designation': 'Business',
          'image': '/api/party/3486751/image',
          'contacts': [],
          'company': {
            'partyId': 3486871,
            'companyName': 'A.C.T.1'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486751'
            }
          }
        },
        {
          'partyId': 3486752,
          'firstName': 'Joe',
          'lastName': 'Vance',
          'title': 'Writer',
          'designation': 'Business',
          'image': '/api/party/3486752/image',
          'contacts': [],
          'company': {
            'partyId': 3486888,
            'companyName': 'Domain'
          },
          '_links': {
            'self': {
              'href': 'http://localhost:9009/rollcall/party/3486752'
            }
          }
        }
      ]
    },
    '_links': {
      'first': {
        'href': 'http://localhost:9009/rollcall/people?page=0&size=10'
      },
      'prev': {
        'href': 'http://localhost:9009/rollcall/people?page=2&size=10'
      },
      'self': {
        'href': 'http://localhost:9009/rollcall/people?page=3&size=10'
      },
      'next': {
        'href': 'http://localhost:9009/rollcall/people?page=4&size=10'
      },
      'last': {
        'href': 'http://localhost:9009/rollcall/people?page=15&size=10'
      }
    },
    'page': {
      'size': 10,
      'totalElements': 155,
      'totalPages': 16,
      'number': 3
    }
  };

  // public static readonly DEFAULT_COL_DEFS_IMAGE: ColumnDefModel[] = [
  //   new ColumnDefModel(
  //     'Name',
  //     'talent',
  //     {
  //       name: 'imageComponent',
  //       params: new ImageParamsModel('talent', 'akaNames', [
  //         'firstName',
  //         'lastName',
  //     ])
  //     },
  //     {
  //       name: 'lastNameComparator',
  //       dataToParse: { field1: 'talent', field2: 'lastName' }
  //     }
  //   ),
  //   new ColumnDefModel('Projects', 'projectName', {
  //     name: 'listComponent',
  //     params: new ListParamsModel('projects', null, true, true)
  //   }),
  //   new ColumnDefModel('ID #', 'id', null, null, {
  //     name: 'ssnFormatter',
  //     field: 'id'
  //   }),
  //   new ColumnDefModel('Representative', 'representative'),
  //   new ColumnDefModel('Company', 'company'),
  //   new ColumnDefModel('Date', 'date', null, null, {
  //     name: 'dateFormatter',
  //     field: 'talent.date'
  //   })
  // ];

  public static readonly DEFAULT_ROW_DATA_IMAGE: any[] = [
    {
      talent: {
        firstName: 'Leonardo',
        lastName: 'DiCaprio',
        akaNames: ['Leo DiCaprio'],
        routeUrl: 'talentGrid/talentDetails',
        date: '2018-05-07T20:39:25',
        image:
          'https://upload.wikimedia.org/wikipedia/commons/2/25/Leonardo_DiCaprio_2014.jpg',
        minor: false
      },
      projects: [
        { projectName: 'The Revenant 14: The Bear finally kills him' },
        { projectName: 'Live By Night' },
        { projectName: 'The Wolf of Wall Streeeeeeeeeeeeet' },
        { projectName: 'The Great Gatsby' },
        { projectName: 'Red Riding Hood' },
        { projectName: 'The Titanic' },
        { projectName: 'Inception' }
      ],
      id: '382654325',
      representative: 'Rick Yorn',
      company: 'LBI Entertainment',
      date: '2018-05-07T20:39:25'
    },
    {
      talent: {
        firstName: 'Scott',
        lastName: 'Diggs (K)',
        akaNames: ['Taye Diggs', 'T Diggs'],
        date: '2015-09-30T18:22:00',
        image:
          'http://images2.fanpop.com/images/photos/2700000/Taye-Diggs-taye-diggs-2709366-1923-2560.jpg',
        minor: false
      },
      projects: [
        { projectName: 'Empire' },
        { projectName: 'Murder in the First' },
        { projectName: 'Opening Night' },
        { projectName: 'NCIS' },
        { projectName: 'Rosewood' }
      ],
      id: '123985467',
      representative: 'Tom Bradenton',
      company: 'GRC Creative',
      date: '2015-09-30T18:22:00'
    },
    {
      talent: {
        firstName: 'Maggie',
        lastName: 'Gyllenhaal',
        akaNames: null,
        date: '2018-08-15T09:41:28',
        image:
          'http://amominredhighheels.com/wp-content/uploads/2008/07/maggie_gyllenhaal.jpg',
        minor: false
      },
      projects: [
        { projectName: 'The Deuce' },
        { projectName: '' },
        { projectName: 'Home' },
        { projectName: 'The New Empress' },
        { projectName: 'Beauty Mark' },
        { projectName: 'The Dark Knight' }
      ],
      id: '213526644',
      representative: 'Sam Tavitz',
      company: 'Gavern Entertainment',
      date: '2018-08-15T09:41:28'
    },
    {
      talent: {
        firstName: 'Kirsten',
        lastName: 'Dunst',
        akaNames: null,
        date: '2013-11-19T13:05:25',
        image:
          'https://ia.media-imdb.com/images/M/MV5BMTQ3NzkwNzM1MV5BMl5BanBnXkFtZTgwMzE2MTQ3MjE@._V1_UY317_CR12,0,214,317_AL_.jpg',
        minor: true
      },
      projects: [
        { projectName: 'The Bell Jar 2: Revenge of the Jars!' },
        { projectName: 'Midnight Special' },
        { projectName: 'Porlandia' },
        { projectName: 'Upside Down' },
        { projectName: 'Melancholia' },
        { projectName: 'Spider Man 1' },
        { projectName: 'Spider Man 2' },
        { projectName: 'Spider Man 3' }
      ],
      id: '527663987',
      representative: 'Alec Nimitz',
      company: 'GRC Creative',
      date: '2013-11-19T13:05:25'
    },
    {
      talent: {
        firstName: 'Andy',
        lastName: 'Garcia',
        akaNames: ['Andrés Arturo García Menéndez'],
        date: '2018-05-11T22:22:22',
        image:
          'http://www.independent.org/images/bios_hirez/garcia_andy_700.jpg',
        minor: false
      },
      projects: [
        { projectName: 'What about Love' },
        { projectName: 'Max Steel' },
        { projectName: 'The Pink Panther 2' }
      ],
      id: '192933353',
      representative: 'Luke Ovitz',
      company: 'Creative Artists Agency',
      date: '2018-05-11T22:22:22'
    }
  ];

  public static readonly DEFAULT_COL_DEFS_PROJECTS: ColumnDefModel[] = [
    new GridTitlesDefModel('Title', 'title',
      new GridTitlesParamsModel({ keys: ['title'], routing: new GridLinkParamsModel('/projectDetails', 'id') }, 'akaNames')
    ),
    new GridListDefModel('Peformer', 'performer',
      new GridListParamsModel({
        iterable: 'deals',
        keys: ['performer.firstName', 'performer.lastName'],
        routing: new GridLinkParamsModel('/wizard', 'id', 'summary')
      }, true, false, 'performer.agencyName', 'performer.lastName')
    ),
    new GridListDefModel('Role', 'performerRole',
      new GridListParamsModel({
        iterable: 'deals',
        keys: ['performerRole']
      }, false, false, 'performer.agencyName', 'performerRole')
    ),
    new GridListDefModel('Agency', 'agencyName',
      new GridListParamsModel({
        iterable: 'deals',
        keys: ['performer.agencyName']
      }, false, true, null, 'performer.agencyName')
    ),
    new GridListDefModel('Union', 'unionLookup',
      new GridListParamsModel({
        iterable: 'deals',
        keys: ['unionLookup.name']
      }, false, false, 'performer.agencyName', 'unionLookup.name')
    ),
    new ColumnDefModel('SAP/GL Code', 'sapCode', {
      name: 'linkComponent',
      params: new GridLinkParamsModel('/welcome', 'sapCode')
    }, { comparator: { name: 'numberComparator' } }),
    new ColumnDefModel('Project Date', 'date', null, {
      comparator: { name: 'dateComparator' },
      formatter: 'dateFormatter',
      valGetter: 'dateGetter'
    })
  ];

  public static readonly DEFAULT_ROW_DATA_PROJECTS: any[] = [
    {
      title: 'COWBOY WAY',
      akaNames: ['PISTOLLERS', 'COWBOYS'],
      date: '2018-09-10',
      sapCode: 100,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Sir Dinglebop Castlebard the Seventy-Seventh',
          performer: {
            firstName: 'EggsBenedict',
            middleName: null,
            lastName: 'Cucumberpatch',
            agencyName: ['ROW1', 'ROW1'],
            partyId: null
          },
          id: 43
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 28',
          performer: {
            firstName: 'This is a really long name',
            middleName: null,
            lastName: 'Williams',
            agencyName: ['ROW2'],
            partyId: null
          },
          id: 44
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 29',
          performer: {
            firstName: 'Jackie',
            middleName: null,
            lastName: 'Bridges',
            agencyName: ['ROW3', 'ROW3', 'ROW3'],
            partyId: null
          },
          id: 45
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 30',
          performer: {
            firstName: 'Thomas',
            middleName: null,
            lastName: 'Joseph',
            agencyName: null,
            partyId: null
          },
          id: 46
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 31',
          performer: {
            firstName: 'Bill',
            middleName: null,
            lastName: 'Hardy',
            agencyName: ['ROW5', 'ROW5'],
            partyId: null
          },
          id: 47
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 32',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ROW6', 'ROW6'],
            partyId: null
          },
          id: 48
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010774'
        }
      },
      id: 1010774
    },
    {
      title: 'LOVERBOY',
      akaNames: ['ALL MY LOVIN\''],
      date: '2018-04-09',
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010775'
        }
      },
      id: 1010775
    },
    {
      title: 'TOUGH STUFF',
      akaNames: ['MARTIAL ARTS PROJECT'],
      date: '2018-01-01',
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010776'
        }
      },
      id: 1010776
    },
    {
      title: 'BLIND FURY',
      akaNames: ['MEN OF THE DARK'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010777'
        }
      },
      id: 1010777
    },
    {
      title: 'MENTAL CASE',
      akaNames: [],
      date: '2018-09-10',
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010778'
        }
      },
      id: 1010778
    },
    {
      title: 'NO MERCY',
      akaNames: ['NM PRODUCTION PROJECT'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010779'
        }
      },
      id: 1010779
    },
    {
      title: 'BREAKTHROUGH',
      akaNames: ['NIGHTVISIONS'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010780'
        }
      },
      id: 1010780
    },
    {
      title: 'WHITE ANGEL',
      akaNames: ['CARINOSA'],
      date: '2017-02-05',
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010781'
        }
      },
      id: 1010781
    },
    {
      title: 'HAILSTORM',
      akaNames: ['WRIGHT BLIND PROJECT'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010782'
        }
      },
      id: 1010782
    },
    {
      title: 'OUT OF CIRCULATION',
      akaNames: ['CAMERON OPTIONAL PROJECT #1', 'LOGIE\'S FOLIES'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010783'
        }
      },
      id: 1010783
    },
    {
      title: 'PRINCIPAL, THE',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010784'
        }
      },
      id: 1010784
    },
    {
      title: 'SILENT SERVICE',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010785'
        }
      },
      id: 1010785
    },
    {
      title: 'GILLIAN',
      akaNames: ['TO GILLIAN ON HER 37TH BIRTHDAY', 'ALONG THE WAY'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010786'
        }
      },
      id: 1010786
    },
    {
      title: 'FOR KEEPS',
      akaNames: ['MAYBE BABY', 'KAZURINSKY/DECLUE BLIND PROJECT'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010787'
        }
      },
      id: 1010787
    },
    {
      title: 'END OF ETERNITY',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010788'
        }
      },
      id: 1010788
    },
    {
      title: 'SWEET HEART\'S DANCE',
      akaNames: ['A KISS IS STILL A KISS', 'STILL MARRIED'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010789'
        }
      },
      id: 1010789
    },
    {
      title: 'I LOVE YOU TO DEATH',
      akaNames: ['MOLER/WELLS/KOSTMAYER PROJECT'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010790'
        }
      },
      id: 1010790
    },
    {
      title: 'HELL TO PAY',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010791'
        }
      },
      id: 1010791
    },
    {
      title: 'GIAT BLIND PROJECT',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010792'
        }
      },
      id: 1010792
    },
    {
      title: 'HAVE I GOT A GIRL FOR YOU',
      akaNames: ['CRAZY DATE'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010793'
        }
      },
      id: 1010793
    },
    {
      title: 'THREE DADS',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010794'
        }
      },
      id: 1010794
    },
    {
      title: 'CHANCES ARE',
      akaNames: [
        'PREVIOUSLY YOURS',
        'NOW AND FOREVER',
        'LIFE AFTER LIFE',
        'MIRACLE IN GEORGETOWN',
        'UNFORGETTABLE'
      ],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010795'
        }
      },
      id: 1010795
    },
    {
      title: 'ANIMAL PASSION',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010796'
        }
      },
      id: 1010796
    },
    {
      title: 'BLUE CHAIR, THE',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010797'
        }
      },
      id: 1010797
    },
    {
      title: 'NOTHING BUT THE BEST',
      akaNames: ['NEVER SAY DIE'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010798'
        }
      },
      id: 1010798
    },
    {
      title: 'BLUE MAAGA',
      akaNames: ['BOBSLED PROJECT', 'DRED SLED'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010799'
        }
      },
      id: 1010799
    },
    {
      title: 'EXECUTIVE PRIVILEGE',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010800'
        }
      },
      id: 1010800
    },
    {
      title: 'SWAYZE, PATRICK UNTITLED',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010801'
        }
      },
      id: 1010801
    },
    {
      title: 'THIRD PARTY',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010802'
        }
      },
      id: 1010802
    },
    {
      title: 'FRANCINE LEFRAK BALLROOM PROJECT',
      akaNames: ['JIVE BABY'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010803'
        }
      },
      id: 1010803
    },
    {
      title: 'BAILOUT',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010804'
        }
      },
      id: 1010804
    },
    {
      title: 'COMPANY OF HEROES',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010805'
        }
      },
      id: 1010805
    },
    {
      title: 'DEAD MAN DOWN',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010806'
        }
      },
      id: 1010806
    },
    {
      title: 'CROOKED ARROWS',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010807'
        }
      },
      id: 1010807
    },
    {
      title: 'MYSTERIOUS MR. SPINES, THE',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010808'
        }
      },
      id: 1010808
    },
    {
      title: 'X-MAS GAMES',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010809'
        }
      },
      id: 1010809
    },
    {
      title: 'STERN, DAVID UNTITLED PROJECT',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010810'
        }
      },
      id: 1010810
    },
    {
      title: 'TENTATIVE LIES (CHINA)',
      akaNames: ['ROMANITC LIES'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010811'
        }
      },
      id: 1010811
    },
    {
      title: 'MERMAID',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010812'
        }
      },
      id: 1010812
    },
    {
      title: 'AFFLICTED',
      akaNames: ['ENDS OF THE EARTH'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010813'
        }
      },
      id: 1010813
    },
    {
      title: 'CAT BALLOU MUSICAL',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3010892'
        }
      },
      id: 3010892
    },
    {
      title: 'DON\'T BE AFRAID OF THE DARK',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3010893'
        }
      },
      id: 3010893
    },
    {
      title: 'LOOPER',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3010894'
        }
      },
      id: 3010894
    },
    {
      title: 'MOM\'S NIGHT OUT',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3010895'
        }
      },
      id: 3010895
    },
    {
      title: 'INSIDIOUS 2',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3010896'
        }
      },
      id: 3010896
    },
    {
      title: 'ANDERSON TAPES',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/11'
        }
      },
      id: 11
    },
    {
      title: 'BAD TEACHER',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/55'
        }
      },
      id: 55
    },
    {
      title: 'AMERICAN HUSTLE',
      akaNames: ['AMERICAN BULLSHIT', 'ABSCAM'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/135'
        }
      },
      id: 135
    },
    {
      title: 'EMERALD CITY',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/493'
        }
      },
      id: 493
    },
    {
      title: 'MASTERS OF THE UNIVERSE',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/655'
        }
      },
      id: 655
    },
    {
      title: 'SKULL, THE',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1030'
        }
      },
      id: 1030
    },
    {
      title: 'GANIS GOVERNESS PROJECT',
      akaNames: ['GOVERNESS PROJECT'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1391'
        }
      },
      id: 1391
    },
    {
      title: 'HOTEL TRANSYLVANIA',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1821'
        }
      },
      id: 1821
    },
    {
      title: 'LOVE HUNTER',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1909'
        }
      },
      id: 1909
    },
    {
      title: 'PRINCE OF 47TH STREET',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/2032'
        }
      },
      id: 2032
    },
    {
      title: 'RECOIL',
      akaNames: ['JACKALS'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/2046'
        }
      },
      id: 2046
    },
    {
      title: 'SKYFALL',
      akaNames: ['BOND 23'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3044'
        }
      },
      id: 3044
    },
    {
      title: 'TAP',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3444'
        }
      },
      id: 3444
    },
    {
      title: 'SWITCHING CHANNELS',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3445'
        }
      },
      id: 3445
    },
    {
      title: 'SEE NO EVIL, HEAR NO EVIL',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3448'
        }
      },
      id: 3448
    },
    {
      title: 'THE FRESHMAN',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3450'
        }
      },
      id: 3450
    },
    {
      title: 'THE MONUMENTS MEN',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3524'
        }
      },
      id: 3524
    },
    {
      title: 'CLOUDY 2:REVENGE OF THE LEFTOVERS',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 31',
          performer: {
            firstName: 'Donny',
            middleName: null,
            lastName: 'Smith',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 43
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 31',
          performer: {
            firstName: 'Rae',
            middleName: null,
            lastName: 'Williams',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 43
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 31',
          performer: {
            firstName: 'Jackie',
            middleName: null,
            lastName: 'Bridges',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 43
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 31',
          performer: {
            firstName: 'Thomas',
            middleName: null,
            lastName: 'Joseph',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 43
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 31',
          performer: {
            firstName: 'Bill',
            middleName: null,
            lastName: 'Hardy',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 43
        },
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 31',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 43
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/3865'
        }
      },
      id: 3865
    },
    {
      title: 'OXFORD',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/4349'
        }
      },
      id: 4349
    },
    {
      title: 'RAID, THE (REMAKE)',
      akaNames: ['RAID 2:  BERANDAL, THE', 'RAID (REMAKE), THE', 'RAID 2'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/4351'
        }
      },
      id: 4351
    },
    {
      title: 'GIRL IN THE SPIDER\'S WEB',
      akaNames: ['THE GIRL IN THE SPIDER\'S WEB'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/8628'
        }
      },
      id: 8628
    },
    {
      title: 'THE WALK',
      akaNames: ['TO REACH THE CLOUDS'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/274250'
        }
      },
      id: 274250
    },
    {
      title: 'THE LADY IN THE VAN',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/328450'
        }
      },
      id: 328450
    },
    {
      title: 'MUNIC BLIND SCRIPT',
      akaNames: [],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010720'
        }
      },
      id: 1010720
    },
    {
      title: 'FATAL BEAUTY',
      akaNames: ['EXTREME MEASURES'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010771'
        }
      },
      id: 1010771
    },
    {
      title: 'SIXTH FAMILY',
      akaNames: ['MADE IN THE SHADE'],
      date: null,
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010772'
        }
      },
      id: 1010772
    },
    {
      title: 'RESCUE (1988)',
      akaNames: [],
      date: '2017-06-06',
      sapCode: null,
      deals: [],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1010773'
        }
      },
      id: 1010773
    },
    {
      title: 'No Wrap title',
      akaNames: [],
      date: null,
      sapCode: 7,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 1
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012348'
        }
      },
      id: 1012348
    },
    {
      title: 'Wrapping Title NO AkA xxxxxxxxxxxxxxxx',
      akaNames: [],
      date: null,
      sapCode: 21,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486642,
          performerRole: 'Doctor',
          performer: {
            firstName: 'Panorama Media LLC as agent for',
            middleName: null,
            lastName: 'White Dog Productions LLC',
            agencyName: '',
            partyId: null
          },
          id: 2
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012349'
        }
      },
      id: 1012349
    },
    {
      title: 'No Wrap title1',
      akaNames: ['AKA1'],
      date: null,
      sapCode: 32,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 3
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012350'
        }
      },
      id: 1012350
    },
    {
      title: 'Wrapping Title Wrap AKAxxxxxxxxxxxx',
      akaNames: ['AKA for Wrapping Title Wrap AKAxxxxxxxx'],
      date: null,
      sapCode: 242,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486642,
          performerRole: 'Doctor',
          performer: {
            firstName: 'Panorama Media LLC as agent for',
            middleName: null,
            lastName: 'White Dog Productions LLC',
            agencyName: '',
            partyId: null
          },
          id: 5
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012351'
        }
      },
      id: 1012351
    },
    {
      title: 'title',
      akaNames: ['AKA1', 'aka2'],
      date: null,
      sapCode: 323,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486645,
          performerRole: 'Lawyer',
          performer: {
            firstName: 'Michael',
            middleName: null,
            lastName: 'Brady',
            agencyName: '',
            partyId: null
          },
          id: 8
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012352'
        }
      },
      id: 1012352
    },
    {
      title: 'Project Title 1',
      akaNames: [
        'Project Title 1 AKA Wrap 2 xxxxxxxxxx',
        'Project Title 1 AKA Wrap 1 xxxxxxxxxx'
      ],
      date: null,
      sapCode: 2321,
      deals: [
        {
          unionLookup: {
            name: 'Union that wraps its name in the column',
            type: 'UNION',
            displayOrder: null,
            id: 26
          },
          performerPartyId: 3486790,
          performerRole: 'Doctor',
          performer: {
            firstName: null,
            middleName: null,
            lastName: null,
            agencyName: null,
            partyId: null
          },
          id: 12
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012353'
        }
      },
      id: 1012353
    },
    {
      title: 'Test Title_migrate 1',
      akaNames: [],
      date: null,
      sapCode: 1,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 1',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 13
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012354'
        }
      },
      id: 1012354
    },
    {
      title: 'Test Title_migrate 2',
      akaNames: [],
      date: null,
      sapCode: 2,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 2',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 14
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012355'
        }
      },
      id: 1012355
    },
    {
      title: 'Test Title_migrate 3',
      akaNames: [],
      date: null,
      sapCode: 3,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 3',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 15
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012356'
        }
      },
      id: 1012356
    },
    {
      title: 'Test Title_migrate 4',
      akaNames: [],
      date: null,
      sapCode: 4,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 4',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 16
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012357'
        }
      },
      id: 1012357
    },
    {
      title: 'Test Title_migrate 5',
      akaNames: [],
      date: null,
      sapCode: 5,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 5',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 17
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012358'
        }
      },
      id: 1012358
    },
    {
      title: 'Test Title_migrate 6',
      akaNames: [],
      date: null,
      sapCode: 6,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 6',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 18
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012359'
        }
      },
      id: 1012359
    },
    {
      title: 'Test Title_migrate 7',
      akaNames: [],
      date: null,
      sapCode: 7,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 7',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM'],
            partyId: null
          },
          id: 19
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012360'
        }
      },
      id: 1012360
    },
    {
      title: 'Test Title_migrate 8',
      akaNames: [],
      date: null,
      sapCode: 8,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 8',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 20
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012361'
        }
      },
      id: 1012361
    },
    {
      title: 'Test Title_migrate 9',
      akaNames: [],
      date: null,
      sapCode: 9,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 9',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 21
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012362'
        }
      },
      id: 1012362
    },
    {
      title: 'Test Title_migrate 10',
      akaNames: [],
      date: null,
      sapCode: 10,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 10',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 22
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012363'
        }
      },
      id: 1012363
    },
    {
      title: 'Test Title_migrate 11',
      akaNames: [],
      date: null,
      sapCode: 11,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 11',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 23
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012364'
        }
      },
      id: 1012364
    },
    {
      title: 'Test Title_migrate 12',
      akaNames: [],
      date: null,
      sapCode: 12,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 12',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 24
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012365'
        }
      },
      id: 1012365
    },
    {
      title: 'Test Title_migrate 13',
      akaNames: [],
      date: null,
      sapCode: 13,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 13',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 25
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012366'
        }
      },
      id: 1012366
    },
    {
      title: 'Test Title_migrate 14',
      akaNames: [],
      date: null,
      sapCode: 14,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 14',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 26
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012367'
        }
      },
      id: 1012367
    },
    {
      title: 'Test Title_migrate 15',
      akaNames: [],
      date: null,
      sapCode: 15,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 15',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 27
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012368'
        }
      },
      id: 1012368
    },
    {
      title: 'Test Title_migrate 16',
      akaNames: [],
      date: null,
      sapCode: 16,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 16',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 28
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012369'
        }
      },
      id: 1012369
    },
    {
      title: 'Test Title_migrate 17',
      akaNames: [],
      date: null,
      sapCode: 17,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 17',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 29
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012370'
        }
      },
      id: 1012370
    },
    {
      title: 'Test Title_migrate 18',
      akaNames: [],
      date: null,
      sapCode: 18,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 18',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 30
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012371'
        }
      },
      id: 1012371
    },
    {
      title: 'Test Title_migrate 19',
      akaNames: [],
      date: null,
      sapCode: 19,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 19',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 31
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012372'
        }
      },
      id: 1012372
    },
    {
      title: 'Test Title_migrate 20',
      akaNames: [],
      date: null,
      sapCode: 20,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 20',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 32
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012373'
        }
      },
      id: 1012373
    },
    {
      title: 'Test Title_migrate 21',
      akaNames: [],
      date: null,
      sapCode: 21,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 21',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 33
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012374'
        }
      },
      id: 1012374
    },
    {
      title: 'Test Title_migrate 22',
      akaNames: [],
      date: null,
      sapCode: 22,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 22',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 34
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012375'
        }
      },
      id: 1012375
    },
    {
      title: 'Test Title_migrate 23',
      akaNames: [],
      date: null,
      sapCode: 23,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 23',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 35
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012376'
        }
      },
      id: 1012376
    },
    {
      title: 'Test Title_migrate 24',
      akaNames: [],
      date: null,
      sapCode: 24,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 24',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 36
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012377'
        }
      },
      id: 1012377
    },
    {
      title: 'Test Title_migrate 25',
      akaNames: [],
      date: null,
      sapCode: 25,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 25',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 37
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012378'
        }
      },
      id: 1012378
    },
    {
      title: 'Test Title_migrate 26',
      akaNames: [],
      date: null,
      sapCode: 26,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 26',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 38
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012379'
        }
      },
      id: 1012379
    },
    {
      title: 'Test Title_migrate 27',
      akaNames: [],
      date: null,
      sapCode: 27,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 27',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 39
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012380'
        }
      },
      id: 1012380
    },
    {
      title: 'Test Title_migrate 28',
      akaNames: [],
      date: null,
      sapCode: 28,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 28',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 40
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012381'
        }
      },
      id: 1012381
    },
    {
      title: 'Test Title_migrate 29',
      akaNames: [],
      date: null,
      sapCode: 29,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 29',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 41
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012382'
        }
      },
      id: 1012382
    },
    {
      title: 'Test Title_migrate 30',
      akaNames: [],
      date: null,
      sapCode: 30,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 30',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 42
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012383'
        }
      },
      id: 1012383
    },
    {
      title: 'Test Title_migrate 31',
      akaNames: [],
      date: null,
      sapCode: 31,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 31',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 43
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012384'
        }
      },
      id: 1012384
    },
    {
      title: 'Test Title_migrate 32',
      akaNames: [],
      date: null,
      sapCode: 32,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 32',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 44
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012385'
        }
      },
      id: 1012385
    },
    {
      title: 'Test Title_migrate 33',
      akaNames: [],
      date: null,
      sapCode: 33,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 33',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 45
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012386'
        }
      },
      id: 1012386
    },
    {
      title: 'Test Title_migrate 34',
      akaNames: [],
      date: null,
      sapCode: 34,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 34',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 46
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012387'
        }
      },
      id: 1012387
    },
    {
      title: 'Test Title_migrate 35',
      akaNames: [],
      date: null,
      sapCode: 35,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 35',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 47
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012388'
        }
      },
      id: 1012388
    },
    {
      title: 'Test Title_migrate 36',
      akaNames: [],
      date: null,
      sapCode: 36,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 36',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 48
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012389'
        }
      },
      id: 1012389
    },
    {
      title: 'Test Title_migrate 37',
      akaNames: [],
      date: null,
      sapCode: 37,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 37',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 49
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012390'
        }
      },
      id: 1012390
    },
    {
      title: 'Test Title_migrate 38',
      akaNames: [],
      date: null,
      sapCode: 38,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 38',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 50
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012391'
        }
      },
      id: 1012391
    },
    {
      title: 'Test Title_migrate 39',
      akaNames: [],
      date: null,
      sapCode: 39,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 39',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 51
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012392'
        }
      },
      id: 1012392
    },
    {
      title: 'Test Title_migrate 40',
      akaNames: [],
      date: null,
      sapCode: 40,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 40',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 52
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012393'
        }
      },
      id: 1012393
    },
    {
      title: 'Test Title_migrate 41',
      akaNames: [],
      date: null,
      sapCode: 41,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 41',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 53
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012394'
        }
      },
      id: 1012394
    },
    {
      title: 'Test Title_migrate 42',
      akaNames: [],
      date: null,
      sapCode: 42,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 42',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 54
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012395'
        }
      },
      id: 1012395
    },
    {
      title: 'Test Title_migrate 43',
      akaNames: [],
      date: null,
      sapCode: 43,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 43',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 55
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012396'
        }
      },
      id: 1012396
    },
    {
      title: 'Test Title_migrate 44',
      akaNames: [],
      date: null,
      sapCode: 44,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 44',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 56
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012397'
        }
      },
      id: 1012397
    },
    {
      title: 'Test Title_migrate 45',
      akaNames: [],
      date: null,
      sapCode: 45,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 45',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 57
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012398'
        }
      },
      id: 1012398
    },
    {
      title: 'Test Title_migrate 46',
      akaNames: [],
      date: null,
      sapCode: 46,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 46',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 58
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012399'
        }
      },
      id: 1012399
    },
    {
      title: 'Test Title_migrate 47',
      akaNames: [],
      date: null,
      sapCode: 47,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 47',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 59
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012400'
        }
      },
      id: 1012400
    },
    {
      title: 'Test Title_migrate 48',
      akaNames: [],
      date: null,
      sapCode: 48,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 48',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 60
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012401'
        }
      },
      id: 1012401
    },
    {
      title: 'Test Title_migrate 49',
      akaNames: [],
      date: null,
      sapCode: 49,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 49',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 61
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012402'
        }
      },
      id: 1012402
    },
    {
      title: 'Test Title_migrate 50',
      akaNames: [],
      date: null,
      sapCode: 50,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 50',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 62
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012403'
        }
      },
      id: 1012403
    },
    {
      title: 'Test Title_migrate 51',
      akaNames: [],
      date: null,
      sapCode: 51,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 51',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 63
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012404'
        }
      },
      id: 1012404
    },
    {
      title: 'Test Title_migrate 52',
      akaNames: [],
      date: null,
      sapCode: 52,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 52',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 64
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012405'
        }
      },
      id: 1012405
    },
    {
      title: 'Test Title_migrate 53',
      akaNames: [],
      date: null,
      sapCode: 53,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 53',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 65
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012406'
        }
      },
      id: 1012406
    },
    {
      title: 'Test Title_migrate 54',
      akaNames: [],
      date: null,
      sapCode: 54,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 54',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 66
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012407'
        }
      },
      id: 1012407
    },
    {
      title: 'Test Title_migrate 55',
      akaNames: [],
      date: null,
      sapCode: 55,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 55',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 67
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012408'
        }
      },
      id: 1012408
    },
    {
      title: 'Test Title_migrate 56',
      akaNames: [],
      date: null,
      sapCode: 56,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 56',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 68
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012409'
        }
      },
      id: 1012409
    },
    {
      title: 'Test Title_migrate 57',
      akaNames: [],
      date: null,
      sapCode: 57,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 57',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 69
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012410'
        }
      },
      id: 1012410
    },
    {
      title: 'Test Title_migrate 58',
      akaNames: [],
      date: null,
      sapCode: 58,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 58',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 70
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012411'
        }
      },
      id: 1012411
    },
    {
      title: 'Test Title_migrate 59',
      akaNames: [],
      date: null,
      sapCode: 59,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 59',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 71
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012412'
        }
      },
      id: 1012412
    },
    {
      title: 'Test Title_migrate 60',
      akaNames: [],
      date: null,
      sapCode: 60,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 60',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 72
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012413'
        }
      },
      id: 1012413
    },
    {
      title: 'Test Title_migrate 61',
      akaNames: [],
      date: null,
      sapCode: 61,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 61',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 73
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012414'
        }
      },
      id: 1012414
    },
    {
      title: 'Test Title_migrate 62',
      akaNames: [],
      date: null,
      sapCode: 62,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 62',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 74
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012415'
        }
      },
      id: 1012415
    },
    {
      title: 'Test Title_migrate 63',
      akaNames: [],
      date: null,
      sapCode: 63,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 63',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 75
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012416'
        }
      },
      id: 1012416
    },
    {
      title: 'Test Title_migrate 64',
      akaNames: [],
      date: null,
      sapCode: 64,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 64',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 76
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012417'
        }
      },
      id: 1012417
    },
    {
      title: 'Test Title_migrate 65',
      akaNames: [],
      date: null,
      sapCode: 65,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 65',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 77
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012418'
        }
      },
      id: 1012418
    },
    {
      title: 'Test Title_migrate 66',
      akaNames: [],
      date: null,
      sapCode: 66,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 66',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 78
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012419'
        }
      },
      id: 1012419
    },
    {
      title: 'Test Title_migrate 67',
      akaNames: [],
      date: null,
      sapCode: 67,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 67',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 79
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012420'
        }
      },
      id: 1012420
    },
    {
      title: 'Test Title_migrate 68',
      akaNames: [],
      date: null,
      sapCode: 68,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 68',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 80
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012421'
        }
      },
      id: 1012421
    },
    {
      title: 'Test Title_migrate 69',
      akaNames: [],
      date: null,
      sapCode: 69,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 69',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 81
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012422'
        }
      },
      id: 1012422
    },
    {
      title: 'Test Title_migrate 70',
      akaNames: [],
      date: null,
      sapCode: 70,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 70',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 82
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012423'
        }
      },
      id: 1012423
    },
    {
      title: 'Test Title_migrate 71',
      akaNames: [],
      date: null,
      sapCode: 71,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 71',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 83
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012424'
        }
      },
      id: 1012424
    },
    {
      title: 'Test Title_migrate 72',
      akaNames: [],
      date: null,
      sapCode: 72,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 72',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 84
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012425'
        }
      },
      id: 1012425
    },
    {
      title: 'Test Title_migrate 73',
      akaNames: [],
      date: null,
      sapCode: 73,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 73',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 85
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012426'
        }
      },
      id: 1012426
    },
    {
      title: 'Test Title_migrate 74',
      akaNames: [],
      date: null,
      sapCode: 74,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 74',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 86
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012427'
        }
      },
      id: 1012427
    },
    {
      title: 'Test Title_migrate 75',
      akaNames: [],
      date: null,
      sapCode: 75,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 75',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 87
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012428'
        }
      },
      id: 1012428
    },
    {
      title: 'Test Title_migrate 76',
      akaNames: [],
      date: null,
      sapCode: 76,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 76',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 88
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012429'
        }
      },
      id: 1012429
    },
    {
      title: 'Test Title_migrate 77',
      akaNames: [],
      date: null,
      sapCode: 77,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 77',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 89
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012430'
        }
      },
      id: 1012430
    },
    {
      title: 'Test Title_migrate 78',
      akaNames: [],
      date: null,
      sapCode: 78,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 78',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 90
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012431'
        }
      },
      id: 1012431
    },
    {
      title: 'Test Title_migrate 79',
      akaNames: [],
      date: null,
      sapCode: 79,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 79',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 91
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012432'
        }
      },
      id: 1012432
    },
    {
      title: 'Test Title_migrate 80',
      akaNames: [],
      date: null,
      sapCode: 80,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 80',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 92
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012433'
        }
      },
      id: 1012433
    },
    {
      title: 'Test Title_migrate 81',
      akaNames: [],
      date: null,
      sapCode: 81,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 81',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 93
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012434'
        }
      },
      id: 1012434
    },
    {
      title: 'Test Title_migrate 82',
      akaNames: [],
      date: null,
      sapCode: 82,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 82',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 94
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012435'
        }
      },
      id: 1012435
    },
    {
      title: 'Test Title_migrate 83',
      akaNames: [],
      date: null,
      sapCode: 83,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 83',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 95
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012436'
        }
      },
      id: 1012436
    },
    {
      title: 'Test Title_migrate 84',
      akaNames: [],
      date: null,
      sapCode: 84,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 84',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 96
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012437'
        }
      },
      id: 1012437
    },
    {
      title: 'Test Title_migrate 85',
      akaNames: [],
      date: null,
      sapCode: 85,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 85',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 97
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012438'
        }
      },
      id: 1012438
    },
    {
      title: 'Test Title_migrate 86',
      akaNames: [],
      date: null,
      sapCode: 86,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 86',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 98
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012439'
        }
      },
      id: 1012439
    },
    {
      title: 'Test Title_migrate 87',
      akaNames: [],
      date: null,
      sapCode: 87,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 87',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 99
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012440'
        }
      },
      id: 1012440
    },
    {
      title: 'Test Title_migrate 88',
      akaNames: [],
      date: null,
      sapCode: 88,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 88',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 100
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012441'
        }
      },
      id: 1012441
    },
    {
      title: 'Test Title_migrate 89',
      akaNames: [],
      date: null,
      sapCode: 89,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 89',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 101
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012442'
        }
      },
      id: 1012442
    },
    {
      title: 'Test Title_migrate 90',
      akaNames: [],
      date: null,
      sapCode: 90,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 90',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 102
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012443'
        }
      },
      id: 1012443
    },
    {
      title: 'Test Title_migrate 91',
      akaNames: [],
      date: null,
      sapCode: 91,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 91',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 103
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012444'
        }
      },
      id: 1012444
    },
    {
      title: 'Test Title_migrate 92',
      akaNames: [],
      date: null,
      sapCode: 92,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 92',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 104
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012445'
        }
      },
      id: 1012445
    },
    {
      title: 'Test Title_migrate 93',
      akaNames: [],
      date: null,
      sapCode: 93,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 93',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 105
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012446'
        }
      },
      id: 1012446
    },
    {
      title: 'Test Title_migrate 94',
      akaNames: [],
      date: null,
      sapCode: 94,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 94',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 106
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012447'
        }
      },
      id: 1012447
    },
    {
      title: 'Test Title_migrate 95',
      akaNames: [],
      date: null,
      sapCode: 95,
      deals: [
        {
          unionLookup: {
            name: 'SAG',
            type: 'UNION',
            displayOrder: null,
            id: 25
          },
          performerPartyId: 3486641,
          performerRole: 'Lawyer 95',
          performer: {
            firstName: 'Jeff',
            middleName: null,
            lastName: 'Daniels',
            agencyName: ['ICM', 'ICM2'],
            partyId: null
          },
          id: 107
        }
      ],
      _links: {
        self: {
          href: 'http://dev.concept2alize.com/fc/dev1/fc/api/project/1012448'
        }
      },
      id: 1012448
    }
  ];

  // public static readonly DEFAULT_COL_DEFS_WORK_ACTIVITY: any[] = [
  //   {
  //     headerName: '',
  //     field: 'icon',
  //     cellRendererSelector: function(params) {
  //       const expandComponent = {
  //         component: 'expandComponent'
  //       };

  //       if (params.data.totalWork !== '1D') {
  //         return expandComponent;
  //       } else {
  //         return null;
  //       }
  //     },
  //     suppressSizeToFit: true,
  //     suppressResize: true,
  //     suppressFilter: true,
  //     width: 32
  //   },
  //   {
  //     headerName: 'Performer',
  //     field: 'performer',
  //     editable: false,
  //     cellRendererFramework: ImageComponent,
  //     width: 375
  //   },
  //   {
  //     headerName: 'Activity',
  //     field: 'activity',
  //     cellRendererFramework: ListComponent,
  //     cellEditorFramework: ListEditorComponent,
  //     editable: true
  //   },
  //   {
  //     headerName: 'Period',
  //     field: 'period',
  //     cellRendererFramework: ListComponent,
  //     cellEditorFramework: ListEditorComponent,
  //     editable: true
  //   },
  //   {
  //     headerName: 'Start Date',
  //     field: 'startDate',
  //     cellRendererFramework: ListComponent,
  //     cellEditorFramework: ListEditorComponent,
  //     editable: true
  //   },
  //   {
  //     headerName: 'Role #',
  //     field: 'roleNum',
  //     filter: 'agNumberColumnFilter'
  //   },
  //   {
  //     headerName: 'Role',
  //     field: 'role',
  //     floatingFilterComponentParams: { suppressFilterButton: true }
  //   },
  //   {
  //     headerName: 'Day Details',
  //     children: [
  //       {
  //         headerName: 'Grntee',
  //         field: 'guarantee',
  //         cellRendererFramework: ListComponent,
  //         cellEditorFramework: ListEditorComponent,
  //         editable: true,
  //         suppressFilter: true
  //       },
  //       {
  //         headerName: 'Princ Free',
  //         field: 'princFree',
  //         cellRendererFramework: ListComponent,
  //         cellEditorFramework: ListEditorComponent,
  //         editable: true,
  //         suppressFilter: true
  //       },
  //       {
  //         headerName: 'Post Free',
  //         field: 'postFree',
  //         cellRendererFramework: ListComponent,
  //         cellEditorFramework: ListEditorComponent,
  //         editable: true,
  //         suppressFilter: true
  //       },
  //       {
  //         headerName: 'Post Rmain',
  //         field: 'postRemain',
  //         cellRendererFramework: ListComponent,
  //         cellEditorFramework: ListEditorComponent,
  //         editable: true,
  //         suppressFilter: true
  //       },
  //       {
  //         headerName: 'Total Work',
  //         field: 'totalWork',
  //         suppressFilter: true
  //       },
  //       {
  //         headerName: 'Notes',
  //         field: 'notes',
  //         cellRendererFramework: ListComponent,
  //         cellEditorFramework: ListEditorComponent,
  //         editable: true,
  //         suppressFilter: true
  //       }
  //     ]
  //   }
  // ];

  public static readonly DEFAULT_ROW_DATA_WORK_ACTIVITY: any[] = [
    {
      icon: '',
      performer: 'Mike Adams',
      roleNum: 888,
      role: 'Stunt',
      totalWork: '2D',
      image:
        'https://vignette.wikia.nocookie.net/mario/images/8/80/Mario_Trofeo_SSBB.jpg/revision/latest?cb=20100929153926&path-prefix=es',
      details: [
        {
          activity: 'Start/Work/Finish',
          period: '',
          startDate: '04/15/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: ''
        },
        {
          activity: 'Start/Work/Finish',
          period: '',
          startDate: '04/16/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: ''
        }
      ]
    },
    {
      icon: '',
      performer: 'James Alfonso',
      roleNum: 888,
      role: 'Stunt',
      totalWork: '7D',
      image:
        'https://vignette.wikia.nocookie.net/supermarioitalia/images/8/82/Lio.jpg/revision/latest?cb=20121229162131&path-prefix=it',
      details: [
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/02/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: ''
        },
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/03/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: 'Off-Camera'
        },
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/04/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: ''
        },
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/05/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: 'Off-Camera'
        },
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/06/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: ''
        },
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/07/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: ''
        },
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/08/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: 'Showed up late'
        }
      ]
    },
    {
      icon: '',
      performer: 'Casey Affleck',
      roleNum: 6,
      role: 'Virgil Malloy',
      totalWork: '1D',
      image:
        'https://vignette.wikia.nocookie.net/ssb/images/c/cc/Bowser_Trophy.jpg/revision/latest?cb=20090114140645',
      details: [
        {
          activity: 'Start/Work/Finish',
          period: '',
          startDate: '02/28/2017',
          guarantee: 'F',
          princFree: 5,
          postFree: 4,
          postRemain: 2,
          notes: 'Notes'
        }
      ]
    },
    {
      icon: '',
      performer: 'Newell Alexander',
      roleNum: 777,
      role: 'Voice Over',
      totalWork: '3D',
      image:
        'https://vignette.wikia.nocookie.net/ssb/images/b/bf/Toad_trophy.jpg/revision/latest?cb=20090128225949',
      details: [
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/25/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: 'Here are some notes that are a little longer.'
        },
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/26/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: ''
        },
        {
          activity: 'Start/Work/Finish',
          period: '1st',
          startDate: '02/27/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: 'More notes'
        }
      ]
    },
    {
      icon: '',
      performer: 'Frankie Jay Allison',
      roleNum: 57,
      role: 'High Roller Pit Boss',
      totalWork: '1D',
      image:
        'https://vignette.wikia.nocookie.net/ssb/images/3/3f/Wario_trophy_%28SSBM%29.jpg/revision/latest?cb=20090625145605',
      details: [
        {
          activity: 'Start/Work/Finish',
          period: 'Reh',
          startDate: '01/15/2017',
          guarantee: '1D',
          princFree: '',
          postFree: '',
          postRemain: '',
          notes: ''
        }
      ]
    }
  ];


  public static readonly DEFAULT_COL_DEF_TRACKING: ColumnDefModel[] = [
    // new GridDateTimePickerDefModel('Date/Time', 'callTime', null, 181, true),

    new GridListDefModel('Tracking List', 'trackingList',
      new GridListParamsModel({
        iterable: 'trackingList',
        keys: ['trackinglist.listName'],
        routing: new GridLinkParamsModel('/trackingDetail', 'trackinglist.listId', '', 'trackinglist.listName')
      }, true, null, null, null, true, false, false, true)
    ),

    new GridListDefModel('Projects-talent', 'projectsTalent',
      new GridListParamsModel({
        iterable: 'projectsTalent',
        keys: ['projectName'],
      }, true, null, null, null, true, false, false, false,true,false,''), { config: { width: 200 } }
    ),

    new GridListDefModel('Talent', 'talent2',
      new GridListParamsModel({
        iterable: 'talent2',
        keys: ['talent2.displayName'],
        routing: new GridLinkParamsModel('/talentDetail', 'talent2.partyId', '', 'trackingtab')
      }, true, null, null, null, true, false, false, false)
    ),

    new GridLinkDefModel('Project', 'projectName',
      new GridLinkParamsModel('/', 'destinationUrl', '', '', false, false, false, false, false, false, true)
      , null),


    // new GridTypeaheadDefModel('Typeahead', 'texttalent', null, {textField:true,textLimit:70, filterType: 'TALENT_ONLY', primaryDisplayColumn: 'typeAheadDisplayName',metaDataColumns:['', ''], autofocus: true }, 200, true),

    // new GridTypeaheadDropdownDefModel('Typeahead-Dropdown', 'status', null, { "StatusOptions":[{ "id": 863, "value": "All Records" }, { "id": 864, "value": "In" }, { "id": 864, "value": "Out" }, { "id": 865, "value": "Incomplete" }],autofocus: true}, 200, true),

    // new GridDropdownEditDefModel('Priority', 'priorityValue', null, [{ "value": "Next to Call", "id": 3706 }, { "value": "New", "id": 3707 }, { "value": 'High', 'id': 3708 }, { 'value': 'Medium', 'id': 3709 }, { 'value': 'Low', 'id': 3710 }, { 'value': 'Blank - New', 'id': 23019 }], false, 120, true),
    // new GridDropdownEditDefModel('Status', 'statusValue', null, [{ 'value': 'Left Word', 'id': 3702 }, { 'value': 'No Answer', 'id': 3703 }, { 'value': 'Returning', 'id': 3705 }, { 'value': 'Need to Call', 'id': 4353 }, { 'value': 'New', 'id': 4354 }, { 'value': 'Completed', 'id': 21995 }, { 'value': 'Blank - No default', 'id': 22507 }], false, 140, true),


    new GridLargeTextEditDefModel('Note', 'notes', null, 300, true),
  ];

  public static readonly DEFAULT_ROW_DATA_TRACKING: any = {
    'content': [{
      'callSheetId': 504,
      'partyId': 11503251,
      'inOut': 'Out',
      'destinationUrl': 'https://google.com',
      'projectName': 'Project name',
      'texttalent': "test",
      "projectsTalent": [{
        "id": 328643,
        "projectName": "Project Title 1",
        "destinationUrl":"www.google.com"
      }],
      'talent': {
        'partyId': 11516699,
        'partyType': 'COMPANY',
        'firstName': null,
        'entityName': 'À',
        'ssnEndChars': null,
        'occupation': null,
        'agency': null,
        'typeAheadDisplayName': 'À',
        'primaryName': null,
        'teamMembers': null,
        'akaId': 33999,
        'companyId': null,
        'dataSetId': 4342,
        'companyLocations': null,
        'isPartyTeam': false
      },
      "trackingList": [{
        "listId": 20258,
        "listName": "Suggested Writers For Shazam-1"
      }],
      "talent2": [{
        "partyId": 11522423,
        "displayName": "A",
        "firstName": null,
        "lastName": "A",
        "companyName": null
      }, {
        "partyId": 11522148,
        "displayName": "B B FOWLER & Xena",
        "firstName": null,
        "lastName": "B B FOWLER & Xena",
        "companyName": null
      }],
      'status': { 'id': 864, 'value': 'In' },
      'StatusOptions': [{ 'id': 863, 'value': 'All Records' }, { 'id': 864, 'value': 'In' }, { 'id': 864, 'value': 'Out' }, { 'id': 865, 'value': 'Incomplete' }],
      'callTime': '12/20/2018 10:16 AM',
      'dateTimeDisplay': [{
        'value': '12/20/2018'
      }, {
        'value': '10:16 AM'
      }],
      'priorityId': 23019,
      'statusId': 22507,
      'priorityValue': 'Blank - New',
      'statusValue': 'Blank - No default',
      'firstName': null,
      'lastName': 'MILNE, A A',
      'companyName': null,
      'displayName': 'MILNE, A A',
      'webContactId': 89,
      'webContactValue': '81492695440000',
      'partyContactId': 12026,
      'notes': 'notes here',
      'imageURL': null,
      'partyType': 'CONTACT',
      'executiveId': null,
      'createdBy': null,
      'createdDate': null,
      'updatedBy': null,
      'updatedDate': null,
      'dataSet': null,
      'webContactList': [{
        'id': 12026,
        'value': '81492695440000 | Work 1',
        'webContactValue': '81492695440000',
        'webContactTypeId': 89,
        'partyContactId': 12026
      }, {
        'id': 7055,
        'value': '(265)-466-4564 | Work 1',
        'webContactValue': '(265)-466-4564',
        'webContactTypeId': 89,
        'partyContactId': 7055
      }, {
        'id': 9168,
        'value': '81492695440000 | Work 2',
        'webContactValue': '81492695440000',
        'webContactTypeId': 90,
        'partyContactId': 9168
      }, {
        'id': 9169,
        'value': 'a@a.com | Home',
        'webContactValue': 'a@a.com',
        'webContactTypeId': 106,
        'partyContactId': 9169
      }],
      'companyId': null,
      'middleName': null,
      'suffix': null
    },
    {
      'callSheetId': 504,
      'partyId': 11503251,
      'inOut': 'Out',
      'destinationUrl': 'https://google.com',
      'projectName': 'Project name',
      'talent': {
        'partyId': 11510313,
        'partyType': 'TALENT_AKA',
        'firstName': 'A',
        'entityName': 'A MILNE',
        'ssnEndChars': '2312',
        'occupation': 'Attorney',
        'agency': null,
        'typeAheadDisplayName': 'A A MILNE',
        'primaryName': 'OOJas',
        'teamMembers': null,
        'akaId': 12367,
        'companyId': null,
        'dataSetId': 4342,
        'companyLocations': null,
        'isPartyTeam': false
      },
      "trackingList": [{
        "listId": 20258,
        "listName": "Suggested Writers For Shazam-1"
      }],
      "talent2": [{
        "partyId": 11522423,
        "displayName": "A",
        "firstName": null,
        "lastName": "A",
        "companyName": null
      }, {
        "partyId": 11522148,
        "displayName": "B B FOWLER & Xena",
        "firstName": null,
        "lastName": "B B FOWLER & Xena",
        "companyName": null
      }],
      'status': { 'id': 864, 'value': 'Out' },
      'callTime': '12/20/2018 10:16 AM',
      'dateTimeDisplay': [{
        'value': '12/20/2018'
      }, {
        'value': '10:16 AM'
      }],
      'priorityId': 23019,
      'statusId': 22507,
      'priorityValue': 'Blank - New',
      'statusValue': 'Blank - No default',
      'firstName': null,
      'lastName': 'MILNE, A A',
      'companyName': null,
      'displayName': 'MILNE, A A',
      'webContactId': 89,
      'webContactValue': '81492695440000',
      'partyContactId': 12026,
      'notes': 'notes here',
      'imageURL': null,
      'partyType': 'CONTACT',
      'executiveId': null,
      'createdBy': null,
      'createdDate': null,
      'updatedBy': null,
      'updatedDate': null,
      'dataSet': null,
      'webContactList': [{
        'id': 12026,
        'value': '81492695440000 | Work 1',
        'webContactValue': '81492695440000',
        'webContactTypeId': 89,
        'partyContactId': 12026
      }, {
        'id': 7055,
        'value': '(265)-466-4564 | Work 1',
        'webContactValue': '(265)-466-4564',
        'webContactTypeId': 89,
        'partyContactId': 7055
      }, {
        'id': 9168,
        'value': '81492695440000 | Work 2',
        'webContactValue': '81492695440000',
        'webContactTypeId': 90,
        'partyContactId': 9168
      }, {
        'id': 9169,
        'value': 'a@a.com | Home',
        'webContactValue': 'a@a.com',
        'webContactTypeId': 106,
        'partyContactId': 9169
      }

      ],
      'companyId': null,
      'middleName': null,
      'suffix': null
    }],
    'page': {
      'number': 0,
      'size': 25,
      'totalPages': 9,
      'totalElements': 217
    }
  };

}

