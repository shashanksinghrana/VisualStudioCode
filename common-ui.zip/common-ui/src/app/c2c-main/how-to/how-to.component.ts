import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'c2c-how-to',
  templateUrl: './how-to.component.html',
  styleUrls: ['./how-to.component.scss']
})
export class HowToComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
