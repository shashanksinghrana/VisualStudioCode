export enum WizardStatusEnum {
  COMPLETE = 'COMPLETE',
  INCOMPLETE = 'INCOMPLETE',
  NOT_APPLICABLE = 'NOT_APPLICABLE',
  COMPLETE_CLASS = 'c2c-flag-complete',
  INCOMPLETE_CLASS = 'c2c-flag-incomplete',
  NOT_APPLICABLE_CLASS = 'c2c-flag-not-applicable'
}
