export enum UserRole {
    BUSINESS_CREATIVE = 'Business/Creative',
    CASTING = 'Casting',
    PRODUCTION = 'Production',
    REP = 'Rep'
}
