export enum TypeAheadMetaData {
  NAME = 'typeAheadDisplayName',
  OCCUPATION = 'occupation',
  COMPANY_NAME = 'agency',
  COMPANY_LOCATION = 'companyLocations',
  SSN = 'ssnEndChars'
}
