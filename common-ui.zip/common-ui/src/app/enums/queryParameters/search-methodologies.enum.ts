export enum SearchMethodologies{
    CONTAINS        = "CONTAINS",
    STARTS_WITH     = "STARTS_WITH"
}