export enum SpecialStrings {
    EMPTY_OPEN  = ' ',
    EMPTY       = ''
}