const PROXY_CONFIG = [
{
  context: [
    "/typeAheadNames",
    "/getTotalRecords",
    "/addParty",
    "/addAlias",
    "/getAccentedChars",
    "/api",
    "/rollcall"

  ],
  "target": "http://dev.concept2alize.com/tal/qa1/talent",
  "secure": false
  }
]

module.exports = PROXY_CONFIG;
