package com.mediaservices.c2c.fc.config.security;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class AntPathRequestMatcherSAMLResponseTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testAntPathRequestMatcherSAMLResponseString() {
        fail("Not yet implemented");
    }

    @Test
    public void testAntPathRequestMatcherSAMLResponseStringString() {
        fail("Not yet implemented");
    }

    @Test
    public void testAntPathRequestMatcherSAMLResponseStringStringBoolean() {
        fail("Not yet implemented");
    }

    @Test
    public void testMatches() {
        fail("Not yet implemented");
    }

    @Test
    public void testExtractUriTemplateVariables() {
        fail("Not yet implemented");
    }

    @Test
    public void testGetPattern() {
        fail("Not yet implemented");
    }

}
