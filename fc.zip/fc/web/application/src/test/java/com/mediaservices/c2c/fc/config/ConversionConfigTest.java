package com.mediaservices.c2c.fc.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.convert.ConversionService;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;

// TODO: Auto-generated Javadoc
/**
 * The Class ConversionConfigTest.
 */
@SpringBootTest
public class ConversionConfigTest extends AbstractTestNGSpringContextTests {

    /** The FC converter. */
    @Autowired
    @Qualifier("fcConverter")
    private ConversionService fcConverter;

}
