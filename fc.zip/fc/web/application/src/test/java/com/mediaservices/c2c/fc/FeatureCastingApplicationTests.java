package com.mediaservices.c2c.fc;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;

// TODO: Auto-generated Javadoc
/**
 * The Class FCApplicationTests.
 */
@SpringBootTest
public class FeatureCastingApplicationTests extends AbstractTestNGSpringContextTests {



}
