package com.mediaservices.c2c.fc.config.security;

import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.opensaml.saml2.core.NameID;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.test.util.ReflectionTestUtils;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.FcUser;
import com.mediaservices.c2c.fc.entity.Permissions;
import com.mediaservices.c2c.fc.entity.User;
import com.mediaservices.c2c.fc.entity.UserRole;
import com.mediaservices.c2c.fc.repository.UserRepository;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.impl.SAMLUserServiceImpl;
import com.mediaservices.c2c.fc.test.MockitoTest;

public class SAMLUserServiceImplTest extends MockitoTest {

    @InjectMocks
    private SAMLUserServiceImpl testee;

    @Mock
    private UserRepository userRepo;

    @Mock
    private SAMLCredential cred;

    @Mock
    private HttpServletRequest request;

    @Mock
    private NameID name;

    @Mock
    private AuthorizationService authorizationService;

    @Test
    public void loadUserBySAML() {
        ReflectionTestUtils.setField(testee, "findUserBy", "USER_ID");
        // given
        when(cred.getNameID()).thenReturn(name);
        when(authorizationService.loadUserDetails(Mockito.anyString())).thenReturn(null);


        // when

        final FcUser output = (FcUser) testee.loadUserBySAML(cred);

        // then
        assertNull(output);
    }

    private User createUsers() {
        final User user = new User();
        user.setFirstName("UserFirst");
        user.setLastName("UserLast");

        final UserRole role = new UserRole();
        role.setRoleName("UserRole");

        final Permissions mainPermission = new Permissions();
        mainPermission.setName("FEATURE_CASTING.VIEW");

        final Permissions viewPermission = new Permissions();
        viewPermission.setName("FEATURE_CASTING.EDIT");

        final List<Permissions> permissions = new ArrayList<>();
        permissions.add(mainPermission);
        permissions.add(viewPermission);
        role.setPermissions(permissions);

        user.setUserRole(role);
        return user;

    }
}
