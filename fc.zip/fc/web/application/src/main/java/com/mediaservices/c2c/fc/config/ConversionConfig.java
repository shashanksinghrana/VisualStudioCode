package com.mediaservices.c2c.fc.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.support.DefaultConversionService;

import com.mediaservices.c2c.fc.converter.BillingToBillingDtoConverter;
import com.mediaservices.c2c.fc.converter.CompensationToCompensationDtoConverter;
import com.mediaservices.c2c.fc.converter.ContractRiderToContractRiderDtoConverter;
import com.mediaservices.c2c.fc.converter.ContractToContractDtoConverter;
import com.mediaservices.c2c.fc.converter.CreditBillingToCreditBillingDtoConverter;
import com.mediaservices.c2c.fc.converter.CreditToCreditDetailDtoConverter;
import com.mediaservices.c2c.fc.converter.CrewToCrewDtoConverter;
import com.mediaservices.c2c.fc.converter.DealToDealDtoConverter;
import com.mediaservices.c2c.fc.converter.DealToDealMinimalDtoConverter;
import com.mediaservices.c2c.fc.converter.DealToPerformerDealDtoConverter;
import com.mediaservices.c2c.fc.converter.DynamicAttributeValueToLookupDtoConverter;
import com.mediaservices.c2c.fc.converter.FormulaDetailToFormulaDetailDtoConverter;
import com.mediaservices.c2c.fc.converter.FormulaToFormulaDtoConverter;
import com.mediaservices.c2c.fc.converter.LookupToLookupDtoConverter;
import com.mediaservices.c2c.fc.converter.PartyToPartyDtoConverter;
import com.mediaservices.c2c.fc.converter.PerqToPerqDtoConverter;
import com.mediaservices.c2c.fc.converter.PowerSearchCriteriaToSavedSearchCriteriaDtoConverter;
import com.mediaservices.c2c.fc.converter.PowerSearchQueryToSavedSearchQueryDtoConverter;
import com.mediaservices.c2c.fc.converter.ProjectAddressToLocationPeriodDto;
import com.mediaservices.c2c.fc.converter.ProjectCastingCompanyToCastingCompanyDtoConverter;
import com.mediaservices.c2c.fc.converter.ProjectNoteToProjectNoteDtoConverter;
import com.mediaservices.c2c.fc.converter.ProjectStatusDateToProjectStatusDateDtoConverter;
import com.mediaservices.c2c.fc.converter.ProjectTitleToProjectTitleDtoConverter;
import com.mediaservices.c2c.fc.converter.ProjectToAllProjectDtoConverter;
import com.mediaservices.c2c.fc.converter.ProjectToProjectDetailsDtoConverter;
import com.mediaservices.c2c.fc.converter.ProjectToProjectDtoConverter;
import com.mediaservices.c2c.fc.converter.SharedLookupToLookupDtoConverter;
import com.mediaservices.c2c.fc.converter.SignatoryUserToSignatoryUserDtoConverter;
import com.mediaservices.c2c.fc.converter.StringToTypeAheadRoleDtoConverter;
import com.mediaservices.c2c.fc.converter.TalentToPartyDtoConverter;
import com.mediaservices.c2c.fc.converter.TypeAheadNameDtoToLookupDtoConverter;
import com.mediaservices.c2c.fc.converter.UserToUserDtoConverter;
import com.mediaservices.c2c.fc.converter.WizardConfigToWizardDtoConverter;
import com.mediaservices.c2c.fc.converter.WizardStatusToWizardDtoConverter;
import com.mediaservices.c2c.fc.converter.WorkActivityToWorkActivityDtoConverter;
import com.mediaservices.c2c.fc.converter.WorkPeriodDetailDtoToWorkPeriodDetailConverter;
import com.mediaservices.c2c.fc.converter.WorkPeriodDetailToWorkPeriodDetailDtoConverter;
import com.mediaservices.c2c.fc.converter.WorkPeriodToWorkPeriodDtoConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToEmployentOfDayConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToIndividual1ParentCAConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToIndividual1ParentNonCAConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToIndividual2ParentCAConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToIndividual2ParentNonCAConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToIndividualNonUnionPerformerConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToLoanoutOfDayConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToMainTitleEndTitleContractConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToMinimumFreelanceConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToMinimumFreelanceLoanoutConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToNonUnionDayPerformerLoanoutConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToOneParentLoanoutCAConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToOneParentLoanoutNonCAConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToTwoParentLoanoutCAConverter;
import com.mediaservices.c2c.fc.converter.contracts.ContractDataToTwoParentsLoanoutNonCAConverter;
import com.mediaservices.c2c.fc.history.converter.ProjectHistoryToProjectDtoForDealConverter;
import com.mediaservices.c2c.fc.history.converter.ProjectTitleHistoryToProjectTitleDtoConverter;

/**
 * The Class ConversionConfig.
 */
@Configuration(value = "fcConversionConfig")
public class ConversionConfig {

    /** The emp of day converter. */
    @Autowired
    private ContractDataToEmployentOfDayConverter empOfDayConverter;

    /** The loanout of day converter. */
    @Autowired
    private ContractDataToLoanoutOfDayConverter loanoutOfDayConverter;

    /** The individual non union converter. */
    @Autowired
    private ContractDataToIndividualNonUnionPerformerConverter individualNonUnionConverter;

    /** The individual 1 parent CA converter. */
    @Autowired
    private ContractDataToIndividual1ParentCAConverter individual1ParentCAConverter;

    /** The individual 2 parent CA converter. */
    @Autowired
    private ContractDataToIndividual2ParentCAConverter individual2ParentCAConverter;

    /** The individual 1 parent non CA converter. */
    @Autowired
    private ContractDataToIndividual1ParentNonCAConverter individual1ParentNonCAConverter;

    /** The individual 2 parent non CA converter. */
    @Autowired
    private ContractDataToIndividual2ParentNonCAConverter individual2ParentNonCAConverter;

    /** The minimum freelance converter. */
    @Autowired
    private ContractDataToMinimumFreelanceConverter minimumFreelanceConverter;

    /** The minimum freelance loanout converter. */
    @Autowired
    private ContractDataToMinimumFreelanceLoanoutConverter minimumFreelanceLoanoutConverter;

    /** The non union day performer loanout converter. */
    @Autowired
    private ContractDataToNonUnionDayPerformerLoanoutConverter nonUnionDayPerformerLoanoutConverter;

    /** The one parent loanout CA converter. */
    @Autowired
    private ContractDataToOneParentLoanoutCAConverter oneParentLoanoutCAConverter;

    /** The two parent loanout CA converter. */
    @Autowired
    private ContractDataToTwoParentLoanoutCAConverter twoParentLoanoutCAConverter;

    /** The one parent loanout non CA converter. */
    @Autowired
    private ContractDataToOneParentLoanoutNonCAConverter oneParentLoanoutNonCAConverter;

    /** The two parents loanout non CA converter. */
    @Autowired
    private ContractDataToTwoParentsLoanoutNonCAConverter twoParentsLoanoutNonCAConverter;

    /** The project casting company to casting company dto converter. */
    @Autowired
    private ProjectCastingCompanyToCastingCompanyDtoConverter projectCastingCompanyToCastingCompanyDtoConverter;

    /** The project to project dto converter. */
    @Autowired
    private ProjectToProjectDtoConverter projectToProjectDtoConverter;

    /** The talent to party dto converter. */
    @Autowired
    private TalentToPartyDtoConverter talentToPartyDtoConverter;

    /** The deal to deal dto converter. */
    @Autowired
    private DealToDealDtoConverter dealToDealDtoConverter;

    @Autowired
    private DealToDealMinimalDtoConverter dealToDealMinimalDtoConverter;

    @Autowired
    private DealToPerformerDealDtoConverter dealToPerformerDealDtoConverter;

    @Autowired
    private CrewToCrewDtoConverter crewToCrewDtoConverter;

    @Autowired
    private ProjectAddressToLocationPeriodDto projectAddressToLocationPeriodDto;

    /** The work period detail dto to work period detail converter. */
    @Autowired
    private WorkPeriodDetailDtoToWorkPeriodDetailConverter workPeriodDetailDtoToWorkPeriodDetailConverter;

    /** The main title end title contract converter. */
    @Autowired
    private ContractDataToMainTitleEndTitleContractConverter mainTitleEndTitleContractConverter;

    @Autowired
    private ProjectToProjectDetailsDtoConverter  projectToProjectDetailsDtoConverter;

    /**
     * Fc converter.
     *
     * @return the conversion service
     */
    @Bean(name = "fcConverter")
    public ConversionService fcConverter() {
        final DefaultConversionService converterService = new DefaultConversionService();
        converterService.addConverter(projectToProjectDtoConverter);
        converterService.addConverter(new ProjectToAllProjectDtoConverter());
        converterService.addConverter(new LookupToLookupDtoConverter());
        converterService.addConverter(dealToDealDtoConverter);
        converterService.addConverter(dealToDealMinimalDtoConverter);
        converterService.addConverter(new SharedLookupToLookupDtoConverter());
        converterService.addConverter(new DynamicAttributeValueToLookupDtoConverter());
        converterService.addConverter(new ProjectTitleToProjectTitleDtoConverter());
        converterService.addConverter(new PartyToPartyDtoConverter());
        converterService.addConverter(new UserToUserDtoConverter());
        converterService.addConverter(projectCastingCompanyToCastingCompanyDtoConverter);
        converterService.addConverter(projectToProjectDetailsDtoConverter);
        converterService.addConverter(new ProjectNoteToProjectNoteDtoConverter());
        converterService.addConverter(new SignatoryUserToSignatoryUserDtoConverter());
        converterService.addConverter(dealToPerformerDealDtoConverter);
        converterService.addConverter(new WizardConfigToWizardDtoConverter());
        converterService.addConverter(new WizardStatusToWizardDtoConverter());
        converterService.addConverter(new FormulaDetailToFormulaDetailDtoConverter());
        converterService.addConverter(new FormulaToFormulaDtoConverter());
        converterService.addConverter(new CompensationToCompensationDtoConverter());
        converterService.addConverter(new PerqToPerqDtoConverter());
        converterService.addConverter(new CreditToCreditDetailDtoConverter());
        converterService.addConverter(new CreditBillingToCreditBillingDtoConverter());
        converterService.addConverter(new WorkActivityToWorkActivityDtoConverter());
        converterService.addConverter(new TypeAheadNameDtoToLookupDtoConverter());
        converterService.addConverter(new ContractRiderToContractRiderDtoConverter());
        converterService.addConverter(new ContractToContractDtoConverter());
        converterService.addConverter(minimumFreelanceConverter);
        converterService.addConverter(minimumFreelanceLoanoutConverter);
        converterService.addConverter(empOfDayConverter);
        converterService.addConverter(loanoutOfDayConverter);
        converterService.addConverter(individualNonUnionConverter);
        converterService.addConverter(individual1ParentCAConverter);
        converterService.addConverter(individual2ParentCAConverter);
        converterService.addConverter(individual1ParentNonCAConverter);
        converterService.addConverter(individual2ParentNonCAConverter);
        converterService.addConverter(nonUnionDayPerformerLoanoutConverter);
        converterService.addConverter(oneParentLoanoutCAConverter);
        converterService.addConverter(twoParentLoanoutCAConverter);
        converterService.addConverter(oneParentLoanoutNonCAConverter);
        converterService.addConverter(twoParentsLoanoutNonCAConverter);
        converterService.addConverter(new StringToTypeAheadRoleDtoConverter());
        converterService.addConverter(new PowerSearchCriteriaToSavedSearchCriteriaDtoConverter());
        converterService.addConverter(new PowerSearchQueryToSavedSearchQueryDtoConverter());
        converterService.addConverter(new BillingToBillingDtoConverter());
        converterService.addConverter(new ProjectStatusDateToProjectStatusDateDtoConverter());
        converterService.addConverter(new WorkPeriodToWorkPeriodDtoConverter());
        converterService.addConverter(new WorkPeriodDetailToWorkPeriodDetailDtoConverter());
        converterService.addConverter(workPeriodDetailDtoToWorkPeriodDetailConverter);
        converterService.addConverter(talentToPartyDtoConverter);
        converterService.addConverter(crewToCrewDtoConverter);
        converterService.addConverter(projectAddressToLocationPeriodDto);
        converterService.addConverter(mainTitleEndTitleContractConverter);
        converterService.addConverter(new ProjectHistoryToProjectDtoForDealConverter());
        converterService.addConverter(new ProjectTitleHistoryToProjectTitleDtoConverter());

        return converterService;
    }

}
