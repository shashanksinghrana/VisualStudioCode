package com.mediaservices.c2c.fc;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * The Class FeatureCastingApplication.
 */
@SpringBootApplication
@EnableAutoConfiguration
@EnableJpaRepositories("com.mediaservices.*")
@EntityScan("com.mediaservices.*")
@ComponentScan(basePackages = { "com.mediaservices.c2c.talent", "com.mediaservices.c2c.fc",
        "com.mediaservices.c2c.rollcall", "com.mediaservices.c2c.elasticsearch", "com.mediaservices.c2c.moduleaccess" })
public class FeatureCastingApplication implements WebMvcConfigurer {

    @Value("${server.servlet.context-path}")
    private String contextPath;

    /**
     * The main method.
     *
     * @param args
     *            the arguments
     */
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(FeatureCastingApplication.class);
        app.setWebApplicationType(WebApplicationType.SERVLET);
        app.run(args);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        WebMvcConfigurer.super.addResourceHandlers(registry);
        registry.addResourceHandler("/**").addResourceLocations("/", "classpath:/public/").setCachePeriod(3000000);
        registry.addResourceHandler("/**").addResourceLocations(contextPath, "classpath:/public/")
                .setCachePeriod(3000000);
        registry.addResourceHandler("index.html").addResourceLocations("/", "classpath:/public/");
        registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
    }

}
