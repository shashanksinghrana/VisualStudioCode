
package com.mediaservices.c2c.fc.config.security;

import java.util.Collections;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpMethod;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.security.web.util.matcher.RequestVariablesExtractor;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

/**
 * The Class AntPathRequestMatcherSAMLResponse.
 */
public class AntPathRequestMatcherSAMLResponse implements RequestMatcher, RequestVariablesExtractor {

    /** The Constant logger. */
    private static final Log logger = LogFactory.getLog(AntPathRequestMatcherSAMLResponse.class);

    /** The Constant MATCH_ALL. */
    private static final String MATCH_ALL = "/**";

    /** The matcher. */
    private final Matcher matcher;

    /** The pattern. */
    private final String pattern;

    /** The http method. */
    private final HttpMethod httpMethod;

    /** The case sensitive. */
    private final boolean caseSensitive;

    /**
     * Creates a matcher with the specific pattern which will match all HTTP methods
     * in a case insensitive manner.
     *
     * @param pattern
     *            the ant pattern to use for matching
     */
    public AntPathRequestMatcherSAMLResponse(String pattern) {
        this(pattern, null);
    }

    /**
     * Creates a matcher with the supplied pattern and HTTP method in a case
     * insensitive manner.
     *
     * @param pattern
     *            the ant pattern to use for matching
     * @param httpMethod
     *            the HTTP method. The {@code matches} method will return false if
     *            the incoming request doesn't have the same method.
     */
    public AntPathRequestMatcherSAMLResponse(String pattern, String httpMethod) {
        this(pattern, httpMethod, true);
    }

    /**
     * Creates a matcher with the supplied pattern which will match the specified
     * Http method.
     *
     * @param pattern
     *            the ant pattern to use for matching
     * @param httpMethod
     *            the HTTP method. The {@code matches} method will return false if
     *            the incoming request doesn't doesn't have the same method.
     * @param caseSensitive
     *            true if the matcher should consider case, else false
     */
    public AntPathRequestMatcherSAMLResponse(String pattern, String httpMethod, boolean caseSensitive) {
        Assert.hasText(pattern, "Pattern cannot be null or empty");
        this.caseSensitive = caseSensitive;

        if (pattern.equals(MATCH_ALL) || "**".equals(pattern)) {
            pattern = MATCH_ALL;
            this.matcher = null;
        } else {
            // If the pattern ends with {@code /**} and has no other wildcards
            // or path
            // variables, then optimize to a sub-path match
            if (pattern.endsWith(MATCH_ALL)
                    && (pattern.indexOf('?') == -1 && pattern.indexOf('{') == -1 && pattern.indexOf('}') == -1)
                    && pattern.indexOf('*') == pattern.length() - 2) {
                this.matcher = new SubpathMatcher(pattern.substring(0, pattern.length() - 3), caseSensitive);
            } else {
                this.matcher = new SpringAntMatcher(pattern, caseSensitive);
            }
        }

        this.pattern = pattern;
        this.httpMethod = StringUtils.hasText(httpMethod) ? HttpMethod.valueOf(httpMethod) : null;
    }

    /**
     * Returns true if the configured pattern (and HTTP-Method) match those of the
     * supplied request.
     *
     * @param request
     *            the request to match against. The ant pattern will be matched
     *            against the {@code servletPath} + {@code pathInfo} of the request.
     * @return true, if successful
     */
    @Override
    public boolean matches(HttpServletRequest request) {
        if (this.httpMethod != null && StringUtils.hasText(request.getMethod())
                && this.httpMethod != valueOf(request.getMethod())) {
            if (logger.isDebugEnabled()) {
                logger.debug("Request '" + request.getMethod() + " " + getRequestPath(request) + "'"
                        + " doesn't match '" + this.httpMethod + " " + this.pattern);
            }
            return false;
        }

        // Validate if request has parameter SAMLResponse
        if (!StringUtils.hasText(request.getParameter("SAMLResponse"))) {
            return false;
        }

        if (this.pattern.equals(MATCH_ALL)) {
            if (logger.isDebugEnabled()) {
                logger.debug("Request '" + getRequestPath(request) + "' matched by universal pattern '/**'");
            }

            return true;
        }

        String url = getRequestPath(request);

        if (logger.isDebugEnabled()) {
            logger.debug("Checking match of request : '" + url + "'; against '" + this.pattern + "'");
        }

        return this.matcher.matches(url);
    }

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.security.web.util.matcher.RequestVariablesExtractor#
     * extractUriTemplateVariables(javax.servlet.http.HttpServletRequest)
     */
    @Override
    public Map<String, String> extractUriTemplateVariables(HttpServletRequest request) {
        if (this.matcher == null || !matches(request)) {
            return Collections.emptyMap();
        }
        String url = getRequestPath(request);
        return this.matcher.extractUriTemplateVariables(url);
    }

    /**
     * Gets the request path.
     *
     * @param request
     *            the request
     * @return the request path
     */
    private String getRequestPath(HttpServletRequest request) {
        String url = request.getServletPath();

        if (request.getPathInfo() != null) {
            url += request.getPathInfo();
        }

        return url;
    }

    /**
     * Gets the pattern.
     *
     * @return the pattern
     */
    public String getPattern() {
        return this.pattern;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof AntPathRequestMatcherSAMLResponse)) {
            return false;
        }

        AntPathRequestMatcherSAMLResponse other = (AntPathRequestMatcherSAMLResponse) obj;
        return this.pattern.equals(other.pattern) && this.httpMethod == other.httpMethod
                && this.caseSensitive == other.caseSensitive;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        int code = 31 ^ this.pattern.hashCode();
        if (this.httpMethod != null) {
            code ^= this.httpMethod.hashCode();
        }
        return code;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Ant [pattern='").append(this.pattern).append("'");

        if (this.httpMethod != null) {
            sb.append(", ").append(this.httpMethod);
        }

        sb.append("]");

        return sb.toString();
    }

    /**
     * Provides a save way of obtaining the HttpMethod from a String. If the method
     * is invalid, returns null.
     *
     * @param method
     *            the HTTP method to use.
     *
     * @return the HttpMethod or null if method is invalid.
     */
    private static HttpMethod valueOf(String method) {
        try {
            return HttpMethod.valueOf(method);
        } catch (IllegalArgumentException e) {
            logger.warn("Error Occurned: returning null", e);
        }

        return null;
    }

    /**
     * The Interface Matcher.
     */
    private static interface Matcher {

        /**
         * Matches.
         *
         * @param path
         *            the path
         * @return true, if successful
         */
        boolean matches(String path);

        /**
         * Extract uri template variables.
         *
         * @param path
         *            the path
         * @return the map
         */
        Map<String, String> extractUriTemplateVariables(String path);
    }

    /**
     * The Class SpringAntMatcher.
     */
    private static class SpringAntMatcher implements Matcher {

        /** The ant matcher. */
        private final AntPathMatcher antMatcher;

        /** The pattern. */
        private final String pattern;

        /**
         * Instantiates a new spring ant matcher.
         *
         * @param pattern
         *            the pattern
         * @param caseSensitive
         *            the case sensitive
         */
        private SpringAntMatcher(String pattern, boolean caseSensitive) {
            this.pattern = pattern;
            this.antMatcher = createMatcher(caseSensitive);
        }

        /*
         * (non-Javadoc)
         *
         * @see com.mediaservices.c2c.talent.config.security.
         * AntPathRequestMatcherSAMLResponse.Matcher#matches(java.lang.String)
         */
        @Override
        public boolean matches(String path) {
            return this.antMatcher.match(this.pattern, path);
        }

        /*
         * (non-Javadoc)
         *
         * @see com.mediaservices.c2c.talent.config.security.
         * AntPathRequestMatcherSAMLResponse.Matcher#extractUriTemplateVariables(java.
         * lang.String)
         */
        @Override
        public Map<String, String> extractUriTemplateVariables(String path) {
            return this.antMatcher.extractUriTemplateVariables(this.pattern, path);
        }

        /**
         * Creates the matcher.
         *
         * @param caseSensitive
         *            the case sensitive
         * @return the ant path matcher
         */
        private static AntPathMatcher createMatcher(boolean caseSensitive) {
            AntPathMatcher matcher = new AntPathMatcher();
            matcher.setTrimTokens(false);
            matcher.setCaseSensitive(caseSensitive);
            return matcher;
        }
    }

    /**
     * Optimized matcher for trailing wildcards.
     */
    private static class SubpathMatcher implements Matcher {

        /** The subpath. */
        private final String subpath;

        /** The length. */
        private final int length;

        /** The case sensitive. */
        private final boolean caseSensitive;

        /**
         * Instantiates a new subpath matcher.
         *
         * @param subpath
         *            the subpath
         * @param caseSensitive
         *            the case sensitive
         */
        private SubpathMatcher(String subpath, boolean caseSensitive) {
            assert !subpath.contains("*");
            this.subpath = caseSensitive ? subpath : subpath.toLowerCase();
            this.length = subpath.length();
            this.caseSensitive = caseSensitive;
        }

        /*
         * (non-Javadoc)
         *
         * @see com.mediaservices.c2c.talent.config.security.
         * AntPathRequestMatcherSAMLResponse.Matcher#matches(java.lang.String)
         */
        @Override
        public boolean matches(String path) {
            if (!this.caseSensitive) {
                path = path.toLowerCase();
            }
            return path.startsWith(this.subpath) && (path.length() == this.length || path.charAt(this.length) == '/');
        }

        /*
         * (non-Javadoc)
         *
         * @see com.mediaservices.c2c.talent.config.security.
         * AntPathRequestMatcherSAMLResponse.Matcher#extractUriTemplateVariables(java.
         * lang.String)
         */
        @Override
        public Map<String, String> extractUriTemplateVariables(String path) {
            return Collections.emptyMap();
        }
    }
}