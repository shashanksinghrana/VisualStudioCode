package com.mediaservices.c2c.fc.config.security;

import java.util.Date;

import org.springframework.security.saml.SAMLAuthenticationProvider;
import org.springframework.security.saml.SAMLCredential;

/**
 * The Class SAMLAuthenticationProviderCustom overrides some default behavior.
 */
public class SAMLAuthenticationProviderCustom extends SAMLAuthenticationProvider {

    /**
     * Ignore the expiration date which is sent in SAML assertion as part of
     * sessionNotOnOrAfter field.
     */
    @Override
    protected Date getExpirationDate(SAMLCredential credential) {
        return null;
    }

}
