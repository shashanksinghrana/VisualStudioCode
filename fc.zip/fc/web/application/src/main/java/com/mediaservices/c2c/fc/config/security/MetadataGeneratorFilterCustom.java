package com.mediaservices.c2c.fc.config.security;

import java.net.URI;
import java.net.URISyntaxException;

import javax.servlet.http.HttpServletRequest;

import org.opensaml.util.SimpleURLCanonicalizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.saml.metadata.MetadataGenerator;
import org.springframework.security.saml.metadata.MetadataGeneratorFilter;
import org.springframework.util.StringUtils;

import com.mediaservices.c2c.talent.execption.TalentApplicationException;

/**
 * The Class MetadataGeneratorFilterCustom overrides the implementation set
 * custom default entityId.
 */
public class MetadataGeneratorFilterCustom extends MetadataGeneratorFilter {

    /** The default entity id. */
    @Value("${sso.default.entityId:/saml/SSO}")
    private String defaultEntityId;

    /** The context path. */
    @Value("${CONTEXT_PATH:}")
    private String contextPath;

    private static final Logger LOGGER = LoggerFactory.getLogger(MetadataGeneratorFilterCustom.class);

    /**
     * Instantiates a new metadata generator filter custom.
     *
     * @param generator
     *            the generator
     */
    public MetadataGeneratorFilterCustom(MetadataGenerator generator) {
        super(generator);
    }

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.security.saml.metadata.MetadataGeneratorFilter#
     * getDefaultEntityID(java.lang.String, java.lang.String)
     */
    @Override
    protected String getDefaultEntityID(String entityBaseUrl, String alias) {

        String displayFilterUrl = defaultEntityId;

        StringBuilder sb = new StringBuilder();
        sb.append(entityBaseUrl);
        sb.append(displayFilterUrl);

        if (StringUtils.hasLength(alias)) {
            sb.append("/alias/");
            sb.append(alias);
        }

        return sb.toString();

    }

    @Override
    protected String getDefaultBaseURL(HttpServletRequest request) {
        if (contextPath.endsWith("/")) {
            contextPath = contextPath.substring(0, contextPath.lastIndexOf('/'));
        }
        URI contextUri = null;
        try {
            contextUri = new URI(contextPath);
            StringBuilder sb = new StringBuilder();
            sb.append(contextUri.getScheme()).append("://").append(contextUri.getHost());
            if (contextUri.getPort() != -1) {
                sb.append(":").append(contextUri.getPort());
            }
            sb.append(contextUri.getPath());
            String url = sb.toString();
            LOGGER.info(url);
            if (isNormalizeBaseUrl()) {
                return SimpleURLCanonicalizer.canonicalize(url);
            } else {
                return url;
            }
        } catch (URISyntaxException e) {
            throw new TalentApplicationException(e.getLocalizedMessage(), e);
        }
    }
}
