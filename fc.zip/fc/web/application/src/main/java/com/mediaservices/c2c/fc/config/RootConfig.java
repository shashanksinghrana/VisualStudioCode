package com.mediaservices.c2c.fc.config;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import com.mediaservices.c2c.moduleaccess.dto.EntityManagerHolder;

@Configuration
public class RootConfig {

    @PersistenceContext
    private EntityManager em;

    /**
     * Message source.
     *
     * @return the reloadable resource bundle message source
     */
    @Bean(name = "messageSource")
    public MessageSource messageSource() {
        final ReloadableResourceBundleMessageSource messageBundle = new ReloadableResourceBundleMessageSource();
        messageBundle.setBasename("classpath:validationmessages");
        messageBundle.setDefaultEncoding("UTF-8");
        return messageBundle;
    }

    @Bean
    public EntityManagerHolder entityManagerHolder() {
        return new EntityManagerHolder(em);
    }
}
