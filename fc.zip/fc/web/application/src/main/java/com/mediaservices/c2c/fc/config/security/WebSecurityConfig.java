package com.mediaservices.c2c.fc.config.security;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Timer;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import org.opensaml.saml2.metadata.provider.FilesystemMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.xml.parse.ParserPool;
import org.opensaml.xml.parse.StaticBasicParserPool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.TestingAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.saml.SAMLAuthenticationProvider;
import org.springframework.security.saml.SAMLBootstrap;
import org.springframework.security.saml.SAMLDiscovery;
import org.springframework.security.saml.SAMLEntryPoint;
import org.springframework.security.saml.SAMLLogoutFilter;
import org.springframework.security.saml.SAMLLogoutProcessingFilter;
import org.springframework.security.saml.SAMLProcessingFilter;
import org.springframework.security.saml.SAMLWebSSOHoKProcessingFilter;
import org.springframework.security.saml.context.SAMLContextProviderImpl;
import org.springframework.security.saml.context.SAMLContextProviderLB;
import org.springframework.security.saml.key.EmptyKeyManager;
import org.springframework.security.saml.key.KeyManager;
import org.springframework.security.saml.log.SAMLDefaultLogger;
import org.springframework.security.saml.metadata.CachingMetadataManager;
import org.springframework.security.saml.metadata.ExtendedMetadata;
import org.springframework.security.saml.metadata.ExtendedMetadataDelegate;
import org.springframework.security.saml.metadata.MetadataDisplayFilter;
import org.springframework.security.saml.metadata.MetadataGenerator;
import org.springframework.security.saml.metadata.MetadataGeneratorFilter;
import org.springframework.security.saml.parser.ParserPoolHolder;
import org.springframework.security.saml.processor.HTTPArtifactBinding;
import org.springframework.security.saml.processor.HTTPPAOS11Binding;
import org.springframework.security.saml.processor.HTTPPostBinding;
import org.springframework.security.saml.processor.HTTPRedirectDeflateBinding;
import org.springframework.security.saml.processor.HTTPSOAP11Binding;
import org.springframework.security.saml.processor.SAMLBinding;
import org.springframework.security.saml.processor.SAMLProcessorImpl;
import org.springframework.security.saml.trust.httpclient.TLSProtocolConfigurer;
import org.springframework.security.saml.trust.httpclient.TLSProtocolSocketFactory;
import org.springframework.security.saml.util.VelocityFactory;
import org.springframework.security.saml.websso.ArtifactResolutionProfile;
import org.springframework.security.saml.websso.ArtifactResolutionProfileImpl;
import org.springframework.security.saml.websso.SingleLogoutProfile;
import org.springframework.security.saml.websso.SingleLogoutProfileImpl;
import org.springframework.security.saml.websso.WebSSOProfile;
import org.springframework.security.saml.websso.WebSSOProfileConsumer;
import org.springframework.security.saml.websso.WebSSOProfileConsumerHoKImpl;
import org.springframework.security.saml.websso.WebSSOProfileConsumerImpl;
import org.springframework.security.saml.websso.WebSSOProfileECPImpl;
import org.springframework.security.saml.websso.WebSSOProfileImpl;
import org.springframework.security.saml.websso.WebSSOProfileOptions;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.firewall.HttpFirewall;
import org.springframework.security.web.firewall.StrictHttpFirewall;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.mediaservices.c2c.fc.service.impl.SAMLUserServiceImpl;

/***
 * The Class WebSecurityConfig provides the implementation of spring
 * security*for SAML integration.
 */

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    private static final String INDEX_HTML = "/index.html";

    /** The is IDM enabled. */
    @Value("${sso.enabled:true}")
    private boolean ssoEnabled;

    /** The context path. */
    @Value("${CONTEXT_PATH:}")
    private String contextPath;

    /** SAML process URL. */
    @Value("${sso.saml.process.url:/saml/SSO}")
    private String samlProcessUrl;

    /** The sp medatada file. */
    @Value("${sso.sp.metadata.file:}")
    private String spMedatadaFile;

    /** The hosted SP name. */
    @Value("${sso.sp.name:}")
    private String hostedSPName;

    /** The idp medatada file. */
    @Value("${sso.idp.metadata.file}")
    private String idpMedatadaFile;

    /** The sign metadata. */
    @Value("${sso.sign.metadata:true}")
    private boolean signMetadata;

    /** The idp discovery enabled. */
    @Value("${sso.idp.discovery.enabled:false}")
    private boolean idpDiscoveryEnabled;

    /** The metadata trust check. */
    @Value("${sso.metadata.trust.check:true}")
    private boolean metadataTrustCheck;

    /** The metadata require signature. */
    @Value("${sso.metadata.require.signature:false}")
    private boolean metadataRequireSignature;

    /** The require logout request signed. */
    @Value("${sso.require.logout.request.signed:false}")
    private boolean requireLogoutRequestSigned;

    /** The require logout response signed. */
    @Value("${sso.require.logout.response.signed:false}")
    private boolean requireLogoutResponseSigned;

    /** The entity id. */
    @Value("${sso.sp.entityId:}")
    private String entityId;

    /** The response skew in seconds. */
    @Value("${sso.response.skew.seconds:60}")
    private int responseSkewInSeconds;

    /** The max authentication age in sec. */
    @Value("${sso.max.authentication.age.seconds:7200}")
    private long maxAuthenticationAgeInSec;

    /** The max assertion time. */
    @Value("${sso.max.assertion.valid.seconds:3000}")
    private int maxAssertionTime;

    /** The saml user details service impl. */
    @Autowired
    private SAMLUserServiceImpl samlUserDetailsServiceImpl;

    /** The background task timer. */
    private Timer backgroundTaskTimer;

    /** The multi threaded http connection manager. */
    private MultiThreadedHttpConnectionManager multiThreadedHttpConnectionManager;

    /**
     * Inits the.
     */
    @PostConstruct
    public void init() {
        this.backgroundTaskTimer = new Timer(true);
        this.multiThreadedHttpConnectionManager = new MultiThreadedHttpConnectionManager();
    }

    /**
     * Destroy.
     */
    @PreDestroy
    public void destroy() {
        this.backgroundTaskTimer.purge();
        this.backgroundTaskTimer.cancel();
        this.multiThreadedHttpConnectionManager.shutdown();
    }

    /**
     * Initialization of the velocity engine
     *
     * @return the velocity engine
     */
    @Bean
    public VelocityEngine velocityEngine() {
        return VelocityFactory.getEngine();
    }

    /**
     * XML parser pool needed for OpenSAML parsing
     *
     * @return the static basic parser pool
     */
    @Bean(initMethod = "initialize")
    public StaticBasicParserPool parserPool() {
        return new StaticBasicParserPool();
    }

    /**
     * Parser pool holder.
     *
     * @return the parser pool holder
     */
    @Bean(name = "parserPoolHolder")
    public ParserPoolHolder parserPoolHolder() {
        return new ParserPoolHolder();
    }

    /**
     * Bindings, encoders and decoders used for creating and parsing messages
     *
     * @return the http client
     */
    @Bean
    public HttpClient httpClient() {
        return new HttpClient(this.multiThreadedHttpConnectionManager);
    }

    /**
     * SAML Authentication Provider responsible for validating of received SAML
     * messages
     *
     * @return the SAML authentication provider
     */
    @Bean
    public SAMLAuthenticationProvider samlAuthenticationProvider() {
        SAMLAuthenticationProvider samlAuthenticationProvider = new SAMLAuthenticationProviderCustom();
        samlAuthenticationProvider.setUserDetails(samlUserDetailsServiceImpl);
        samlAuthenticationProvider.setForcePrincipalAsString(false);
        return samlAuthenticationProvider;
    }

    /**
     * Provider of default SAML Context
     *
     * @return the SAML context provider impl
     * @throws URISyntaxException
     *             the URI syntax exception
     */
    @Bean
    public SAMLContextProviderImpl contextProvider() throws URISyntaxException {
        if (StringUtils.isNotBlank(contextPath)) {
            if (contextPath.endsWith("/")) {
                contextPath = contextPath.substring(0, contextPath.lastIndexOf('/'));
            }
            URI contextUri = new URI(contextPath);
            SAMLContextProviderLB sAMLContextProviderLB = new SAMLContextProviderLB();
            sAMLContextProviderLB.setContextPath(contextUri.getPath());
            sAMLContextProviderLB.setScheme(contextUri.getScheme());
            String serverName = contextUri.getHost();
            if (contextUri.getPort() != -1) {
                serverName += ":" + contextUri.getPort();
            } else {
                sAMLContextProviderLB.setIncludeServerPortInRequestURL(false);
            }
            sAMLContextProviderLB.setServerName(serverName);
            return sAMLContextProviderLB;
        } else {
            return new SAMLContextProviderImpl();
        }
    }

    /**
     * Initialization of OpenSAML library
     *
     * @return the SAML bootstrap
     */
    @Bean
    public static SAMLBootstrap sAMLBootstrap() {
        return new SAMLBootstrap();
    }

    /**
     * Logger for SAML messages and events
     *
     * @return the SAML default logger
     */
    @Bean
    public SAMLDefaultLogger samlLogger() {
        return new SAMLDefaultLogger();
    }

    /**
     * SAML 2.0 WebSSO Assertion Consumer
     *
     * @return the web SSO profile consumer
     */
    @Bean
    public WebSSOProfileConsumer webSSOprofileConsumer() {
        WebSSOProfileConsumerImpl webSSOProfileConsumer = new WebSSOProfileConsumerImpl();
        webSSOProfileConsumer.setMaxAssertionTime(maxAssertionTime);
        webSSOProfileConsumer.setResponseSkew(responseSkewInSeconds);
        webSSOProfileConsumer.setMaxAuthenticationAge(maxAuthenticationAgeInSec);
        return webSSOProfileConsumer;
    }

    /**
     * SAML 2.0 Holder-of-Key WebSSO Assertion Consumer
     *
     * @return the web SSO profile consumer ho K impl
     */
    @Bean
    public WebSSOProfileConsumerHoKImpl hokWebSSOprofileConsumer() {
        return new WebSSOProfileConsumerHoKImpl();
    }

    /**
     * SAML 2.0 Web SSO profile
     *
     * @return the web SSO profile
     */
    @Bean
    public WebSSOProfile webSSOprofile() {
        return new WebSSOProfileImpl();
    }

    /**
     * SAML 2.0 Holder-of-Key Web SSO profile
     *
     * @return the web SSO profile consumer ho K impl
     */
    @Bean
    public WebSSOProfileConsumerHoKImpl hokWebSSOProfile() {
        return new WebSSOProfileConsumerHoKImpl();
    }

    /**
     * SAML 2.0 ECP profile
     *
     * @return the web SSO profile ECP impl
     */
    @Bean
    public WebSSOProfileECPImpl ecpprofile() {
        return new WebSSOProfileECPImpl();
    }

    /**
     * SAML 2.0 Logout Profile
     *
     * @return the single logout profile
     */
    @Bean
    public SingleLogoutProfile logoutprofile() {
        SingleLogoutProfileImpl singleLogoutProfile = new SingleLogoutProfileImpl();
        singleLogoutProfile.setMaxAssertionTime(maxAssertionTime);
        singleLogoutProfile.setResponseSkew(responseSkewInSeconds);
        return singleLogoutProfile;
    }

    /**
     * Central storage of cryptographic keys
     *
     * @return the key manager
     */
    @Bean
    public KeyManager keyManager() {
        return new EmptyKeyManager();
    }

    /**
     * Setup TLS Socket Factory
     *
     * @return the TLS protocol configurer
     */
    @Bean
    public TLSProtocolConfigurer tlsProtocolConfigurer() {
        return new TLSProtocolConfigurer();
    }

    /**
     * Socket factory.
     *
     * @return the protocol socket factory
     */
    @Bean
    public ProtocolSocketFactory socketFactory() {
        return new TLSProtocolSocketFactory(keyManager(), null, "allowAll");
    }

    /**
     * Socket factory protocol.
     *
     * @return the protocol
     */
    @Bean
    public Protocol socketFactoryProtocol() {
        return new Protocol("https", socketFactory(), 443);
    }

    /**
     * Socket factory initialization.
     *
     * @return the method invoking factory bean
     */
    @Bean
    public MethodInvokingFactoryBean socketFactoryInitialization() {
        MethodInvokingFactoryBean methodInvokingFactoryBean = new MethodInvokingFactoryBean();
        methodInvokingFactoryBean.setTargetClass(Protocol.class);
        methodInvokingFactoryBean.setTargetMethod("registerProtocol");
        Object[] args = { "https", socketFactoryProtocol() };
        methodInvokingFactoryBean.setArguments(args);
        return methodInvokingFactoryBean;
    }

    /**
     * Default web SSO profile options.
     *
     * @return the web SSO profile options
     */
    @Bean
    public WebSSOProfileOptions defaultWebSSOProfileOptions() {
        WebSSOProfileOptions webSSOProfileOptions = new WebSSOProfileOptions();
        webSSOProfileOptions.setIncludeScoping(false);
        return webSSOProfileOptions;
    }

    /**
     * Entry point to initialize authentication, default values taken from
     * properties file
     *
     * @return the SAML entry point
     */
    @Bean
    public SAMLEntryPoint samlEntryPoint() {
        SAMLEntryPoint samlEntryPoint = new SAMLEntryPoint();
        samlEntryPoint.setDefaultProfileOptions(defaultWebSSOProfileOptions());

        return samlEntryPoint;
    }

    /**
     * Setup advanced info about metadata
     *
     * @return the extended metadata
     */
    @Bean
    public ExtendedMetadata extendedMetadata() {
        ExtendedMetadata extendedMetadata = new ExtendedMetadata();
        extendedMetadata.setIdpDiscoveryEnabled(idpDiscoveryEnabled);
        extendedMetadata.setSignMetadata(signMetadata);
        extendedMetadata.setEcpEnabled(true);

        extendedMetadata.setRequireLogoutRequestSigned(requireLogoutRequestSigned);
        extendedMetadata.setRequireLogoutResponseSigned(requireLogoutResponseSigned);
        return extendedMetadata;
    }

    /**
     * IDP Discovery Service
     *
     * @return the SAML discovery
     */
    @Bean
    public SAMLDiscovery samlIDPDiscovery() {
        return new SAMLDiscovery();
    }

    /**
     * Idp extended metadata provider.
     *
     * @return the extended metadata delegate
     * @throws MetadataProviderException
     *             the metadata provider exception
     */
    @Bean
    @Qualifier("idp-metadata")
    public ExtendedMetadataDelegate idpExtendedMetadataProvider() throws MetadataProviderException {
        FilesystemMetadataProvider httpMetadataProvider = new FilesystemMetadataProvider(this.backgroundTaskTimer,
                new File(idpMedatadaFile));
        httpMetadataProvider.setParserPool(parserPool());
        httpMetadataProvider.setFailFastInitialization(ssoEnabled);
        ExtendedMetadataDelegate extendedMetadataDelegate = new ExtendedMetadataDelegate(httpMetadataProvider,
                extendedMetadata());
        extendedMetadataDelegate.setMetadataTrustCheck(metadataTrustCheck);
        extendedMetadataDelegate.setMetadataRequireSignature(metadataRequireSignature);
        backgroundTaskTimer.purge();
        return extendedMetadataDelegate;
    }

    /**
     * Sp extended metadata provider.
     *
     * @return the extended metadata delegate
     * @throws MetadataProviderException
     *             the metadata provider exception
     */
    public ExtendedMetadataDelegate spExtendedMetadataProvider() throws MetadataProviderException {
        FilesystemMetadataProvider httpMetadataProvider = new FilesystemMetadataProvider(this.backgroundTaskTimer,
                new File(spMedatadaFile));
        httpMetadataProvider.setParserPool(parserPool());
        httpMetadataProvider.setFailFastInitialization(ssoEnabled);
        ExtendedMetadataDelegate extendedMetadataDelegate = new ExtendedMetadataDelegate(httpMetadataProvider,
                extendedMetadata());
        extendedMetadataDelegate.setMetadataTrustCheck(metadataTrustCheck);
        extendedMetadataDelegate.setMetadataRequireSignature(metadataRequireSignature);
        backgroundTaskTimer.purge();
        return extendedMetadataDelegate;
    }

    /**
     * IDP & SP Metadata configuration - paths to metadata of IDPs & SP in
     * circle of trust is here Do no forget to call iniitalize method on
     * providers
     *
     * @return the caching metadata manager
     * @throws MetadataProviderException
     *             the metadata provider exception
     */
    @Bean
    @Qualifier("metadata")
    public CachingMetadataManager metadata() throws MetadataProviderException {
        List<MetadataProvider> providers = new ArrayList<>();
        providers.add(idpExtendedMetadataProvider());
        if (StringUtils.isNotBlank(hostedSPName)) {
            providers.add(spExtendedMetadataProvider());
        }
        CachingMetadataManager metadataManager = new CachingMetadataManager(providers);
        if (StringUtils.isNotBlank(hostedSPName)) {
            metadataManager.setHostedSPName(hostedSPName);
        }
        return metadataManager;
    }

    /**
     * Filter automatically generates default SP metadata
     *
     * @return the metadata generator
     */
    @Bean
    public MetadataGenerator metadataGenerator() {
        MetadataGenerator metadataGenerator = new MetadataGenerator();
        metadataGenerator.setExtendedMetadata(extendedMetadata());
        metadataGenerator.setIncludeDiscoveryExtension(false);
        metadataGenerator.setKeyManager(keyManager());
        if (StringUtils.isNotBlank(entityId)) {
            metadataGenerator.setEntityId(entityId);
        }

        metadataGenerator.setRequestSigned(false);
        metadataGenerator.setWantAssertionSigned(false);
        if (StringUtils.isNotBlank(contextPath)) {
            metadataGenerator.setEntityBaseURL(contextPath);
        }
        return metadataGenerator;
    }

    /**
     * The filter is waiting for connections on URL suffixed with filterSuffix
     * and presents SP metadata there
     *
     * @return the metadata display filter
     */
    @Bean
    public MetadataDisplayFilter metadataDisplayFilter() {
        return new MetadataDisplayFilter();
    }

    /**
     * Handler deciding where to redirect user after successful login
     *
     * @return the saved request aware authentication success handler
     */
    @Bean
    public SavedRequestAwareAuthenticationSuccessHandler successRedirectHandler() {
        SavedRequestAwareAuthenticationSuccessHandler successRedirectHandler = new SavedRequestAwareAuthenticationSuccessHandler();
        successRedirectHandler.setDefaultTargetUrl(INDEX_HTML);
        return successRedirectHandler;
    }

    /**
     * Handler deciding where to redirect user after failed login
     *
     * @return the simple url authentication failure handler
     */
    @Bean
    public SimpleUrlAuthenticationFailureHandler authenticationFailureHandler() {
        SimpleUrlAuthenticationFailureHandler failureHandler = new SimpleUrlAuthenticationFailureHandler();
        failureHandler.setUseForward(false);
        failureHandler.setDefaultFailureUrl("/LoginError.html");
        return failureHandler;
    }

    /**
     * Saml web SSO ho K processing filter.
     *
     * @return the SAML web SSO ho K processing filter
     * @throws Exception
     *             the exception
     */
    @Bean
    public SAMLWebSSOHoKProcessingFilter samlWebSSOHoKProcessingFilter() throws Exception {
        SAMLWebSSOHoKProcessingFilter samlWebSSOHoKProcessingFilter = new SAMLWebSSOHoKProcessingFilter();
        samlWebSSOHoKProcessingFilter.setAuthenticationSuccessHandler(successRedirectHandler());
        samlWebSSOHoKProcessingFilter.setAuthenticationManager(authenticationManager());
        samlWebSSOHoKProcessingFilter.setAuthenticationFailureHandler(authenticationFailureHandler());
        return samlWebSSOHoKProcessingFilter;
    }

    /**
     * Processing filter for WebSSO profile messages
     *
     * @return the SAML processing filter
     * @throws Exception
     *             the exception
     */
    @Bean
    public SAMLProcessingFilter samlWebSSOProcessingFilter() throws Exception {
        SAMLProcessingFilter samlWebSSOProcessingFilter;
        if (SAMLProcessingFilter.FILTER_URL.equals(samlProcessUrl)) {
            samlWebSSOProcessingFilter = new SAMLProcessingFilter();
        } else {
            samlWebSSOProcessingFilter = new SAMLProcessingFilterCustom(samlProcessUrl);
        }

        samlWebSSOProcessingFilter.setAuthenticationManager(authenticationManager());
        samlWebSSOProcessingFilter.setAuthenticationSuccessHandler(successRedirectHandler());
        samlWebSSOProcessingFilter.setAuthenticationFailureHandler(authenticationFailureHandler());
        return samlWebSSOProcessingFilter;
    }

    /**
     * Metadata generator filter.
     *
     * @return the metadata generator filter
     * @throws MetadataProviderException
     *             the metadata provider exception
     */
    @Bean
    public MetadataGeneratorFilter metadataGeneratorFilter() throws MetadataProviderException {
        MetadataGeneratorFilter metadataGeneratorFilter = new MetadataGeneratorFilter(metadataGenerator());
        metadataGeneratorFilter.setNormalizeBaseUrl(true);
        return metadataGeneratorFilter;
    }

    /**
     * Handler for successful logout
     *
     * @return the simple url logout success handler
     */
    @Bean
    public SimpleUrlLogoutSuccessHandler successLogoutHandler() {
        SimpleUrlLogoutSuccessHandler successLogoutHandler = new SimpleUrlLogoutSuccessHandler();
        successLogoutHandler.setDefaultTargetUrl(INDEX_HTML);
        return successLogoutHandler;
    }

    /**
     * Logout handler terminating local session
     *
     * @return the security context logout handler
     */
    @Bean
    public SecurityContextLogoutHandler logoutHandler() {
        SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
        logoutHandler.setInvalidateHttpSession(true);
        logoutHandler.setClearAuthentication(true);
        return logoutHandler;
    }

    /**
     * Filter processing incoming logout messages First argument determines URL
     * user will be redirected to after successful global logout
     *
     * @return the SAML logout processing filter
     */
    @Bean
    public SAMLLogoutProcessingFilter samlLogoutProcessingFilter() {
        return new SAMLLogoutProcessingFilter(successLogoutHandler(), logoutHandler());
    }

    /**
     * Overrides default logout processing filter with the one processing SAML
     * messages
     *
     * @return the SAML logout filter
     */
    @Bean
    public SAMLLogoutFilter samlLogoutFilter() {
        return new SAMLLogoutFilter(successLogoutHandler(), new LogoutHandler[] { logoutHandler() },
                new LogoutHandler[] { logoutHandler() });
    }

    /**
     * Bindings
     *
     * @return the artifact resolution profile
     */
    private ArtifactResolutionProfile artifactResolutionProfile() {
        final ArtifactResolutionProfileImpl artifactResolutionProfile = new ArtifactResolutionProfileImpl(httpClient());
        artifactResolutionProfile.setProcessor(new SAMLProcessorImpl(soapBinding()));
        return artifactResolutionProfile;
    }

    /**
     * Artifact binding.
     *
     * @param parserPool
     *            the parser pool
     * @param velocityEngine
     *            the velocity engine
     * @return the HTTP artifact binding
     */
    @Bean
    public HTTPArtifactBinding artifactBinding(ParserPool parserPool, VelocityEngine velocityEngine) {
        return new HTTPArtifactBinding(parserPool, velocityEngine, artifactResolutionProfile());
    }

    /**
     * Soap binding.
     *
     * @return the HTTPSOAP 11 binding
     */
    @Bean
    public HTTPSOAP11Binding soapBinding() {
        return new HTTPSOAP11Binding(parserPool());
    }

    /**
     * Http post binding.
     *
     * @return the HTTP post binding
     */
    @Bean
    public HTTPPostBinding httpPostBinding() {
        return new HTTPPostBinding(parserPool(), velocityEngine());
    }

    /**
     * Http redirect deflate binding.
     *
     * @return the HTTP redirect deflate binding
     */
    @Bean
    public HTTPRedirectDeflateBinding httpRedirectDeflateBinding() {
        return new HTTPRedirectDeflateBinding(parserPool());
    }

    /**
     * Http SOAP 11 binding.
     *
     * @return the HTTPSOAP 11 binding
     */
    @Bean
    public HTTPSOAP11Binding httpSOAP11Binding() {
        return new HTTPSOAP11Binding(parserPool());
    }

    /**
     * Http PAOS 11 binding.
     *
     * @return the HTTPPAOS 11 binding
     */
    @Bean
    public HTTPPAOS11Binding httpPAOS11Binding() {
        return new HTTPPAOS11Binding(parserPool());
    }

    /**
     * Processor.
     *
     * @return the SAML processor impl
     */
    @Bean
    public SAMLProcessorImpl processor() {
        Collection<SAMLBinding> bindings = new ArrayList<>();
        bindings.add(httpRedirectDeflateBinding());
        bindings.add(httpPostBinding());
        bindings.add(artifactBinding(parserPool(), velocityEngine()));
        bindings.add(httpSOAP11Binding());
        bindings.add(httpPAOS11Binding());
        return new SAMLProcessorImpl(bindings);
    }

    /**
     * Define the security filter chain in order to support SSO Auth by using
     * SAML 2.0
     *
     * @return Filter chain proxy
     * @throws Exception
     *             the exception
     */
    @Bean
    public FilterChainProxy samlFilter() throws Exception {
        List<SecurityFilterChain> chains = new ArrayList<>();
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/login/**"), samlEntryPoint()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/logout/**"), samlLogoutFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/metadata/**"),
                metadataDisplayFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcherSAMLResponse(samlProcessUrl),
                samlWebSSOProcessingFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/SSOHoK/**"),
                samlWebSSOHoKProcessingFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/SingleLogout/**"),
                samlLogoutProcessingFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/discovery/**"), samlIDPDiscovery()));
        FilterChainProxy filterChainProxy = new FilterChainProxy(chains);
        filterChainProxy.setFirewall(allowUrlEncodedSlashHttpFirewall());
        return filterChainProxy;
    }

    /**
     * Returns the authentication manager currently used by Spring. It
     * represents a bean definition with the aim allow wiring from other classes
     * performing the Inversion of Control (IoC).
     *
     * @return the authentication manager
     * @throws Exception
     *             the exception
     */
    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    /**
     * Defines the web based security configuration.
     *
     * @param http
     *            It allows configuring web based security for specific http
     *            requests.
     * @throws Exception
     *             the exception
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        if (ssoEnabled) {
            http.httpBasic().authenticationEntryPoint(samlEntryPoint());
            http.csrf().disable();
            http.addFilterBefore(metadataGeneratorFilter(), ChannelProcessingFilter.class).addFilterAfter(samlFilter(),
                    BasicAuthenticationFilter.class);
            http.authorizeRequests()
                    // allow all to see the error page
                    .antMatchers("/error").permitAll().antMatchers("/LoginError.html").permitAll()
                    .antMatchers("/c2c-banner*.png").permitAll()
                    // allow all to access the login
                    .antMatchers("/saml/**").permitAll()
                    // Everything else requires the TALENT.VEIW permission from
                    // the DB
                    .anyRequest().hasAuthority("FEATURE_CASTING.VIEW");
            http.logout().logoutSuccessUrl(INDEX_HTML);
        } else {
            http.httpBasic().disable();
            http.csrf().disable();
            http.authorizeRequests().anyRequest().permitAll();
        }
    }

    /**
     * Override this method to configure {@link WebSecurity}. For example, if
     * you wish to ignore certain requests.
     *
     * @param web
     *            the web
     * @throws Exception
     *             the exception
     */
    @Override
    public void configure(WebSecurity web) throws Exception {
        super.configure(web);
        web.httpFirewall(allowUrlEncodedSlashHttpFirewall());
    }

    /**
     * Allow url encoded slash http firewall.
     *
     * @return the http firewall
     */
    @Bean
    public HttpFirewall allowUrlEncodedSlashHttpFirewall() {
        StrictHttpFirewall firewall = new StrictHttpFirewall();
        firewall.setAllowUrlEncodedSlash(true);
        firewall.setAllowBackSlash(true);
        firewall.setAllowUrlEncodedPercent(true);
        firewall.setAllowUrlEncodedPeriod(true);
        firewall.setAllowSemicolon(true);
        return firewall;
    }

    /**
     * Sets a custom authentication provider.
     *
     * @param auth
     *            SecurityBuilder used to create an AuthenticationManager.
     * @throws Exception
     *             the exception
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        if (ssoEnabled) {
            auth.authenticationProvider(samlAuthenticationProvider());
        } else {
            auth.authenticationProvider(new TestingAuthenticationProvider());
        }
    }

}