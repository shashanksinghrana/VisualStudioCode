package com.mediaservices.c2c.fc.config.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.saml.SAMLProcessingFilter;
import org.springframework.util.StringUtils;

/*
 * The Class SAMLProcessingFilterCustom.
 */
public class SAMLProcessingFilterCustom extends SAMLProcessingFilter {

    /** The Constant logger. */
    protected static final Logger LOG = LoggerFactory.getLogger(SAMLProcessingFilter.class);

    /**
     * Instantiates a new SAML processing filter custom.
     *
     * @param defaultFilterProcessesUrl
     *            the default filter processes url
     */
    public SAMLProcessingFilterCustom(String defaultFilterProcessesUrl) {
        super(defaultFilterProcessesUrl);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     *
     * org.springframework.security.saml.SAMLProcessingFilter#requiresAuthentication
     * (javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected boolean requiresAuthentication(HttpServletRequest request, HttpServletResponse response) {
        if (!StringUtils.hasText(request.getParameter("SAMLResponse"))) {
            LOG.debug("No parameter found with for SAMLResponse");
            return false;
        }
        LOG.debug("Found SAMLResponse, now matching URLs, 1:" + request.getRequestURI() + "--2:"
                + getFilterProcessesUrl());
        return request.getRequestURI().equalsIgnoreCase(getFilterProcessesUrl());
    }
}
