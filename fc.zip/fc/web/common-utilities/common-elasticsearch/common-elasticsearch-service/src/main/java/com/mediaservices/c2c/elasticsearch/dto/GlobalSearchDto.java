package com.mediaservices.c2c.elasticsearch.dto;

/**
 * The Class GlobalSearchDto.
 */
public class GlobalSearchDto {

    /** The display name. */
    private String displayName;

    /** The source. */
    private String source;

    /** The destination url. */
    private String destinationUrl;

    /**
     * Gets the display name.
     *
     * @return the display name
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the display name.
     *
     * @param displayName
     *            the new display name
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Gets the source.
     *
     * @return the source
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the source.
     *
     * @param source
     *            the new source
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * Gets the destination url.
     *
     * @return the destination url
     */
    public String getDestinationUrl() {
        return destinationUrl;
    }

    /**
     * Sets the destination url.
     *
     * @param destinationUrl
     *            the new destination url
     */
    public void setDestinationUrl(String destinationUrl) {
        this.destinationUrl = destinationUrl;
    }
}
