package com.mediaservices.c2c.elasticsearch.service;

import com.mediaservices.c2c.elasticsearch.dto.GlobalSearchResponseDto;
import com.mediaservices.c2c.elasticsearch.dto.TypeAheadNameSearchDto;

@FunctionalInterface
public interface GlobalSearchService {

    /**
     * Gets the search result.
     *
     * @param typeAheadNameSearchDto
     *            the type ahead name search dto
     * @param userId
     *            the user id
     * @return the search result
     */
    public GlobalSearchResponseDto getSearchResult(TypeAheadNameSearchDto typeAheadNameSearchDto, String userId);

}