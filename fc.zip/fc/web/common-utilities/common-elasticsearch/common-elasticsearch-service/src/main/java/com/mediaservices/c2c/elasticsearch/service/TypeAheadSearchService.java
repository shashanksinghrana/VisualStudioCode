package com.mediaservices.c2c.elasticsearch.service;

import org.elasticsearch.action.search.SearchResponse;

import com.mediaservices.c2c.elasticsearch.dto.TypeAheadNameSearchDto;

/**
 * The Interface TypeAheadNameService.
 */
public interface TypeAheadSearchService {

	/**
	 * Gets the type ahead names.
	 *
	 * @param searchDto
	 *            the search dto
	 * @return the type ahead names
	 */
	SearchResponse getTypeAheadNames(TypeAheadNameSearchDto searchDto);

}