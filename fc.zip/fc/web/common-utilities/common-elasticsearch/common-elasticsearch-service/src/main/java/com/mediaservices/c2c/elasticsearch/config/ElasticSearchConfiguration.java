package com.mediaservices.c2c.elasticsearch.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * The Class ElasticSearchConfiguration.
 */
@Configuration
@ComponentScan(basePackages = { "com.mediaservices.c2c.elasticsearch" })
public class ElasticSearchConfiguration {
}
