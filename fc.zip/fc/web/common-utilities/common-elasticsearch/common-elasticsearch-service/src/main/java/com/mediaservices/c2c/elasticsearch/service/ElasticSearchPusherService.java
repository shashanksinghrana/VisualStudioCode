package com.mediaservices.c2c.elasticsearch.service;

/**
 * The Interface ElasticSearchPusherService.
 */
public interface ElasticSearchPusherService {

    /**
     * Update ElasticSearch by party id.
     *
     * @param partyId
     *            the party id
     */
    public void updateElasticSearchByPartyId(Long partyId);

    /**
     * Update gsearch elastic search by entity id.
     *
     * @param entityId
     *            the entity id
     */
    public void updateGsearchElasticSearchByEntityId(Long entityId);
}