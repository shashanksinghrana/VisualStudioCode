package com.mediaservices.c2c.elasticsearch.dto;

import java.util.List;

/**
 * The Class GlobalSearchResponseDto.
 */
public class GlobalSearchResponseDto {

    /** The content. */
    private List<GlobalSearchDto> content;

    /** The total record count. */
    private Long totalRecordCount;

    /** The no record sent. */
    private Long noRecordSent;

    /**
     * Gets the content.
     *
     * @return the content
     */
    public List<GlobalSearchDto> getContent() {
        return content;
    }

    /**
     * Sets the content.
     *
     * @param content
     *            the new content
     */
    public void setContent(List<GlobalSearchDto> content) {
        this.content = content;
    }

    /**
     * Gets the total record count.
     *
     * @return the total record count
     */
    public Long getTotalRecordCount() {
        return totalRecordCount;
    }

    /**
     * Sets the total record count.
     *
     * @param totalRecordCount
     *            the new total record count
     */
    public void setTotalRecordCount(Long totalRecordCount) {
        this.totalRecordCount = totalRecordCount;
    }

    /**
     * Gets the no record sent.
     *
     * @return the no record sent
     */
    public Long getNoRecordSent() {
        return noRecordSent;
    }

    /**
     * Sets the no record sent.
     *
     * @param noRecordSent
     *            the new no record sent
     */
    public void setNoRecordSent(Long noRecordSent) {
        this.noRecordSent = noRecordSent;
    }
}
