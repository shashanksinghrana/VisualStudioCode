package com.mediaservices.c2c.elasticsearch.dto;

import com.mediaservices.c2c.elasticsearch.enums.TypeaheadFilterType;

/**
 * The Class TypeAheadNameSearchDto.
 */
public class TypeAheadNameSearchDto {

	/** The text to be searched. */
	private String textToBeSearched;
	
	/** The data set id. */
	private Long dataSetId;

	/** The filter type. */
	private TypeaheadFilterType filterType;

	/** The no of records to be returned. */
	private int noOfRecordsToBeReturned;
	
	/** The context. */
	private String context;

	/**
	 * Gets the text to be searched.
	 *
	 * @return the text to be searched
	 */
	public String getTextToBeSearched() {
		return textToBeSearched;
	}

	/**
	 * Sets the text to be searched.
	 *
	 * @param textToBeSearched
	 *            the new text to be searched
	 */
	public void setTextToBeSearched(String textToBeSearched) {
		this.textToBeSearched = textToBeSearched;
	}

	/**
	 * Gets the filter type.
	 *
	 * @return the filter type
	 */
	public TypeaheadFilterType getFilterType() {
		return filterType;
	}

	/**
	 * Sets the filter type.
	 *
	 * @param filterType
	 *            the new filter type
	 */
	public void setFilterType(TypeaheadFilterType filterType) {
		this.filterType = filterType;
	}

	/**
	 * Gets the no of records to be returned.
	 *
	 * @return the no of records to be returned
	 */
	public int getNoOfRecordsToBeReturned() {
		return noOfRecordsToBeReturned;
	}

	/**
	 * Sets the no of records to be returned.
	 *
	 * @param noOfRecordsToBeReturned
	 *            the new no of records to be returned
	 */
	public void setNoOfRecordsToBeReturned(int noOfRecordsToBeReturned) {
		this.noOfRecordsToBeReturned = noOfRecordsToBeReturned;
	}

	/**
	 * Gets the data set id.
	 *
	 * @return the dataSetId
	 */
	public Long getDataSetId() {
		return dataSetId;
	}

	/**
	 * Sets the data set id.
	 *
	 * @param dataSetId the dataSetId to set
	 */
	public void setDataSetId(Long dataSetId) {
		this.dataSetId = dataSetId;
	}

	/**
	 * Gets the context.
	 *
	 * @return the context
	 */
	public String getContext() {
		return context;
	}

	/**
	 * Sets the context.
	 *
	 * @param context the context to set
	 */
	public void setContext(String context) {
		this.context = context;
	}
	
}
