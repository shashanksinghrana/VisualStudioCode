package com.mediaservices.c2c.elasticsearch.enums;

/**
 * The Enum SearchDataMethodology.
 */
public enum TypeaheadFilterType {

	/** The no alias. */
	NO_ALIAS("NO_ALIAS", 1),
	/** The contact only. */
	CONTACT_ONLY("CONTACT_ONLY", 2),
	/** The company only. */
	COMPANY_ONLY("COMPANY_ONLY", 3),
	/** The talent only. */
	TALENT_ONLY("TALENT_ONLY", 4),
	/** The talent contact. */
	TALENT_CONTACT("TALENT_CONTACT", 5),
	/** The contact company. */
	CONTACT_COMPANY("CONTACT_COMPANY", 6),
	/** The talent company. */
	TALENT_COMPANY("TALENT_COMPANY", 7);

	/** The type. */
	private int type;

	/** The name. */
	private String name;

	/**
	 * Instantiates a new search data methodology.
	 *
	 * @param name
	 *            the name
	 * @param type
	 *            the type
	 */
	private TypeaheadFilterType(String name, int type) {
		this.name = name;
		this.type = type;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

}
