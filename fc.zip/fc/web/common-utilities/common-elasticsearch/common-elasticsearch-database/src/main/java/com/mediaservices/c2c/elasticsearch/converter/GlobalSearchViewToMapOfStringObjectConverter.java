package com.mediaservices.c2c.elasticsearch.converter;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.convert.converter.Converter;

import com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants;
import com.mediaservices.c2c.elasticsearch.entity.GlobalSearchView;

/**
 * The Class GlobalSearchViewToMapOfStringObjectConverter.
 */
public class GlobalSearchViewToMapOfStringObjectConverter
implements Converter<GlobalSearchView, Map<String, Object>> {

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.core.convert.converter.Converter#convert(java.lang.
     * Object)
     */
    @Override
    public Map<String, Object> convert(GlobalSearchView typeahead) {

        Map<String, Object> doc = new HashMap<>();
        addIfNotNull(doc, ElasticSearchConstants.ENTITY_ID, typeahead.getGlobalSearchViewId().getEntityId());
        addIfNotNull(doc, ElasticSearchConstants.DISPLAY_NAME, typeahead.getGlobalSearchViewId().getDisplayName());
        addIfNotNull(doc, ElasticSearchConstants.ENTITY_TYPE, typeahead.getGlobalSearchViewId().getEntityType());
        addIfNotNull(doc, ElasticSearchConstants.ENTITY_NAME, typeahead.getGlobalSearchViewId().getSearchName());
        addIfNotNull(doc, ElasticSearchConstants.ENTITY_SOURCE, typeahead.getGlobalSearchViewId().getSource());
        addIfNotNull(doc, ElasticSearchConstants.LAST_MODIFIED_TS, typeahead.getUpdateTs());
        return doc;
    }

    /**
     * Adds the if not null.
     *
     * @param doc the doc
     * @param key the key
     * @param value the value
     */
    private void addIfNotNull(Map<String, Object> doc, String key, Object value) {
        if (value != null) {
            doc.put(key, value);
        }
    }

}
