package com.mediaservices.c2c.elasticsearch.service;

import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.DISPLAY_NAME_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.FOLDED_DISPLAY_NAME_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.FOLDED_PRIMARY_NAME_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.FOLDED_TEAM_MEMBERS_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.LOGCIAL_AND_SPACE_PADDED;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.PRIMARY_NAME_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.QUERY_TERM_PATTERN;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.SPACE;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.TEAM_MEMBERS_DOC_KEY;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants;
import com.mediaservices.c2c.elasticsearch.dto.TypeAheadNameSearchDto;
import com.mediaservices.c2c.elasticsearch.enums.TypeaheadFilterType;

/**
 * The Class TypeAheadSearchServiceImpl.
 */
@Service("typeAheadSearchService")
public class TypeAheadSearchServiceImpl implements TypeAheadSearchService {

	/** The Constant LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(TypeAheadSearchServiceImpl.class);

	/** The elastic client. */
	@Autowired
	private RestHighLevelClient elasticClient;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.mediaservices.c2c.elasticsearch.service.TypeAheadSearchService#
	 * getTypeAheadNames(com.mediaservices.c2c.elasticsearch.dto.
	 * TypeAheadNameSearchDto)
	 */
	@Override
	public SearchResponse getTypeAheadNames(TypeAheadNameSearchDto searchDto) {

		SearchRequest query = new SearchRequest();

		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder.query(QueryBuilders.queryStringQuery(this.toQueryString(searchDto.getTextToBeSearched()))
				.field(DISPLAY_NAME_DOC_KEY).field(FOLDED_DISPLAY_NAME_DOC_KEY).field(PRIMARY_NAME_DOC_KEY)
				.field(FOLDED_PRIMARY_NAME_DOC_KEY).field(TEAM_MEMBERS_DOC_KEY).field(FOLDED_TEAM_MEMBERS_DOC_KEY))
				.from(0).size(searchDto.getNoOfRecordsToBeReturned());
		
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		
		this.addFilter(boolQueryBuilder, searchDto.getFilterType());
		
		if(null != searchDto.getDataSetId()){
			this.addDatasetFilter(boolQueryBuilder, searchDto);
		}
		
		searchSourceBuilder.postFilter(boolQueryBuilder);
		this.addSort(searchSourceBuilder, searchDto.getFilterType());
		
		query.source(searchSourceBuilder);

		if (LOG.isDebugEnabled()) {
			LOG.debug("ElasticSearch Query is {}", query);
		}
		try {
			return elasticClient.search(query);
		} catch (IOException e) {
			throw new RuntimeException("Error making Elasticsearch Query", e);
		}

	}

	/**
	 * Adds the filter.
	 *
	 * @param builder
	 *            the builder
	 * @param type
	 *            the type
	 * @return the search source builder
	 */
	private BoolQueryBuilder addFilter(BoolQueryBuilder boolQueryBuilder, TypeaheadFilterType type) {

		if (TypeaheadFilterType.NO_ALIAS.equals(type)) {
			boolQueryBuilder.mustNot(QueryBuilders.existsQuery(PRIMARY_NAME_DOC_KEY));
		} else if (TypeaheadFilterType.CONTACT_ONLY.equals(type)) {
			boolQueryBuilder.must(QueryBuilders.termQuery(ElasticSearchConstants.IS_CONTACT_DOC_KEY, true));
		} else if (TypeaheadFilterType.COMPANY_ONLY.equals(type)) {
			boolQueryBuilder.must(QueryBuilders.termQuery(ElasticSearchConstants.IS_COMPANY_DOC_KEY, true));
		} else if (TypeaheadFilterType.TALENT_ONLY.equals(type)) {
			boolQueryBuilder.must(QueryBuilders.termQuery(ElasticSearchConstants.IS_TALENT_DOC_KEY, true));
		} else if (TypeaheadFilterType.TALENT_CONTACT.equals(type)) {
			boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.IS_TALENT_DOC_KEY, true));
			boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.IS_CONTACT_DOC_KEY, true));
		} else if (TypeaheadFilterType.TALENT_COMPANY.equals(type)) {
			boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.IS_TALENT_DOC_KEY, true));
			boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.IS_COMPANY_DOC_KEY, true));
		} else if (TypeaheadFilterType.CONTACT_COMPANY.equals(type)) {
			boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.IS_CONTACT_DOC_KEY, true))
			.should(QueryBuilders.termQuery(ElasticSearchConstants.IS_COMPANY_DOC_KEY, true));
		}
		return boolQueryBuilder;
	}
	
	/**
	 * Adds data set filter.
	 *
	 * @param boolQueryBuilder the bool query builder
	 * @param dto the dto
	 * @return the search source builder
	 */
	private BoolQueryBuilder addDatasetFilter(BoolQueryBuilder boolQueryBuilder, TypeAheadNameSearchDto dto) {

		boolQueryBuilder.must(QueryBuilders.termQuery(ElasticSearchConstants.DATASET_ID_DOC_KEY, dto.getDataSetId()));
		return boolQueryBuilder;
	}
	
	/**
	 * Adds the sort.
	 *
	 * @param searchSourceBuilder the search source builder
	 * @param type the type
	 * @return the search source builder
	 */
	private SearchSourceBuilder addSort(SearchSourceBuilder searchSourceBuilder, TypeaheadFilterType type) {

		if (TypeaheadFilterType.CONTACT_COMPANY.equals(type)) {
			searchSourceBuilder.sort(ElasticSearchConstants.IS_CONTACT_DOC_KEY, SortOrder.DESC);
		}
		return searchSourceBuilder;
	}

	/**
	 * To query string.
	 *
	 * @param term
	 *            the term
	 * @return the string
	 */
	private String toQueryString(String term) {

		List<String> terms = escapeTerms(cleanTerms(term.split(SPACE)));
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < terms.size() - 1; i++) {
			builder.append(String.format(QUERY_TERM_PATTERN, terms.get(i))).append(LOGCIAL_AND_SPACE_PADDED);
		}
		builder.append(String.format(QUERY_TERM_PATTERN, terms.get(terms.size() - 1)));

		return builder.toString();

	}

	/**
	 * Clean terms.
	 *
	 * @param terms
	 *            the terms
	 * @return the list
	 */
	private List<String> cleanTerms(String[] terms) {
		List<String> output = new ArrayList<>();
		for (String term : terms) {
			if (term.contains(",")) {
				output.addAll(cleanTerms(term.split(",")));
			} else if (StringUtils.isNotBlank(term)) {
				output.add(term.trim());
			}
		}
		return output;
	}

	/**
	 * Escape terms.
	 *
	 * @param terms
	 *            the terms
	 * @return the list
	 */
	private List<String> escapeTerms(List<String> terms) {
		List<String> output = new ArrayList<>();
		for (String term : terms) {
			// append \\ in front of reserved characters.
			output.add(term.replaceAll(ElasticSearchConstants.ELASTIC_RESERVED_CHARACTERS_REGEX, "\\\\$1"));
		}
		return output;
	}

}
