package com.mediaservices.c2c.elasticsearch.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * The Class GlobalSearchView.
 */
@Entity
@Table(name = "VIEW_GLOBAL_SEARCH")
public class GlobalSearchView implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The global search view id. */
    @EmbeddedId
    private GlobalSearchViewId globalSearchViewId;

    /** The update ts. */
    @Column(name = "LAST_MODIFIED_TS")
    private LocalDateTime updateTs;

    /**
     * Gets the global search view id.
     *
     * @return the global search view id
     */
    public GlobalSearchViewId getGlobalSearchViewId() {
        return globalSearchViewId;
    }

    /**
     * Sets the global search view id.
     *
     * @param globalSearchViewId
     *            the new global search view id
     */
    public void setGlobalSearchViewId(GlobalSearchViewId globalSearchViewId) {
        this.globalSearchViewId = globalSearchViewId;
    }

    /**
     * Gets the update ts.
     *
     * @return the update ts
     */
    public LocalDateTime getUpdateTs() {
        return updateTs;
    }

    /**
     * Sets the update ts.
     *
     * @param updateTs
     *            the new update ts
     */
    public void setUpdateTs(LocalDateTime updateTs) {
        this.updateTs = updateTs;
    }

}
