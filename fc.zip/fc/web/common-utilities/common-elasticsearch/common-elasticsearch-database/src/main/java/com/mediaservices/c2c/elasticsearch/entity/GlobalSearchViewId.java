package com.mediaservices.c2c.elasticsearch.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The Class GlobalSearchViewId.
 */
@Embeddable
public class GlobalSearchViewId implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The entity id. */
    @Column(name = "ENTITY_ID")
    private Long entityId;

    /** The entity type. */
    @Column(name = "ENTITY_TYPE")
    private String entityType;

    /** The search name. */
    @Column(name = "SEARCH_NAME")
    private String searchName;

    /** The display name. */
    @Column(name = "DISPLAY_NAME")
    private String displayName;

    /** The sourcs. */
    @Column(name = "ENTITY_SOURCE")
    private String source;

    /**
     * Gets the entity id.
     *
     * @return the entity id
     */
    public Long getEntityId() {
        return entityId;
    }

    /**
     * Sets the entity id.
     *
     * @param entityId
     *            the new entity id
     */
    public void setEntityId(Long entityId) {
        this.entityId = entityId;
    }

    /**
     * Gets the entity type.
     *
     * @return the entity type
     */
    public String getEntityType() {
        return entityType;
    }

    /**
     * Sets the entity type.
     *
     * @param entityType
     *            the new entity type
     */
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    /**
     * Gets the search name.
     *
     * @return the search name
     */
    public String getSearchName() {
        return searchName;
    }

    /**
     * Sets the search name.
     *
     * @param searchName
     *            the new search name
     */
    public void setSearchName(String searchName) {
        this.searchName = searchName;
    }

    /**
     * Gets the display name.
     *
     * @return the display name
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the display name.
     *
     * @param displayName
     *            the new display name
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Gets the sourcs.
     *
     * @return the sourcs
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the sourcs.
     *
     * @param sourcs
     *            the new sourcs
     */
    public void setSource(String source) {
        this.source = source;
    }

}
