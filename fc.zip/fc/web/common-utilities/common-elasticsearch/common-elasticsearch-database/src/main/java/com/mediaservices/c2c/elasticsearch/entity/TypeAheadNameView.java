package com.mediaservices.c2c.elasticsearch.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

/**
 * The Class TypeAheadNameView.
 */
@Entity
@Table(name = "VIEW_NAME_TYPEAHEAD")
public class TypeAheadNameView implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The type ahead names id. */
    @EmbeddedId
    private TypeAheadNamesId typeAheadNamesId;

    /** The first name. */
    @Column(name = "FIRST_NAME")
    private String firstName;

    /** The ssn end chars. */
    @Column(name = "END_CHARS_OF_SSN")
    private String ssnEndChars;

    /** The occupation. */
    @Column(name = "OCCUPATION")
    private String occupation;



    /** The type ahead display name. */
    @Column(name = "TYPE_AHEAD_DISPLAY_NAME")
    private String typeAheadDisplayName;

    /** The primary name. */
    @Column(name = "PRIMARY_NAME")
    private String primaryName;

    /** The primary display name. */
    @Column(name = "PRIMARY_DISPLAY_NAME")
    private String primaryDisplayName;

    /** The team members. */
    @Column(name = "TEAM_MEMBERS")
    private String teamMembers;

    /** The aka id. */
    @Column(name = "AKA_ID")
    private Long akaId;
    
    /** The data set id. */
    @Column(name = "DATASET_ID")
    private Long dataSetId;
    
    /** The is talent. */
    @Column(name = "IS_TALENT")
    @Type(type = "org.hibernate.type.YesNoType")
    private Boolean isTalent;

    /** The is contact. */
    @Column(name = "IS_CONTACT")
    @Type(type = "org.hibernate.type.YesNoType")
    private Boolean isContact;

    /** The is company. */
    @Column(name = "IS_COMPANY")
    @Type(type = "org.hibernate.type.YesNoType")
    private Boolean isCompany;

    /**
     * Gets the type ahead names id.
     *
     * @return the type ahead names id
     */
    public TypeAheadNamesId getTypeAheadNamesId() {
        return typeAheadNamesId;
    }

    /**
     * Sets the type ahead names id.
     *
     * @param typeAheadNamesId
     *            the new type ahead names id
     */
    public void setTypeAheadNamesId(TypeAheadNamesId typeAheadNamesId) {
        this.typeAheadNamesId = typeAheadNamesId;
    }

    /**
     * Gets the first name.
     *
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the first name.
     *
     * @param firstName
     *            the new first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets the ssn end chars.
     *
     * @return the ssn end chars
     */
    public String getSsnEndChars() {
        return ssnEndChars;
    }

    /**
     * Sets the ssn end chars.
     *
     * @param ssnEndChars
     *            the new ssn end chars
     */
    public void setSsnEndChars(String ssnEndChars) {
        this.ssnEndChars = ssnEndChars;
    }

    /**
     * Gets the occupation.
     *
     * @return the occupation
     */
    public String getOccupation() {
        return occupation;
    }

    /**
     * Sets the occupation.
     *
     * @param occupation
     *            the new occupation
     */
    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    /**
     * Gets the type ahead display name.
     *
     * @return the type ahead display name
     */
    public String getTypeAheadDisplayName() {
        return typeAheadDisplayName;
    }

    /**
     * Sets the type ahead display name.
     *
     * @param typeAheadDisplayName
     *            the new type ahead display name
     */
    public void setTypeAheadDisplayName(String typeAheadDisplayName) {
        this.typeAheadDisplayName = typeAheadDisplayName;
    }

    /**
     * Gets the primary name.
     *
     * @return the primaryName
     */
    public String getPrimaryName() {
        return primaryName;
    }

    /**
     * Sets the primary name.
     *
     * @param primaryName
     *            the primaryName to set
     */
    public void setPrimaryName(String primaryName) {
        this.primaryName = primaryName;
    }

    /**
     * Gets the primary display name.
     *
     * @return the primaryDisplayName
     */
    public String getPrimaryDisplayName() {
        return primaryDisplayName;
    }

    /**
     * Sets the primary display name.
     *
     * @param primaryDisplayName
     *            the primaryDisplayName to set
     */
    public void setPrimaryDisplayName(String primaryDisplayName) {
        this.primaryDisplayName = primaryDisplayName;
    }

    /**
     * Gets the team members.
     *
     * @return the teamMembers
     */
    public String getTeamMembers() {
        return teamMembers;
    }

    /**
     * Sets the team members.
     *
     * @param teamMembers
     *            the teamMembers to set
     */
    public void setTeamMembers(String teamMembers) {
        this.teamMembers = teamMembers;
    }

    /**
     * Gets the aka id.
     *
     * @return the akaId
     */
    public Long getAkaId() {
        return akaId;
    }

    /**
     * Sets the aka id.
     *
     * @param akaId
     *            the akaId to set
     */
    public void setAkaId(Long akaId) {
        this.akaId = akaId;
    }

    /**
     * Gets the checks if is talent.
     *
     * @return the checks if is talent
     */
    public Boolean getIsTalent() {
        return isTalent;
    }

    /**
     * Sets the checks if is talent.
     *
     * @param isTalent
     *            the new checks if is talent
     */
    public void setIsTalent(Boolean isTalent) {
        this.isTalent = isTalent;
    }

    /**
     * Gets the checks if is contact.
     *
     * @return the checks if is contact
     */
    public Boolean getIsContact() {
        return isContact;
    }

    /**
     * Sets the checks if is contact.
     *
     * @param isContact
     *            the new checks if is contact
     */
    public void setIsContact(Boolean isContact) {
        this.isContact = isContact;
    }

    /**
     * Gets the checks if is company.
     *
     * @return the checks if is company
     */
    public Boolean getIsCompany() {
        return isCompany;
    }

    /**
     * Sets the checks if is company.
     *
     * @param isCompany
     *            the new checks if is company
     */
    public void setIsCompany(Boolean isCompany) {
        this.isCompany = isCompany;
    }

	/**
	 * Gets the data set id.
	 *
	 * @return the dataSetId
	 */
	public Long getDataSetId() {
		return dataSetId;
	}

	/**
	 * Sets the data set id.
	 *
	 * @param dataSetId the dataSetId to set
	 */
	public void setDataSetId(Long dataSetId) {
		this.dataSetId = dataSetId;
	}
    
}
