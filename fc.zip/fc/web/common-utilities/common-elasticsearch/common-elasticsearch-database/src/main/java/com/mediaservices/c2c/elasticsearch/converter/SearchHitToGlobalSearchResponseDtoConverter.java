package com.mediaservices.c2c.elasticsearch.converter;

import java.util.Map;
import java.util.Optional;

import org.elasticsearch.search.SearchHit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants;
import com.mediaservices.c2c.elasticsearch.dao.GlobalSearchDAO;
import com.mediaservices.c2c.elasticsearch.dto.GlobalSearchDto;

/**
 * The Class SearchHitToGlobalSearchResponseDtoConverter.
 */
@Component
public class SearchHitToGlobalSearchResponseDtoConverter implements Converter<SearchHit, GlobalSearchDto> {

    @Value("${dp.application.context.url:}")
    private String dpUrl;

    /** The dp deal url. */
    @Value("${dp.deal.url:web/createDealMemo/_dealId/_studio_id}")
    private String dpDealUrl;

    /** The dp project url. */
    @Value("${dp.project.url:web/projectDetail/_projectId/participants}")
    private String dpProjectUrl;

    @Value("${fc.application.context.url:}")
    private String fcUrl;

    /** The fc deal url. */
    @Value("${fc.deal.url:#/createDeal/_dealId/summary}")
    private String fcDealUrl;

    /** The fc project url. */
    @Value("${fc.project.url:#/projectDetails/_projectId/performers}")
    private String fcProjectUrl;

    @Value("${st.application.context.url:/saml/SSO}")
    private String stUrl;

    /** The st submission url. */
    @Value("${st.submission.url:/saml/SSO}")
    private String stSubmissionUrl;

    /** The st project url. */
    @Value("${st.project.url:/saml/SSO}")
    private String stProjectUrl;

    /** The hl project url. */
    @Value("${hl.project.url:/saml/SSO}")
    private String hlProjectUrl;

    @Value("${tal.application.context.url:}")
    private String talentUrl;

    /** The talent details url. */
    @Value("${tal.details.url:#/talentDetail/_partyId/submission}")
    private String talentDetailsUrl;

    @Value("${rc.application.context.url:}")
    private String rollcallUrl;

    /** The contact details url. */
    @Value("${rc.people.details.url:#/peopleDetail/_partyId}")
    private String contactDetailsUrl;

    /** The company details url. */
    @Value("${rc.company.details.url:#/companiesDetail/_partyId}")
    private String companyDetailsUrl;

    /** The global searchdao. */
    @Autowired
    private GlobalSearchDAO globalSearchdao;

    /*
     * (non-Javadoc)
     *
     * @see
     * org.springframework.core.convert.converter.Converter#convert(java.lang.
     * Object)
     */
    @Override
    public GlobalSearchDto convert(SearchHit hit) {
        final GlobalSearchDto dto = new GlobalSearchDto();
        final Map<String, Object> source = hit.getSourceAsMap();
        dto.setSource(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_SOURCE));
        dto.setDisplayName(getStringFieldFromDocument(source, ElasticSearchConstants.DISPLAY_NAME));
        if (dto.getDisplayName() != null && !dto.getDisplayName()
                .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_NAME))) {
            dto.setDisplayName(
                    dto.getDisplayName() + " | "
                            + getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_NAME));
        }
        final Long id = getLongFieldFromDocument(source, ElasticSearchConstants.ENTITY_ID);
        switch (dto.getSource()) {
        case "DP":
            if (ElasticSearchConstants.PROJECT
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {
                final String url = dpProjectUrl.replaceAll("_projectId", id != null ? id.toString() : null);
                dto.setDestinationUrl(dpUrl + url);
            } else if (ElasticSearchConstants.DEAL
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {
                final Long studioId = globalSearchdao
                        .getStudioOfDeal(getLongFieldFromDocument(source, ElasticSearchConstants.ENTITY_ID));
                final String url = dpDealUrl.replaceAll("_dealId", id != null ? id.toString() : null).replaceAll(
                        "_studio_id",
                        studioId != null ? studioId.toString() : null);
                dto.setDestinationUrl(dpUrl + url);
            }
            break;
        case "FC":
            if (ElasticSearchConstants.PROJECT
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {
                final String url = fcProjectUrl.replaceAll("_projectId", id != null ? id.toString() : null);
                dto.setDestinationUrl(fcUrl + url);
            } else if (ElasticSearchConstants.DEAL
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {
                final String url = fcDealUrl.replaceAll("_dealId", id != null ? id.toString() : null);
                dto.setDestinationUrl(fcUrl + url);
            }
            break;
        case "ST":
            if (ElasticSearchConstants.PROJECT
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {

            } else if (ElasticSearchConstants.DEAL
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {

            }
            break;
        case "HL":
            if (ElasticSearchConstants.PROJECT
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {

            }
            break;
        case "TALENT2":
            dto.setDestinationUrl(
                    talentUrl + talentDetailsUrl.replaceAll("_partyId", id != null ? id.toString() : null));
            break;
        case "ROLLCALL2":
            if (ElasticSearchConstants.CONTACT
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {
                dto.setDestinationUrl(
                        rollcallUrl + contactDetailsUrl.replaceAll("_partyId", id != null ? id.toString() : null));
            } else if (ElasticSearchConstants.COMPANY
                    .equals(getStringFieldFromDocument(source, ElasticSearchConstants.ENTITY_TYPE))) {
                dto.setDestinationUrl(
                        rollcallUrl + companyDetailsUrl.replaceAll("_partyId", id != null ? id.toString() : null));
            }
            break;
        default:
            dto.setDestinationUrl(null);

        }

        return dto;

    }

    /**
     * Gets a string field from a document.
     *
     * @param document
     *            the document to get a value from
     * @param field
     *            the field to get from the document
     * @return the string field from document
     */
    private String getStringFieldFromDocument(Map<String, Object> document, String field) {
        return Optional.ofNullable(document.get(field)).map(String.class::cast).orElse(null);
    }

    /**
     * Gets a long field from a document.
     *
     * @param document
     *            the document to get the Long value from
     * @param field
     *            the field the field in the document with the Long value
     * @return the long field from document
     */
    private Long getLongFieldFromDocument(Map<String, Object> document, String field) {
        final Object value = document.get(field);
        if (value instanceof String) {
            return Long.parseLong((String) value);
        }
        if (value instanceof Integer) {
            return ((Integer) value).longValue();
        }

        return null;
    }

}
