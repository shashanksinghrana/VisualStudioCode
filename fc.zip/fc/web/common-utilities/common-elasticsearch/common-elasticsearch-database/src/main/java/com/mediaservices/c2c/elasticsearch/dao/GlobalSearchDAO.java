package com.mediaservices.c2c.elasticsearch.dao;

public interface GlobalSearchDAO {

    public boolean checkDealpointAccess(String userId);

    public boolean checkScriptTrackerAccess(String userId);

    public boolean checkHitListAccess(String userId);

    public boolean checkFeatureCastingAccess(String userId);

    public boolean checkRollCallAccess(String userId);

    public boolean checkTalentAccess(String userId);

    public Long getStudioOfDeal(Long dealId);
}
