package com.mediaservices.c2c.elasticsearch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mediaservices.c2c.elasticsearch.entity.GlobalSearchView;
import com.mediaservices.c2c.elasticsearch.entity.GlobalSearchViewId;

/**
 * The Interface TypeAheadNameRepository.
 */
@Repository
public interface GlobalSearchViewRepository extends JpaRepository<GlobalSearchView, GlobalSearchViewId> {

    public List<GlobalSearchView> findByGlobalSearchViewId_EntityId(Long entityId);

}
