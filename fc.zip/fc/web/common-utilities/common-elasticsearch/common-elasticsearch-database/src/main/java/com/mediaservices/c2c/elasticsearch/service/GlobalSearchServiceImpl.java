package com.mediaservices.c2c.elasticsearch.service;

import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.LOGCIAL_AND_SPACE_PADDED;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.QUERY_TERM_PATTERN;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.SPACE;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Service;

import com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants;
import com.mediaservices.c2c.elasticsearch.dao.GlobalSearchDAO;
import com.mediaservices.c2c.elasticsearch.dto.GlobalSearchDto;
import com.mediaservices.c2c.elasticsearch.dto.GlobalSearchResponseDto;
import com.mediaservices.c2c.elasticsearch.dto.TypeAheadNameSearchDto;

/**
 * The Class GlobalSearchServiceImpl.
 */
@Service("globalSearchService")
public class GlobalSearchServiceImpl implements GlobalSearchService {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(GlobalSearchServiceImpl.class);

    /** The elastic client. */
    @Autowired
    private RestHighLevelClient elasticClient;

    /** The global search DAO. */
    @Autowired
    private GlobalSearchDAO globalSearchDAO;

    /** The converter. */
    @Autowired
    @Qualifier("elasticSearchConverter")
    private ConversionService converter;

    /** The ec index gsearch. */
    @Value("${elasticsearch.gsearch.index:gsearch}")
    private String ecIndexGsearch;

    /*
     * (non-Javadoc)
     *
     * @see com.mediaservices.c2c.elasticsearch.service.GlobalSearchService#
     * getSearchResult(com.mediaservices.c2c.elasticsearch.dto.
     * TypeAheadNameSearchDto, java.lang.String)
     */
    @Override
    public GlobalSearchResponseDto getSearchResult(TypeAheadNameSearchDto searchDto, String userId) {

        SearchRequest query = new SearchRequest(ecIndexGsearch);

        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.queryStringQuery(this.toQueryString(searchDto.getTextToBeSearched()))
                .field(ElasticSearchConstants.ENTITY_NAME).field(ElasticSearchConstants.FOLDED_ENTITY_NAME_DOC_KEY))
        .from(0).size(searchDto.getNoOfRecordsToBeReturned());
        this.addFilter(searchSourceBuilder, userId);
        query.source(searchSourceBuilder);

        if (LOG.isDebugEnabled()) {
            LOG.debug("ElasticSearch Query is {}", query);
        }
        try {
            SearchResponse response = elasticClient.search(query);
            GlobalSearchResponseDto globalSearchResponseDto = new GlobalSearchResponseDto();
            globalSearchResponseDto.setContent(Stream.of(response.getHits().getHits())
                    .map(document -> converter.convert(document, GlobalSearchDto.class)).collect(Collectors.toList()));
            globalSearchResponseDto.setTotalRecordCount(response.getHits().totalHits);
            globalSearchResponseDto.setNoRecordSent(Long.valueOf(globalSearchResponseDto.getContent().size()));
            return globalSearchResponseDto;

        } catch (IOException e) {
            throw new RuntimeException("Error making Elasticsearch Query", e);
        }

    }

    /**
     * Adds the filter.
     *
     * @param builder
     *            the builder
     * @param userId
     *            the user id
     * @return the search source builder
     */
    private SearchSourceBuilder addFilter(SearchSourceBuilder builder, String userId) {
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if (globalSearchDAO.checkDealpointAccess(userId)) {
            boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.ENTITY_SOURCE, "DP"));
        }
        if (globalSearchDAO.checkScriptTrackerAccess(userId)) {
            boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.ENTITY_SOURCE, "ST"));
        }
        if (globalSearchDAO.checkHitListAccess(userId)) {
            boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.ENTITY_SOURCE, "HL"));
        }
        if (globalSearchDAO.checkFeatureCastingAccess(userId)) {
            boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.ENTITY_SOURCE, "FC"));
        }
        if (globalSearchDAO.checkRollCallAccess(userId)) {
            boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.ENTITY_SOURCE, "ROLLCALL2"));
        }
        if (globalSearchDAO.checkTalentAccess(userId)) {
            boolQueryBuilder.should(QueryBuilders.termQuery(ElasticSearchConstants.ENTITY_SOURCE, "TALENT2"));
        }
        builder.postFilter(boolQueryBuilder).sort(ElasticSearchConstants.LAST_MODIFIED_TS, SortOrder.DESC);
        return builder;
    }

    /**
     * To query string.
     *
     * @param term
     *            the term
     * @return the string
     */
    private String toQueryString(String term) {

        List<String> terms = escapeTerms(cleanTerms(term.split(SPACE)));
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < terms.size() - 1; i++) {
            builder.append(String.format(QUERY_TERM_PATTERN, terms.get(i))).append(LOGCIAL_AND_SPACE_PADDED);
        }
        builder.append(String.format(QUERY_TERM_PATTERN, terms.get(terms.size() - 1)));

        return builder.toString();

    }

    /**
     * Clean terms.
     *
     * @param terms
     *            the terms
     * @return the list
     */
    private List<String> cleanTerms(String[] terms) {
        List<String> output = new ArrayList<>();
        for (String term : terms) {
            if (term.contains(",")) {
                output.addAll(cleanTerms(term.split(",")));
            } else if (StringUtils.isNotBlank(term)) {
                output.add(term.trim());
            }
        }
        return output;
    }

    /**
     * Escape terms.
     *
     * @param terms
     *            the terms
     * @return the list
     */
    private List<String> escapeTerms(List<String> terms) {
        List<String> output = new ArrayList<>();
        for (String term : terms) {
            // append \\ in front of reserved characters.
            output.add(term.replaceAll(ElasticSearchConstants.ELASTIC_RESERVED_CHARACTERS_REGEX, "\\\\$1"));
        }
        return output;
    }

}
