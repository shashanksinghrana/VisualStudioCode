package com.mediaservices.c2c.elasticsearch.service;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Service;

import com.mediaservices.c2c.elasticsearch.entity.GlobalSearchView;
import com.mediaservices.c2c.elasticsearch.entity.GlobalSearchViewId;
import com.mediaservices.c2c.elasticsearch.entity.TypeAheadNameView;
import com.mediaservices.c2c.elasticsearch.repository.TypeAheadRepository;

/**
 * The Class ElasticSearchPusherServiceImpl.
 */
@Service
public class ElasticSearchPusherServiceImpl implements ElasticSearchPusherService {

    /** The typeahead repo. */
    @Autowired
    private TypeAheadRepository typeaheadRepo;

    /** The elasticsearch client. */
    @Autowired
    private RestHighLevelClient elasticClient;

    /** The converter. */
    @Autowired
    @Qualifier("elasticSearchConverter")
    private ConversionService converter;

    /** The em. */
    @Autowired
    private EntityManager em;

    /** The ec index. */
    @Value("${elasticsearch.index:typeahead}")
    private String ecIndex;

    /** The ec type. */
    @Value("${elasticsearch.type:doc}")
    private String ecType;

    /** The ec index. */
    @Value("${elasticsearch.gsearch.index:gsearch}")
    private String ecIndexGsearch;

    /** The ec type. */
    @Value("${elasticsearch.gsearch.type:docgsearch}")
    private String ecTypeGsearch;

    /** The LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(ElasticSearchPusherServiceImpl.class);

    /** The Constant DELETE_BY_QUERY_URL_FORMAT. */
    private static final String DELETE_BY_QUERY_URL_FORMAT = "/%1$s/_delete_by_query?conflicts=proceed";

    /** The Constant DELETE_BY_QUERY_REQUEST_FORAMT. */
    private static final String DELETE_BY_QUERY_REQUEST_FORAMT = "{\"query\": {\"bool\": {\"must\": [ {\"term\": {\"PartyID\": \"%1$s\"}}]}}}";

    /** The Constant DELETE_BY_QUERY_REQUEST_FORAMT_GSEARCH. */
    private static final String DELETE_BY_QUERY_REQUEST_FORAMT_GSEARCH = "{\"query\": {\"bool\": {\"must\": [ {\"term\": {\"EntityId\": \"%1$s\"}}]}}}";

    /** The Constant FIND_GLOBAL_SEARCH_RECORD_TO_UPDATE. */
    private static final String FIND_GLOBAL_SEARCH_RECORD_TO_UPDATE = "Select * from DBO_TC.VIEW_GLOBAL_SEARCH where entity_id =:entityId";

    /**
     * Saves a typeAhead instance to ElasticSearch.
     *
     * @param typeahead
     *            the typeahead to save to elasticsearch
     * @return the index request
     */
    private IndexRequest createIndexRequest(TypeAheadNameView typeahead) {
        final IndexRequest request = new IndexRequest(ecIndex, ecType);
        request.source(converter.convert(typeahead, Map.class));
        return request;

    }

    /**
     * Update elastic search by party id.
     *
     * @param partyId
     *            the party id
     */
    @Override
    public void updateElasticSearchByPartyId(Long partyId) {
        final List<TypeAheadNameView> typeAheads = typeaheadRepo.findByTypeAheadNamesId_PartyId(partyId);
        saveToElasticSearch(typeAheads, partyId);
    }

    /**
     * Save to elasticsearch.
     *
     * @param typeAheads
     *            the type aheads
     * @param partyId
     *            the party id
     */
    private void saveToElasticSearch(List<TypeAheadNameView> typeAheads, Long partyId) {
        deleteExistingDocs(partyId);
        final BulkRequest bulk = new BulkRequest();
        typeAheads.stream().map(this::createIndexRequest).forEach(bulk::add);
        if (!typeAheads.isEmpty()) {
            try {
                elasticClient.bulk(bulk);
            } catch (final IOException e) {
                LOGGER.error("Problems createing indexes for party id " + partyId, e);
            }
        }
    }

    /**
     * Delete existing docs.
     *
     * @param partyId
     *            the party id
     */
    private void deleteExistingDocs(Long partyId) {
        try (NStringEntity entity = new NStringEntity(String.format(DELETE_BY_QUERY_REQUEST_FORAMT, partyId),
                ContentType.APPLICATION_JSON)) {
            elasticClient.getLowLevelClient().performRequest("POST", String.format(DELETE_BY_QUERY_URL_FORMAT, ecIndex),
                    Collections.emptyMap(), entity);
        } catch (final IOException ex) {
            LOGGER.error("Problem removing party with party id " + partyId + " from Index", ex);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.elasticsearch.service.ElasticSearchPusherService#
     * updateGsearchElasticSearchByEntityId(java.lang.Long)
     */
    @Override
    public void updateGsearchElasticSearchByEntityId(Long entityId) {
        final List<Object[]> searchResults = em.createNativeQuery(FIND_GLOBAL_SEARCH_RECORD_TO_UPDATE)
                .setParameter("entityId", entityId.toString()).getResultList();
        Object[] columns;
        final List<GlobalSearchView> globalSearchViews = new ArrayList<>();
        GlobalSearchView globalSearchView = null;
        for (final Object object : searchResults) {
            columns = (Object[]) object;
            globalSearchView = new GlobalSearchView();
            globalSearchView.setGlobalSearchViewId(new GlobalSearchViewId());
            globalSearchView.getGlobalSearchViewId().setEntityId(entityId);
            globalSearchView.getGlobalSearchViewId().setEntityType(columns[1] != null ? (String) columns[1] : null);
            globalSearchView.getGlobalSearchViewId().setSearchName(columns[2] != null ? (String) columns[2] : null);
            globalSearchView.getGlobalSearchViewId().setDisplayName(columns[3] != null ? (String) columns[3] : null);
            globalSearchView.getGlobalSearchViewId().setSource(columns[5] != null ? (String) columns[5] : null);
            globalSearchView.setUpdateTs(columns[4] != null ? ((Timestamp) columns[4]).toLocalDateTime() : null);
            globalSearchViews.add(globalSearchView);
        }

        saveToGsearchElasticSearch(globalSearchViews, entityId);
    }

    /**
     * Save to gsearch elastic search.
     *
     * @param typeAheads
     *            the type aheads
     * @param entityId
     *            the entity id
     */
    private void saveToGsearchElasticSearch(List<GlobalSearchView> typeAheads, Long entityId) {
        deleteGsearchExistingDocs(entityId);
        final BulkRequest bulk = new BulkRequest();
        typeAheads.stream().map(this::createGsearchIndexRequest).forEach(bulk::add);
        if (!typeAheads.isEmpty()) {
            try {
                elasticClient.bulk(bulk);
            } catch (final IOException e) {
                LOGGER.error("Problems createing indexes for entity id " + entityId, e);
            }
        }
    }

    /**
     * Delete gsearch existing docs.
     *
     * @param entityId
     *            the entity id
     */
    private void deleteGsearchExistingDocs(Long entityId) {
        try (NStringEntity entity = new NStringEntity(String.format(DELETE_BY_QUERY_REQUEST_FORAMT_GSEARCH, entityId),
                ContentType.APPLICATION_JSON)) {
            elasticClient.getLowLevelClient().performRequest("POST",
                    String.format(DELETE_BY_QUERY_URL_FORMAT, ecIndexGsearch), Collections.emptyMap(), entity);
        } catch (final IOException ex) {
            LOGGER.error("Problem removing entity with entity id " + entityId + " from Index", ex);
        }
    }

    /**
     * Creates the gsearch index request.
     *
     * @param typeahead
     *            the typeahead
     * @return the index request
     */
    private IndexRequest createGsearchIndexRequest(GlobalSearchView typeahead) {
        final IndexRequest request = new IndexRequest(ecIndexGsearch, ecTypeGsearch);
        request.source(converter.convert(typeahead, Map.class));
        return request;

    }
}
