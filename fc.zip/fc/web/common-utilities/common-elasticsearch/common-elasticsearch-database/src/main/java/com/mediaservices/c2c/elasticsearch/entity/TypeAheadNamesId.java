package com.mediaservices.c2c.elasticsearch.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The Class TypeAheadNamesId. This acts as an Composite key to get Name type
 * Ahead from Database where no key can be nullable.
 */
@Embeddable
public class TypeAheadNamesId implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The party id. */
	@Column(name = "PARTY_ID")
	private Long partyId;

	/** The party type. */
	@Column(name = "PARTY_TYPE")
	private String partyType;

	@Column(name = "ENTITY_NAME")
	private String entityName;

	/**
	 * Gets the party type.
	 *
	 * @return the party type
	 */
	public String getPartyType() {
		return partyType;
	}

	/**
	 * Sets the party type.
	 *
	 * @param partyType
	 *            the new party type
	 */
	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	/**
	 * Gets the party id.
	 *
	 * @return the party id
	 */
	public Long getPartyId() {
		return partyId;
	}

	/**
	 * Sets the party id.
	 *
	 * @param partyId
	 *            the new party id
	 */
	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	/**
	 * Gets the entity name.
	 *
	 * @return the entity name
	 */
	public String getEntityName() {
		return entityName;
	}

	/**
	 * Sets the entity name.
	 *
	 * @param entityName the new entity name
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}


}
