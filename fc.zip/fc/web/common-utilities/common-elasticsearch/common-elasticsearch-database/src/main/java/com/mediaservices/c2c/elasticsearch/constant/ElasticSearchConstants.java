package com.mediaservices.c2c.elasticsearch.constant;

/**
 * The Class ElasticSearchConstants.
 */
public class ElasticSearchConstants {

    public static final String ENTITY_ID = "EntityId";

    public static final String ENTITY_NAME = "SearchName";

    public static final String ENTITY_TYPE = "EntityType";

    public static final String ENTITY_SOURCE = "Source";

    public static final String LAST_MODIFIED_TS = "LastModifiedTs";

    public static final String DISPLAY_NAME = "DisplayName";

    public static final String FOLDED_FIELD_SUFFIX = ".folded";

    public static final String PROJECT = "PROJECT";

    public static final String DEAL = "DEAL";

    public static final String TALENT = "TALENT";

    public static final String CONTACT = "CONTACT";

    public static final String COMPANY = "COMPANY";

    /** The Constant FOLDED_ENTITY_NAME_DOC_KEY. */
    public static final String FOLDED_ENTITY_NAME_DOC_KEY = ENTITY_NAME + FOLDED_FIELD_SUFFIX;

    /**
     * The Constant AGENCY_DOC_KEY key for the agency field of a searchable
     * document.
     */
    public static final String AGENCY_DOC_KEY = "Agency";

    /**
     * The Constant ENTITY_NAME_DOC_KEY key for the entity name field of a
     * searchable document.
     */
    public static final String ENTITY_NAME_DOC_KEY = "EntityName";

    /**
     * The Constant FIRST_NAME_DOC_KEY key for the first name field of a searchable
     * document.
     */
    public static final String FIRST_NAME_DOC_KEY = "FirstName";

    /**
     * The Constant OCCUPATION_DOC_KEY key for the occupation field of a searchable
     * document.
     */
    public static final String OCCUPATION_DOC_KEY = "Occupation";

    /**
     * The Constant PARTY_ID_DOC_KEY key for the party id field of a searchable
     * document.
     */
    public static final String PARTY_ID_DOC_KEY = "PartyID";

    /**
     * The Constant PARTY_TYPE_DOC_KEY key for the Party Type field of a searchable
     * document.
     */
    public static final String PARTY_TYPE_DOC_KEY = "PartyType";

    /**
     * The Constant LAST_4SSN_DOC_KEY key for the Last 4 digits of a social security
     * number field of a searchable document.
     */
    public static final String LAST_4SSN_DOC_KEY = "Last4SSN";

    /**
     * The Constant DISPLAY_NAME_DOC_KEY key for the Display name field of a
     * searchable document.
     */
    public static final String DISPLAY_NAME_DOC_KEY = "DisplayName";

    /** The Constant TEAM_MEMBERS_DOC_KEY. */
    public static final String TEAM_MEMBERS_DOC_KEY = "TeamMembers";

    /** The Constant for the ascii folded analyzed field of the display name. */
    public static final String FOLDED_DISPLAY_NAME_DOC_KEY = DISPLAY_NAME_DOC_KEY + FOLDED_FIELD_SUFFIX;

    /** The Constant PRIMARY_NAME_DOC_KEY the "legal" name for an AKA. */
    public static final String PRIMARY_NAME_DOC_KEY = "PrimaryName";

    /** The Constant AKA_ID_DOC_KEY the id for the AKA id in the Party_aka table. */
    public static final String AKA_ID_DOC_KEY = "AkaID";

    /** The Constant IS_TALENT_DOC_KEY. */
    public static final String IS_TALENT_DOC_KEY = "IsTalent";

    /** The Constant IS_CONTACT_DOC_KEY. */
    public static final String IS_CONTACT_DOC_KEY = "IsContact";

    /** The Constant IS_COMPANY_DOC_KEY. */
    public static final String IS_COMPANY_DOC_KEY = "IsCompany";
    
    /** The Constant DATASET_ID_DOC_KEY the id for the data set id in the Party table. */
    public static final String DATASET_ID_DOC_KEY = "DataSetID";

    /**
     * The Constant FOLDED_PRIMARY_NAME_DOC_KEY for the ascii folded field for
     * primary name.
     */
    public static final String FOLDED_PRIMARY_NAME_DOC_KEY = PRIMARY_NAME_DOC_KEY + FOLDED_FIELD_SUFFIX;

    /** The Constant FOLDED_TEAM_MEMBERS_DOC_KEY. */
    public static final String FOLDED_TEAM_MEMBERS_DOC_KEY = TEAM_MEMBERS_DOC_KEY + FOLDED_FIELD_SUFFIX;

    /** The Constant SPACE used in splitting out query terms. */
    public static final String SPACE = " ";

    /** The Constant FUZZY_TERM_CHAR fuzzy search indicator for solr. */
    public static final String FUZZY_TERM_CHAR = "~";

    /** The Constant WILDCARD_CHAR wild card search indicator for solr. */
    public static final String WILDCARD_CHAR = "*";

    /** The Constant LOGICAL_AND solr logical AND operator. */
    public static final String LOGICAL_AND = "AND";

    /**
     * The Constant LOGCIAL_AND_SPACE_PADDED a logical and sutable for appending to
     * search terms.
     */
    public static final String LOGCIAL_AND_SPACE_PADDED = SPACE + LOGICAL_AND + SPACE;

    /** The Constant FUZZY_WILDCARD_TERM a fuzzy wildcard term search. */
    public static final String FUZZY_WILDCARD_TERM = FUZZY_TERM_CHAR + WILDCARD_CHAR;

    /**
     * The Constant QUERY_TERM_PATTERN a pattern to return a query term in the form
     * of (Term^10 OR Term*^5).
     */
    public static final String QUERY_TERM_PATTERN = "(%1$s^10 OR %1$s*^5)";

    /**
     * The Constant LAST_4_SSN_FORMAT a string format to add in leading zeros to the
     * last 4 of the ssn.
     */
    public static final String LAST_4_SSN_FORMAT = "%04d";

    /**
     * The Constant ELASTIC_RESERVED_CHARACTERS_REGEX checks for the elastic search
     * reserved characters + - = ! ( ) { } [ ] ^ " ~ * ? : \ / And Character sets of
     * && || and it captures it into a group to be used for replacement.
     */
    public static final String ELASTIC_RESERVED_CHARACTERS_REGEX = "([+-=!(){}\\[\\]^\\\"~*?:\\\\\\/]|[&|]{2})";

    /**
     * Instantiates a new elastic search constants.
     */
    private ElasticSearchConstants() {
    }
}
