package com.mediaservices.c2c.elasticsearch.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mediaservices.c2c.elasticsearch.entity.TypeAheadNameView;
import com.mediaservices.c2c.elasticsearch.entity.TypeAheadNamesId;

/**
 * The Interface TypeAheadNameRepository.
 */
@Repository
public interface TypeAheadRepository extends JpaRepository<TypeAheadNameView, TypeAheadNamesId> {

    /**
     * Find by type ahead display name containing ignore case.
     *
     * @param textToBeSearched
     *            the text to be searched
     * @param page
     *            the page
     * @return the list
     */
    List<TypeAheadNameView> findByTypeAheadDisplayNameContainingIgnoreCase(String textToBeSearched, Pageable page);

    /**
     * Find by type ahead display name starting with ignore case.
     *
     * @param textToBeSearched
     *            the text to be searched
     * @param page
     *            the page
     * @return the list
     */
    List<TypeAheadNameView> findByTypeAheadDisplayNameStartingWithIgnoreCase(String textToBeSearched, Pageable page);

    /**
     * Find by type ahead names id party id.
     *
     * @param partyId
     *            the party id
     * @return the list
     */
    List<TypeAheadNameView> findByTypeAheadNamesId_PartyId(long partyId);

    /**
     * Find by type ahead names id party id and type ahead names id entity name.
     *
     * @param partyId
     *            the party id
     * @param entityName
     *            the entity name
     * @return the list
     */
    List<TypeAheadNameView> findByTypeAheadNamesId_PartyIdAndTypeAheadNamesId_EntityName(long partyId,
            String entityName);

    /**
     * Find by type ahead names id party id and type ahead names id entity name and
     * and type ahead names id party type.
     *
     * @param partyId
     *            the party id
     * @param entityName
     *            the entity name
     * @param partyType
     *            the party type
     * @return the type ahead name view
     */
    TypeAheadNameView findByTypeAheadNamesId_PartyIdAndTypeAheadNamesId_EntityNameAndAndTypeAheadNamesId_PartyType(
            long partyId, String entityName, String partyType);

}
