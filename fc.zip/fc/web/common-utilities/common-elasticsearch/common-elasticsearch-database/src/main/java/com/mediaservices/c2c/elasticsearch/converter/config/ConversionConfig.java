package com.mediaservices.c2c.elasticsearch.converter.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.support.DefaultConversionService;

import com.mediaservices.c2c.elasticsearch.converter.GlobalSearchViewToMapOfStringObjectConverter;
import com.mediaservices.c2c.elasticsearch.converter.SearchHitToGlobalSearchResponseDtoConverter;
import com.mediaservices.c2c.elasticsearch.converter.TypeAheadNameViewToMapOfStringObjectConverter;

/**
 * The Class ConversionConfig.
 */
@Configuration(value = "esConversionConfig")
public class ConversionConfig {

    @Autowired
    private SearchHitToGlobalSearchResponseDtoConverter searchHitToGlobalSearchResponseDtoConverter;

    /**
     * Elastic search converter.
     *
     * @return the conversion service
     */
    @Bean()
    public ConversionService elasticSearchConverter() {
        DefaultConversionService converterService = new DefaultConversionService();
        converterService.addConverter(new TypeAheadNameViewToMapOfStringObjectConverter());
        converterService.addConverter(searchHitToGlobalSearchResponseDtoConverter);
        converterService.addConverter(new GlobalSearchViewToMapOfStringObjectConverter());
        return converterService;
    }

}
