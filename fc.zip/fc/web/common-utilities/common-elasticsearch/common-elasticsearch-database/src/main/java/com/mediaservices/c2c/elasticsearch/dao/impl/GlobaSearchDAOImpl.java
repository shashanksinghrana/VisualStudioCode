package com.mediaservices.c2c.elasticsearch.dao.impl;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

import com.mediaservices.c2c.elasticsearch.dao.GlobalSearchDAO;

@Component
public class GlobaSearchDAOImpl implements GlobalSearchDAO {

    private static final String CHECK_ACCESS = "select count(*) from DBO_MP.MODULE_ACCESS m inner join DBO_MP.LOOKUP l on m.MODULE_ID = l.LOOKUP_ID and l.LOOKUP_NAME =:lookupName and m.USER_ID =:userId";

    private static final String CHECK_ROLLCALL_ACCESS = "select count(*) from DBO_MP.ROLLCALL_ACCESS where USER_ID =:userId";

    private static final String GET_STUDIO = "select p.studio from DBO_MP.PROJECT p inner join DBO_DP.DEALS d on p.PROJECT_ID = d.PROJECT_ID and d.DEAL_ID =:dealId";

    private static final String CHECK_ST_HITLIST_ACCESS = "select count(*) from DBO_MP.USER_ACCESS m inner join DBO_MP.LOOKUP l on m.MODULE_ID = l.LOOKUP_ID and l.LOOKUP_NAME =:lookupName and m.USER_ID =:userId";

    private static final String USER_ID = "userId";

    /** The em. */
    @PersistenceContext
    private EntityManager em;

    @Override
    public boolean checkDealpointAccess(String userId) {
        final Object result = em.createNativeQuery(CHECK_ACCESS).setParameter("lookupName", "DealPoint")
                .setParameter(USER_ID, userId).getSingleResult();
        return Integer.valueOf(result.toString()) > 0;
    }

    @Override
    public boolean checkScriptTrackerAccess(String userId) {
        final Object result = em.createNativeQuery(CHECK_ST_HITLIST_ACCESS).setParameter("lookupName", "Submissions")
                .setParameter(USER_ID, userId).getSingleResult();
        return Integer.valueOf(result.toString()) > 0;
    }

    @Override
    public boolean checkHitListAccess(String userId) {
        final Object result = em.createNativeQuery(CHECK_ST_HITLIST_ACCESS).setParameter("lookupName", "Hitlist")
                .setParameter(USER_ID, userId).getSingleResult();
        return Integer.valueOf(result.toString()) > 0;
    }

    @Override
    public boolean checkFeatureCastingAccess(String userId) {
        final Object result = em.createNativeQuery(CHECK_ACCESS).setParameter("lookupName", "Feature Casting")
                .setParameter(USER_ID, userId).getSingleResult();
        return Integer.valueOf(result.toString()) > 0;
    }

    @Override
    public boolean checkRollCallAccess(String userId) {
        final Object result = em.createNativeQuery(CHECK_ROLLCALL_ACCESS).setParameter(USER_ID, userId)
                .getSingleResult();
        return Integer.valueOf(result.toString()) > 0;
    }

    @Override
    public boolean checkTalentAccess(String userId) {
        final Object result = em.createNativeQuery(CHECK_ACCESS).setParameter("lookupName", "Talent2")
                .setParameter(USER_ID, userId).getSingleResult();
        return Integer.valueOf(result.toString()) > 0;
    }

    @Override
    public Long getStudioOfDeal(Long dealId) {
        final Object result = em.createNativeQuery(GET_STUDIO).setParameter("dealId", dealId).getSingleResult();
        if (result != null) {
            return ((BigDecimal) result).longValue();
        }
        return null;
    }

}
