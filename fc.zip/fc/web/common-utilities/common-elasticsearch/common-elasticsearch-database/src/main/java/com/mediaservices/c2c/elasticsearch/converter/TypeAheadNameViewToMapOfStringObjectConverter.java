package com.mediaservices.c2c.elasticsearch.converter;

import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.AKA_ID_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.DISPLAY_NAME_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.ENTITY_NAME_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.FIRST_NAME_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.IS_COMPANY_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.IS_CONTACT_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.IS_TALENT_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.LAST_4SSN_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.OCCUPATION_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.PARTY_ID_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.PARTY_TYPE_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.PRIMARY_NAME_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.TEAM_MEMBERS_DOC_KEY;
import static com.mediaservices.c2c.elasticsearch.constant.ElasticSearchConstants.DATASET_ID_DOC_KEY;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.convert.converter.Converter;

import com.mediaservices.c2c.elasticsearch.entity.TypeAheadNameView;

/**
 * The Class TypeAheadNameViewToMapOfStringObjectConverter.
 */
public class TypeAheadNameViewToMapOfStringObjectConverter
implements Converter<TypeAheadNameView, Map<String, Object>> {

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.core.convert.converter.Converter#convert(java.lang.
     * Object)
     */
    @Override
    public Map<String, Object> convert(TypeAheadNameView typeahead) {

        Map<String, Object> doc = new HashMap<>();
        addIfNotNull(doc, PARTY_ID_DOC_KEY, typeahead.getTypeAheadNamesId().getPartyId());
        addIfNotNull(doc, ENTITY_NAME_DOC_KEY, typeahead.getTypeAheadNamesId().getEntityName());
        addIfNotNull(doc, PARTY_TYPE_DOC_KEY, typeahead.getTypeAheadNamesId().getPartyType());
        //addIfNotNull(doc, AGENCY_DOC_KEY, typeahead.getAgencyName());
        addIfNotNull(doc, FIRST_NAME_DOC_KEY, typeahead.getFirstName());
        addIfNotNull(doc, OCCUPATION_DOC_KEY, typeahead.getOccupation());
        addIfNotNull(doc, LAST_4SSN_DOC_KEY, typeahead.getSsnEndChars());
        addIfNotNull(doc, DISPLAY_NAME_DOC_KEY, typeahead.getTypeAheadDisplayName());
        addIfNotNull(doc, PRIMARY_NAME_DOC_KEY, typeahead.getPrimaryName());
        addIfNotNull(doc, TEAM_MEMBERS_DOC_KEY, typeahead.getTeamMembers());
        addIfNotNull(doc, AKA_ID_DOC_KEY, typeahead.getAkaId());
        addIfNotNull(doc, IS_TALENT_DOC_KEY, typeahead.getIsTalent());
        addIfNotNull(doc, IS_CONTACT_DOC_KEY, typeahead.getIsContact());
        addIfNotNull(doc, IS_COMPANY_DOC_KEY, typeahead.getIsCompany());
        addIfNotNull(doc, DATASET_ID_DOC_KEY, typeahead.getDataSetId());
        return doc;
    }

    /**
     * Adds the if not null.
     *
     * @param doc the doc
     * @param key the key
     * @param value the value
     */
    private void addIfNotNull(Map<String, Object> doc, String key, Object value) {
        if (value != null) {
            doc.put(key, value);
        }
    }

}
