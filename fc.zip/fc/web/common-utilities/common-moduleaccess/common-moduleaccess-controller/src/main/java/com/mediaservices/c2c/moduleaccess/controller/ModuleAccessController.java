package com.mediaservices.c2c.moduleaccess.controller;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.moduleaccess.enums.ModuleCodes;
import com.mediaservices.c2c.moduleaccess.service.ModuleAccessService;

/**
 * The Class ModuleAccessController.
 */
@RestController()
public class ModuleAccessController {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ModuleAccessController.class);

    /** The module access service. */
    @Autowired
    private ModuleAccessService moduleAccessService;

    /**
     * Check.
     *
     * @param principal
     *            the authentication
     * @param module
     *            the module
     * @return true, if successful
     */
    @CrossOrigin
    @RequestMapping(value = "/api/module-access", method = RequestMethod.GET)
    public Map<String, String> check(Principal principal, @RequestParam("moduleName") ModuleCodes module) {
        LOG.info("Checking Module permission for user");
        final Map<String, String> result = new HashMap<>();
        result.put("url", null);
        if (principal != null && principal.getName() != null) {
            result.put("url", moduleAccessService.checkModuleAccess(module, principal.getName()));
        }
        return result;
    }
}
