package com.mediaservices.c2c.moduleaccess.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * The Class ModuleAccessConfiguration.
 */
@Configuration
@ComponentScan(basePackages = { "com.mediaservices.c2c.moduleaccess" })
public class ModuleAccessConfiguration {
}
