package com.mediaservices.c2c.moduleaccess.service;

import com.mediaservices.c2c.moduleaccess.enums.ModuleCodes;

/**
 * The Interface ModuleAccessService.
 */
public interface ModuleAccessService {

    /**
     * Check module access.
     *
     * @param module
     *            the module
     * @param userId
     *            the user id
     * @return true, if successful
     */
    public String checkModuleAccess(ModuleCodes module, String userId);
}
