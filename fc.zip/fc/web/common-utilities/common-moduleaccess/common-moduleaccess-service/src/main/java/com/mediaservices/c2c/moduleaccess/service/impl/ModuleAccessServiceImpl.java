package com.mediaservices.c2c.moduleaccess.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mediaservices.c2c.moduleaccess.dao.ModuleAccessDAO;
import com.mediaservices.c2c.moduleaccess.enums.ModuleCodes;
import com.mediaservices.c2c.moduleaccess.service.ModuleAccessService;

// TODO: Auto-generated Javadoc
/**
 * The Class ModuleAccessServiceImpl.
 */
@Service("moduleAccessService")
public class ModuleAccessServiceImpl implements ModuleAccessService {

    /** The module access DAO. */
    @Autowired
    private ModuleAccessDAO moduleAccessDAO;

    /** The dp url. */
    @Value("${dp.application.context.url:/dealpoint/}")
    private String dpUrl;

    /** The fc url. */
    @Value("${fc.application.context.url:/fc/}")
    private String fcUrl;

    /** The st url. */
    @Value("${st.application.context.url:/scripttracker/}")
    private String stUrl;

    /** The hl project url. */
    @Value("${hl.application.context.url:/hitist/}")
    private String hlUrl;

    /** The talent url. */
    @Value("${tal.application.context.url:/talent/}")
    private String talentUrl;

    /** The rollcall url. */
    @Value("${rc.application.context.url:/talent/rollcall/}")
    private String rollcallUrl;

    /** The music url. */
    @Value("${music.application.context.url:/music/}")
    private String musicUrl;

    /** The contracts url. */
    @Value("${contracts.application.context.url:/contracts/}")
    private String contractsUrl;

    /** The raid url. */
    @Value("${raid.application.context.url:rating/RatingSearch.xhtml}")
    private String raidUrl;

    /** The frog url. */
    @Value("${frog.application.context.url:frog/FrogSearch.xhtml}")
    private String frogUrl;

    /** The focus url. */
    @Value("${focus.application.context.url:/focus/}")
    private String focusUrl;

    /*
     * (non-Javadoc)
     *
     * @see com.mediaservices.c2c.moduleaccess.service.ModuleAccessService#
     * checkModuleAccess(com.mediaservices.c2c.moduleaccess.enums.ModuleCodes,
     * java.lang.String)
     */
    @Override
    public String checkModuleAccess(ModuleCodes module, String userId) {
        boolean hasAccess = false;
        if (ModuleCodes.RC.getModuleName().equals(module.getModuleName())) {
            hasAccess = moduleAccessDAO.checkRollCallAccess(userId);
        } else if (ModuleCodes.RAID.getModuleName().equals(module.getModuleName())) {
            hasAccess = moduleAccessDAO.checkRaidAccess(userId);
        } else if (ModuleCodes.FOCUS.getModuleName().equals(module.getModuleName())) {
            hasAccess = moduleAccessDAO.checkFocusAccess(userId, module.getModuleName());
        } else if (ModuleCodes.ST.getModuleName().equals(module.getModuleName())
                || ModuleCodes.HL.getModuleName().equals(module.getModuleName())) {
            hasAccess = moduleAccessDAO.checkSTHitListAccess(userId, module.getModuleName());
        } else {
            hasAccess = moduleAccessDAO.checkAccess(userId, module.getModuleName());
        }
        if (hasAccess) {
            return getModuleUrl(module);
        }
        return null;
    }

    /**
     * Gets the module url.
     *
     * @param module
     *            the module
     * @return the module url
     */
    private String getModuleUrl(ModuleCodes module) {
        switch (module) {
        case DP:
            return dpUrl;
        case FC:
            return fcUrl;
        case ST:
            return stUrl;
        case HL:
            return hlUrl;
        case TALENT2:
            return talentUrl;
        case RC:
            return rollcallUrl;
        case MUSIC:
            return musicUrl;
        case CONTRACTS:
            return contractsUrl;
        case RAID:
            return stUrl + raidUrl;
        case FROG:
            return stUrl + frogUrl;
        case FOCUS:
            return focusUrl;
        }
        return null;
    }

}
