package com.mediaservices.c2c.moduleaccess.enums;

/**
 * The Enum ModuleCodes.
 */
public enum ModuleCodes {

    /** The dp. */
    DP("DealPoint"),
    /** The st. */
    ST("Submissions"),
    /** The hl. */
    HL("Hitlist"),
    /** The fc. */
    FC("Feature Casting"),
    /** The rc. */
    RC("RollCall2"),
    /** The talent2. */
    TALENT2("Talent2"),
    /** The music. */
    MUSIC("Music"),
    /** The contracts. */
    CONTRACTS("Contracts"),
    /** The raid. */
    RAID("Raid"),
    /** The frog. */
    FROG("Frog"),
    /** The focus. */
    FOCUS("Focus");

    /** The module name. */
    private String moduleName;

    /**
     * Instantiates a new module codes.
     *
     * @param moduleName
     *            the module name
     */
    private ModuleCodes(final String moduleName) {
        this.moduleName = moduleName;
    }

    /**
     * Gets the module name.
     *
     * @return the module name
     */
    public String getModuleName() {
        return moduleName;
    }
}
