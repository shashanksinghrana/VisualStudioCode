package com.mediaservices.c2c.moduleaccess.dao;

/**
 * The Interface ModuleAccessDAO.
 */
public interface ModuleAccessDAO {

    /**
     * Check access.
     *
     * @param userId
     *            the user id
     * @param moduleName
     *            the module name
     * @return true, if successful
     */
    public boolean checkAccess(String userId, String moduleName);

    /**
     * Check roll call access.
     *
     * @param userId
     *            the user id
     * @return true, if successful
     */
    public boolean checkRollCallAccess(String userId);

    /**
     * Check raid access.
     *
     * @param userId
     *            the user id
     * @return true, if successful
     */
    public boolean checkRaidAccess(String userId);

    /**
     * Check focus access.
     *
     * @param userId
     *            the user id
     * @param moduleName
     *            the module name
     * @return true, if successful
     */
    public boolean checkFocusAccess(String userId, String moduleName);

    /**
     * Check ST hit list access.
     *
     * @param userId
     *            the user id
     * @param moduleName
     *            the module name
     * @return true, if successful
     */
    public boolean checkSTHitListAccess(String userId, String moduleName);

}
