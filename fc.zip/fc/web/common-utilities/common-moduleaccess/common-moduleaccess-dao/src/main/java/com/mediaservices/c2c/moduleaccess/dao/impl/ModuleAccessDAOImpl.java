package com.mediaservices.c2c.moduleaccess.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.moduleaccess.dao.ModuleAccessDAO;
import com.mediaservices.c2c.moduleaccess.dto.EntityManagerHolder;

/**
 * The Class ModuleAccessDAOImpl.
 */
@Component
public class ModuleAccessDAOImpl implements ModuleAccessDAO {

	/** The Constant CHECK_ACCESS. */
	private static final String CHECK_ACCESS = "select count(*) from DBO_MP.MODULE_ACCESS m inner join DBO_MP.LOOKUP l on m.MODULE_ID = l.LOOKUP_ID and l.LOOKUP_NAME =:lookupName and m.USER_ID =:userId";

	/** The Constant CHECK_ROLLCALL_ACCESS. */
	private static final String CHECK_ROLLCALL_ACCESS = "select count(*) from DBO_MP.ROLLCALL_ACCESS where USER_ID =:userId";

	/** The Constant CHECK_RAID_ACCESS. */
	private static final String CHECK_RAID_ACCESS = "select count(*) from DBO_MP.RATING_ACCESS where USER_ID =:userId";

	/** The Constant CHECK_FOCUS_ACCESS. */
	private static final String CHECK_FOCUS_ACCESS = "select count(*) from DBO_MP.USER_ACCESS m inner join DBO_MP.LOOKUP l on m.MODULE_ID = l.LOOKUP_ID and l.LOOKUP_NAME =:lookupName and m.USER_ID =:userId";

	private static final String CHECK_ST_HITLIST_ACCESS = "select count(*) from DBO_MP.USER_ACCESS m inner join DBO_MP.LOOKUP l on m.MODULE_ID = l.LOOKUP_ID and l.LOOKUP_NAME =:lookupName and m.USER_ID =:userId";

	/** The Constant USER_ID. */
	private static final String USER_ID = "userId";

	/** The Constant LOOKUP_NAME. */
	private static final String LOOKUP_NAME = "lookupName";


	/** The entity manager holder. */
	@Autowired
	private EntityManagerHolder entityManagerHolder;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.mediaservices.c2c.moduleaccess.dao.ModuleAccessDAO#checkAccess(java.
	 * lang.String, java.lang.String)
	 */
	@Override
	public boolean checkAccess(String userId, String moduleName) {
		final Object result = entityManagerHolder.getEntityManager().createNativeQuery(CHECK_ACCESS)
				.setParameter(LOOKUP_NAME, moduleName).setParameter(USER_ID, userId).getSingleResult();
		return Integer.valueOf(result.toString()) > 0;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.mediaservices.c2c.moduleaccess.dao.ModuleAccessDAO#
	 * checkRollCallAccess(java.lang.String)
	 */
	@Override
	public boolean checkRollCallAccess(String userId) {
		final Object result = entityManagerHolder.getEntityManager().createNativeQuery(CHECK_ROLLCALL_ACCESS)
				.setParameter(USER_ID, userId).getSingleResult();
		return Integer.valueOf(result.toString()) > 0;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.mediaservices.c2c.moduleaccess.dao.ModuleAccessDAO#checkRaidAccess(
	 * java.lang.String)
	 */
	@Override
	public boolean checkRaidAccess(String userId) {
		final Object result = entityManagerHolder.getEntityManager().createNativeQuery(CHECK_RAID_ACCESS)
				.setParameter(USER_ID, userId).getSingleResult();
		return Integer.valueOf(result.toString()) > 0;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.mediaservices.c2c.moduleaccess.dao.ModuleAccessDAO#checkFocusAccess(
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public boolean checkFocusAccess(String userId, String moduleName) {
		final Object result = entityManagerHolder.getEntityManager().createNativeQuery(CHECK_FOCUS_ACCESS)
				.setParameter(LOOKUP_NAME, moduleName).setParameter(USER_ID, userId).getSingleResult();
		return Integer.valueOf(result.toString()) > 0;
	}

	@Override
	public boolean checkSTHitListAccess(String userId, String moduleName) {
		final Object result = entityManagerHolder.getEntityManager().createNativeQuery(CHECK_ST_HITLIST_ACCESS)
				.setParameter("lookupName", "Submissions").setParameter(USER_ID, userId).getSingleResult();
		return Integer.valueOf(result.toString()) > 0;
	}

}
