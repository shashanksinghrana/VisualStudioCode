package com.mediaservices.c2c.moduleaccess.dto;

import javax.persistence.EntityManager;

/**
 * The Class EntityManagerHolder.
 */
public class EntityManagerHolder {

	/** The entity manager. */
	private EntityManager entityManager;

	/**
	 * Instantiates a new entity manager holder.
	 *
	 * @param entityManager the entity manager
	 */
	public EntityManagerHolder(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Gets the entity manager.
	 *
	 * @return the entity manager
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}
}
