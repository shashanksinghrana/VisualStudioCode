package com.mediaservices.c2c.dsync.service;

import java.net.Inet4Address;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mediaservices.c2c.dsync.entity.DistributedSynchronizationEntity;
import com.mediaservices.c2c.dsync.repository.DateItemRepository;
import com.mediaservices.c2c.dsync.repository.DistributedSynchronizationRepository;

/**
 * The Class DatabaseDistributedSynchronizationService.
 */
@Service("databaseDistributedSynchronizationService")
public class DatabaseDistributedSynchronizationService implements DistributedSynchronizationService {
    /** Logger. */
    private static final Logger LOGGER = LoggerFactory.getLogger(DatabaseDistributedSynchronizationService.class);

    /** Default value is 7 minute interval 7 * 60 * 1000. */
    @Value("${dsync.heartbeat_interval:60000}")
    private long heartbeatInterval;

    /** The distributed synchronization reposiroty. */
    @Autowired
    private DistributedSynchronizationRepository dsyncRepository;

    /** The date repository. */
    @Autowired
    private DateItemRepository dateRepository;

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.dsync.service.DistributedSynchronizationService#
     * acquireLock(java.lang.String)
     */
    @Transactional(propagation=Propagation.SUPPORTS, noRollbackFor={Exception.class})
    @Override
    public boolean acquireLock(final String lockName) {
        System.out.println(dateRepository.getSysdate());
        LOGGER.debug("DistributedSynchronization Acquiring Lock for lockName  : {}", lockName);
        DistributedSynchronizationEntity distributedSynchronizationEntity = getDistributedSynchronizationEntity(
                lockName);
        if (distributedSynchronizationEntity == null) {
            LOGGER.debug("DistributedSynchronization distributedSynchronizationEntity is NULL for {}", lockName);
            return createDistributedLockEntry(lockName);
        } else {
            if (distributedSynchronizationEntity.isLocked()) {
                boolean isLive = checkIsHeartbeatLive(distributedSynchronizationEntity.getLiveOn());
                if (isLive) {
                    LOGGER.debug("DistributedSynchronization Heartbeat is LIVE for {}",
                            distributedSynchronizationEntity.getLiveOn());
                    return false;
                } else {
                    LOGGER.debug("DistributedSynchronization Heartbeat is DEAD for {}",
                            distributedSynchronizationEntity.getLiveOn());
                    return captureDistributedLock(distributedSynchronizationEntity);
                }
            } else {
                LOGGER.debug("DistributedSynchronization NOT LOCKED for lock name {}",
                        distributedSynchronizationEntity.getLockName());
                return captureDistributedLock(distributedSynchronizationEntity);
            }
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.dsync.service.DistributedSynchronizationService#
     * updateHeartbeat(java.lang.String)
     */
    @Override
    public void updateHeartbeat(final String lockName) {
        LOGGER.debug("DistributedSynchronization Updating Heartbeat for lockName : {}", lockName);
        DistributedSynchronizationEntity distributedSynchronizationEntity = getDistributedSynchronizationEntity(
                lockName);
        if (distributedSynchronizationEntity != null) {
            LOGGER.debug("DistributedSynchronization Updating Heartbeat for existing lockid : {}",
                    distributedSynchronizationEntity.getId());
            distributedSynchronizationEntity.setLiveOn(getCurrentTimestamp());
            boolean isHeartbeatUpdated = saveDistributedSynchronizationEntity(distributedSynchronizationEntity);
            if (isHeartbeatUpdated) {
                LOGGER.debug("DistributedSynchronization Heartbeat Updated");
            } else {
                LOGGER.debug("DistributedSynchronization Heartbeat Update FAILED for lockName");
            }
        } else {
            LOGGER.error(
                    "DistributedSynchronization Update Heartbeat FAILED, distributedSynchronizationEntity is NULL for lockName : {}",
                    lockName);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.dsync.service.DistributedSynchronizationService#
     * releaseLock(java.lang.String)
     */
    @Transactional(propagation=Propagation.SUPPORTS, noRollbackFor={Exception.class})
    @Override
    public void releaseLock(final String lockName) {
        LOGGER.debug("DistributedSynchronization Releasing Lock for lockName : {}", lockName);
        DistributedSynchronizationEntity distributedSynchronizationEntity = getDistributedSynchronizationEntity(
                lockName);
        if (distributedSynchronizationEntity != null) {
            distributedSynchronizationEntity.setLocked(false);
            boolean isReleased = saveDistributedSynchronizationEntity(distributedSynchronizationEntity);
            if (isReleased) {
                LOGGER.debug("DistributedSynchronization Lock Released for lockid : {}",
                        distributedSynchronizationEntity.getId());
            } else {
                LOGGER.error("DistributedSynchronization Lock Release FAILED for lockid : {}",
                        distributedSynchronizationEntity.getId());
            }
        } else {
            LOGGER.error(
                    "DistributedSynchronization Lock Release FAILED, distributedSynchronizationEntity is NULL for lockName : {}",
                    lockName);
        }
    }

    /**
     * Capture distributed lock.
     *
     * @param distributedSynchronizationEntity
     *            the distributed synchronization entity
     * @return true, if successful
     */
    private boolean captureDistributedLock(final DistributedSynchronizationEntity distributedSynchronizationEntity) {
        if (distributedSynchronizationEntity != null) {
            distributedSynchronizationEntity.setLiveOn(getCurrentTimestamp());
            distributedSynchronizationEntity.setLocked(true);
            return saveDistributedSynchronizationEntity(distributedSynchronizationEntity);
        } else {
            LOGGER.error("DistributedSynchronization Capture Lock FAILED, distributedSynchronizationEntity is NULL");
        }
        return false;
    }

    /**
     * Check is heartbeat live.
     *
     * @param heartbeatTimestamp
     *            the heartbeat timestamp
     * @return true, if successful
     */
    private boolean checkIsHeartbeatLive(final Timestamp heartbeatTimestamp) {
        if (heartbeatTimestamp != null) {
            Timestamp currentTimestamp = getCurrentTimestamp();
            long diff = currentTimestamp.getTime() - heartbeatTimestamp.getTime();
            LOGGER.debug(
                    "DistributedSynchronization currentTimestamp {} - heartbeatTimestamp {}, diff : {}, heartbeatInterval : {}",
                    currentTimestamp, heartbeatTimestamp, diff, heartbeatInterval);
            if (diff >= 0 && diff < heartbeatInterval) {
                return true;
            } else {
                LOGGER.error(
                        "INFO DistributedSynchronization currentTimestamp {} - heartbeatTimestamp {}, diff : {}, heartbeatInterval : {}",
                        currentTimestamp, heartbeatTimestamp, diff, heartbeatInterval);
            }
        }
        return false;
    }

    /**
     * Creates the distributed lock entry.
     *
     * @param lockName
     *            the lock name
     * @return true, if successful
     */
    private boolean createDistributedLockEntry(final String lockName) {
        DistributedSynchronizationEntity distributedSynchronizationEntity = createDistributedSynchronizationEntity(
                lockName);
        return saveDistributedSynchronizationEntity(distributedSynchronizationEntity);
    }

    /**
     * Creates the distributed synchronization entity.
     *
     * @param lockName
     *            the lock name
     * @return the distributed synchronization entity
     */
    private DistributedSynchronizationEntity createDistributedSynchronizationEntity(final String lockName) {
        DistributedSynchronizationEntity distributedSynchronizationEntity = new DistributedSynchronizationEntity();
        distributedSynchronizationEntity.setLocked(true);
        distributedSynchronizationEntity.setLockName(lockName);
        distributedSynchronizationEntity.setLiveOn(getCurrentTimestamp());
        distributedSynchronizationEntity.setVersion(0);
        return distributedSynchronizationEntity;
    }

    /**
     * Gets the distributed synchronization entity.
     *
     * @param lockName
     *            the lock name
     * @return the distributed synchronization entity
     */
    private DistributedSynchronizationEntity getDistributedSynchronizationEntity(final String lockName) {
        return dsyncRepository.findByLockName(lockName);
    }

    /**
     * Save distributed synchronization entity.
     *
     * @param distributedSynchronizationEntity
     *            the distributed synchronization entity
     * @return true, if successful
     */
    private boolean saveDistributedSynchronizationEntity(
            final DistributedSynchronizationEntity distributedSynchronizationEntity) {
        if (distributedSynchronizationEntity != null) {
            try {
                distributedSynchronizationEntity.setHost(getHost());
                dsyncRepository.saveAndFlush(distributedSynchronizationEntity);
                LOGGER.debug("DistributedSynchronization Saved with lockname : {}",
                        distributedSynchronizationEntity.getLockName());
                return true;
            } catch (Exception e) {
                LOGGER.error("DistributedSynchronization Saved FAILED for lockname: {}",
                        distributedSynchronizationEntity.getLockName(), e);
            }
        } else {
            LOGGER.error("DistributedSynchronization Save FAILED, distributedSynchronizationEntity is NULL");
        }
        return false;
    }

    /**
     * Gets the host.
     *
     * @return the host
     */
    private String getHost() {
        try {
            return Inet4Address.getLocalHost().getHostName();
        } catch (Exception e) {
            LOGGER.error("DistributedSynchronization Get HostName FAILED", e);
        }
        return null;
    }

    /**
     * Gets the current timestamp.
     *
     * @return the current timestamp
     */
    public Timestamp getCurrentTimestamp() {
        try {
            return new Timestamp(dateRepository.getSysdate().getDate().getTime());
        } catch (Exception e) {
            LOGGER.error("Error Fetching Timestamp from Database", e);
        }
        return new Timestamp(System.currentTimeMillis());
    }
}
