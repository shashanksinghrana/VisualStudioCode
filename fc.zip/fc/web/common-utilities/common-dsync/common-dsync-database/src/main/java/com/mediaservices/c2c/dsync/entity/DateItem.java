package com.mediaservices.c2c.dsync.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The Class DateItem.
 */
@Entity
public class DateItem {

    /** The date. */
    private Date date;

    /**
     * Gets the date.
     *
     * @return the date
     */
    @Id
    @Column(name = "DATE_VALUE")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getDate() {
        return date;
    }

    /**
     * Sets the date.
     *
     * @param date
     *            the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }
}