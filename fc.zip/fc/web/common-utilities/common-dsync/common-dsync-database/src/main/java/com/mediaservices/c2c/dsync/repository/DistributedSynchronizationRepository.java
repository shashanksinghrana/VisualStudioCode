package com.mediaservices.c2c.dsync.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mediaservices.c2c.dsync.entity.DistributedSynchronizationEntity;

/**
 * The Interface DistributedSynchronizationRepository.
 */
@Repository
public interface DistributedSynchronizationRepository extends JpaRepository<DistributedSynchronizationEntity, String> {

    /**
     * Find by lock name.
     *
     * @param lockName the lock name
     * @return the distributed synchronization entity
     */
    DistributedSynchronizationEntity findByLockName(final String lockName);
}
