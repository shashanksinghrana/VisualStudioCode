package com.mediaservices.c2c.dsync.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mediaservices.c2c.dsync.entity.DateItem;

/**
 * The Interface DistributedSynchronizationRepository.
 */
@Repository
public interface DateItemRepository extends JpaRepository<DateItem, Date> {

    /**
     * Gets the sysdate.
     *
     * @return the sysdate
     */
    @Query(value = "select sysdate as date_value from dual", nativeQuery = true)
    public DateItem getSysdate();
}
