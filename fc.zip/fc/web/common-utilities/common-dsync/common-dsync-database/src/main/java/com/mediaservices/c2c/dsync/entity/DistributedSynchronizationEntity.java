package com.mediaservices.c2c.dsync.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;

/**
 * The persistent class for the dsync_lock database table.
 */
@Entity
@Table(name = "dsync_lock")
@Cacheable(false)
public class DistributedSynchronizationEntity implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The id. */
    @Id
    @Column(name = "id", unique = true, nullable = false, columnDefinition = "char(36)")
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
    private String id;

    /** The lock name. */
    @Column(name = "lock_name", unique = true, length = 100, nullable = false)
    private String lockName;

    /** The host. */
    @Column(name = "host_name")
    private String host;

    /** The is locked. */
    @Column(name = "is_locked")
    private boolean isLocked;

    /** The live on. */
    @Column(name = "live_on")
    private Timestamp liveOn;

    /** The version. */
    @Version
    @Column(name = "version")
    private long version;

    /**
     * Gets the lock name.
     *
     * @return the lock name
     */
    public String getLockName() {
        return lockName;
    }

    /**
     * Sets the lock name.
     *
     * @param lockName
     *            the new lock name
     */
    public void setLockName(String lockName) {
        this.lockName = lockName;
    }

    /**
     * Gets the host.
     *
     * @return the host
     */
    public String getHost() {
        return host;
    }

    /**
     * Sets the host.
     *
     * @param host
     *            the new host
     */
    public void setHost(String host) {
        this.host = host;
    }

    /**
     * Checks if is locked.
     *
     * @return true, if is locked
     */
    public boolean isLocked() {
        return isLocked;
    }

    /**
     * Sets the locked.
     *
     * @param isLocked
     *            the new locked
     */
    public void setLocked(boolean isLocked) {
        this.isLocked = isLocked;
    }

    /**
     * Gets the live on.
     *
     * @return the live on
     */
    public Timestamp getLiveOn() {
        return liveOn;
    }

    /**
     * Sets the live on.
     *
     * @param liveOn
     *            the new live on
     */
    public void setLiveOn(Timestamp liveOn) {
        this.liveOn = liveOn;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public long getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version
     *            the new version
     */
    public void setVersion(long version) {
        this.version = version;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
