package com.mediaservices.c2c.dsync.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit4.SpringRunner;

import com.mediaservices.c2c.dsync.config.DistributedSyncConfiguration;
import com.mediaservices.c2c.dsync.config.TestDataSourceConfig;

/**
 * The Class DatabaseDistributedSynchronizationServiceIntegrationTest has the
 * integration tests with H2 in-memory database.
 */
@RunWith(SpringRunner.class)
@Import({ DistributedSyncConfiguration.class, TestDataSourceConfig.class })
public class DatabaseDistributedSynchronizationServiceIntegrationTest {

    @Value("${dsync.heartbeat_interval}")
    private Long heartbeatInterval;

    @Autowired
    private DistributedSynchronizationService dsyncService;

    /**
     * Test acquire lock.
     */
    @Test
    public void testAcquireLock() {
        boolean isLockAcquired = Boolean.FALSE;
        String lockName = "test";

        // Lock should be acquired for the first time
        isLockAcquired = dsyncService.acquireLock(lockName);
        assertThat(isLockAcquired).isEqualTo(true);

        // Lock should NOT be acquired for 2nd time as it's already given
        isLockAcquired = dsyncService.acquireLock(lockName);
        assertThat(isLockAcquired).isEqualTo(false);

        // Lock should be acquired after releasing earlier lock
        dsyncService.releaseLock(lockName);
        isLockAcquired = dsyncService.acquireLock(lockName);
        assertThat(isLockAcquired).isEqualTo(true);

        // Lock should be acquired after waiting for hearbeat interval
        try {
            Thread.sleep(heartbeatInterval);
        } catch (InterruptedException e) {
            // Do Nothing
        }
        isLockAcquired = dsyncService.acquireLock(lockName);
        assertThat(isLockAcquired).isEqualTo(true);

    }
}
