package com.mediaservices.c2c.dsync.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * The Class DistributedSyncConfiguration provides spring bootstrapping
 * configuration.
 */
@Configuration
@ComponentScan(basePackages = { "com.mediaservices.c2c.dsync" })
public class DistributedSyncConfiguration {
}
