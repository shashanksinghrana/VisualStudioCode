package com.mediaservices.c2c.dsync.service;

/**
 * Provide api details of {@link DistributedSynchronizationService}
 */
public interface DistributedSynchronizationService {

    /**
     * Acquire lock.
     *
     * @param lockName
     *            the lock name
     * @return true, if successful
     */
    boolean acquireLock(String lockName);

    /**
     * Release lock.
     *
     * @param lockName
     *            the lock name
     */
    void releaseLock(String lockName);

    /**
     * Update heartbeat.
     *
     * @param lockName
     *            the lock name
     */
    void updateHeartbeat(String lockName);

}
