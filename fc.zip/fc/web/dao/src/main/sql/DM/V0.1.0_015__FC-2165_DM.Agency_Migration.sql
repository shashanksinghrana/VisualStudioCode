DECLARE
--FC_AGENT_IMPORT
V_SCRIPT_ID VARCHAR2(10) :='1.00.122';

V_PARTY_ID NUMBER;
v_contact_id NUMBER;
V_ERROR VARCHAR2(4000);
--CREATE 
CURSOR C_AGENCY IS
SELECT *
FROM FC_SOURCE.FC_AGENCY_STAGING
WHERE 1=1
AND PARTY_ID IS NULL;

--
--CREATE_PARTY_COMPANY
FUNCTION CREATE_PARTY_COMPANY(P_PARTY_ID IN NUMBER,
P_ADDRESS_LINE1 IN VARCHAR2,
P_ADDRESS_LINE2 IN VARCHAR2,
P_ADDRESS_LINE3 IN VARCHAR2,
P_CITY IN VARCHAR2,
P_STATE IN VARCHAR2,
P_COUNTRY IN VARCHAR2,
P_ZIP IN VARCHAR2)
RETURN NUMBER
AS
V_CONTACT_ID NUMBER;
v_ADDRESS_id NUMBER;
V_AGENCY_EXIST VARCHAR2(5);
BEGIN
V_CONTACT_ID:=NULL;
v_ADDRESS_id:=NULL;
--CHECK WHETHER THE ADDRESS EXIST FOR THE COMPANY
BEGIN
SELECT PC.CONTACT_ID
INTO V_AGENCY_EXIST
FROM DBO_TC.ADDRESS AD,DBO_TC.PARTY_CONTACT PC
WHERE  	PC.CONTACT_ID=AD.CONTACT_ID
AND 	PC.PARTY_ID=P_PARTY_ID
AND 	TRIM(NVL(FIRST_LINE,'N'))=TRIM(NVL(P_ADDRESS_LINE1,'N'))
AND  	TRIM(NVL(SECOND_LINE,'N'))=TRIM(NVL(P_ADDRESS_LINE2,'N'))
AND   	TRIM(NVL(THIRD_LINE,'N'))=TRIM(NVL(P_ADDRESS_LINE3,'N'))
AND 	TRIM(NVL(CITY,'N'))=TRIM(NVL(P_CITY,'N'))
AND ROWNUM=1;
--
EXCEPTION
WHEN OTHERS THEN
 V_AGENCY_EXIST:=NULL;
END;
IF V_AGENCY_EXIST IS NULL THEN 
BEGIN
BEGIN
SELECT CONTACT_ID 
INTO v_contact_id
FROM dbo_tc.PARTY_CONTACT
WHERE PARTY_ID=P_PARTY_ID
AND CONTACT_TYPE='ADDRESS'
AND PRIMARY_FLAG='Y'
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
v_contact_id:=NULL;
END;
IF v_contact_id IS NULL THEN
	BEGIN
		select dbo_tc.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		Insert into dbo_tc.party_contact (CONTACT_ID,PARTY_ID,CONTACT_TYPE,PRIMARY_FLAG,CREATED_BY,CREATED_DATE,UPDATED_BY,UPDATE_DATE,	UPDATED_BY_APP) values 
		(v_contact_id,P_PARTY_ID,'ADDRESS','Y','c2cdm',SYSDATE,'c2cdm',SYSDATE,401);
		
	EXCEPTION
		WHEN OTHERS THEN
					V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to party_contact_table for Suite Address',V_ERROR); 
			
	END;
ELSE
	BEGIN
		select dbo_tc.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		Insert into dbo_tc.party_contact (CONTACT_ID,PARTY_ID,CONTACT_TYPE,PRIMARY_FLAG,CREATED_BY,CREATED_DATE,UPDATED_BY,UPDATE_DATE,	UPDATED_BY_APP) values 
		(v_contact_id,P_PARTY_ID,'ADDRESS','N','c2cdm',SYSDATE,'c2cdm',SYSDATE,401);
		
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to party_contact_table for else Address'||P_PARTY_ID,V_ERROR); 
			
	END;
END IF;
END;
BEGIN
SELECT ADDRESS_ID
INTO v_ADDRESS_id
FROM dbo_tc.ADDRESS
WHERE contact_id=v_contact_id
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	BEGIN
		select DBO_TC.SEQ_ADDRESS_ID.NEXTVAL 
		into v_ADDRESS_id
		from dual;
--	
	INSERT INTO dbo_tc.ADDRESS (  ADDRESS_ID,CONTACT_ID,
                         LOCATION_NAME,ADDRESS_TYPE,
                         FIRST_LINE,SECOND_LINE,THIRD_LINE,CITY,
                         STATE,ZIP,COUNTRY,STATE_ID) VALUES 
		(	v_ADDRESS_id,
			v_contact_id,
			NULL,
			'OFFICE',
			P_ADDRESS_LINE1,
			P_ADDRESS_LINE2,
			P_ADDRESS_LINE3,
			P_CITY,
			P_STATE,
			P_ZIP,
			FC_SOURCE.FC_MAP_PKG.GET_C2_COUNTRY_ID(P_COUNTRY),
			FC_SOURCE.FC_MAP_PKG.GET_C2_STATE_ID(P_STATE)
      );
	EXCEPTION
		WHEN OTHERS THEN
--
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to address table for party id'||p_party_id,V_ERROR); 
	END;
END;
ELSE 
v_contact_id:=V_AGENCY_EXIST;
END IF;
RETURN v_contact_id;
commit;
END;
--
--PROC_CONTACT_PHONE
PROCEDURE PROC_CONTACT_PHONE(P_PARTY_ID IN NUMBER,
P_PHONE_TYPE IN VARCHAR2,
P_PHONE_NO IN VARCHAR2,
P_CONTACT_ID IN NUMBER) 
AS
v_contact_phone_id NUMBER;
v_phone_id NUMBER;
V_PROP_ID NUMBER;
v_cont_reln_id NUMBER;
V_PHONE_EXIST VARCHAR2(5);
V_PRIMARY_FLAG VARCHAR2(10);
P_PRIMARY_FLAG VARCHAR2(10);
BEGIN
V_PHONE_EXIST:=NULL;
--
BEGIN
SELECT 'Y'
INTO V_PHONE_EXIST
FROM DBO_TC.PHONE PH,DBO_TC.PARTY_CONTACT PC
WHERE  	PC.CONTACT_ID=PH.CONTACT_ID
AND 	PC.PARTY_ID=P_PARTY_ID
AND 	TRIM(NVL(PHONE_NO,'N'))=TRIM(NVL(P_PHONE_NO,'N'))
AND ROWNUM=1;
--
EXCEPTION
WHEN OTHERS THEN
 V_PHONE_EXIST:=NULL;
END;
--
IF V_PHONE_EXIST IS NULL THEN
BEGIN 
v_contact_phone_id:=NULL;
v_phone_id:=NULL;
V_PROP_ID:=NULL;
v_cont_reln_id:=NULL;
V_PRIMARY_FLAG:=NULL;
P_PRIMARY_FLAG:=NULL;
--
BEGIN
		SELECT PRIMARY_FLAG
		INTO V_PRIMARY_FLAG
		FROM DBO_TC.PARTY_CONTACT
		WHERE PARTY_ID=P_PARTY_ID
		AND CONTACT_TYPE='PHONE'
		AND PRIMARY_FLAG='Y'
		AND ROWNUM=1;
		--
		IF V_PRIMARY_FLAG='Y'
		THEN 
			P_PRIMARY_FLAG:='N';
		ELSE 
			P_PRIMARY_FLAG:='Y';
		END IF;
			
	EXCEPTION
  WHEN OTHERS THEN 
		P_PRIMARY_FLAG:='Y';
	END;
	--
select dbo_tc.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_phone_id
		from dual;
--
		INSERT INTO dbo_tc.PARTY_CONTACT (CONTACT_ID,
                              PARTY_ID,
                              CONTACT_TYPE,
                              PRIMARY_FLAG,
                              CREATED_BY,
                              CREATED_DATE,
                              UPDATED_BY,
                              UPDATE_DATE,	
                              UPDATED_BY_APP) values 
                              (v_contact_phone_id,
                              p_party_id,
                              'PHONE',
                              p_primary_flag,
                              'c2cdm',
                              SYSDATE,
                              'c2cdm',
                              SYSDATE,
                              NULL
                             );
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to party_contact table for party id'||p_party_id,V_ERROR); 
	END;
	commit;
	--
	BEGIN
		SELECT SPV.PROP_ID
		INTO V_PROP_ID
		FROM dbo_tc.SYS_PROPERTY SP,
			 dbo_tc.SYS_PROP_VALUE SPV
		WHERE SP.SYS_PROP_ID=SPV.SYS_PROP_ID
		AND SP.SYS_PROP_NAME LIKE 'PHONE_TYPE'
		AND spv.prop_value=P_PHONE_TYPE
		AND ROWNUM=1;
	EXCEPTION
	WHEN OTHERS THEN
--
		V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting phone type data to table for location1 phone1 for party'||p_party_id,V_ERROR); 
		END;
	
	BEGIN
		select dbo_tc.SEQ_PHONE_ID.NEXTVAL 
		into v_phone_id
		from dual;
--
	INSERT INTO dbo_tc.PHONE ( 
						 PHONE_ID,CONTACT_ID,
                         PHONE_TYPE,PHONE_NO) VALUES 
					  (	v_phone_id,
						v_contact_phone_id,
						V_PROP_ID,
						P_PHONE_NO);
--					
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to phone table for party'||p_party_id,V_ERROR); 
			--
	END;
	--ADDRESS_PHONE--
	BEGIN
		select dbo_tc.SEQ_CONTACT_RELATION_ID.NEXTVAL 
		into v_cont_reln_id
		from dual;
--
	INSERT INTO dbo_tc.CONTACT_RELATION ( 
						 PARENT_CONTACT_ID, CHILD_CONTACT_ID, RELATION_TYPE, CONTACT_RELATION_ID) VALUES 
					  (	P_CONTACT_ID,
						v_contact_phone_id,'ADDRESS_PHONE',v_cont_reln_id);
--					
	EXCEPTION
		WHEN OTHERS THEN
		--
				V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to contact relation  table for party'||p_party_id,V_ERROR); 
			--
	END;
	COMMIT;
	END IF;
END;
--EMAIL IMPORT
PROCEDURE PROC_CONTACT_EMAIL(P_PARTY_ID IN NUMBER,
P_EMAIL_TYPE IN VARCHAR2,
P_PRIMARY_FLAG IN VARCHAR2,
P_EMAIL IN VARCHAR2) 
AS
v_contact_id NUMBER;
v_email_id NUMBER;
V_PROP_ID NUMBER;
BEGIN
--
BEGIN 
v_contact_id:=NULL;
v_email_id:=NULL;
V_PROP_ID:=NULL;
--
select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		INSERT INTO dbo_tc.PARTY_CONTACT (CONTACT_ID,
                              PARTY_ID,
                              CONTACT_TYPE,
                              PRIMARY_FLAG,
                              CREATED_BY,
                              CREATED_DATE,
                              UPDATED_BY,
                              UPDATE_DATE,	
                              UPDATED_BY_APP) values 
                              (v_contact_id,
                              p_party_id,
                              'SOCIAL_MEDIA',
                              p_primary_flag,
                              'c2cdm',
                              SYSDATE,
                              'c2cdm',
                              SYSDATE,
                              NULL
                             );
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to PARTY_CONTACT relation  table for party email'||p_party_id,V_ERROR); 
	END;
	commit;
	--
	BEGIN
		SELECT SPV.PROP_ID
		INTO V_PROP_ID
		FROM dbo_tc.SYS_PROPERTY SP,
			 dbo_tc.SYS_PROP_VALUE SPV
		WHERE SP.SYS_PROP_ID=SPV.SYS_PROP_ID
		AND SP.SYS_PROP_NAME LIKE 'SOCIAL_MEDIA'
		AND spv.prop_value=P_EMAIL_TYPE
		AND ROWNUM=1;
	EXCEPTION
	WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting phone type data to table for location email for party'||p_party_id,V_ERROR); 
	END;
--
	
	BEGIN
		select dbo_tc.SEQ_WEBCONTACT_ID.NEXTVAL 
		into v_email_id
		from dual;
--
	INSERT INTO dbo_tc.WEB_CONTACT ( 
						 WEBCONTACT_ID,CONTACT_ID,
                         CONTACT_TYPE,CONTACT_VALUE) VALUES 
					  (	v_email_id,
						v_contact_id,
						V_PROP_ID,
						P_EMAIL);
--					
	EXCEPTION
		WHEN OTHERS THEN
					V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to web_contact_table party'||v_contact_id,V_ERROR); 
	END;
END;
--PARTY_PERSON_IMPORT
PROCEDURE PERSON_COMPANY_INSERT(P_PARTY_ID IN NUMBER,P_COMPANY_NAME IN VARCHAR2)
AS
V_PARTY_ID NUMBER;
V_CONTACT_ID NUMBER;
BEGIN

BEGIN
		SELECT PARTY_ID
		INTO V_PARTY_ID
		FROM dbo_tc.COMPANY
		WHERE PARTY_ID=P_PARTY_ID
		AND ROWNUM=1;
EXCEPTION 
WHEN OTHERS THEN 
  insert into dbo_tc.COMPANY (
						PARTY_ID,
						COMPANY_NAME,
						TYPE,
						FEDERAL_TAX_ID,
						STATE_TAX_ID,
						VAT_REG_ID
					)  
					VALUES
						(P_PARTY_ID,
						P_COMPANY_NAME,
						NULL,
						NULL,
						NULL,
						NULL
					);
END;
EXCEPTION 
  WHEN OTHERS THEN
         
		  V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting agency data to company  table'||P_PARTY_ID,V_ERROR); 
		END;
--COMPANY_OCCUPATION
PROCEDURE COMPANY_OCCUPATION(P_PARTY_ID IN NUMBER,P_AGENCY_ID IN NUMBER)
AS
V_PROP_ID NUMBER;
V_CONTCOMPANY_OCCUPATION NUMBER;
V_AGENCY_TYPE_VALUE VARCHAR2(200);
V_COMPANY_OCCUPATION NUMBER;
BEGIN
BEGIN
	SELECT MAPPED_VALUE
	INTO V_AGENCY_TYPE_VALUE
	FROM FC_SOURCE.CODES_AGENCYTYPE_MAP
	WHERE AGENCYTYPEID=P_AGENCY_ID
	AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	V_AGENCY_TYPE_VALUE:=NULL;
END ;
--
BEGIN
select FC_SOURCE.FC_MAP_PKG.GET_SYSPROP_VALUE('COMPANY_OCCUPATION', V_AGENCY_TYPE_VALUE) 
INTO V_PROP_ID
FROM DUAL; 
END;


BEGIN
		SELECT occupation_id
		INTO V_COMPANY_OCCUPATION
		FROM dbo_tc.occupation
		WHERE PARTY_ID=P_PARTY_ID
		AND OCCU_NAME_ID=V_PROP_ID
		AND ROWNUM=1;
EXCEPTION 
WHEN OTHERS THEN 
  insert into dbo_tc.OCCUPATION (
						occupation_id,
						PARTY_ID,
						OCCU_NAME_ID
						)  
						VALUES
							(DBO_TC.SEQ_OCCUPATION_ID.NEXTVAL,
							P_PARTY_ID,
							V_PROP_ID
						);
END;
COMMIT;
EXCEPTION 
  WHEN OTHERS THEN
--
		  	  V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting agency data to occupation  table'||P_PARTY_ID,V_ERROR);
		END;
		
		--AKA INSERT
	PROCEDURE PARTY_AKA_INSERT( P_PARTY_ID IN NUMBER,P_AGENCYNAME IN VARCHAR2)
	AS
	BEGIN
		INSERT INTO DBO_TC.PARTY_AKA
				(ID,
				PARTY_ID,
				AKA_NAME ,
				AKA_IND ,
				FIRST_NAME, 
				LAST_NAME,
				LAST_UPDATED_USER,
				LAST_UPDATED_TS,
				IS_CURRENT)
		VALUES
			(	DBO_TC.SEQ_PARTY_AKA_ID.NEXTVAL,
				P_PARTY_ID,
				TRIM(P_AGENCYNAME),
				'N',
				NULL,
				TRIM(P_AGENCYNAME),
				'c2cdm',
				SYSDATE,
				'Y');
--
	COMMIT;
--		

	EXCEPTION 
	WHEN OTHERS THEN
          V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting agency data to party_aka  table'||P_PARTY_ID,V_ERROR);
	END;
--

FUNCTION create_party(p_display_name IN VARCHAR2)
RETURN NUMBER
AS
v_cont_party_id NUMBER;
--
		 BEGIN
          SELECT dbo_tc.seq_party_id.nextval INTO v_cont_party_id FROM dual;
         --
          INSERT
          INTO dbo_tc.party
            (
              party_id ,
              party_type ,
              display_name ,
			  ta_display_name,
              created_by,
              created_date,
              updated_by,
              updated_date,
              updated_by_app,
              created_by_app,
			  dataset_id
            )
            VALUES
            (
              v_cont_party_id,
              'COMPANY' ,
              trim(p_display_name) ,
              lower(p_display_name),
              'c2cdm' ,
              SYSDATE ,
              'c2cdm' ,
              SYSDATE ,
              360 ,
              360,
			  '4342'
            );
			RETURN v_cont_party_id;
        EXCEPTION
        WHEN OTHERS THEN
           V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting agency data to party  table'||p_display_name,V_ERROR);

		  RETURN NULL;
	END;
--
	BEGIN
			FOR I IN C_AGENCY
			LOOP
			--create party
			BEGIN
	
				SELECT PARTY_ID
				INTO v_party_id
				FROM DBO_TC.PARTY
				WHERE upper(trim(display_name)) = upper(trim(I.COMPANY_NAME))
				AND PARTY_TYPE ='COMPANY'
				AND ROWNUM                =1;
			EXCEPTION	
				WHEN OTHERS THEN 
					v_party_id:=create_party(trim(I.COMPANY_NAME));
			END;
			--updating staging table with party_id
				UPDATE FC_SOURCE.fc_agency_staging
				SET PARTY_ID=NVL(v_party_id,0)
				WHERE agency_id=i.agency_id;
				--update occupation
				COMPANY_OCCUPATION(v_party_id,i.AGENCY_TYPE_ID);
			--CREATE PARTY CONTACT
			v_contact_id:=CREATE_PARTY_COMPANY(v_party_id,i.address_line1, i.address_line2, i.address_line3, i.city, i.state1, i.zip,i.country);			--
			--PERSON_CONTACT_INSERT
			PERSON_COMPANY_INSERT(v_party_id,I.COMPANY_NAME);
			--AKA INSERT
			 PARTY_AKA_INSERT( v_party_id,I.COMPANY_NAME);
			
			--PROC_CONTACT_EMAIL
      IF i.EMAIL_ADDRESS is NOT NULL THEN
			PROC_CONTACT_EMAIL(V_PARTY_ID,'Email','Y',I.EMAIL_ADDRESS);
      END IF;
			--
			BEGIN 
			IF i.phone1 is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Work 1',I.phone1,v_contact_id);
			END IF;
			--
			IF i.phone2 is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Work 2',I.phone2,v_contact_id);
			END IF;
			--
			IF i.fax is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Work Fax',I.fax,v_contact_id);
			END IF;
				END;
				COMMIT;
				END LOOP;
END;
/

