DECLARE
V_SCRIPT_ID 	VARCHAR2(10) := 'V0.0017';
V_ERROR     	VARCHAR2(4000);
V_PC_AD_COUNT 	NUMBER;

V_COUNTRY_ID 	NUMBER;
V_PC_EM_COUNT   NUMBER;
V_PHTYPE        NUMBER;
V_EMTYPE		NUMBER;
V_CONTACT_ID	NUMBER;
V_ADDRESS_ID	NUMBER;
--PHONE INSERT
--
CURSOR C1 IS 
SELECT DISTINCT FC_SOURCE.FC_MAP_PKG.GET_C2_PRODCOMPANY(PRODUCTIONID) COMPANY_ID,
		SEQUENCENUM,
		ADDRESSLINE1,
		ADDRESSLINE2,
		ADDRESSLINE3,
		CITY,
		STATEPROV,
		ZIP,
		COUNTRYID,
		FC_SOURCE.FC_MAP_PKG.GET_C2_COUNTRY_ID(L.COUNTRYID) COUNTRYCODE,
		PHONE,
		FAX,
		HOTELPHONE,
		HOTELFAX,
		FOREIGNPHONE,
		OTHERPHONE,
		EMAILADDRESS,
			   PRODUCTIONID,
       FC_SOURCE.FC_MAP_PKG.GET_C2_PROJECT(PRODUCTIONID) PROJECT_ID,
       LOCATION,
	   TO_DATE(FROMDATE,'MM/DD/RRRR') FROMDATE,
	   TO_DATE(TODATE,'MM/DD/RRRR') TODATE 
  FROM FC_SOURCE.LOCATION L
 WHERE FC_SOURCE.FC_MAP_PKG.GET_C2_PROJECT(PRODUCTIONID) IS NOT NULL
   AND FC_SOURCE.FC_MAP_PKG.GET_C2_PRODCOMPANY(PRODUCTIONID) IS NOT NULL;

   --
PROCEDURE PROC_PHONE_INSERT(P_COMPANY_ID IN NUMBER,P_PHTYPE IN NUMBER,P_PHONE_NO IN VARCHAR2) AS
V_PC_PH_COUNT	NUMBER;
--
BEGIN
BEGIN ---- PHONE insert -------------------------------------------------------------------------------------------
				SELECT COUNT(*)
				  INTO V_PC_PH_COUNT
				  FROM DBO_TC.PARTY_CONTACT
				 WHERE PARTY_ID = P_COMPANY_ID
				   AND PRIMARY_FLAG = 'Y'
				   AND CONTACT_TYPE = 'PHONE';			
				-------
				SELECT DBO_TC.SEQ_CONTACT_ID.NEXTVAL
				INTO V_CONTACT_ID
				FROM DUAL;
				--
				IF V_PC_PH_COUNT = 0 THEN
					INSERT INTO DBO_TC.PARTY_CONTACT
								(CONTACT_ID,
								PARTY_ID,
								CONTACT_TYPE,
								PRIMARY_FLAG,
								CREATED_BY,
								CREATED_DATE,
								UPDATED_BY,
								UPDATE_DATE,
								UPDATED_BY_APP )
						VALUES
							  (	V_CONTACT_ID,
								P_COMPANY_ID,
								'PHONE',
								'Y',
								'c2cdm',
								SYSDATE,
								'c2cdm',
								SYSDATE,
								NULL );
				ELSE
					INSERT INTO DBO_TC.PARTY_CONTACT
								(CONTACT_ID,
								PARTY_ID,
								CONTACT_TYPE,
								PRIMARY_FLAG,
								CREATED_BY,
								CREATED_DATE,
								UPDATED_BY,
								UPDATE_DATE,
								UPDATED_BY_APP )
						VALUES
							  (	V_CONTACT_ID,
								P_COMPANY_ID,
								'PHONE',
								'N',
								'c2cdm',
								SYSDATE,
								'c2cdm',
								SYSDATE,
								NULL );
					
				END IF;
		EXCEPTION
					WHEN OTHERS THEN
					V_ERROR := SUBSTR(SQLERRM,1,3000);
					INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,NULL,NULL,V_ERROR);
		END;
		
		
BEGIN
			INSERT INTO DBO_TC.PHONE (PHONE_ID,
												CONTACT_ID,
												PHONE_TYPE,
												PHONE_NO)
										VALUES(DBO_TC.SEQ_PHONE_ID.NEXTVAL,
											   V_CONTACT_ID,
											   P_PHTYPE,
											   P_PHONE_NO);
											   
											   
											   
END;
EXCEPTION
					WHEN OTHERS THEN
					V_ERROR := SUBSTR(SQLERRM,1,3000);
					INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,NULL,NULL,V_ERROR);
END;	
------------------

--EMAIL INSERT
PROCEDURE PROC_CONTACT_EMAIL(P_PARTY_ID IN NUMBER,
P_EMAIL_TYPE IN VARCHAR2,
P_EMAIL IN VARCHAR2) 
AS
v_contact_id NUMBER;
v_email_id NUMBER;
V_PROP_ID NUMBER;
BEGIN
--
BEGIN 
v_contact_id:=NULL;
v_email_id:=NULL;
V_PROP_ID:=NULL;
--
				SELECT DBO_TC.SEQ_CONTACT_ID.NEXTVAL
				INTO v_contact_id
				FROM DUAL;
				----------
				SELECT COUNT(*)
				  INTO V_PC_EM_COUNT
				  FROM DBO_TC.PARTY_CONTACT
				 WHERE PARTY_ID = P_PARTY_ID
				   AND PRIMARY_FLAG = 'Y'
				   AND CONTACT_TYPE = 'EMAIL';			
			     -----------
				 ---------
				IF V_PC_EM_COUNT = 0 THEN
					-- 
					INSERT INTO DBO_TC.PARTY_CONTACT
								(CONTACT_ID,
								PARTY_ID,
								CONTACT_TYPE,
								PRIMARY_FLAG,
								CREATED_BY,
								CREATED_DATE,
								UPDATED_BY,
								UPDATE_DATE,
								UPDATED_BY_APP )
						VALUES
							  (	v_contact_id,
								P_PARTY_ID,
								'EMAIL',
								'Y',
								'c2cdm',
								SYSDATE,
								'c2cdm',
								SYSDATE,
								NULL );
				ELSE
					INSERT INTO DBO_TC.PARTY_CONTACT
								(CONTACT_ID,
								PARTY_ID,
								CONTACT_TYPE,
								PRIMARY_FLAG,
								CREATED_BY,
								CREATED_DATE,
								UPDATED_BY,
								UPDATE_DATE,
								UPDATED_BY_APP )
						VALUES
							  (	v_contact_id,
								P_PARTY_ID,
								'EMAIL',
								'N',
								'c2cdm',
								SYSDATE,
								'c2cdm',
								SYSDATE,
								NULL );
					
				END IF;
	--
	BEGIN
		SELECT SPV.PROP_ID
		INTO V_PROP_ID
		FROM DBO_TC.SYS_PROPERTY SP,
			 DBO_TC.SYS_PROP_VALUE SPV
		WHERE SP.SYS_PROP_ID=SPV.SYS_PROP_ID
		AND SP.SYS_PROP_NAME LIKE 'SOCIAL_MEDIA'
		AND spv.prop_value=P_EMAIL_TYPE
		AND ROWNUM=1;
	EXCEPTION
	WHEN OTHERS THEN
		V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Location :'||P_PARTY_ID,V_ERROR);	
		END;
	
	BEGIN
		select DBO_TC.SEQ_WEBCONTACT_ID.NEXTVAL 
		into v_email_id
		from dual;
--
	INSERT INTO DBO_TC.WEB_CONTACT ( 
						 WEBCONTACT_ID,CONTACT_ID,
                         CONTACT_TYPE,CONTACT_VALUE) VALUES 
					  (	v_email_id,
						v_contact_id,
						V_PROP_ID,
						P_EMAIL);
--					
	EXCEPTION
		WHEN OTHERS THEN
				V_ERROR := 'Error in inserting data to web table for party'||SUBSTR(SQLERRM,1,3000);
					INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,NULL,NULL,V_ERROR);
			--
	END;
END;
		
EXCEPTION
					WHEN OTHERS THEN
					V_ERROR := SUBSTR(SQLERRM,1,3000);
					INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,NULL,NULL,V_ERROR);
END;				
--

--
BEGIN
	FOR I IN C1
	LOOP
	BEGIN
	--------------------------
	IF I.PROJECT_ID IS NOT NULL THEN
		
	---------------------------
		BEGIN
			BEGIN ---- Address insert -----------------------------------------------------------------------------------------
				SELECT COUNT(*)
				  INTO V_PC_AD_COUNT
				  FROM DBO_TC.PARTY_CONTACT
				 WHERE PARTY_ID = I.COMPANY_ID
				   AND PRIMARY_FLAG = 'Y'
				   AND CONTACT_TYPE = 'ADDRESS';			
				------
				/*IF I.COUNTRY_NAME IS NOT NULL
				THEN 
				BEGIN
				SELECT PROP_ID
				  INTO V_COUNTRY_ID
				  FROM DBO_TC.SYS_PROP_VALUE SPV,
					   DBO_TC.SYS_PROPERTY SP
				 WHERE SPV.SYS_PROP_ID = SP.SYS_PROP_ID
				   AND TRIM(UPPER(PROP_VALUE)) = TRIM(UPPER(I.COUNTRY_NAME));
				EXCEPTION
				WHEN OTHERS THEN
				V_COUNTRY_ID:=NULL;
				V_ERROR := SUBSTR(SQLERRM,1,3000);
				INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,NULL,'Error in country :',I.COMPANY_ID||' '||V_ERROR);	
			END; 
			END IF;	*/		
				-----------------------------------------------------------------
				IF V_PC_AD_COUNT = 0 THEN
					-- Address
					INSERT INTO DBO_TC.PARTY_CONTACT
								(CONTACT_ID,
								PARTY_ID,
								CONTACT_TYPE,
								PRIMARY_FLAG,
								CREATED_BY,
								CREATED_DATE,
								UPDATED_BY,
								UPDATE_DATE,
								UPDATED_BY_APP )
						VALUES
							  (	DBO_TC.SEQ_CONTACT_ID.NEXTVAL,
								I.COMPANY_ID,
								'ADDRESS',
								'Y',
								'c2cdm',
								SYSDATE,
								'c2cdm',
								SYSDATE,
								NULL );
				ELSE
					INSERT INTO DBO_TC.PARTY_CONTACT
								(CONTACT_ID,
								PARTY_ID,
								CONTACT_TYPE,
								PRIMARY_FLAG,
								CREATED_BY,
								CREATED_DATE,
								UPDATED_BY,
								UPDATE_DATE,
								UPDATED_BY_APP )
						VALUES
							  (	DBO_TC.SEQ_CONTACT_ID.NEXTVAL,
								I.COMPANY_ID,
								'ADDRESS',
								'N',
								'c2cdm',
								SYSDATE,
								'c2cdm',
								SYSDATE,
								NULL );
					
				END IF;
				--
				SELECT DBO_TC.SEQ_ADDRESS_ID.NEXTVAL
				INTO V_ADDRESS_ID FROM DUAL;
				--
					INSERT INTO DBO_TC.ADDRESS (ADDRESS_ID,
												CONTACT_ID,
												ADDRESS_TYPE,
												LOCATION_NAME,
												FIRST_LINE,
												SECOND_LINE,
												THIRD_LINE,
												CITY,
												STATE,
												ZIP,
												COUNTRY,
												STATE_ID)
										VALUES(V_ADDRESS_ID,
											   DBO_TC.SEQ_CONTACT_ID.CURRVAL,
											   'OFFICE',
											   I.LOCATION,
											   I.ADDRESSLINE1,
											   I.ADDRESSLINE2,
											   I.ADDRESSLINE3,
											   I.CITY,
											   I.STATEPROV,
											   I.ZIP,
											   I.COUNTRYCODE,
											   FC_SOURCE.FC_MAP_PKG.GET_C2_STATE_ID(I.STATEPROV));
				
			
			END; -- Address insert ends
			--INSERT INTO PROJECT_LOCATION
			BEGIN
			INSERT INTO DBO_MP.PROJECT_LOCATION (ID,
												START_DATE,
												END_DATE,
												CREATED_BY,
												UPDATE_DATE,
												CREATE_DATE,
												UPDATED_BY,
												PROJECT_ID,
												ADDRESS_ID
												)
										 VALUES(DBO_MP.PROJECT_LOCATION_ID_SEQ.NEXTVAL,
												I.FROMDATE,
												I.TODATE,
												'c2cdm',
												SYSDATE,
												SYSDATE,
												'c2cdm',
												I.PROJECT_ID,
												V_ADDRESS_ID);
			--			
		END;
		--END OF INSERT
			
					IF I.PHONE IS NOT NULL THEN
						V_PHTYPE :=  FC_SOURCE.FC_MAP_PKG.GET_SYSPROP_VALUE('PHONE_TYPE', 'Work 1');
						PROC_PHONE_INSERT(I.COMPANY_ID,V_PHTYPE,I.PHONE);
					END IF;
					IF I.FAX IS NOT NULL THEN
						V_PHTYPE :=  FC_SOURCE.FC_MAP_PKG.GET_SYSPROP_VALUE('PHONE_TYPE', 'Work Fax');
						PROC_PHONE_INSERT(I.COMPANY_ID,V_PHTYPE,I.FAX);
					END IF;
					IF I.HOTELPHONE IS NOT NULL THEN
						V_PHTYPE :=  FC_SOURCE.FC_MAP_PKG.GET_SYSPROP_VALUE('PHONE_TYPE', 'Work 2');
					PROC_PHONE_INSERT(I.COMPANY_ID,V_PHTYPE,I.HOTELPHONE);
					END IF;
					IF I.HOTELFAX IS NOT NULL THEN
						V_PHTYPE :=  FC_SOURCE.FC_MAP_PKG.GET_SYSPROP_VALUE('PHONE_TYPE', 'Home Fax');
						PROC_PHONE_INSERT(I.COMPANY_ID,V_PHTYPE,I.HOTELFAX);
					END IF;
					IF I.FOREIGNPHONE IS NOT NULL THEN
						V_PHTYPE :=  FC_SOURCE.FC_MAP_PKG.GET_SYSPROP_VALUE('PHONE_TYPE', 'Foreign');
						PROC_PHONE_INSERT(I.COMPANY_ID,V_PHTYPE,I.FOREIGNPHONE);
					END IF;
						IF I.OTHERPHONE IS NOT NULL THEN
						V_PHTYPE :=  FC_SOURCE.FC_MAP_PKG.GET_SYSPROP_VALUE('PHONE_TYPE', 'Other');
						PROC_PHONE_INSERT(I.COMPANY_ID,V_PHTYPE,I.OTHERPHONE);
					END IF;	
					EXCEPTION
				WHEN OTHERS THEN
				V_ERROR := SUBSTR(SQLERRM,1,3000);
				INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Phone :',I.COMPANY_ID||' '||V_ERROR);	
			END; --
					
		-- phone insert ends 
      IF I.EMAILADDRESS IS NOT NULL
      THEN
			BEGIN ---- Email insert -----------------------------------------------------------------------------------------
				PROC_CONTACT_EMAIL(I.COMPANY_ID,'Email',I.EMAILADDRESS);			
			EXCEPTION
				WHEN OTHERS THEN
				V_ERROR := SUBSTR(SQLERRM,1,3000);
				INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,NULL,'Email :',I.COMPANY_ID||' '||V_ERROR);	
			END; -- Email insert ends
      END IF;
--
	ELSE			
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'No project for :'||I.PRODUCTIONID,V_ERROR);
		
	END IF;--IF PROJECT ID IS NOT NULL
	EXCEPTION
				WHEN OTHERS THEN
				V_ERROR := SUBSTR(SQLERRM,1,3000);
				INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Phone :',I.COMPANY_ID||' '||V_ERROR);	
			END; --
	END LOOP;	

EXCEPTION
WHEN OTHERS THEN
	V_ERROR := SUBSTR(SQLERRM,1,3000);
	DBMS_OUTPUT.PUT_LINE('Error in :'||V_SCRIPT_ID||' '||V_ERROR);
	INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Outer Block',V_ERROR);
END;
/
