DECLARE
V_SCRIPT_ID 	VARCHAR2(10) := 'V0.1.0_028';
V_ERROR     	VARCHAR2(4000);
V_PG_ID			NUMBER;
V_SG_ID			NUMBER;
V_PG_PARTY_ID   NUMBER;
V_SG_PARTY_ID   NUMBER;
v_party_id      number;
--
CURSOR C1 IS 
 SELECT P.PERFORMERID,
		FC_SOURCE.FC_MAP_PKG.GET_C2_PER_PARTY(P.PERFORMERID) PARTY_ID,
		PRIMARYGUARDIAN,
		PRIMARYGUARDDESC,
		SECONDGUARDIAN,
		SECONDGUARDDESC
   FROM FC_SOURCE.PERFORMER P
  WHERE FC_SOURCE.FC_MAP_PKG.GET_C2_PER_PARTY(P.PERFORMERID) IS NOT NULL
  AND (PRIMARYGUARDIAN IS NOT NULL OR SECONDGUARDIAN IS NOT NULL)
;
--
BEGIN
	FOR I IN C1
	LOOP
		BEGIN	
			IF I.PRIMARYGUARDIAN IS NOT NULL THEN
				BEGIN
					SELECT PARTY_ID
					  INTO V_PG_ID
					  FROM DBO_TC.PARTY
					 WHERE PARTY_TYPE = 'CONTACT'
					   AND UPPER(TRIM(DISPLAY_NAME)) = UPPER(TRIM(I.PRIMARYGUARDIAN))
					   AND ROWNUM =1;
					 
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						V_PG_ID := NULL;
					WHEN OTHERS THEN
						V_PG_ID := NULL;
						V_ERROR := SUBSTR(SQLERRM,1,3000);
						DBMS_OUTPUT.PUT_LINE('Issue finding PG :'||V_SCRIPT_ID||' '||V_ERROR);
						INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'PG Issue :',V_ERROR);
				END;
			END IF;
			----
			IF I.SECONDGUARDIAN IS NOT NULL THEN
				BEGIN
					SELECT PARTY_ID
					  INTO V_SG_ID
					  FROM DBO_TC.PARTY
					 WHERE PARTY_TYPE = 'CONTACT'
					   AND UPPER(TRIM(DISPLAY_NAME)) = UPPER(TRIM(I.SECONDGUARDIAN))
					   AND ROWNUM =1;
				EXCEPTION
				WHEN NO_DATA_FOUND THEN
					V_SG_ID := NULL;
				WHEN OTHERS THEN
					V_SG_ID := NULL;
					V_ERROR := SUBSTR(SQLERRM,1,3000);
					DBMS_OUTPUT.PUT_LINE('Issue finding PG :'||V_SCRIPT_ID||' '||V_ERROR);
					INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'SG Issue :',V_ERROR);
				END;
			END IF;
			---- Inserting Primary guardian
			IF V_PG_ID IS NULL AND I.PRIMARYGUARDIAN IS NOT NULL THEN
				V_PG_PARTY_ID :=  DBO_TC.SEQ_PARTY_ID.NEXTVAL;
				INSERT INTO DBO_TC.PARTY
							(PARTY_ID,
							PARTY_TYPE,
							DISPLAY_NAME,
							CREATED_BY,
							CREATED_DATE,
							TA_DISPLAY_NAME,
							DATASET_ID,
							UPDATED_BY_APP,
							CREATED_BY_APP)
						VALUES
							(V_PG_PARTY_ID,
							'CONTACT',
							TRIM(INITCAP(I.PRIMARYGUARDIAN)),
							'c2cdm',
							SYSDATE,
							LOWER(I.PRIMARYGUARDIAN),
							NULL,
							360,
							360);
							COMMIT;
				-----
				/*INSERT INTO DBO_TC.PARTY_AKA
							(ID,
							 PARTY_ID,
							AKA_NAME,
							AKA_IND,
							LAST_NAME,
							LAST_UPDATED_USER,
							LAST_UPDATED_TS,
							IS_CURRENT)
						VALUES
							(DBO_TC.SEQ_PARTY_AKA_ID.NEXTVAL,
							V_PG_PARTY_ID,
							TRIM(INITCAP(I.PRIMARYGUARDIAN)),
							'N',
							TRIM(INITCAP(I.PRIMARYGUARDIAN)),
							'c2cdm',
							SYSDATE,
							'Y');*/
								COMMIT;
				------
				INSERT INTO DBO_TC.PERSON
				  (	PARTY_ID,
					FIRST_NAME,
					LAST_NAME )	
				VALUES (V_PG_PARTY_ID,
					NULL,
					TRIM(INITCAP(I.PRIMARYGUARDIAN)));
				---
		
			-----
			INSERT INTO DBO_TC.PARTY_RELATION (PARENT_ID,
											   CHILD_ID,
											   RELATION_TYPE,
											   PARTY_RELATION_ID,
											   PRIMARY_FLAG,
											   RELATION_NAME,
											   RELATION_CREATED_ON,
											   UPDATED_BY_APP)
										VALUES (I.PARTY_ID,
												NVL(V_PG_ID,V_PG_PARTY_ID),
												'TALENT_GUARDIAN',
												DBO_TC.SEQ_PARTY_RELATION_ID.NEXTVAL,
												'Y',
												I.PRIMARYGUARDDESC,
												SYSDATE,
												360);
													COMMIT;
				END IF;
			-------------------------------------------------------------------------------------------------------------------
			-- Inserting Secondary Guardian
			IF V_SG_ID IS NULL AND I.SECONDGUARDIAN IS NOT NULL THEN
				V_SG_PARTY_ID :=  DBO_TC.SEQ_PARTY_ID.NEXTVAL;
				INSERT INTO DBO_TC.PARTY
							(PARTY_ID,
							PARTY_TYPE,
							DISPLAY_NAME,
							CREATED_BY,
							CREATED_DATE,
							TA_DISPLAY_NAME,
							DATASET_ID,
							UPDATED_BY_APP,
							CREATED_BY_APP)
						VALUES
							(V_SG_PARTY_ID,
							'CONTACT',
							TRIM(INITCAP(I.SECONDGUARDIAN)),
							'c2cdm',
							SYSDATE,
							LOWER(I.SECONDGUARDIAN),
							NULL,
							360,
							360);
								COMMIT;
				-----------------------------
				INSERT INTO DBO_TC.PARTY_AKA
							(ID,
							 PARTY_ID,
							AKA_NAME,
							AKA_IND,
							LAST_NAME,
							LAST_UPDATED_USER,
							LAST_UPDATED_TS,
							IS_CURRENT)
						VALUES
							(DBO_TC.SEQ_PARTY_AKA_ID.NEXTVAL,
							V_SG_PARTY_ID,
							TRIM(INITCAP(I.SECONDGUARDIAN)),
							'N',
							TRIM(INITCAP(I.SECONDGUARDIAN)),
							'c2cdm',
							SYSDATE,
							'Y');
				----
				INSERT INTO DBO_TC.PERSON
						(	PARTY_ID,
						FIRST_NAME,
						LAST_NAME )	
				VALUES (V_SG_PARTY_ID,
						NULL,
						TRIM(INITCAP(I.SECONDGUARDIAN)));
				-----------------------------
				INSERT INTO DBO_TC.CONTACT  (PARTY_ID) VALUES (V_SG_PARTY_ID);
					COMMIT;
				-----------
			END IF;
			INSERT INTO DBO_TC.PARTY_RELATION (PARENT_ID,
											   CHILD_ID,
											   RELATION_TYPE,
											   PARTY_RELATION_ID,
											   PRIMARY_FLAG,
											   RELATION_NAME,
											   RELATION_CREATED_ON,
											   UPDATED_BY_APP)
										VALUES (I.PARTY_ID,
												NVL(V_SG_ID,V_SG_PARTY_ID),
												'TALENT_GUARDIAN',
												DBO_TC.SEQ_PARTY_RELATION_ID.NEXTVAL,
												'N',
												I.SECONDGUARDDESC,
												SYSDATE,
												360);
													COMMIT;
			-------------------------------------------------------------------------------------------------------------------
			---- SG insert ends
		EXCEPTION 
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES (FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Loop',I.PERFORMERID||' '||V_ERROR);	
		END;
		COMMIT;
	END LOOP;

EXCEPTION
WHEN OTHERS THEN
	V_ERROR := SUBSTR(SQLERRM,1,3000);
	DBMS_OUTPUT.PUT_LINE('Error in :'||V_SCRIPT_ID||' '||V_ERROR);
	INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Outer Exception',V_ERROR);
END;
/
COMMIT;
/