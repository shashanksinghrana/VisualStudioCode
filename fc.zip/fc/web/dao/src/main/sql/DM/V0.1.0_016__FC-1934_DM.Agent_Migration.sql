DECLARE
V_SCRIPT_ID VARCHAR2(10) :='1.00.121';
--
v_party_id NUMBER;
V_ERROR VARCHAR2(4000);
--CREATE 
CURSOR C_AGENT IS
SELECT *
FROM FC_SOURCE.FC_AGENT_STAGING
WHERE  PARTY_ID IS NULL;
--

--CREATE_PARTY_CONTACT
PROCEDURE CREATE_PARTY_CONTACT(P_PARTY_ID IN NUMBER)
IS
V_CONTACT_ID NUMBER;
v_ADDRESS_id NUMBER;
BEGIN
V_CONTACT_ID:=NULL;
v_ADDRESS_id:=NULL;
SELECT CONTACT_ID 
INTO v_contact_id
FROM dbo_tc.PARTY_CONTACT
WHERE PARTY_ID=P_PARTY_ID
AND CONTACT_TYPE='ADDRESS'
AND PRIMARY_FLAG='Y'
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	BEGIN
		select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		Insert into DBO_TC.party_contact (CONTACT_ID,PARTY_ID,CONTACT_TYPE,PRIMARY_FLAG,CREATED_BY,CREATED_DATE,UPDATED_BY,UPDATE_DATE,	UPDATED_BY_APP) values 
		(v_contact_id,P_PARTY_ID,'ADDRESS','Y','c2cdm',SYSDATE,'c2cdm',SYSDATE,401);
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to party_contact_table for Suite Address',V_ERROR); 
	END;
	--
BEGIN
SELECT ADDRESS_ID
INTO v_ADDRESS_id
FROM DBO_TC.ADDRESS
WHERE contact_id=v_contact_id
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	BEGIN
		select DBO_TC.SEQ_ADDRESS_ID.NEXTVAL 
		into v_ADDRESS_id
		from dual;
--	
	INSERT INTO DBO_TC.ADDRESS (  ADDRESS_ID,CONTACT_ID,
                         LOCATION_NAME,ADDRESS_TYPE,
                         FIRST_LINE,SECOND_LINE,CITY,
                         STATE,ZIP,COUNTRY) VALUES 
		(	v_ADDRESS_id,
			v_contact_id,
			NULL,
			'Suite',
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			null);
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to address table for agent',V_ERROR); 
	END;
END;
commit;
--insert Home Address
BEGIN
v_contact_id:=NULL;
SELECT CONTACT_ID 
INTO v_contact_id
FROM DBO_TC.PARTY_CONTACT
WHERE PARTY_ID=P_PARTY_ID
AND CONTACT_TYPE='ADDRESS'
AND (PRIMARY_FLAG IS NULL OR PRIMARY_FLAG='N')
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	BEGIN
		select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		Insert into DBO_TC.party_contact (CONTACT_ID,PARTY_ID,CONTACT_TYPE,PRIMARY_FLAG,CREATED_BY,CREATED_DATE,UPDATED_BY,UPDATE_DATE,	UPDATED_BY_APP) values 
		(v_contact_id,P_PARTY_ID,'ADDRESS','N','c2cdm',SYSDATE,'c2cdm',SYSDATE,null);
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to address table for agent home adress',V_ERROR); 
	END;
END;
BEGIN
SELECT ADDRESS_ID
INTO v_ADDRESS_id
FROM DBO_TC.ADDRESS
WHERE contact_id=v_contact_id
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	BEGIN
		select DBO_TC.SEQ_ADDRESS_ID.NEXTVAL 
		into v_ADDRESS_id
		from dual;
--	
	INSERT INTO DBO_TC.ADDRESS (  ADDRESS_ID,CONTACT_ID,
                         LOCATION_NAME,ADDRESS_TYPE,
                         FIRST_LINE,SECOND_LINE,CITY,
                         STATE,ZIP,COUNTRY) VALUES 
		(	v_ADDRESS_id,
			v_contact_id,
			NULL,
			'Home',
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			null);
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to address table',V_ERROR); 
	END;
END;
END;
--PROC_CONTACT_PHONE
PROCEDURE PROC_CONTACT_PHONE(P_PARTY_ID IN NUMBER,
P_PHONE_TYPE IN VARCHAR2,
P_PRIMARY_FLAG IN VARCHAR2,
P_PHONE_NO IN VARCHAR2) 
AS
v_contact_phone_id NUMBER;
v_phone_id NUMBER;
V_PROP_ID NUMBER;
BEGIN
--
BEGIN 
v_contact_phone_id:=NULL;
v_phone_id:=NULL;
V_PROP_ID:=NULL;
--
select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_phone_id
		from dual;
--
		INSERT INTO DBO_TC.PARTY_CONTACT (CONTACT_ID,
                              PARTY_ID,
                              CONTACT_TYPE,
                              PRIMARY_FLAG,
                              CREATED_BY,
                              CREATED_DATE,
                              UPDATED_BY,
                              UPDATE_DATE,	
                              UPDATED_BY_APP) values 
                              (v_contact_phone_id,
                              p_party_id,
                              'PHONE',
                              p_primary_flag,
                              'c2cdm',
                              SYSDATE,
                              'c2cdm',
                              SYSDATE,
                              NULL
                             );
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to party contact table'||P_PARTY_ID,V_ERROR);
	END;
	commit;
	--
	BEGIN
		SELECT SPV.PROP_ID
		INTO V_PROP_ID
		FROM DBO_TC.SYS_PROPERTY SP,
			 DBO_TC.SYS_PROP_VALUE SPV
		WHERE SP.SYS_PROP_ID=SPV.SYS_PROP_ID
		AND SP.SYS_PROP_NAME LIKE 'PHONE_TYPE'
		AND spv.prop_value=P_PHONE_TYPE
		AND ROWNUM=1;
	EXCEPTION
	WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting phone type data to table for location1 phone1 for party'||P_PARTY_ID,V_ERROR);
	
		END;
	
	BEGIN
		select DBO_TC.SEQ_PHONE_ID.NEXTVAL 
		into v_phone_id
		from dual;
--
	INSERT INTO DBO_TC.PHONE ( 
						 PHONE_ID,CONTACT_ID,
                         PHONE_TYPE,PHONE_NO) VALUES 
					  (	v_phone_id,
						v_contact_phone_id,
						V_PROP_ID,
						P_PHONE_NO);
--					
	EXCEPTION
		WHEN OTHERS THEN
						V_ERROR := SUBSTR(SQLERRM,1,3000);
						INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to phone table for party'||P_PARTY_ID,V_ERROR);
	
	END;
END;
--EMAIL IMPORT
PROCEDURE PROC_CONTACT_EMAIL(P_PARTY_ID IN NUMBER,
P_EMAIL_TYPE IN VARCHAR2,
P_PRIMARY_FLAG IN VARCHAR2,
P_EMAIL IN VARCHAR2) 
AS
v_contact_id NUMBER;
v_email_id NUMBER;
V_PROP_ID NUMBER;
BEGIN
--
BEGIN 
v_contact_id:=NULL;
v_email_id:=NULL;
V_PROP_ID:=NULL;
--
select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		INSERT INTO DBO_TC.PARTY_CONTACT (CONTACT_ID,
                              PARTY_ID,
                              CONTACT_TYPE,
                              PRIMARY_FLAG,
                              CREATED_BY,
                              CREATED_DATE,
                              UPDATED_BY,
                              UPDATE_DATE,	
                              UPDATED_BY_APP) values 
                              (v_contact_id,
                              p_party_id,
                              'EMAIL',
                              p_primary_flag,
                              'c2cdm',
                              SYSDATE,
                              'c2cdm',
                              SYSDATE,
                              NULL
                             );
	EXCEPTION
		WHEN OTHERS THEN
						V_ERROR := SUBSTR(SQLERRM,1,3000);
						INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to party_contact_table for contact for email for'||P_PARTY_ID,V_ERROR);
			END;
	commit;
	--
	BEGIN
		SELECT SPV.PROP_ID
		INTO V_PROP_ID
		FROM DBO_TC.SYS_PROPERTY SP,
			 DBO_TC.SYS_PROP_VALUE SPV
		WHERE SP.SYS_PROP_ID=SPV.SYS_PROP_ID
		AND SP.SYS_PROP_NAME LIKE 'EMAIL'
		AND spv.prop_value=P_EMAIL_TYPE
		AND ROWNUM=1;
	EXCEPTION
	WHEN OTHERS THEN
		V_ERROR := SUBSTR(SQLERRM,1,3000);
		INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in getting data for Email'||P_PARTY_ID,V_ERROR); 
		END;
	
	BEGIN
		select DBO_TC.SEQ_WEBCONTACT_ID.NEXTVAL 
		into v_email_id
		from dual;
--
	INSERT INTO DBO_TC.WEB_CONTACT ( 
						 WEBCONTACT_ID,CONTACT_ID,
                         CONTACT_TYPE,CONTACT_VALUE) VALUES 
					  (	v_email_id,
						v_contact_id,
						V_PROP_ID,
						P_EMAIL);
--					
	EXCEPTION
		WHEN OTHERS THEN
		V_ERROR := SUBSTR(SQLERRM,1,3000);
		INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to web table for party'||P_PARTY_ID||P_EMAIL,V_ERROR); 
	END;
END;
--PARTY_PERSON_IMPORT
PROCEDURE PERSON_CONTACT_INSERT(P_PARTY_ID IN NUMBER,P_FIRST_NAME IN VARCHAR2,P_LAST_NAME IN VARCHAR2)
AS
V_PARTY_ID NUMBER;
V_CONTACT_ID NUMBER;
BEGIN

BEGIN
		SELECT PARTY_ID
		INTO V_PARTY_ID
		FROM DBO_TC.PERSON
		WHERE PARTY_ID=P_PARTY_ID
		AND ROWNUM=1;
EXCEPTION 
WHEN OTHERS THEN 
  insert into DBO_TC.person (
						PARTY_ID,
						FIRST_NAME,
						LAST_NAME,
						GENDER,
						RACE,
						DOB,
						SSN,
						SSN_END_CHARS
					)  
					VALUES
                    (P_PARTY_ID,
						P_FIRST_NAME,
						P_LAST_NAME,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL
					);
END;
--CONTACT
BEGIN
		SELECT PARTY_ID
		INTO V_CONTACT_ID
		FROM DBO_TC.CONTACT
		WHERE PARTY_ID=P_PARTY_ID
		AND ROWNUM=1;
EXCEPTION
		WHEN OTHERS THEN 
		insert into DBO_TC.CONTACT(PARTY_ID, 
							DESIGNATION, 
							TYPE, 
							NEVER_EMAIL_IND, 
							BUSINESS_PERSONAL, 
							DEPARTMENT_ID
							)  
						VALUES
							(P_PARTY_ID,
							NULL,
							NULL,
							NULL,
							NULL,
							NULL
							);
END;
EXCEPTION 
  WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting agent data to person contact table'||P_PARTY_ID,V_ERROR); 
          --
		END;
--
PROCEDURE PARTY_AKA_INSERT( P_PARTY_ID IN NUMBER,P_LAST_NAME IN VARCHAR2,P_FIRST_NAME IN VARCHAR2)
AS
BEGIN
		INSERT INTO DBO_TC.PARTY_AKA
				(ID,
				PARTY_ID,
				AKA_NAME ,
				AKA_IND ,
				FIRST_NAME, 
				LAST_NAME,
				LAST_UPDATED_USER,
				LAST_UPDATED_TS,
				IS_CURRENT)
		VALUES
			(	DBO_TC.SEQ_PARTY_AKA_ID.NEXTVAL,
				P_PARTY_ID,
				TRIM(P_FIRST_NAME)||' '||TRIM(P_LAST_NAME),
				'N',
				TRIM(P_FIRST_NAME),
				TRIM(P_LAST_NAME),
				'c2cdm',
				sysdate,
				'Y');
--
	COMMIT;
--		

	EXCEPTION 
	WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting agent data to p contact table'||P_PARTY_ID,V_ERROR); 
          --
	END;
	--
	FUNCTION create_party(p_display_name IN VARCHAR2)
RETURN NUMBER
AS
v_cont_party_id NUMBER;
--
		 BEGIN
          SELECT DBO_TC.seq_party_id.nextval INTO v_cont_party_id FROM dual;
         --
          INSERT
          INTO DBO_TC.party
            (
              party_id ,
              party_type ,
              display_name ,
				ta_display_name,
              created_by,
              created_date,
              updated_by,
              updated_date,
              updated_by_app,
              created_by_app,
              DATASET_ID
            )
            VALUES
            (
              v_cont_party_id,
              'CONTACT' ,
              trim(p_display_name) ,
              lower(p_display_name) ,
              'c2cdm' ,
              SYSDATE ,
              'c2cdm' ,
              SYSDATE ,
              '360' ,
              '360',
              '4342'
            );
			RETURN v_cont_party_id;
        EXCEPTION
        WHEN OTHERS THEN
				V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting agent data to table'||p_display_name,V_ERROR); 
          --FC_LOG_PRC('FC-PARTY','AGENT INSERT','Error in inserting agent data to table'||P_DISPLAY_NAME,SYSDATE);
		  RETURN NULL;
	END;
--FC_AGENT_IMPORT
--
	BEGIN
			FOR I IN C_AGENT
			LOOP
			--create party
			BEGIN	
					v_party_id:=create_party(trim(I.LAST_NAME||', '||I.FIRST_NAME||' '||I.MIDDLE_NAME));
			END;
			--updating staging table with party_id
				UPDATE FC_SOURCE.fc_agent_staging
				SET PARTY_ID=NVL(v_party_id,0)
				WHERE agent_id=i.agent_id;
				--
			--CREATE PARTY CONTACT
			CREATE_PARTY_CONTACT(v_party_id);
			--
			--PERSON_CONTACT_INSERT
			PERSON_CONTACT_INSERT(v_party_id,I.FIRST_NAME||' '||I.MIDDLE_NAME,I.LAST_NAME);
			--PARTY_AKA_INSERT
			PARTY_AKA_INSERT(v_party_id,trim(I.LAST_NAME),TRIM(I.FIRST_NAME||' '||I.MIDDLE_NAME));
			--PROC_CONTACT_EMAIL
      IF i.email is NOT NULL THEN
        PROC_CONTACT_EMAIL(V_PARTY_ID,'Work','Y',I.EMAIL);
      END IF;
      --
      IF i.email2 is NOT NULL THEN
        PROC_CONTACT_EMAIL(V_PARTY_ID,'Other','N',I.EMAIL2);
      END IF;
			--
			BEGIN 
			IF i.homephone is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Home 1','N',I.HOMEPHONE);
			END IF;
			IF i.homefax is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Home Fax','N',I.homefax);
			END IF;
			IF i.officephone is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Work 1','Y',I.officephone);
			END IF;
			IF i.pager is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Pager','N',I.pager);
			END IF;
			IF i.cell is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Cell 1','N',I.cell);
			END IF;
				END;
        COMMIT;
				END LOOP;
				END;

/