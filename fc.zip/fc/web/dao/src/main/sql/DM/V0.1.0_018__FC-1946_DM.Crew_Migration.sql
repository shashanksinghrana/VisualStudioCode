DECLARE
--VARIABLE DECLARATIONS
v_party_id NUMBER;
	V_SCRIPT_ID 	VARCHAR2(10) := 'V0.1.0_170';
  V_ERROR VARCHAR2(4000);
--CREATE 
CURSOR C_AGENT IS
SELECT *
FROM FC_SOURCE.FC_CREW_STAGING
WHERE PARTY_ID IS NULL;
--
--CREATE_PARTY_CONTACT
PROCEDURE CREATE_PARTY_CONTACT(P_PARTY_ID IN NUMBER,P_ADDRESSLINE1 IN VARCHAR2,P_ADDRESSLINE2 IN VARCHAR2,P_ADDRESSLINE3 IN VARCHAR2,P_CITY IN VARCHAR2,P_STATEPROV IN VARCHAR2,P_ZIP IN VARCHAR2,P_COUNTRYID IN VARCHAR2)
IS
V_CONTACT_ID NUMBER;
v_ADDRESS_id NUMBER;
BEGIN
V_CONTACT_ID:=NULL;
v_ADDRESS_id:=NULL;
BEGIN
SELECT CONTACT_ID 
INTO v_contact_id
FROM DBO_TC.PARTY_CONTACT
WHERE PARTY_ID=P_PARTY_ID
AND CONTACT_TYPE='ADDRESS'
AND PRIMARY_FLAG='Y'
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	BEGIN
		select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		Insert into DBO_TC.party_contact (CONTACT_ID,PARTY_ID,CONTACT_TYPE,PRIMARY_FLAG,CREATED_BY,CREATED_DATE,UPDATED_BY,UPDATE_DATE,	UPDATED_BY_APP) values 
		(v_contact_id,P_PARTY_ID,'ADDRESS','Y','c2cdm',SYSDATE,'c2cdm',SYSDATE,401);
	EXCEPTION
		WHEN OTHERS THEN
		V_ERROR := SUBSTR(SQLERRM,1,3000);
		INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to party_contact_table for Suite Address'||p_party_id,V_ERROR);
		END;
END;
COMMIT;
BEGIN
SELECT ADDRESS_ID
INTO v_ADDRESS_id
FROM DBO_TC.ADDRESS
WHERE contact_id=v_contact_id
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	BEGIN
		select DBO_TC.SEQ_ADDRESS_ID.NEXTVAL 
		into v_ADDRESS_id
		from dual;
--	
	INSERT INTO DBO_TC.ADDRESS (  ADDRESS_ID,CONTACT_ID,
                         LOCATION_NAME,ADDRESS_TYPE,
                         FIRST_LINE,SECOND_LINE,THIRD_LINE,CITY,
                         STATE,ZIP,COUNTRY) VALUES 
		(	v_ADDRESS_id,
			v_contact_id,
			NULL,
			'Suite',
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			null);
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to address table'||p_party_id,V_ERROR);
	END;
END;
commit;
v_contact_id:=NULL;
--insert Home Address
BEGIN
		select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		Insert into DBO_TC.party_contact (CONTACT_ID,PARTY_ID,CONTACT_TYPE,PRIMARY_FLAG,CREATED_BY,CREATED_DATE,UPDATED_BY,UPDATE_DATE,	UPDATED_BY_APP) values 
		(v_contact_id,P_PARTY_ID,'ADDRESS','N',401,SYSDATE,401,SYSDATE,null);
	EXCEPTION
		WHEN OTHERS THEN
			V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to party_contact_table for Home Address'||p_party_id,V_ERROR);
			--
	END;
--
BEGIN
SELECT ADDRESS_ID
INTO V_ADDRESS_ID
FROM DBO_TC.ADDRESS
WHERE contact_id=v_contact_id
AND ROWNUM=1;
EXCEPTION
WHEN OTHERS THEN 
	BEGIN
		select DBO_TC.SEQ_ADDRESS_ID.NEXTVAL 
		into v_ADDRESS_id
		from dual;
--	
	INSERT INTO DBO_TC.ADDRESS (  ADDRESS_ID,CONTACT_ID,
                         LOCATION_NAME,ADDRESS_TYPE,
                         FIRST_LINE,SECOND_LINE,THIRD_LINE,CITY,
                         STATE,ZIP,COUNTRY,STATE_ID) VALUES 
		(	v_ADDRESS_id,
			v_contact_id,
			NULL,
			'Home',
			P_ADDRESSLINE1,
			P_ADDRESSLINE2,
			P_ADDRESSLINE3,
			P_CITY,
			P_STATEPROV,
			P_ZIP,
			FC_SOURCE.FC_MAP_PKG.GET_C2_COUNTRY_ID(P_COUNTRYID),
			FC_SOURCE.FC_MAP_PKG.GET_C2_STATE_ID(P_STATEPROV)
      );
	EXCEPTION
		WHEN OTHERS THEN
				V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to address table  for Home Address'||p_party_id,V_ERROR);
	END;
END;
END;
--CREW OCCUPATION
PROCEDURE CREW_OCCUPATION(P_PARTY_ID IN NUMBER)
AS
V_PROP_ID NUMBER;
V_COMPANY_OCCUPATION NUMBER;
BEGIN
BEGIN
SELECT SPV.PROP_ID
		INTO V_PROP_ID
		FROM DBO_TC.SYS_PROPERTY SP,
			 DBO_TC.SYS_PROP_VALUE SPV
		WHERE SP.SYS_PROP_ID=SPV.SYS_PROP_ID
		AND SP.SYS_PROP_NAME LIKE 'CONTACT_OCCUPATION'
		AND spv.prop_value='Crew'
		AND ROWNUM=1;
END;


BEGIN
		SELECT occupation_id
		INTO V_COMPANY_OCCUPATION
		FROM DBO_TC.occupation
		WHERE PARTY_ID=P_PARTY_ID
		AND OCCU_NAME_ID=V_PROP_ID
		AND ROWNUM=1;
EXCEPTION 
WHEN OTHERS THEN 
  insert into DBO_TC.OCCUPATION (
						occupation_id,
						PARTY_ID,
						OCCU_NAME_ID
						)  
						VALUES
							(dbo_tc.SEQ_OCCUPATION_ID.NEXTVAL,
							P_PARTY_ID,
							V_PROP_ID
						);
END;
COMMIT;
EXCEPTION 
  WHEN OTHERS THEN
          V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to OCCUPATION table  for Home Address'||p_party_id,V_ERROR);
		END;
--PROC_CONTACT_PHONE
PROCEDURE PROC_CONTACT_PHONE(P_PARTY_ID IN NUMBER,
P_PHONE_TYPE IN VARCHAR2,
P_PHONE_NO IN VARCHAR2) 
AS
v_contact_phone_id NUMBER;
v_phone_id NUMBER;
V_PROP_ID NUMBER;
P_PRIMARY_FLAG VARCHAR2(100);
V_PRIMARY_FLAG VARCHAR2(100);
BEGIN
--
BEGIN 
v_contact_phone_id:=NULL;
v_phone_id:=NULL;
V_PROP_ID:=NULL;
P_PRIMARY_FLAG:=NULL;
V_PRIMARY_FLAG:=NULL;

BEGIN
		SELECT PRIMARY_FLAG
		INTO V_PRIMARY_FLAG
		FROM DBO_TC.PARTY_CONTACT
		WHERE PARTY_ID=P_PARTY_ID
		AND CONTACT_TYPE='PHONE'
		AND PRIMARY_FLAG='Y'
		AND ROWNUM=1;
		--
		IF V_PRIMARY_FLAG='Y'
		THEN 
			P_PRIMARY_FLAG:='N';
		ELSE 
			P_PRIMARY_FLAG:='Y';
		END IF;
			
	EXCEPTION
  WHEN OTHERS THEN 
		P_PRIMARY_FLAG:='Y';
	END;
--
select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_phone_id
		from dual;
--
		INSERT INTO DBO_TC.PARTY_CONTACT (CONTACT_ID,
                              PARTY_ID,
                              CONTACT_TYPE,
                              PRIMARY_FLAG,
                              CREATED_BY,
                              CREATED_DATE,
                              UPDATED_BY,
                              UPDATE_DATE,	
                              UPDATED_BY_APP) values 
                              (v_contact_phone_id,
                              p_party_id,
                              'PHONE',
                              p_primary_flag,
                              'c2cdm',
                              SYSDATE,
                              'c2cdm',
                              SYSDATE,
                              NULL
                             );
		END;
	commit;
	--
	BEGIN
		SELECT SPV.PROP_ID
		INTO V_PROP_ID
		FROM DBO_TC.SYS_PROPERTY SP,
			 DBO_TC.SYS_PROP_VALUE SPV
		WHERE SP.SYS_PROP_ID=SPV.SYS_PROP_ID
		AND SP.SYS_PROP_NAME LIKE 'PHONE_TYPE'
		AND spv.prop_value=trim(P_PHONE_TYPE)
		AND ROWNUM=1;
--
		END;
	
	BEGIN
		select DBO_TC.SEQ_PHONE_ID.NEXTVAL 
		into v_phone_id
		from dual;
--
	INSERT INTO DBO_TC.PHONE ( 
						 PHONE_ID,CONTACT_ID,
                         PHONE_TYPE,PHONE_NO) VALUES 
					  (	v_phone_id,
						v_contact_phone_id,
						V_PROP_ID,
						P_PHONE_NO);--					
	
	END;
	EXCEPTION
		WHEN OTHERS THEN
		 V_ERROR := SUBSTR(SQLERRM,1,3000);
			INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting phone data for party'||p_party_id,V_ERROR);
	END;
--EMAIL IMPORT
PROCEDURE PROC_CONTACT_EMAIL(P_PARTY_ID IN NUMBER,
P_EMAIL_TYPE IN VARCHAR2,
P_EMAIL IN VARCHAR2) 
AS
v_contact_id NUMBER;
v_email_id NUMBER;
V_PROP_ID NUMBER;
V_PRIMARY_FLAG VARCHAR2(10);
P_PRIMARY_FLAG VARCHAR2(10);
BEGIN
--
BEGIN 
v_contact_id:=NULL;
v_email_id:=NULL;
V_PROP_ID:=NULL;
V_PRIMARY_FLAG:=NULL;
P_PRIMARY_FLAG:=NULL;
BEGIN
		SELECT PRIMARY_FLAG
		INTO V_PRIMARY_FLAG
		FROM DBO_TC.PARTY_CONTACT
		WHERE PARTY_ID=P_PARTY_ID
		AND CONTACT_TYPE='EMAIL'
		AND PRIMARY_FLAG='Y'
		AND ROWNUM=1;
		--
		IF V_PRIMARY_FLAG='Y'
		THEN 
			P_PRIMARY_FLAG:='N';
		ELSE 
			P_PRIMARY_FLAG:='Y';
		END IF;
			
	EXCEPTION
  WHEN OTHERS THEN 
		P_PRIMARY_FLAG:='Y';
	END;
--
select DBO_TC.SEQ_CONTACT_ID.NEXTVAL 
		into v_contact_id
		from dual;
--
		INSERT INTO DBO_TC.PARTY_CONTACT (CONTACT_ID,
                              PARTY_ID,
                              CONTACT_TYPE,
                              PRIMARY_FLAG,
                              CREATED_BY,
                              CREATED_DATE,
                              UPDATED_BY,
                              UPDATE_DATE,	
                              UPDATED_BY_APP) values 
                              (v_contact_id,
                              p_party_id,
                              'EMAIL',
                              p_primary_flag,
                              'c2cdm',
                              SYSDATE,
                              'c2cdm',
                              SYSDATE,
                              NULL
                             );
	--
	END;
	commit;
	--
	BEGIN
		SELECT SPV.PROP_ID
		INTO V_PROP_ID
		FROM DBO_TC.SYS_PROPERTY SP,
			 DBO_TC.SYS_PROP_VALUE SPV
		WHERE SP.SYS_PROP_ID=SPV.SYS_PROP_ID
		AND SP.SYS_PROP_NAME LIKE 'EMAIL'
		AND spv.prop_value=P_EMAIL_TYPE
		AND ROWNUM=1;
--
		END;
--	
	BEGIN
		select DBO_TC.SEQ_WEBCONTACT_ID.NEXTVAL 
		into v_email_id
		from dual;
--
	INSERT INTO DBO_TC.WEB_CONTACT ( 
						 WEBCONTACT_ID,CONTACT_ID,
                         CONTACT_TYPE,CONTACT_VALUE) VALUES 
					  (	v_email_id,
						v_contact_id,
						V_PROP_ID,
						P_EMAIL);
--					

	END;
		EXCEPTION
		WHEN OTHERS THEN
		V_ERROR := SUBSTR(SQLERRM,1,3000);
		INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data for email  for party  :'||p_party_id,V_ERROR);
END;
--PARTY_PERSON_IMPORT
PROCEDURE PERSON_CONTACT_INSERT(P_PARTY_ID IN NUMBER,P_FIRST_NAME IN VARCHAR2,P_LAST_NAME IN VARCHAR2)
AS
V_PARTY_ID NUMBER;
V_CONTACT_ID NUMBER;
BEGIN

BEGIN
		SELECT PARTY_ID
		INTO V_PARTY_ID
		FROM DBO_TC.PERSON
		WHERE PARTY_ID=P_PARTY_ID
		AND ROWNUM=1;
EXCEPTION 
WHEN OTHERS THEN 
  insert into DBO_TC.person (
						PARTY_ID,
						FIRST_NAME,
						LAST_NAME,
						GENDER,
						RACE,
						DOB,
						SSN,
						SSN_END_CHARS
					)  
					VALUES
                    (	P_PARTY_ID,
						P_FIRST_NAME,
						nvl(P_LAST_NAME,P_FIRST_NAME),
						NULL,
						NULL,
						NULL,
						NULL,
						NULL
					);
END;
--CONTACT
BEGIN
		SELECT PARTY_ID
		INTO V_CONTACT_ID
		FROM DBO_TC.CONTACT
		WHERE PARTY_ID=P_PARTY_ID
		AND ROWNUM=1;
EXCEPTION
		WHEN OTHERS THEN 
		insert into DBO_TC.CONTACT(PARTY_ID, 
							DESIGNATION, 
							TYPE, 
							NEVER_EMAIL_IND, 
							BUSINESS_PERSONAL, 
							DEPARTMENT_ID
							)  
						VALUES
							(P_PARTY_ID,
							NULL,
							NULL,
							NULL,
							NULL,
							NULL
							);
END;
EXCEPTION 
  WHEN OTHERS THEN
        V_ERROR := SUBSTR(SQLERRM,1,3000);
		INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting data to person and contact table  for party:'||p_party_id,V_ERROR);
		END;
--
--PARTY_AKA_INSERT
PROCEDURE PARTY_AKA_INSERT( P_PARTY_ID IN NUMBER,P_LAST_NAME IN VARCHAR2,P_FIRST_NAME IN VARCHAR2)
AS
	BEGIN
		INSERT INTO DBO_TC.PARTY_AKA
				(ID,
				PARTY_ID,
				AKA_NAME ,
				AKA_IND ,
				FIRST_NAME, 
				LAST_NAME,
				LAST_UPDATED_USER,
				LAST_UPDATED_TS,
				IS_CURRENT)
		VALUES
			(	DBO_TC.SEQ_PARTY_AKA_ID.NEXTVAL,
				P_PARTY_ID,
				TRIM(P_FIRST_NAME)||' '||TRIM(P_LAST_NAME),
				'N',
				TRIM(P_FIRST_NAME),
				TRIM(P_LAST_NAME),
				'c2cdm',
				sysdate,
				'Y');
	COMMIT;
--		

	EXCEPTION 
	WHEN OTHERS THEN
		V_ERROR := SUBSTR(SQLERRM,1,3000);
		INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in inserting CREW data to party_aka  table:'||p_party_id,V_ERROR);
        --
	END;
	--CREATE PARTY
	FUNCTION create_party(p_display_name IN VARCHAR2)
RETURN NUMBER
AS
v_cont_party_id NUMBER;
--
		 BEGIN
          SELECT DBO_TC.seq_party_id.nextval INTO v_cont_party_id FROM dual;
         --
          INSERT
          INTO dbo_tc.party
            (
              party_id ,
              party_type ,
              display_name ,
			  ta_display_name,
              created_by,
              created_date,
              updated_by,
              updated_date,
              updated_by_app,
              created_by_app,
			  dataset_id
            )
            VALUES
            (
              v_cont_party_id,
              'CONTACT' ,
              trim(p_display_name) ,
			  lower(p_display_name),
              'c2cdm' ,
              SYSDATE ,
              'c2cdm' ,
              SYSDATE ,
              360 ,
              360,
			  '4342'
            );
			RETURN v_cont_party_id;
        EXCEPTION
        WHEN OTHERS THEN
				V_ERROR := SUBSTR(SQLERRM,1,3000);
				INSERT INTO FC_SOURCE.FC_DM_DEBUG VALUES(FC_SOURCE.SEQ_FC_DM_DEBUG.NEXTVAL,1,V_SCRIPT_ID,'Error in creating the party :'||p_display_name,V_ERROR);
	END;

	BEGIN
			FOR I IN C_AGENT
			LOOP
			--create party
			BEGIN
	
				SELECT PARTY_ID
				INTO v_party_id
				FROM DBO_TC.PARTY
				WHERE upper(trim(display_name)) = upper(trim(I.LASTNAME||', '||I.FIRSTNAME||' '||I.MIDDLENAME))
				AND PARTY_TYPE ='CONTACT'
				AND ROWNUM                =1;
			EXCEPTION	
				WHEN OTHERS THEN 
				IF I.LASTNAME IS NULL THEN
					v_party_id:=create_party(trim(I.FIRSTNAME||' '||I.MIDDLENAME));
				ELSE
				
					v_party_id:=create_party(trim(I.LASTNAME||', '||I.FIRSTNAME||' '||I.MIDDLENAME));
				END IF;
			END;
			IF v_party_id IS NOT NULL
			THEN 
			--updating staging table with party_id
				UPDATE FC_SOURCE.fc_crew_staging
				SET PARTY_ID=NVL(v_party_id,0)
				WHERE crewid=i.crewid;
				--
			--CREATE PARTY CONTACT
			CREATE_PARTY_CONTACT(v_party_id,i.ADDRESSLINE1,i.ADDRESSLINE2,i.ADDRESSLINE3,
			i.CITY,I.STATEPROV,I.ZIP,I.COUNTRYID);			--
			--PERSON_CONTACT_INSERT
			IF I.LASTNAME IS NULL THEN
			PERSON_CONTACT_INSERT(v_party_id,NULL,I.FIRSTNAME);
			ELSE
			PERSON_CONTACT_INSERT(v_party_id,I.FIRSTNAME,I.LASTNAME);
			END IF;
			--PARTY_AKA_INSERT
			--PARTY_AKA_INSERT(v_party_id,trim(I.LASTNAME),TRIM(I.FIRSTNAME||' '||I.MIDDLENAME));
			--CREW OCCUPATION
			CREW_OCCUPATION(v_party_id);
			--
      IF I.EMAILADDRESS IS NOT NULL THEN
			PROC_CONTACT_EMAIL(V_PARTY_ID,'Work',I.EMAILADDRESS);
      END IF;
	  IF I.EMAILADDRESS2 IS NOT NULL THEN
			PROC_CONTACT_EMAIL(V_PARTY_ID,'Other',I.EMAILADDRESS2);
      END IF;
			--
		BEGIN 
			IF i.homephone is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Home 1',I.HOMEPHONE);
			END IF;
			IF i.workphone is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Work 1',I.workphone);
			END IF;
			IF i.fax is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Home Fax',I.fax);
			END IF;
			IF i.pager is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Pager',I.pager);
			END IF;
			IF i.cell is NOT NULL THEN
				PROC_CONTACT_PHONE(v_party_id,'Cell 1',I.cell);
			END IF;
		END;
		END IF;--PARTY_ID EXISTS
				END LOOP;
				END;

/
