
DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM all_tab_cols
    WHERE 
    column_name = 'VERSION'
    AND table_name = 'FC_CONTRACT_TEMPLATE'
    AND owner = 'DBO_FC';
  IF (v_exists = 1) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_TEMPLATE  DROP COLUMN VERSION';
  END IF;
END;
/


ALTER TABLE DBO_FC.FC_CONTRACT_RIDER  ADD FILTER VARCHAR(100) NULL;