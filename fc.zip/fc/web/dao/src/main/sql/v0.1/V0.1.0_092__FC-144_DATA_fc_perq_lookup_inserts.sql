--Data insert for Default UNIONS

DECLARE
TYPE name_array IS   VARRAY(9) OF VARCHAR2(255);
var_perq_array name_array;
var_perq_picklist_id NUMBER;
var_studio_wb NUMBER;
BEGIN
  var_perq_array := name_array('Compensation', 'Expenses/Transportation', 'Paid Ads', 'Dressing Room', 'Bio/Still/Likeness Approval', 'Premiere/DVD', 'Miscellaneous');
  SELECT lk.lookup_id 
  INTO var_studio_wb
  FROM DBO_MP.LOOKUP lk
  WHERE lk.lookup_name = 'WB Pictures' and lk.LOOKUP_TYPE_ID = (select LOOKUP_TYPE_ID from DBO_MP.LOOKUP_TYPE where LOOKUP_TYPE_NAME = 'STUDIO');
  --picklist entry for pereq, used for type in admin codes
  
  INSERT
  INTO DBO_FC.FC_LOOKUP
    (
      ID,
      NAME,
      TYPE,
      CREATE_DATE,
      UPDATED_BY,
      CREATED_BY,
      UPDATE_DATE
    )
    VALUES
    (
      DBO_FC.FC_LOOKUP_ID_SEQ.nextval,
      'PERQ',
      'PICKLIST',
      SYSDATE,
      'C2C_Migration',
      'C2C_Migration',
      SYSDATE
    );
  --get id of union picklist value
  SELECT DBO_FC.FC_LOOKUP_ID_SEQ.currval
  INTO var_perq_picklist_id
  FROM dual;
  FOR i IN 1..var_perq_array.count
  LOOP
    INSERT
    INTO DBO_FC.FC_LOOKUP
      (
        ID,
        NAME,
        TYPE,
        CREATE_DATE,
        UPDATED_BY,
        CREATED_BY,
        UPDATE_DATE,
        DISPLAY_ORDER
      )
      VALUES
      (
        DBO_FC.FC_LOOKUP_ID_SEQ.nextval,
        var_perq_array(i),
        'PERQ',
        SYSDATE,
        'C2C_Migration',
        'C2C_Migration',
        SYSDATE,
        i
      );
   
             -- Create Admin Codes record for union
      INSERT
      INTO DBO_FC.FC_ADMIN_CODES
        (
          DBO_FC.FC_ADMIN_CODES.ID,
          EFFECTIVE_DATE,
          DISABLED_FLAG,
          LOOKUP_ID,
          STUDIO_LOOKUP_ID,
          TYPE_LOOKUP_ID,
          UPDATE_DATE,
          UPDATED_BY,
          CREATE_DATE,
          CREATED_BY,
          ORDER_NUM
        )
        VALUES
        (
          DBO_FC.FC_ADMIN_CODES_ID_SEQ.nextval,
          SYSDATE,
          'N',
          DBO_FC.FC_LOOKUP_ID_SEQ.currval,
          var_studio_wb,
          var_perq_picklist_id,
          SYSDATE,
          'C2C_Migration',
          SYSDATE,
          'C2C_Migration',
          i
        ); 
  END LOOP;
END;
