--FC-2043 and fc-2048 making notes section larger to handle html that gets added to inserted text from 
--Rich text editor in UI.

ALTER TABLE DBO_FC.FC_DEAL MODIFY (PERFORMER_I_NINE_STATUS_NOTE  VARCHAR2(2500));
ALTER TABLE DBO_FC.FC_DEAL MODIFY (SAG_STATUS_NOTE  VARCHAR2(2500));
