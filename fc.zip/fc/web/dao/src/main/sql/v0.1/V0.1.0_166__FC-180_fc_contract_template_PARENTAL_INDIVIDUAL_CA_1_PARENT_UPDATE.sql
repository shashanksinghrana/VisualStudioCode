
DECLARE 
    contractTemplate CLOB := '<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <style>
        th {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        td {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        p {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }
    </style>
</head>
<body>
    <h2 style="text-align: center;"><strong>PARENTAL&nbsp;AGREEMENT<br /></strong><strong style="font-size: 18px;">(Individual)</strong></h2>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 100%;">
                    <p>THIS PARENTAL AGREEMENT dated as of&nbsp;[[${data.getDealDate()}]] (&ldquo;Agreement&rdquo;) by and between&nbsp;[[${data.getProductionCompany()}]] (&ldquo;Producer&rdquo;) and&nbsp;[[${data.getParent()}]] (&ldquo;Parent&rdquo;) is made with reference to the following facts:</p>
                    <ol style="list-style-type: upper-alpha;">
                        <li>Producer has engaged&nbsp;[[${data.getPerformerName()}]], a minor (&ldquo;Minor&rdquo;)&nbsp;[[${data.getPerformerAge()}]] years of age (born on&nbsp;[[${data.getPerformerDOB()}]]) pursuant to a written contract dated as of&nbsp;[[${data.getDealDate()}]] (&ldquo;Minor&rsquo;s Contract&rdquo;) to render acting services for Producer in connection with a motion picture presently entitled&nbsp;"[[${data.getProjectName()}]]" ("Picture").</li>
                        <li>[[${data.getParent()}]] is the parent of the Minor and is entitled to the sole care, custody and control of the Minor.</li>
                        <li>The parties hereto contemplate and understand that a petition will be made by Producer to the Superior Court of the State of California for the County of Los Angeles for the approval by such court of the Minor&rsquo;s Contract.</li>
                        <li>Parent understands that Producer will rely on this Agreement in: (a) entering into and performing the Minor&rsquo;s Contract, and (b) undertaking substantial expenditures in addition to the compensation payable pursuant to the Minor&rsquo;s Contract.</li>
                    </ol>
                    <p>NOW, THEREFORE, the parties, in consideration of the mutual promises herein contained and other good and valuable consideration, agree as follows:</p>
                    <ol>
                        <li>Parent warrants and represents that the above recitals are true and correct, that no judgment, order or decree has been made by any court awarding the custody of the Minor to any other person or in any other manner affecting the status or the right of Parent as parent of the Minor, that the Minor has not been emancipated, and that Parent has not in any way relinquished to the Minor or to any other person, firm or corporation the earnings of the Minor under the Minor&rsquo;s Contract nor the right to collect, receive or control such earnings, except as hereinafter expressly provided.</li>
                        <li>Parent hereby irrevocably and perpetually releases, relinquishes and quitclaims to the Minor all salary and compensation payable to the Minor pursuant to the Minor&rsquo;s Contract and agrees that Parent is not entitled to receive or to claim any such salary or compensation, or any part thereof, or demand that Producer pay such salary or compensation, or any part thereof, to Parent or to anyone other than the Minor, unless pursuant to instructions from the Minor.</li>
                        <li>Parent hereby consents to and ratifies the execution by the Minor of the Minor&rsquo;s Contract. Parent acknowledges that Parent has read the Minor&rsquo;s Contract and is familiar with all of the terms, covenants and conditions contained therein, and is satisfied that the Minor&rsquo;s Contract is fair, just and equitable and is for the benefit of the Minor, and that Parent will not revoke said consent during the minority of the Minor, or thereafter.</li>
                        <li><br />(a) Parent agrees to cooperate fully with Producer by providing information, executing such documents as Producer may require and giving testimony, if necessary, in securing the approval of the Minor&rsquo;s Contract by a court of competent jurisdiction. Without limiting the foregoing, Parent hereby agrees that Producer may petition to the Superior Court of the State of California for the County of Los Angeles (&ldquo;Court&rdquo;) as provided by law for approval of the Minor&rsquo;s Contract. Parent further agrees that a copy of this Agreement may be filed with such application for approval as evidence of the consent herein granted. Parent hereby waives notice of any hearing before the Court with respect to such application. Parent agrees that such amount of the salary or compensation of the Minor payable under the Minor&rsquo;s Contract as may be determined to be proper by the Court may be set aside for investment in government bonds or in such other blocked, federally insured savings plan or in such trust fund as the Court may determine to be held and preserved for the Minor, subject to the order of the Court, and Parent hereby consents to serve as sole or joint guardian or trustee thereof if the Court so appoints Parent. In connection with the foregoing, Parent acknowledges that the 15% amount that the Court is being requested to order be set aside in a federally insured, blocked trust account or other savings plan does not exceed one-half of the net earnings under the Minor&rsquo;s Contract, as the term &ldquo;net earnings&rdquo; is defined by Section 6752 of the Family Code of the State of California. <br />(b) Parent further agrees that, notwithstanding the foregoing provisions with respect to the Court approval of the Minor&rsquo;s Contract, Parent guarantees the performance by the Minor of the terms and provisions of the Minor&rsquo;s Contract as well as any court decree which grants approval of same, and represents and warrants that the Minor will not disaffirm the Minor&rsquo;s Contract at any time during or after minority. Parent further agrees to indemnify and hold Producer, its successors, licensees and assigns and their respective officers, directors, shareholders, employees and agents harmless from any and all damages, liabilities, costs or expenses of any kind or nature, including reasonable attorneys&rsquo; fees, with respect to any claim whatsoever arising from the breach by the Minor and/or Parent of any of the provisions of the Minor&rsquo;s Contract and/or this Agreement, including without limitation the Minor&rsquo;s attempt to disaffirm or disavow the Minor&rsquo;s Contract on the grounds of the Minor&rsquo;s minority or otherwise.</li>
                        <li>Parent hereby consents to the distribution, exhibition and other exploitation of the Picture without limitation, and the use of Minor&rsquo;s name, likeness, voice and biographical material in connection with publicity and advertising of the Picture, and Parent expressly releases the Producer, its licensees and assigns from any and all claims which may arise out of said exhibition, distribution and/or other exploitation of the Picture. The foregoing is subject to the provisions of the Minor&rsquo;s Contract.</li>
                        <li>This Agreement shall apply to the Minor&rsquo;s Contract, to all modifications and extensions thereof and amendments thereto and to any employment agreement between Producer and the Minor which may be substituted in full or in part for the Minor&rsquo;s Contract.</li>
                        <li>This Agreement shall inure to the benefit of and be binding upon the parties hereto, their respective successors, assigns, next of kin, heirs, administrators, executors, officers and agents, as the case may be.</li>
                    </ol>
                    <p>IN WITNESS WHEREOF, the parties hereto have executed this Agreement on the date hereinabove set forth.</p>
                </td>
            </tr>
        </tbody>
    </table>
    <p style="padding-left: 60px;">&nbsp;</p>
    <table style="height: 49px; width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;">
        <tbody>
            <tr>
                <td style="width: 50%; vertical-align: top;">
                    <p>____________________________________________________<br />[[${data.getParent()}]]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;("Parent")</p>
                    <p>ADDRESS:&nbsp;&nbsp;[[${data.getPerformerAddress()}]]</p>
                    <p>TELEPHONE:&nbsp;&nbsp;[[${data.getParentPhoneNumber()}]]</p>
                </td>
                <td style="width: 50%;">
                    <p>[[${data.getProductionCompany()}]]<br />("Producer")</p>
                    <p>By:________________________________________<br />&nbsp; &nbsp; &nbsp;Its:&nbsp;[[${data.getSignatoryTitle()}]]</p>
                </td>
            </tr>
        </tbody>
    </table>
    <p>&nbsp;</p>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 50%;">[[${data.getDealDate()}]] <br />[[${data.getProjectName()}]]<br />[[${data.getPerformerName()}]]</td>
                <td style="width: 50%; text-align: right;">FORM 509 rev. 7/27/97<br />Parental Agreement (Individual)<br />One Parent</td>
            </tr>
        </tbody>
    </table>
    <p style="text-align: left;"><br /><br /><br /></p>
</body>
</html>'; 
    i                   INT; 
BEGIN 
    WHILE Length(contractTemplate) <= 6000 LOOP 
        contractTemplate := contractTemplate 
                               || ' '; 
    END LOOP; 
	select id into i from FC_LOOKUP where name='Parental Agreement (Individual – CA – 1 Parent)';
	update FC_CONTRACT_TEMPLATE set TEXT=contractTemplate where CONTRACT_LOOKUP_ID=i; 

commit;                         
END; 
