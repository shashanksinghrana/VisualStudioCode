--FC-142 updating columns to allow nulls on compenstation table. 
DECLARE
   allready_null EXCEPTION;
   PRAGMA EXCEPTION_INIT(allready_null, -1451);
BEGIN
   execute immediate 'ALTER TABLE DBO_FC.FC_COMPENSATION MODIFY (GUARANTEE_NUMBER NUMBER NULL)';
EXCEPTION
   WHEN allready_null THEN
      null; -- handle the error
END;