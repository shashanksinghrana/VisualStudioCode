DECLARE
TYPE proj_status_array IS VARRAY(2) OF VARCHAR2(300);
var_proj_status proj_status_array;
BEGIN
  var_proj_status := proj_status_array('Added Scenes','Other');

  --insert DYNAMIC ATTRIBUTE for Project status
  INSERT
  INTO DBO_MP.DYNAMIC_ATTRIBUTE
    (
      DYNAMIC_ATTRIBUTE_ID,
      DYNAMIC_ATTRIBUTE_TYPE,
      DYNAMIC_ATTRIBUTE_MODULE,
      DYNAMIC_ATTRIBUTE_DISP_VAL,
      ATTRIBUTE_TYPE,
      UPDATED_DATE,
      UPDATED_BY
    )
    VALUES
    (
      DBO_MP.SEQ_DYNAMIC_ATTRIBUTE_ID.nextval,
      'PROJ_STATUS',
      'FEATURE_CASTING',
      'Sub-Status Values',
      'PickList',
      SYSDATE,
      'JeffreyL'
    );
    
  FOR i in 1..var_proj_status.count
    LOOP
    
  INSERT
  INTO DBO_MP.DYNAMIC_ATTRIBUTE_VALUES
    (
      DYNAMIC_ATTRIBUTE_VALUES_ID,
      DYNAMIC_ATTRIBUTE_ID,
      ATTRIBUTE_ACTIVE_IND,
      ATTRIBUTE_VALUE,
      ATTRIBUTE_DISP_VAL,
      ATTRIBUTE_CONVERTERVALUES,
      ATTRIBUTE_DELETE_IND,
      LAST_UPDATE_TS,
      LAST_UPDATE_USER
    )
    VALUES
    (
      DBO_MP.SEQ_DYNAMIC_ATTR_VAL_ID.nextval,
      DBO_MP.SEQ_DYNAMIC_ATTRIBUTE_ID.currval ,
      'Y',
      var_proj_status(i),
      var_proj_status(i),
      var_proj_status(i),
      'N',
      SYSTIMESTAMP,
      'JeffreyL'
    );
    END LOOP;
    END;
  