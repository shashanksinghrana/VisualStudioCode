--Insert Feature Casting module lookup for studio module access.
DECLARE
  type_id NUMBER;
BEGIN
  SELECT t.LOOKUP_TYPE_ID
  INTO type_id
  FROM DBO_MP.LOOKUP_TYPE t
  WHERE t.LOOKUP_TYPE_NAME='DEFAULT_TAB';
  INSERT
  INTO DBO_MP.LOOKUP
    (
      LOOKUP_ID,
      LOOKUP_NAME,
      MNEMONIC_CODE,
      LOOKUP_TYPE_ID,
      LAST_UPDATE_TS,
      LAST_UPDATE_USER
    )
    VALUES
    (
      DBO_MP.SEQ_LOOKUP_ID.nextval,
      'Feature Casting',
      'Feature Casting',
      type_id,
      SYSTIMESTAMP,
      'JeffreyL'
    );
END;