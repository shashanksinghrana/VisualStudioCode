-- Contract Rider fILTER COLUMN CREATE & Inserts
SET DEFINE OFF;
DECLARE
var_contract_lookup_id_1 NUMBER;


BEGIN

SELECT lk.ID
INTO var_contract_lookup_id_1
FROM DBO_FC.FC_LOOKUP lk
WHERE NAME = 'Loanout of a Day Performer';


UPDATE DBO_FC.FC_CONTRACT_RIDER SET FILTER = 'LOANOUT' WHERE CONTRACT_LOOKUP_ID = var_contract_lookup_id_1;

END;


