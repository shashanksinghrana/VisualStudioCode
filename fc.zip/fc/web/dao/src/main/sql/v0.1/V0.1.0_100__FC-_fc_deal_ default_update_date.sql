alter table dbo_fc.fc_deal modify( update_date DATE default systimestamp );
commit;