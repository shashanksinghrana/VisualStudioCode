--------------------------------------------------------
--  File created - Monday-August-20-2018   
--------------------------------------------------------
DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM ALL_TABLES
    WHERE table_name = 'FC_RIDERS'
    AND owner = 'DBO_FC';
  IF (v_exists = 1) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_RIDERS RENAME TO FC_CONTRACT_RIDER';
  END IF;
END;
/

DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM all_tab_cols
    WHERE 
    column_name = 'CONTRACT_TEMPLATE_ID'
    AND table_name = 'FC_CONTRACT_RIDER'
    AND owner = 'DBO_FC';
  IF (v_exists = 1) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_RIDER RENAME COLUMN CONTRACT_TEMPLATE_ID TO CONTRACT_LOOKUP_ID';
  END IF;
END;
/

DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM all_tab_cols
    WHERE 
    column_name = 'DEAL_ID'
    AND table_name = 'FC_CONTRACT_RIDER'
    AND owner = 'DBO_FC';
  IF (v_exists = 1) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_RIDER RENAME COLUMN DEAL_ID TO FEETYPE_LOOKUP_ID';
  END IF;
END;
/


