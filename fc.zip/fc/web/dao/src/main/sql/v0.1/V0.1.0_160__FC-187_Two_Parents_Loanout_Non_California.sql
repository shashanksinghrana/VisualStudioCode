
DECLARE 
    contractTemplate CLOB := '<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <style>
        th {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        td {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        p {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }
    </style>
</head>
<body>
    <h2 style="text-align: center;"><strong>PARENTAL&nbsp;AGREEMENT<br /></strong><strong style="font-size: 18px;">(Loanout)</strong></h2>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 100%;">
                    THIS PARENTAL AGREEMENT dated as of&nbsp;[[${data.getDealDate()}]] (&ldquo;Agreement&rdquo;) by and between&nbsp;[[${data.getProductionCompany()}]] (&ldquo;Producer&rdquo;), on the one hand, and [[${data.getParent1()}]] and [[${data.getParent2()}]] (collectively, "Parents") and [[${data.getLoanoutCompany()}]] ("Lender&rdquo;) on the other hand, is made with reference to the following facts:<br /><br /><br /><span style="font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit;">A. Producer has engaged Lender to furnish the services of </span>[[${data.getPerformerName()}]]<span style="font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit;">, a minor (&ldquo;Minor&rdquo;)&nbsp;</span>[[${data.getPerformerAge()}]]<span style="font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit;"> years of age (born on&nbsp;</span>[[${data.getPerformerDOB()}]])<span style="font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit;"> pursuant to a written contract dated as of&nbsp;</span>[[${data.getDealDate()}]]<span style="font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit;"> (&ldquo;Motion Picture Contract&rdquo;) in connection with a motion picture presently entitled "</span>[[${data.getProjectName()}]]<span style="font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit;">" ("Picture").<br /><br /></span>
                    <div>[B. Concurrently with the execution of the Motion Picture Contract, the Minor acknowledged and agreed to keep and perform all of the terms and conditions of the Motion Picture Contract and to perform acting services for Producer in accordance with the terms and conditions thereof (&ldquo;Ratification Contract&rdquo;).]</div>
                    <div>[B. Minor agreed and accepted to be bound by the Motion Picture Contract in Minor&rsquo;s capacity as an individual as evidenced by Minor&rsquo;s signature of the Motion Picture Contract (&ldquo;Ratification Contract&rdquo;).]</div>
                    <div>[B. Included in the Motion Picture Contract is an inducement pursuant to which the Minor agreed to keep and perform all of the terms and conditions of the Motion Picture Contract and to perform acting services for Producer in accordance with the terms and conditions thereof (&ldquo;Ratification Contract&rdquo;).]</div>
                    <br />C. Lender is a corporation duly organized and existing under and by virtue of the laws of the State of [[${data.getState()}]] and is authorized to engage in business in the entertainment field in the State of [[${data.getState()}]].&amp;nbsp;Prior to the date hereof, Lender and the Minor entered into an employment contract (&amp;ldquo;Loanout Agreement&amp;rdquo;) pursuant to which Lender employed the Minor to render acting services and Lender would furnish the Minor&amp;rsquo;s services as a performer to third parties in the entertainment field.<br /><br />D.&nbsp;The Motion Picture Contract and the Ratification Contract are hereinafter collectively referred to as the &ldquo;Contract&rdquo;.<br /><br />E.&nbsp;[[${data.getParent1()}]]&nbsp; and&nbsp;[[${data.getParent2()}]] are the parents of the Minor and are entitled to the sole care, custody and control of the Minor.<br /><br />F. The parties hereto contemplate and understand that a petition will be made by Producer to therelevant judicial forum for the approval by such court of the Minor&rsquo;s Contract.<br /><br />G.&nbsp;Lender and Parents understand that Producer will rely on this Agreement in: (a) entering into and performing the Contract, and (b) undertaking substantial expenditures in addition to the compensation payable pursuant to the Contract.<br />
                    <p>NOW, THEREFORE, the parties, in consideration of the mutual promises herein contained and other good and valuable consideration, agree as follows:</p>
                    <ol>
                        <li>Lender and Parents warrant and represent that the above recitals are true and correct, that no judgment, order or decree has been made by any court awarding the custody of the Minor to any other person or in any other manner affecting the status or the right of Parents as parents of the Minor, that the Minor has not been emancipated, and that neither Lender nor Parents have in any way relinquished to the Minor or to any other person, firm or corporation the earnings of the Minor or Lender under the Contract nor the right to collect, receive or control such earnings, except as hereinafter expressly provided.</li>
                        <li>Parents and the Minor hereby irrevocably and perpetually release, relinquish and quitclaim to Lender all salary and compensation payable to Lender pursuant to the Motion Picture Contract, and Parents hereby agree that Parents are not entitled to receive or to claim any such salary or compensation, or any part thereof, to Parents or to anyone other than Lender, unless pursuant to instructions from Lender. Lender and Parents hereby further irrevocably and perpetually release, relinquish and quitclaim to the Minor all salary and compensation payable to the Minor pursuant to the Employment Contract. If for any reason, including under the Ratification Contract, it is deemed that the Minor is employed directly by Producer pursuant to the Motion Picture Contract, Lender and Parents irrevocably and perpetually release and relinquish to the Minor all salary and compensation payable pursuant to the Employment Contract, and in such event, Lender and Parents hereby also agree that they are not entitled to receive or to claim any such salary or compensation or demand that Producer pay such salary or compensation, or any part thereof, to Lender, Parents or anyone other than the Minor.</li>
                        <li>Lender and Parents hereby consent to and ratify the execution by the Minor of the Contract and the Employment Contract. Parents consent to and approve of Lender&rsquo;s furnishing of Minor&rsquo;s services pursuant to the Employment Contract. Lender and Parents acknowledge that they have read each of the Contract and the Employment Contract and are familiar with all of the terms, covenants and conditions contained therein, and are satisfied that each of the Contract and the Employment Contract is fair, just and equitable and is for the benefit of the Minor, and that neither Lender nor Parents will revoke said consents during the minority of the Minor, or thereafter.</li>
                        <li>
                            <div><br />(a)&nbsp; &nbsp; Lender and Parents agree to cooperate fully with Producer by providing information, executing such documents as Producer may require and giving testimony, if necessary, in securing the approval of the Contract by a court of competent jurisdiction. Without limiting the foregoing, Lender and Parents hereby agree that Producer may petition to the Superior Court of the State of California for the County of Los Angeles (&ldquo;Court&rdquo;) as provided by law for approval of the Contract. Lender and Parents further agree that a copy of this Agreement may be filed with such application for approval as evidence of the consent herein granted. Lender and Parents hereby waive notice of any hearing before the Court with respect to such application. Lender and Parents agree that such amount of the salary of compensation of the Minor payable under the Contract as may be determined to be proper by the Court may be set aside for investment in government bonds or in such other blocked, federally insured savings plan or in such trust fund as the Court may determine to be held and preserved for the Minor, subject to the order of the Court, and Parents hereby consent to serve as sole or joint guardians or trustees thereof if the Court so appoints Parents. In connection with the foregoing, Lender and Parents acknowledge that the 15% amount that the Court is being requested to order be set aside in a federally insured, blocked trust account or other savings plan does not exceed one-half of the net earnings under the Contract, as the term &ldquo;net earnings&rdquo; is defined by Section 6752 of the Family Code of the State of California.</div>
                            <div>(b)&nbsp; &nbsp;Lender and Parents further agree that, notwithstanding the foregoing provisions with respect to the Court approval of the Contract, Lender and Parents guarantee the performance by the Minor of the terms and provisions of the Contract as well as any court decree which grants approval of same, and represent and warrant that the Minor will not disaffirm the Contract at any time during or after minority. Lender and Parents further agree to indemnify and hold Producer, its successors, licensees and assigns and their respective officers, directors, shareholders, employees and agents harmless from any and all damages, liabilities, costs or expenses of any kind or nature, including reasonable attorneys&rsquo; fees, with respect to any claim whatsoever arising from the breach by the Minor, Lender and/or Parents of any of the provisions of the Contract, the Employment Contract and/or this Agreement, including without limitation the Minor&rsquo;s attempt to disaffirm or disavow the Contract on the grounds of the Minor&rsquo;s minority or otherwise.</div>
                        </li>
                        <li>Lender and Parents hereby consent to the distribution, exhibition and other exploitation of the Picture without limitation, and the use of Minor&rsquo;s name, likeness, voice and biographical material in connection with publicity and advertising of the Picture, and Lender and Parents expressly release the Producer, its licensees and assigns from any and all claims which may arise out of said exhibition, distribution and/or other exploitation of the Picture. The foregoing is subject to the provisions of the Contract.</li>
                        <li>This Agreement shall apply to the Contract, to all modifications and extensions thereof and amendments thereto and to any employment agreement between Producer and Lender and/or the Minor which may be substituted in full or in part for the Contract.</li>
                        <li>This Agreement shall inure to the benefit of and be binding upon the parties hereto, their respective successors, assigns, next of kin, heirs, administrators, executors, officers and agents, as the case may be.<br /><br />IN WITNESS WHEREOF, the parties hereto have executed this Agreement on the date hereinabove<span style="font-family: Roboto; font-size: 12px; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit;"> set forth.</span></li>
                    </ol>
                </td>
            </tr>
        </tbody>
    </table>
    <p>&nbsp;</p>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 100%;">
                    <p style="padding-left: 780px;">[[${data.getProductionCompany()}]]</p>
                    <p style="padding-left: 1110px;">("Producer")</p>
                    <p style="padding-left: 870px;">By:________________________________________<br />&nbsp; &nbsp; &nbsp;Its:&nbsp;[[${data.getSignatoryTitle()}]]</p>
                    <p style="padding-left: 870px;">&nbsp;</p>
                    <p>____________________________________________________<br />[[${data.getParent1()}]]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;("Parent")<br /><br /><br />____________________________________________________<br />[[${data.getParent2()}]]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;("Parent")</p>
                    <p>ADDRESS:&nbsp;&nbsp;[[${data.getPerformerAddress()}]]</p>
                    <p>TELEPHONE:&nbsp;&nbsp;[[${data.getParentPhoneNumber()}]]</p>
                </td>
            </tr>
        </tbody>
    </table>
    <p>&nbsp;</p>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 50%;">[[${data.getDealDate()}]] <br />[[${data.getProjectName()}]]<br />[[${data.getPerformerNamePKA()}]]</td>
                <td style="width: 50%; text-align: right;">FORM 508A rev. 8/19/97<br />Parental Agreement (Loanout)<br />Two Parents</td>
            </tr>
        </tbody>
    </table>
    <p style="text-align: left;"><br /><br /><br /></p>
</body>
</html>'; 
    i                   INT; 
BEGIN 
    WHILE Length(contractTemplate) <= 6000 LOOP 
        contractTemplate := contractTemplate 
                               || ' '; 
    END LOOP; 
	select id into i from FC_LOOKUP where name='Parental Agreement (Loanout – Non-CA – 2 Parents)';

Insert into FC_CONTRACT_TEMPLATE (ID,CONTRACT_NAME,CREATED_BY,CREATE_DATE,CONTRACT_LOOKUP_ID,TEXT) values (DBO_FC.FC_CONTRACT_TEMPLATE_ID_SEQ.nextval,'TWO_PARENT_LOANOUT_AGREEMENT_NON_CA','JefferyL',SYSDATE,i,contractTemplate);

    dbms_output.Put_line('I have finished inputting your clob: ' 
                         || Length(contractTemplate)); 
commit;                         
END; 
