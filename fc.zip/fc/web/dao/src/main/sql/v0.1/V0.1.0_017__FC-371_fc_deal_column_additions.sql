--adding columns for No quote deal indicator and Lead Performer indicator
ALTER TABLE DBO_FC.FC_DEAL ADD performer_lead_ind VARCHAR2(1);
ALTER TABLE DBO_FC.FC_DEAL ADD no_quote_deal_ind VARCHAR2(1);