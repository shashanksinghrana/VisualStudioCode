UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '2' WHERE NAME = 'Exhibit A End Title' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '3' WHERE NAME = 'Exhibit A Main Title' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '4' WHERE NAME = 'Guardian Agreement (Individual - CA)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '5' WHERE NAME = 'Guardian Agreement (Individual - Non-CA)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '6' WHERE NAME = 'Loanout of a Day Performer' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '7' WHERE NAME = 'Minimum Freelance Contract' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '8' WHERE NAME = 'Minimum Freelance Loanout Contract' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '9' WHERE NAME = 'Non-Union Day Performer Agreement (Loanout)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '10' WHERE NAME = 'Non-Union Day Performer Agreement (Straight Hire)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '11' WHERE NAME = 'Parental Agreement (Individual – CA – 1 Parent)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '12' WHERE NAME = 'Parental Agreement (Individual – CA – 2 Parents)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '13' WHERE NAME = 'Parental Agreement (Individual – Non-CA – 1 Parent)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '14' WHERE NAME = 'Parental Agreement (Individual – Non-CA – 2 Parents)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '15' WHERE NAME = 'Parental Agreement (Loanout – CA – 1 Parent)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '16' WHERE NAME = 'Parental Agreement (Loanout – CA – 2 Parents)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '17' WHERE NAME = 'Parental Agreement (Loanout – Non-CA – 1 Parent)' AND TYPE ='CONTRACT';
UPDATE "DBO_FC"."FC_LOOKUP" SET DISPLAY_ORDER = '18' WHERE NAME = 'Parental Agreement (Loanout – Non-CA – 2 Parents)' AND TYPE ='CONTRACT';

















