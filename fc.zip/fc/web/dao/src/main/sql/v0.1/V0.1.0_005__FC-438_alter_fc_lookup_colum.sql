--changing display_order column from NUMBER to Varchar2
ALTER TABLE DBO_FC.FC_LOOKUP MODIFY DISPLAY_ORDER VARCHAR2(20);