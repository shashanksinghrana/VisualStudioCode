ALTER TABLE DBO_FC.FC_LOOKUP
  ADD display_label varchar2(100 byte);

declare
begin
	FOR rec1 IN
  (
      select l.type as type1, l.name as name1, l2.type type2, l2.name name2 from DBO_FC.FC_LOOKUP l  inner join DBO_FC.FC_LOOKUP l2 on l2.type = l.name and l.type = 'ACTIVITY'
  )
  loop
    update dbo_fc.fc_lookup set display_label = rec1.name2 where type = rec1.type1 and name = rec1.name1;
    delete from DBO_FC.FC_LOOKUP where type = rec1.type2 and name = rec1.name2;
  end loop;
commit;
end;