-- insert wizard lookup values
SET DEFINE OFF;
DECLARE

var_type_id NUMBER;
var_form_id NUMBER;
var_names_id NUMBER;
var_loanout_id NUMBER;
var_notices_id NUMBER;
var_comp_id NUMBER;
var_credit_id NUMBER;
var_perqs_id NUMBER;
var_work_act_id NUMBER;
var_summary_id NUMBER;

BEGIN
--insert type lookup
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'DEAL', 'DEAL_TYPE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 1);
var_type_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval; -- get type id
-- form tyype  lookup
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'WIZARD', 'FORM_TYPE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 1);
var_form_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval; -- get form id

-- page inserts
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'Names/Project Details', 'WIZARD_PAGE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 1);
var_names_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval;
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'Loanout', 'WIZARD_PAGE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 2);
var_loanout_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval;
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'Notices & Payments', 'WIZARD_PAGE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 3);
var_notices_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval;
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'Compensation', 'WIZARD_PAGE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 4);
var_comp_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval;
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'Credit', 'WIZARD_PAGE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 5);
var_credit_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval;
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'Perqs', 'WIZARD_PAGE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 6);
var_perqs_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval;
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'Work Activity', 'WIZARD_PAGE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 7);
var_work_act_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval;
insert into DBO_FC.FC_LOOKUP(ID, NAME, TYPE, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY, DISPLAY_ORDER) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval, 'Summary', 'WIZARD_PAGE', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL', 8);
var_summary_id := DBO_FC.FC_LOOKUP_ID_SEQ.currval;
--wizard config inserts
insert into FC_WIZARD_CONFIG(ID, TYPE_LOOKUP_ID, FORM_LOOKUP_ID, PAGE_LOOKUP_ID, DISPLAY_ORDER, CREATED_BY, CREATE_DATE, UPDATED_BY, UPDATE_DATE) values(DBO_FC.FC_WIZARD_CONFIG_ID_SEQ.nextval, var_type_id, var_form_id, var_names_id, 1, 'JeffreyL', SYSDATE, 'JeffreyL', SYSDATE); 
insert into FC_WIZARD_CONFIG(ID, TYPE_LOOKUP_ID, FORM_LOOKUP_ID, PAGE_LOOKUP_ID, DISPLAY_ORDER, CREATED_BY, CREATE_DATE, UPDATED_BY, UPDATE_DATE) values(DBO_FC.FC_WIZARD_CONFIG_ID_SEQ.nextval, var_type_id, var_form_id, var_loanout_id , 2, 'JeffreyL', SYSDATE, 'JeffreyL', SYSDATE); 
insert into FC_WIZARD_CONFIG(ID, TYPE_LOOKUP_ID, FORM_LOOKUP_ID, PAGE_LOOKUP_ID, DISPLAY_ORDER, CREATED_BY, CREATE_DATE, UPDATED_BY, UPDATE_DATE) values(DBO_FC.FC_WIZARD_CONFIG_ID_SEQ.nextval, var_type_id, var_form_id, var_notices_id, 3, 'JeffreyL', SYSDATE, 'JeffreyL', SYSDATE); 
insert into FC_WIZARD_CONFIG(ID, TYPE_LOOKUP_ID, FORM_LOOKUP_ID, PAGE_LOOKUP_ID, DISPLAY_ORDER, CREATED_BY, CREATE_DATE, UPDATED_BY, UPDATE_DATE) values(DBO_FC.FC_WIZARD_CONFIG_ID_SEQ.nextval, var_type_id, var_form_id, var_comp_id, 4, 'JeffreyL', SYSDATE, 'JeffreyL', SYSDATE); 
insert into FC_WIZARD_CONFIG(ID, TYPE_LOOKUP_ID, FORM_LOOKUP_ID, PAGE_LOOKUP_ID, DISPLAY_ORDER, CREATED_BY, CREATE_DATE, UPDATED_BY, UPDATE_DATE) values(DBO_FC.FC_WIZARD_CONFIG_ID_SEQ.nextval, var_type_id, var_form_id, var_credit_id, 5, 'JeffreyL', SYSDATE, 'JeffreyL', SYSDATE); 
insert into FC_WIZARD_CONFIG(ID, TYPE_LOOKUP_ID, FORM_LOOKUP_ID, PAGE_LOOKUP_ID, DISPLAY_ORDER, CREATED_BY, CREATE_DATE, UPDATED_BY, UPDATE_DATE) values(DBO_FC.FC_WIZARD_CONFIG_ID_SEQ.nextval, var_type_id, var_form_id, var_perqs_id, 6, 'JeffreyL', SYSDATE, 'JeffreyL', SYSDATE); 
insert into FC_WIZARD_CONFIG(ID, TYPE_LOOKUP_ID, FORM_LOOKUP_ID, PAGE_LOOKUP_ID, DISPLAY_ORDER, CREATED_BY, CREATE_DATE, UPDATED_BY, UPDATE_DATE) values(DBO_FC.FC_WIZARD_CONFIG_ID_SEQ.nextval, var_type_id, var_form_id, var_work_act_id, 7, 'JeffreyL', SYSDATE, 'JeffreyL', SYSDATE); 
insert into FC_WIZARD_CONFIG(ID, TYPE_LOOKUP_ID, FORM_LOOKUP_ID, PAGE_LOOKUP_ID, DISPLAY_ORDER, CREATED_BY, CREATE_DATE, UPDATED_BY, UPDATE_DATE) values(DBO_FC.FC_WIZARD_CONFIG_ID_SEQ.nextval, var_type_id, var_form_id, var_summary_id, 8, 'JeffreyL', SYSDATE, 'JeffreyL', SYSDATE); 


END;