
DECLARE 
    contractTemplate CLOB := '<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>

    <table border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td colspan="2">Engagement Starts</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Production No.</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getStartDate()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getProductionNumber()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Role</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Deal Date</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getRole()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getDealDate()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Picture</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Employer</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getProjectName()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getLoanoutCo()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Daily Rate</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">State of Incorporation or Federal I.D. No.</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getDailyRate()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getStateEIN()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Weekly Conversion Rate</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Performer</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getWeeklyConversionRate()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getPerformerName()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Producer</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Contract Address</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getProductionCompany()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getContractAddress()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Producer’s Address</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Agent</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getProducerAddress()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getRepName()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Performer’s Social Security No.</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Performer’s Telephone No.</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getSocialSecurityNumber()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getPerformerPhoneNumber()}]]</td>
            <td></td>
        </tr>
    </table>
    <p>
        Producer hereby engages Employer to cause Performer to reader services as an actor in the above role in the Picture on the terms set forth above. This engagement is subject to the provisions printed below and ON THE REVERSE SIDE and all provisions in the applicable “PRODUCER-SCREEN ACTORS GUILD CODIFIED BASIC AGREEMENT” (the “SAG Agreement).
    </p>
    <p>
        SAG Pension and Health Plans: Producer shall pay, as agent for Employer, so the SAG Pension and Health Plan the employer contributions required under the SAG Agreement by reason of Performer’s service hereunder; provided, however, that the amount of such contributions shall not exceed the amount of the Pension and Health Plan contributions which Producer would have been required to pay lead Producer employed Performer directly for the service hereunder at the rates of compensation provided for herein.
    </p>
    <p>
        Employer and Performer hereby consent to Performer’s flying on charter flights for this engagement.
    </p>
    <p>
        Employer agrees to accept the sum properly computed based upon the times and the basic wage rate shown above as payment in full for all services rendered by Performer in the Picture referred to herein. It is further agreed that checks be addressed to Employer at the last reported address and deposited in the Unites States mail within five (5) days (excluding Saturday, Sunday and Holidays) following completion of Performer’s workweek.
    </p>
    <p>
        Employer (does) (does not) hereby authorize Producer to deduct from the compensation hereinabove specified, an amount equal to __________ percent of each installment of compensation due to Employer hereunder, and to pay the amount so deducted to the Motion Picture and Television Relief Fund, Inc. Performer agrees to furnish all modern wardrobe and wearing apparel reasonably necessary for the portrayal of said role; it being agreed, however, that should so-called “character” or “period” costumes be required, Producer shall supply same. Should any dispute or controversy arise between the parties hereto with reference to this Agreement, or the engagement herein provided for, such dispute or controversy shall be settled and determined by conciliation and arbitration in accordance with the conciliation and arbitration provisions of the SAG Agreement and such provisions are hereby referred to and by such reference incorporated herein and made a part of this Agreement with the same effect as though same were set forth herein in detail.
    </p>
    <p>
        It is further agreed that in the event of retakes of all or any of the scenes in which Performer participates or if additional scenes are required (whether originally contemplated or not) Performer will return to work and render services in such scenes at the same basic rate of compensation as that set forth above. By countersigning this Agreement, Performer agrees to be bound hereby and confirms and joins in all grants and XXX services herein provided for, to look solely to Employer for compensation for such services, and to indemnify XXX applicable hereto.
    </p>
    <table border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td>[[${data.getLoanoutCo()}]]</td>
            <td>[[${data.getProductionCompany()}]]</td>
        </tr>
        <tr>
            <td>EMPLOYER</td>
            <td>PRODUCER</td>
        </tr>
        <tr>
            <td>By:_____________________________________</td>
            <td>By:_____________________________________</td>
        </tr>
        <tr>
            <td>   In</td>
            <td>   [[${data.getSignatoryTitle()}]]</td>
        </tr>
        <tr>
            <td>By:_____________________________________</td>
            <td></td>
        </tr>
        <tr>
            <td>   Performer: [[${data.getPerformerName()}]]</td>
            <td></td>
        </tr>
    </table>

</body>
</html>'; 
    i                   INT; 
BEGIN 
    WHILE Length(contractTemplate) <= 6000 LOOP 
        contractTemplate := contractTemplate 
                               || ' '; 
    END LOOP; 
	select id into i from FC_LOOKUP where name='Loanout of a Day Performer';

Insert into FC_CONTRACT_TEMPLATE (ID,CONTRACT_NAME,CREATED_BY,CREATE_DATE,CONTRACT_LOOKUP_ID,TEXT) values (DBO_FC.FC_CONTRACT_TEMPLATE_ID_SEQ.nextval,'LOANOUT_OF_A_DAY_PERFORMER','AmitS',sysdate,i,contractTemplate);

    dbms_output.Put_line('I have finished inputting your clob: ' 
                         || Length(contractTemplate)); 
commit;                         
END; 
