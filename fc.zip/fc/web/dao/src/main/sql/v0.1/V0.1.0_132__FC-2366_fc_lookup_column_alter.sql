-- add temp column to hold existing data in new datatype
ALTER TABLE DBO_FC.FC_LOOKUP ADD (DISPLAY_ORDER_TEMP NUMBER); 
-- move existing data to new column
UPDATE DBO_FC.FC_LOOKUP SET DISPLAY_ORDER_TEMP = DISPLAY_ORDER; 
-- remove old column with wrong dataType
ALTER TABLE DBO_FC.FC_LOOKUP DROP COLUMN DISPLAY_ORDER; 
-- rename new column with data in it to correct column name.
ALTER TABLE DBO_FC.FC_LOOKUP RENAME COLUMN DISPLAY_ORDER_TEMP TO DISPLAY_ORDER; 