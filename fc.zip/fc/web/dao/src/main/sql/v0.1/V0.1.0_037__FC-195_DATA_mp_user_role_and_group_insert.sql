Declare
  difference INTEGER;
  sqlstmt varchar2(255);
  sequenceValue Number;
begin
sqlstmt := 'ALTER SEQUENCE DBO_MP.SEQ_GROUP_ID INCREMENT BY ';
select DBO_MP.SEQ_GROUP_ID.NEXTVAL into sequenceValue from dual;
select  (nvl(Max(GROUP_ID),0) - sequenceValue)+1 into difference from DBO_MP.USER_GROUP;
if difference > 0 then
  EXECUTE IMMEDIATE sqlstmt || difference;
  select  DBO_MP.SEQ_GROUP_ID.NEXTVAL INTO sequenceValue from dual;
  EXECUTE IMMEDIATE sqlstmt || 1;
end if;
end;
/

--Insert feature casting user group and roles
insert into DBO_MP.USER_GROUP(GROUP_ID, GROUP_NAME, SELECTED_IND, LAST_UPDATE_TS, LAST_UPDATE_USER)
values(DBO_MP.SEQ_GROUP_ID.nextval, 'Feature Casating Group', 'N', SYSTIMESTAMP, 'JeffreyL');


insert into DBO_MP.USER_ROLE(ROLE_ID, GROUP_ID, ROLE_NAME, DISPLAY_ORDER, SELECTED_IND, LAST_UPDATE_TS1, LAST_UPDATE_USER1)
values(DBO_MP.SEQ_ROLE_ID.nextval, DBO_MP.SEQ_GROUP_ID.currval, 'Feature Casting Administrator', 1, 'N', SYSTIMESTAMP, 'JeffreyL');

insert into DBO_MP.USER_ROLE(ROLE_ID, GROUP_ID, ROLE_NAME, DISPLAY_ORDER, SELECTED_IND, LAST_UPDATE_TS1, LAST_UPDATE_USER1)
values(DBO_MP.SEQ_ROLE_ID.nextval, DBO_MP.SEQ_GROUP_ID.currval, 'Feature Casting Owner', 1, 'N', SYSTIMESTAMP, 'JeffreyL');

insert into DBO_MP.USER_ROLE(ROLE_ID, GROUP_ID, ROLE_NAME, DISPLAY_ORDER, SELECTED_IND, LAST_UPDATE_TS1, LAST_UPDATE_USER1)
values(DBO_MP.SEQ_ROLE_ID.nextval, DBO_MP.SEQ_GROUP_ID.currval, 'Feature Casting Guest', 1, 'N', SYSTIMESTAMP, 'JeffreyL');