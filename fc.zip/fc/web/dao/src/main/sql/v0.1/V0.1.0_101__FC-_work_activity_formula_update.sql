update DBO_FC.FC_FORMULA_DETAIL set field_name = 'startDate' where FORMULA_ID in (select id from DBO_FC.FC_FORMULA where DEAL_TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'DEAL_TYPE' and name = 'DEAL') and TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'WIZARD_PAGE' and name = 'Work Activity') ) and table_name = 'FC_WORK_ACTIVITY' and table_field_name = 'START_DATE';

update DBO_FC.FC_FORMULA_DETAIL set field_name = 'activityLookupId' where FORMULA_ID in (select id from DBO_FC.FC_FORMULA where DEAL_TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'DEAL_TYPE' and name = 'DEAL') and TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'WIZARD_PAGE' and name = 'Work Activity') ) and table_name = 'FC_WORK_ACTIVITY' and table_field_name = 'ACTIVITY_LOOKUP_ID';

update DBO_FC.FC_FORMULA_DETAIL set field_name = 'description' where FORMULA_ID in (select id from DBO_FC.FC_FORMULA where DEAL_TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'DEAL_TYPE' and name = 'DEAL') and TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'WIZARD_PAGE' and name = 'Work Activity') ) and table_name = 'FC_WORK_ACTIVITY' and table_field_name = 'DESCRIPTION';


update DBO_FC.FC_FORMULA_DETAIL set field_name = 'guranteeLookupId' where FORMULA_ID in (select id from DBO_FC.FC_FORMULA where DEAL_TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'DEAL_TYPE' and name = 'DEAL') and TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'WIZARD_PAGE' and name = 'Work Activity') ) and table_name = 'FC_WORK_ACTIVITY' and table_field_name = 'GUARANTEE_LOOKUP_ID';


update DBO_FC.FC_FORMULA_DETAIL set field_name = 'princFreeLookupId' where FORMULA_ID in (select id from DBO_FC.FC_FORMULA where DEAL_TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'DEAL_TYPE' and name = 'DEAL') and TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'WIZARD_PAGE' and name = 'Work Activity') ) and table_name = 'FC_WORK_ACTIVITY' and table_field_name = 'PRINCIPAL_FREE_LOOKUP_ID';


update DBO_FC.FC_FORMULA_DETAIL set field_name = 'postFreeLookupId' where FORMULA_ID in (select id from DBO_FC.FC_FORMULA where DEAL_TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'DEAL_TYPE' and name = 'DEAL') and TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'WIZARD_PAGE' and name = 'Work Activity') ) and table_name = 'FC_WORK_ACTIVITY' and table_field_name = 'POST_FREE_LOOKUP_ID';


update DBO_FC.FC_FORMULA_DETAIL set field_name = 'note' where FORMULA_ID in (select id from DBO_FC.FC_FORMULA where DEAL_TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'DEAL_TYPE' and name = 'DEAL') and TYPE_LOOKUP_ID = (select id from DBO_FC.FC_LOOKUP where Type = 'WIZARD_PAGE' and name = 'Work Activity') ) and table_name = 'FC_WORK_ACTIVITY' and table_field_name = 'NOTE';

commit;