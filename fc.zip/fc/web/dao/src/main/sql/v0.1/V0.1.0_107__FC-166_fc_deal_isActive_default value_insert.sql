--adding column for active deal in the deal table
UPDATE DBO_FC.FC_DEAL SET is_Active = 'Y' where is_Active = null;
