
DECLARE

  var_post_pro NUMBER;
  var_pro NUMBER;
  var_lookup_id NUMBER;
--val.attribute_value IN ('Production', 'Post-Production', 'Pre-Production');
BEGIN

  select val.DYNAMIC_ATTRIBUTE_VALUES_ID INTO var_post_pro
    FROM DBO_MP.DYNAMIC_ATTRIBUTE_VALUES val where val.ATTRIBUTE_DISP_VAL = 'Post-Production' and val.DYNAMIC_ATTRIBUTE_ID = (select a.DYNAMIC_ATTRIBUTE_ID from DBO_MP.DYNAMIC_ATTRIBUTE a where a.DYNAMIC_ATTRIBUTE_MODULE = 'FEATURE_CASTING') ;
    
     select val.DYNAMIC_ATTRIBUTE_VALUES_ID INTO var_pro
    FROM DBO_MP.DYNAMIC_ATTRIBUTE_VALUES val where val.ATTRIBUTE_DISP_VAL = 'Production' and val.DYNAMIC_ATTRIBUTE_ID = (select a.DYNAMIC_ATTRIBUTE_ID from DBO_MP.DYNAMIC_ATTRIBUTE a where a.DYNAMIC_ATTRIBUTE_MODULE = 'FEATURE_CASTING') ;

select lok.ID INTO var_lookup_id FROM DBO_FC.FC_LOOKUP lok where lok.NAME = 'PROJECT_STATUS' and lok.TYPE = 'PROJECT_FIELD_TYPE' ;
 
    INSERT
    INTO DBO_FC.FC_DYNAMIC_ATTRIBUTE_VALS_ADMN
      (
        ID,
        DYNAMIC_ATTRIBUTE_VALUES_ID,
        TYPE_LOOKUP_ID,
        CREATED_BY,
        UPDATED_BY,
        CREATE_DATE,
        UPDATE_DATE
      ) select DBO_FC.FC_DYNMC_ATRBT_VLS_ADMN_ID_SEQ.nextval, var_post_pro, var_lookup_id, 'JeffreyL', 'JeffreyL', SYSDATE, SYSDATE  from dual where not exists(select * from DBO_FC.FC_DYNAMIC_ATTRIBUTE_VALS_ADMN a where (a.TYPE_LOOKUP_ID = var_lookup_id and a.DYNAMIC_ATTRIBUTE_VALUES_ID = var_post_pro));
  
  
   INSERT
    INTO DBO_FC.FC_DYNAMIC_ATTRIBUTE_VALS_ADMN
      (
        ID,
        DYNAMIC_ATTRIBUTE_VALUES_ID,
        TYPE_LOOKUP_ID,
        CREATED_BY,
        UPDATED_BY,
        CREATE_DATE,
        UPDATE_DATE
      ) select DBO_FC.FC_DYNMC_ATRBT_VLS_ADMN_ID_SEQ.nextval, var_pro, var_lookup_id, 'JeffreyL', 'JeffreyL', SYSDATE, SYSDATE  from dual where not exists(select * from DBO_FC.FC_DYNAMIC_ATTRIBUTE_VALS_ADMN a where (a.TYPE_LOOKUP_ID = var_lookup_id and a.DYNAMIC_ATTRIBUTE_VALUES_ID = var_pro));
  
  
END;