
DECLARE 
    contractTemplate CLOB := '<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <style>
        th {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        td {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        p {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        @media print {
            footer {
                page-break-after: always;
            }
        }
    </style>
</head>
<body>
    <h3 style="text-align: center;"><strong>LOANOUT OF A DAY PERFORMER</strong></h3>
    <p>&nbsp;</p>
    <table style="width: 90%; margin-left: auto; margin-right: auto;" border="0" cellspacing="0" cellpadding="0">
        <tbody>
            <tr>
                <th style="text-align: left;">Picture:</th>
                <th style="text-align: left;">Employer:</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getProjectName()}]]</td>
                <td style="padding-left: 30px;">[[${data.getLoanoutCompany()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <td>Deal Date:</td>
                <td>State of Incorporation &amp; Federal I.D. No.#:</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getDealDate()}]]</td>
                <td style="padding-left: 30px;">[[${data.getEIN()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Start Date:</th>
                <th style="text-align: left;">Performer:</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getEndDate()}]]</td>
                <td style="padding-left: 30px;">[[${data.getPerformerName()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Role:</th>
                <th style="text-align: left;">Performer&rsquo;s Social Security #.:</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getRole()}]]</td>
                <td style="padding-left: 30px;">[[${data.getSocialSecurityNumber()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Daily Rate:</th>
                <th style="text-align: left;">Contract Address:</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getRate()}]]</td>
                <td style="padding-left: 30px;">[[${data.getContractAddress()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Producer:</th>
                <th style="text-align: left;">Agent:</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getProductionCompany()}]]</td>
                <td style="padding-left: 30px;">[[${data.getRepName()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Producer&rsquo;s Address:</th>
                <th style="text-align: left;">Performer&rsquo;s Telephone No.:</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getProducerAddress()}]]</td>
                <td style="padding-left: 30px; vertical-align: top;">[[${data.getPerformerPhoneNumber()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px; vertical-align: top;">&nbsp;</td>
            </tr>
        </tbody>
    </table>
    <p>&nbsp;</p>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 100%;">
                    <p>Producer hereby engages Employer to cause Performer to render services as an actor in the above role in the Picture on the terms set forth above. The engagement is subject to the provisions stated herein.</p>
                    <p>Employer agrees to accept the sum properly computed based upon the time and the basic wage rate shown above as payment in full for all services rendered by Performer in the Picture referred to herein. It is further agreed that checks be addressed to Employer at the last reported address and deposited in the United States mail within five (5) days (excluding Saturday, Sunday and Holidays) following completion of Performer&rsquo;s workweek.</p>
                </td>
            </tr>
        </tbody>
    </table>
    <p>&nbsp;</p>
    <p id="footer" style="text-align: center;"><!-- pagebreak --></p>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 100%;">
                    <p style="text-align: center;"><strong>ADDITIONAL TERMS AND CONDITIONS</strong></p>
                    <p style="text-indent: 30px;">A. <strong>Ownership and Rights Granted.</strong> The results and proceeds of Performer&rsquo;s service are or shall be deemed a work made for hire for Producer. Without limiting the foregoing, Producer and its licensees, successors and assigns shall own, and Employer and Performer hereby assigns to Producer, forever and throughout the universe, all rights of every kind and nature whatsoever in and to the results and proceeds of Performer&rsquo;s services (inclusive of, by way of example, all work done and all poses, acts, plays, and appearances made by Performer hereunder) and all copyrights pertaining thereto and extensions and renewals thereof, including without limitation the right to exploit in any manner and through any media now known or hereafter devised (including by way of illustration all rental, lending and other rights of communication to the public) any and all such results and proceeds. 3.8% of the compensation paid under this Agreement shall be deemed allocated to, and equitable remuneration for, said rental and lending rights. Neither the expiration nor&nbsp;termination of this Agreement shall affect Producer&rsquo;s ownership of the results and proceeds of Performer&rsquo;s services or Producer&rsquo;s other rights hereunder.</p>
                    <p style="text-indent: 30px;">B. <strong>Services Unique.</strong> Performer&rsquo;s services and the rights granted to Producer under this Agreement are of a special, unique, unusual, extraordinary and intellectual character giving them a peculiar value, the loss of which cannot be reasonably or adequately compensated in damages in any action at law. A breach hereof by Performer and/or Employer shall cause Producer irreparable injury and Producer shall be entitled to injunctive and other equitable relief to secure enforcement of this Agreement, but resort to such relief shall not limit Producer&rsquo;s other rights.</p>
                    <p style="text-indent: 30px;">C. <strong>Pay or Play.</strong> Producer is not obligated in any manner actually to utilize Performer&rsquo;s services or the results and proceeds thereof or to producer, exhibit or otherwise exploit the Picture, or to exercise any of the rights granted to Producer hereunder. Producer shall have fully discharged its obligations hereunder by Payment of the fixed compensation for the minimum period provided for in this Agreement, subject to Producer&rsquo;s rights and remedies at law, in equity.</p>
                    <p style="text-indent: 30px;">D. <strong>No Injunctive Relief.</strong> It is acknowledged that the rights and remedies in the event of a breach or alleged breach of this Agreement by Producer (including without limitation the provisions of Paragraph F hereof) shall be strictly limited to the right, if any, to recover damages in accordance with the arbitration procedures set forth below (it being acknowledged that payment of such damages are an adequate remedy) and there shall be no right by reason of any such breach to rescind this Agreement, or to restrain Producer&rsquo;s exercise of any of the rights granted to Producer hereunder.</p>
                    <p style="text-indent: 30px;">E. <strong>Insurance.</strong> If Producer requests, Performer shall assist Producer in securing customary insurance by submitting to customary medical examinations and by signing such instruments as may be reasonably required in connection therewith. In the event Performer fails to qualify for such insurance at customary rates and on other customary terms, Producer shall have the right to terminate this Agreement without further obligations.</p>
                    <p style="text-indent: 30px;">F. <strong>Right to Work.</strong> Producer may terminate this Agreement without further obligation if any work permits, visas, or proof of Performer&rsquo;s right to work required in connection with Performer&rsquo;s services cannot be obtained in a timely fashion. Whether or not Producer in Producer&rsquo;s discretion agreed to obtain such work permits or visas for Performer, the responsibility therefore shall rest with Performer and/or Employer.</p>
                    <p style="text-indent: 30px;">G. <strong>Rules and Regulations.</strong> (a) No personal photography or audio/visual recording is permitted on sets or in work areas. Any and all photographs and recordings made or caused to be made by Performer and/or Employer on Producer&rsquo;s sets or in other work areas shall be the property of Producer; (b) Neither Performer nor Employer shall disclose any information concerning the Picture to individuals outside the production without the prior consent of Producer; (c) Transportation to and from overnight locations shall be provided by Producer; personal transportation may not be used; (d) Performer must pay in advance (by check or credit card) for personal travel or shipping arranged as a courtesy to Performer by the production office; (e) Performer and Employer will be responsible for, and promptly pay or reimburse Producer on demand for, any unsettled hotel incidents personally incurred by Performer, or any unreconciled petty cash advances.</p>
                    <p style="text-indent: 30px;">H. <strong>Loan-out.</strong> Employer warrants that: Employer is a bona fide corporate business entity duly established for a valid business purpose within the meaning of the tax laws of the United States; and Performer is under an exclusive contract of employment with Employer, which contract gives Employer the right to loan or furnish&nbsp;Producer Performer&rsquo;s services during the term hereof. For the purposes of any applicable Workers&rsquo; Compensation statute, an employment relationship exists between Producer and Performer, Producer being Performer&rsquo;s special employer hereunder and Employer being Performer&rsquo;s general employer (as the terms &ldquo;special employer&rdquo; and &ldquo;general employer&rdquo; are understood for purposes of Workers&rsquo; Compensation statutes). As between Employer and Producer, Producer shall have the exclusive right to direct and control the performance of Performer&rsquo;s services hereunder. If the applicability of any Workers&rsquo; Compensation statutes to the engagement of Performer&rsquo;s services hereunder is dependent upon an election on the part of Employer, Performer and/or Producer, such election is hereby made in favor of such application.</p>
                    <p style="text-indent: 30px;">I. <strong>Arbitration.</strong> Any and all disputes arising out of this Agreement shall be resolved solely by final and binding arbitration in accordance with JAMS Arbitration Rules and Procedures, except as modified herein (&ldquo;Arbitration Rules&rdquo;). The arbitration shall be conducted in Los Angeles County, California before a single neutral arbitrator who is a retired judge or justice from a California state or federal court appointed in accordance with the Arbitration Rules. The arbitrator shall apply California law and the Federal Rules of Evidence in adjudicating the dispute. The parties and the arbitrator(s) shall treat the arbitration, any party submissions and disclosures therein and any award and orders as confidential, except as necessary to enforce an award or as otherwise required by law.<br /><br />By countersigning this Agreement, Employer and Performer agree to be bound hereby and confirm and join in all grants and warranties made by Employer and Performer, and agree to render services herein provided for, to look solely to Employer for compensation for such services, and to indemnify Producer against liability for withholding and payroll taxes applicable hereto.</p>
                </td>
            </tr>
        </tbody>
    </table>
    <p>&nbsp;</p>
    <table style="width: 90%; margin-left: auto; margin-right: auto;" border="0" cellspacing="0" cellpadding="0">
        <tbody>
            <tr>
                <td><span style="letter-spacing: normal;">EMPLOYMENT ACCEPTED: </span></td>
                <td><span style="letter-spacing: normal;">&nbsp;</span></td>
            </tr>
            <tr>
                <td><span style="letter-spacing: normal;">[[${data.getLoanoutCompany()}]] </span></td>
                <td><span style="letter-spacing: normal;">[[${data.getProductionCompany()}]] </span></td>
            </tr>
            <tr>
                <td><span style="letter-spacing: normal;">&nbsp;</span></td>
                <td><span style="letter-spacing: normal;">&nbsp;</span></td>
            </tr>
            <tr>
                <td><span style="letter-spacing: normal;">EMPLOYER:</span></td>
                <td><span style="letter-spacing: normal;">PRODUCER:</span></td>
            </tr>
            <tr>
                <td><span style="letter-spacing: normal;">By:_____________________________________ </span></td>
                <td><span style="letter-spacing: normal;">By:_____________________________________ </span></td>
            </tr>
            <tr>
                <td><span style="letter-spacing: normal;">&nbsp;</span></td>
                <td><span style="letter-spacing: normal;">[[${data.getSignatoryTitle()}]] </span></td>
            </tr>
            <tr>
                <td><span style="letter-spacing: normal;">COUNTERSIGNED:</span></td>
                <td><span style="letter-spacing: normal;">&nbsp;</span></td>
            </tr>
            <tr>
                <td><span style="letter-spacing: normal;">By:_____________________________________ </span></td>
                <td><span style="letter-spacing: normal;">&nbsp;</span></td>
            </tr>
            <tr>
                <td style="padding-left: 30px;"><span style="letter-spacing: normal;">Performer: [[${data.getPerformerName()}]]</span></td>
                <td style="padding-left: 30px;"><span style="letter-spacing: normal;">&nbsp;</span></td>
            </tr>
        </tbody>
    </table>
</body>
</html>'; 
    i                   INT; 
BEGIN 
    WHILE Length(contractTemplate) <= 6000 LOOP 
        contractTemplate := contractTemplate 
                               || ' '; 
    END LOOP; 
	select id into i from FC_LOOKUP where name='Non-Union Day Performer Agreement (Loanout)';

Insert into FC_CONTRACT_TEMPLATE (ID,CONTRACT_NAME,CREATED_BY,CREATE_DATE,CONTRACT_LOOKUP_ID,TEXT) values (DBO_FC.FC_CONTRACT_TEMPLATE_ID_SEQ.nextval,'NON_UNION_DAY_PERFORMER_LOANOUT','ShashankR',SYSDATE,i,contractTemplate);

    dbms_output.Put_line('I have finished inputting your clob: ' 
                         || Length(contractTemplate)); 
commit;                         
END; 
