DECLARE
TYPE proj_status_array IS VARRAY(2) OF VARCHAR2(300);
var_proj_status proj_status_array;
var_attribute_values NUMBER;
BEGIN
	--add new additional FC exclusive Project Statuses
  var_proj_status := proj_status_array('Post Production','Production');

  --insert DYNAMIC ATTRIBUTE for Project status
  SELECT a.DYNAMIC_ATTRIBUTE_ID INTO var_attribute_values from DBO_MP.DYNAMIC_ATTRIBUTE a where a.DYNAMIC_ATTRIBUTE_TYPE= 'PROJ_STATUS' and a.DYNAMIC_ATTRIBUTE_MODULE = 'FEATURE_CASTING';
    
  FOR i in 1..var_proj_status.count
    LOOP
    
  INSERT
  INTO DBO_MP.DYNAMIC_ATTRIBUTE_VALUES
    (
      DYNAMIC_ATTRIBUTE_VALUES_ID,
      DYNAMIC_ATTRIBUTE_ID,
      ATTRIBUTE_ACTIVE_IND,
      ATTRIBUTE_VALUE,
      ATTRIBUTE_DISP_VAL,
      ATTRIBUTE_CONVERTERVALUES,
      ATTRIBUTE_DELETE_IND,
      LAST_UPDATE_TS,
      LAST_UPDATE_USER
    )
    VALUES
    (
      DBO_MP.SEQ_DYNAMIC_ATTR_VAL_ID.nextval,
      var_attribute_values,
      'Y',
      var_proj_status(i),
      var_proj_status(i),
      var_proj_status(i),
      'N',
      SYSTIMESTAMP,
      'JeffreyL'
    );
    END LOOP;
    END;
  