
DECLARE
var_drop_down NUMBER;

BEGIN

select lk.id
into var_drop_down
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'DROP_DOWN' and lk.TYPE = 'FIELD_TYPE';


update DBO_FC.FC_FORMULA_DETAIL d set d.VALUE = 'PLUS_OR_MINUS_TYPE' where d.TABLE_FIELD_NAME = 'INTERVAL' and d.FIELD_TYPE_LOOKUP_ID = 119;
update DBO_FC.FC_FORMULA_DETAIL d set d.VALUE = 'PRINCIPAL_FREE_TYPE' where d.TABLE_FIELD_NAME = 'prinicpal_free_interval' and d.FIELD_TYPE_LOOKUP_ID = var_drop_down;
update DBO_FC.FC_FORMULA_DETAIL d set d.VALUE = 'POST_FREE_TYPE' where d.TABLE_FIELD_NAME = 'post_free_interval' and d.FIELD_TYPE_LOOKUP_ID = var_drop_down;

END;