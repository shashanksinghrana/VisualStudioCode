--adding column for active deal in the deal table
ALTER TABLE DBO_FC.FC_DEAL ADD is_Active CHAR(1) DEFAULT ('Y') NOT NULL;
