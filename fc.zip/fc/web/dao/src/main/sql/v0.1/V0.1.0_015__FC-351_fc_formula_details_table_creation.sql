CREATE TABLE DBO_FC.FC_FORMULA_DETAIL (
                id NUMBER NOT NULL,
                formula_id NUMBER NOT NULL,
                display_name VARCHAR2(50),
                field_type_lookup_id NUMBER,
                value VARCHAR2(500),
                order_num NUMBER,
                group_type_lookup_id NUMBER,
                table_name VARCHAR2(50),
                table_field_name VARCHAR2(500),
                validation_expression VARCHAR2(500),
                depends_on_order_num VARCHAR2(50),
                required_flag VARCHAR2(1),
                summary_group_type_lookup_id NUMBER,
                summary_order NUMBER,
                update_date DATE,
                updated_by VARCHAR2(50),
                create_date DATE,
                created_by VARCHAR2(50),
                CONSTRAINT PK_FC_FORMULA_DETAIL_ID PRIMARY KEY (id)
);

-- TABLE GRANT TO APP_FC
GRANT ALL ON DBO_FC.FC_FORMULA_DETAIL to APP_FC;
CREATE OR REPLACE SYNONYM APP_FC.FC_FORMULA_DETAIL FOR DBO_FC.FC_FORMULA_DETAIL;

--SEQUENCE FOR FC_FORMULA_DETAIL TABLE
CREATE SEQUENCE DBO_FC.FC_FORMULA_DETAIL_ID_SEQ MINVALUE 1 MAXVALUE 999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE;
GRANT ALL ON DBO_FC.FC_FORMULA_DETAIL_ID_SEQ TO APP_FC;

--FOREIGN KEY CREATION
ALTER TABLE DBO_FC.FC_FORMULA_DETAIL ADD CONSTRAINT FC_FORMULA_DETAIL_FCFORMULA_FK
FOREIGN KEY (formula_id)
REFERENCES DBO_FC.FC_FORMULA (id);

ALTER TABLE DBO_FC.FC_FORMULA_DETAIL ADD CONSTRAINT FCFORMULA_DETAIL_FCLOOKUP_FK00
FOREIGN KEY (field_type_lookup_id)
REFERENCES DBO_FC.FC_LOOKUP (id);

ALTER TABLE DBO_FC.FC_FORMULA_DETAIL ADD CONSTRAINT FCFORMULA_DETAIL_FCLOOKUP_FK01
FOREIGN KEY (group_type_lookup_id)
REFERENCES DBO_FC.FC_LOOKUP (id);

ALTER TABLE DBO_FC.FC_FORMULA_DETAIL ADD CONSTRAINT FCFORMULA_DETAIL_FCLOOKUP_FK02
FOREIGN KEY (summary_group_type_lookup_id)
REFERENCES DBO_FC.FC_LOOKUP (id);
