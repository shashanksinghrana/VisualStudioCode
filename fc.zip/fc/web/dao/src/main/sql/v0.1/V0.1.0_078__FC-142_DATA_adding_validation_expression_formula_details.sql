-- adding validation to amount an number field formula columns
SET DEFINE OFF;
DECLARE 
var_amount_field NUMBER;
var_number_field NUMBER;

BEGIN

select lk.id
into var_amount_field
from DBO_FC.FC_LOOKUP lk
where lk.TYPE = 'FIELD_TYPE' and lk.NAME = 'AMOUNT_FIELD';

select lk.id
into var_number_field
from DBO_FC.FC_LOOKUP lk
where lk.TYPE = 'FIELD_TYPE' and lk.NAME = 'NUMBER_FIELD';

--set amount field validation
UPDATE DBO_FC.FC_FORMULA_DETAIL d set d.VALIDATION_EXPRESSION = '^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$' where d.FIELD_TYPE_LOOKUP_ID = var_amount_field;

--set number field validation
UPDATE DBO_FC.FC_FORMULA_DETAIL d set d.VALIDATION_EXPRESSION = '^[1-9]\d*$' where d.FIELD_TYPE_LOOKUP_ID = var_number_field;

END;
