CREATE OR REPLACE SYNONYM APP_FC.seq_party_id FOR DBO_TC.seq_party_id;
grant all on DBO_TC.seq_party_id to APP_FC;