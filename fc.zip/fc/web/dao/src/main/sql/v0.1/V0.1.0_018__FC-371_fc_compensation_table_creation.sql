CREATE TABLE DBO_FC.FC_COMPENSATION (
                id NUMBER NOT NULL,
                deal_id NUMBER NOT NULL,
                guarantee_number NUMBER NOT NULL,
                guarantee_type VARCHAR2(100) NOT NULL,
                fee_type_id NUMBER NOT NULL,
                rate_value NUMBER NOT NULL,
                descript VARCHAR2(1),
                start_date DATE,
                update_date DATE,
                period_id NUMBER NOT NULL,
                created_by VARCHAR2(50),
                interval VARCHAR2(100) NOT NULL,
                contract_returned_date DATE,
                contract_revisied_date DATE,
                contract_info VARCHAR2(100),
                total_amount NUMBER NOT NULL,
                contract_text VARCHAR2(250),
                contract_sent_date DATE,
                void_flag VARCHAR2(1),
                principal_free NUMBER NOT NULL,
                prinicpal_free_inteval VARCHAR2(100) NOT NULL,
                updated_by VARCHAR2(50),
                post_free NUMBER NOT NULL,
                post_free_interval VARCHAR2(100) NOT NULL,
                adjustment_interval NUMBER NOT NULL,
                create_date DATE,
                start_date_qualifier NUMBER,
                CONSTRAINT PK_FC_COMPENSATION PRIMARY KEY (id)
);

-- TABLE GRANT TO APP_FC
GRANT ALL ON DBO_FC.FC_COMPENSATION to APP_FC;
CREATE OR REPLACE SYNONYM APP_FC.FC_COMPENSATION FOR DBO_FC.FC_COMPENSATION;

--SEQUENCE FOR FC_COMPENSATION_ID TABLE
CREATE SEQUENCE DBO_FC.FC_COMPENSATION_ID_SEQ MINVALUE 1 MAXVALUE 999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE;
GRANT ALL ON DBO_FC.FC_COMPENSATION_ID_SEQ TO APP_FC;

--Foreign Keys for FC_COMPENSATION TABLE
ALTER TABLE DBO_FC.FC_COMPENSATION ADD CONSTRAINT FC_COMPENSATION_FC_LOOKUP_FK
FOREIGN KEY (start_date_qualifier)
REFERENCES DBO_FC.FC_LOOKUP (id);

ALTER TABLE DBO_FC.FC_COMPENSATION ADD CONSTRAINT FC_COMPENSATION_FC_DEAL_FK
FOREIGN KEY (deal_id)
REFERENCES DBO_FC.FC_DEAL (id);