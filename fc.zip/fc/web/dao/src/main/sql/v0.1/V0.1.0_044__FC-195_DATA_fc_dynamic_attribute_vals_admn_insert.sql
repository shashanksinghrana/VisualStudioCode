-- insert FC lookup type for project types
INSERT
INTO DBO_FC.FC_LOOKUP
  (
    ID,
    NAME,
    TYPE,
    DISPLAY_ORDER,
    CREATE_DATE,
    UPDATE_DATE,
    CREATED_BY,
    UPDATED_BY
  )
  VALUES
  (
    DBO_FC.FC_LOOKUP_ID_SEQ.nextval,
    'PROJECT_STATUS',
    'PROJECT_FIELD_TYPE',
    0,
    SYSDATE,
    SYSDATE,
    'JeffreyL',
    'JeffreyL'
  );
DECLARE
  counter NUMBER := 0;
  CURSOR statuses
  IS
    SELECT val.DYNAMIC_ATTRIBUTE_VALUES_ID
    FROM DBO_MP.DYNAMIC_ATTRIBUTE_VALUES val
    WHERE val.DYNAMIC_ATTRIBUTE_ID IN
      (SELECT att.DYNAMIC_ATTRIBUTE_ID
      FROM DBO_MP.DYNAMIC_ATTRIBUTE att
      WHERE att.DYNAMIC_ATTRIBUTE_MODULE = 'FEATURE_CASTING'
      )
  OR val.attribute_value IN ('Production', 'Post-Production', 'Pre-Production');
BEGIN
  FOR stat IN statuses
  LOOP
    INSERT
    INTO DBO_FC.FC_DYNAMIC_ATTRIBUTE_VALS_ADMN
      (
        ID,
        DYNAMIC_ATTRIBUTE_VALUES_ID,
        TYPE_LOOKUP_ID,
        DISPLAY_ORDER,
        CREATED_BY,
        UPDATED_BY,
        CREATE_DATE,
        UPDATE_DATE
      )
      VALUES
      (
        DBO_FC.FC_DYNMC_ATRBT_VLS_ADMN_ID_SEQ.nextval,
        stat.DYNAMIC_ATTRIBUTE_VALUES_ID,
        DBO_FC.FC_LOOKUP_ID_SEQ.currval,
        counter,
        'JeffreyL',
        'JeffreyL',
        SYSDATE,
        SYSDATE
      );
    counter := counter + 1;
  END LOOP;
END;