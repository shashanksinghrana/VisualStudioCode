--------------------------------------------------------
--  File created - Monday-August-20-2018   
--------------------------------------------------------
INSERT INTO FC_LOOKUP(ID, NAME, TYPE, DISPLAY_ORDER, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval,'SAG-Employment of a Day Performer', 'CONTRACT', 1, SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL');

INSERT INTO FC_LOOKUP(ID, NAME, TYPE, DISPLAY_ORDER, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval,'SAG-Minimum Freelance Contract', 'CONTRACT', 2, SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL');

INSERT INTO FC_LOOKUP(ID, NAME, TYPE, DISPLAY_ORDER, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY) values(DBO_FC.FC_LOOKUP_ID_SEQ.nextval,'Non-Union – Employment of a Day Performer', 'CONTRACT', 3, SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL');
