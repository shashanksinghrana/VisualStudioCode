
DECLARE 
    contractTemplate CLOB := '<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>

    <table border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td colspan="2">Producer</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Production No.</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getProductionCompany()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getProductionNumber()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Producer’s Address</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Deal Date</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getProducerAddress()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getDealDate()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Performer</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td></td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getPerformerName()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Engagement Starts</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Contract Address</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getEndDate()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td rowspan="5">[[${data.getContractAddress()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Role</td>
            <td></td>
            <td width="10%"></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getRole()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Picture</td>
            <td></td>
            <td width="10%"></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getProjectName()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Social Security No.</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Agent</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getSocialSecurityNumber()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getRepName()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Daily Rate</td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Telephone No.</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td>[[${data.getDailyRate()}]]</td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getPerformerPhoneNumber()}]]</td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td></td>
            <td width="10%"></td>
            <td colspan="2">Weekly Conversion Rate</td>
            <td></td>
        </tr>
        <tr>
            <td width="5%"></td>
            <td></td>
            <td></td>
            <td width="10%"></td>
            <td width="5%"></td>
            <td>[[${data.getWeeklyConversionRate()}]]</td>
            <td></td>
        </tr>
    </table>
    <p>
        Producer hereby employs Performer [[${data.getPerformerName()}]] in the above role in the Picture on the terms set forth above. The engagement is subject to the provisions printed below and ON THE REVERSE SIDE and all provisions in the applicable “PRODUCER-SCREEN ACTORS GUILD CODIFIED BASIC AGREEMENT” (the “SAG Agreement”. Performer hereby consents to fly on charter flights for this engagement.
    </p>
    <p>
        Performer agrees to accept the sum properly computed based upon the times and the basic wage rate shown above as payment in full for all services rendered by Performer in the Picture referred to herein. It is further agreed that said sum, less all deductions required by law, may be paid to Performer by negotiable check, said check to be addressed to Performer at the last reported address and deposited in the United States mail within five (5) days (excluding Saturday, Sunday and Holidays) following the completion of Performer’s workweek.
    </p>
    <p>
        Performer (does) (does not) hereby authorize Producer to deduct from the compensation here in above specified, an amount equal to Picture and Television Relief Fund, Inc. Performer agrees to furnish all modern wardrobe and wearing apparel reasonably necessary for the portrayal of said role; it being agreed, however, that should so-called “character” or “period” costumes be required, Producer shall supply same. Should any dispute or controversy arise between the parties hereto with reference to this Agreement, or the employment herein provided for, such dispute or controversy shall be settled and determined by conciliation and arbitration in accordance with the conciliation and arbitration provisions of the SAG Agreement and such provisions are hereby referred to and by such reference incorporated herein and made a part of this Agreement with the same effect as though same were set forth herein in detail.
    </p>
    <p>
        Performer further agrees that in the event of retakes of all or any of the scenes in which Performer participates or if additional scenes are required (whether originally contemplated or not) Performer will return to XXX same basic rate of compensation as that set forth above.
    </p>
    <table border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td></td>
            <td>[[${data.getProductionCompany()}]]</td>
        </tr>
        <tr>
            <td>EMPLOYMENT ACCEPTED</td>
            <td>PRODUCER</td>
        </tr>
        <tr>
            <td>By:_____________________________________</td>
            <td>By:_____________________________________</td>
        </tr>
        <tr>
            <td>   Performer: [[${data.getPerformerName()}]]</td>
            <td>   [[${data.getSignatoryTitle()}]]</td>
        </tr>
    </table>

</body>
</html>'; 
    i                   INT; 
BEGIN 
    WHILE Length(contractTemplate) <= 6000 LOOP 
        contractTemplate := contractTemplate 
                               || ' '; 
    END LOOP; 
	delete from DBO_FC.FC_CONTRACT_TEMPLATE where CONTRACT_NAME='SAG_EMPLOYMENT_OF_A_DAY_PERFORMER';
	select id into i from FC_LOOKUP where name='Employment of a Day Performer';

Insert into FC_CONTRACT_TEMPLATE (ID,CONTRACT_NAME,CREATED_BY,CREATE_DATE,CONTRACT_LOOKUP_ID,TEXT) values (DBO_FC.FC_CONTRACT_TEMPLATE_ID_SEQ.nextval,'EMPLOYMENT_OF_A_DAY_PERFORMER','AmitS',sysdate,i,contractTemplate);

    dbms_output.Put_line('I have finished inputting your clob: ' 
                         || Length(contractTemplate)); 
commit;                         
END; 
