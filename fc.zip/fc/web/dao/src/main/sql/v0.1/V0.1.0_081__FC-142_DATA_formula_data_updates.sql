--update Formula details
SET DEFINE OFF;
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'startDate' where d.FIELD_NAME = 'adjustmentInterval' and d.TABLE_FIELD_NAME ='START_DATE';

UPDATE DBO_FC.FC_FORMULA_DETAIL d set d.VALIDATION_EXPRESSION = '^\s*(?=.*[0-9])\d*(?:\.\d{1,2})?\s*$' where d.DISPLAY_NAME ='Total Amount' and d.FIELD_TYPE_LOOKUP_ID = (select lk.id from DBO_FC.FC_LOOKUP lk where lk.TYPE = 'FIELD_TYPE' and lk.NAME = 'AMOUNT_FIELD')