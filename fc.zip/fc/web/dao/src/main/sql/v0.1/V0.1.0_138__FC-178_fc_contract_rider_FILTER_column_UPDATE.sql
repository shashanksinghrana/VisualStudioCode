-- Contract Rider fILTER COLUMN CREATE & Inserts
SET DEFINE OFF;
DECLARE
var_contract_lookup_id_2 NUMBER;
var_contract_lookup_id_3 NUMBER;

BEGIN

SELECT lk.ID
INTO var_contract_lookup_id_2
FROM DBO_FC.FC_LOOKUP lk
WHERE NAME = 'Non-Union Day Performer Agreement (Loanout)';

SELECT lk.ID
INTO var_contract_lookup_id_3
FROM DBO_FC.FC_LOOKUP lk
WHERE NAME = 'Minimum Freelance Loanout Contract';

UPDATE DBO_FC.FC_CONTRACT_RIDER SET FILTER = 'LOANOUT' WHERE CONTRACT_LOOKUP_ID = var_contract_lookup_id_2;
UPDATE DBO_FC.FC_CONTRACT_RIDER SET FILTER = 'LOANOUT' WHERE CONTRACT_LOOKUP_ID = var_contract_lookup_id_3;

END;


