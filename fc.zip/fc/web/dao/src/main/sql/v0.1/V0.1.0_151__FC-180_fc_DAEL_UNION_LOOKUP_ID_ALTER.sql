DECLARE
v_column_exists number := 0; 
BEGIN
SELECT COUNT(*) 
INTO v_column_exists
FROM all_tab_cols
WHERE column_name = 'UNION_LOOKUP_ID'
AND table_name = 'FC_DEAL'
AND owner = 'DBO_FC'
AND NULLABLE = 'N';

IF (v_column_exists = 1) THEN
EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_DEAL MODIFY UNION_LOOKUP_ID NULL';
END IF;
END;