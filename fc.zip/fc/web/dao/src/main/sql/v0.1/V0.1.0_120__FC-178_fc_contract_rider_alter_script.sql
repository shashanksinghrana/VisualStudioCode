--------------------------------------------------------
--  File created - Monday-August-20-2018   
--------------------------------------------------------
DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM ALL_CONSTRAINTS
    WHERE
    constraint_name = 'DBO_FC_CONTRACT_TEMPLATE_DB995'
    AND table_name = 'FC_CONTRACT_TEMPLATE'
    AND owner = 'DBO_FC';
  IF (v_exists = 1) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_TEMPLATE DROP CONSTRAINT DBO_FC_CONTRACT_TEMPLATE_DB995';
  END IF;
END;
/

DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM ALL_CONSTRAINTS
    WHERE
    constraint_name = 'DBO_FC_CONTRACT_TEMPLATE_DB995'
    AND table_name = 'FC_CONTRACT_RIDER'
    AND owner = 'DBO_FC';
  IF (v_exists = 1) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_RIDER DROP CONSTRAINT DBO_FC_CONTRACT_TEMPLATE_DB995';
  END IF;
END;
/

DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM ALL_CONSTRAINTS
    WHERE
    constraint_name = 'FC_LOOKUP_FC_CONTRACT_RIDER628'
    AND table_name = 'FC_CONTRACT_RIDER'
    AND owner = 'DBO_FC';
  IF (v_exists = 1) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_RIDER DROP CONSTRAINT FC_LOOKUP_FC_CONTRACT_RIDER628';
  END IF;
END;
/


