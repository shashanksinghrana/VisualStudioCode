--------------------------------------------------------
--  File created - Thursday-August-09-2018   
--------------------------------------------------------
Insert into FC_LOOKUP (ID,NAME,TYPE,CREATE_DATE,UPDATED_BY,CREATED_BY,UPDATE_DATE,DISPLAY_ORDER) values (DBO_FC.FC_LOOKUP_ID_SEQ.nextval,'Sched K-III Daily Flat','FEE_TYPE',TO_DATE(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),'JeffreyL','JeffreyL',TO_DATE(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),'9');
Insert into FC_LOOKUP (ID,NAME,TYPE,CREATE_DATE,UPDATED_BY,CREATED_BY,UPDATE_DATE,DISPLAY_ORDER) values (DBO_FC.FC_LOOKUP_ID_SEQ.nextval,'Sched K-III Weekly Flat','FEE_TYPE',TO_DATE(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),'JeffreyL','JeffreyL',TO_DATE(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),'10');
Insert into FC_LOOKUP (ID,NAME,TYPE,CREATE_DATE,UPDATED_BY,CREATED_BY,UPDATE_DATE,DISPLAY_ORDER) values (DBO_FC.FC_LOOKUP_ID_SEQ.nextval,'SAG Weekly Above Scale','FEE_TYPE',TO_DATE(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),'JeffreyL','JeffreyL',TO_DATE(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),'11');
