--remove project types from dyanmic attribute tables
DELETE
FROM DBO_MP.DYNAMIC_ATTRIBUTE_VALUES v
WHERE v.ATTRIBUTE_VALUE IN ('Animation', 'DTV', 'Feature', 'Feature Animation', 'Tv', 'Tv/Airline');
DELETE
FROM DBO_MP.DYNAMIC_ATTRIBUTE da
WHERE da.DYNAMIC_ATTRIBUTE_TYPE = 'PROJECT_TYPE'
AND da.DYNAMIC_ATTRIBUTE_MODULE = 'FEATURE_CASTING';
-- insert FC lookup type for project types
INSERT
INTO DBO_FC.FC_LOOKUP
  (
    ID,
    NAME,
    TYPE,
    DISPLAY_ORDER,
    CREATE_DATE,
    UPDATE_DATE,
    CREATED_BY,
    UPDATED_BY
  )
  VALUES
  (
    DBO_FC.FC_LOOKUP_ID_SEQ.nextval,
    'PROJECT_TYPE',
    'PROJECT_FIELD_TYPE',
    0,
    SYSDATE,
    SYSDATE,
    'JeffreyL',
    'JeffreyL'
  );
  

DECLARE
TYPE proj_type_array IS VARRAY(6) OF VARCHAR2(300);
var_proj_types proj_type_array;
var_other_count NUMBER;
var_lookup_type NUMBER;
var_type_other NUMBER;

CURSOR typesDp
IS
  SELECT l.LOOKUP_ID
  FROM DBO_MP.LOOKUP l
  WHERE upper(l.LOOKUP_NAME) != upper('Other') and l.LOOKUP_TYPE_ID =
    (SELECT t.LOOKUP_TYPE_ID
    FROM DBO_MP.LOOKUP_TYPE t
    WHERE t.lookup_type_name = 'PROJECT_TYPE'
    );

BEGIN
  --get lookup type id value
  var_proj_types := proj_type_array('Animation', 'DTV', 'Feature', 'Feature Animation', 'Tv', 'Tv/Airline');
  SELECT t.LOOKUP_TYPE_ID
  INTO var_lookup_type
  FROM DBO_MP.LOOKUP_TYPE t
  WHERE t.LOOKUP_TYPE_NAME = 'PROJECT_TYPE';
  
  
   SELECT count(t.LOOKUP_ID)
  INTO var_other_count
  FROM DBO_MP.LOOKUP t
  WHERE t.LOOKUP_NAME = 'Other' and t.LOOKUP_TYPE_ID = var_lookup_type;
  
  
  
  --validate if other entry exists
  if var_other_count != 0 THEN
  --get other entry
    SELECT t.LOOKUP_ID
    INTO var_type_other
    FROM DBO_MP.LOOKUP t
    WHERE t.LOOKUP_NAME = 'Other' and t.LOOKUP_TYPE_ID = var_lookup_type;
  ELSE
  --insert other entry
    INSERT INTO DBO_MP.LOOKUP
      (
        LOOKUP_ID,
        LOOKUP_NAME,
        LOOKUP_TYPE_ID,
        LAST_UPDATE_TS,
        LAST_UPDATE_USER
      )
      VALUES
      (
        DBO_MP.SEQ_LOOKUP_ID.nextval,
        'Other',
        var_lookup_type,
        SYSTIMESTAMP,
        'JeffreyL'
      );
      --get inserted record
    SELECT t.LOOKUP_ID
    INTO var_type_other
    FROM DBO_MP.LOOKUP t
    WHERE t.LOOKUP_NAME = 'Other' and t.LOOKUP_TYPE_ID = var_lookup_type;
  
  END IF;
  
  
  
  FOR i IN 1..var_proj_types.count
  --insert default values for project type
  LOOP
    INSERT
    INTO DBO_MP.LOOKUP
      (
        LOOKUP_ID,
        LOOKUP_NAME,
        LOOKUP_TYPE_ID,
        LAST_UPDATE_TS,
        LAST_UPDATE_USER
      )
      VALUES
      (
        DBO_MP.SEQ_LOOKUP_ID.nextval,
        var_proj_types(i),
        var_lookup_type,
        SYSTIMESTAMP,
        'JeffreyL'
      );
    INSERT
    INTO DBO_FC.FC_ADMIN_MP_LOOKUP
      (
        ID,
        FC_TYPE_LOOKUP_ID,
        MP_LOOKUP_ID,
        MODULE,
        DISPLAY_ORDER,
        CREATED_BY,
        UPDATED_BY,
        CREATE_DATE,
        UPDATE_DATE
      )
      VALUES
      (
        DBO_FC.FC_ADMIN_MP_LOOKUP_ID_SEQ.nextval,
        DBO_FC.FC_LOOKUP_ID_SEQ.currval,
        DBO_MP.SEQ_LOOKUP_ID.currval,
        'FEATURE_CASTING',
        i,
        'JeffreyL',
        'JeffreyL',
        SYSDATE,
        SYSDATE
      );
  END LOOP;
  
  FOR dpType in TypesDp
  LOOP
     INSERT
    INTO DBO_FC.FC_ADMIN_MP_LOOKUP
      (
        ID,
        FC_TYPE_LOOKUP_ID,
        MP_LOOKUP_ID,
        MODULE,
        CREATED_BY,
        UPDATED_BY,
        CREATE_DATE,
        UPDATE_DATE
      )
      VALUES
      (
        DBO_FC.FC_ADMIN_MP_LOOKUP_ID_SEQ.nextval,
        DBO_FC.FC_LOOKUP_ID_SEQ.currval,
        dpType.LOOKUP_ID,
        'DEALPOINT',
        'JeffreyL',
        'JeffreyL',
        SYSDATE,
        SYSDATE
      );
      
    END LOOP;
    -- insert 'other' as FC entry
     INSERT
    INTO DBO_FC.FC_ADMIN_MP_LOOKUP
      (
        ID,
        FC_TYPE_LOOKUP_ID,
        MP_LOOKUP_ID,
        MODULE,
        CREATED_BY,
        UPDATED_BY,
        CREATE_DATE,
        UPDATE_DATE
      )
      VALUES
      (
        DBO_FC.FC_ADMIN_MP_LOOKUP_ID_SEQ.nextval,
        DBO_FC.FC_LOOKUP_ID_SEQ.currval,
        var_type_other,
        'FEATURE_CASTING',
        'JeffreyL',
        'JeffreyL',
        SYSDATE,
        SYSDATE
      );
    
END;