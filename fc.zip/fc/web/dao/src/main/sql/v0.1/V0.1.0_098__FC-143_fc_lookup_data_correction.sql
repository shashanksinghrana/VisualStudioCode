     -- Update DBO_FC.FC_LOOKUP data
	 UPDATE DBO_FC.FC_LOOKUP SET NAME='No Less than 5th Position' WHERE NAME='No Les than 5th Position';