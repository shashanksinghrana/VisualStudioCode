
insert into DBO_FC.FC_SIGNATORY_USERS(ID, FIRST_NAME, LAST_NAME, TITLE, UPDATE_DATE, CREATE_DATE, CREATED_BY, UPDATED_BY) 
values(DBO_FC.FC_SIGNATORY_USERS_ID_SEQ.nextval, 'Kathleen', 'Shekter', 'Casting Administration', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL');

insert into DBO_FC.FC_SIGNATORY_USERS(ID, FIRST_NAME, LAST_NAME, TITLE, UPDATE_DATE, CREATE_DATE, CREATED_BY, UPDATED_BY) 
values(DBO_FC.FC_SIGNATORY_USERS_ID_SEQ.nextval, 'David', 'Blaikley', 'Authorized Representative', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL');

insert into DBO_FC.FC_SIGNATORY_USERS(ID, FIRST_NAME, LAST_NAME, TITLE, UPDATE_DATE, CREATE_DATE, CREATED_BY, UPDATED_BY) 
values(DBO_FC.FC_SIGNATORY_USERS_ID_SEQ.nextval, 'Authorized', 'Representative', '', SYSDATE, SYSDATE, 'JeffreyL', 'JeffreyL');
