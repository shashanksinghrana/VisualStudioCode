--Table to provide user admin control for MP Lookup entries
CREATE TABLE DBO_FC.FC_ADMIN_MP_LOOKUP (
                id NUMBER NOT NULL,
                display_order NUMBER,
                module VARCHAR2(50),
                created_by VARCHAR2(50),
                updated_by VARCHAR2(50),
                create_date DATE,
                update_date DATE,
                mp_lookup_id NUMBER NOT NULL,
                fc_type_lookup_id NUMBER NOT NULL
);

-- index and primary key creation
 CREATE UNIQUE INDEX FC_ADMIN_MP_LOOKUP_ID_IDX ON DBO_FC.FC_ADMIN_MP_LOOKUP(ID);
  ALTER TABLE DBO_FC.FC_ADMIN_MP_LOOKUP ADD CONSTRAINT FC_ADMIN_MP_LOOKUP_ID_PK PRIMARY KEY(ID) USING INDEX FC_ADMIN_MP_LOOKUP_ID_IDX;

--Table grant to APP_FC
  GRANT ALL ON DBO_FC.FC_ADMIN_MP_LOOKUP TO APP_FC;
  CREATE OR REPLACE SYNONYM APP_FC.FC_ADMIN_MP_LOOKUP FOR DBO_FC.FC_ADMIN_MP_LOOKUP;
--Sequence creation for primary key
  CREATE SEQUENCE DBO_FC.FC_ADMIN_MP_LOOKUP_ID_SEQ MINVALUE 1 MAXVALUE 999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER NOCYCLE;
  GRANT ALL ON DBO_FC.FC_ADMIN_MP_LOOKUP_ID_SEQ TO APP_FC;