-- setting field_name default values.
SET DEFINE OFF;
--rate
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'rate' where d.DISPLAY_NAME = 'Rate';

--info
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'contractInfo' where d.DISPLAY_NAME = 'Info';

--total amount 
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'totalAmount' where d.DISPLAY_NAME = 'Total Amount';

-- +/-
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'adjustmentInterval' where d.TABLE_FIELD_NAME = 'ADJUSTMENT_INTERVAL';

--start date qualifier
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'startDateQualifierId' where d.TABLE_FIELD_NAME = 'START_DATE_QUALIFIER';
-- start date
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'adjustmentInterval' where d.TABLE_FIELD_NAME = 'START_DATE';

--contract returned date
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'contractReturnedDate' where d.DISPLAY_NAME = 'Returned';

--contract revised date
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'contractRevisedDate' where d.DISPLAY_NAME = 'Revised';

--contract sent date
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'contractSentDate' where d.DISPLAY_NAME = 'Sent';

--contract text date
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'contractText' where d.DISPLAY_NAME = 'Text';

-- guarantee #
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'guaranteeNumber' where d.TABLE_FIELD_NAME = 'GUARANTEE_NUMBER';

-- interval
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'interval' where d.TABLE_FIELD_NAME = 'INTERVAL';

-- period
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'periodId' where d.DISPLAY_NAME = 'Period';

-- post free days
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'postFree' where d.TABLE_FIELD_NAME = 'POST_FREE';

-- void
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'voidFlag' where d.DISPLAY_NAME = 'Void';

-- post free interval
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'postFreeInterval' where d.TABLE_FIELD_NAME = 'post_free_interval';

--prinicpal free
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'principalFree' where d.TABLE_FIELD_NAME = 'prinicpal_free';

--prinicpal free interval
update DBO_FC.FC_FORMULA_DETAIL d set d.FIELD_NAME = 'principalFreeInterval' where d.TABLE_FIELD_NAME = 'prinicpal_free_interval';

