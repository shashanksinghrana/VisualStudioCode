-- Field Type Inserts
SET DEFINE OFF;

DECLARE
var_fee_type NUMBER;
var_studio_wb NUMBER;
var_deal_type NUMBER;
var_page NUMBER;
var_drop_down NUMBER;
var_amount_field NUMBER;
var_percent_field NUMBER;
var_check_box NUMBER;
var_text_area NUMBER;
var_number_field NUMBER;
var_date_field NUMBER;
var_alpah_numeric NUMBER;
var_read_only NUMBER;
var_dynamic_drop NUMBER;
var_start_date_group NUMBER;
var_contract_group NUMBER;

BEGIN
--studios

	SELECT lk.lookup_id 
  INTO var_studio_wb
  FROM DBO_MP.LOOKUP lk
  WHERE lk.lookup_name = 'WB Pictures' and lk.LOOKUP_TYPE_ID = (select LOOKUP_TYPE_ID from DBO_MP.LOOKUP_TYPE where LOOKUP_TYPE_NAME = 'STUDIO');
  
--deal type
SELECT lk.id
INTO var_deal_type 
FROM DBO_FC.FC_LOOKUP lk
where lk.TYPE = 'DEAL_TYPE';
--wizard page
select lk.id
into var_page
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'Compensation' and lk.TYPE = 'WIZARD_PAGE';

--Field Type options
select lk.id
into var_amount_field
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'AMOUNT_FIELD' and lk.TYPE = 'FIELD_TYPE';

select lk.id
into var_drop_down
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'DROP_DOWN' and lk.TYPE = 'FIELD_TYPE';

select lk.id
into var_check_box
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'CHECK_BOX' and lk.TYPE = 'FIELD_TYPE';

select lk.id
into var_text_area
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'TEXT_AREA' and lk.TYPE = 'FIELD_TYPE';

select lk.id
into var_number_field
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'NUMBER_FIELD' and lk.TYPE = 'FIELD_TYPE';

select lk.id
into var_date_field
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'DATE_FIELD' and lk.TYPE = 'FIELD_TYPE';
 

--group type option 
select lk.id
into var_start_date_group 
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'Start Date' and lk.TYPE = 'GROUP_TYPE';

select lk.id
into var_contract_group 
FROM DBO_FC.FC_LOOKUP lk
where lk.NAME = 'Contract' and lk.TYPE = 'GROUP_TYPE';
  
 select  lk.ID into var_fee_type FROM DBO_FC.FC_LOOKUP lk where lk.TYPE = 'FEE_TYPE' and lk.NAME = 'Other Daily';

  
--insert  other daily fee type  formula

 --WB studio
   insert into DBO_FC.FC_FORMULA(ID, DEAL_TYPE_LOOKUP_ID, TYPE_LOOKUP_ID, STUDIO_LOOKUP_ID, SUB_TYPE_LOOKUP_ID, DISABLE_FLAG, EFFECTIVE_DATE, UPDATE_DATE, UPDATED_BY, CREATED_BY, CREATE_DATE)
  values(DBO_FC.FC_FORMULA_ID_SEQ.nextval, var_deal_type, var_page, var_studio_wb, var_fee_type, 'N', SYSDATE, SYSDATE, 'C2C_Migration', 'C2C_Migration', SYSDATE);
 
  -- formula details
    --rate
  insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Rate', var_amount_field, null, null,  1, null, 'FC_COMPENSATION' , 'RATE_VALUE', null, null, 'Y', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, 2 );
   --guranatee
   insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, '# Guarantee', var_number_field, null, null,  2, null, 'FC_COMPENSATION' , 'GUARANTEE_NUMBER', null, null, 'Y', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, 3 );
  --Period
  insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Period', var_drop_down, 'PERIOD_TYPE', null,  3, null, 'FC_COMPENSATION' , 'PERIOD_ID', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, null );
   
   --start date qualifier
  insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, '', var_drop_down, 'START_DATE_QUALIFIER_TYPE',null,  4, var_start_date_group,  'FC_COMPENSATION' , 'START_DATE_QUALIFIER', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, 4 ); 
   
  --start date
  insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, '', var_date_field, null, null, 5, var_start_date_group,  'FC_COMPENSATION' , 'START_DATE', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, 5 ); 
   
   -- contract sent
    insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Sent', var_date_field, null, null, 6, var_contract_group,  'FC_COMPENSATION' , 'CONTRACT_SENT_DATE', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, null ); 
   
   --contract returned
    insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Returned', var_date_field, null, null, 7, var_contract_group,  'FC_COMPENSATION' , 'CONTRACT_RETURNED_DATE', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, null ); 
   
    --contract revised
    insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Revised', var_date_field, null, null, 8, var_contract_group,  'FC_COMPENSATION' , 'CONTRACT_REVISIED_DATE', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, null ); 
   
    --contract info
    insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Info', var_text_area, null, null, 9, var_contract_group,  'FC_COMPENSATION' , 'CONTRACT_INFO', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, null ); 
   
    --contract text
    insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Text', var_text_area, null, null, 10, var_contract_group,  'FC_COMPENSATION' , 'CONTRACT_TEXT', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, null ); 
   
     --contract void
    insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Void', var_check_box, null, null, 11, var_contract_group,  'FC_COMPENSATION' , 'VOID_FLAG', null, null, 'N', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, null ); 
   
     --total Amount
    insert into FC_FORMULA_DETAIL(ID, FORMULA_ID, DISPLAY_NAME, FIELD_TYPE_LOOKUP_ID, VALUE, DEFAULT_VALUE, ORDER_NUM, GROUP_TYPE_LOOKUP_ID, TABLE_NAME, TABLE_FIELD_NAME, VALIDATION_EXPRESSION, DEPENDS_ON_ORDER_NUM, REQUIRED_FLAG, UPDATE_DATE, UPDATED_BY, CREATE_DATE, CREATED_BY, SUMMARY_GROUP_TYPE_LOOKUP_ID, SUMMARY_ORDER)
   values(DBO_FC.FC_FORMULA_DETAIL_ID_SEQ.nextval, DBO_FC.FC_FORMULA_ID_SEQ.currval, 'Total Amount', var_amount_field, null, null, 12, null,  'FC_COMPENSATION' , 'TOTAL_AMOUNT', null, null, 'Y', SYSDATE, 'C2C_Migration', SYSDATE, 'C2C_Migration', null, 1); 
   
 
   
END;