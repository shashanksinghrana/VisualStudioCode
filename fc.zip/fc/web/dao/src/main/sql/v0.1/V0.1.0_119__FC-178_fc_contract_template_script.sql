--------------------------------------------------------
--  File created - Monday-August-20-2018   
--------------------------------------------------------

DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM all_tab_cols
    WHERE 
    column_name = 'CONTRACT_LOOKUP_ID'
    AND table_name = 'FC_CONTRACT_TEMPLATE'
    AND owner = 'DBO_FC';
  IF (v_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_TEMPLATE ADD CONTRACT_LOOKUP_ID NUMBER NOT NULL';
  END IF;
END;
/

DECLARE
  v_exists number := 0; 
BEGIN
  SELECT COUNT(1) INTO v_exists 
  FROM all_tab_cols
    WHERE 
    column_name = 'TEXT'
    AND data_type = 'CLOB'
    AND table_name = 'FC_CONTRACT_TEMPLATE'
    AND owner = 'DBO_FC';
  IF (v_exists = 0) THEN
    EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_TEMPLATE DROP COLUMN TEXT';
	EXECUTE IMMEDIATE 'ALTER TABLE DBO_FC.FC_CONTRACT_TEMPLATE ADD TEXT CLOB NOT NULL';
  END IF;
END;
/
