
DECLARE 
    contractTemplate CLOB := '<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <style>
        th {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        td {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        p {
            font-weight: 300;
            font-family: Roboto;
            font-size: 12px;
            letter-spacing: 0.25px;
        }

        @media print {
            footer {
                page-break-after: always;
            }
        }
    </style>
</head>
<body>
    <h3 style="text-align: center;"><strong>EMPLOYMENT OF A DAY PERFORMER</strong></h3>
    <p>&nbsp;</p>
    <table style="width: 90%; margin-left: auto; margin-right: auto;" border="0" cellspacing="0" cellpadding="0">
        <tbody>
            <tr>
                <th style="text-align: left;">Producer</th>
                <th style="text-align: left;">Production No.</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getProductionCompany()}]]</td>
                <td style="padding-left: 30px;">[[${data.getProductionNumber()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Producer&rsquo;s Address</th>
                <th style="text-align: left;">Deal Date</th>
            </tr>
            <tr>
                <td style="padding-left: 30px; vertical-align: top;" rowspan="3">[[${data.getProducerAddress()}]]</td>
                <td style="padding-left: 30px;">[[${data.getDealDate()}]]</td>
            </tr>
            <tr>
                <th style="text-align: left;">Performer</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getPerformerName()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px; vertical-align: top;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Engagement Starts</th>
                <th style="text-align: left;">Contract Address</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getStartDate()}]]</td>
                <td style="text-align: left; vertical-align: top; padding-left: 30px;" rowspan="5">[[${data.getContractAddress()}]]</td>
            </tr>
            <tr>
                <th style="text-align: left;">Role</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getRole()}]]</td>
            </tr>
            <tr>
                <th style="text-align: left;">Picture</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getProjectName()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="text-align: left; vertical-align: top; padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Social Security No.</th>
                <th style="text-align: left;">Agent</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getSocialSecurityNumber()}]]</td>
                <td style="padding-left: 30px;">[[${data.getRepName()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">Daily Rate</th>
                <th style="text-align: left;">Telephone No.</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">[[${data.getRate()}]]</td>
                <td style="padding-left: 30px;">[[${data.getPerformerPhoneNumber()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <th style="text-align: left;">Weekly Conversion Rate</th>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td style="padding-left: 30px;">[[${data.getWeeklyConversionRate()}]]</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
        </tbody>
    </table>
    <p>&nbsp;</p>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 100%;">
                    <p>Producer hereby employs Performer to render services as an actor in the above role in the Picture on the terms set forth above. The engagement is subject, to the provisions printed below and ON THE REVERSE SIDE and all provisions in the applicable "PRODUCER-SCREEN ACTORS GUILD CODIFIED BASIC AGREEMENT" (the "SAG Agreement"). Performer hereby consents to fly on charter flights for this engagement.</p>
                    <p>Performer agrees to accept the sum properly computed based upon the times and the basic wage rate shown above as payment in full for all services rendered by Performer in the Picture referred to herein. It is further agreed that said sum, less all deductions required by law, may be paid to Performer by negotiable check, said check to be addressed to Performer at the last reported address and deposited in the United States mail within five (5) days (excluding Saturday, Sunday and Holidays) following completion of Performer&rsquo;s workweek.</p>
                    <p>Performer (does) (does not) hereby authorize Producer to deduct from the compensation hereinabove specified, an amount equal to percent of each installment of compensation due to Performer hereunder, and to pay the amount so deducted to the Motion Picture and Television Relief Fund, Inc. Performer agrees to furnish all modern wardrobe and wearing apparel reasonably necessary for the portrayal of said role; it being agreed, however, that should so-called "character" or "period" costumes be required, Producer shall supply same. Should any dispute or controversy arise between the parties hereto with reference to this Agreement, or the employment herein provided for, if required under the SAG Agreement such dispute or controversy shall be settled and determined by conciliation and arbitration in accordance with the conciliation and arbitration provisions thereunder and such provisions are hereby referred to and by such reference incorporated herein and made a part of this Agreement with the same effect as though same were set forth herein in detail.</p>
                    <p>Performer further agrees that in the event of retakes of all or any of the scenes in which Performer participates, or if additional scenes are required (whether originally contemplated or not) Performer will return to work and render services in such scenes at the same basic rate of compensation as that set forth above.</p>
                </td>
            </tr>
        </tbody>
    </table>
    <p>&nbsp;</p>
    <table style="width: 90%; margin-left: auto; margin-right: auto;" border="0" cellspacing="0" cellpadding="0">
        <tbody>
            <tr>
                <td>&nbsp;</td>
                <td>[[${data.getProductionCompany()}]]</td>
            </tr>
            <tr>
                <th style="text-align: left;">EMPLOYMENT ACCEPTED</th>
                <th style="text-align: left;">PRODUCER</th>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <th style="text-align: left;">By:_____________________________________</th>
                <th style="text-align: left;">By:_____________________________________</th>
            </tr>
            <tr>
                <td style="padding-left: 30px;">Performer: [[${data.getPerformerName()}]]</td>
                <td style="padding-left: 30px;">[[${data.getSignatoryTitle()}]]</td>
            </tr>
			<tr>
                <td style="padding-left: 30px;"></td>
                <td style="padding-left: 30px;">[[${data.getSignatoryTitle()}]]</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">&nbsp;</td>
                <td style="padding-left: 30px;">&nbsp;</td>
            </tr>
        </tbody>
    </table>
    <p id="footer" style="text-align: center;"><!-- pagebreak --></p>
    <table style="width: 90%; border-collapse: collapse; margin-left: auto; margin-right: auto;" border="0">
        <tbody>
            <tr>
                <td style="width: 100%;">
                    <p style="text-align: center;"><strong>ADDITIONAL TERMS AND CONDITIONS</strong></p>
                    <p style="text-indent: 30px;">A. <strong>Ownership and Rights Granted.</strong> The results and proceeds of Performer&rsquo;s services are or shall be deemed a work made for hire for Producer. Without limiting the foregoing, Producer and its licensees, successors and assigns shall own, and Performer hereby assigns to Producer, forever and throughout the universe, all rights of every kind and nature whatsoever in and to the results and proceeds of Performer&rsquo;s services (inclusive of, by way of example, all work done and all poses, acts, plays, and appearances made by Performer hereunder) and all copyrights pertaining thereto and extensions and renewals thereof, including without limitation the right to exploit in any manner and through any media now known or hereafter devised (including by way of illustration all rental, lending and other rights of communication to the public) any and all such results and proceeds. 3.8% of the compensation paid under this Agreement shall be deemed allocated to, and equitable remuneration for, said rental and lending rights. Neither the expiration nor termination of this Agreement shall affect Producer&rsquo;s ownership of the results and proceeds of Performer&rsquo;s services or Producer&rsquo;s other rights hereunder.</p>
                    <p style="text-indent: 30px;">B. <strong>Advertising and Exploitation Rights.</strong> Without limiting the generality of paragraph A above, Producer and its licensees, successors and assigns shall have, forever and throughout the universe, the exclusive right to use the results and proceeds of Performer&rsquo;s services and the non-exclusive right to use Performer&rsquo;s name, photographs (still or moving, in whole or in part), likeness, voice and/or biography in and in connection with the advertising and exploitation of the Picture, and in connection with novelizations, books and other publications relating to marketing of the Picture, and in all products, commodities and/or services contained in so-called commercial tie-ups (as that term is commonly known and utilized in the motion picture industry) relating to the Picture, provided that Producer shall not advertise or announce in any such commercial tie-up that Performer directly endorses or uses any particular product, commodity or service without Performer&rsquo;s written consent. Performer authorizes Producer to use excerpts of the photography and sound recordings of the Picture containing Performer&rsquo;s voice and likeness in &ldquo;New Media,&rdquo; including re-use for promotional purposes. To the extent payment is required under the applicable Screen Actors Guild Basic Agreement, said payment shall be at the minimum compensation set forth therein for such use.</p>
                    <p style="text-indent: 30px;">C. <strong>Merchandising.</strong> Without limiting the generality of paragraph A above, Producer shall have the exclusive right, forever and throughout the universe, but only in connection with the role portrayed by Performer hereunder, to use and to license others to use Performer&rsquo;s name, voice and likeness in and in connection with any novelizations and other publications, by-products, tieins, merchandise (including interactive/wireless merchandise), covers of soundtrack audio devices, commodities and services of every kind if reference is made to the Picture or literary property upon which the Picture is based, and if Performer is not represented as using or endorsing any such item. In consideration thereof, Producer shall pay to Performer a pro rata share (payable among all members of the cast of the Picture whose names and likenesses are used in the particular item involved) of 5% of the net receipts, if any, actually received by Producer out of the license fees for merchandising items or services using Performer&rsquo;s name and likeness, other than in any listing of credits for the Picture. Net receipts shall be computed and accounted for in accordance with Producer&rsquo;s customary accounting practices, including deduction of a distribution fee of 50% of gross receipts, and deduction of all expenses incurred in connection with such merchandising. For purposes of computing payment under this Paragraph C, soundtrack audio devices and novelizations and other publications relating to the Picture shall not be deemed merchandising undertakings for which the merchandising royalty is payable.</p>
                    <p style="text-indent: 30px;">D. <strong>Services Unique.</strong> Performer&rsquo;s services and the rights granted to Producer under this Agreement are of a special, unique, unusual, extraordinary and intellectual character giving them a peculiar value, the loss of which cannot be reasonably or adequately compensated in damages in any action at law. A breach hereof by Performer shall cause Producer irreparable injury and Producer shall be entitled to injunctive and other equitable relief to secure enforcement of this Agreement, but resort to such relief shall not limit Producer&rsquo;s other rights.</p>
                    <p style="text-indent: 30px;">E. <strong>Promotional Films.</strong> Producer shall have the exclusive right to make one or more promotional films of thirty minutes or less and to utilize the results and proceeds of Performer&rsquo;s services therein upon all of the terms and provisions set forth in the SAG Agreement. Performer shall render such services for said promotional films during the term as Producer may request, and Producer shall have the right to use film clips and behind-the-scenes shots in which Performer appears in such promotional films. No additional compensation shall be payable for any such services or uses unless specifically required under the SAG Agreement, in which event Producer shall pay the applicable minimum required therefor.</p>
                    <p style="text-indent: 30px;">F. <strong>Credit.</strong> On the condition that Performer fully performs Performer&rsquo;s services and is not in breach hereunder, and that Performer&rsquo;s role is retained in the Picture as generally released and that Performer appears recognizably in such role, Producer agrees to accord Performer the credit(s) provided for in Exhibit A, if any, attached hereto and incorporated herein by this reference. If no such Exhibit A is attached hereto, then Producer shall have the right, but not the obligation, to accord Performer such credit as Producer may determine in Producer&rsquo;s sole discretion. Except as expressly set forth in said Exhibit A, the size, placement, form and all other matters relating to any credit accorded to Performer shall be determined by Producer in Producer&rsquo;s sole discretion. The term &ldquo;paid advertising&rdquo; as used herein and in said Exhibit A (if at all) shall be subject to Producer&rsquo;s and all distributors&rsquo; customary exclusions. With respect to any credit to be accorded Performer in paid advertising, whenever reference is made to the size of the title of the Picture and/or the name(s) of one or more of the members of the cast of the Picture, the references to the title of the Picture and/or the names of any cast members shall be the &ldquo;regular&rdquo; and not the &ldquo;artwork&rdquo; uses thereof. No casual or inadvertent failure by Producer or others to comply with the provisions of this Paragraph F shall be deemed a breach of this Agreement, nor shall failure by any third party to accord any credit to Performer constitute a breach by Producer of this Agreement.</p>
                    <p style="text-indent: 30px;">G. <strong>Pay or Play.</strong> Producer is not obligated in any manner actually to utilize Performer&rsquo;s services or the results and proceeds thereof or to produce, exhibit or otherwise exploit the Picture, or to exercise any of the rights granted to Producer hereunder. Producer shall have fully discharged its obligations hereunder by payment of the fixed compensation for the minimum period provided for in this Agreement, subject to Producer&rsquo;s rights and remedies at law, in equity or under the SAG Agreement.</p>
                    <p style="text-indent: 30px;">H. <strong>No Injunctive Relief.</strong> It is acknowledged that the rights and remedies in the event of a breach or alleged breach of this Agreement by Producer (including without limitation the provisions of Paragraph F hereof) shall be strictly limited to the right, if any, to recover damages in accordance with the arbitration procedures set forth below (it being acknowledged that payment of such damages are an adequate remedy), and there shall be no right by reason of any such breach to rescind this Agreement, or to restrain Producer&rsquo;s exercise of any of the rights granted to Producer hereunder.</p>
                    <p style="text-indent: 30px;">I. <strong>Insurance.</strong> If Producer requests, Performer shall assist Producer in securing customary insurance by submitting to customary medical examinations and by signing such instruments as may be reasonably required in connection therewith. In the event Performer fails to qualify for such insurance at customary rates and on other customary terms, Producer shall have the right to terminate this Agreement without further obligation.</p>
                    <p style="text-indent: 30px;">J. <strong>Contingencies.</strong> Without limiting Producer&rsquo;s rights under the SAG Agreement or at law or equity, if Performer fails or refuses to perform or is incapacitated or if the production of the Picture is prevented or impaired by an event of force majeure, including labor controversy, illness of personnel, lack of materials or any other event beyond Producer&rsquo;s control, then Producer may suspend and extend this Agreement during such contingency, or at any time during such contingency terminate this Agreement without further obligation.</p>
                    <p style="text-indent: 30px;">K. <strong>SAG Agreement.</strong> This Agreement is subject to the SAG Agreement. Except as expressly provided herein, Producer shall be entitled to the maximum benefits provided for in the SAG Agreement. To the extent any provision of this Agreement conflicts with the mandatory provisions of the SAG Agreement or any applicable law or regulation, the latter shall prevail, provided that the provision of this Agreement so affected shall be limited only to the minimum extent necessary to comply with such SAG Agreement, law or regulation. In the event the SAG Agreement requires the payment of compensation to Performer in addition to that provided herein, such additional compensation shall be paid at the minimum applicable rates specified in the SAG Agreement.</p>
                    <p style="text-indent: 30px;">L. <strong>Right To Work.</strong> Producer may terminate this Agreement without further obligation if any work permits, visas, or proof of Performer&rsquo;s right to work required in connection with Performer&rsquo;s services cannot be obtained in a timely fashion. Whether or not Producer in Producer&rsquo;s discretion agrees to obtain such work permits or visas for Performer, the responsibility therefor shall rest with Performer.</p>
                    <p style="text-indent: 30px;">M. <strong>Rules And Regulations.</strong> (a) No personal photography or audio/visual recording is permitted on sets or in work areas. Any and all photographs and recordings made or caused to be made by Performer on Producer&rsquo;s sets or in other work areas shall be the property of Producer; (b) Performer shall not disclose any information concerning the Picture to individuals outside the production without the prior consent of Producer; (c) Transportation to and from overnight locations shall be provided by Producer; personal transportation may not be used; (d) Performer must pay in advance (by check or credit card) for personal travel or shipping arranged as a courtesy to Performer by the production office; (e) Performer will be responsible for, and promptly pay or reimburse Producer on demand for, any unsettled hotel incidentals personally incurred by Performer, or any unreconciled petty cash advances.</p>
                    <p style="text-indent: 30px;">N. <strong>Arbitration.</strong> Except for matters specifically subject to the conciliation and arbitration procedures of the SAG Agreement, any and all disputes arising out of this Agreement shall be resolved solely by final and binding arbitration in accordance with JAMS Arbitration Rules and Procedures, except as modified herein (&ldquo;Arbitration Rules&rdquo;). The arbitration shall be conducted in Los Angeles County, California before a single neutral arbitrator who is a retired judge or justice from a California state or federal court appointed in accordance with the Arbitration Rules. The arbitrator shall apply California law and the Federal Rules of Evidence in adjudicating the dispute. The parties and the arbitrator(s) shall treat the arbitration, any party submissions and disclosures therein and any award and orders as confidential, except as necessary to enforce an award or as otherwise required by law.</p>
                </td>
            </tr>
        </tbody>
    </table>
    <p style="text-indent: 30px;">&nbsp;</p>
    <p>&nbsp;</p>
</body>
</html>'; 
    i                   INT; 
BEGIN 
    WHILE Length(contractTemplate) <= 6000 LOOP 
        contractTemplate := contractTemplate 
                               || ' '; 
    END LOOP; 
	select id into i from FC_LOOKUP where name='Employment of a Day Performer';
update FC_CONTRACT_TEMPLATE set TEXT=contractTemplate where CONTRACT_LOOKUP_ID=i;    
commit;                         
END; 
