DECLARE
  var_studio_type NUMBER;
  var_a20 NUMBER;
  var_npu NUMBER;
  var_wb  NUMBER;
BEGIN
SELECT lt.LOOKUP_TYPE_ID into var_studio_type
    FROM DBO_MP.LOOKUP_TYPE lt
    WHERE lt.LOOKUP_TYPE_NAME = 'STUDIO';

--Validate studios don't exist already
  SELECT count(lk.LOOKUP_ID)
  INTO var_a20
  FROM DBO_MP.LOOKUP lk
  WHERE lk.LOOKUP_TYPE_ID =
    var_studio_type
  AND upper(lk.LOOKUP_NAME) = upper('A-20');
  
  SELECT count(lk.LOOKUP_ID)
  INTO var_npu
  FROM DBO_MP.LOOKUP lk
  WHERE lk.LOOKUP_TYPE_ID =
    var_studio_type
  AND upper(lk.LOOKUP_NAME) = upper('N/PU');
  
  SELECT count(lk.LOOKUP_ID)
  INTO var_wb
  FROM DBO_MP.LOOKUP lk
  WHERE lk.LOOKUP_TYPE_ID =
   var_studio_type
  AND upper(lk.LOOKUP_NAME) = upper('WARNER BROS.');
  
  if(var_a20 = 0)
  then
  insert into DBO_MP.LOOKUP(LOOKUP_ID, LOOKUP_NAME, LOOKUP_TYPE_ID, LAST_UPDATE_TS, LAST_UPDATE_USER) values(DBO_MP.SEQ_LOOKUP_ID.nextval, 'A-20', var_studio_type, SYSTIMESTAMP, 'JeffreyL'  );
  end if;
  
  if(var_npu = 0)
  then
  insert into DBO_MP.LOOKUP(LOOKUP_ID, LOOKUP_NAME, LOOKUP_TYPE_ID, LAST_UPDATE_TS, LAST_UPDATE_USER) values(DBO_MP.SEQ_LOOKUP_ID.nextval, 'N/PU', var_studio_type, SYSTIMESTAMP, 'JeffreyL'  );
  end if;
  
  if(var_wb = 0)
  then
  insert into DBO_MP.LOOKUP(LOOKUP_ID, LOOKUP_NAME, LOOKUP_TYPE_ID, LAST_UPDATE_TS, LAST_UPDATE_USER) values(DBO_MP.SEQ_LOOKUP_ID.nextval, 'WARNER BROS.', var_studio_type, SYSTIMESTAMP, 'JeffreyL'  );
  end if;
  
  
END;
