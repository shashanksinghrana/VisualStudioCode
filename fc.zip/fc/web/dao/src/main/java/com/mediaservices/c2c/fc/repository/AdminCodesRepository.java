package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.AdminCode;

/**
 * The Interface AdminCodes Repository.
 */
public interface AdminCodesRepository extends JpaRepository<AdminCode, Long> {

    @Query(value = QueryConstants.ADMIN_CODES_BY_STUDIO_AND_TYPE, nativeQuery = true)
    public List<AdminCode> findByTypeAndStudio(@Param("type") String type, @Param("studioId") Long studioId);
}
