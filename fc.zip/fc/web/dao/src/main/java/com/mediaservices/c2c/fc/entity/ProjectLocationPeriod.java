package com.mediaservices.c2c.fc.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

@Entity
@Table(name = "FC_PROJECT_WORK_COMP_LOCATION")
public class ProjectLocationPeriod {
	
	 	@Id
	    @Column(name = "ID")
	    @GeneratedValue(generator = "seqLocationId1")
	    @SequenceGenerator(name = "seqLocationId1", sequenceName = "DBO_FC.FC_PWCL_ID_SEQ", allocationSize = 1)
	    private Long id;
	 	
	 	@ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "PROJECT_COMPANY_ID")
	    private ProjectCompany projectCompanyId;

	 	/** The project id. */
	    @Column(name = "ADDRESS_ID")
	    private Long addressId;
	    
	    /** The start date date. */
	    @Column(name = "START_DATE")
	    @Convert(converter = LocalDateConverter.class)
	    private LocalDate startDate;
	    
	    
	    /** The end date date. */
	    @Column(name = "END_DATE")
	    @Convert(converter = LocalDateConverter.class)
	    private LocalDate endDate;
	    
	    
	    /** The created user. */
	    @Column(name = "CREATED_BY", updatable = false)
	    private String createdUser;

	    /** The created date. */
	    @Column(name = "CREATE_DATE", updatable = false)
	    @Convert(converter = LocalDateTimeConverter.class)
	    private LocalDateTime createdDate;

	    /** The last updated user. */
	    @Column(name = "UPDATED_BY")
	    private String lastUpdatedUser;

	    /** The updated date. */
	    @Column(name = "UPDATE_DATE")
	    @Convert(converter = LocalDateTimeConverter.class)
	    private LocalDateTime updatedDate;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Long getAddressId() {
			return addressId;
		}

		public void setAddressId(Long addressId) {
			this.addressId = addressId;
		}

		public LocalDate getStartDate() {
			return startDate;
		}

		public void setStartDate(LocalDate startDate) {
			this.startDate = startDate;
		}

		public LocalDate getEndDate() {
			return endDate;
		}

		public void setEndDate(LocalDate endDate) {
			this.endDate = endDate;
		}

		public String getCreatedUser() {
			return createdUser;
		}

		public void setCreatedUser(String createdUser) {
			this.createdUser = createdUser;
		}

		public LocalDateTime getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(LocalDateTime createdDate) {
			this.createdDate = createdDate;
		}

		public String getLastUpdatedUser() {
			return lastUpdatedUser;
		}

		public void setLastUpdatedUser(String lastUpdatedUser) {
			this.lastUpdatedUser = lastUpdatedUser;
		}
		
		public ProjectCompany getProjectCompanyId() {
			return projectCompanyId;
		}
		
		public void setProjectCompanyId(ProjectCompany projectCompanyId) {
			this.projectCompanyId = projectCompanyId;
		}

		public LocalDateTime getUpdatedDate() {
			return updatedDate;
		}

		public void setUpdatedDate(LocalDateTime updatedDate) {
			this.updatedDate = updatedDate;
		}
}