/*
 *
 */
package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;

/**
 * The Class WorkPeriodDetail.
 */
@Entity
@Table(name = "FC_WORK_PERIOD_DETAILS")
public class WorkPeriodDetail implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The work period detail id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqWorkPeriodDetailId")
    @SequenceGenerator(name = "seqWorkPeriodDetailId", sequenceName = "DBO_FC.FC_WORK_PERIOD_DETAILS_ID_SEQ", allocationSize = 1)
    private Long workPeriodDetailId;

    /** The off day. */
    @Column(name = "OFF_DAY")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate offDay;

    /** The work period detail. */
    @ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @JoinColumn(name = "WORK_PERIOD_ID")
    private WorkPeriod workPeriodId;

    /**
     * @return the workPeriod
     */
    public WorkPeriod getWorkPeriodId() {
        return workPeriodId;
    }

    /**
     * @param workPeriod
     *            the workPeriod to set
     */
    public void setWorkPeriodId(WorkPeriod workPeriod) {
        this.workPeriodId = workPeriod;
    }

    /**
     * @return the workPeriodDetailId
     */
    public Long getWorkPeriodDetailId() {
        return workPeriodDetailId;
    }

    /**
     * @param workPeriodDetailId
     *            the workPeriodDetailId to set
     */
    public void setWorkPeriodDetailId(Long workPeriodDetailId) {
        this.workPeriodDetailId = workPeriodDetailId;
    }

    /**
     * @return the offDay
     */
    public LocalDate getOffDay() {
        return offDay;
    }

    /**
     * @param offDay
     *            the offDay to set
     */
    public void setOffDay(LocalDate offDay) {
        this.offDay = offDay;
    }

}
