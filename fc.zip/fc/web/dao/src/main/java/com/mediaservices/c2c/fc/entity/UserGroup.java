/**
 *
 */
package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the USER_GROUP database table.
 * 
 */
@Entity
@Table(name = "USER_GROUP")
public class UserGroup implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "GROUP_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqGroupId")
    @SequenceGenerator(name = "seqGroupId", sequenceName = "SEQ_GROUP_ID", allocationSize = 1, initialValue = 7)
    private Long groupId;

    @Column(name = "GROUP_NAME")
    private String groupName;

    @Column(name = "DISPLAY_ORDER")
    private Long displayOrder;

    @Column(name = "SELECTED_IND")
    private String selectedIND;

    @Column(name = "LAST_UPDATE_TS")
    private Timestamp updateTimestamp;

    @Column(name = "LAST_UPDATE_USER")
    private String updateUser;

    public UserGroup() {
        super();
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Long getGroupId() {
        return this.groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Long getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder;
    }

    public String getSelectedIND() {
        return selectedIND;
    }

    public void setSelectedIND(String selectedIND) {
        this.selectedIND = selectedIND;
    }

    public Timestamp getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(Timestamp updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

}
