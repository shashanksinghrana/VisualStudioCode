package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The persistent class for the FC_LOOKUP database table.
 *
 */
@Entity
@Table(name = "FC_LOOKUP")
public class FcLookup implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The lookup id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqFcLookupId")
    @SequenceGenerator(name = "seqFcLookupId", sequenceName = "FC_LOOKUP_ID_SEQ", allocationSize = 1)
    private Long lookupId;

    /** The lookup name. */
    @Column(name = "NAME")
    private String name;

    /** The lookup type. */
    @Column(name = "TYPE")
    private String type;

    /** The created by user. */
    @Column(name = "CREATED_BY")
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    /** The display order. */
    @Column(name = "DISPLAY_ORDER")
    private Long displayOrder;

    /** The display label. */
    @Column(name = "DISPLAY_LABEL")
    private String displayLabel;

    /**
     * Instantiates a new Lookup.
     */
    public FcLookup() {

    }

    /**
     * Gets the lookup id.
     *
     * @return the lookup id
     */
    public Long getLookupId() {
        return lookupId;
    }

    /**
     * Sets the lookup id.
     *
     * @param lookupId
     *            the new lookup id
     */
    public void setLookupId(Long lookupId) {
        this.lookupId = lookupId;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the new type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the created by user.
     *
     * @return the created by user
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * Sets the created by user.
     *
     * @param createdUser
     *            the new created by user
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * Gets the created ts.
     *
     * @return the created ts
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created ts.
     *
     * @param createdDate
     *            the new created ts
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the last updated by user.
     *
     * @return the last updated by user
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * Sets the last updated by user.
     *
     * @param lastUpdatedUser
     *            the new updated by user
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * Gets the updated ts.
     *
     * @return the updated ts
     */
    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated ts.
     *
     * @param updatedDate
     *            the new updated ts
     */
    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Gets the display order.
     *
     * @return the display order
     */
    public Long getDisplayOrder() {
        return displayOrder;
    }

    /**
     * Sets the display order.
     *
     * @param displayOrder
     *            the new display order
     */
    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder;
    }

    /**
     * Gets the display label.
     *
     * @return the display label
     */
    public String getDisplayLabel() {
        return displayLabel;
    }

    /**
     * Sets the display label.
     *
     * @param displayLabel
     *            the new display label
     */
    public void setDisplayLabel(String displayLabel) {
        this.displayLabel = displayLabel;
    }

}
