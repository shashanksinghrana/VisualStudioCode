package com.mediaservices.c2c.fc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.CompensationOperation;

/**
 * The Interface CompensationOperationRepository.
 */
public interface CompensationOperationRepository extends JpaRepository<CompensationOperation, Long> {

}
