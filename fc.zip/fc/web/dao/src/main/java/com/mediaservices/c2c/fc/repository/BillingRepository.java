package com.mediaservices.c2c.fc.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.Billing;

/**
 * The Interface CreditBillingRepository.
 */
public interface BillingRepository extends JpaRepository<Billing, Long> {

    /**
     * Find by deal id.
     *
     * @param dealid
     *            the dealid
     * @return the list
     */
    Billing findByDealId(Long dealid);

    /**
     * Find by deal id in.
     *
     * @param deals
     *            the deals
     * @return the list
     */
    List<Billing> findByDealIdIn(Set<Long> deals);
}
