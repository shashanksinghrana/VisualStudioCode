package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;

/**
 * The persistent class for the PROJECT database table.
 *
 */
@Entity
@Table(name = "PROJECT")
public class FCProject implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The project id. */
    @Id
    @Column(name = "PROJECT_ID")
    @GeneratedValue(generator = "seqFCProjectId")
    @SequenceGenerator(name = "seqFCProjectId", sequenceName = "DBO_MP.SEQ_HITLIST_PROJ_ID", allocationSize = 1)
    private Long projectId;

    /** The project titles. */
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "PROJECT_ID", updatable = false, insertable = false)
    @OrderBy("projectTitleId")
    private Set<FCProjectTitle> titles;

    /** The deals. */
    @Transient
    private Set<Deal> deals;

    /** The sap code. */
    @Column(name = "GL#_PROD")
    private String sapCode;

    /** The sag prod id. */
    @Column(name = "SAG_PROD_ID", length = 10)
    private String sagProdId;

    /** The assigned to user id. */
    @Column(name = "ASSIGNED_TO_USER_ID")
    private String assignedToUserId;

    /** The create user. */
    @Column(name = "CREATED_BY")
    private String createUser;

    /** The created date. */
    @Column(name = "CREATED_DATE")
    private ZonedDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The updated date. */
    @Column(name = "UPDATED_DATE")
    private ZonedDateTime updatedDate;

    /** The start date. */
    @Column(name = "START_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate startDate;

    /** The wrap date. */
    @Column(name = "WRAP_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate wrapDate;

    /** The release date. */
    @Column(name = "RELEASE_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate releaseDate;

    /** The studio id. */
    @Column(name = "STUDIO")
    private Long studioId;

    @Column(name = "DEPARTMENT_ID")
    private Long department;

    /** The studio FK. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STUDIO", referencedColumnName = "LOOKUP_ID", insertable = false, updatable = false)
    private SharedLookup studio;

    /** The type. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TYPE", insertable = false, updatable = false)
    private SharedLookup type;

    /** The type. */
    @Column(name = "TYPE")
    private Long typeId;

    /** The status id. */
    @Column(name = "STATUS")
    private Long statusId;

    /** The status. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STATUS", insertable = false, updatable = false)
    private DynamicAttributeValues status;

    /** The project creation date. */
    @Column(name = "PROJECT_CREATION_DATE ")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate projectCreationDate;

    /** The note. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PROJECT_ID", referencedColumnName = "PROJECT_ID", insertable = false, updatable = false)
    private ProjectNote note;

    /** The casting company set. */
    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "PROJECT_ID", insertable = false, updatable = false)
    @OrderBy("projectCastingCompanyId asc")
    private List<ProjectCastingCompany> castingCompanySet;

    /** The assigned to user. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ASSIGNED_TO_USER_ID", insertable = false, updatable = false)
    private User assignedToUser;

    /** The created by app. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CREATED_BY_APP")
    private SharedLookup createdByApp;

    /**
     * Instantiates a new project.
     */
    public FCProject() {

    }

    /**
     * Gets the project id.
     *
     * @return the project id
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * Sets the project id.
     *
     * @param projectId
     *            the new project id
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * Gets the titles.
     *
     * @return the titles
     */
    public Set<FCProjectTitle> getTitles() {
        return titles;
    }

    /**
     * Sets the titles.
     *
     * @param titles
     *            the new titles
     */
    public void setTitles(Set<FCProjectTitle> titles) {
        this.titles = titles;
    }

    /**
     * Gets the deals.
     *
     * @return the deals
     */
    public Set<Deal> getDeals() {
        return deals;
    }

    /**
     * Sets the deals.
     *
     * @param deals
     *            the new deals
     */
    public void setDeals(Set<Deal> deals) {
        this.deals = deals;
    }

    /**
     * Gets the sap code.
     *
     * @return the sap code
     */
    public String getSapCode() {
        return sapCode;
    }

    /**
     * Sets the sap code.
     *
     * @param sapCode
     *            the new sap code
     */
    public void setSapCode(String sapCode) {
        this.sapCode = sapCode;
    }

    /**
     * Gets the sag prod id.
     *
     * @return the sag prod id
     */
    public String getSagProdId() {
        return sagProdId;
    }

    /**
     * Sets the sag prod id.
     *
     * @param sagProdId
     *            the new sag prod id
     */
    public void setSagProdId(String sagProdId) {
        this.sagProdId = sagProdId;
    }

    /**
     * Gets the project creation date.
     *
     * @return the project creation date
     */
    public LocalDate getProjectCreationDate() {
        return projectCreationDate;
    }

    /**
     * Sets the project creation date.
     *
     * @param projectCreationDate
     *            the new project creation date
     */
    public void setProjectCreationDate(LocalDate projectCreationDate) {
        this.projectCreationDate = projectCreationDate;
    }

    /**
     * Gets the creates the user.
     *
     * @return the creates the user
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * Sets the creates the user.
     *
     * @param createUser
     *            the new creates the user
     */
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    /**
     * Gets the last updated user.
     *
     * @return the last updated user
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * Sets the last updated user.
     *
     * @param lastUpdatedUser
     *            the new last updated user
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public ZonedDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate
     *            the new created date
     */
    public void setCreatedDate(ZonedDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the release date.
     *
     * @return the release date
     */
    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    /**
     * Sets the release date.
     *
     * @param releaseDate
     *            the new release date
     */
    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }

    /**
     * Gets the start date.
     *
     * @return the start date
     */
    public LocalDate getStartDate() {
        return startDate;
    }

    /**
     * Sets the start date.
     *
     * @param startDate
     *            the new start date
     */
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    /**
     * Gets the studio.
     *
     * @return the studio
     */
    public SharedLookup getStudio() {
        return studio;
    }

    /**
     * Sets the studio.
     *
     * @param studio
     *            the new studio
     */
    public void setStudio(SharedLookup studio) {
        this.studio = studio;
    }

    /**
     * Gets the type Id.
     *
     * @return the type
     */
    public Long getTypeId() {
        return typeId;
    }

    /**
     * Sets the type.
     *
     * @param typeId
     *            the new type id
     */
    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    /**
     * Gets the status id.
     *
     * @return the status id
     */
    public Long getStatusId() {
        return statusId;
    }

    /**
     * Sets the status id.
     *
     * @param statusId
     *            the new status id
     */
    public void setStatusId(Long statusId) {
        this.statusId = statusId;
    }

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate
     *            the new updated date
     */
    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Gets the wrap date.
     *
     * @return the wrap date
     */
    public LocalDate getWrapDate() {
        return wrapDate;
    }

    /**
     * Sets the wrap date.
     *
     * @param wrapDate
     *            the new wrap date
     */
    public void setWrapDate(LocalDate wrapDate) {
        this.wrapDate = wrapDate;
    }

    /**
     * Gets the assigned to user id.
     *
     * @return the assigned to user id
     */
    public String getAssignedToUserId() {
        return assignedToUserId;
    }

    /**
     * Sets the assigned to user id.
     *
     * @param assignedToUserId
     *            the new assigned to user id
     */
    public void setAssignedToUserId(String assignedToUserId) {
        this.assignedToUserId = assignedToUserId;
    }

    /**
     * Gets the studio id.
     *
     * @return the studio id
     */
    public Long getStudioId() {
        return studioId;
    }

    /**
     * Sets the studio id.
     *
     * @param studioId
     *            the new studio id
     */
    public void setStudioId(Long studioId) {
        this.studioId = studioId;
    }

    /**
     * Gets the note.
     *
     * @return the note
     */
    public ProjectNote getNote() {
        return note;
    }

    /**
     * Sets the note.
     *
     * @param note
     *            the new note
     */
    public void setNote(ProjectNote note) {
        this.note = note;
    }

    /**
     * Gets the casting company set.
     *
     * @return the casting company set
     */
    public List<ProjectCastingCompany> getCastingCompanySet() {
        return castingCompanySet;
    }

    /**
     * Sets the casting company set.
     *
     * @param castingCompanySet
     *            the new casting company set
     */
    public void setCastingCompanySet(List<ProjectCastingCompany> castingCompanySet) {
        this.castingCompanySet = castingCompanySet;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public SharedLookup getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the new type
     */
    public void setType(SharedLookup type) {
        this.type = type;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public DynamicAttributeValues getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status
     *            the new status
     */
    public void setStatus(DynamicAttributeValues status) {
        this.status = status;
    }

    /**
     * Gets the assigned to user.
     *
     * @return the assigned to user
     */
    public User getAssignedToUser() {
        return assignedToUser;
    }

    /**
     * Sets the assigned to user.
     *
     * @param assignedToUser
     *            the new assigned to user
     */
    public void setAssignedToUser(User assignedToUser) {
        this.assignedToUser = assignedToUser;
    }

    /**
     * Gets the created by app.
     *
     * @return the created by app
     */
    public SharedLookup getCreatedByApp() {
        return createdByApp;
    }

    /**
     * Sets the created by app.
     *
     * @param createdByApp
     *            the new created by app
     */
    public void setCreatedByApp(SharedLookup createdByApp) {
        this.createdByApp = createdByApp;
    }

    public Long getDepartment() {
		return department;
	}
    
    public void setDepartment(Long department) {
		this.department = department;
	}

}
