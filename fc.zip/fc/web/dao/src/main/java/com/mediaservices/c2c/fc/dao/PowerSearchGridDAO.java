package com.mediaservices.c2c.fc.dao;

import org.springframework.data.domain.Pageable;

import com.mediaservices.c2c.fc.dto.PageContent;
import com.mediaservices.c2c.fc.dto.PowerSearchCriteriaDto;
import com.mediaservices.c2c.fc.dto.PowerSearchDto;

/**
 * The Interface PowerSearchGridDAO.
 */
public interface PowerSearchGridDAO {

    /**
     * Gets the power search by filters.
     *
     * @param searchFilter
     *            the search filter
     * @param pageable
     *            the pageable
     * @return the power search by filters
     */
    public PageContent<PowerSearchDto> getPowerSearchByFilters(PowerSearchCriteriaDto searchFilter, Pageable pageable);

    String getPowerSearchReport(PowerSearchCriteriaDto searchFilter);

}
