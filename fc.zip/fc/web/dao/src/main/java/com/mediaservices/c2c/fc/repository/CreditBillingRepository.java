package com.mediaservices.c2c.fc.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.CreditBilling;

/**
 * The Interface CreditBillingRepository.
 */
public interface CreditBillingRepository extends JpaRepository<CreditBilling, Long> {

    /**
     * Find by deal id.
     *
     * @param dealid
     *            the dealid
     * @return the list
     */
    List<CreditBilling> findByDealId(Long dealid);

    /**
     * Find all billing text by deal id.
     *
     * @param dealId
     *            the deal id
     * @return the list
     */
    List<String> findAllBillingTextByDealId(Long dealId);

    /**
     * Find all by deal id in.
     *
     * @param deals
     *            the deals
     * @return the list
     */
    List<CreditBilling> findAllByDealIdIn(Set<Long> deals);
}
