package com.mediaservices.c2c.fc.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.Formula;

/**
 * The Interface FormulaRepository.
 */
public interface FormulaRepository extends JpaRepository<Formula, Long> {

    /**
     * Returns the Formulas with the given parameters.
     * 
     * @param dealType
     * @param pageType
     * @param feeTypeId
     * @param studioId
     * @return Set<Formula>
     */
    @Query(value = QueryConstants.FORMULAS_BY_PAGE_AND_DEAL_TYPE_AND_FEE_TYPE_AND_STUDIO_ID, nativeQuery = true)
    public Set<Formula> getFormulasUsingDealTypeAndTypeLookupAndSubTypeLookupAndStudio(
            @Param("dealType") String dealType, @Param("pageType") String pageType, @Param("feeTypeId") Long feeTypeId,
            @Param("studioId") Long studioId);

    /**
     * Returns the Formulas with the given parameters.
     * 
     * @param dealType
     * @param pageType
     * @param feeTypeId
     * @return Set<Formula>
     */
    @Query(value = QueryConstants.FORMULAS_BY_PAGE_AND_DEAL_TYPE_AND_FEE_TYPE, nativeQuery = true)
    public Set<Formula> getFormulasUsingDealTypeAndTypeLookupAndSubTypeLookup(@Param("dealType") String dealType,
            @Param("pageType") String pageType, @Param("feeTypeId") Long feeTypeId);

    /**
     * Returns the Formulas with the given parameters.
     * 
     * @param dealType
     * @param pageType
     * @param studioId
     * @return Set<Formula>
     */
    @Query(value = QueryConstants.FORMULAS_BY_PAGE_AND_DEAL_TYPE_AND_STUDIO_ID, nativeQuery = true)
    public Set<Formula> getFormulasUsingDealTypeAndTypeLookupAndStudio(@Param("dealType") String dealType,
            @Param("pageType") String pageType, @Param("studioId") Long studioId);

    /**
     * Returns the Formulas with the given parameters.
     * 
     * @param dealType
     * @param pageType
     * @return Set<Formula>
     */
    @Query(value = QueryConstants.FORMULAS_BY_PAGE_AND_DEAL_TYPE, nativeQuery = true)
    public Set<Formula> getFormulasUsingDealTypeAndTypeLookup(@Param("dealType") String dealType,
            @Param("pageType") String pageType);

}
