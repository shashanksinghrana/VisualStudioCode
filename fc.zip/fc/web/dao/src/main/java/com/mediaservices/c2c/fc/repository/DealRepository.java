package com.mediaservices.c2c.fc.repository;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.Deal;

/**
 * The Interface DealRepository.
 */
public interface DealRepository extends JpaRepository<Deal, Long> {

    /**
     * Find all by project id.
     *
     * @param projectId
     *            the project id
     * @return the sets the
     */
    @Query(nativeQuery = true, value = "SELECT d.* FROM FC_DEAL d INNER JOIN DBO_TC.PERSON p ON d.PERFORMER_PARTY_ID = p.PARTY_ID where d.IS_ACTIVE ='Y' and d.PROJECT_ID = :projectId ORDER BY p.LAST_NAME")
    Set<Deal> findAllByProjectId(@Param("projectId") Long projectId);

    /**
     * Find by deal id.
     *
     * @param dealId
     *            the deal id
     * @return the deal
     */
    @Query(value = "select d.* from DBO_FC.FC_DEAL d where d.id = :dealId and d.IS_ACTIVE = 'Y'", nativeQuery = true)
    Deal getDeal(@Param("dealId") Long dealId);

    /**
     * Find by deal id.
     *
     * @param dealId
     *            the deal id
     * @return the deal
     */
    @Query(value = "select d.PERFORMER_PARTY_ID from DBO_FC.FC_DEAL d where d.id = :dealId and d.IS_ACTIVE = 'Y'", nativeQuery = true)
    Long getPerformerIdByDealId(@Param("dealId") Long dealId);

    /**
     * Delete deal by id.
     *
     * @param dealId
     *            the deal id
     */
    @Modifying
    // @Query("Update Deal u set u.active ='N' WHERE u.dealId = :dealId")
    @Query(value = "UPDATE DBO_FC.FC_DEAL d set d.IS_ACTIVE = 'N' where d.id = :dealId", nativeQuery = true)
    void deleteDealById(@Param("dealId") Long dealId);

    /**
     * Update deal update date.
     *
     * @param dealId
     *            the deal id
     * @param updatedBy
     *            the updated by
     */
    @Modifying
    @Query(value = "UPDATE DBO_FC.FC_DEAL d set d.UPDATE_DATE =:updateDate , d.UPDATED_BY = :updatedBy where d.id = :dealId", nativeQuery = true)
    void updateDealUpdateDate(@Param("dealId") Long dealId, @Param("updatedBy") String updatedBy,
            @Param("updateDate") ZonedDateTime updateDate);

    /**
     * Find deals by project id.
     *
     * @param projectId
     *            the project id
     * @return the list
     */
    @Query(value = "select d.project_id, d.id as deal_id, d.PERFORMER_PARTY_ID, d.PERFORMER_ROLE, d.UPDATE_DATE as deal_date, lk.* from DBO_FC.FC_DEAL d left join DBO_FC.FC_LOOKUP lk"
            + " on d.UNION_LOOKUP_ID = lk.ID where d.is_active ='Y' and d.project_id in (:projectIds) order by d.project_id , d.UPDATE_DATE desc, d.id asc", nativeQuery = true)
    List<Object[]> findDealsByProjectId(@Param("projectIds") Set<Long> projectId);

    /**
     * Find deals with deal date by project id.
     *
     * @param projectId
     *            the project id
     * @return the list
     */
    @Query(value = "select d.project_id, d.id as deal_id, p.FIRST_NAME,  p.LAST_NAME, d.UPDATE_DATE as deal_update_date, d.DEAL_DATE, lk.Id, lk.NAME,lk.TYPE from DBO_FC.FC_DEAL d inner JOIN DBO_TC.PERSON p ON d.PERFORMER_PARTY_ID = p.PARTY_ID left join DBO_FC.FC_LOOKUP lk"
            + " on d.UNION_LOOKUP_ID = lk.ID where d.is_active ='Y' and d.project_id in (:projectIds) order by d.project_id , d.UPDATE_DATE desc, d.id asc", nativeQuery = true)
    List<Object[]> findDealsWithDealDateByProjectId(@Param("projectIds") Set<Long> projectIds);

    /**
     * Find deal deatails by project id.
     *
     * @param projectId
     *            the project id
     * @return the list
     */
    @Query(value = " SELECT d.project_id,   d.UPDATE_DATE,   d.id,   p.party_id,   a.FIRST_NAME,   "
            + "a.last_name,   p.DOB,   c.COMPANY_NAME FROM DBO_TC.PERSON p INNER JOIN DBO_FC.FC_DEAL d "
            + "ON d.PERFORMER_PARTY_ID = p.PARTY_ID LEFT JOIN DBO_FC.FC_REPRESENTATION r ON r.DEAL_ID        "
            + "        = d.ID LEFT JOIN DBO_TC.COMPANY c ON c.PARTY_ID = r.company_party_id LEFT JOIN DBO_TC.PARTY_AKA a "
            + "ON d.PERFORMER_AKA_ID=a.ID WHERE d.is_active    ='Y' AND d.project_id IN (:projectIds) ORDER BY d.project_id , "
            + "  d.UPDATE_DATE DESC,   d.id ASC,   a.LAST_NAME,   c.COMPANY_NAME", nativeQuery = true)
    List<Object[]> findDealDeatailsByProjectId(@Param("projectIds") Set<Long> projectId);

    /**
     * Find deals by deal ids.
     *
     * @param dealIds
     *            the deal ids
     * @return the list
     */
    @Query(value = "select d.id as deal_id, d.PERFORMER_PARTY_ID, d.PERFORMER_ROLE,d.PERFORMER_ROLE_NUMBER,d.PERFORMER_NOTE, d.DEAL_DATE as deal_date,pn.PARTY_ID,"
            + "a.FIRST_NAME,a.LAST_NAME,pn.DOB, lk.* from DBO_FC.FC_DEAL d inner join DBO_TC.PERSON pn on d.PERFORMER_PARTY_ID = pn.PARTY_ID left join "
            + "DBO_FC.FC_LOOKUP lk on d.UNION_LOOKUP_ID = lk.ID left join DBO_TC.PARTY_AKA a ON d.PERFORMER_AKA_ID=a.ID where d.is_active ='Y' and  d.id in (:dealIds) order by  d.id asc", nativeQuery = true)
    List<Object[]> findDealsByDealIds(@Param("dealIds") Set<Long> dealIds);

    /**
     * Find role by search term.
     *
     * @param searchTerm
     *            the search term
     * @param count
     *            the count
     * @return the list
     */
    @Query(value = QueryConstants.DISTINCT_PERFORMER_ROLE_BY_SEARCH_TERM, nativeQuery = true)
    List<String> findRoleBySearchTerm(@Param("searchTerm") String searchTerm, @Param("count") Pageable count);

    /**
     * Gets the aka names by deal id in.
     *
     * @param dealIds
     *            the deal ids
     * @return the aka names by deal id in
     */
    @Query(value = QueryConstants.PERFORMER_NAME_BY_AKA_IDs, nativeQuery = true)
    List<Object[]> getAkaNamesByDealIdIn(@Param("dealIds") Set<Long> dealIds);

    /**
     * Gets the pkas by deal id in.
     *
     * @param dealIds
     *            the deal ids
     * @return the pkas by deal id in
     */
    @Query(value = QueryConstants.PERFORMER_CURRENT_NAMEs, nativeQuery = true)
    List<Object[]> getPkasByDealIdIn(@Param("dealIds") Set<Long> dealIds);

}
