package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.DynamicAttributeValues;

/**
 * The Interface DynamicAttributeValueRepository.
 */
public interface DynamicAttributeValueRepository extends JpaRepository<DynamicAttributeValues, Long> {

    /**
     * Returns the List of DynamicAttributeValues where the dynamic attribute
     * matches the parameters.
     *
     * @param type
     * @param filter
     * @return List<DynamicAttributeValues>
     */
    @Query(value = QueryConstants.DYNAMIC_ATTRIBUTE_VALUE_BY_ATTRIBUTE_TYPE_AND_MODULE, nativeQuery = true)
    public List<DynamicAttributeValues> getDynamicAttributeValueByAttribute(@Param("type") String type,
            @Param("module") String module, @Param("studioId") Long studioId);

    /**
     * Returns the List of DynamicAttributeValues where the dynamic attribute
     * matches the parameters.
     *
     * @param type
     * @return List<DynamicAttributeValues>
     */
    @Query(value = QueryConstants.DYNAMIC_ATTRIBUTE_VALUE_BY_ATTRIBUTE_TYPE, nativeQuery = true)
    public List<DynamicAttributeValues> getDynamicAttributeValueByAttributeType(@Param("type") String type);
}
