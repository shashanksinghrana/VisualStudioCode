package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.WorkPeriod;

/**
 * The Interface WorkPeriodRepository.
 */
public interface WorkPeriodRepository extends JpaRepository<WorkPeriod, Long> {

    /**
     * Find all by project id.
     *
     * @param projectId
     *            the project id
     * @return the list
     */
    List<WorkPeriod> findAllByProjectId(Long projectId);

}
