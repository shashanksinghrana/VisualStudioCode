package com.mediaservices.c2c.fc.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.dao.AllProjectGridDAO;
import com.mediaservices.c2c.fc.dto.AllProjectDto;
import com.mediaservices.c2c.fc.dto.AllProjectsGridSearchCriteria;
import com.mediaservices.c2c.fc.grid.AllProjectListQueryBuilder;

/**
 * The Class AllProjectGridDAOImpl2.
 */
@Component
public class AllProjectGridDAOImpl implements AllProjectGridDAO {

    /** The Constant COLON. */
    private static final String COLON = ":";

    /** The Constant FROM. */
    private static final String FROM = " from ";

    /** The Constant PARTY_TABLE. */
    private static final String PROJECT_TABLE = "dbo_mp.PROJECT";

    /** The Constant OUTER_SELECT_QUERY. */
    private static final String OUTER_SELECT_QUERY = "select project.* from (\n";

    /** The Constant SELECT. */
    private static final String SELECT = "select";

    /** The Constant DISTINCT_PARTY_ID. */
    private static final String DISTINCT_PROJECT_ID = " distinct project.PROJECT_ID";

    /** The Constant FIELD_TITLE. */
    private static final String FIELD_TITLE = "title";

    /** The Constant FIELD_UNION. */
    private static final String FIELD_UNION = "union";

    /** The Constant FIELD_ROLE. */
    private static final String FIELD_ROLE = "role";
    
    private static final String FIELD_ASSIGNED_TO_USER_ID = "assignedToUserId";

    /** The Constant FIELD_SAP. */
    private static final String FIELD_SAP = "sapCode";

    /** The Constant FIELD_PERFORMER_NAME. */
    private static final String FIELD_PERFORMER_NAME = "performerName";

    /** The Constant FIELD_AGENCY. */
    private static final String FIELD_AGENCY = "agency";

    /** The em. */
    @PersistenceContext
    private EntityManager em;

    /** The extracter. */
    @Autowired
    private AllProjectListViewGridDataExtractor extracter;
    

    /** The Constant SELECT_PROJECT_COUNT. */
    private static final String SELECT_PROJECT_COUNT = SELECT + " count(" + DISTINCT_PROJECT_ID + ") as count" + FROM
            + PROJECT_TABLE + " project \n";

    /** The Constant SELECT_PROJECTS. */
    private static final String SELECT_PROJECTS = OUTER_SELECT_QUERY + SELECT + DISTINCT_PROJECT_ID + FROM
            + PROJECT_TABLE + " project \n";

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.fc.dao.AllProjectGridDAO2#getProjectByFilters(com.
     * mediaservices.c2c.fc.dto.AllProjectsGridSearchCriteria,
     * org.springframework.data.domain.Pageable)
     */
    @Override
    public Page<AllProjectDto> getProjectByFilters(AllProjectsGridSearchCriteria searchFilter, Pageable pageable) {

        List<AllProjectDto> projectList = new ArrayList<>();

        AllProjectListQueryBuilder builder = new AllProjectListQueryBuilder();

        whereCondition(builder);

        filterConditions(searchFilter, builder);

        Long totalRecords = getCount(builder);

        if (totalRecords > 0) {
            Sort sort = pageable.getSort();
            String sortBy = (sort != null) ? sort.toString().split(COLON)[0] : "";
            String sortDirection = getSortDirection(sort);
            sortConditions(builder, sortBy, sortDirection);
            builder.setQuery(SELECT_PROJECTS);
            Query companyQuery = em.createNativeQuery(builder.buildQuery());
            setQueryParam(companyQuery, builder.getFilterAndSortConditions().getNamedParam());
            companyQuery.setMaxResults(pageable.getPageSize());
            companyQuery.setFirstResult((int) pageable.getOffset());
            List<Object> result = companyQuery.getResultList();
            List<Long> projectIds = new ArrayList<>();

            result.forEach(obj -> {
                Long projectId;
                /***
                 * It returns two values in case we retrieve data from db for
                 * any page other than first page and project id at first place
                 * of the result which if of Type BigDecimal.
                 */
                if (obj instanceof BigDecimal) {
                    projectId = convertToLong((BigDecimal) obj);
                } else {
                    Object[] columns = (Object[]) obj;
                    projectId = convertToLong((BigDecimal) columns[0]);
                }

                projectIds.add(projectId);
            });

            projectList = extracter.createProjectList(projectIds);
        }
        return new PageImpl<>(projectList, pageable, totalRecords);
    }

    /**
     * Sort conditions.
     *
     * @param builder
     *            the builder
     * @param sortBy
     *            the sort by
     * @param sortDirection
     *            the sort direction
     */
    private void sortConditions(AllProjectListQueryBuilder builder, String sortBy, String sortDirection) {
        if (FIELD_TITLE.equals(sortBy)) {
            builder.sortByTitle(sortDirection);
        } else if (FIELD_UNION.equals(sortBy)) {
            builder.sortByUnion(sortDirection);
        } else if (FIELD_ROLE.equals(sortBy)) {
            builder.sortByRole(sortDirection);
        } else if (FIELD_SAP.equals(sortBy)) {
            builder.sortBySap(sortDirection);
        } else if (FIELD_PERFORMER_NAME.equals(sortBy)) {
            builder.sortByPerformerName(sortDirection);
        } else if (FIELD_AGENCY.equals(sortBy)) {
            builder.sortByAgency(sortDirection);
        } else if ("updateDate".equals(sortBy)) {
            builder.sortByDate(sortDirection);
        }
    }

    /**
     * Gets the sort direction.
     *
     * @param sort
     *            the sort
     * @return the sort direction
     */
    private String getSortDirection(Sort sort) {
        String sortDirection = (sort != null) ? sort.toString().split(COLON)[1].trim() : "";
        return Sort.Direction.ASC.toString().equalsIgnoreCase(sortDirection) ? Sort.Direction.ASC.toString()
                : Sort.Direction.DESC.toString();
    }

    /**
     * Where condition.
     *
     * @param builder
     *            the builder
     */
    private void whereCondition(AllProjectListQueryBuilder builder) {
        builder.getFilterAndSortConditions().getConditionsFilter().add(" 1 = 1 \n");
    }

    /**
     * Filter conditions.
     *
     * @param searchDTO
     *            the search DTO
     * @param builder
     *            the builder
     */
    private void filterConditions(AllProjectsGridSearchCriteria searchDTO, AllProjectListQueryBuilder builder) {

        if (!StringUtils.isBlank(searchDTO.getTitle())) {
            builder.filterByTitle(searchDTO.getTitle());
        }

        if (!StringUtils.isBlank(searchDTO.getPerformerName())) {
            builder.filterByPerformerName(searchDTO.getPerformerName());
        }

        if (!StringUtils.isBlank(searchDTO.getAgency())) {
            builder.filterByAgency(searchDTO.getAgency());
        }

        if (!StringUtils.isBlank(searchDTO.getSapCode())) {
            builder.filterBySapCode(searchDTO.getSapCode());
        }

        if (!StringUtils.isBlank(searchDTO.getUnion())) {
            builder.filterByUnion(searchDTO.getUnion());
        }

        if (!StringUtils.isBlank(searchDTO.getRole())) {
            builder.filterByRole(searchDTO.getRole());
        }
        
        if (!StringUtils.isBlank(searchDTO.getAssignedToUserId())) {
            builder.filterByAssignedToUserId(searchDTO.getAssignedToUserId());
        }
    }

    /**
     * Gets the count.
     *
     * @param builder
     *            the builder
     * @return the count
     */
    private Long getCount(AllProjectListQueryBuilder builder) {
        builder.setQuery(SELECT_PROJECT_COUNT);
        Query talentQuery = em.createNativeQuery(builder.buildCountQuery());
        setQueryParam(talentQuery, builder.getFilterAndSortConditions().getNamedParam());
        BigDecimal count = (BigDecimal) talentQuery.getSingleResult();
        return count.longValue();
    }

    /**
     * Sets the query param.
     *
     * @param query
     *            the query
     * @param namedParam
     *            the named param
     */
    private void setQueryParam(Query query, Map<String, List<String>> namedParam) {

        if (namedParam.containsKey(FIELD_TITLE)) {
            query.setParameter(FIELD_TITLE, namedParam.get(FIELD_TITLE));
        }

        if (namedParam.containsKey(FIELD_SAP)) {
            query.setParameter(FIELD_SAP, namedParam.get(FIELD_SAP));
        }

        if (namedParam.containsKey(FIELD_PERFORMER_NAME)) {
            query.setParameter(FIELD_PERFORMER_NAME, namedParam.get(FIELD_PERFORMER_NAME));
        }

        if (namedParam.containsKey(FIELD_AGENCY)) {
            query.setParameter(FIELD_AGENCY, namedParam.get(FIELD_AGENCY));
        }

        if (namedParam.containsKey(FIELD_ROLE)) {
            query.setParameter(FIELD_ROLE, namedParam.get(FIELD_ROLE));
        }

        if (namedParam.containsKey(FIELD_UNION)) {
            query.setParameter(FIELD_UNION, namedParam.get(FIELD_UNION));
        }
        
        if (namedParam.containsKey(FIELD_ASSIGNED_TO_USER_ID)) {
            query.setParameter(FIELD_ASSIGNED_TO_USER_ID, namedParam.get(FIELD_ASSIGNED_TO_USER_ID));
        }

    }

    /**
     * Convert to long.
     *
     * @param source
     *            the source
     * @return the long
     */
    private Long convertToLong(BigDecimal source) {
        if (source == null) {
            return null;
        }
        return source.longValue();
    }

}
