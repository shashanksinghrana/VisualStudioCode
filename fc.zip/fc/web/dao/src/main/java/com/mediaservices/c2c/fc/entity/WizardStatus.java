package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

@Entity
@Table(name = "FC_WIZARD_STATUS")
public class WizardStatus implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "wizardStatusIdSeq")
    @SequenceGenerator(name = "wizardStatusIdSeq", sequenceName = "DBO_FC.FC_WIZARD_STATUS_ID_SEQ", allocationSize = 1)
    private Long wizardStatusId;

    @Column(name = "DEAL_ID")
    private Long dealId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PAGE_LOOKUP_ID")
    private FcLookup page;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "STATUS_LOOKUP_ID", insertable = false, updatable = false)
    private FcLookup status;

    @Column(name = "STATUS_LOOKUP_ID")
    private Long statusLookupId;

    /** The created by user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    public WizardStatus() {
        super();
    }

    public Long getDealId() {
        return dealId;
    }

    public Long getWizardStatusId() {
        return wizardStatusId;
    }

    public void setWizardStatusId(Long wizardStatusId) {
        this.wizardStatusId = wizardStatusId;
    }

    public FcLookup getPage() {
        return page;
    }

    public void setPage(FcLookup page) {
        this.page = page;
    }

    public Long getStatusLookupId() {
        return statusLookupId;
    }

    public void setStatusLookupId(Long statusLookupId) {
        this.statusLookupId = statusLookupId;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public FcLookup getStatus() {
        return status;
    }

    public void setStatus(FcLookup status) {
        this.status = status;
    }

}
