package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the FC_SIGNATORY_USERS database table.
 *
 */
@Entity
@Table(name = "FC_SIGNATORY_USERS")
public class SignatoryUser implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "Id")
    private Long signatoryUserId;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATE_DATE")
    private Date updatedDate;

    /**
     * Default Constructor for a new SignatoryUser
     */
    public SignatoryUser() {
    }

    public Long getSignatoryUserId() {
        return signatoryUserId;
    }

    public void setSignatoryUserId(Long signatoryUserId) {
        this.signatoryUserId = signatoryUserId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

}