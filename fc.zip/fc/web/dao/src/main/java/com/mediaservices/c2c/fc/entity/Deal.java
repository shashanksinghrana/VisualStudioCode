package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZonedDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.Type;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;

import com.mediaservices.c2c.fc.history.entity.FCProjectHistory;
import com.mediaservices.c2c.talent.dto.Talent;
import com.mediaservices.c2c.talent.dto.TypeAheadNameDto;

/**
 * The Class Deal.
 */
@Entity
@Table(name = "FC_DEAL")
public class Deal implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The deal id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqFCDealId")
    @SequenceGenerator(name = "seqFCDealId", sequenceName = "DBO_FC.FC_DEAL_ID_SEQ", allocationSize = 1)
    private Long dealId;

    /** The union lookup. */
    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
    @JoinColumn(name = "UNION_LOOKUP_ID", insertable = false, updatable = false)
    private FcLookup unionLookup;

    /** The union id. */
    @Column(name = "UNION_LOOKUP_ID")
    private Long unionId;

    /** The project. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
        @JoinColumn(updatable = false, insertable = false, name = "PROJECT_ID", referencedColumnName = "PROJECT_ID"),
        @JoinColumn(updatable = false, insertable = false, name = "PROJECT_ID_VER", referencedColumnName = "VERSION") })
    @NotFound(action = NotFoundAction.IGNORE)
    private FCProjectHistory project;

    /** The project id. */
    @Column(name = "PROJECT_ID")
    private Long projectId;

    @Column(name = "PROJECT_ID_VER")
    private Long projectIdVer;

    /** The performer party id. */
    @Column(name = "PERFORMER_PARTY_ID")
    private Long performerPartyId;

    /** The performer party id ver. */
    @Column(name = "PERFORMER_PARTY_ID_VER")
    private Long performerPartyIdVer;

    /** The performer aka id. */
    @Column(name = "PERFORMER_AKA_ID")
    private Long performerAkaId;

    /** The loanout id. */
    @Column(name = "LOANOUT_ID")
    private Long loanoutId;

    /** The loanout id ver. */
    @Column(name = "LOANOUT_PARTY_ID_VER")
    private Long loanoutIdVer;

    /** The deal date. */
    @Column(name = "DEAL_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate dealDate;

    /** The performer I nine status id. */
    @Column(name = "PERFORMER_I_NINE_STATUS_ID")
    private Long performerINineStatusId;

    /** The i 9 status lookup. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PERFORMER_I_NINE_STATUS_ID", updatable = false, insertable = false)
    private FcLookup i9StatusLookup;

    /** The performer role number. */
    @Column(name = "PERFORMER_ROLE_NUMBER")
    private String performerRoleNumber;

    /** The prod company id. */
    @Column(name = "PROD_COMPANY_ID")
    private Long prodCompanyId;

    /** The performer role. */
    @Column(name = "PERFORMER_ROLE")
    private String performerRole;

    /** The performer note. */
    @Column(name = "PERFORMER_NOTE")
    private String performerNote;

    /** The performer party version id. */
    @Column(name = "PERFORMER_PARTY_VERSION_ID")
    private Long performerPartyVersionId;

    /** The lead ind. */
    @Column(name = "PERFORMER_LEAD_IND")
    @Type(type = "yes_no")
    private Boolean leadInd;

    /** The no quote deal ind. */
    @Column(name = "NO_QUOTE_DEAL_IND")
    @Type(type = "yes_no")
    private Boolean noQuoteDealInd;

    /** The sag status lookup id. */
    @Column(name = "SAG_STATUS_LOOKUP_ID")
    private Long sagStatusLookupId;

    /** The sag status lookup. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SAG_STATUS_LOOKUP_ID", updatable = false, insertable = false)
    private FcLookup sagStatusLookup;

    /** The sag status note. */
    @Column(name = "SAG_STATUS_NOTE")
    private String sagStatusNote;

    /** The i 9 note. */
    @Column(name = "PERFORMER_I_NINE_STATUS_NOTE")
    private String i9Note;

    /** The representative selected. */
    @Column(name = "REPRESENTATATIVE_SELECTED_FLAG")
    @Type(type = "yes_no")
    private Boolean representativeSelected;

    /** The active. */
    @Column(name = "IS_ACTIVE")
    @Type(type = "yes_no")
    private Boolean active;

    /** The created user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created date. */
    @Column(name = "CREATE_DATE", updatable = false)
    private ZonedDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The updated date. */
    @Column(name = "UPDATE_DATE")
    private ZonedDateTime updatedDate;

    /** The performer. */
    @Transient
    private transient Talent performer;

    /** The production company. */
    @Transient
    private transient TypeAheadNameDto productionCompany;

    /**
     * Instantiates a new deal.
     */
    public Deal() {

    }

    /**
     * Gets the deal id.
     *
     * @return the deal id
     */
    public Long getDealId() {
        return dealId;
    }

    /**
     * Sets the deal id.
     *
     * @param dealId
     *            the new deal id
     */
    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    /**
     * Gets the union lookup.
     *
     * @return the union lookup
     */
    public FcLookup getUnionLookup() {
        return unionLookup;
    }

    /**
     * Sets the union lookup.
     *
     * @param unionLookup
     *            the new union lookup
     */
    public void setUnionLookup(FcLookup unionLookup) {
        this.unionLookup = unionLookup;
    }

    /**
     * Gets the project.
     *
     * @return the project
     */
    public FCProjectHistory getProject() {
        return project;
    }

    /**
     * Sets the project.
     *
     * @param project
     *            the new project
     */
    public void setProject(FCProjectHistory project) {
        this.project = project;
    }

    /**
     * Gets the performer party id.
     *
     * @return the performer party id
     */
    public Long getPerformerPartyId() {
        return performerPartyId;
    }

    /**
     * Sets the performer party id.
     *
     * @param performerPartyId
     *            the new performer party id
     */
    public void setPerformerPartyId(Long performerPartyId) {
        this.performerPartyId = performerPartyId;
    }

    /**
     * Gets the performer aka id.
     *
     * @return the performer aka id
     */
    public Long getPerformerAkaId() {
        return performerAkaId;
    }

    /**
     * Sets the performer aka id.
     *
     * @param performerAkaId
     *            the new performer aka id
     */
    public void setPerformerAkaId(Long performerAkaId) {
        this.performerAkaId = performerAkaId;
    }

    /**
     * Gets the loanout id.
     *
     * @return the loanout id
     */
    public Long getLoanoutId() {
        return loanoutId;
    }

    /**
     * Sets the loanout id.
     *
     * @param loanoutId
     *            the new loanout id
     */
    public void setLoanoutId(Long loanoutId) {
        this.loanoutId = loanoutId;
    }

    /**
     * Gets the deal date.
     *
     * @return the deal date
     */
    public LocalDate getDealDate() {
        return dealDate;
    }

    /**
     * Sets the deal date.
     *
     * @param dealDate
     *            the new deal date
     */
    public void setDealDate(LocalDate dealDate) {
        this.dealDate = dealDate;
    }

    /**
     * Gets the performer I nine status id.
     *
     * @return the performer I nine status id
     */
    public Long getPerformerINineStatusId() {
        return performerINineStatusId;
    }

    /**
     * Checks if is representative selected.
     *
     * @return the boolean
     */
    public Boolean isRepresentativeSelected() {
        return representativeSelected;
    }

    /**
     * Sets the representative selected.
     *
     * @param representativeSelected
     *            the new representative selected
     */
    public void setRepresentativeSelected(Boolean representativeSelected) {
        this.representativeSelected = representativeSelected;
    }

    /**
     * Checks if is active.
     *
     * @return the boolean
     */
    public Boolean isActive() {
        return active;
    }

    /**
     * Sets the active.
     *
     * @param active
     *            the new active
     */
    public void setActive(Boolean active) {
        this.active = active;
    }

    /**
     * Sets the performer I nine status id.
     *
     * @param performerINineStatusId
     *            the new performer I nine status id
     */
    public void setPerformerINineStatusId(Long performerINineStatusId) {
        this.performerINineStatusId = performerINineStatusId;
    }

    /**
     * Gets the i 9 status lookup.
     *
     * @return the i 9 status lookup
     */
    public FcLookup getI9StatusLookup() {
        return i9StatusLookup;
    }

    /**
     * Sets the i 9 status lookup.
     *
     * @param i9StatusLookup
     *            the new i 9 status lookup
     */
    public void setI9StatusLookup(FcLookup i9StatusLookup) {
        this.i9StatusLookup = i9StatusLookup;
    }

    /**
     * Gets the performer role number.
     *
     * @return the performer role number
     */
    public String getPerformerRoleNumber() {
        return performerRoleNumber;
    }

    /**
     * Sets the performer role number.
     *
     * @param performerRoleNumber
     *            the new performer role number
     */
    public void setPerformerRoleNumber(String performerRoleNumber) {
        this.performerRoleNumber = performerRoleNumber;
    }

    /**
     * Gets the prod company id.
     *
     * @return the prod company id
     */
    public Long getProdCompanyId() {
        return prodCompanyId;
    }

    /**
     * Sets the prod company id.
     *
     * @param prodCompanyId
     *            the new prod company id
     */
    public void setProdCompanyId(Long prodCompanyId) {
        this.prodCompanyId = prodCompanyId;
    }

    /**
     * Gets the performer role.
     *
     * @return the performer role
     */
    public String getPerformerRole() {
        return performerRole;
    }

    /**
     * Sets the performer role.
     *
     * @param performerRole
     *            the new performer role
     */
    public void setPerformerRole(String performerRole) {
        this.performerRole = performerRole;
    }

    /**
     * Gets the performer note.
     *
     * @return the performer note
     */
    public String getPerformerNote() {
        return performerNote;
    }

    /**
     * Sets the performer note.
     *
     * @param performerNote
     *            the new performer note
     */
    public void setPerformerNote(String performerNote) {
        this.performerNote = performerNote;
    }

    /**
     * Gets the performer party version id.
     *
     * @return the performer party version id
     */
    public Long getPerformerPartyVersionId() {
        return performerPartyVersionId;
    }

    /**
     * Sets the performer party version id.
     *
     * @param performerPartyVersionId
     *            the new performer party version id
     */
    public void setPerformerPartyVersionId(Long performerPartyVersionId) {
        this.performerPartyVersionId = performerPartyVersionId;
    }

    /**
     * Gets the created user.
     *
     * @return the created user
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * Sets the created user.
     *
     * @param createdUser
     *            the new created user
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public ZonedDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate
     *            the new created date
     */
    public void setCreatedDate(ZonedDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the last updated user.
     *
     * @return the last updated user
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * Sets the last updated user.
     *
     * @param lastUpdatedUser
     *            the new last updated user
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate
     *            the new updated date
     */
    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Gets the performer.
     *
     * @return the performer
     */
    public Talent getPerformer() {
        return performer;
    }

    /**
     * Sets the performer.
     *
     * @param performer
     *            the new performer
     */
    public void setPerformer(Talent performer) {
        this.performer = performer;
    }

    /**
     * Gets the project id.
     *
     * @return the project id
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * Sets the project id.
     *
     * @param projectId
     *            the new project id
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * Gets the lead ind.
     *
     * @return the lead ind
     */
    public Boolean getLeadInd() {
        return leadInd;
    }

    /**
     * Sets the lead ind.
     *
     * @param leadInd
     *            the new lead ind
     */
    public void setLeadInd(Boolean leadInd) {
        this.leadInd = leadInd;
    }

    /**
     * Gets the no quote deal ind.
     *
     * @return the no quote deal ind
     */
    public Boolean getNoQuoteDealInd() {
        return noQuoteDealInd;
    }

    /**
     * Sets the no quote deal ind.
     *
     * @param noQuoteDealInd
     *            the new no quote deal ind
     */
    public void setNoQuoteDealInd(Boolean noQuoteDealInd) {
        this.noQuoteDealInd = noQuoteDealInd;
    }

    /**
     * Gets the sag status lookup id.
     *
     * @return the sag status lookup id
     */
    public Long getSagStatusLookupId() {
        return sagStatusLookupId;
    }

    /**
     * Sets the sag status lookup id.
     *
     * @param sagStatusLookupId
     *            the new sag status lookup id
     */
    public void setSagStatusLookupId(Long sagStatusLookupId) {
        this.sagStatusLookupId = sagStatusLookupId;
    }

    /**
     * Gets the sag status lookup.
     *
     * @return the sag status lookup
     */
    public FcLookup getSagStatusLookup() {
        return sagStatusLookup;
    }

    /**
     * Sets the sag status lookup.
     *
     * @param sagStatusLookup
     *            the new sag status lookup
     */
    public void setSagStatusLookup(FcLookup sagStatusLookup) {
        this.sagStatusLookup = sagStatusLookup;
    }

    /**
     * Gets the sag status note.
     *
     * @return the sag status note
     */
    public String getSagStatusNote() {
        return sagStatusNote;
    }

    /**
     * Sets the sag status note.
     *
     * @param sagStatusNote
     *            the new sag status note
     */
    public void setSagStatusNote(String sagStatusNote) {
        this.sagStatusNote = sagStatusNote;
    }

    /**
     * Gets the i 9 note.
     *
     * @return the i 9 note
     */
    public String getI9Note() {
        return i9Note;
    }

    /**
     * Sets the i 9 note.
     *
     * @param i9Note
     *            the new i 9 note
     */
    public void setI9Note(String i9Note) {
        this.i9Note = i9Note;
    }

    /**
     * Gets the production company.
     *
     * @return the production company
     */
    public TypeAheadNameDto getProductionCompany() {
        return productionCompany;
    }

    /**
     * Sets the production company.
     *
     * @param productionCompany
     *            the new production company
     */
    public void setProductionCompany(TypeAheadNameDto productionCompany) {
        this.productionCompany = productionCompany;
    }

    /**
     * Gets the union id.
     *
     * @return the union id
     */
    public Long getUnionId() {
        return unionId;
    }

    /**
     * Sets the union id.
     *
     * @param unionId
     *            the new union id
     */
    public void setUnionId(Long unionId) {
        this.unionId = unionId;
    }

    /**
     * Gets the performer party id ver.
     *
     * @return the performer party id ver
     */
    public Long getPerformerPartyIdVer() {
        return performerPartyIdVer;
    }

    /**
     * Sets the performer party id ver.
     *
     * @param performerPartyIdVer
     *            the new performer party id ver
     */
    public void setPerformerPartyIdVer(Long performerPartyIdVer) {
        this.performerPartyIdVer = performerPartyIdVer;
    }

    /**
     * Gets the loanout id ver.
     *
     * @return the loanout id ver
     */
    public Long getLoanoutIdVer() {
        return loanoutIdVer;
    }

    /**
     * Sets the loanout id ver.
     *
     * @param loanoutIdVer
     *            the new loanout id ver
     */
    public void setLoanoutIdVer(Long loanoutIdVer) {
        this.loanoutIdVer = loanoutIdVer;
    }

    public Long getProjectIdVer() {
        return projectIdVer;
    }

    public void setProjectIdVer(Long projectIdVer) {
        this.projectIdVer = projectIdVer;
    }

}
