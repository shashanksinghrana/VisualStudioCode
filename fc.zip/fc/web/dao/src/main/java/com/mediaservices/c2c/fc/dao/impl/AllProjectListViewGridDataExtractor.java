package com.mediaservices.c2c.fc.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.mediaservices.c2c.fc.dto.AllProjectDto;
import com.mediaservices.c2c.fc.dto.DealMinimalDto;
import com.mediaservices.c2c.fc.dto.LookupDto;
import com.mediaservices.c2c.fc.dto.PartyDto;
import com.mediaservices.c2c.fc.entity.FCProjectTitle;
import com.mediaservices.c2c.fc.repository.DealRepository;
import com.mediaservices.c2c.fc.repository.FCProjectRepository;
import com.mediaservices.c2c.fc.repository.ProjectTitleRepository;

/**
 * The Class AllProjectListViewGridDataExtractor.
 */
@Component
public class AllProjectListViewGridDataExtractor {

    /** The em. */
    @PersistenceContext
    private EntityManager em;

    /** The project repository. */
    @Autowired
    private FCProjectRepository projectRepository;

    /** The project tite repository. */
    @Autowired
    @Qualifier("fcProjectTitleRepository")
    private ProjectTitleRepository projectTiteRepository;

    /** The deal repository. */
    @Autowired
    private DealRepository dealRepository;

    /**
     * Creates the project list.
     *
     * @param projectIds
     *            the project ids
     * @return the list
     */
    @Transactional(readOnly = true)
    public List<AllProjectDto> createProjectList(List<Long> projectIds) {

        final Map<Long, AllProjectDto> projectDtoMap = new LinkedHashMap<>();
        for (final Long projectId : projectIds) {
            projectDtoMap.put(projectId, new AllProjectDto());
        }

        loadProjectDetails(projectDtoMap);
        loadProjectAkas(projectDtoMap);
        loadProjectDeals(projectDtoMap);

        return projectDtoMap.values().stream().collect(Collectors.toList());

    }

    /**
     * Load project details.
     *
     * @param talentDtoMap
     *            the talent dto map
     */
    private void loadProjectDetails(Map<Long, AllProjectDto> talentDtoMap) {
        final List<Object[]> projects = projectRepository.findProjectByProjectIds(talentDtoMap.keySet());
        AllProjectDto allProjectDto;
        for (final Object obj : projects) {
            final Object[] project = (Object[]) obj;
            allProjectDto = talentDtoMap.get(convertToLong((BigDecimal) project[0]));
            allProjectDto.setProjectId(convertToLong((BigDecimal) project[0]));
            // if (project[1] != null && !StringUtils.contains((String) project[1], ".")) {
            allProjectDto.setSapCode((String) project[1]);
            // }
            allProjectDto.setUpdatedDate(
                    project[2] != null ? ((Timestamp) project[2]).toLocalDateTime().atZone(ZoneId.systemDefault())
                            : null);
            allProjectDto.setAkaNames(new LinkedHashSet<>());
            allProjectDto.setDeals(new LinkedHashSet<>());
            talentDtoMap.put(allProjectDto.getProjectId(), allProjectDto);
        }
    }

    /**
     * Load project akas.
     *
     * @param talentDtoMap
     *            the talent dto map
     */
    private void loadProjectAkas(Map<Long, AllProjectDto> talentDtoMap) {
        final List<FCProjectTitle> projectTitles = projectTiteRepository.findAllByProjectId(talentDtoMap.keySet());
        for (final FCProjectTitle projectTitle : projectTitles) {
            if (projectTitle.getAka() == 'N') {
                talentDtoMap.get(projectTitle.getProjectId()).setTitle(projectTitle.getTitle());
            } else {
                talentDtoMap.get(projectTitle.getProjectId()).getAkaNames().add(projectTitle.getTitle());
            }
        }
    }

    /**
     * Load project deals.
     *
     * @param talentDtoMap
     *            the talent dto map
     */
    private void loadProjectDeals(Map<Long, AllProjectDto> talentDtoMap) {
        final List<Object[]> deals = dealRepository.findDealsByProjectId(talentDtoMap.keySet());
        if (!CollectionUtils.isEmpty(deals)) {
            DealMinimalDto dealMinimalDto;
            final Map<Long, PartyDto> performers = loadDealDetails(talentDtoMap);
            for (final Object obj : deals) {
                final Object[] deal = (Object[]) obj;
                dealMinimalDto = new DealMinimalDto();
                dealMinimalDto.setUpdateDate(
                        deal[4] != null ? ((Timestamp) deal[4]).toLocalDateTime().atZone(ZoneId.systemDefault())
                                : null);
                dealMinimalDto.setDealId(convertToLong((BigDecimal) deal[1]));
                dealMinimalDto.setPerformerPartyId(convertToLong((BigDecimal) deal[2]));
                dealMinimalDto.setPerformer(performers.get(convertToLong((BigDecimal) deal[1])));
                dealMinimalDto.setPerformerRole((String) deal[3]);
                dealMinimalDto.setUnionLookup(createDealUnionLookup(deal));
                talentDtoMap.get(convertToLong((BigDecimal) deal[0])).getDeals().add(dealMinimalDto);
            }
        }
    }

    /**
     * Creates the deal union lookup.
     *
     * @param deal
     *            the deal
     * @return the lookup dto
     */
    private LookupDto createDealUnionLookup(Object[] deal) {
        LookupDto dto = null;
        if (deal != null && deal[5] != null) {
            dto = new LookupDto();
            dto.setLookupId(convertToLong((BigDecimal) deal[5]));
            dto.setName((String) deal[6]);
            dto.setType((String) deal[7]);
        }

        return dto;
    }

    /**
     * Load deal details.
     *
     * @param talentDtoMap
     *            the talent dto map
     * @return the map
     */
    private Map<Long, PartyDto> loadDealDetails(Map<Long, AllProjectDto> talentDtoMap) {
        Map<Long, PartyDto> partyMap = null;
        final List<Object[]> dealDetails = dealRepository.findDealDeatailsByProjectId(talentDtoMap.keySet());
        if (!CollectionUtils.isEmpty(dealDetails)) {
            partyMap = new LinkedHashMap<>();
            PartyDto partyDto;
            for (final Object obj : dealDetails) {
                final Object[] party = (Object[]) obj;
                if (!partyMap.containsKey(convertToLong((BigDecimal) party[2]))) {
                    partyDto = new PartyDto();
                    partyMap.put(convertToLong((BigDecimal) party[2]), partyDto);
                    partyDto.setPartyId(convertToLong((BigDecimal) party[3]));
                    partyDto.setDob(party[6] != null ? ((Timestamp) party[6]).toLocalDateTime().toLocalDate() : null);
                    partyDto.setFirstName((String) party[4]);
                    partyDto.setLastName((String) party[5]);
                    partyDto.setAgencyList(new ArrayList<>());
                } else {
                    partyDto = partyMap.get(convertToLong((BigDecimal) party[2]));
                }
                if (party[7] != null) {
                    partyDto.getAgencyList().add((String) party[7]);
                }

            }
        }
        return partyMap;
    }

    /**
     * Convert to long.
     *
     * @param source
     *            the source
     * @return the long
     */
    private Long convertToLong(BigDecimal source) {
        if (source == null) {
            return null;
        }
        return source.longValue();
    }

}