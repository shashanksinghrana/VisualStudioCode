package com.mediaservices.c2c.fc.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.FCProjectTitle;

/**
 * The Interface ProjectTitleRepository.
 */
@Repository("fcProjectTitleRepository")
public interface ProjectTitleRepository extends JpaRepository<FCProjectTitle, Long> {

    /**
     * Returns the ProjectTitles with the given Project ids.
     *
     * @param projectId
     * @return Set<ProjectTitle>
     */
    Set<FCProjectTitle> findByProjectId(Long projectId);

    /**
     * Returns the List of ProjectTitles with the searchTerm matching the given
     * title given record count.
     *
     * @param searchTerm
     * @param count
     * @return List<ProjectTitle>
     */
    @Query(value = QueryConstants.PROJECT_TITLE_BY_SEARCH_TERM, nativeQuery = true)
    List<FCProjectTitle> findAllBySearchTerm(@Param("searchTerm") String searchTerm, @Param("count") Pageable count);

    /**
     * Returns a List of ProjectTitles with the given Aka indicator and projectId.
     *
     * @param projectId
     * @param aka
     * @return List<ProjectTitle>
     */
    List<FCProjectTitle> findAllByProjectIdAndAka(Long projectId, Character aka);

    @Query(value = "select pt.* from project_title pt where pt.project_id in (:projectIds) order by project_Id asc, project_Title_Id asc", nativeQuery = true)
    List<FCProjectTitle> findAllByProjectId(@Param("projectIds") Set<Long> projectIds);

}
