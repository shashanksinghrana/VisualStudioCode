package com.mediaservices.c2c.fc.history.entity;

import java.io.Serializable;

/**
 * The Class FCProjectTitleHistoryId.
 */
public class FCProjectTitleHistoryId implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The project title id. */
    private Long projectTitleId;

    /** The project id. */
    private Long projectId;

    /** The project id version. */
    private Long projectIdVersion;

    /**
     * Gets the project title id.
     *
     * @return the project title id
     */
    public Long getProjectTitleId() {
        return projectTitleId;
    }

    /**
     * Sets the project title id.
     *
     * @param projectTitleId
     *            the new project title id
     */
    public void setProjectTitleId(Long projectTitleId) {
        this.projectTitleId = projectTitleId;
    }

    /**
     * Gets the project id.
     *
     * @return the project id
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * Sets the project id.
     *
     * @param projectId
     *            the new project id
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * Gets the project id version.
     *
     * @return the project id version
     */
    public Long getProjectIdVersion() {
        return projectIdVersion;
    }

    /**
     * Sets the project id version.
     *
     * @param projectIdVersion
     *            the new project id version
     */
    public void setProjectIdVersion(Long projectIdVersion) {
        this.projectIdVersion = projectIdVersion;
    }

}
