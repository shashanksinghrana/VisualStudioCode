package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The persistent class for the FC_PROJECT_NOTES database table.
 *
 */
@Entity
@Table(name = "FC_PROJECT_NOTES")
public class ProjectNote implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "projectNoteIdSeq")
    @SequenceGenerator(name = "projectNoteIdSeq", sequenceName = "DBO_FC.FC_PROJECT_NOTES_ID_SEQ", allocationSize = 1)
    private Long projectNoteId;

    @Column(name = "NOTE")
    private byte[] note;

    /** The created by user. */
    @Column(name = "CREATED_BY")
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    @Column(name = "PROJECT_ID")
    private Long projectId;

    @Column(name = "TYPE")
    private String type;

    /**
     * Instantiates a new ProjectNote.
     */
    public ProjectNote() {

    }

    public byte[] getNote() {
        return note;
    }

    public void setNote(byte[] note) {
        this.note = note;
    }

    public Long getProjectNoteId() {
        return projectNoteId;
    }

    public void setProjectNoteId(Long projectNoteId) {
        this.projectNoteId = projectNoteId;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
