package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class Crew.
 */
@Entity
@Table(name = "FC_CREW")
public class Crew implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The crew id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqCrewId")
    @SequenceGenerator(name = "seqCrewId", sequenceName = "DBO_FC.SEQ_FC_CREW_ID", allocationSize = 1)
    private Long crewId;

    /** The project id. */
    @Column(name = "PROJECT_ID", updatable = false)
    private Long projectId;

    /** The crew party id. */
    @Column(name = "PARTY_ID")
    private Long crewPartyId;

    /** The created user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created date. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The updated date. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    /**
     * Gets the crer id.
     *
     * @return the crer id
     */
    public Long getCrewId() {
        return crewId;
    }

    /**
     * Sets the crew id.
     *
     * @param representationId
     *            the new crew id
     */
    public void setCrewId(Long representationId) {
        this.crewId = representationId;
    }

    /**
     * Gets the project id.
     *
     * @return the project id
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * Sets the project id.
     *
     * @param projectId
     *            the new project id
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * Gets the crew party id.
     *
     * @return the crew party id
     */
    public Long getCrewPartyId() {
        return crewPartyId;
    }

    /**
     * Sets the crew party id.
     *
     * @param crewPartyId
     *            the new crew party id
     */
    public void setCrewPartyId(Long crewPartyId) {
        this.crewPartyId = crewPartyId;
    }

    /**
     * Gets the created user.
     *
     * @return the created user
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * Sets the created user.
     *
     * @param createdUser
     *            the new created user
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate
     *            the new created date
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the last updated user.
     *
     * @return the last updated user
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * Sets the last updated user.
     *
     * @param lastUpdatedUser
     *            the new last updated user
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate
     *            the new updated date
     */
    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

}
