package com.mediaservices.c2c.fc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.SignatoryUser;

/**
 * The Interface UserRepository.
 */
public interface SignataoryUserRepository extends JpaRepository<SignatoryUser, Long> {

}
