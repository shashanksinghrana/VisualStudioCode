package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.entity.Representation;

/**
 * The Interface RepresentationRepository.
 */
public interface RepresentationRepository extends CrudRepository<Representation, Long> {

    /**
     * Find by deal id.
     *
     * @param dealId
     *            the deal id
     * @return the list
     */
    List<Representation> findByDealId(Long dealId);

    /**
     * Find by deal id and direct contact.
     *
     * @param dealId
     *            the deal id
     * @param contactId
     *            the contact id
     * @return the list
     */
    List<Representation> findByDealIdAndDirectContact(Long dealId, Long contactId);

    /**
     * Find by deal id and representation id.
     *
     * @param dealId
     *            the deal id
     * @param representationPartyId
     *            the representation party id
     * @return the representation
     */
    Representation findByDealIdAndRepresentationPartyId(Long dealId, Long representationPartyId);

    /**
     * Delete by deal id.
     *
     * @param dealId
     *            the deal id
     */
    void deleteByDealId(Long dealId);

    /**
     * Find representation party id ver by deal id and rep party id.
     *
     * @param dealId
     *            the deal id
     * @param repPartyId
     *            the rep party id
     * @return the long
     */
    @Query(value = "select REP_PARTY_ID_VER from FC_REPRESENTATION where DEAL_ID = :dealId and REPRESENTATION_PARTY_ID = :repPartyId", nativeQuery = true)
    Long findRepresentationPartyIdVerByDealIdAndRepPartyId(@Param("dealId") Long dealId,
            @Param("repPartyId") Long repPartyId);

}
