package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.Compensation;

/**
 * The Interface CompensationRepository.
 */
public interface CompensationRepository extends JpaRepository<Compensation, Long> {

    /**
     * Returns the Set of Compensations with the given deal id. Orders records
     * by Start Date
     *
     * @param id
     * @return Set<Compensation>
     */
    List<Compensation> findAllByDealIdOrderByContractDateDesc(Long id);

}
