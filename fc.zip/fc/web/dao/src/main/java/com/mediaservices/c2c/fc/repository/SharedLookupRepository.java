package com.mediaservices.c2c.fc.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.SharedLookup;

/**
 * The Interface LookupRepository.
 */
public interface SharedLookupRepository extends JpaRepository<SharedLookup, Long> {

    /**
     * Find by lookup type id.
     *
     * @param lookupTypeId
     *            the lookup type id
     * @return the list
     */
    public List<SharedLookup> findByLookupTypeIdOrderByDisplayOrder(Long lookupTypeId);

    /**
     * Returns a set of SharedLookup objects representing the STUDIO for the given
     * userId and module.
     *
     * @param userId
     *            the user id
     * @param module
     *            the module
     * @return Set<SharedLookup>
     */
    @Query(value = QueryConstants.STUDIO_BY_USER_ID_AND_MODULE, nativeQuery = true)
    public Set<SharedLookup> getStudiosByUserIdAndModule(@Param("userId") String userId,
            @Param("module") String module);

    /**
     * Gets the lookup by lookup name and lookup type.
     *
     * @param lookupName
     *            the lookup name
     * @return the lookup by lookup name and lookup type
     */
    @Query(value = QueryConstants.STUDIO_WITH_MODULE_NAME, nativeQuery = true)
    public Optional<SharedLookup> getLookupByLookupNameAndLookupType(@Param("lookupName") String lookupName);

    /**
     * Gets the master dataset id.
     *
     * @return the master dataset id
     */
    @Query(value = QueryConstants.GET_MASTER_DATASET_ID, nativeQuery = true)
    public Long getMasterDatasetId();
}
