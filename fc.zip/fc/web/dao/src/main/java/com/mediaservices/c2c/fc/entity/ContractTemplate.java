package com.mediaservices.c2c.fc.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class ContractTemplate.
 */
@Entity
@Table(name = "FC_CONTRACT_TEMPLATE")
public class ContractTemplate {

    /** The template id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqContractTemplateId")
    @SequenceGenerator(name = "seqContractTemplateId", sequenceName = "DBO_FC.FC_CONTRACT_TEMPLATE_ID_SEQ", allocationSize = 1)
    private Long templateId;

    /** The contract lookup id. */
    @Column(name = "CONTRACT_LOOKUP_ID")
    private Long contractLookupId;

    /** The contract name. */
    @Column(name = "CONTRACT_NAME")
    private String contractName;

    /** The text. */
    @Column(name = "TEXT")
    private String text;

    /** The filter. */
    @Column(name = "FILTER")
    private String filter;

    /** The created by user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /**
     * Gets the contract lookup id.
     *
     * @return the contract lookup id
     */
    public Long getContractLookupId() {
        return contractLookupId;
    }

    /**
     * Sets the contract lookup id.
     *
     * @param contractLookupId
     *            the new contract lookup id
     */
    public void setContractLookupId(Long contractLookupId) {
        this.contractLookupId = contractLookupId;
    }

    /**
     * Gets the template id.
     *
     * @return the template id
     */
    public Long getTemplateId() {
        return templateId;
    }

    /**
     * Sets the template id.
     *
     * @param templateId
     *            the new template id
     */
    public void setTemplateId(Long templateId) {
        this.templateId = templateId;
    }

    /**
     * Gets the contract name.
     *
     * @return the contract name
     */
    public String getContractName() {
        return contractName;
    }

    /**
     * Sets the contract name.
     *
     * @param contractName
     *            the new contract name
     */
    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    /**
     * Gets the text.
     *
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * Sets the text.
     *
     * @param text
     *            the new text
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * @return the filter
     */
    public String getFilter() {
        return filter;
    }

    /**
     * @param filter
     *            the filter to set
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    /**
     * Gets the created user.
     *
     * @return the created user
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * Sets the created user.
     *
     * @param createdUser
     *            the new created user
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate
     *            the new created date
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
}
