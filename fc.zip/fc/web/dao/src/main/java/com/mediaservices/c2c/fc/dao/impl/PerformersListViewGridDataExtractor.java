package com.mediaservices.c2c.fc.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.mediaservices.c2c.fc.dto.ContractDto;
import com.mediaservices.c2c.fc.dto.LookupDto;
import com.mediaservices.c2c.fc.dto.PartyDto;
import com.mediaservices.c2c.fc.dto.PerformerDealDto;
import com.mediaservices.c2c.fc.repository.ContractRepository;
import com.mediaservices.c2c.fc.repository.DealRepository;

@Component
public class PerformersListViewGridDataExtractor {

    @PersistenceContext
    private EntityManager em;

    @Autowired
    private DealRepository dealRepository;

    @Autowired
    private ContractRepository contractRepository;

    @Transactional(readOnly = true)
    public List<PerformerDealDto> createPerformersList(Map<Long, PerformerDealDto> dealDtoMap) {

        loadDealDetails(dealDtoMap);
        return dealDtoMap.values().stream().collect(Collectors.toList());
    }

    private void loadDealDetails(Map<Long, PerformerDealDto> dealDtoMap) {
        final List<Object[]> deals = dealRepository.findDealsByDealIds(dealDtoMap.keySet());
        final Map<Long, List<ContractDto>> contracts = getContracts(dealDtoMap.keySet());
        if (!CollectionUtils.isEmpty(deals)) {
            PerformerDealDto performerDealDto;
            for (final Object obj : deals) {
                final Object[] deal = (Object[]) obj;
                performerDealDto = dealDtoMap.get(convertToLong((BigDecimal) deal[0]));
                performerDealDto.setDealId(convertToLong((BigDecimal) deal[0]));
                performerDealDto
                .setDealDate(deal[5] != null ? ((Timestamp) deal[5]).toLocalDateTime().toLocalDate() : null);
                performerDealDto.setPerformerNote((String) deal[4]);
                performerDealDto.setPerformerPartyId(convertToLong((BigDecimal) deal[1]));
                performerDealDto.setPerformerRole((String) deal[2]);
                if (deal[3] != null) {
                    performerDealDto.setPerformerRoleNumber((String) deal[3]);
                }
                performerDealDto.setUnionLookup(createDealUnionLookup(deal));
                performerDealDto.setPerformer(createParty(deal));
                performerDealDto.setContracts(contracts != null ? contracts.get(performerDealDto.getDealId()) : null);
            }
        }
    }

    public Map<Long, List<ContractDto>> getContracts(Set<Long> dealsIds) {
        Map<Long, List<ContractDto>> contractMap = null;
        final List<Object[]> contracts = contractRepository.getAllContractsForDeals(dealsIds);
        if (!CollectionUtils.isEmpty(contracts)) {
            contractMap = new LinkedHashMap<>();
            List<ContractDto> contractDtos;
            for (final Object obj : contracts) {
                final Object[] contract = (Object[]) obj;
                if (!contractMap.containsKey(convertToLong((BigDecimal) contract[3]))) {
                    contractDtos = new ArrayList<>();
                    contractMap.put(convertToLong((BigDecimal) contract[3]), contractDtos);
                } else {
                    contractDtos = contractMap.get(convertToLong((BigDecimal) contract[3]));
                }

                contractDtos.add(new ContractDto(convertToLong((BigDecimal) contract[0]),
                        contract[4] != null ? contract[4].toString() : null,
                                convertToLong((BigDecimal) contract[3]), convertToLong((BigDecimal) contract[1]),
                                (String) contract[2]));
            }
        }
        return contractMap;
    }

    public LookupDto createDealUnionLookup(Object[] deal) {
        LookupDto dto = null;
        if (deal != null && deal[10] != null) {
            dto = new LookupDto();
            dto.setLookupId(convertToLong((BigDecimal) deal[10]));
            dto.setName((String) deal[11]);
            dto.setType((String) deal[12]);
        }

        return dto;
    }

    private PartyDto createParty(Object[] deal) {
        PartyDto partyDto = null;
        if (deal != null && deal[6] != null) {
            partyDto = new PartyDto();
            partyDto.setPartyId(convertToLong((BigDecimal) deal[6]));
            partyDto.setDob(deal[9] != null ? ((Timestamp) deal[9]).toLocalDateTime().toLocalDate() : null);
            partyDto.setFirstName((String) deal[7]);
            partyDto.setLastName((String) deal[8]);
            partyDto.setAgencyList(new ArrayList<>());
        }
        return partyDto;
    }

    private Long convertToLong(BigDecimal source) {
        if (source == null) {
            return null;
        }
        return source.longValue();
    }

}