package com.mediaservices.c2c.fc.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.dao.PowerSearchGridDAO;
import com.mediaservices.c2c.fc.dto.PageContent;
import com.mediaservices.c2c.fc.dto.PowerSearchCriteriaDto;
import com.mediaservices.c2c.fc.dto.PowerSearchDto;
import com.mediaservices.c2c.fc.grid.PowerSearchListQueryBuilder;

/**
 * The Class PowerSearchGridDAOImpl.
 */
@Component
public class PowerSearchGridDAOImpl implements PowerSearchGridDAO {

    /** The Constant ASC. */
    private static final String ASC = "ASC";

    /** The Constant BILLING. */
    private static final String BILLING = "billing";

    /** The Constant ROLES. */
    private static final String ROLES = "roles";

    /** The Constant PRODUCTION_COMPANIES. */
    private static final String PRODUCTION_COMPANIES = "productionCompanies";

    /** The Constant PERFORMERS. */
    private static final String PERFORMERS = "performers";

    /** The Constant UNIONS. */
    private static final String UNIONS = "unions";

    /** The Constant PROJECT_IDS. */
    private static final String PROJECT_IDS = "projectIds";

    /** The Constant FIELD_DEAL_DATE. */
    private static final String FIELD_DEAL_DATE = "dealDate";

    /** The Constant COLON. */
    private static final String COLON = ":";

    /** The Constant FIELD_TITLE. */
    private static final String FIELD_TITLE = "title";

    /** The Constant FIELD_UNION. */
    private static final String FIELD_UNION = "union";

    /** The Constant FIELD_ROLE. */
    private static final String FIELD_ROLE = "role";

    /** The Constant FIELD_PERFORMER_NAME. */
    private static final String FIELD_PERFORMER_NAME = "performerName";

    /** The em. */
    @PersistenceContext
    private EntityManager em;

    /** The extracter. */
    @Autowired
    private PowerSearchListViewGridDataExtractor extracter;

    /** The Constant OUTER_SELECT_QUERY. */
    private static final String OUTER_SELECT_QUERY = "select project.* from (\n";

    /** The Constant SELECT_DEAL_COUNT. */
    private static final String SELECT_DEAL_COUNT = "SELECT COUNT( DISTINCT d.ID ) FROM DBO_FC.FC_DEAL d ";

    /** The Constant SELECT_DEAL_IDS. */
    private static final String SELECT_DEAL_IDS = "SELECT  DISTINCT d.ID, ttl.TITLE  FROM DBO_FC.FC_DEAL d  ";

    /** The Constant SELECT_PROJECTS. */
    private static final String SELECT_PROJECTS = "SELECT d.PROJECT_ID, d.ID as deal_id, d.UPDATE_DATE as deal_update_date, d.DEAL_DATE, ps.FIRST_NAME, ps.LAST_NAME, d.PERFORMER_ROLE, ulk.Id, ulk.NAME, ulk.TYPE  from DBO_FC.FC_DEAL d ";

    /** The Constant GROUP_BY. */
    private static final String GROUP_BY = " GROUP BY d.ID, d.project_id, d.UPDATE_DATE, d.DEAL_DATE, ps.FIRST_NAME, ps.LAST_NAME, d.PERFORMER_ROLE, ulk.Id, ulk.NAME, ulk.TYPE ,ttl.TITLE ";

    /*
     * (non-Javadoc)
     *
     * @see com.mediaservices.c2c.fc.dao.AllProjectGridDAO2#getProjectByFilters(com.
     * mediaservices.c2c.fc.dto.AllProjectsGridSearchCriteria,
     * org.springframework.data.domain.Pageable)
     */
    @Override
    public PageContent<PowerSearchDto> getPowerSearchByFilters(PowerSearchCriteriaDto searchFilter, Pageable pageable) {
        List<PowerSearchDto> projectList = new ArrayList<>();
        PowerSearchListQueryBuilder builder = new PowerSearchListQueryBuilder();
        whereCondition(searchFilter, builder);
        filterConditions(searchFilter, builder);
        Set<Long> projectIds = new LinkedHashSet<>();
        String sqlQuery = null;
        Query companyQuery = null;
        Long totalRecords = getCount(builder);

        String sortConditions[] = (pageable.getSort() != null) ? pageable.getSort().toString().split(",") : null;
        if (null != sortConditions && sortConditions.length > 0) {
            for (String sortCond : sortConditions) {
                String sorts[] = sortCond.split(COLON);
                String sortBy = (sorts != null) ? sorts[0].trim() : "";
                String dir = (sorts != null) ? sorts[1].trim() : "";
                String sortDir = Sort.Direction.ASC.toString().equalsIgnoreCase(dir) ? Sort.Direction.ASC.toString()
                        : Sort.Direction.DESC.toString();
                sortConditions(builder, sortBy, sortDir);
            }
        } else {
            sortConditions(builder, "title", "ASC");
        }
        builder.sortByDealId();
        if (totalRecords > 0) {
            builder.getFilterAndSortConditions().setGroupBy(GROUP_BY);
            builder.setQuery(SELECT_PROJECTS);
            Query dealQuery = em.createNativeQuery(builder.buildComplexQuery());
            setQueryParam(dealQuery, builder);
            dealQuery.setMaxResults(pageable.getPageSize());
            dealQuery.setFirstResult((int) pageable.getOffset());
            List<Object[]> result = dealQuery.getResultList();
            result.forEach(obj -> {
                Long projectId;
                Object[] columns = obj;
                projectId = convertToLong((BigDecimal) columns[0]);
                projectIds.add(projectId);
            });
            projectList = extracter.createProjectList(projectIds, result);
        }
        return getPageContent(projectList, pageable, totalRecords);
    }

    /*
     * (non-Javadoc)
     *
     * @see com.mediaservices.c2c.fc.dao.PowerSearchGridDAO#getPowerSearchI9Report(
     * com.mediaservices.c2c.fc.dto.PowerSearchCriteriaDto)
     */
    @Override
    public String getPowerSearchReport(PowerSearchCriteriaDto searchFilter) {

        Set<Long> projectIds = new LinkedHashSet<>();
        PowerSearchListQueryBuilder builder = new PowerSearchListQueryBuilder();
        whereCondition(searchFilter, builder);
        filterConditions(searchFilter, builder);
        sortConditions(builder, "title", "ASC");
        builder.setQuery(SELECT_DEAL_IDS);
        Query dealQuery = em.createNativeQuery(builder.buildComplexQuery());
        setQueryParam(dealQuery, builder);
        List<Object[]> result = dealQuery.getResultList();
        /*
         * result.forEach(obj -> { Long projectId; Object[] columns = obj; projectId =
         * convertToLong((BigDecimal) columns[0]); projectIds.add(projectId); });
         */
        return result.stream().map(deal -> deal[0].toString()).collect(Collectors.joining(","));
    }

    /**
     * Gets the page content.
     *
     * @param projectList
     *            the project list
     * @param pageable
     *            the pageable
     * @param totalRecords
     *            the total records
     * @return the page content
     */
    private PageContent<PowerSearchDto> getPageContent(List<PowerSearchDto> projectList, Pageable pageable,
            long totalRecords) {
        PageContent<PowerSearchDto> powerSearchPagination = new PageContent<>();
        powerSearchPagination.setContent(projectList);
        powerSearchPagination.setTotalPages((int) Math.ceil((double) totalRecords / pageable.getPageSize()));
        powerSearchPagination.setTotalRecords(totalRecords);
        powerSearchPagination.setCurrentPageNumber(pageable.getPageNumber());
        powerSearchPagination.setCurrentPageSize(projectList.size());
        powerSearchPagination.setPageSize(pageable.getPageSize());
        return powerSearchPagination;
    }

    /**
     * Sort conditions.
     *
     * @param builder
     *            the builder
     * @param sortBy
     *            the sort by
     * @param sortDirection
     *            the sort direction
     */
    private void sortConditions(PowerSearchListQueryBuilder builder, String sortBy, String sortDirection) {

        if (FIELD_TITLE.equals(sortBy)) {
            builder.sortByTitle(sortDirection);
        } else if (FIELD_UNION.equals(sortBy)) {
            builder.sortByUnion(sortDirection);
        } else if (FIELD_ROLE.equals(sortBy)) {
            builder.sortByRole(sortDirection);
        } else if (FIELD_PERFORMER_NAME.equals(sortBy)) {
            builder.sortByPerformerName(sortDirection);
        } else if (FIELD_DEAL_DATE.equals(sortBy)) {
            builder.sortByDate(sortDirection);
        }
    }

    /**
     * Gets the sort direction.
     *
     * @param sort
     *            the sort
     * @return the sort direction
     */
    private String getSortDirection(Sort sort) {
        String sortDirection = (sort != null) ? sort.toString().split(COLON)[1].trim() : "";
        return Sort.Direction.ASC.toString().equalsIgnoreCase(sortDirection) ? Sort.Direction.ASC.toString()
                : Sort.Direction.DESC.toString();
    }

    /**
     * Where condition.
     *
     * @param searchFilter
     *            the search filter
     * @param builder
     *            the builder
     */
    private void whereCondition(PowerSearchCriteriaDto searchFilter, PowerSearchListQueryBuilder builder) {
        builder.filterByDealDate(searchFilter.getStartDate(), searchFilter.getEndDate());
        builder.filterByProjectTitle(searchFilter.getProjectTitles());
        builder.filterByPerformer(searchFilter.getPerformers());
        builder.filterByUnion(searchFilter.getUnions());
        builder.filterByProdCompany(searchFilter.getProductionCompanies());
        builder.filterByRoles(searchFilter.getRoles());
        builder.filterByBilling(searchFilter.getBillings());
        builder.filterByCompensation(searchFilter.getCompensations());
        builder.filterByWorkActivities(searchFilter.getWorkActivities());
        builder.filterByTextFields(searchFilter.getTextFields());
        builder.filterByStatusDates(searchFilter.getStatusDates());
    }

    /**
     * Filter conditions.
     *
     * @param searchFilter
     *            the search filter
     * @param builder
     *            the builder
     */
    private void filterConditions(PowerSearchCriteriaDto searchFilter, PowerSearchListQueryBuilder builder) {
        builder.filterGridByTitle(searchFilter.getGridTitle());
        builder.filterGridByPerformerName(searchFilter.getGridPerformer());
        builder.filterGridByRole(searchFilter.getGridRole());
        builder.filterGridByUnion(searchFilter.getGridUnion());
        builder.filterGridByDealDate(searchFilter.getGridDealDate());
    }

    /**
     * Gets the count.
     *
     * @param builder
     *            the builder
     * @return the count
     */
    private Long getCount(PowerSearchListQueryBuilder builder) {
        builder.setQuery(SELECT_DEAL_COUNT);
        Query talentQuery = em.createNativeQuery(builder.buildComplexQuery());
        setQueryParam(talentQuery, builder);
        BigDecimal count = (BigDecimal) talentQuery.getSingleResult();
        return count.longValue();
    }

    /**
     * Sets the query param.
     *
     * @param query
     *            the query
     * @param builder
     *            the builder
     */
    private void setQueryParam(Query query, PowerSearchListQueryBuilder builder) {

        if (builder.getFilterAndSortConditions().getNamedLongParam().containsKey(PROJECT_IDS)) {
            query.setParameter(PROJECT_IDS, builder.getFilterAndSortConditions().getNamedLongParam().get(PROJECT_IDS));
        }
        if (builder.getFilterAndSortConditions().getNamedLongParam().containsKey(UNIONS)) {
            query.setParameter(UNIONS, builder.getFilterAndSortConditions().getNamedLongParam().get(UNIONS));
        }
        if (builder.getFilterAndSortConditions().getNamedLongParam().containsKey(PERFORMERS)) {
            query.setParameter(PERFORMERS, builder.getFilterAndSortConditions().getNamedLongParam().get(PERFORMERS));
        }
        if (builder.getFilterAndSortConditions().getNamedLongParam().containsKey(PRODUCTION_COMPANIES)) {
            query.setParameter(PRODUCTION_COMPANIES,
                    builder.getFilterAndSortConditions().getNamedLongParam().get(PRODUCTION_COMPANIES));
        }
        if (builder.getFilterAndSortConditions().getNamedParam().containsKey(ROLES)) {
            query.setParameter(ROLES, builder.getFilterAndSortConditions().getNamedParam().get(ROLES));
        }
        if (builder.getFilterAndSortConditions().getNamedParam().containsKey(BILLING)) {
            query.setParameter(BILLING, builder.getFilterAndSortConditions().getNamedParam().get(BILLING));
        }

    }

    /**
     * Convert to long.
     *
     * @param source
     *            the source
     * @return the long
     */
    private Long convertToLong(BigDecimal source) {
        if (source == null) {
            return null;
        }
        return source.longValue();
    }

}
