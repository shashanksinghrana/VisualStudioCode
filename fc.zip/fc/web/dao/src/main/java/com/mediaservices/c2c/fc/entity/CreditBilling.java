package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class CreditBilling.
 */
@Entity
@Table(name = "FC_CREDIT_BILLING")
public class CreditBilling implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The deal id. */
	@Id
	@Column(name = "ID")
	@GeneratedValue(generator = "seqCrditBillingId")
	@SequenceGenerator(name = "seqCrditBillingId", sequenceName = "DBO_FC.FC_CREDIT_BILLING_ID_SEQ", allocationSize = 1)
	private Long creditBillingId;

	/** The deal id. */
	@Column(name = "DEAL_ID", updatable = false)
	private Long dealId;

	/** The billing text. */
	@Column(name = "BILLING_TEXT")
	private String billingText;

	/** The billing lookup. */
	@ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
	@JoinColumn(name = "BILLING_LOOKUP_ID", updatable = false)
	private FcLookup billingLookup;

	/** The created by user. */
	@Column(name = "CREATED_BY", updatable = false)
	private String createdUser;

	/** The created ts. */
	@Column(name = "CREATE_DATE", updatable = false)
	@Convert(converter = LocalDateTimeConverter.class)
	private LocalDateTime createdDate;

	/** The last updated user. */
	@Column(name = "UPDATED_BY")
	private String lastUpdatedUser;

	/** The last updated ts. */
	@Column(name = "UPDATE_DATE")
	@Convert(converter = LocalDateTimeConverter.class)
	private LocalDateTime updatedDate;

	/**
	 * Gets the credit billing id.
	 *
	 * @return the credit billing id
	 */
	public Long getCreditBillingId() {
		return creditBillingId;
	}

	/**
	 * Sets the credit billing id.
	 *
	 * @param creditBillingId
	 *            the new credit billing id
	 */
	public void setCreditBillingId(Long creditBillingId) {
		this.creditBillingId = creditBillingId;
	}

	/**
	 * Gets the deal id.
	 *
	 * @return the deal id
	 */
	public Long getDealId() {
		return dealId;
	}

	/**
	 * Sets the deal id.
	 *
	 * @param dealId
	 *            the new deal id
	 */
	public void setDealId(Long dealId) {
		this.dealId = dealId;
	}

	/**
	 * Gets the billing text.
	 *
	 * @return the billing text
	 */
	public String getBillingText() {
		return billingText;
	}

	/**
	 * Sets the billing text.
	 *
	 * @param billingText
	 *            the new billing text
	 */
	public void setBillingText(String billingText) {
		this.billingText = billingText;
	}

	/**
	 * Gets the billing lookup.
	 *
	 * @return the billing lookup
	 */
	public FcLookup getBillingLookup() {
		return billingLookup;
	}

	/**
	 * Sets the billing lookup.
	 *
	 * @param billingLookup
	 *            the new billing lookup
	 */
	public void setBillingLookup(FcLookup billingLookup) {
		this.billingLookup = billingLookup;
	}

	/**
	 * Gets the created user.
	 *
	 * @return the created user
	 */
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * Sets the created user.
	 *
	 * @param createdUser
	 *            the new created user
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate
	 *            the new created date
	 */
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the last updated user.
	 *
	 * @return the last updated user
	 */
	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	/**
	 * Sets the last updated user.
	 *
	 * @param lastUpdatedUser
	 *            the new last updated user
	 */
	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	/**
	 * Gets the updated date.
	 *
	 * @return the updated date
	 */
	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * Sets the updated date.
	 *
	 * @param updatedDate
	 *            the new updated date
	 */
	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

}
