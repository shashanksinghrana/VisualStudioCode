
package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The persistent class for the FC_PERQ database table.
 *
 */
@Entity
@Table(name = "FC_PERQ")
public class Perq implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "perqIdSeq")
    @SequenceGenerator(name = "perqIdSeq", sequenceName = "DBO_FC.FC_PERQ_ID_SEQ", allocationSize = 1)
    private Long perqId;

    @Column(name = "DEAL_ID")
    private Long dealId;

    @Column(name = "PERQ_TYPE_LOOKUP_ID")
    private Long perqTypeLookupId;

    @Column(name = "PERQ_TEXT")
    private String perqText;

    @Column(name = "PRINT_RIDER_FLAG")
    @Type(type = "yes_no")
    private Boolean printRiderInd;

    @Column(name = "PAID_AD_FLAG")
    @Type(type = "yes_no")
    private Boolean paidAdInd;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PERQ_TYPE_LOOKUP_ID", updatable = false, insertable = false)
    private FcLookup perqTypeLookup;

    /** The created by user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    public Perq() {

    }

    public Long getPerqId() {
        return perqId;
    }

    public void setPerqId(Long perqId) {
        this.perqId = perqId;
    }

    public Long getDealId() {
        return dealId;
    }

    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    public Long getPerqTypeLookupId() {
        return perqTypeLookupId;
    }

    public void setPerqTypeLookupId(Long perqTypeLookupId) {
        this.perqTypeLookupId = perqTypeLookupId;
    }

    public String getPerqText() {
        return perqText;
    }

    public void setPerqText(String perqText) {
        this.perqText = perqText;
    }

    public Boolean getPrintRiderInd() {
        return printRiderInd;
    }

    public void setPrintRiderInd(Boolean printRiderInd) {
        this.printRiderInd = printRiderInd;
    }

    public Boolean getPaidAdInd() {
        return paidAdInd;
    }

    public void setPaidAdInd(Boolean paidAdInd) {
        this.paidAdInd = paidAdInd;
    }

    public FcLookup getPerqTypeLookup() {
        return perqTypeLookup;
    }

    public void setPerqTypeLookup(FcLookup perqTypeLookup) {
        this.perqTypeLookup = perqTypeLookup;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((dealId == null) ? 0 : dealId.hashCode());
        result = prime * result + ((perqId == null) ? 0 : perqId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Perq other = (Perq) obj;
        if (dealId == null) {
            if (other.dealId != null) {
                return false;
            }
        } else if (!dealId.equals(other.dealId)) {
            return false;
        }
        if (perqId == null) {
            if (other.perqId != null) {
                return false;
            }
        } else if (!perqId.equals(other.perqId)) {
            return false;
        }
        return true;
    }

}