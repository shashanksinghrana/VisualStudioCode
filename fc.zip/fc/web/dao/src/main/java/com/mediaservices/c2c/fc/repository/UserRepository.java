package com.mediaservices.c2c.fc.repository;

import static com.mediaservices.c2c.fc.constants.QueryConstants.USER_ID_BY_USER_LOGIN_ID;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.User;

/**
 * The Interface UserRepository.
 */
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Gets the user id by active and user id.
     *
     * @param userId
     *            the user id
     * @return the user id by active and user id
     */
    @Query(value = QueryConstants.USER_ID_BY_USER_ID_AND_ACTIVE_IND, nativeQuery = true)
    String getUserIdByActiveAndUserId(String userId);

    /**
     * Gets the user by user role list.
     *
     * @param roleList
     *            the role list
     * @return the user by user role list
     */
    @Query(value = QueryConstants.USERS_BY_USER_ROLE_LIST)
    Set<User> getUserByUserRoleList(@Param("userRoleList") List<String> roleList);

    /**
     * Gets the user by user id.
     *
     * @param userId
     *            the user id
     * @return the user by user id
     */
    @Query(value = QueryConstants.USER_BY_USER_ID, nativeQuery = true)
    User getUserByUserId(@Param("userId") String userId);

    /**
     * Find by user id.
     *
     * @param userId
     *            the user id
     * @return the optional
     */
    Optional<User> findByUserId(String userId);

    /**
     * Find by user id and is active.
     *
     * @param userId
     *            the user id
     * @param isActive
     *            the is active
     * @return the optional
     */
    Optional<User> findByUserIdAndIsActive(String userId, boolean isActive);

    /**
     * Find user id by user login id.
     *
     * @param userLoginId
     *            the user login id
     * @return the string
     */
    @Query(value = USER_ID_BY_USER_LOGIN_ID, nativeQuery = true)
    public String findUserIdByUserLoginId(@Param("userLoginId") String userLoginId);

    /**
     * Find by user id and is active true and module accesses module lookup
     * name.
     *
     * @param userId
     *            the user id
     * @param lookupName
     *            the lookup name
     * @return the user
     */
    public User findByUserIdAndIsActiveTrueAndModuleAccesses_module_lookupName(String userId, String lookupName);
}
