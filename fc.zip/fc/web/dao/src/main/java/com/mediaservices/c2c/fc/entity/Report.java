package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class Report.
 */
@Entity
@Table(name = "FC_REPORT")
public class Report implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The report id. */
    @Id
    @Column(name = "Id")
    @SequenceGenerator(name = "seqReportId", sequenceName = "DBO_FC.FC_REPORT_ID_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "seqReportId")
    private Long reportId;

    /** The filtered deals. */
    @Column(name = "FILTER")
    private String filteredDeals;

    /** The created user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created date. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /**
     * Gets the report id.
     *
     * @return the report id
     */
    public Long getReportId() {
        return reportId;
    }

    /**
     * Sets the report id.
     *
     * @param reportId
     *            the new report id
     */
    public void setReportId(Long reportId) {
        this.reportId = reportId;
    }

    /**
     * Gets the filtered deals.
     *
     * @return the filtered deals
     */
    public String getFilteredDeals() {
        return filteredDeals;
    }

    /**
     * Sets the filtered deals.
     *
     * @param filteredDeals
     *            the new filtered deals
     */
    public void setFilteredDeals(String filteredDeals) {
        this.filteredDeals = filteredDeals;
    }

    /**
     * Gets the created user.
     *
     * @return the created user
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * Sets the created user.
     *
     * @param createdUser
     *            the new created user
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate
     *            the new created date
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

}
