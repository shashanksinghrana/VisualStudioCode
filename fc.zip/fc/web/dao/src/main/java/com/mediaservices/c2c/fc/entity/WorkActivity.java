package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class WorkActivity.
 */
@Entity
@Table(name = "FC_WORK_ACTIVITY")
public class WorkActivity implements Serializable {
    
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The work activity id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "workActivityIdSeq")
    @SequenceGenerator(name = "workActivityIdSeq", sequenceName = "FC_WORK_ACTIVITY_ID_SEQ", allocationSize = 1)
    private Long workActivityId;
    
    /** The activity lookup. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ACTIVITY_LOOKUP_ID")
    private FcLookup activityLookup;
    
    /** The start date. */
    @Column(name = "START_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate startDate;
    
    /** The note. */
    @Column(name = "NOTE")
    private String note;

    /** The deal id. */
    @Column(name = "DEAL_ID")
    private Long dealId;
    
    /** The princ free lookup. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRINCIPAL_FREE_LOOKUP_ID")
    private FcLookup princFreeLookup;
    
    /** The post free lookup. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "POST_FREE_LOOKUP_ID")
    private FcLookup postFreeLookup;
    
    /** The gurantee lookup. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GUARANTEE_LOOKUP_ID")
    private FcLookup guranteeLookup;

    /** The description. */
    @Column(name = "DESCRIPTION")
    private String description;

	/**
	 * Gets the work activity id.
	 *
	 * @return the work activity id
	 */
	public Long getWorkActivityId() {
		return workActivityId;
	}

	/**
	 * Sets the work activity id.
	 *
	 * @param workActivityId the new work activity id
	 */
	public void setWorkActivityId(Long workActivityId) {
		this.workActivityId = workActivityId;
	}

	/**
	 * Gets the activity lookup.
	 *
	 * @return the activity lookup
	 */
	public FcLookup getActivityLookup() {
		return activityLookup;
	}

	/**
	 * Sets the activity lookup.
	 *
	 * @param activityLookup the new activity lookup
	 */
	public void setActivityLookup(FcLookup activityLookup) {
		this.activityLookup = activityLookup;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public LocalDate getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the note.
	 *
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * Sets the note.
	 *
	 * @param note the new note
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * Gets the deal id.
	 *
	 * @return the deal id
	 */
	public Long getDealId() {
		return dealId;
	}

	/**
	 * Sets the deal id.
	 *
	 * @param dealId the new deal id
	 */
	public void setDealId(Long dealId) {
		this.dealId = dealId;
	}

	/**
	 * Gets the princ free lookup.
	 *
	 * @return the princ free lookup
	 */
	public FcLookup getPrincFreeLookup() {
		return princFreeLookup;
	}

	/**
	 * Sets the princ free lookup.
	 *
	 * @param princFreeLookup the new princ free lookup
	 */
	public void setPrincFreeLookup(FcLookup princFreeLookup) {
		this.princFreeLookup = princFreeLookup;
	}

	/**
	 * Gets the post free lookup.
	 *
	 * @return the post free lookup
	 */
	public FcLookup getPostFreeLookup() {
		return postFreeLookup;
	}

	/**
	 * Sets the post free lookup.
	 *
	 * @param postFreeLookup the new post free lookup
	 */
	public void setPostFreeLookup(FcLookup postFreeLookup) {
		this.postFreeLookup = postFreeLookup;
	}

	/**
	 * Gets the gurantee lookup.
	 *
	 * @return the gurantee lookup
	 */
	public FcLookup getGuranteeLookup() {
		return guranteeLookup;
	}

	/**
	 * Sets the gurantee lookup.
	 *
	 * @param guranteeLookup the new gurantee lookup
	 */
	public void setGuranteeLookup(FcLookup guranteeLookup) {
		this.guranteeLookup = guranteeLookup;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

  

}