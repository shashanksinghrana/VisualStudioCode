package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * Persistent class of Formula Details table
 * 
 *
 */
@Entity
@Table(name = "FC_FORMULA_DETAIL")
public class FormulaDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "formulaDetailIdSeq")
    @SequenceGenerator(name = "formulaDetailIdSeq", sequenceName = "DBO_FC.FC_FORMULA_DETAIL_ID_SEQ", allocationSize = 1)
    private Long formulaDetailId;

    // Bidirectional mapping
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "FORMULA_ID")
    private Formula adminFormula;

    @Column(name = "DISPLAY_NAME")
    private String displayName;

    @OneToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "FIELD_TYPE_LOOKUP_ID")
    private FcLookup fieldType;

    @Column(name = "VALUE")
    private String value;

    @Column(name = "DEFAULT_VALUE")
    private String defaultValue;

    @Column(name = "ORDER_NUM")
    private Long orderNum;

    @Column(name = "DEPENDS_ON_ORDER_NUM")
    private String dependsOnOrderNum;

    @OneToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "GROUP_TYPE_LOOKUP_ID")
    private FcLookup groupType;

    @Column(name = "TABLE_NAME")
    private String tableName;

    @Column(name = "TABLE_FIELD_NAME")
    private String tableFieldName;

    @Type(type = "yes_no")
    @Column(name = "REQUIRED_FLAG")
    private Boolean requiredFlag;

    @Column(name = "VALIDATION_EXPRESSION")
    private String validationExpression;

    @OneToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "SUMMARY_GROUP_TYPE_LOOKUP_ID")
    private FcLookup summaryGroupType;

    @Column(name = "SUMMARY_ORDER")
    private Long summaryOrder;

    /** The created by user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    @Column(name = "FIELD_NAME")
    private String fieldName;

    public Long getFormulaDetailId() {
        return formulaDetailId;
    }

    public void setFormulaDetailId(Long formulaDetailId) {
        this.formulaDetailId = formulaDetailId;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Formula getAdminFormula() {
        return adminFormula;
    }

    public void setAdminFormula(Formula adminFormula) {
        this.adminFormula = adminFormula;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public Long getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Long orderNum) {
        this.orderNum = orderNum;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getTableFieldName() {
        return tableFieldName;
    }

    public void setTableFieldName(String tableFieldName) {
        this.tableFieldName = tableFieldName;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public Boolean getRequiredFlag() {
        return requiredFlag;
    }

    public void setRequiredFlag(Boolean requiredFlag) {
        this.requiredFlag = requiredFlag;
    }

    public String getValidationExpression() {
        return validationExpression;
    }

    public void setValidationExpression(String validationExpression) {
        this.validationExpression = validationExpression;
    }

    public String getDependsOnOrderNum() {
        return dependsOnOrderNum;
    }

    public void setDependsOnOrderNum(String dependsOnOrderNum) {
        this.dependsOnOrderNum = dependsOnOrderNum;
    }

    public FcLookup getFieldType() {
        return fieldType;
    }

    public void setFieldType(FcLookup fieldType) {
        this.fieldType = fieldType;
    }

    public FcLookup getGroupType() {
        return groupType;
    }

    public void setGroupType(FcLookup groupType) {
        this.groupType = groupType;
    }

    public FcLookup getSummaryGroupType() {
        return summaryGroupType;
    }

    public void setSummaryGroupType(FcLookup summaryGroupType) {
        this.summaryGroupType = summaryGroupType;
    }

    public Long getSummaryOrder() {
        return summaryOrder;
    }

    public void setSummaryOrder(Long summaryOrder) {
        this.summaryOrder = summaryOrder;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

}
