package com.mediaservices.c2c.fc.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.entity.Contract;

/**
 * The Interface ContractRepository.
 */
public interface ContractRepository extends JpaRepository<Contract, Long> {

    /**
     * Returns the Set of contracts with the given deal id. Orders records by
     * Start Date
     *
     * @param id
     * @return Set<Contract>
     */
    List<Contract> findAllByDealId(Long dealId);

    /**
     * Gets the all contracts for deals.
     *
     * @param dealIds
     *            the deal ids
     * @return the all contracts for deals
     */
    @Query(value = "select contract.ID, contract.CONTRACT_LOOKUP_ID,contract_lookup.NAME, contract.DEAL_ID, contract.COMPENSATION_ID from DBO_FC.FC_CONTRACT contract inner join DBO_FC.FC_LOOKUP contract_lookup on contract.CONTRACT_LOOKUP_ID = contract_lookup.ID  where DEAL_ID in (:dealIds) order by contract.DEAL_ID, contract.UPDATE_DATE desc, contract.ID", nativeQuery = true)
    List<Object[]> getAllContractsForDeals(@Param("dealIds") Set<Long> dealIds);

    /**
     * Gets the all contract by deal id.
     *
     * @param dealId
     *            the deal id
     * @return the all contract by deal id
     */
    @Query(value = "SELECT contract.* FROM (SELECT c.*, CASE WHEN c.COMPENSATION_ID IS NOT NULL THEN 1 END AS Compensation, l.TYPE, comp.CONTRACT_DATE  FROM DBO_FC.FC_CONTRACT c  LEFT JOIN FC_COMPENSATION comp  ON c.COMPENSATION_ID = comp.ID INNER JOIN DBO_FC.FC_LOOKUP l  ON l.ID = c.CONTRACT_LOOKUP_ID  WHERE c.DEAL_ID = :dealId ) contract ORDER BY contract.CONTRACT_DATE desc,  contract.TYPE desc, contract.id ASC", nativeQuery = true)
    List<Contract> getAllContractByDealId(@Param("dealId") Long dealId);

}
