package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * Persistent class for Formula table
 * 
 * @author U50922
 *
 */
@Entity
@Table(name = "FC_FORMULA")
public class Formula implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "formulaIdSeq")
    @SequenceGenerator(name = "formulaIdSeq", sequenceName = "DBO_FC.FC_FORMULA_ID_SEQ")
    private Long formulaId;

    @Column(name = "DEAL_TYPE_LOOKUP_ID")
    private Long dealTypeId;

    @Column(name = "FUNCTION_LOOKUP_ID")
    private Long functionTypeId;

    @Column(name = "TYPE_LOOKUP_ID")
    private Long typeLookupId;

    @Column(name = "SUB_TYPE_LOOKUP_ID")
    private Long subTypeLookupId;

    @Column(name = "STUDIO_LOOKUP_ID")
    private Long studioId;

    @Type(type = "yes_no")
    @Column(name = "DISABLE_FLAG")
    private Boolean disableFlag;

    @Column(name = "EFFECTIVE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime effectiveDate;

    /** The created by user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    @OneToMany(mappedBy = "adminFormula", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("orderNum")
    private Set<FormulaDetail> adminFormulaDetail;

    public Boolean getDisableFlag() {
        return disableFlag;
    }

    public void setDisableFlag(Boolean disableFlag) {
        this.disableFlag = disableFlag;
    }

    public LocalDateTime getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDateTime effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Long getFormulaId() {
        return formulaId;
    }

    public void setFormulaId(Long formulaId) {
        this.formulaId = formulaId;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<FormulaDetail> getAdminFormulaDetail() {
        if (this.adminFormulaDetail == null) {
            this.adminFormulaDetail = new HashSet<>();
        }

        return adminFormulaDetail;
    }

    public void setAdminFormulaDetail(Set<FormulaDetail> adminFormulaDetail) {
        this.adminFormulaDetail = adminFormulaDetail;
    }

    public Long getDealTypeId() {
        return dealTypeId;
    }

    public void setDealTypeId(Long dealTypeId) {
        this.dealTypeId = dealTypeId;
    }

    public Long getFunctionTypeId() {
        return functionTypeId;
    }

    public void setFunctionTypeId(Long functionTypeId) {
        this.functionTypeId = functionTypeId;
    }

    public Long getTypeLookupId() {
        return typeLookupId;
    }

    public void setTypeLookupId(Long typeLookupId) {
        this.typeLookupId = typeLookupId;
    }

    public Long getSubTypeLookupId() {
        return subTypeLookupId;
    }

    public void setSubTypeLookupId(Long subTypeLookupId) {
        this.subTypeLookupId = subTypeLookupId;
    }

    public Long getStudioId() {
        return studioId;
    }

    public void setStudioId(Long studioId) {
        this.studioId = studioId;
    }

}
