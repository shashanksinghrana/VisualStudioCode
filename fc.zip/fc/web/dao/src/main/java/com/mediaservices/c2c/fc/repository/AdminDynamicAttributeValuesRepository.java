package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.AdminDynamicAttributeValues;

/**
 * The Interface AdminDynamicAttributeValuesRepository.
 */
public interface AdminDynamicAttributeValuesRepository extends JpaRepository<AdminDynamicAttributeValues, Long> {

    @Query(value = QueryConstants.ADMIN_DYNAMIC_ATTRIBUTE_VALUES_BY_TYPE_AND_MODULE, nativeQuery = true)
    List<AdminDynamicAttributeValues> getAdminDynamicAttributeValuesByTypeAndModule(@Param("type") String type,
            @Param("module") String module);

    @Query(value = QueryConstants.ADMIN_DYNAMIC_ATTRIBUTE_VALUES_BY_TYPE, nativeQuery = true)
    List<AdminDynamicAttributeValues> getAdminDynamicAttributeValuesByType(@Param("type") String type);

}
