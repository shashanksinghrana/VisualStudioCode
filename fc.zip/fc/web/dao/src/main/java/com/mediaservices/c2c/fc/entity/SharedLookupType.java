package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LOOKUP_TYPE")
public class SharedLookupType implements Serializable {
    @Id
    @Column(name = "LOOKUP_TYPE_ID")
    private Long lookupTypeId;

    @Column(name = "LOOKUP_TYPE_NAME")
    private String lookupTypeName;

    private static final long serialVersionUID = 1L;

    public SharedLookupType() {
        super();
    }

    public Long getLookupTypeId() {
        return lookupTypeId;
    }

    public void setLookupTypeId(Long lookupTypeId) {
        this.lookupTypeId = lookupTypeId;
    }

    public String getLookupTypeName() {
        return lookupTypeName;
    }

    public void setLookupTypeName(String lookupTypeName) {
        this.lookupTypeName = lookupTypeName;
    }

}
