package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.ProjectCastingCompany;

/**
 * The Interface ProjectCastingCompanyRepository.
 */
public interface ProjectCastingCompanyRepository extends JpaRepository<ProjectCastingCompany, Long> {

    /**
     * Returns the set of ProjectCastingCompanies for the given projectId.
     *
     * @param projectId
     *            the project id
     * @return Set<ProjectCastingCompany>
     */
    List<ProjectCastingCompany> findAllByProjectId(Long projectId);

    /**
     * Find all by project id and production company id.
     *
     * @param projectId
     *            the project id
     * @param compId
     *            the comp id
     * @return the list
     */
    List<ProjectCastingCompany> findAllByProjectIdAndProductionCompanyId(Long projectId, Long compId);

}
