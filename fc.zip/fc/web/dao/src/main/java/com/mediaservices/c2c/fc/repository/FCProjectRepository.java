package com.mediaservices.c2c.fc.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.entity.FCProject;

/**
 * The Interface ProjectRepository.
 */
public interface FCProjectRepository extends JpaRepository<FCProject, Long> {

    @Query(value = "select * from DBO_MP.PROJECT  order by updated_date DESC NULLS LAST", nativeQuery = true)
    List<FCProject> findAllByOrderByUpdatedDateDesc();

    @Query(value = "select project_id, GL#_PROD, UPDATED_DATE from DBO_MP.PROJECT where PROJECT_ID in (:projectIds)", nativeQuery = true)
    List<Object[]> findProjectByProjectIds(@Param("projectIds") Set<Long> projectIds);
}
