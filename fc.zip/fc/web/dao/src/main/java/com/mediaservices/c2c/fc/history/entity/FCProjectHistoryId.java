package com.mediaservices.c2c.fc.history.entity;

import java.io.Serializable;

/**
 * The Class ProjectHistoryId.
 */
public class FCProjectHistoryId implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 2232158199501582075L;

    /** The project id. */
    private Long projectId;

    /** The version. */
    private Long version;

    public FCProjectHistoryId() {
        super();
        // TODO Auto-generated constructor stub
    }

    public FCProjectHistoryId(Long projectId, Long version) {
        super();
        this.projectId = projectId;
        this.version = version;
    }

    /**
     * Gets the project id.
     *
     * @return the project id
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * Sets the project id.
     *
     * @param projectId
     *            the new project id
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Long getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version
     *            the new version
     */
    public void setVersion(Long version) {
        this.version = version;
    }

}