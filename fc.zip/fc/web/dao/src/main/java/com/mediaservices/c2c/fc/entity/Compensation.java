package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The persistent class for the FC_COMPENSATION database table.
 *
 */
@Entity
@Table(name = "FC_COMPENSATION")
public class Compensation implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "compensationIdSeq")
    @SequenceGenerator(name = "compensationIdSeq", sequenceName = "DBO_FC.FC_COMPENSATION_ID_SEQ", allocationSize = 1)
    private Long compensationId;

    @Column(name = "DEAL_ID")
    private Long dealId;

    @Column(name = "GUARANTEE_NUMBER")
    private Long guaranteeNumber;

    @Column(name = "GUARANTEE_TYPE")
    private String guaranteeType;

    @Column(name = "FEE_TYPE_ID")
    private Long feeTypeId;

    @Column(name = "RATE_VALUE")
    private Double rate;

    @Type(type = "yes_no")
    @Column(name = "DESCRIPT")
    private Boolean descript;

    @Column(name = "START_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate startDate;

    @Column(name = "PERIOD_ID")
    private Long periodId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PERIOD_ID", updatable = false, insertable = false)
    private FcLookup periodLookup;

    @Column(name = "INTERVAL")
    private String interval;

    @Column(name = "CONTRACT_RETURNED_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate contractReturnedDate;

    @Column(name = "CONTRACT_REVISIED_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate contractRevisedDate;

    @Column(name = "CONTRACT_SENT_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate contractSentDate;

    @Column(name = "CONTRACT_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate contractDate;

    @Column(name = "CONTRACT_TEXT")
    private String contractText;

    @Column(name = "CONTRACT_INFO")
    private String contractInfo;

    @Column(name = "TOTAL_AMOUNT")
    private Double totalAmount;

    @Type(type = "yes_no")
    @Column(name = "VOID_FLAG")
    private Boolean voidFlag;

    @Column(name = "PRINCIPAL_FREE")
    private Long principalFree;

    @Column(name = "PRINCIPAL_FREE_INTERVAL")
    private String principalFreeInterval;

    @Column(name = "POST_FREE")
    private Long postFree;

    @Column(name = "POST_FREE_INTERVAL")
    private String postFreeInterval;

    @Column(name = "ADJUSTMENT_INTERVAL")
    private Long adjustmentInterval;

    @Column(name = "START_DATE_QUALIFIER")
    private Long startDateQualifierId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "START_DATE_QUALIFIER", updatable = false, insertable = false)
    private FcLookup startDateQualifierLookup;

    /** The created by user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPENSATION_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    private Set<CompensationCondition> conditionSet;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPENSATION_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    private Set<CompensationOperation> operationSet;

    public Compensation() {
    }

    public Long getCompensationId() {
        return compensationId;
    }

    public void setCompensationId(Long compensationId) {
        this.compensationId = compensationId;
    }

    public Long getDealId() {
        return dealId;
    }

    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    public Long getGuaranteeNumber() {
        return guaranteeNumber;
    }

    public void setGuaranteeNumber(Long guaranteeNumber) {
        this.guaranteeNumber = guaranteeNumber;
    }

    public String getGuaranteeType() {
        return guaranteeType;
    }

    public void setGuaranteeType(String guaranteeType) {
        this.guaranteeType = guaranteeType;
    }

    public Long getFeeTypeId() {
        return feeTypeId;
    }

    public void setFeeTypeId(Long feeTypeId) {
        this.feeTypeId = feeTypeId;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public Boolean getDescript() {
        return descript;
    }

    public void setDescript(Boolean descript) {
        this.descript = descript;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public Long getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Long periodId) {
        this.periodId = periodId;
    }

    public String getInterval() {
        return interval;
    }

    public void setInterval(String interval) {
        this.interval = interval;
    }

    public LocalDate getContractReturnedDate() {
        return contractReturnedDate;
    }

    public void setContractReturnedDate(LocalDate contractReturnedDate) {
        this.contractReturnedDate = contractReturnedDate;
    }

    public LocalDate getContractRevisedDate() {
        return contractRevisedDate;
    }

    public void setContractRevisedDate(LocalDate contractRevisedDate) {
        this.contractRevisedDate = contractRevisedDate;
    }

    public LocalDate getContractSentDate() {
        return contractSentDate;
    }

    public void setContractSentDate(LocalDate contractSentDate) {
        this.contractSentDate = contractSentDate;
    }

    /**
     * @return the contractDate
     */
    public LocalDate getContractDate() {
        return contractDate;
    }

    /**
     * @param contractDate
     *            the contractDate to set
     */
    public void setContractDate(LocalDate contractDate) {
        this.contractDate = contractDate;
    }

    public String getContractText() {
        return contractText;
    }

    public void setContractText(String contractText) {
        this.contractText = contractText;
    }

    public String getContractInfo() {
        return contractInfo;
    }

    public void setContractInfo(String contractInfo) {
        this.contractInfo = contractInfo;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Boolean getVoidFlag() {
        return voidFlag;
    }

    public void setVoidFlag(Boolean voidFlag) {
        this.voidFlag = voidFlag;
    }

    public Long getPrincipalFree() {
        return principalFree;
    }

    public void setPrincipalFree(Long principalFree) {
        this.principalFree = principalFree;
    }

    public String getPrincipalFreeInterval() {
        return principalFreeInterval;
    }

    public void setPrincipalFreeInterval(String principalFreeInterval) {
        this.principalFreeInterval = principalFreeInterval;
    }

    public Long getPostFree() {
        return postFree;
    }

    public void setPostFree(Long postFree) {
        this.postFree = postFree;
    }

    public String getPostFreeInterval() {
        return postFreeInterval;
    }

    public void setPostFreeInterval(String postFreeInterval) {
        this.postFreeInterval = postFreeInterval;
    }

    public Long getAdjustmentInterval() {
        return adjustmentInterval;
    }

    public void setAdjustmentInterval(Long adjustmentInterval) {
        this.adjustmentInterval = adjustmentInterval;
    }

    public Long getStartDateQualifierId() {
        return startDateQualifierId;
    }

    public void setStartDateQualifierId(Long startDateQualifierId) {
        this.startDateQualifierId = startDateQualifierId;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public FcLookup getPeriodLookup() {
        return periodLookup;
    }

    public void setPeriodLookup(FcLookup periodLookup) {
        this.periodLookup = periodLookup;
    }

    public FcLookup getStartDateQualifierLookup() {
        return startDateQualifierLookup;
    }

    public void setStartDateQualifierLookup(FcLookup startDateQualifierLookup) {
        this.startDateQualifierLookup = startDateQualifierLookup;
    }

    public Set<CompensationCondition> getConditionSet() {
        return conditionSet;
    }

    public void setConditionSet(Set<CompensationCondition> conditionSet) {
        this.conditionSet = conditionSet;
    }

    public Set<CompensationOperation> getOperationSet() {
        return operationSet;
    }

    public void setOperationSet(Set<CompensationOperation> operationSet) {
        this.operationSet = operationSet;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(51, 13).append(compensationId).append(dealId).toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Compensation other = (Compensation) obj;
        return new EqualsBuilder().append(compensationId, other.compensationId).append(dealId, other.dealId).isEquals();
    }

}