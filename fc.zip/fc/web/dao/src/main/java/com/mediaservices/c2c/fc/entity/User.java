package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Type;

/**
 * The persistent class for the USERS database table.
 *
 */
@Entity
@Table(name = "USERS")
public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "USER_ID")
    private String userId;

    @OneToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_ROLE_ID", referencedColumnName = "ROLE_ID")
    private UserRole userRole;

    @Type(type = "yes_no")
    @Column(name = "ACTIVE_IND")
    private Boolean isActive;

    @Column(name = "DEPARTMENT_ID")
    private Long departmentId;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private Date updatedDate;

    @Column(name = "DEPARTMENT")
    private String department;

    /** The module accesses. */
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ModuleAccess> moduleAccesses;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public UserRole getUserRole() {
        return userRole;
    }

    public void setUserRole(UserRole userRole) {
        this.userRole = userRole;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    /**
     * Gets the module accesses.
     *
     * @return the module accesses
     */
    public List<ModuleAccess> getModuleAccesses() {
        return moduleAccesses;
    }

    /**
     * Sets the module accesses.
     *
     * @param moduleAccesses
     *            the new module accesses
     */
    public void setModuleAccesses(List<ModuleAccess> moduleAccesses) {
        this.moduleAccesses = moduleAccesses;
    }
    
    public String getFullName() {
		String fullName = "";
		if(StringUtils.isNotBlank(this.firstName) && StringUtils.isNotBlank(this.lastName)) {
			fullName = this.firstName + " " + this.lastName;
		} else if(StringUtils.isNotBlank(this.firstName) && StringUtils.isBlank(this.lastName)) {
			fullName = this.firstName;
		} else if (StringUtils.isNotBlank(this.lastName) && StringUtils.isBlank(this.firstName)) {
			fullName = this.lastName;
		}
		return fullName;
	}
}