package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * Entity which contains the FC_ADMIN_MP_LOOKUP table entries. This table
 * controls user admin access for MP.LOOKUP tables.
 * 
 * @author lstaley
 *
 */
@Entity
@Table(name = "FC_ADMIN_MP_LOOKUP")
public class AdminSharedLookup implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "adminMpLookupSeq")
    @SequenceGenerator(name = "adminMpLookupSeq", sequenceName = "FC_ADMIN_MP_LOOKUP_ID_SEQ")
    private Long adminSharedLookupId;

    @Column(name = "FC_TYPE_LOOKUP_ID")
    private Long typeLookupId;

    @Column(name = "MP_LOOKUP_ID")
    private Long sharedLookupId;

    @Column(name = "MODULE")
    private String module;

    @Column(name = "DISPLAY_ORDER")
    private Long displayOrder;

    @Column(name = "CREATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createDate;

    @Column(name = "CREATED_BY")
    private String createUser;

    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updateDate;

    @ManyToOne
    @JoinColumn(name = "MP_LOOKUP_ID", referencedColumnName = "LOOKUP_ID", insertable = false, updatable = false)
    private SharedLookup sharedLookup;

    @ManyToOne()
    @JoinColumn(name = "FC_TYPE_LOOKUP_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    private FcLookup typeLookup;

    /**
     * Default Constructor
     */
    public AdminSharedLookup() {
        super();
    }

    public AdminSharedLookup(Long adminSharedLookupId, Long sharedLookupId, SharedLookup lookup) {
        this.adminSharedLookupId = adminSharedLookupId;
        this.sharedLookupId = sharedLookupId;
        this.sharedLookup = lookup;
    }

    public Long getAdminSharedLookupId() {
        return adminSharedLookupId;
    }

    public void setAdminSharedLookupId(Long adminSharedLookupId) {
        this.adminSharedLookupId = adminSharedLookupId;
    }

    public Long getTypeLookupId() {
        return typeLookupId;
    }

    public void setTypeLookupId(Long typeLookupId) {
        this.typeLookupId = typeLookupId;
    }

    public Long getSharedLookupId() {
        return sharedLookupId;
    }

    public void setSharedLookupId(Long sharedLookupId) {
        this.sharedLookupId = sharedLookupId;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public Long getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder;
    }

    public LocalDateTime getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public LocalDateTime getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(LocalDateTime updateDate) {
        this.updateDate = updateDate;
    }

    public SharedLookup getSharedLookup() {
        return sharedLookup;
    }

    public void setSharedLookup(SharedLookup sharedLookup) {
        this.sharedLookup = sharedLookup;
    }

}