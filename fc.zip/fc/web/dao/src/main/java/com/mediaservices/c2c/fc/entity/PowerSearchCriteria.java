package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

/**
 * The persistent class for the FC_PS_QUERY_CRITERIA database table.
 *
 */
@Entity
@Table(name = "FC_PS_QUERY_CRITERIA")
public class PowerSearchCriteria implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "psQueryCriteriaIdSeq")
    @SequenceGenerator(name = "psQueryCriteriaIdSeq", sequenceName = "DBO_FC.FC_PS_QUERY_CRITERIA_ID_SEQ", allocationSize = 1)
    private Long queryCriteriaId;

    @Column(name = "CLAUSE_CONDITION")
    private String clauseCondition;

    @Column(name = "CRITERIA_NAME")
    private String criteriaName;

    @Column(name = "CRITERIA_CONDITION")
    private String criteriaCondition;

    @Column(name = "CRITERIA_VALUE")
    private String criteriaValue;

    @Column(name = "CRITERIA_LABEL")
    private String criteriaLabel;

    @ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @JoinColumn(name = "QUERY_ID")
    private PowerSearchQuery queryId;

    @Type(type = "yes_no")
    @Column(name = "DEFAULT_IND")
    private Boolean defaultCriteria;

    /**
     * @return the queryCriteriaId
     */
    public Long getQueryCriteriaId() {
        return queryCriteriaId;
    }

    /**
     * @param queryCriteriaId
     *            the queryCriteriaId to set
     */
    public void setQueryCriteriaId(Long queryCriteriaId) {
        this.queryCriteriaId = queryCriteriaId;
    }

    /**
     * @return the clauseCondition
     */
    public String getClauseCondition() {
        return clauseCondition;
    }

    /**
     * @param clauseCondition
     *            the clauseCondition to set
     */
    public void setClauseCondition(String clauseCondition) {
        this.clauseCondition = clauseCondition;
    }

    /**
     * @return the criteriaName
     */
    public String getCriteriaName() {
        return criteriaName;
    }

    /**
     * @param criteriaName
     *            the criteriaName to set
     */
    public void setCriteriaName(String criteriaName) {
        this.criteriaName = criteriaName;
    }

    /**
     * @return the criteriaCondition
     */
    public String getCriteriaCondition() {
        return criteriaCondition;
    }

    /**
     * @param criteriaCondition
     *            the criteriaCondition to set
     */
    public void setCriteriaCondition(String criteriaCondition) {
        this.criteriaCondition = criteriaCondition;
    }

    /**
     * @return the criteriaValue
     */
    public String getCriteriaValue() {
        return criteriaValue;
    }

    /**
     * @param criteriaValue
     *            the criteriaValue to set
     */
    public void setCriteriaValue(String criteriaValue) {
        this.criteriaValue = criteriaValue;
    }

    /**
     * @return the criteriaLabel
     */
    public String getCriteriaLabel() {
        return criteriaLabel;
    }

    /**
     * @param criteriaLabel
     *            the criteriaLabel to set
     */
    public void setCriteriaLabel(String criteriaLabel) {
        this.criteriaLabel = criteriaLabel;
    }

    /**
     * @return the queyId
     */
    public PowerSearchQuery getQueryId() {
        return queryId;
    }

    /**
     * @param queyId
     *            the queyId to set
     */
    public void setQueryId(PowerSearchQuery queyId) {
        this.queryId = queyId;
    }

    /**
     * @return the defaultCriteria
     */
    public Boolean getDefaultCriteria() {
        return defaultCriteria;
    }

    /**
     * @param defaultCriteria
     *            the defaultCriteria to set
     */
    public void setDefaultCriteria(Boolean defaultCriteria) {
        this.defaultCriteria = defaultCriteria;
    }
}