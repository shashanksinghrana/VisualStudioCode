package com.mediaservices.c2c.fc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.Report;

/**
 * The Interface CreditBillingRepository.
 */
public interface ReportRepository extends JpaRepository<Report, Long> {

}
