package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.ProjectStatusDate;

/**
 * The Interface ProjectStatusDateRepository.
 */

public interface ProjectStatusDateRepository extends JpaRepository<ProjectStatusDate, Long> {

    /**
     * Find by project id.
     *
     * @param projectId
     *            the project id
     * @return the list
     */
    List<ProjectStatusDate> findAllByProjectIdOrderByStartDateAsc(Long projectId);

}
