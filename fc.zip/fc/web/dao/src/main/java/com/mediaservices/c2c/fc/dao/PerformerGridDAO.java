package com.mediaservices.c2c.fc.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.mediaservices.c2c.fc.dto.PerformerDealDto;
import com.mediaservices.c2c.fc.dto.PerformerGridSearchCriteria;
import com.mediaservices.c2c.fc.entity.Deal;

/**
 * Interface for Performer Grid DAO.
 * 
 * @author lstaley
 *
 */
@FunctionalInterface
public interface PerformerGridDAO {

    Page<PerformerDealDto> getPerfomerGridData(Long projectId, PerformerGridSearchCriteria searcCriteria, Pageable pageable);

}
