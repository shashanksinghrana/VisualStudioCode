package com.mediaservices.c2c.fc.repository;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.WizardStatus;

/**
 * The Interface WizardStatusRepository.
 */
public interface WizardStatusRepository extends JpaRepository<WizardStatus, Long> {

    /**
     * Returns a set containing all WizardStatuses for the given dealId.
     *
     * @param dealId
     * @return Set<WizardStatus>
     */
    Set<WizardStatus> findAllByDealId(Long dealId);

    Optional<WizardStatus> findByDealIdAndPage_lookupId(Long dealId, Long lookupId);

    Optional<WizardStatus> findByDealIdAndPageLookupId(Long dealId, Long pageLookupId);
}
