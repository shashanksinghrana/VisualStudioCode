package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class WorkPeriod.
 */
@Entity
@Table(name = "FC_WORK_PERIOD")
public class WorkPeriod implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The work period id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqWorkPeriodId")
    @SequenceGenerator(name = "seqWorkPeriodId", sequenceName = "DBO_FC.FC_WORK_PERIOD_ID_SEQ", allocationSize = 1)
    private Long workPeriodId;

    /** The project id. */
    @Column(name = "PROJECT_ID", updatable = false)
    private Long projectId;

    /** The start date. */
    @Column(name = "START_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate startDate;

    /** The finish date. */
    @Column(name = "FINISH_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate finishDate;

    /** The work period. */
    @OneToMany(mappedBy = "workPeriodId", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<WorkPeriodDetail> workPeriodDetail;

    /** The created user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created date. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The updated date. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    /**
     * @param workPeriodId
     *            the workPeriodId to set
     */
    public void setWorkPeriodId(Long workPeriodId) {
        this.workPeriodId = workPeriodId;
    }

    /**
     * @return the projectId
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * @return the startDate
     */
    public LocalDate getStartDate() {
        return startDate;
    }

    /**
     * @param startDate
     *            the startDate to set
     */
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the finishDate
     */
    public LocalDate getFinishDate() {
        return finishDate;
    }

    /**
     * @param finishDate
     *            the finishDate to set
     */
    public void setFinishDate(LocalDate finishDate) {
        this.finishDate = finishDate;
    }

    /**
     * @return the workPeriodId
     */
    public Long getWorkPeriodId() {
        return workPeriodId;
    }

    /**
     * @param workPeriodDetail
     *            the workPeriodDetail to set
     */
    public void setWorkPeriodDetail(List<WorkPeriodDetail> workPeriodDetail) {
        this.workPeriodDetail = workPeriodDetail;
    }

    /**
     * @return the workPeriodDetail
     */
    public List<WorkPeriodDetail> getWorkPeriodDetail() {
        return workPeriodDetail;
    }

    /**
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * @param createdUser
     *            the createdUser to set
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * @return the createdDate
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the lastUpdatedUser
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * @param lastUpdatedUser
     *            the lastUpdatedUser to set
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * @return the updatedDate
     */
    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

}
