package com.mediaservices.c2c.fc.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.dao.PerformerGridDAO;
import com.mediaservices.c2c.fc.dto.PerformerDealDto;
import com.mediaservices.c2c.fc.dto.PerformerGridSearchCriteria;
import com.mediaservices.c2c.fc.grid.PerformersListQueryBuilder;

/**
 * The Class PerformerGridDAOImpl.
 */
@Component
public class PerformerGridDAOImpl implements PerformerGridDAO {

    /** The Constant COLON. */
    private static final String COLON = ":";

    /** The Constant FROM. */
    private static final String FROM = " from ";

    /** The Constant DEAL_TABLE. */
    private static final String DEAL_TABLE = "dbo_fc.fc_deal";

    /** The Constant OUTER_SELECT_QUERY. */
    private static final String OUTER_SELECT_QUERY = "select deal.* from (\n";

    /** The Constant SELECT. */
    private static final String SELECT = "select";

    /** The Constant DISTINCT_DEAL_ID. */
    private static final String DISTINCT_DEAL_ID = " distinct deal.id";

    /** The Constant FIELD_ROLE. */
    private static final String FIELD_ROLE = "role";

    /** The Constant FIELD_ROLE_NUMBER. */
    private static final String FIELD_ROLE_NUMBER = "roleNumber";

    private static final String FIELD_CONTRACT = "contract";

    /** The Constant FIELD_UNION. */
    private static final String FIELD_UNION = "unionName";

    /** The Constant FIELD_PERFORMER_NOTE. */
    private static final String FIELD_PERFORMER_NOTE = "performerNote";

    /** The Constant FIELD_DEAL_DATE. */
    private static final String FIELD_DEAL_DATE = "dealDate";

    /** The Constant FIELD_DEAL_UPDATE_DATE. */
    private static final String FIELD_DEAL_UPDATE_DATE = "dealUpdateDate";

    /** The Constant FIELD_PERFORMER_NAME. */
    private static final String FIELD_PERFORMER_NAME = "performerName";

    /** The Constant FIELD_AGENCY. */
    private static final String FIELD_AGENCY = "agency";

    /** The em. */
    @PersistenceContext
    private EntityManager em;

    /** The extracter. */
    @Autowired
    private PerformersListViewGridDataExtractor extracter;

    /** The Constant SELECT_DEAL_COUNT. */
    private static final String SELECT_DEAL_COUNT = SELECT + " count(" + DISTINCT_DEAL_ID + ") as count" + FROM
            + DEAL_TABLE + " deal inner JOIN DBO_TC.PERSON pn  ON deal.PERFORMER_PARTY_ID = pn.PARTY_ID\n";

    /** The Constant SELECT_DEALS. */
    private static final String SELECT_DEALS = OUTER_SELECT_QUERY + SELECT + DISTINCT_DEAL_ID + FROM + DEAL_TABLE
            + " deal inner JOIN DBO_TC.PERSON pn  ON deal.PERFORMER_PARTY_ID = pn.PARTY_ID\n";

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.fc.dao.AllProjectGridDAO2#getProjectByFilters(com.
     * mediaservices.c2c.fc.dto.PerformerGridSearchCriteria,
     * org.springframework.data.domain.Pageable)
     */
    @Override
    public Page<PerformerDealDto> getPerfomerGridData(Long projectId, PerformerGridSearchCriteria searcCriteria,
            Pageable pageable) {

        List<PerformerDealDto> dealList = new ArrayList<>();

        final PerformersListQueryBuilder builder = new PerformersListQueryBuilder();

        whereCondition(builder, projectId);

        filterConditions(searcCriteria, builder);

        final Long totalRecords = getCount(builder);

        if (totalRecords > 0) {
            final Sort sort = pageable.getSort();
            final String sortBy = sort != null ? sort.toString().split(COLON)[0] : "";
            final String sortDirection = getSortDirection(sort);
            sortConditions(builder, sortBy, sortDirection);
            builder.setQuery(SELECT_DEALS);
            final Query companyQuery = em.createNativeQuery(builder.buildQuery());
            setQueryParam(companyQuery, builder.getFilterAndSortConditions().getNamedParam());
            companyQuery.setMaxResults(pageable.getPageSize());
            companyQuery.setFirstResult((int) pageable.getOffset());
            final List<Object> result = companyQuery.getResultList();

            final Map<Long, PerformerDealDto> dealMap = new LinkedHashMap<>();
            result.forEach(obj -> {
                final PerformerDealDto dealDto = new PerformerDealDto();
                /***
                 * It returns two values in case we retrieve data from db for
                 * any page other than first page and project id at first place
                 * of the result which if of Type BigDecimal.
                 */
                if (obj instanceof BigDecimal) {
                    dealDto.setDealId(convertToLong((BigDecimal) obj));
                } else {
                    final Object[] columns = (Object[]) obj;
                    dealDto.setDealId(convertToLong((BigDecimal) columns[0]));
                }
                dealMap.put(dealDto.getDealId(), dealDto);
            });

            dealList = extracter.createPerformersList(dealMap);
        }
        return new PageImpl<>(dealList, pageable, totalRecords);
    }

    /**
     * Sort conditions.
     *
     * @param builder
     *            the builder
     * @param sortBy
     *            the sort by
     * @param sortDirection
     *            the sort direction
     */
    private void sortConditions(PerformersListQueryBuilder builder, String sortBy, String sortDirection) {
        if (FIELD_DEAL_DATE.equals(sortBy)) {
            builder.sortByDealDate(sortDirection);
        } else if (FIELD_UNION.equals(sortBy)) {
            builder.sortByUnion(sortDirection);
        } else if (FIELD_ROLE.equals(sortBy)) {
            builder.sortByRole(sortDirection);
        } else if (FIELD_PERFORMER_NOTE.equals(sortBy)) {
            builder.sortByPerformerNote(sortDirection);
        } else if (FIELD_PERFORMER_NAME.equals(sortBy)) {
            builder.sortByPerformerName(sortDirection);
        } else if (FIELD_ROLE_NUMBER.equals(sortBy)) {
            builder.sortByRoleNumber(sortDirection);
        } else if (FIELD_DEAL_UPDATE_DATE.equals(sortBy)) {
            builder.sortByDealUpdate(sortDirection);
        } else if (FIELD_CONTRACT.equals(sortBy)) {
            builder.sortByContract(sortDirection);
        }
    }

    /**
     * Gets the sort direction.
     *
     * @param sort
     *            the sort
     * @return the sort direction
     */
    private String getSortDirection(Sort sort) {
        final String sortDirection = sort != null ? sort.toString().split(COLON)[1].trim() : "";
        return Sort.Direction.ASC.toString().equalsIgnoreCase(sortDirection) ? Sort.Direction.ASC.toString()
                : Sort.Direction.DESC.toString();
    }

    /**
     * Where condition.
     *
     * @param builder
     *            the builder
     * @param projectId
     *            the project id
     */
    private void whereCondition(PerformersListQueryBuilder builder, Long projectId) {
        builder.getFilterAndSortConditions().getConditionsFilter()
        .add(" deal.IS_ACTIVE ='Y' and deal.project_id =" + projectId + "\n");
    }

    /**
     * Filter conditions.
     *
     * @param searchDTO
     *            the search DTO
     * @param builder
     *            the builder
     */
    private void filterConditions(PerformerGridSearchCriteria searchDTO, PerformersListQueryBuilder builder) {

        if (!StringUtils.isBlank(searchDTO.getPerformerName())) {
            builder.filterByPerformerName(searchDTO.getPerformerName());
        }

        if (!StringUtils.isBlank(searchDTO.getDealDate())) {
            builder.filterByDealDate(searchDTO.getDealDate());
        }

        if (!StringUtils.isBlank(searchDTO.getPerformerNote())) {
            builder.filterByPerformerNote(searchDTO.getPerformerNote());
        }

        if (!StringUtils.isBlank(searchDTO.getUnionName())) {
            builder.filterByUnion(searchDTO.getUnionName());
        }

        if (!StringUtils.isBlank(searchDTO.getRole())) {
            builder.filterByRole(searchDTO.getRole());
        }

        if (!StringUtils.isBlank(searchDTO.getRoleNumber())) {
            builder.filterByRoleNumber(searchDTO.getRoleNumber());
        }

        if (!StringUtils.isBlank(searchDTO.getContract())) {
            builder.filterByContract(searchDTO.getContract());
        }
    }

    /**
     * Gets the count.
     *
     * @param builder
     *            the builder
     * @return the count
     */
    private Long getCount(PerformersListQueryBuilder builder) {
        builder.setQuery(SELECT_DEAL_COUNT);
        final Query talentQuery = em.createNativeQuery(builder.buildCountQuery());
        setQueryParam(talentQuery, builder.getFilterAndSortConditions().getNamedParam());
        final BigDecimal count = (BigDecimal) talentQuery.getSingleResult();
        return count.longValue();
    }

    /**
     * Sets the query param.
     *
     * @param query
     *            the query
     * @param namedParam
     *            the named param
     */
    private void setQueryParam(Query query, Map<String, List<String>> namedParam) {

        if (namedParam.containsKey(FIELD_DEAL_DATE)) {
            query.setParameter(FIELD_DEAL_DATE, namedParam.get(FIELD_DEAL_DATE));
        }

        if (namedParam.containsKey(FIELD_PERFORMER_NOTE)) {
            query.setParameter(FIELD_PERFORMER_NOTE, namedParam.get(FIELD_PERFORMER_NOTE));
        }

        if (namedParam.containsKey(FIELD_PERFORMER_NAME)) {
            query.setParameter(FIELD_PERFORMER_NAME, namedParam.get(FIELD_PERFORMER_NAME));
        }

        if (namedParam.containsKey(FIELD_AGENCY)) {
            query.setParameter(FIELD_AGENCY, namedParam.get(FIELD_AGENCY));
        }

        if (namedParam.containsKey(FIELD_ROLE)) {
            query.setParameter(FIELD_ROLE, namedParam.get(FIELD_ROLE));
        }

        if (namedParam.containsKey(FIELD_UNION)) {
            query.setParameter(FIELD_UNION, namedParam.get(FIELD_UNION));
        }

        if (namedParam.containsKey(FIELD_ROLE_NUMBER)) {
            query.setParameter(FIELD_ROLE_NUMBER, namedParam.get(FIELD_ROLE_NUMBER));
        }

        if (namedParam.containsKey(FIELD_CONTRACT)) {
            query.setParameter(FIELD_CONTRACT, namedParam.get(FIELD_CONTRACT));
        }

    }

    /**
     * Convert to long.
     *
     * @param source
     *            the source
     * @return the long
     */
    private Long convertToLong(BigDecimal source) {
        if (source == null) {
            return null;
        }
        return source.longValue();
    }

}
