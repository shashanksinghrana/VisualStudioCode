package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.EntityGraph.EntityGraphType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.entity.ProjectCompany;

/**
 * The Interface ProjectLocationPeriodRepository.
 */
public interface ProjectCompanyRepository extends CrudRepository<ProjectCompany, Long> {
	
	@EntityGraph(value = "ProjectCompany", type = EntityGraphType.LOAD)
	List<ProjectCompany> findByProjectId(@Param("projectId") Long projectId);
	
	ProjectCompany findByProjectIdAndCompanyId(@Param("projectId") Long projectId, @Param("companyId") Long companyId);
}
