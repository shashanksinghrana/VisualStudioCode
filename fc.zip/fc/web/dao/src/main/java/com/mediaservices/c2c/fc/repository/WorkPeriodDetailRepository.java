package com.mediaservices.c2c.fc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.WorkPeriod;
import com.mediaservices.c2c.fc.entity.WorkPeriodDetail;

/**
 * The Interface WorkPeriodRepository.
 */
public interface WorkPeriodDetailRepository extends JpaRepository<WorkPeriodDetail, Long> {

    /**
     * Delete by work period id.
     *
     * @param workPeriod
     *            the work period
     */
    void deleteByWorkPeriodId(WorkPeriod workPeriod);

}
