package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.entity.PowerSearchCriteria;
import com.mediaservices.c2c.fc.entity.PowerSearchQuery;

/**
 * The Interface PowerSearchCriteriaRepository.
 */
public interface PowerSearchCriteriaRepository extends JpaRepository<PowerSearchCriteria, Long> {
    @Modifying
    @Query("Delete from PowerSearchCriteria c where c.queryId = :queryId")
    void deleteByQueryId(@Param("queryId") PowerSearchQuery queryId);

    @Query(" from PowerSearchCriteria c where c.queryId = :queryId")
    List<PowerSearchCriteria> findAllByQueryId(@Param("queryId") PowerSearchQuery queryId);

}
