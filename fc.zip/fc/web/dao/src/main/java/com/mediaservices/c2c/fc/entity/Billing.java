package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class Billing.
 */
@Entity
@Table(name = "FC_BILLING")
public class Billing implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The billing id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqBillingId")
    @SequenceGenerator(name = "seqBillingId", sequenceName = "DBO_FC.FC_BILLING_ID_SEQ", allocationSize = 1)
    private Long billingId;

    /** The deal id. */
    @Column(name = "DEAL_ID", updatable = false)
    private Long dealId;

    /** The credit as. */
    @Column(name = "CREDIT_AS")
    private String creditAs;

    /** The cut flag. */
    @Column(name = "CUT_FLAG")
    @Type(type = "yes_no")
    private Boolean cutFlag;

    /** The credited flag. */
    @Column(name = "CREDITED_FLAG")
    @Type(type = "yes_no")
    private Boolean creditedFlag;

    /** The contract_lookup_id. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONFIRMED_BY_LOOKUP_ID")
    private FcLookup confirmedBy;

    /** The attachment. */
    @Column(name = "ATTACHMENT")
    private byte[] attachment;

    /** The attachment type. */
    @Column(name = "ATTACHMENT_TYPE")
    private String attachmentType;

    /** The attachment name. */
    @Column(name = "ATTACHMENT_NAME")
    private String attachmentName;

    /** The billing status note. */
    @Column(name = "BILLING_STATUS_NOTE")
    private String billingStatusNote;

    /** The main title. */
    @Column(name = "MAIN_TITLE_FLAG")
    @Type(type = "yes_no")
    private Boolean mainTitle;

    /** The end title. */
    @Column(name = "END_TITLE_FLAG")
    @Type(type = "yes_no")
    private Boolean endTitle;

    /** The created user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created date. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The updated date. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    /**
     * Gets the billing id.
     *
     * @return the billing id
     */
    public Long getBillingId() {
        return billingId;
    }

    /**
     * Sets the billing id.
     *
     * @param billingId
     *            the new billing id
     */
    public void setBillingId(Long billingId) {
        this.billingId = billingId;
    }

    /**
     * Gets the deal id.
     *
     * @return the deal id
     */
    public Long getDealId() {
        return dealId;
    }

    /**
     * Sets the deal id.
     *
     * @param dealId
     *            the new deal id
     */
    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    /**
     * Gets the credit as.
     *
     * @return the credit as
     */
    public String getCreditAs() {
        return creditAs;
    }

    /**
     * Sets the credit as.
     *
     * @param creditAs
     *            the new credit as
     */
    public void setCreditAs(String creditAs) {
        this.creditAs = creditAs;
    }

    /**
     * Checks if is cut flag.
     *
     * @return true, if is cut flag
     */
    public Boolean isCutFlag() {
        return cutFlag;
    }

    /**
     * Sets the cut flag.
     *
     * @param cutFlag
     *            the new cut flag
     */
    public void setCutFlag(Boolean cutFlag) {
        this.cutFlag = cutFlag;
    }

    /**
     * Checks if is credited flag.
     *
     * @return true, if is credited flag
     */
    public Boolean isCreditedFlag() {
        return creditedFlag;
    }

    /**
     * Sets the credited flag.
     *
     * @param creditedFlag
     *            the new credited flag
     */
    public void setCreditedFlag(Boolean creditedFlag) {
        this.creditedFlag = creditedFlag;
    }

    /**
     * Gets the confirmed by.
     *
     * @return the confirmed by
     */
    public FcLookup getConfirmedBy() {
        return confirmedBy;
    }

    /**
     * Sets the confirmed by.
     *
     * @param confirmedBy
     *            the new confirmed by
     */
    public void setConfirmedBy(FcLookup confirmedBy) {
        this.confirmedBy = confirmedBy;
    }

    /**
     * Gets the attachment.
     *
     * @return the attachment
     */
    public byte[] getAttachment() {
        return attachment;
    }

    /**
     * Sets the attachment.
     *
     * @param attachment
     *            the new attachment
     */
    public void setAttachment(byte[] attachment) {
        this.attachment = attachment;
    }

    /**
     * Gets the attachment type.
     *
     * @return the attachment type
     */
    public String getAttachmentType() {
        return attachmentType;
    }

    /**
     * @return the attachmentName
     */
    public String getAttachmentName() {
        return attachmentName;
    }

    /**
     * @param attachmentName
     *            the attachmentName to set
     */
    public void setAttachmentName(String attachmentName) {
        this.attachmentName = attachmentName;
    }

    /**
     * Sets the attachment type.
     *
     * @param attachmentType
     *            the new attachment type
     */
    public void setAttachmentType(String attachmentType) {
        this.attachmentType = attachmentType;
    }

    /**
     * Gets the created user.
     *
     * @return the created user
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * Sets the created user.
     *
     * @param createdUser
     *            the new created user
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate
     *            the new created date
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the last updated user.
     *
     * @return the last updated user
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * Sets the last updated user.
     *
     * @param lastUpdatedUser
     *            the new last updated user
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate
     *            the new updated date
     */
    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Gets the billing status note.
     *
     * @return the billing status note
     */
    public String getBillingStatusNote() {
        return billingStatusNote;
    }

    /**
     * Sets the billing status note.
     *
     * @param billingStatusNote
     *            the new billing status note
     */
    public void setBillingStatusNote(String billingStatusNote) {
        this.billingStatusNote = billingStatusNote;
    }

    /**
     * @return the mainTitle
     */
    public Boolean isMainTitle() {
        return mainTitle;
    }

    /**
     * @param mainTitle
     *            the mainTitle to set
     */
    public void setMainTitle(Boolean mainTitle) {
        this.mainTitle = mainTitle;
    }

    /**
     * @return the endTitle
     */
    public Boolean isEndTitle() {
        return endTitle;
    }

    /**
     * @param endTitle
     *            the endTitle to set
     */
    public void setEndTitle(Boolean endTitle) {
        this.endTitle = endTitle;
    }

}
