package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class Contract.
 */
@Entity
@Table(name = "FC_CONTRACT")
public class Contract implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The contract id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqContractId")
    @SequenceGenerator(name = "seqContractId", sequenceName = "DBO_FC.FC_CONTRACT_FORMS_ID_SEQ", allocationSize = 1)
    private Long contractId;

    /** The deal Id. */
    @Column(name = "deal_id")
    private Long dealId;

    /** The compensation id. */
    @Column(name = "compensation_id")
    private Long compensationId;

    /** The contract_lookup_id. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contract_lookup_id")
    private FcLookup contractLookupId;

    /** The primary. */
    /** The created by user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The updated by user. */
    @Column(name = "UPDATED_BY")
    private String updatedUser;

    /** The updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    /**
     * Gets the contract id.
     *
     * @return the contractId
     */
    public Long getContractId() {
        return contractId;
    }

    /**
     * Sets the contract id.
     *
     * @param contractId
     *            the contractId to set
     */
    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    /**
     * Gets the deal id.
     *
     * @return the dealId
     */
    public Long getDealId() {
        return dealId;
    }

    /**
     * Sets the deal id.
     *
     * @param dealId
     *            the dealId to set
     */
    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    /**
     * Gets the compensation id.
     *
     * @return the compensationId
     */
    public Long getCompensationId() {
        return compensationId;
    }

    /**
     * Sets the compensation id.
     *
     * @param compensationId
     *            the compensationId to set
     */
    public void setCompensationId(Long compensationId) {
        this.compensationId = compensationId;
    }

    /**
     * Gets the contract lookup id.
     *
     * @return the contractLookupId
     */
    public FcLookup getContractLookupId() {
        return contractLookupId;
    }

    /**
     * Sets the contract lookup id.
     *
     * @param contractLookupId
     *            the contractLookupId to set
     */
    public void setContractLookupId(FcLookup contractLookupId) {
        this.contractLookupId = contractLookupId;
    }

    /**
     * Gets the created user.
     *
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * Sets the created user.
     *
     * @param createdUser
     *            the createdUser to set
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * Gets the created date.
     *
     * @return the createdDate
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the updated user.
     *
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /**
     * Sets the updated user.
     *
     * @param updatedUser
     *            the updatedUser to set
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    /**
     * Gets the updated date.
     *
     * @return the updatedDate
     */
    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

}
