package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateConverter;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class ProjectStatusDate.
 */
@Entity
@Table(name = "FC_PROJECT_STATUS_DATE")
public class ProjectStatusDate implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The project status id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqProjectStatusId")
    @SequenceGenerator(name = "seqProjectStatusId", sequenceName = "DBO_FC.FC_PROJECT_STATUS_ID_SEQ", allocationSize = 1)
    private Long projectStatusId;

    /** The project id. */
    @Column(name = "PROJECT_ID", updatable = false)
    private Long projectId;

    /** The description. */
    @Column(name = "DESCRIPTION")
    private String desc;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STATUS_LOOKUP_ID")
    private DynamicAttributeValues status;

    /** The start date. */
    @Column(name = "START_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate startDate;

    /** The finish date. */
    @Column(name = "FINISH_DATE")
    @Convert(converter = LocalDateConverter.class)
    private LocalDate finishDate;

    /** The created user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created date. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The updated date. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    /**
     * @return the projectStatusId
     */
    public Long getProjectStatusId() {
        return projectStatusId;
    }

    /**
     * @param projectStatusId
     *            the projectStatusId to set
     */
    public void setProjectStatusId(Long projectStatusId) {
        this.projectStatusId = projectStatusId;
    }

    /**
     * @return the projectId
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc
     *            the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * @return the status
     */
    public DynamicAttributeValues getStatus() {
        return status;
    }

    /**
     * @param sharedLookup
     *            the status to set
     */
    public void setStatus(DynamicAttributeValues sharedLookup) {
        status = sharedLookup;
    }

    /**
     * @return the startDate
     */
    public LocalDate getStartDate() {
        return startDate;
    }

    /**
     * @param startDate
     *            the startDate to set
     */
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the finishDate
     */
    public LocalDate getFinishDate() {
        return finishDate;
    }

    /**
     * @param finishDate
     *            the finishDate to set
     */
    public void setFinishDate(LocalDate finishDate) {
        this.finishDate = finishDate;
    }

    /**
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * @param createdUser
     *            the createdUser to set
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * @return the createdDate
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the lastUpdatedUser
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * @param lastUpdatedUser
     *            the lastUpdatedUser to set
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * @return the updatedDate
     */
    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

}
