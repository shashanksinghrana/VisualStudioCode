package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

@Entity
@Table(name = "FC_COMP_OPERATIONS")
public class CompensationOperation implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "operationIdSeq")
    @SequenceGenerator(name = "operationIdSeq", sequenceName = "DBO_FC.FC_COMP_OPERATIONS_ID_SEQ")
    private Long operationId;

    // bi-directional many-to-one association to Compensation
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPENSATION_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    private Compensation compensation;

    @Column(name = "COMPENSATION_ID")
    private Long compensationId;

    @Column(name = "TYPE_LOOKUP_ID")
    private Long typeLookupId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TYPE_LOOKUP_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    private FcLookup typeLookup;

    @Column(name = "ORDER_NUM")
    private Integer orderNum;

    @Column(name = "OPERATION_LOOKUP_ID")
    private Long operationLookupId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "OPERATION_LOOKUP_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    private FcLookup operationLookup;

    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    @Column(name = "CREATE_DATE")
    private LocalDateTime createdDate;

    @Column(name = "CREATED_BY")
    private String createdUser;

    public CompensationOperation() {
    }

    public Long getOperationId() {
        return operationId;
    }

    public void setOperationId(Long operationId) {
        this.operationId = operationId;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public Compensation getCompensation() {
        return compensation;
    }

    public void setCompensation(Compensation compensation) {
        this.compensation = compensation;
    }

    public Long getTypeLookupId() {
        return typeLookupId;
    }

    public void setTypeLookupId(Long typeLookupId) {
        this.typeLookupId = typeLookupId;
    }

    public FcLookup getTypeLookup() {
        return typeLookup;
    }

    public void setTypeLookup(FcLookup typeLookup) {
        this.typeLookup = typeLookup;
    }

    public Long getOperationLookupId() {
        return operationLookupId;
    }

    public void setOperationLookupId(Long operationLookupId) {
        this.operationLookupId = operationLookupId;
    }

    public FcLookup getOperationLookup() {
        return operationLookup;
    }

    public void setOperationLookup(FcLookup operationLookup) {
        this.operationLookup = operationLookup;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Long getCompensationId() {
        return compensationId;
    }

    public void setCompensationId(Long compensationId) {
        this.compensationId = compensationId;
    }

}
