package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The persistent class for the FC_DYNAMIC_ATTRIBUTE_VALS_ADMN database table.
 * Class represents the table which manages FC's user admin for
 * DynamicAttributeValues.
 *
 */
@Entity
@Table(name = "FC_DYNAMIC_ATTRIBUTE_VALS_ADMN")
public class AdminDynamicAttributeValues implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "dynamicAttributeValueAdminIdSeq")
    @SequenceGenerator(name = "dynamicAttributeValueAdminIdSeq", sequenceName = "FC_DYNMC_ATRBT_VLS_ADMN_ID_SEQ", allocationSize = 1)
    private Long adminDynamicAttributeValuesId;

    @ManyToOne(fetch = FetchType.EAGER, cascade = javax.persistence.CascadeType.ALL)
    @JoinColumn(name = "DYNAMIC_ATTRIBUTE_VALUES_ID", referencedColumnName = "DYNAMIC_ATTRIBUTE_VALUES_ID")
    private DynamicAttributeValues dynamicAttributeValues;

    @Column(name = "TYPE_LOOKUP_ID")
    private Long typeLookupId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TYPE_LOOKUP_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    private FcLookup typeLookup;

    /** The created by user. */
    @Column(name = "CREATED_BY")
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    /** The display order. */
    @Column(name = "DISPLAY_ORDER")
    private String displayOrder;

    public AdminDynamicAttributeValues() {

    }

    public Long getAdminDynamicAttributeValuesId() {
        return adminDynamicAttributeValuesId;
    }

    public void setAdminDynamicAttributeValuesId(Long adminDynamicAttributeValuesId) {
        this.adminDynamicAttributeValuesId = adminDynamicAttributeValuesId;
    }

    public DynamicAttributeValues getDynamicAttributeValues() {
        return dynamicAttributeValues;
    }

    public void setDynamicAttributeValues(DynamicAttributeValues dynamicAttributeValues) {
        this.dynamicAttributeValues = dynamicAttributeValues;
    }

    public Long getTypeLookupId() {
        return typeLookupId;
    }

    public void setTypeLookupId(Long typeLookupId) {
        this.typeLookupId = typeLookupId;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(String displayOrder) {
        this.displayOrder = displayOrder;
    }

    public FcLookup getTypeLookup() {
        return typeLookup;
    }

    public void setTypeLookup(FcLookup typeLookup) {
        this.typeLookup = typeLookup;
    }

}
