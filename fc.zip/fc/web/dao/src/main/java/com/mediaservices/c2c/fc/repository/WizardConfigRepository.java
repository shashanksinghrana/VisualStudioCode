package com.mediaservices.c2c.fc.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.WizardConfig;

/**
 * The Interface WizardConfigRepository.
 */
public interface WizardConfigRepository extends JpaRepository<WizardConfig, Long> {

    @Query(value = QueryConstants.WIZARD_CONFIG_BY_STUDIO_AND_FORM_AND_TYPE, nativeQuery = true)
    Set<WizardConfig> findAllWizardConfigByStudio(@Param("studioId") Long studioId, @Param("type") String type,
            @Param("formType") String formType);

    @Query(value = QueryConstants.WIZARD_CONFIG_BY_FORM_AND_TYPE, nativeQuery = true)
    Set<WizardConfig> findAllWizardConfig(@Param("type") String type, @Param("formType") String formType);

}
