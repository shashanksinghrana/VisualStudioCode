package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the LOOKUP database table.
 *
 */
@Entity
@Table(name = "LOOKUP")
public class SharedLookup implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The mp lookup id. */
    @Id
    @Column(name = "LOOKUP_ID")
    @GeneratedValue(generator = "sharedSseqLookupId")
    @SequenceGenerator(name = "sharedSseqLookupId", sequenceName = "SEQ_LOOKUP_ID", allocationSize = 1)
    private Long mpLookupId;

    /** The lookup name. */
    @Column(name = "LOOKUP_NAME")
    private String lookupName;

    /** The lookup type id. */
    @Column(name = "LOOKUP_TYPE_ID")
    private Long lookupTypeId;

    @Column(name = "DISPLAY_ORDER")
    private Long displayOrder;

    /**
     * Instantiates a new Lookup.
     */
    public SharedLookup() {

    }

    public SharedLookup(Long mpLookupId, String lookupName, Long lookupTypeId) {
        this.mpLookupId = mpLookupId;
        this.lookupName = lookupName;
        this.lookupTypeId = lookupTypeId;
    }

    /**
     * Gets the project notes id.
     *
     * @return the project notes id
     */
    public Long getMpLookupId() {
        return mpLookupId;
    }

    /**
     * Sets the mp lookup id.
     *
     * @param mpLookupId
     *            the new mp lookup id
     */
    public void setMpLookupId(Long mpLookupId) {
        this.mpLookupId = mpLookupId;
    }

    /**
     * Gets the lookup name.
     *
     * @return the lookup name
     */
    public String getLookupName() {
        return lookupName;
    }

    /**
     * Sets the lookup name.
     *
     * @param lookupName
     *            the new lookup name
     */
    public void setLookupName(String lookupName) {
        this.lookupName = lookupName;
    }

    /**
     * Gets the lookup type id.
     *
     * @return the lookup type id
     */
    public Long getLookupTypeId() {
        return lookupTypeId;
    }

    /**
     * Sets the lookup type id.
     *
     * @param lookupTypeId
     *            the new lookup type id
     */
    public void setLookupTypeId(Long lookupTypeId) {
        this.lookupTypeId = lookupTypeId;
    }

    public Long getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder;
    }
}
