package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

@Entity
@Table(name = "FC_WIZARD_CONFIG")
public class WizardConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "wizardConfigIdSeq")
    @SequenceGenerator(name = "wizardConfigIdSeq", sequenceName = "DBO_FC.FC_WIZARD_CONFIG_ID_SEQ")
    private Long wizardConfigId;

    @Column(name = "TYPE_LOOKUP_ID")
    private Long typeLookupId;

    @Column(name = "FORM_LOOKUP_ID")
    private Long formId;

    @Column(name = "FUNCTION_LOOKUP_ID")
    private Long functionLookupId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PAGE_LOOKUP_ID")
    private FcLookup page;

    @Column(name = "DISPLAY_ORDER")
    private Long order;

    @Column(name = "STUDIO_LOOKUP_ID")
    private Long studioId;

    /** The created by user. */
    @Column(name = "CREATED_BY")
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The last updated ts. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    public WizardConfig() {
        super();
    }

    public Long getWizardConfigId() {
        return wizardConfigId;
    }

    public void setWizardConfigId(Long wizardConfigId) {
        this.wizardConfigId = wizardConfigId;
    }

    public Long getTypeLookupId() {
        return typeLookupId;
    }

    public void setTypeLookupId(Long typeLookupId) {
        this.typeLookupId = typeLookupId;
    }

    public Long getFormId() {
        return formId;
    }

    public void setFormId(Long formId) {
        this.formId = formId;
    }

    public Long getFunctionLookupId() {
        return functionLookupId;
    }

    public void setFunctionLookupId(Long functionLookupId) {
        this.functionLookupId = functionLookupId;
    }

    public FcLookup getPage() {
        return page;
    }

    public void setPage(FcLookup page) {
        this.page = page;
    }

    public Long getOrder() {
        return order;
    }

    public void setOrder(Long order) {
        this.order = order;
    }

    public Long getStudioId() {
        return studioId;
    }

    public void setStudioId(Long studioId) {
        this.studioId = studioId;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

}
