package com.mediaservices.c2c.fc.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.mediaservices.c2c.fc.dto.LookupDto;
import com.mediaservices.c2c.fc.dto.PowerSearchDealDto;
import com.mediaservices.c2c.fc.dto.PowerSearchDto;
import com.mediaservices.c2c.fc.entity.FCProjectTitle;
import com.mediaservices.c2c.fc.repository.DealRepository;
import com.mediaservices.c2c.fc.repository.FCProjectRepository;
import com.mediaservices.c2c.fc.repository.ProjectTitleRepository;

/**
 * The Class AllProjectListViewGridDataExtractor.
 */
@Component
public class PowerSearchListViewGridDataExtractor {

    /** The em. */
    @PersistenceContext
    private EntityManager em;

    /** The project repository. */
    @Autowired
    private FCProjectRepository projectRepository;

    /** The project tite repository. */
    @Autowired
    @Qualifier("fcProjectTitleRepository")
    private ProjectTitleRepository projectTiteRepository;

    /** The deal repository. */
    @Autowired
    private DealRepository dealRepository;

    /**
     * Creates the project list.
     *
     * @param projectIds
     *            the project ids
     * @return the list
     */
    @Transactional(readOnly = true)
    public List<PowerSearchDto> createProjectList(Collection<Long> projectIds, List<Object[]> dataMap) {

        Map<Long, PowerSearchDto> projectDtoMap = new LinkedHashMap<>();
        for (Long projectId : projectIds) {
            projectDtoMap.put(projectId, new PowerSearchDto());
        }

        loadProjectDetails(projectDtoMap);
        loadProjectAkas(projectDtoMap);
        loadProjectDeals(projectDtoMap, dataMap);

        return projectDtoMap.values().stream().collect(Collectors.toList());

    }

    /**
     * Load project details.
     *
     * @param talentDtoMap
     *            the talent dto map
     */
    private void loadProjectDetails(Map<Long, PowerSearchDto> talentDtoMap) {
        List<Object[]> projects = projectRepository.findProjectByProjectIds(talentDtoMap.keySet());
        PowerSearchDto allProjectDto;
        for (Object obj : projects) {
            Object[] project = (Object[]) obj;
            allProjectDto = talentDtoMap.get(convertToLong((BigDecimal) project[0]));
            allProjectDto.setProjectId(convertToLong((BigDecimal) project[0]));
            allProjectDto.setUpdatedDate(project[2] != null ? ((Timestamp) project[2]).toLocalDateTime() : null);
            allProjectDto.setAkaNames(new LinkedHashSet<>());
            allProjectDto.setDeals(new LinkedHashSet<>());
            talentDtoMap.put(allProjectDto.getProjectId(), allProjectDto);
        }
    }

    /**
     * Load project akas.
     *
     * @param talentDtoMap
     *            the talent dto map
     */
    private void loadProjectAkas(Map<Long, PowerSearchDto> talentDtoMap) {
        List<FCProjectTitle> projectTitles = projectTiteRepository.findAllByProjectId(talentDtoMap.keySet());
        for (FCProjectTitle projectTitle : projectTitles) {
            if (projectTitle.getAka() == 'N') {
                talentDtoMap.get(projectTitle.getProjectId()).setTitle(projectTitle.getTitle());
            } else {
                talentDtoMap.get(projectTitle.getProjectId()).getAkaNames().add(projectTitle.getTitle());
            }
        }
    }

    /**
     * Load project deals.
     *
     * @param searchDtoMap
     *            the talent dto map
     */
    private void loadProjectDeals(Map<Long, PowerSearchDto> searchDtoMap, List<Object[]> deals) {
        if (!CollectionUtils.isEmpty(deals)) {
            PowerSearchDealDto dealDto;
            for (Object obj : deals) {
                Object[] deal = (Object[]) obj;
                dealDto = new PowerSearchDealDto();
                dealDto.setDealDate(deal[3] != null ? ((Timestamp) deal[3]).toLocalDateTime().toLocalDate() : null);
                dealDto.setUpdateDate(deal[2] != null ? ((Timestamp) deal[2]).toLocalDateTime().toLocalDate() : null);
                dealDto.setDealId(convertToLong((BigDecimal) deal[1]));
                dealDto.setFirstName((String) deal[4]);
                dealDto.setLastName((String) deal[5]);
                dealDto.setRole((String) deal[6]);
                dealDto.setUnionLookup(createDealUnionLookup(deal));
                searchDtoMap.get(convertToLong((BigDecimal) deal[0])).getDeals().add(dealDto);
            }
        }
    }

    /**
     * Creates the deal union lookup.
     *
     * @param deal
     *            the deal
     * @return the lookup dto
     */
    private LookupDto createDealUnionLookup(Object[] deal) {
        LookupDto dto = null;
        if (deal != null && deal[7] != null) {
            dto = new LookupDto();
            dto.setLookupId(convertToLong((BigDecimal) deal[7]));
            dto.setName((String) deal[8]);
            dto.setType((String) deal[9]);
        }

        return dto;
    }

    /**
     * Convert to long.
     *
     * @param source
     *            the source
     * @return the long
     */
    private Long convertToLong(BigDecimal source) {
        if (source == null) {
            return null;
        }
        return source.longValue();
    }

}