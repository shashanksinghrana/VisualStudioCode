package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.entity.WorkActivity;

/**
 * The Interface WorkActivityRepository.
 */
public interface WorkActivityRepository extends JpaRepository<WorkActivity, Long> {

    /**
     * Find all by deal id order by start date desc.
     *
     * @param dealId
     *            the deal id
     * @return the sets the
     */
    List<WorkActivity> findAllByDealIdOrderByStartDateDesc(Long dealId);

    /**
     * Delete work activity.
     *
     * @param dealId
     *            the deal id
     * @param workActivityIds
     *            the work activity ids
     */
    @Modifying
    @Query(value = "delete from fc_work_activity where deal_id =:dealId and id not in(:workActivityIds)", nativeQuery = true)
    void deleteWorkActivity(@Param("dealId") Long dealId, @Param("workActivityIds") List<Long> workActivityIds);

    /**
     * Delete all work activity by deal.
     *
     * @param dealId
     *            the deal id
     */
    @Modifying
    @Query(value = "delete from fc_work_activity where deal_id =:dealId", nativeQuery = true)
    void deleteAllWorkActivityByDeal(@Param("dealId") Long dealId);

}
