package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

@Entity
@Table(name = "FC_COMP_CONDITIONS")
public class CompensationCondition implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "conditionIdSeq")
    @SequenceGenerator(name = "conditionIdSeq", sequenceName = "DBO_FC.FC_COMP_CONDITIONS_ID_SEQ")
    private Long conditionId;

    // bi-directional many-to-one association to Term
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPENSATION_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    private Compensation compensation;

    @Column(name = "COMPENSATION_ID")
    private Long compensationId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TYPE_LOOKUP_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    private FcLookup typeLookup;

    @Column(name = "TYPE_LOOKUP_ID")
    private Long typeLookupId;

    @Column(name = "ORDER_NUM")
    private Integer orderNum;

    @Column(name = "GP_NP_PERCENTILE")
    private Float gpNpPercentile;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONDITION_LOOKUP_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    private FcLookup conditionLookup;

    @Column(name = "CONDITION_LOOKUP_ID")
    private Long conditionLookupId;

    @Column(name = "CONDITION_AMOUNT")
    private Double amount;

    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    @Column(name = "CREATE_DATE")
    private LocalDateTime createdDate;

    @Column(name = "CREATED_BY")
    private String createdUser;

    public CompensationCondition() {
    }

    public Long getConditionId() {
        return conditionId;
    }

    public void setConditionId(Long conditionId) {
        this.conditionId = conditionId;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public Float getGpNpPercentile() {
        return gpNpPercentile;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Compensation getCompensation() {
        return compensation;
    }

    public void setCompensation(Compensation compensation) {
        this.compensation = compensation;
    }

    public Long getCompensationId() {
        return compensationId;
    }

    public void setCompensationId(Long compensationId) {
        this.compensationId = compensationId;
    }

    public FcLookup getTypeLookup() {
        return typeLookup;
    }

    public void setTypeLookup(FcLookup typeLookup) {
        this.typeLookup = typeLookup;
    }

    public Long getTypeLookupId() {
        return typeLookupId;
    }

    public void setTypeLookupId(Long typeLookupId) {
        this.typeLookupId = typeLookupId;
    }

    public FcLookup getConditionLookup() {
        return conditionLookup;
    }

    public void setConditionLookup(FcLookup conditionLookup) {
        this.conditionLookup = conditionLookup;
    }

    public Long getConditionLookupId() {
        return conditionLookupId;
    }

    public void setConditionLookupId(Long conditionLookupId) {
        this.conditionLookupId = conditionLookupId;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public void setGpNpPercentile(Float gpNpPercentile) {
        this.gpNpPercentile = gpNpPercentile;
    }

}
