package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The Entity Class for FC_PS_QUERY.
 */
@Entity
@Table(name = "FC_PS_QUERY")
public class PowerSearchQuery implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "psQueryIdSeq")
    @SequenceGenerator(name = "psQueryIdSeq", sequenceName = "DBO_FC.FC_PS_QUERY_ID_SEQ", allocationSize = 1)
    private Long queryId;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "QUERY_NAME")
    private String queryName;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "UPDATE_DATE")
    private LocalDateTime updatedDate;

    @Column(name = "CREATE_DATE")
    private LocalDateTime createdDate;

    @OneToMany(mappedBy = "queryId", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @OrderBy(value = "queryCriteriaId")
    private List<PowerSearchCriteria> powerSearchCriteria;

    /**
     * @return the queryId
     */
    public Long getQueryId() {
        return queryId;
    }

    /**
     * @param queryId
     *            the queryId to set
     */
    public void setQueryId(Long queryId) {
        this.queryId = queryId;
    }

    /**
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy
     *            the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the queryName
     */
    public String getQueryName() {
        return queryName;
    }

    /**
     * @param queryName
     *            the queryName to set
     */
    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy
     *            the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the updatedDate
     */
    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * @return the createdDate
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the powerSearchCriteria
     */
    public List<PowerSearchCriteria> getPowerSearchCriteria() {
        return powerSearchCriteria;
    }

    /**
     * @param powerSearchCriteria
     *            the powerSearchCriteria to set
     */
    public void setPowerSearchCriteria(List<PowerSearchCriteria> powerSearchCriteria) {
        this.powerSearchCriteria = powerSearchCriteria;
    }
}