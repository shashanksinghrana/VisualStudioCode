package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.Credit;

/**
 * The Interface CreditRepository.
 */
public interface CreditRepository extends JpaRepository<Credit, Long> {

	/**
	 * Find by deal id.
	 *
	 * @param dealid
	 *            the dealid
	 * @return the list
	 */
	List<Credit> findByDealId(Long dealid);
}
