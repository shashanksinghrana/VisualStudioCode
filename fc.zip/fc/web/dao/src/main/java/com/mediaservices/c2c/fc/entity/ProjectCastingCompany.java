package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.mediaservices.c2c.talent.dto.TypeAheadNameDto;

/**
 * The persistent class for the PROJECT_CASTING_COMMPANY database table.
 *
 */
@Entity
@Table(name = "PROJECT_CASTING_COMPANY")
public class ProjectCastingCompany implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "projectCastingCompanyIdSeq")
    @SequenceGenerator(name = "projectCastingCompanyIdSeq", sequenceName = "PROJECT_CASTING_COMPANY_ID_SEQ", allocationSize = 1)
    private Long projectCastingCompanyId;

    /** The project id FK. */
    @Column(name = "PROJECT_ID")
    private Long projectId;

    @Column(name = "SIGNATORY_USER_ID")
    private Long signatoryUserId;

    @Type(type = "yes_no")
    @Column(name = "PRIMARY")
    private Boolean primary;

    @Column(name = "UNION_LOOKUP_ID")
    private Long unionLookupId;

    @Column(name = "PRODUCTION_COMPANY_ID")
    private Long productionCompanyId;

    @Column(name = "CREATE_DATE")
    private LocalDateTime createdDate;

    @Column(name = "CREATED_BY")
    private String createdUser;

    @Column(name = "UPDATE_DATE")
    private LocalDateTime updatedDate;

    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    @Column(name = "UNION_NOTE")
    private byte[] unionNote;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UNION_LOOKUP_ID", insertable = false, updatable = false)
    private FcLookup union;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SIGNATORY_USER_ID", insertable = false, updatable = false)
    private SignatoryUser signatoryUser;

    @Transient
    private transient TypeAheadNameDto productionCompany;

    /**
     * Instantiates a new project casting company.
     */
    public ProjectCastingCompany() {

    }

    /**
     * Gets the project id.
     *
     * @return the project id
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * Sets the project id.
     *
     * @param projectId
     *            the new project id
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectCastingCompanyId() {
        return projectCastingCompanyId;
    }

    public void setProjectCastingCompanyId(Long projectCastingCompanyId) {
        this.projectCastingCompanyId = projectCastingCompanyId;
    }

    public Long getSignatoryUserId() {
        return signatoryUserId;
    }

    public void setSignatoryUserId(Long signatoryUserId) {
        this.signatoryUserId = signatoryUserId;
    }

    public Boolean getPrimary() {
        return primary;
    }

    public void setPrimary(Boolean primary) {
        this.primary = primary;
    }

    public Long getUnionLookupId() {
        return unionLookupId;
    }

    public void setUnionLookupId(Long unionLookupId) {
        this.unionLookupId = unionLookupId;
    }

    public Long getProductionCompanyId() {
        return productionCompanyId;
    }

    public void setProductionCompanyId(Long productionCompanyId) {
        this.productionCompanyId = productionCompanyId;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public FcLookup getUnion() {
        return union;
    }

    public void setUnion(FcLookup union) {
        this.union = union;
    }

    public SignatoryUser getSignatoryUser() {
        return signatoryUser;
    }

    public void setSignatoryUser(SignatoryUser signatoryUser) {
        this.signatoryUser = signatoryUser;
    }

    public TypeAheadNameDto getProductionCompany() {
        return productionCompany;
    }

    public void setProductionCompany(TypeAheadNameDto productionCompany) {
        this.productionCompany = productionCompany;
    }

    public byte[] getUnionNote() {
        return unionNote;
    }

    public void setUnionNote(byte[] unionNote) {
        this.unionNote = unionNote;
    }

}
