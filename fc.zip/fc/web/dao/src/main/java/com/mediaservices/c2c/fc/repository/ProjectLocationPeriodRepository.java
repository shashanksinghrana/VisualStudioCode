package com.mediaservices.c2c.fc.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.entity.ProjectLocationPeriod;

/**
 * The Interface ProjectLocationPeriodRepository.
 */
public interface ProjectLocationPeriodRepository extends CrudRepository<ProjectLocationPeriod, Long> {
	
	@Query(value = "select plp from ProjectLocationPeriod plp where plp.projectCompanyId.projectId =:projectId and plp.projectCompanyId.companyId =:companyId and plp.addressId =:addressId")
	ProjectLocationPeriod getProjectLocationPeriod(@Param("projectId") Long projectId, @Param("companyId") Long companyId, @Param("addressId") Long addressId);
	
	ProjectLocationPeriod findByProjectCompanyIdProjectIdAndProjectCompanyIdCompanyIdAndAddressId(@Param("projectId") Long projectId, @Param("companyId") Long companyId, @Param("addressId") Long addressId);
}
