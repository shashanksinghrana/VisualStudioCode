package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.entity.Crew;

/**
 * The Interface RepresentationRepository.
 */
public interface CrewRepository extends CrudRepository<Crew, Long> {

    List<Crew> findAllByProjectId(final Long projectId);

    @Query(nativeQuery = true, value = "select p.PARTY_ID,p.FIRST_NAME,p.LAST_NAME,w.CONTACT_VALUE from DBO_TC.PERSON p LEFT JOIN DBO_TC.PARTY_CONTACT c ON p.PARTY_ID=c.PARTY_ID and c.CONTACT_TYPE in ('EMAIL') AND c.PRIMARY_FLAG='Y'  LEFT JOIN DBO_TC.WEB_CONTACT w ON c.CONTACT_ID=w.CONTACT_ID where p.PARTY_ID in (:partyIds) ORDER BY p.PARTY_ID")
    List<Object[]> findCrewNameAndEmailByPartyId(@Param("partyIds") final List<Long> partyIds);

    @Query(nativeQuery = true, value = "select c.PARTY_ID,c.PRIMARY_FLAG ,sp.PROP_VALUE ,w.PHONE_NO from PARTY_CONTACT c INNER JOIN DBO_TC.PHONE w ON c.CONTACT_ID=w.CONTACT_ID INNER JOIN SYS_PROP_VALUE sp ON sp.PROP_ID=w.PHONE_TYPE where c.PARTY_ID in (:partyIds) AND c.CONTACT_TYPE in ('PHONE') ORDER BY c.PARTY_ID")
    List<Object[]> findCrewPhones(@Param("partyIds") final List<Long> partyIds);

    @Query(nativeQuery = true, value = "select party_id, prop_value from ( select rank() over (order by s.sort_order asc) as rn, o.PARTY_ID, s.PROP_VALUE,s.sort_order from DBO_TC.OCCUPATION o INNER JOIN SYS_PROP_VALUE s ON o.OCCU_NAME_ID=s.PROP_ID where o.PARTY_ID in (:partyIds) )")
    List<Object[]> findCrewOccupations(@Param("partyIds") final List<Long> partyIds);
}
