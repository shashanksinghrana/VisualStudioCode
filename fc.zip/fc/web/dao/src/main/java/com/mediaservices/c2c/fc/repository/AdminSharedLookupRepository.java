package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mediaservices.c2c.fc.constants.QueryConstants;
import com.mediaservices.c2c.fc.entity.AdminSharedLookup;

/**
 * The Interface AdminSharedLookupRepository.
 */
public interface AdminSharedLookupRepository extends JpaRepository<AdminSharedLookup, Long> {

    @Query(value = QueryConstants.ADMIN_SHARED_LOOKUP_BY_TYPE_AND_MODULE)
    List<AdminSharedLookup> findByTypeAndModule(@Param("type") String type, @Param("module") String module);

    @Query(value = QueryConstants.ADMIN_SHARED_LOOKUP_BY_TYPE)
    List<AdminSharedLookup> findByType(@Param("type") String type);

}
