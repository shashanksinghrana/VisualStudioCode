package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

/**
 * Entity which contains the Dynamic Attribute Values.
 * 
 * @author lstaley
 *
 */
@Entity
@Table(name = "DYNAMIC_ATTRIBUTE_VALUES")
public class DynamicAttributeValues implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "DYNAMIC_ATTRIBUTE_VALUES_ID")
    @GeneratedValue(generator = "SeqDynamicAttrValId")
    @SequenceGenerator(name = "SeqDynamicAttrValId", sequenceName = "SEQ_DYNAMIC_ATTR_VAL_ID")
    private Long dynamicAttributeValuesId;

    @Column(name = "ATTRIBUTE_VALUE")
    private String attributeValue;

    @Column(name = "ATTRIBUTE_ORDER")
    private Long attributeOrder;

    @Type(type = "yes_no")
    @Column(name = "ATTRIBUTE_ACTIVE_IND")
    private Boolean attributeActiveInd;

    @Column(name = "ATTRIBUTE_PARENT_ID")
    private String parentId;

    @Type(type = "yes_no")
    @Column(name = "ATTRIBUTE_DELETE_IND")
    private Boolean deleteIndex;

    @Column(name = "ATTRIBUTE_DISP_VAL")
    private String attributeDisplayValue;

    @Column(name = "DYNAMIC_ATTRIBUTE_ID")
    private Long dynamicAttributeId;

    @Column(name = "LAST_UPDATE_USER")
    private String updateUser;

    @Column(name = "LAST_UPDATE_TS")
    private Timestamp updateTimestamp;

    /**
     * Constructor
     * 
     * @param dynamicAttributeValuesId
     * @param attributeActiveInd
     * @param attributeDisplayValue
     */
    public DynamicAttributeValues(Long dynamicAttributeValuesId, Boolean attributeActiveInd,
            String attributeDisplayValue) {
        super();
        this.dynamicAttributeValuesId = dynamicAttributeValuesId;
        this.attributeActiveInd = attributeActiveInd;
        this.attributeDisplayValue = attributeDisplayValue;
    }

    /**
     * Default Constructor
     */
    public DynamicAttributeValues() {
        super();
    }

    public String getAttributeDisplayValue() {
        return attributeDisplayValue;
    }

    public void setAttributeDisplayValue(String attributeDisplayValue) {
        this.attributeDisplayValue = attributeDisplayValue;
    }

    public String getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }

    public Long getAttributeOrder() {
        return attributeOrder;
    }

    public void setAttributeOrder(Long attributeOrder) {
        this.attributeOrder = attributeOrder;
    }

    public Long getDynamicAttributeValuesId() {
        return dynamicAttributeValuesId;
    }

    public void setAttributeActiveInd(Boolean attributeActiveInd) {
        this.attributeActiveInd = attributeActiveInd;
    }

    public Boolean getAttributeActiveInd() {
        return attributeActiveInd;
    }

    public Boolean getDeleteIndex() {
        return deleteIndex;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public void setDeleteIndex(Boolean deleteIndex) {
        this.deleteIndex = deleteIndex;
    }

    public Long getDynamicAttributeId() {
        return dynamicAttributeId;
    }

    public void setDynamicAttributeId(Long dynamicAttributeId) {
        this.dynamicAttributeId = dynamicAttributeId;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Timestamp getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(Timestamp updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

}