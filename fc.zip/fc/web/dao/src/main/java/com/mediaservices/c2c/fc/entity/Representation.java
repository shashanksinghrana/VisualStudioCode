package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class Representation.
 */
@Entity
@Table(name = "FC_REPRESENTATION")
public class Representation implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The representation id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqRepresentationId")
    @SequenceGenerator(name = "seqRepresentationId", sequenceName = "DBO_FC.FC_REPRESENTATION_ID_SEQ", allocationSize = 1)
    private Long representationId;

    /** The deal id. */
    @Column(name = "DEAL_ID", updatable = false)
    private Long dealId;

    /** The primary. */
    @Column(name = "PRIMARY_REP")
    @Type(type = "yes_no")
    private Boolean primary;

    /** The contract. */
    @Column(name = "CONTRACT")
    @Type(type = "yes_no")
    private Boolean contract;

    /** The direct contact. */
    @Column(name = "DIRECT_CONTACT_ID")
    private Long directContact;

    /** The representation party id. */
    @Column(name = "REPRESENTATION_PARTY_ID")
    private Long representationPartyId;

    @Column(name = "REP_PARTY_ID_VER")
    private Long representationPartyIdVer;

    /** The representation aka id. */
    @Column(name = "REPRESENTATION_AKA_ID")
    private Long representationAkaId;

    /** The company aka id. */
    @Column(name = "COMPANY_AKA_ID")
    private Long companyAkaId;

    /** The occupation id. */
    @Column(name = "OCCUPATION_ID")
    private Long occupationId;

    /** The company party id. */
    @Column(name = "COMPANY_PARTY_ID")
    private Long companyPartyId;

    @Column(name = "COMPANY_PARTY_ID_VER")
    private Long companyPartyIdVer;

    /** The created user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created date. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /** The last updated user. */
    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    /** The updated date. */
    @Column(name = "UPDATE_DATE")
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime updatedDate;

    /**
     * Gets the representation id.
     *
     * @return the representation id
     */
    public Long getRepresentationId() {
        return representationId;
    }

    /**
     * Sets the representation id.
     *
     * @param representationId
     *            the new representation id
     */
    public void setRepresentationId(Long representationId) {
        this.representationId = representationId;
    }

    /**
     * Gets the deal id.
     *
     * @return the deal id
     */
    public Long getDealId() {
        return dealId;
    }

    /**
     * Sets the deal id.
     *
     * @param dealId
     *            the new deal id
     */
    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }

    /**
     * Gets the primary.
     *
     * @return the primary
     */
    public Boolean getPrimary() {
        return primary;
    }

    /**
     * Sets the primary.
     *
     * @param primary
     *            the new primary
     */
    public void setPrimary(Boolean primary) {
        this.primary = primary;
    }

    /**
     * Gets the contract.
     *
     * @return the contract
     */
    public Boolean getContract() {
        return contract;
    }

    /**
     * Sets the contract.
     *
     * @param contract
     *            the new contract
     */
    public void setContract(Boolean contract) {
        this.contract = contract;
    }

    /**
     * Gets the direct contact.
     *
     * @return the direct contact
     */
    public Long getDirectContact() {
        return directContact;
    }

    /**
     * Sets the direct contact.
     *
     * @param directContact
     *            the new direct contact
     */
    public void setDirectContact(Long directContact) {
        this.directContact = directContact;
    }

    /**
     * Gets the representation party id.
     *
     * @return the representation party id
     */
    public Long getRepresentationPartyId() {
        return representationPartyId;
    }

    /**
     * Sets the representation party id.
     *
     * @param representationParty
     *            the new representation party id
     */
    public void setRepresentationPartyId(Long representationParty) {
        representationPartyId = representationParty;
    }

    /**
     * Gets the representation aka id.
     *
     * @return the representation aka id
     */
    public Long getRepresentationAkaId() {
        return representationAkaId;
    }

    /**
     * Sets the representation aka id.
     *
     * @param representationAkaId
     *            the new representation aka id
     */
    public void setRepresentationAkaId(Long representationAkaId) {
        this.representationAkaId = representationAkaId;
    }

    /**
     * Gets the company party id.
     *
     * @return the company party id
     */
    public Long getCompanyPartyId() {
        return companyPartyId;
    }

    /**
     * Sets the company party id.
     *
     * @param companyPartyId
     *            the new company party id
     */
    public void setCompanyPartyId(Long companyPartyId) {
        this.companyPartyId = companyPartyId;
    }

    /**
     * Gets the company aka id.
     *
     * @return the company aka id
     */
    public Long getCompanyAkaId() {
        return companyAkaId;
    }

    /**
     * Sets the company aka id.
     *
     * @param companyAkaId
     *            the new company aka id
     */
    public void setCompanyAkaId(Long companyAkaId) {
        this.companyAkaId = companyAkaId;
    }

    /**
     * Gets the occupation id.
     *
     * @return the occupation id
     */
    public Long getOccupationId() {
        return occupationId;
    }

    public Long getRepresentationPartyIdVer() {
        return representationPartyIdVer;
    }

    public void setRepresentationPartyIdVer(Long representationPartyIdVer) {
        this.representationPartyIdVer = representationPartyIdVer;
    }

    public Long getCompanyPartyIdVer() {
        return companyPartyIdVer;
    }

    public void setCompanyPartyIdVer(Long companyPartyIdVer) {
        this.companyPartyIdVer = companyPartyIdVer;
    }

    /**
     * Sets the occupation id.
     *
     * @param occupationId
     *            the new occupation id
     */
    public void setOccupationId(Long occupationId) {
        this.occupationId = occupationId;
    }

    /**
     * Gets the created user.
     *
     * @return the created user
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * Sets the created user.
     *
     * @param createdUser
     *            the new created user
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate
     *            the new created date
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the last updated user.
     *
     * @return the last updated user
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * Sets the last updated user.
     *
     * @param lastUpdatedUser
     *            the new last updated user
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate
     *            the new updated date
     */
    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

}
