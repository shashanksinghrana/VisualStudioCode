package com.mediaservices.c2c.fc.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.Compensation;
import com.mediaservices.c2c.fc.entity.Contract;
import com.mediaservices.c2c.fc.entity.ContractRider;

/**
 * The Interface ContractRepository.
 */
public interface ContractRiderRepository extends JpaRepository<ContractRider, Long> {

    
}
