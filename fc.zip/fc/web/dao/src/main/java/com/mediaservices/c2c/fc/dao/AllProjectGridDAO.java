package com.mediaservices.c2c.fc.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.mediaservices.c2c.fc.dto.AllProjectDto;
import com.mediaservices.c2c.fc.dto.AllProjectsGridSearchCriteria;
import com.mediaservices.c2c.fc.entity.FCProject;

/**
 * Interface for Performer Grid DAO.
 * 
 * @author lstaley
 *
 */
@FunctionalInterface
public interface AllProjectGridDAO {

    public Page<AllProjectDto> getProjectByFilters(AllProjectsGridSearchCriteria searcCriteria, Pageable pageable);

}
