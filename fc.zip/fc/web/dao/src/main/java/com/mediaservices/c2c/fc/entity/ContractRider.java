package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class Representation.
 */
@Entity
@Table(name = "FC_CONTRACT_RIDER")
public class ContractRider implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The contract rider id. */
    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "seqContractRiderId")
    @SequenceGenerator(name = "seqContractRiderId", sequenceName = "DBO_FC.FC_RIDERS_ID_SEQ", allocationSize = 1)
    private Long contractRiderId;

    /** The feetype_lookup_id. */
    @Column(name = "feetype_lookup_id")
    private Long feetypLookupId;

    /** The contract_lookup_id. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contract_lookup_id")
    private FcLookup contractLookupId;

    /** The primary. */
    /** The filter criteria. */
    @Column(name = "FILTER")
    private String filter;

    /** The primary. */
    /** The created by user. */
    @Column(name = "CREATED_BY", updatable = false)
    private String createdUser;

    /** The created ts. */
    @Column(name = "CREATE_DATE", updatable = false)
    @Convert(converter = LocalDateTimeConverter.class)
    private LocalDateTime createdDate;

    /**
     * @return the contractRiderId
     */
    public Long getContractRiderId() {
        return contractRiderId;
    }

    /**
     * @param contractRiderId
     *            the contractRiderId to set
     */
    public void setContractRiderId(Long contractRiderId) {
        this.contractRiderId = contractRiderId;
    }

    /**
     * @return the feetypLookupId
     */
    public Long getFeetypLookupId() {
        return feetypLookupId;
    }

    /**
     * @param feetypLookupId
     *            the feetypLookupId to set
     */
    public void setFeetypLookupId(Long feetypLookupId) {
        this.feetypLookupId = feetypLookupId;
    }

    /**
     * @return the contractLookupId
     */
    public FcLookup getContractLookupId() {
        return contractLookupId;
    }

    /**
     * @param contractLookupId
     *            the contractLookupId to set
     */
    public void setContractLookupId(FcLookup contractLookupId) {
        this.contractLookupId = contractLookupId;
    }

    /**
     * @return the filter
     */
    public String getFilter() {
        return filter;
    }

    /**
     * @param filter
     *            the filter to set
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    /**
     * @return the createdUser
     */
    public String getCreatedUser() {
        return createdUser;
    }

    /**
     * @param createdUser
     *            the createdUser to set
     */
    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    /**
     * @return the createdDate
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

}
