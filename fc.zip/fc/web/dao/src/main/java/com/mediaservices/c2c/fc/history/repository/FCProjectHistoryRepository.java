package com.mediaservices.c2c.fc.history.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mediaservices.c2c.fc.history.entity.FCProjectHistory;
import com.mediaservices.c2c.fc.history.entity.FCProjectHistoryId;

/**
 * The Interface ProjectRepository.
 */
public interface FCProjectHistoryRepository extends JpaRepository<FCProjectHistory, FCProjectHistoryId> {

    @Query(value = "select SEQ_PROJECT_VER_ID.nextval from dual", nativeQuery = true)
    public Long getNextProjectVersion();
}
