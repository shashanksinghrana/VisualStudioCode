package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the PROJECT_TITLE database table.
 *
 */
@Entity
@Table(name = "PROJECT_TITLE")
public class FCProjectTitle implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The project title id. */
    @Id
    @Column(name = "PROJECT_TITLE_ID")
    @GeneratedValue(generator = "seqFCProjectTitleId")
    @SequenceGenerator(name = "seqFCProjectTitleId", sequenceName = "DBO_MP.SEQ_PROJECT_TITLE_ID", allocationSize = 1)
    private Long projectTitleId;

    /** The project id FK. */
    @Column(name = "PROJECT_ID")
    private Long projectId;

    /** The aka. */
    @Column(name = "AKA_IND")
    private Character aka;

    /** The title. */
    @Column(name = "TITLE")
    private String title;

    @Column(name = "TITLE_ORDERING")
    private String titleOrder;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PROJECT_ID", insertable = false, updatable = false)
    private FCProject project;

    /**
     * Instantiates a new project title.
     */
    public FCProjectTitle() {

    }

    /**
     * Gets the project title id.
     *
     * @return the project title id
     */
    public Long getProjectTitleId() {
        return projectTitleId;
    }

    /**
     * Sets the project title id.
     *
     * @param projectTitleId
     *            the new project title id
     */
    public void setProjectTitleId(Long projectTitleId) {
        this.projectTitleId = projectTitleId;
    }

    /**
     * Gets the project id.
     *
     * @return the project id
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * Sets the project id.
     *
     * @param projectId
     *            the new project id
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * Gets the aka.
     *
     * @return the aka
     */
    public Character getAka() {
        return aka;
    }

    /**
     * Sets the aka.
     *
     * @param aka
     *            the new aka
     */
    public void setAka(Character aka) {
        this.aka = aka;
    }

    /**
     * Gets the title.
     *
     * @return the title
     */
    public String getTitle() {
        return title.toUpperCase();
    }

    /**
     * Sets the title.
     *
     * @param title
     *            the new title
     */
    public void setTitle(String title) {
        this.title = title;
        if (title != null) {
            this.titleOrder = title.toLowerCase();
        }
    }

    public FCProject getProject() {
        return project;
    }

    public void setProject(FCProject project) {
        this.project = project;
    }

    public String getTitleOrder() {
        return titleOrder;
    }

    public void setTitleOrder(String titleOrder) {
        this.titleOrder = titleOrder;
    }

}
