package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

/**
 * The Class Credit.
 */
@Entity
@Table(name = "FC_CREDIT")
public class Credit implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The deal id. */
	@Id
	@Column(name = "ID")
	@GeneratedValue(generator = "seqCrditId")
	@SequenceGenerator(name = "seqCrditId", sequenceName = "DBO_FC.FC_CREDIT_ID_SEQ", allocationSize = 1)
	private Long creditId;

	/** The deal id. */
	@Column(name = "DEAL_ID", updatable = false)
	private Long dealId;

	/** The position lookup. */
	@ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
	@JoinColumn(name = "POSITION_LOOKUP_ID", updatable = false)
	private FcLookup positionLookup;

	/** The card lookup. */
	@ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
	@JoinColumn(name = "CARD_LOOKUP_ID", updatable = false)
	private FcLookup cardLookup;

	/** The title lookup. */
	@ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
	@JoinColumn(name = "TITLE_LOOKUP_ID", updatable = false)
	private FcLookup titleLookup;

	/** The note. */
	@Column(name = "NOTE")
	private String note;

	/** The created by user. */
	@Column(name = "CREATED_BY", updatable = false)
	private String createdUser;

	/** The created ts. */
	@Column(name = "CREATE_DATE", updatable = false)
	@Convert(converter = LocalDateTimeConverter.class)
	private LocalDateTime createdDate;

	/** The last updated user. */
	@Column(name = "UPDATED_BY")
	private String lastUpdatedUser;

	/** The last updated ts. */
	@Column(name = "UPDATE_DATE")
	@Convert(converter = LocalDateTimeConverter.class)
	private LocalDateTime updatedDate;

	/**
	 * Gets the credit id.
	 *
	 * @return the credit id
	 */
	public Long getCreditId() {
		return creditId;
	}

	/**
	 * Sets the credit id.
	 *
	 * @param creditId
	 *            the new credit id
	 */
	public void setCreditId(Long creditId) {
		this.creditId = creditId;
	}

	/**
	 * Gets the deal id.
	 *
	 * @return the deal id
	 */
	public Long getDealId() {
		return dealId;
	}

	/**
	 * Sets the deal id.
	 *
	 * @param dealId
	 *            the new deal id
	 */
	public void setDealId(Long dealId) {
		this.dealId = dealId;
	}

	/**
	 * Gets the position lookup.
	 *
	 * @return the position lookup
	 */
	public FcLookup getPositionLookup() {
		return positionLookup;
	}

	/**
	 * Sets the position lookup.
	 *
	 * @param positionLookup
	 *            the new position lookup
	 */
	public void setPositionLookup(FcLookup positionLookup) {
		this.positionLookup = positionLookup;
	}

	/**
	 * Gets the card lookup.
	 *
	 * @return the card lookup
	 */
	public FcLookup getCardLookup() {
		return cardLookup;
	}

	/**
	 * Sets the card lookup.
	 *
	 * @param cardLookup
	 *            the new card lookup
	 */
	public void setCardLookup(FcLookup cardLookup) {
		this.cardLookup = cardLookup;
	}

	/**
	 * Gets the title lookup.
	 *
	 * @return the title lookup
	 */
	public FcLookup getTitleLookup() {
		return titleLookup;
	}

	/**
	 * Sets the title lookup.
	 *
	 * @param titleLookup
	 *            the new title lookup
	 */
	public void setTitleLookup(FcLookup titleLookup) {
		this.titleLookup = titleLookup;
	}

	/**
	 * Gets the note.
	 *
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * Sets the note.
	 *
	 * @param note
	 *            the new note
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * Gets the created user.
	 *
	 * @return the created user
	 */
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * Sets the created user.
	 *
	 * @param createdUser
	 *            the new created user
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate
	 *            the new created date
	 */
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the last updated user.
	 *
	 * @return the last updated user
	 */
	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	/**
	 * Sets the last updated user.
	 *
	 * @param lastUpdatedUser
	 *            the new last updated user
	 */
	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	/**
	 * Gets the updated date.
	 *
	 * @return the updated date
	 */
	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * Sets the updated date.
	 *
	 * @param updatedDate
	 *            the new updated date
	 */
	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
}
