package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

// TODO: Auto-generated Javadoc
/**
 * The Class ModuleAccess.
 */
@Entity
@Table(name = "MODULE_ACCESS")
public class ModuleAccess implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 3375590018926608681L;

    /** The module access id. */
    @Column(name = "ID")
    @Id
    private String moduleAccessId;

    /** The module. */
    @OneToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
    @JoinColumn(name = "MODULE_ID")
    private SharedLookup module;

    /** The studio. */
    @OneToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
    @JoinColumn(name = "STUDIO_ID")
    private SharedLookup studio;

    /** The default access. */
    @Column(name = "DEFAULT_ACCESS")
    @Type(type = "org.hibernate.type.YesNoType")
    private Boolean defaultAccess;

    /** The user role. */
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "ROLE_ID")
    private UserRole userRole;

    /** The user. */
    @JoinColumn(name = "USER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private User user;

    /**
     * Gets the module access id.
     *
     * @return the module access id
     */
    public String getModuleAccessId() {
        return moduleAccessId;
    }

    /**
     * Sets the module access id.
     *
     * @param moduleAccessId
     *            the new module access id
     */
    public void setModuleAccessId(String moduleAccessId) {
        this.moduleAccessId = moduleAccessId;
    }

    /**
     * Gets the module.
     *
     * @return the module
     */
    public SharedLookup getModule() {
        return module;
    }

    /**
     * Sets the module.
     *
     * @param module
     *            the new module
     */
    public void setModule(SharedLookup module) {
        this.module = module;
    }

    /**
     * Gets the studio.
     *
     * @return the studio
     */
    public SharedLookup getStudio() {
        return studio;
    }

    /**
     * Sets the studio.
     *
     * @param studio
     *            the new studio
     */
    public void setStudio(SharedLookup studio) {
        this.studio = studio;
    }

    /**
     * Gets the default access.
     *
     * @return the default access
     */
    public Boolean getDefaultAccess() {
        return defaultAccess;
    }

    /**
     * Sets the default access.
     *
     * @param defaultAccess
     *            the new default access
     */
    public void setDefaultAccess(Boolean defaultAccess) {
        this.defaultAccess = defaultAccess;
    }

    /**
     * Gets the user role.
     *
     * @return the user role
     */
    public UserRole getUserRole() {
        return userRole;
    }

    /**
     * Sets the user role.
     *
     * @param userRole
     *            the new user role
     */
    public void setUserRole(UserRole userRole) {
        this.userRole = userRole;
    }

    /**
     * Gets the user.
     *
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user.
     *
     * @param user
     *            the new user
     */
    public void setUser(User user) {
        this.user = user;
    }

}
