package com.mediaservices.c2c.fc.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.Perq;

/**
 * The Interface PerqRepository.
 */
public interface PerqRepository extends JpaRepository<Perq, Long> {

    /**
     * Finds the Set of Perqs for the given DealId.
     *
     * @param dealId
     * @return
     */
    List<Perq> findAllByDealIdOrderByPerqTypeLookupIdAsc(Long dealId);

    /**
     * Returns the Perq with the given id.
     *
     * @param perqId
     * @return Perq
     */
    Perq getByPerqId(Long perqId);

    /**
     * Find all paid ad ind true by deal id in.
     *
     * @param deals
     *            the deals
     * @return the list
     */
    List<Perq> findAllPaidAdIndTrueByDealIdIn(Set<Long> deals);

}
