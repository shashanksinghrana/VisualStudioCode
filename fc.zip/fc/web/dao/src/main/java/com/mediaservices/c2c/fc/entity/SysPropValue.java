package com.mediaservices.c2c.fc.entity;

public class SysPropValue {

	private Long propId;
	private Long sysPropId;
	private String propValue;
	private String abbr;
	private int sortOrder;
}
