package com.mediaservices.c2c.fc.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedEntityGraphs;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

@Entity
@Table(name = "FC_PROJECT_WORK_COMPANY")
@NamedEntityGraphs({
	@NamedEntityGraph(name = "ProjectCompany",  
					  attributeNodes = { 
							  @NamedAttributeNode(value = "projectLocationPeriods")
							 })
})
public class ProjectCompany {
	
	 	@Id
	    @Column(name = "ID")
	    @GeneratedValue(generator = "seqProjectCompanyId")
	    @SequenceGenerator(name = "seqProjectCompanyId", sequenceName = "DBO_FC.FC_PROJECT_WORK_COMPANY_ID_SEQ", allocationSize = 1)
	    private Long id;

	 	/** The project id. */
	    @Column(name = "PROJECT_ID")
	    private Long projectId;
	    
	    /** The address id. */
	    @Column(name = "COMPANY_ID")
	    private Long companyId;
	    
	    /** The created user. */
	    @Column(name = "CREATED_BY")
	    private String createdBy;

	    /** The created date. */
	    @Column(name = "CREATE_DATE")
	    @Convert(converter = LocalDateTimeConverter.class)
	    private LocalDateTime createdDate;
	    
	    @OneToMany(mappedBy = "projectCompanyId", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	    private List<ProjectLocationPeriod> projectLocationPeriods;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Long getProjectId() {
			return projectId;
		}

		public void setProjectId(Long projectId) {
			this.projectId = projectId;
		}

		public Long getCompanyId() {
			return companyId;
		}

		public void setCompanyId(Long companyId) {
			this.companyId = companyId;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public LocalDateTime getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(LocalDateTime createdDate) {
			this.createdDate = createdDate;
		}
		
		public List<ProjectLocationPeriod> getProjectLocationPeriods() {
			return projectLocationPeriods;
		}
		
		public void setProjectLocationPeriods(List<ProjectLocationPeriod> projectLocationPeriods) {
			this.projectLocationPeriods = projectLocationPeriods;
		}
}
