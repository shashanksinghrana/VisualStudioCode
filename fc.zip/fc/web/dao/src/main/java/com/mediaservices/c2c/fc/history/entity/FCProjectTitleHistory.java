package com.mediaservices.c2c.fc.history.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent entity class for the PROJECT_TITLE_VIEW database view.
 *
 */
@Entity
@Table(name = "PROJECT_TITLE_HISTORY")
@IdClass(FCProjectTitleHistoryId.class)
public class FCProjectTitleHistory implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The project title id. */
    @Id
    @Column(name = "PROJECT_TITLE_ID")
    private Long projectTitleId;

    /** The project id. */
    @Id
    @Column(name = "PROJECT_ID")
    private Long projectId;

    /** The project id version. */
    @Id
    @Column(name = "PROJECT_ID_VER")
    private Long projectIdVersion;

    /** The aka. */
    @Column(name = "AKA_IND")
    private Character aka;

    /** The title. */
    @Column(name = "TITLE")
    private String title;

    /** The title order. */
    @Column(name = "TITLE_ORDERING")
    private String titleOrder;

    /** The project. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
        @JoinColumn(updatable = false, insertable = false, name = "PROJECT_ID", referencedColumnName = "PROJECT_ID"),
        @JoinColumn(updatable = false, insertable = false, name = "PROJECT_ID_VER", referencedColumnName = "VERSION") })
    @JsonIgnore
    private FCProjectHistory project;

    /**
     * Gets the project title id.
     *
     * @return the project title id
     */
    public Long getProjectTitleId() {
        return projectTitleId;
    }

    /**
     * Sets the project title id.
     *
     * @param projectTitleId
     *            the new project title id
     */
    public void setProjectTitleId(Long projectTitleId) {
        this.projectTitleId = projectTitleId;
    }

    /**
     * Gets the project id.
     *
     * @return the project id
     */
    public Long getProjectId() {
        return projectId;
    }

    /**
     * Sets the project id.
     *
     * @param projectId
     *            the new project id
     */
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    /**
     * Gets the project id version.
     *
     * @return the project id version
     */
    public Long getProjectIdVersion() {
        return projectIdVersion;
    }

    /**
     * Sets the project id version.
     *
     * @param projectIdVersion
     *            the new project id version
     */
    public void setProjectIdVersion(Long projectIdVersion) {
        this.projectIdVersion = projectIdVersion;
    }

    /**
     * Gets the aka.
     *
     * @return the aka
     */
    public Character getAka() {
        return aka;
    }

    /**
     * Sets the aka.
     *
     * @param aka
     *            the new aka
     */
    public void setAka(Character aka) {
        this.aka = aka;
    }

    /**
     * Gets the title.
     *
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title.
     *
     * @param title
     *            the new title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the title order.
     *
     * @return the title order
     */
    public String getTitleOrder() {
        return titleOrder;
    }

    /**
     * Sets the title order.
     *
     * @param titleOrder
     *            the new title order
     */
    public void setTitleOrder(String titleOrder) {
        this.titleOrder = titleOrder;
    }

    /**
     * Gets the project.
     *
     * @return the project
     */
    public FCProjectHistory getProject() {
        return project;
    }

    /**
     * Sets the project.
     *
     * @param project
     *            the new project
     */
    public void setProject(FCProjectHistory project) {
        this.project = project;
    }

}
