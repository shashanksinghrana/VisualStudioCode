package com.mediaservices.c2c.fc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mediaservices.c2c.fc.entity.ContractTemplate;

/**
 * The Interface ContractTemplateRepository.
 */
@Repository
public interface ContractTemplateRepository extends JpaRepository<ContractTemplate, Long> {

    /**
     * Find by contract name.
     *
     * @param contractname
     *            the contractname
     * @return the contract template
     */
    ContractTemplate findByContractName(String contractname);

    /**
     * Find by contract lookup id.
     *
     * @param contractlookupid
     *            the contractlookupid
     * @return the list
     */
    ContractTemplate findByContractLookupId(Long contractId);

    /**
     * Find by contract lookup id and filter.
     *
     * @param contractlookupid
     *            the contractlookupid
     * @param filter
     *            the filter
     * @return the contract template
     */
    ContractTemplate findByContractLookupIdAndFilter(Long contractlookupid, String filter);

}
