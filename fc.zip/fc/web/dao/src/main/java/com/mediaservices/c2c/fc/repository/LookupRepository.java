package com.mediaservices.c2c.fc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mediaservices.c2c.fc.entity.FcLookup;

/**
 * The Interface LookupRepository.
 */
public interface LookupRepository extends JpaRepository<FcLookup, Long> {
    public List<FcLookup> findByTypeOrderByDisplayOrder(String type);

    /**
     * Finds the Lookup by the Name and Type parameters.
     * 
     * @param name
     * @param lookupTypeWizardIndicator
     * @return Lookup
     */
    public FcLookup findByNameAndType(String name, String type);
}
