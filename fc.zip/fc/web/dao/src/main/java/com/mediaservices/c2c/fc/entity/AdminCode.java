package com.mediaservices.c2c.fc.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The class which establishes a Lookup's access criteria
 *
 * 
 *
 */
@Entity
@Table(name = "FC_ADMIN_CODES")
public class AdminCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(generator = "adminCodesIdSeq")
    @SequenceGenerator(name = "adminCodesIdSeq", sequenceName = "FC_ADMIN_CODES_ID_SEQ")
    private Long id;

    @Column(name = "STUDIO_LOOKUP_ID")
    private Long studioLookupId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STUDIO_LOOKUP_ID", updatable = false, insertable = false)
    private SharedLookup studio;

    @Column(name = "FUNCTION_LOOKUP_ID")
    private Long functionLookupId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "FUNCTION_LOOKUP_ID", updatable = false, insertable = false)
    private FcLookup function;

    @Column(name = "TYPE_LOOKUP_ID")
    private Long typeLookupId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TYPE_LOOKUP_ID", updatable = false, insertable = false)
    private FcLookup typeLookup;

    @Column(name = "SUB_TYPE_LOOKUP_ID")
    private FcLookup subTypeLookupId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SUB_TYPE_LOOKUP_ID", updatable = false, insertable = false)
    private FcLookup subTypeLookup;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "LOOKUP_ID")
    private FcLookup lookup;

    @Column(name = "DISABLED_FLAG")
    private Character disabledFlag;

    @Column(name = "ORDER_NUM")
    private Long orderNum;

    @Column(name = "UPDATE_DATE")
    private LocalDateTime updatedDate;

    @Column(name = "UPDATED_BY")
    private String lastUpdatedUser;

    public AdminCode() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SharedLookup getStudio() {
        return studio;
    }

    public void setStudio(SharedLookup studio) {
        this.studio = studio;
    }

    public FcLookup getFunction() {
        return function;
    }

    public void setFunction(FcLookup function) {
        this.function = function;
    }

    public FcLookup getTypeLookup() {
        return typeLookup;
    }

    public void setTypeLookup(FcLookup typeLookup) {
        this.typeLookup = typeLookup;
    }

    public FcLookup getSubTypeLookup() {
        return subTypeLookup;
    }

    public void setSubTypeLookup(FcLookup subTypeLookup) {
        this.subTypeLookup = subTypeLookup;
    }

    public Character getDisabledFlag() {
        return disabledFlag;
    }

    public void setDisabledFlag(Character disabledFlag) {
        this.disabledFlag = disabledFlag;
    }

    public Long getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Long orderNum) {
        this.orderNum = orderNum;
    }

    public FcLookup getLookup() {
        return lookup;
    }

    public void setLookup(FcLookup lookup) {
        this.lookup = lookup;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public Long getStudioLookupId() {
        return studioLookupId;
    }

    public void setStudioLookupId(Long studioLookupId) {
        this.studioLookupId = studioLookupId;
    }

    public Long getFunctionLookupId() {
        return functionLookupId;
    }

    public void setFunctionLookupId(Long functionLookupId) {
        this.functionLookupId = functionLookupId;
    }

    public Long getTypeLookupId() {
        return typeLookupId;
    }

    public void setTypeLookupId(Long typeLookupId) {
        this.typeLookupId = typeLookupId;
    }

    public FcLookup getSubTypeLookupId() {
        return subTypeLookupId;
    }

    public void setSubTypeLookupId(FcLookup subTypeLookupId) {
        this.subTypeLookupId = subTypeLookupId;
    }

}
