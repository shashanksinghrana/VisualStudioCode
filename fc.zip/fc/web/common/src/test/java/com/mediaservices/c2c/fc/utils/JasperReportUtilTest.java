package com.mediaservices.c2c.fc.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.core.io.ClassPathResource;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.test.MockitoTest;

public class JasperReportUtilTest extends MockitoTest {

    @Test(enabled = false)
    public void testGetReport() throws SQLException, IOException {
        final Map<String, Object> data = new HashMap<>();
        final Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "APP_FC", "c0nn#appFC");
        final InputStream jasperTemplate = new ClassPathResource("jasper/I9StatusReport/I-9Status_main.jrxml")
                .getInputStream();
        final byte[] response = JasperReportUtil.getReport("pdf", jasperTemplate, con, data);
        Assert.assertNotNull(response);
    }
}
