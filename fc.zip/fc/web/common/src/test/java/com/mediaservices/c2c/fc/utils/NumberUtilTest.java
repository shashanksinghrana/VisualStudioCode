package com.mediaservices.c2c.fc.utils;

import org.mockito.InjectMocks;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.test.MockitoTest;

public class NumberUtilTest extends MockitoTest {

    @InjectMocks
    NumberUtil testee;


    @Test
    public void testStringToLong() {
        final Long response = testee.stringToLong("1");
        Assert.assertNotNull(response);
    }

    @Test
    public void testStringToLongNull() {
        final Long response = testee.stringToLong(null);
        Assert.assertNull(response);
    }

    @Test
    public void testLongToString() {
        final String response = testee.longToString(1l);
        Assert.assertEquals("1", response);
    }

    @Test
    public void testLongToStringNull() {
        final String response = testee.longToString(null);
        Assert.assertNull(response);
    }

    @Test
    public void testConvertNumberToWordNumberZero() {
        final String response = testee.convertNumberToWord(0);
        Assert.assertEquals("Zero", response);
    }

    @Test
    public void testConvertNumberToWordNumberModLessThenTwenty() {
        final String response = testee.convertNumberToWord(1000);
        Assert.assertEquals("Ten Hundred", response);
    }

    @Test
    public void testConvertNumberToWordNumberModMoreThenTwenty() {
        final String response = testee.convertNumberToWord(120);
        Assert.assertEquals("One Hundred Twenty", response);
    }
}
