package com.mediaservices.c2c.fc.utils;

import static org.mockito.Mockito.when;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.thymeleaf.ITemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.mediaservices.c2c.fc.test.MockitoTest;

public class HtmlToPdfUtilTest extends MockitoTest {

    @InjectMocks
    HtmlToPdfUtil testee;

    @Mock
    ITemplateEngine templateEngine;

    @Mock
    ITextRenderer renderer;

    @Test
    public void testGeneratePdf() {
        final Context context = new Context();
        // template should have 'data' element
        context.setVariable("data", new Object());

        when(templateEngine.process("test", context)).thenReturn("test");

        final byte[] response = testee.generatePdf("test", "test");
        Assert.assertNotNull(response);
    }
}
