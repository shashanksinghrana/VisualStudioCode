package com.mediaservices.c2c.fc.exporter;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.mockito.InjectMocks;
import org.springframework.core.io.ClassPathResource;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.exporter.impl.PdfExport;
import com.mediaservices.c2c.fc.test.MockitoTest;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

/**
 * The Class PdfExportTest.
 */
public class PdfExportTest extends MockitoTest {

    /** The export. */
    @InjectMocks
    private PdfExport export;

    /**
     * Test export.
     *
     * @throws SQLException
     *             the SQL exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws JRException
     *             the JR exception
     */
    @Test(enabled = false)
    public void testExport() throws SQLException, IOException, JRException {
        final Map<String, Object> data = new HashMap<>();
        final Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "APP_FC", "c0nn#appFC");
        final InputStream jasperTemplate = new ClassPathResource("jasper/I9StatusReport/I-9Status_main.jrxml")
                .getInputStream();
        final JasperReport report = JasperCompileManager.compileReport(jasperTemplate);
        final JasperPrint jasperPrint = JasperFillManager.fillReport(report, data, con);
        final byte[] response = export.export(jasperPrint);
        Assert.assertNotNull(response);
    }

    /**
     * Test export throws file not found exception.
     *
     * @throws SQLException
     *             the SQL exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws JRException
     *             the JR exception
     */
    @Test(expectedExceptions = FileNotFoundException.class, enabled = false)
    public void testExportThrowsFileNotFoundException() throws SQLException, IOException, JRException {
        final Map<String, Object> data = new HashMap<>();
        final Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "APP_FC", "c0nn#appFC");
        final InputStream jasperTemplate = new ClassPathResource("jasper/I9StatusReport/I-9Status_mainUnavailable.jrxml")
                .getInputStream();
        final JasperReport report = JasperCompileManager.compileReport(jasperTemplate);
        final JasperPrint jasperPrint = JasperFillManager.fillReport(report, data, con);
        export.export(jasperPrint);
    }

    /**
     * Test export null.
     *
     * @throws SQLException
     *             the SQL exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws JRException
     *             the JR exception
     */
    @Test
    public void testExportNull() throws SQLException, IOException, JRException {
        final byte[] response = export.export(null);
        Assert.assertNull(response);
    }

}
