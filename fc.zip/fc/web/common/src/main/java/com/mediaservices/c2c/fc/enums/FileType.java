package com.mediaservices.c2c.fc.enums;

public enum FileType {
    PDF, WORD, EXCEL;
}
