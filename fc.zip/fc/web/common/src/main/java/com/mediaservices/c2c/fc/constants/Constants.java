package com.mediaservices.c2c.fc.constants;

/**
 * Class containing constants for Feature Casting Application.
 *
 * @author lstaley
 *
 */
public class Constants {

    // Lookups
    public static final String SHARED_LOOKUP_TYPE_STUDIO = "STUDIO";
    public static final String DYNAMIC_ATTRIBUTE_TYPE_PROJECT_STATUS = "PROJECT_STATUS";
    public static final String DYNAMIC_ATTRIBUTE_TYPE_PROJECT_TYPE = "PROJECT_TYPE";
    public static final String LOOKUP_TYPE_NAME_UNION = "UNION";
    public static final String SHARED_LOOKUP_TYPES = "STUDIO,PROJECT_STATUS,PROJECT_TYPE,ROLLCALL_DATASET";
    public static final String ROLLCALL_LOOKUP_TYPES = "PROD_COMPANY";
    public static final String USER_STUDIOS_LOOKUP = "USER_STUDIOS";
    // Security/access
    public static final String APPLICATION_NAME = "Feature Casting";

    // Roles
    public static final String USER_ROLE_FC_ADMIN = "Feature Casting Administrator";
    public static final String USER_ROLE_FC_OWNER = "Feature Casting Owner";
    public static final String USER_ROLE_FC_GUEST = "Feature Casting Guest";

    // Note types
    public static final String NOTE_TYPE_UNION = "UNION";
    public static final String NOTE_TYPE_PROJECT = "PROJECT";

    // Wizard Types
    public static final String WIZARD_TYPE_STATUS = "STATUS";
    public static final String WIZARD_TYPE_CONFIG = "CONFIG";

    // Wizard Page
    public static final String WIZARD_PAGE_LOANOUT = "Loanout";
    public static final String WIZARD_PAGE_NOTICES = "Notices & Payments";

    // Credit Page
    public static final String MAIN_TITLE = "MainTitle";
    public static final String END_TITLE = "EndTitle";

    public static final String LOOKUP_TYPE_WIZARD_INDICATOR = "WIZARD_INDICATOR";

    // Record Defaults
    public static final int DEFAULT_RECORD_COUNT = 25;

}
