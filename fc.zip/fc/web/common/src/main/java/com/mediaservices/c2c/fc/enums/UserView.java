package com.mediaservices.c2c.fc.enums;

/**
 * Defines the UserRoles recognized by the system.
 */
public enum UserView {

    /** The view role. */
    VIEW,
    /** The edit role. */
    EDIT,
    /** The user admin role. */
    USER_ADMIN;

}
