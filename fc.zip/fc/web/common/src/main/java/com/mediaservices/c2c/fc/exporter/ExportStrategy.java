package com.mediaservices.c2c.fc.exporter;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;

/**
 * The Class ExportStrategy.
 */
public class ExportStrategy {

    /**
     * Execute report.
     *
     * @param export
     *            the export
     * @param print
     *            the print
     * @return the byte array output stream
     * @throws JRException
     */
    public byte[] executeReport(Export export, JasperPrint print) throws JRException {
        return export.export(print);
    }
}
