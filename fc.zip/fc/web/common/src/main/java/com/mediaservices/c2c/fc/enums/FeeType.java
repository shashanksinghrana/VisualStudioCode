package com.mediaservices.c2c.fc.enums;

/**
 * The Enum FeeType.
 */
public enum FeeType {

	/** The test. */
	TEST,
	/** The sag daily scale. */
	SAG_DAILY_SCALE;
}
