package com.mediaservices.c2c.fc.exporter.impl;

import java.io.ByteArrayOutputStream;

import com.itextpdf.text.pdf.PdfWriter;
import com.mediaservices.c2c.fc.exporter.Export;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;

/**
 * The Class PdfExport.
 */
public class PdfExport implements Export {

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.fc.exporter.Export#export(net.sf.jasperreports.
     * engine.JasperPrint)
     */
    @Override
    public byte[] export(JasperPrint jasperPrint) throws JRException {
        ByteArrayOutputStream outputStream = null;
        if (null != jasperPrint) {
            outputStream = new ByteArrayOutputStream();
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputStream));
            SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
            configuration.setPermissions(PdfWriter.ALLOW_COPY | PdfWriter.ALLOW_PRINTING);
            exporter.setConfiguration(configuration);
            exporter.exportReport();
        }
        return null != outputStream ? outputStream.toByteArray() : null;
    }

}
