package com.mediaservices.c2c.fc.execption;

import java.util.Optional;

import com.mediaservices.c2c.fc.enums.ErrorCode;

/**
 * Base class for all application related exception.
 *
 */
public class FcApplicationException extends RuntimeException {

    /** For serialization. */
    private static final long serialVersionUID = -3838987348527735362L;

    /** Error code. */
    private final ErrorCode errorCode;

    private final String field;

    /**
     * @return the field
     */
    public String getField() {
        return field;
    }

    /**
     * Constructor to set error message.
     *
     * @param message
     *            - error message
     * @param errorCode
     *            - error error code
     */
    public FcApplicationException(final String message, final ErrorCode errorCode) {
        super(message);
        this.errorCode = errorCode;
        this.field = null;
    }

    /**
     * Instantiates a new fc application exception.
     *
     * @param message
     *            the message
     * @param errorCode
     *            the error code
     * @param field
     *            the field
     */
    public FcApplicationException(final String message, final ErrorCode errorCode, String field) {
        super(message);
        this.errorCode = Optional.ofNullable(errorCode).orElse(ErrorCode.INTERNAL_SERVER_ERROR);
        this.field = field;
    }

    /**
     * Constructor to set error message and <code>Throwable</code> instance.
     *
     * @param message
     *            - error message
     * @param exception
     *            - <code>Throwable</code> instance
     */
    public FcApplicationException(final String message, final Throwable exception) {
        super(message, exception);
        this.errorCode = ErrorCode.INTERNAL_SERVER_ERROR;
        this.field = null;
    }

    /**
     * Constructor to set error message and <code>Throwable</code> instance.
     *
     * @param message
     *            - error message
     * @param exception
     *            - <code>Throwable</code> instance
     * @param errorCode
     *            - error error code
     */
    public FcApplicationException(final String message, final Throwable exception, final ErrorCode errorCode) {
        super(message, exception);
        this.errorCode = errorCode;
        this.field = null;
    }

    /**
     * Return the error code.
     *
     * @return the errorCodeInvalidArgumentException.java
     */
    public ErrorCode getErrorCode() {
        return errorCode;
    }

}
