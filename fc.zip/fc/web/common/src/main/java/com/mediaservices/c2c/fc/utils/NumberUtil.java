package com.mediaservices.c2c.fc.utils;

/**
 * The Class NumberUtil.
 */
public class NumberUtil {

    /** The Constant tensNames. */
    private static final String[] tensNames = { "", " Ten", " Twenty", " Thirty", " Forty", " Fifty", " Sixty",
            " Seventy", " Eighty", " Ninety" };

    /** The Constant numNames. */
    private static final String[] numNames = { "", " One", " Two", " Three", " Four", " Five", " Six", " Seven",
            " Eight", " Nine", " Ten", " Eleven", " Twelve", " Thirteen", " Fourteen", " Fifteen", " Sixteen",
            " Seventeen", " Eighteen", " Nineteen" };

    /**
     * String to long.
     *
     * @param value
     *            the value
     * @return the long
     */
    public static Long stringToLong(String value) {
        if (value != null) {
            return Long.valueOf(value);
        }
        return null;
    }

    /**
     * Long to string.
     *
     * @param value
     *            the value
     * @return the string
     */
    public static String longToString(Long value) {
        if (value != null) {
            return Long.toString(value);
        }
        return null;
    }

    /**
     * Convert less than one thousand.
     *
     * @param number
     *            the number
     * @return the string
     */
    private static String convertLessThanOneThousand(int number) {
        String soFar;
        if (number % 100 < 20) {
            soFar = numNames[number % 100];
            number /= 100;
        } else {
            soFar = numNames[number % 10];
            number /= 10;

            soFar = tensNames[number % 10] + soFar;
            number /= 10;
        }
        if (number == 0) {
            return soFar;
        }
        return numNames[number] + " Hundred" + soFar;
    }

    /**
     * Convert.
     *
     * @param number
     *            the number
     * @return the string
     */
    public static String convertNumberToWord(int number) {
        if (number == 0) {
            return "Zero";
        }
        String word;
        word = convertLessThanOneThousand(number);

        // remove extra spaces!
        return word.replaceAll("^\\s+", "").replaceAll("\\b\\s{2,}\\b", " ");
    }
}
