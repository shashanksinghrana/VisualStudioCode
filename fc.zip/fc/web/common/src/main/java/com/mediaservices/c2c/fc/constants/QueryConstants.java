package com.mediaservices.c2c.fc.constants;

public class QueryConstants {
    public static final String DYNAMIC_ATTRIBUTE_VALUE_BY_ATTRIBUTE_TYPE_AND_MODULE = "select * from DBO_MP.DYNAMIC_ATTRIBUTE_VALUES v where v.DYNAMIC_ATTRIBUTE_ID = (select a.DYNAMIC_ATTRIBUTE_ID from DBO_MP.DYNAMIC_ATTRIBUTE a INNER JOIN DBO_MP.DEPARTMENT d ON a.DYNAMIC_ATTRIBUTE_DEPARTMENT=d.DEPARTMENT_ID INNER JOIN DBO_MP.LOOKUP l ON l.LOOKUP_ID=:studioId AND l.LOOKUP_NAME=d.DEPARTMENT_NAME  where a.DYNAMIC_ATTRIBUTE_TYPE = :type and a.DYNAMIC_ATTRIBUTE_MODULE = :module )";
    public static final String DYNAMIC_ATTRIBUTE_VALUE_BY_ATTRIBUTE_TYPE = "select * from DBO_MP.DYNAMIC_ATTRIBUTE_VALUES v where v.DYNAMIC_ATTRIBUTE_ID in (select a.DYNAMIC_ATTRIBUTE_ID from DBO_MP.DYNAMIC_ATTRIBUTE a where a.DYNAMIC_ATTRIBUTE_TYPE = :type)";

    public static final String ADMIN_CODES_BY_STUDIO_AND_TYPE = "SELECT ac.* FROM DBO_FC.FC_ADMIN_CODES ac where ac.DISABLED_FLAG='N' AND ac.STUDIO_LOOKUP_ID = :studioId AND ac.LOOKUP_ID in (SELECT l.ID FROM DBO_FC.FC_LOOKUP l WHERE l.TYPE = :type)";

    public static final String USER_ID_BY_USER_ID_AND_ACTIVE_IND = "select USER_ID from USERS where ACTIVE_IND = 'Y' and UPPER(user_id) =:userId";
    public static final String USER_BY_USER_ID = "select * from DBO_MP.USERS where  UPPER(user_id) = UPPER(:userId)";
    public static final String STUDIO_BY_USER_ID_AND_MODULE = "SELECT studio.* FROM DBO_MP.LOOKUP studio INNER JOIN module_access ma ON studio.LOOKUP_ID = ma.STUDIO_ID INNER JOIN DBO_MP.LOOKUP_TYPE lt ON studio.LOOKUP_TYPE_ID = lt.LOOKUP_TYPE_ID AND lt.LOOKUP_TYPE_NAME = 'STUDIO' INNER JOIN DBO_MP.LOOKUP lm ON lm.LOOKUP_ID = ma.MODULE_ID INNER JOIN DBO_MP.LOOKUP_TYPE ltm ON lm.LOOKUP_TYPE_ID     = ltm.LOOKUP_TYPE_ID AND ltm.LOOKUP_TYPE_NAME = 'DEFAULT_TAB' AND lm.lookup_name =:module AND ma.user_id =:userId";
    public static final String USERS_BY_USER_ROLE_LIST = "select user from User user where user.isActive = 'Y' and user.userRole.roleName in :userRoleList";
    public static final String ADMIN_SHARED_LOOKUP_BY_TYPE_AND_MODULE = "select new AdminSharedLookup(admn.adminSharedLookupId, admn.sharedLookupId, lk) from AdminSharedLookup admn inner join admn.sharedLookup as lk where admn.module = :module and admn.typeLookup.name = :type";
    public static final String ADMIN_SHARED_LOOKUP_BY_TYPE = "select new AdminSharedLookup(admn.adminSharedLookupId, admn.sharedLookupId, lk)  from AdminSharedLookup admn inner join admn.sharedLookup as lk  where admn.typeLookup.name = :type";

    public static final String ADMIN_DYNAMIC_ATTRIBUTE_VALUES_BY_TYPE_AND_MODULE = "SELECT admn.*, va.* FROM DBO_FC.FC_DYNAMIC_ATTRIBUTE_VALS_ADMN admn INNER JOIN DBO_MP.DYNAMIC_ATTRIBUTE_VALUES va ON admn.DYNAMIC_ATTRIBUTE_VALUES_ID  = va.DYNAMIC_ATTRIBUTE_VALUES_ID WHERE admn.DYNAMIC_ATTRIBUTE_VALUES_ID IN (SELECT va.DYNAMIC_ATTRIBUTE_VALUES_ID FROM DBO_MP.DYNAMIC_ATTRIBUTE_VALUES val WHERE va.DYNAMIC_ATTRIBUTE_ID IN (SELECT  att.DYNAMIC_ATTRIBUTE_ID FROM DBO_MP.DYNAMIC_ATTRIBUTE att WHERE att.DYNAMIC_ATTRIBUTE_MODULE = :module )) and admn.TYPE_LOOKUP_ID in (select up.ID from DBO_FC.FC_LOOKUP up where up.NAME = :type)";
    public static final String ADMIN_DYNAMIC_ATTRIBUTE_VALUES_BY_TYPE = "SELECT admn.*, va.* FROM DBO_FC.FC_DYNAMIC_ATTRIBUTE_VALS_ADMN admn INNER JOIN DBO_MP.DYNAMIC_ATTRIBUTE_VALUES va ON admn.DYNAMIC_ATTRIBUTE_VALUES_ID = va.DYNAMIC_ATTRIBUTE_VALUES_ID WHERE admn.TYPE_LOOKUP_ID in(select up.ID from DBO_FC.FC_LOOKUP up where up.NAME=:type) order by va.ATTRIBUTE_DISP_VAL";

    public static final String WIZARD_CONFIG_BY_STUDIO_AND_FORM_AND_TYPE = "select *from DBO_FC.FC_WIZARD_CONFIG wz where wz.TYPE_LOOKUP_ID in (select ty.ID from DBO_FC.FC_LOOKUP ty where ty.NAME = :type) and wz.FORM_LOOKUP_ID in (select fm.ID from DBO_FC.FC_LOOKUP fm where fm.NAME = :formType) and WZ.STUDIO_LOOKUP_ID=:studioId";
    public static final String WIZARD_CONFIG_BY_FORM_AND_TYPE = "select * from DBO_FC.FC_WIZARD_CONFIG wz where wz.TYPE_LOOKUP_ID in (select ty.ID from DBO_FC.FC_LOOKUP ty where ty.NAME = :type) and wz.FORM_LOOKUP_ID in (select fm.ID from DBO_FC.FC_LOOKUP fm where fm.NAME = :formType)";

    public static final String FORMULAS_BY_PAGE_AND_DEAL_TYPE = "select * from DBO_FC.FC_FORMULA  fm inner join DBO_FC.FC_LOOKUP lk on fm.DEAL_TYPE_LOOKUP_ID = lk.id and lk.NAME = :dealType inner join DBO_FC.FC_LOOKUP l on fm.TYPE_LOOKUP_ID = l.ID and l.NAME = :pageType";
    public static final String FORMULAS_BY_PAGE_AND_DEAL_TYPE_AND_STUDIO_ID = "SELECT * FROM DBO_FC.FC_FORMULA fm JOIN DBO_MP.LOOKUP studio ON fm.STUDIO_LOOKUP_ID = studio.LOOKUP_ID AND studio.LOOKUP_ID   =:studioId JOIN DBO_FC.FC_LOOKUP page ON fm.TYPE_LOOKUP_ID =page.ID AND page.NAME =:pageType JOIN DBO_FC.FC_LOOKUP dealType ON fm.DEAL_TYPE_LOOKUP_ID =dealType.ID AND dealType.NAME =:dealType";
    public static final String FORMULAS_BY_PAGE_AND_DEAL_TYPE_AND_FEE_TYPE_AND_STUDIO_ID = "SELECT * FROM DBO_FC.FC_FORMULA fm JOIN DBO_MP.LOOKUP studio ON fm.STUDIO_LOOKUP_ID = studio.LOOKUP_ID AND studio.LOOKUP_ID   =:studioId JOIN DBO_FC.FC_LOOKUP page ON fm.TYPE_LOOKUP_ID =page.ID AND page.name =:pageType JOIN DBO_FC.FC_LOOKUP dealType ON fm.DEAL_TYPE_LOOKUP_ID =dealType.ID AND dealType.NAME =:dealType JOIN DBO_FC.FC_LOOKUP feeType ON fm.SUB_TYPE_LOOKUP_ID = feeType.ID AND feeType.ID =:feeTypeId";
    public static final String FORMULAS_BY_PAGE_AND_DEAL_TYPE_AND_FEE_TYPE = "SELECT * FROM DBO_FC.FC_FORMULA fm JOIN DBO_FC.FC_LOOKUP page ON fm.TYPE_LOOKUP_ID =page.ID AND page.NAME =:pageType JOIN DBO_FC.FC_LOOKUP dealType ON fm.DEAL_TYPE_LOOKUP_ID =dealType.ID AND dealType.NAME =:dealType JOIN DBO_FC.FC_LOOKUP feeType ON fm.SUB_TYPE_LOOKUP_ID = feeType.ID AND feeType.ID =:feeTypeId";

    public static final String PROJECT_TITLE_BY_SEARCH_TERM = "select * from DBO_MP.PROJECT_TITLE where ( lower(convert(TITLE, 'ZHT16MSWIN950')) like convert(CONCAT(CONCAT('%',lower( :searchTerm )),'%'),'ZHT16MSWIN950' ) escape '\\')  ORDER BY CASE WHEN LOWER(TITLE) LIKE convert(LOWER(CONCAT(:searchTerm, '%')),'ZHT16MSWIN950' ) escape '\\' THEN TITLE ELSE NULL END ASC";
    public static final String USER_ID_BY_USER_LOGIN_ID = "select user_id from user_login where user_login_id=:userLoginId";

    public static final String DISTINCT_PERFORMER_ROLE_BY_SEARCH_TERM = " SELECT DISTINCT d.PERFORMER_ROLE FROM  DBO_FC.FC_DEAL d WHERE D.IS_ACTIVE = 'Y' AND LOWER(d.PERFORMER_ROLE) LIKE LOWER(CONCAT(CONCAT('%', :searchTerm), '%')) ORDER BY CASE WHEN LOWER(d.PERFORMER_ROLE) LIKE LOWER(CONCAT(:searchTerm, '%')) THEN d.PERFORMER_ROLE ELSE NULL END ASC ";

    public static final String STUDIO_WITH_MODULE_NAME = "select l.* from lookup l inner join DBO_MP.LOOKUP_TYPE lt on l.LOOKUP_TYPE_ID = lt.LOOKUP_TYPE_ID and lt.LOOKUP_TYPE_NAME = 'DEFAULT_TAB' and l.LOOKUP_NAME =:lookupName";

    public static final String GET_MASTER_DATASET_ID = "SELECT app.VALUE FROM lookup l INNER JOIN DBO_MP.LOOKUP_TYPE lt ON l.LOOKUP_TYPE_ID     = lt.LOOKUP_TYPE_ID AND lt.LOOKUP_TYPE_NAME = 'FEATURE_NAME' AND l.LOOKUP_NAME       ='Master Dataset' inner join APP_FEATURE_SETTING app on l.LOOKUP_ID = app.feature_id";

    public static final String PERFORMER_NAME_BY_AKA_IDs = "SELECT d.ID,p.FIRST_NAME,p.LAST_NAME,p.IS_CURRENT FROM PARTY_AKA p INNER JOIN FC_DEAL d ON p.ID = d.PERFORMER_AKA_ID AND d.ID IN (:dealIds) ORDER BY p.LAST_NAME ASC";

    public static final String PERFORMER_CURRENT_NAMEs = "SELECT d.ID, p.AKA_NAME FROM PARTY_AKA p INNER JOIN FC_DEAL d ON p.PARTY_ID = d.PERFORMER_PARTY_ID AND p.IS_CURRENT = 'Y' AND d.ID IN (:dealIds) ORDER BY p.LAST_NAME ASC";
}
