package com.mediaservices.c2c.fc.exporter.impl;

import java.io.ByteArrayOutputStream;

import com.mediaservices.c2c.fc.exporter.Export;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

/**
 * The Class ExcelExport.
 */
public class ExcelExport implements Export {

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.fc.exporter.Export#export(net.sf.jasperreports.
     * engine.JasperPrint)
     */
    @Override
    public byte[] export(JasperPrint jasperPrint) throws JRException {
        ByteArrayOutputStream outputStream = null;
        if (null != jasperPrint) {
            outputStream = new ByteArrayOutputStream();
            JRXlsxExporter exporter = new JRXlsxExporter();
            SimpleXlsxReportConfiguration reportConfig = new SimpleXlsxReportConfiguration();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputStream));
            reportConfig.setRemoveEmptySpaceBetweenRows(true);
            reportConfig.setOnePagePerSheet(false);
            reportConfig.setWhitePageBackground(false);
            reportConfig.setDetectCellType(true);
            exporter.setConfiguration(reportConfig);
            exporter.exportReport();

        }
        return null != outputStream ? outputStream.toByteArray() : null;
    }

}
