package com.mediaservices.c2c.fc.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.StringTemplateResolver;
import org.w3c.tidy.Tidy;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.itextpdf.text.DocumentException;
import com.mediaservices.c2c.fc.execption.FcApplicationException;

/**
 * The Class HtmlToPdfUtil.
 */
@Component
public class HtmlToPdfUtil {
    /** The Constant UTF_8. */
    private static final String UTF_8 = "UTF-8";

    /**
     * Generate pdf.
     *
     * @param data
     *            the data
     * @param template
     *            the template
     * @return the byte[]
     */
    public byte[] generatePdf(Object data, String template) {
        TemplateEngine templateEngine = new TemplateEngine();
        StringTemplateResolver templateResolver = new StringTemplateResolver();
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateEngine.setTemplateResolver(templateResolver);

        Context context = new Context();
        // template should have 'data' element
        context.setVariable("data", data);
        String html = templateEngine.process(template, context);
        String xHtml = convertToXhtml(html);

        ITextRenderer renderer = new ITextRenderer();
        renderer.setDocumentFromString(xHtml);
        renderer.layout();

        // And finally, we create the PDF:
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            renderer.createPDF(outputStream);
        } catch (DocumentException | IOException e) {
            throw new FcApplicationException(e.getLocalizedMessage(), e);
        }
        return outputStream.toByteArray();
    }

    /**
     * Convert to xhtml.
     *
     * @param html
     *            the html
     * @return the string
     */
    private String convertToXhtml(String html) {
        String xhtmlRepresentation = null;
        Tidy tidy = new Tidy();
        tidy.setInputEncoding(UTF_8);
        tidy.setOutputEncoding(UTF_8);
        tidy.setXHTML(true);
        tidy.setEncloseText(false);
        tidy.setEscapeCdata(false);
        ByteArrayInputStream inputStream = null;
        try {
            inputStream = new ByteArrayInputStream(html.getBytes(UTF_8));
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            tidy.parseDOM(inputStream, outputStream);
            xhtmlRepresentation = outputStream.toString(UTF_8).replace("&amp;nbsp;", "&nbsp;");
            xhtmlRepresentation = xhtmlRepresentation.replace("&lt;br/&gt;", "<br/>");
            Matcher matcher = Pattern.compile("[\\000]*").matcher(xhtmlRepresentation);
            if (matcher.find()) {
                xhtmlRepresentation = matcher.replaceAll("");
            }
        } catch (UnsupportedEncodingException e) {
            throw new FcApplicationException(e.getLocalizedMessage(), e);
        }

        return xhtmlRepresentation;
    }
}
