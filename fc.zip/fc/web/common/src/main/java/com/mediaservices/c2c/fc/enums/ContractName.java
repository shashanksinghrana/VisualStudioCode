package com.mediaservices.c2c.fc.enums;

/**
 * The Enum ContractName.
 */
public enum ContractName {

    /** The employment of a day performer. */
    EMPLOYMENT_OF_A_DAY_PERFORMER,

    /** The loanout of a day performer. */
    LOANOUT_OF_A_DAY_PERFORMER,

    /** The minimum freelance contract. */
    MINIMUM_FREELANCE_CONTRACT;
}
