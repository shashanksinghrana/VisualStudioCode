package com.mediaservices.c2c.fc.enums;

/**
 * The Enum ReportType.
 */
public enum ReportType {

    /** The i9 status. */
    I9_STATUS("I9-Status-"),

    /** The missing birthdate. */
    MISSING_BIRTHDATE("Missing-birthdate-"),

    /** The contract status. */
    CONTRACT_STATUS("contract-status-"),

    /** The post sync time log. */
    POST_SYNC_TIME_LOG("post-sync-time-log-"),

    /** The station12. */
    STATION12("station12-"),

    /** The billing list. */
    BILLING_LIST("billing-list-"),

    /** The cast list. */
    CAST_LIST("cast-list-"),

    /** The blank contract. */
    BLANK_CONTRACT("blank-contract-"),

    /** The crew list. */
    CREW_LIST("crew-list-worksheet-"),

    /** The talent voucher. */
    TALENT_VOUCHER("talent-voucher"),

    CASTING_DATA("casting-data-");

    /** The file name. */
    private String fileName;

    /**
     * Instantiates a new report type.
     *
     * @param fileName
     *            the file name
     */
    private ReportType(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Gets the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }
}
