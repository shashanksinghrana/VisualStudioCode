package com.mediaservices.c2c.fc.utils;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Map;

import com.mediaservices.c2c.fc.enums.ErrorCode;
import com.mediaservices.c2c.fc.enums.FileType;
import com.mediaservices.c2c.fc.execption.FcApplicationException;
import com.mediaservices.c2c.fc.exporter.ExportStrategy;
import com.mediaservices.c2c.fc.exporter.impl.ExcelExport;
import com.mediaservices.c2c.fc.exporter.impl.PdfExport;
import com.mediaservices.c2c.fc.exporter.impl.WordExport;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

/**
 * The Class JasperReportUtil.
 */
public class JasperReportUtil {

    /** The export strategy. */
    private static ExportStrategy exportStrategy = new ExportStrategy();

    /**
     * Gets the report.
     *
     * @param reportType
     *            the report type
     * @param jasperTemplate
     *            the jasper template
     * @param con
     *            the con
     * @param data
     *            the data
     * @return the report
     */
    public static byte[] getReport(final String reportType, final InputStream jasperTemplate, final Connection con,
            final Map<String, Object> data) {
        byte[] response = null;
        try {
            JasperReport report = JasperCompileManager.compileReport(jasperTemplate);
            JasperPrint jasperPrint = JasperFillManager.fillReport(report, data, con);
            if (reportType.equalsIgnoreCase(FileType.PDF.name())) {
                response = exportStrategy.executeReport(new PdfExport(), jasperPrint);
            } else if (reportType.equalsIgnoreCase(FileType.WORD.name())) {
                response = exportStrategy.executeReport(new WordExport(), jasperPrint);
            } else if (reportType.equalsIgnoreCase(FileType.EXCEL.name())) {
                response = exportStrategy.executeReport(new ExcelExport(), jasperPrint);
            }
        } catch (JRException e) {
            throw new FcApplicationException("Jasper report engine failed", e, ErrorCode.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
}
