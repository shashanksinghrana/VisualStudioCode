package com.mediaservices.c2c.fc.enums;

public enum ReportPath {
    I9StatusXlsxReport("jasper/I9StatusReport/I-9Status_main_Excel.jrxml"), I9StatusReport(
            "jasper/I9StatusReport/I-9Status_main.jrxml");

    private String path;

    private ReportPath(String path) {
        this.path = path;
    }

    /**
     * @return the path
     */
    public String getPath() {
        return path;
    }
}
