package com.mediaservices.c2c.fc.exporter;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;

/**
 * The Interface Export.
 */
public interface Export {

    /**
     * Export.
     *
     * @param jasperPrint
     *            the jasper print
     * @return the byte array output stream
     * @throws JRException
     */
    public byte[] export(JasperPrint jasperPrint) throws JRException;
}
