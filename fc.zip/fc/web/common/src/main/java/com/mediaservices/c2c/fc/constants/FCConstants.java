package com.mediaservices.c2c.fc.constants;

public class FCConstants {

    public static final String MODULE_FEATURE_CASTING = "Feature Casting";

    private FCConstants() {

    }

}
