package com.mediaservices.c2c.fc.execption;

import java.util.List;
import java.util.stream.Collectors;

import com.mediaservices.c2c.fc.enums.ErrorCode;
import com.mediaservices.c2c.talent.error.dto.ErrorDetailDto;

/**
 * The Class InvalidArgumentException.
 */
public class InvalidArgumentException extends FcApplicationException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8373289620748405203L;

    /** The errors. */
    private final List<ErrorDetailDto> errors;

    /**
     * Gets the errors.
     *
     * @return the errors
     */
    public List<ErrorDetailDto> getErrors() {
        return errors;
    }

    /**
     * Instantiates a new invalid argument exception.
     *
     * @param errors
     *            the errors
     */
    public InvalidArgumentException(List<ErrorDetailDto> errors, String field) {
        super(errors.stream().map(ErrorDetailDto::getDetail).collect(Collectors.joining(", ")),
                ErrorCode.SSN_ALREADY_EXIST, field);
        this.errors = errors;
    }

}
