package com.mediaservices.c2c.fc.exporter.impl;

import java.io.ByteArrayOutputStream;

import com.mediaservices.c2c.fc.exporter.Export;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;

/**
 * The Class WordExport.
 */
public class WordExport implements Export {

    /*
     * (non-Javadoc)
     *
     * @see
     * com.mediaservices.c2c.fc.exporter.Export#export(net.sf.jasperreports.
     * engine.JasperPrint)
     */
    @Override
    public byte[] export(JasperPrint jasperPrint) throws JRException {
        ByteArrayOutputStream outputStream = null;
        if (null != jasperPrint) {
            outputStream = new ByteArrayOutputStream();
            JRDocxExporter exporter = new JRDocxExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputStream));
            exporter.exportReport();
        }
        return null != outputStream ? outputStream.toByteArray() : null;
    }
}
