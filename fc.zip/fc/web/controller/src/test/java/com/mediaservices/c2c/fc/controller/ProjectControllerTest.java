package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.CoreMatchers.any;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.Resources;

import com.mediaservices.c2c.fc.dto.AllProjectDto;
import com.mediaservices.c2c.fc.dto.AllProjectsGridSearchCriteria;
import com.mediaservices.c2c.fc.dto.BillingDto;
import com.mediaservices.c2c.fc.dto.CrewDto;
import com.mediaservices.c2c.fc.dto.CrewRequestDto;
import com.mediaservices.c2c.fc.dto.LocationPeriodDto;
import com.mediaservices.c2c.fc.dto.LookupDto;
import com.mediaservices.c2c.fc.dto.ProjectDetailsDto;
import com.mediaservices.c2c.fc.dto.ProjectDto;
import com.mediaservices.c2c.fc.dto.ProjectStatusDateDto;
import com.mediaservices.c2c.fc.dto.WorkPeriodDto;
import com.mediaservices.c2c.fc.hateoas.AllProjectResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.ProjectDetailsResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.ProjectResourceAssembler;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.ProjectService;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;
import com.mediaservices.c2c.talent.dto.TypeAheadNameDto;

// TODO: Auto-generated Javadoc
/**
 * The Class ProjectControllerTest.
 */
public class ProjectControllerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private ProjectController testee;

    /** The project service. */
    @Mock
    private ProjectService projectService;

    /** The resource assembler. */
    @Mock
    private ProjectResourceAssembler resourceAssembler;

    @Mock
    private AllProjectResourceAssembler allProjectResourceAssembler;

    @Mock
    private ProjectDetailsResourceAssembler projectDetailsAssembler;

    /** The page assembler. */
    @Mock
    private PagedResourcesAssembler<ProjectDto> pageAssembler;

    /** The paged resources. */
    @Mock
    private PagedResources<ProjectDto> pagedResources;

    @Mock
    private PagedResourcesAssembler<AllProjectDto> allProjectAssembler;

    @Mock
    AuthorizationService authorizationService;

    @Override
    @Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    /** The Constant RANDOM. */
    private static final Random RANDOM = new Random();

    /**
     * Gets the party page.
     *
     * @return the party page
     */
    @Test
    public void testGetProjectPage() {
        // given
        final List<ProjectDto> projectList = new ArrayList<>();
        final Page<ProjectDto> projects = new PageImpl<>(projectList);

        final Pageable pageable = PageRequest.of(1, 20);

        when(projectService.getProjectsPage(pageable)).thenReturn(projects);

        when(pageAssembler.toResource(projects, resourceAssembler)).thenReturn(pagedResources);

        // when
        final PagedResources<ProjectDto> output = testee.getProjectPage(pageable);

        // then
        assertThat(output, is(pagedResources));

    }

    /**
     * Gets the party.
     *
     * @return the party
     */
    @Test
    public void testGetProject() {
        // given
        final Long id = RANDOM.nextLong();
        final ProjectDto project = new ProjectDto();
        when(projectService.getProjectById(id)).thenReturn(project);

        final ProjectDto resourcedProject = new ProjectDto();
        when(resourceAssembler.toResource(project)).thenReturn(resourcedProject);

        // when
        final ProjectDto output = testee.getProject(id);

        // then
        assertThat(output, is(resourcedProject));

    }

    @Test
    public void testGetProjectDetails() {
        // given
        final Long id = RANDOM.nextLong();
        final ProjectDetailsDto project = new ProjectDetailsDto();
        when(projectService.getProjectDetailsById(id)).thenReturn(project);

        final ProjectDetailsDto resourcedProject = new ProjectDetailsDto();
        when(projectDetailsAssembler.toResource(project)).thenReturn(resourcedProject);

        // when
        final ProjectDetailsDto output = testee.getProjectDetails(id);

        // then
        assertThat(output, is(resourcedProject));
    }

    @Test
    public void testAllProjects() {
        // given
        final Pageable pageable = PageRequest.of(1, 20);
        final List<AllProjectDto> projects = new ArrayList<>();
        final List<AllProjectDto> resourcedProjects = new ArrayList<>();
        final AllProjectDto project1 = new AllProjectDto();
        final AllProjectDto project2 = new AllProjectDto();
        resourcedProjects.add(project1);
        resourcedProjects.add(project2);

        when(projectService.getAllProjects()).thenReturn(projects);

        when(allProjectResourceAssembler.toResources(projects)).thenReturn(resourcedProjects);

        // when

        final Resources<AllProjectDto> output = testee.getAllProjects(pageable, new AllProjectsGridSearchCriteria());

        assertNull(output);
    }

    @Test
    public void getBillingsTest() {
        final BillingDto billingDto = new BillingDto();
        final List<BillingDto> billingList = new ArrayList<>();
        final Long projectId = RANDOM.nextLong();
        billingList.add(billingDto);
        when(testee.getBillings(projectId)).thenReturn(billingList);
        final List<BillingDto> output = testee.getBillings(projectId);

        assertThat(billingList, is(output));
    }

    @Test
    public void saveBillingsTest() {
        final BillingDto billingDto = new BillingDto();
        when(testee.saveBilling(billingDto)).thenReturn(billingDto);
        final BillingDto output = testee.saveBilling(billingDto);

        assertThat(billingDto, is(output));

    }

    @Test
    public void getBillingAttachmentTest() {
        when(projectService.getBillingAttachment(Mockito.anyLong())).thenReturn(new byte[100]);
        final byte[] output = testee.getBillingAttachment(1l);

        assertNotNull(output);
    }

    @Test
    public void getProjectStatusDateTest() {
        final List<ProjectStatusDateDto> statusDtoList = new ArrayList<>();
        final Long projectId = RANDOM.nextLong();
        when(testee.getStatusDates(projectId)).thenReturn(statusDtoList);
        final List<ProjectStatusDateDto> output = testee.getStatusDates(projectId);

        assertThat(output, is(statusDtoList));

    }

    @Test
    public void saveProjectStatusDateTest() {

        final ProjectStatusDateDto statusDto = new ProjectStatusDateDto();
        final Long projectId = RANDOM.nextLong();
        when(testee.saveStatusDates(statusDto, projectId)).thenReturn(new ProjectStatusDateDto());
        final ProjectStatusDateDto output = testee.saveStatusDates(statusDto, projectId);

        assertThat(output, any(ProjectStatusDateDto.class));

    }

    @Test
    public void deleteProjectStatusDateTest() {
        final Long id = RANDOM.nextLong();
        doNothing().when(projectService).deleteProjectStatusDates(id);
        testee.deleteStatusDatesById(id);

        verify(projectService).deleteProjectStatusDates(id);

    }

    @Test
    public void testGetMyProjects() {
        // given
        final Pageable pageable = PageRequest.of(1, 20);
        final List<AllProjectDto> projects = new ArrayList<>();
        final List<AllProjectDto> resourcedProjects = new ArrayList<>();
        final AllProjectDto project1 = new AllProjectDto();
        final AllProjectDto project2 = new AllProjectDto();
        resourcedProjects.add(project1);
        resourcedProjects.add(project2);

        when(projectService.getAllProjects()).thenReturn(projects);

        when(allProjectResourceAssembler.toResources(projects)).thenReturn(resourcedProjects);


        final Resources<AllProjectDto> output = testee.getMyProjects(pageable, new AllProjectsGridSearchCriteria());

        assertNull(output);
    }

    @Test
    public void testCreateProject() {
        final ProjectDto projectDto = new ProjectDto();
        final ProjectDto resourcedProjectDto = new ProjectDto();
        resourcedProjectDto.add(new ArrayList<Link>());
        when(resourceAssembler.toResource(new ProjectDto())).thenReturn(projectDto);
        when(projectService.createProject(projectDto)).thenReturn(resourcedProjectDto);
        final ProjectDto output = testee.createProject(projectDto);
        assertNotNull(output);

    }

    @Test
    public void testUpdateProject() {
        final ProjectDto projectDto = new ProjectDto();
        final ProjectDto resourcedProjectDto = new ProjectDto();
        resourcedProjectDto.add(new ArrayList<Link>());
        when(resourceAssembler.toResource(new ProjectDto())).thenReturn(projectDto);
        when(projectService.updateProject(projectDto)).thenReturn(resourcedProjectDto);
        final ProjectDto output = testee.updateProject(projectDto);
        assertNotNull(output);

    }

    @Test
    public void testGetProductionCompany() {
        final List<TypeAheadNameDto> typeAheadNameDtos = new ArrayList<>();

        final TypeAheadNameDto typeAheadNameDto = new TypeAheadNameDto();

        typeAheadNameDtos.add(typeAheadNameDto);

        when(projectService.getProductionCompany(Mockito.any())).thenReturn(typeAheadNameDtos);

        final List<TypeAheadNameDto> output = testee.getProductionCompany(Mockito.any());
        assertNotNull(output);
    }

    @Test
    public void testGetUnion() {
        final List<LookupDto> lookupDtos = new ArrayList<>();

        final LookupDto lookupDto = new LookupDto();

        lookupDtos.add(lookupDto);

        when(projectService.getUnion(Mockito.any(), Mockito.any())).thenReturn(lookupDtos);

        final List<LookupDto> output = testee.getUnion(Mockito.any(), Mockito.any());
        assertNotNull(output);
    }

    @Test
    public void testGetCrewByProjectId() {
        final List<CrewDto> crewDtos = new ArrayList<>();

        final CrewDto crewDto = new CrewDto();

        crewDtos.add(crewDto);

        when(projectService.getCrewByProjectId(Mockito.any())).thenReturn(crewDtos);

        final List<CrewDto> output = testee.getCrewByProjectId(Mockito.any());
        assertNotNull(output);
    }

    @Test
    public void testGetLocationsByProjectId() {
        final List<LocationPeriodDto> locationPeriodDtos = new ArrayList<>();

        final LocationPeriodDto locationPeriodDto = new LocationPeriodDto();

        locationPeriodDtos.add(locationPeriodDto);

        when(projectService.getLocationByProjectId(Mockito.any())).thenReturn(locationPeriodDtos);

        final List<LocationPeriodDto> output = testee.getLocationsByProjectId(Mockito.any());
        assertNotNull(output);
    }

    @Test
    public void testSaveCrewByProjectId() {

        when(projectService.saveCrewByProjectId(Mockito.any(), Mockito.any())).thenReturn(new CrewRequestDto());
        final CrewRequestDto output = testee.saveCrewByProjectId(Mockito.any(), Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testSaveLocationsByProjectId() {

        when(projectService.saveLocationPeriodsByProjectId(Mockito.any(), Mockito.any())).thenReturn(new ArrayList<>());
        final List<LocationPeriodDto> output = testee.saveLocationsByProjectId(Mockito.any(), Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testEditLocationsByProjectId() {

        when(projectService.editLocationPeriodByProjectId(Mockito.any(), Mockito.any()))
        .thenReturn(new LocationPeriodDto());
        final LocationPeriodDto output = testee.editLocationsByProjectId(Mockito.any(), Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetProjectWorkWeeks() {
        final List<WorkPeriodDto> workPeriodDtos = new ArrayList<>();

        final WorkPeriodDto workPeriodDto = new WorkPeriodDto();

        workPeriodDtos.add(workPeriodDto);

        when(projectService.getProjectWorkWeeks(Mockito.any())).thenReturn(workPeriodDtos);

        final List<WorkPeriodDto> output = testee.getProjectWorkWeeks(Mockito.any());
        assertNotNull(output);
    }

    @Test
    public void testSaveProjectWorkWeek() {

        when(projectService.saveProjectWorkWeek(Mockito.any())).thenReturn(new WorkPeriodDto());
        final WorkPeriodDto output = testee.saveProjectWorkWeek(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testDeleteProjectWorkWeekbyId() {

        testee.deleteProjectWorkWeekbyId(Mockito.any());

        Mockito.verify(projectService, Mockito.atLeastOnce()).deleteProjectWorkWeekbyId(Mockito.any());
    }

    @Test
    public void getProjectWorkWeeksTest() {
        List<WorkPeriodDto> workPeriodDtoList = new ArrayList<>();
        Long projectId = RANDOM.nextLong();
        when(testee.getProjectWorkWeeks(projectId)).thenReturn(workPeriodDtoList);
        List<WorkPeriodDto> output = testee.getProjectWorkWeeks(projectId);

        assertThat(output, is(workPeriodDtoList));

    }

    @Test
    public void saveProjectWorkWeekTest() {

        WorkPeriodDto workWeekDto = new WorkPeriodDto();
        when(testee.saveProjectWorkWeek(workWeekDto)).thenReturn(new WorkPeriodDto());
        WorkPeriodDto output = testee.saveProjectWorkWeek(workWeekDto);

        assertThat(output, any(WorkPeriodDto.class));

    }

    @Test
    public void deleteProjectWorkWeekbyIdTest() {
        Long id = RANDOM.nextLong();
        doNothing().when(projectService).deleteProjectWorkWeekbyId(id);
        testee.deleteProjectWorkWeekbyId(id);

        verify(projectService).deleteProjectWorkWeekbyId(id);

    }
}
