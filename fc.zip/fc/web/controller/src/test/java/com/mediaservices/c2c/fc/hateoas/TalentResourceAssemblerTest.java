package com.mediaservices.c2c.fc.hateoas;

import static org.testng.Assert.assertNotNull;

import org.mockito.InjectMocks;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.LoanoutDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

public class TalentResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private TalentResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        final LoanoutDto dto = new LoanoutDto();

        // when
        final LoanoutDto output = testee.toResource(dto);

        assertNotNull(output);
    }
}
