package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resources;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.FcUser;
import com.mediaservices.c2c.fc.dto.UserDto;
import com.mediaservices.c2c.fc.hateoas.UserResourceAssembler;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.UserService;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

/**
 * The Class UserControllerTest.
 */
public class UserControllerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private UserController testee;

    /** The user service. */
    @Mock
    private UserService userService;

    /** The resource assembler. */
    @Mock
    private UserResourceAssembler resourceAssembler;

    @Mock
    private AuthorizationService authorizationService;

    /** The Constant RANDOM. */
    private static final Random RANDOM = new Random();

    @Test
    public void testGetUser() {
        // given
        when(authorizationService.getLoggedInUser())
        .thenReturn(new FcUser("test", "test", true, true, true, true, new ArrayList<>()));

        testee.getUser();
        Mockito.verify(authorizationService, Mockito.atLeastOnce()).getLoggedInUser();
    }

    @Test
    public void testGetAssignedToUsers() {
        // given
        final Set<UserDto> users = new HashSet<>();
        final UserDto dto1 = new UserDto();
        final UserDto dto2 = new UserDto();
        final List<UserDto> resourcedUsers = new ArrayList<>();
        resourcedUsers.add(dto2);
        resourcedUsers.add(dto1);

        when(userService.getUsersByRoles(any(List.class))).thenReturn(users);
        when(resourceAssembler.toResources(users)).thenReturn(resourcedUsers);

        // when
        final Resources<UserDto> output = testee.getAssignedToUsers();

        // then
        assertThat(output.getContent(), is(iterableWithSize(2)));
        assertThat(output.getContent(), containsInAnyOrder(dto1, dto2));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/assignedToUsers"));
    }

}
