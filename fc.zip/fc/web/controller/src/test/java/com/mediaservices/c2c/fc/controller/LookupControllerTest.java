package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;

import com.mediaservices.c2c.elasticsearch.enums.TypeaheadFilterType;
import com.mediaservices.c2c.fc.dto.LookupDto;
import com.mediaservices.c2c.fc.dto.RoleTypeAheadDto;
import com.mediaservices.c2c.fc.dto.SignatoryUserDto;
import com.mediaservices.c2c.fc.hateoas.LookupResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.SignatoryUserResourceAssembler;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.LookupService;
import com.mediaservices.c2c.fc.service.TalentService;
import com.mediaservices.c2c.talent.dto.AccentedCharacterSet;
import com.mediaservices.c2c.talent.dto.PicklistsDTO;
import com.mediaservices.c2c.talent.dto.SystemPropValueDTO;
import com.mediaservices.c2c.talent.dto.TypeAheadNameDto;
import com.mediaservices.c2c.talent.service.CommonService;

@RunWith(MockitoJUnitRunner.class)
public class LookupControllerTest {

    /** The testee. */
    @InjectMocks
    private LookupController testee;

    /** The lookup service. */
    @Mock
    private LookupService lookupService;

    @Mock
    private TalentService talentService;

    @Mock
    CommonService commonService;

    /** The resource assembler. */
    @Mock
    private LookupResourceAssembler resourceAssembler;

    @Mock
    private SignatoryUserResourceAssembler signatoryUserAssembler;

    /** The page assembler. */
    @Mock
    private PagedResourcesAssembler<LookupDto> pageAssembler;

    /** The paged resources. */
    @Mock
    private PagedResources<LookupDto> pagedResources;

    /** The Constant RANDOM. */
    private static final Random RANDOM = new Random();

    @Mock
    private AuthorizationService authorizationService;
    /**
     * Gets the lookup page.
     *
     * @return the lookup page
     */
    @Test
    public void getLookupPage() {
        // given
        final List<LookupDto> lookupList = new ArrayList<>();
        final Page<LookupDto> lookups = new PageImpl<>(lookupList);

        final Pageable pageable = PageRequest.of(1, 20);

        when(lookupService.getLookupsPage(pageable)).thenReturn(lookups);

        when(pageAssembler.toResource(lookups, resourceAssembler)).thenReturn(pagedResources);

        // when
        final PagedResources<LookupDto> output = testee.getLookupPage(pageable);

        // then
        assertThat(output, is(pagedResources));

    }

    /**
     * Gets the lookup.
     *
     * @return the lookup
     */
    @Test
    public void getLookup() {
        // given
        final Long id = RANDOM.nextLong();
        final LookupDto lookup = new LookupDto();
        when(lookupService.getLookupById(id)).thenReturn(lookup);

        final LookupDto resourcedLookup = new LookupDto();
        when(resourceAssembler.toResource(lookup)).thenReturn(resourcedLookup);

        // when
        final LookupDto output = testee.getLookup(id);

        // then
        assertThat(output, is(resourcedLookup));

    }

    /**
     * Gets all lookups by type
     */
    @Test
    public void getLookupsByType() {
        // given
        final String type = UUID.randomUUID().toString();
        final List<LookupDto> lookups = new ArrayList<>();
        final List<LookupDto> resourcedLookups = new ArrayList<>();
        final LookupDto lookup1 = new LookupDto();
        final LookupDto lookup2 = new LookupDto();
        resourcedLookups.add(lookup1);
        resourcedLookups.add(lookup2);

        when(lookupService.getLookupsByType(type, 123L, null)).thenReturn(lookups);

        when(resourceAssembler.toResources(lookups)).thenReturn(resourcedLookups);

        // when
        final List<LookupDto> output = testee.getLookupsByType(type, 123L, null);

        // then
        assertThat(output, hasSize(2));
        assertThat(output, containsInAnyOrder(lookup1, lookup2));
        assertThat(output, is(resourcedLookups));
    }

    @Test
    public void testGetRolesTypeAhead() {
        final List<RoleTypeAheadDto> roleTypeAhead = new ArrayList<>();
        when(lookupService.getAllRoles(Mockito.anyString(), Mockito.anyInt()))
        .thenReturn(new ArrayList<RoleTypeAheadDto>());
        final List<RoleTypeAheadDto> output = testee.getRoles(Mockito.anyString(), Mockito.anyInt());
        assertThat(output, is(roleTypeAhead));
        assertThat(output, hasSize(Matchers.lessThanOrEqualTo(10)));
    }

    @Test
    public void testGetLookupsByPickList() {
        final PicklistsDTO dto = new PicklistsDTO();
        dto.setPicklists(new HashMap<>());
        dto.getPicklists().put("1", new ArrayList<>());
        when(commonService.getPickListsBasedOnTypes(Mockito.anyString())).thenReturn(dto);
        final List<SystemPropValueDTO> output = testee.getLookupsByPickList("1");
        assertNotNull(output);
    }

    @Test
    public void testGetStudioForLoggedInUser() {
        when(authorizationService.getLoggedInUserId()).thenReturn("test");
        final List<LookupDto> output = testee.getStudioForLoggedInUser();
        assertNotNull(output);
    }

    @Test
    public void testGetSignatoryUsers() {
        when(lookupService.getSignatoryUsers()).thenReturn(new ArrayList<>());
        when(signatoryUserAssembler.toResources(Mockito.any())).thenReturn(new ArrayList<>());
        final List<SignatoryUserDto> output = testee.getSignatoryUsers();
        assertNotNull(output);
    }

    @Test
    public void testGetSignatoryUser() {
        when(lookupService.getSignatoryUserById(Mockito.anyLong())).thenReturn(new SignatoryUserDto());
        when(signatoryUserAssembler.toResources(Mockito.any())).thenReturn(new ArrayList<>());
        final SignatoryUserDto output = testee.getSignatoryUser(Mockito.anyLong());
        Mockito.verify(lookupService, Mockito.atLeastOnce()).getSignatoryUserById(Mockito.any());
    }

    @Test
    public void testGetRepName() {
        when(lookupService.getTypeAheadNames("1", TypeaheadFilterType.CONTACT_ONLY, 10))
        .thenReturn(new ArrayList<>());
        final List<TypeAheadNameDto> output = testee.getRepName("1", 10);
        assertNotNull(output);
    }

    @Test
    public void testGetCompanyName() {
        when(lookupService.getTypeAheadNames("1", TypeaheadFilterType.COMPANY_ONLY, 10))
        .thenReturn(new ArrayList<>());
        final List<TypeAheadNameDto> output = testee.getCompanyName("1", 10);
        assertNotNull(output);
    }

    @Test
    public void testGetAccentedChars() {
        when(talentService.getAccentedChars(Mockito.anyString())).thenReturn(new AccentedCharacterSet());
        final AccentedCharacterSet output = testee.getAccentedChars("123");
        assertNotNull(output);
    }

    @Test
    public void testGetPickListValues() {
        when(commonService.getPickListsBasedOnStudio(Mockito.anyLong(), Mockito.anyString()))
        .thenReturn(new PicklistsDTO());
        final PicklistsDTO output = testee.getPickListValues(Mockito.anyString(), Mockito.anyLong());
        assertNotNull(output);
    }

    @Test
    public void testGetPickLists() {
        when(commonService.getPickListsFromType(Mockito.anyString()))
        .thenReturn(new com.mediaservices.c2c.rollcall.dto.PicklistsDTO());
        final com.mediaservices.c2c.rollcall.dto.PicklistsDTO output = testee.getPickLists(Mockito.anyString());
        assertNotNull(output);
    }
}
