package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resources;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.ProjectTitleDto;
import com.mediaservices.c2c.fc.hateoas.ProjectTitleResourceAssembler;
import com.mediaservices.c2c.fc.service.ProjectTitleService;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

/**
 * The Class ProjectTitleControllerTest.
 */
public class ProjectTitleControllerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private ProjectTitleController testee;

    /** The projectTitle service. */
    @Mock
    private ProjectTitleService projectTitleService;

    /** The resource assembler. */
    @Mock
    private ProjectTitleResourceAssembler resourceAssembler;

    /** The Constant RANDOM. */
    private static final Random RANDOM = new Random();

    @Test
    public void testGetProjectTitle() {
        final Long id = RANDOM.nextLong();
        final ProjectTitleDto projectTitle = new ProjectTitleDto();
        final ProjectTitleDto resourcedTitle = new ProjectTitleDto();
        when(projectTitleService.getProjectTitleById(id)).thenReturn(projectTitle);
        when(resourceAssembler.toResource(projectTitle)).thenReturn(resourcedTitle);

        // when
        final ProjectTitleDto output = testee.getProjectTitle(id);

        // then
        assertThat(output, is(resourcedTitle));
    }

    @Test
    public void testGetProjectAkasByProject() {
        final List<ProjectTitleDto> projectTitle = new ArrayList<>();
        projectTitle.add(new ProjectTitleDto());
        when(projectTitleService.getProjectAkasByProjectId(Mockito.anyLong())).thenReturn(projectTitle);

        // when
        final Resources<ProjectTitleDto> output = testee.getProjectAkasByProject(13l);

        assertNotNull(output);
    }

    @Test
    public void testGetProjectTitleTypeAhead() {
        // given
        final String searchTerm = "term";
        final int recordCount = 3;
        final List<ProjectTitleDto> titles = new ArrayList<>();
        final List<ProjectTitleDto> resourcedTitles = new ArrayList<>();
        final ProjectTitleDto dto1 = new ProjectTitleDto();
        final ProjectTitleDto dto2 = new ProjectTitleDto();
        final ProjectTitleDto dto3 = new ProjectTitleDto();
        resourcedTitles.add(dto3);
        resourcedTitles.add(dto2);
        resourcedTitles.add(dto1);

        when(projectTitleService.getProjectTitles(searchTerm, recordCount)).thenReturn(titles);
        when(resourceAssembler.toResources(titles)).thenReturn(resourcedTitles);

        // when
        final Resources<ProjectTitleDto> output = testee.getProjectTitleTypeAhead("term", recordCount);
        assertThat(output.getContent(), is(iterableWithSize(3)));
        assertThat(output.getContent(), containsInAnyOrder(dto1, dto2, dto3));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/typeAhead/projectTitles"));
    }

}
