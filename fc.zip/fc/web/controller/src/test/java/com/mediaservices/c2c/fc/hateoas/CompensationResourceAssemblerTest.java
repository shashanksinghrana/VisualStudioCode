package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.CompensationDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

/**
 * The Class CompensationResourceAssemblerTest.
 */
public class CompensationResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private CompensationResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        CompensationDto compensation = new CompensationDto();
        compensation.setCompensationId("2");

        // when
        CompensationDto output = testee.toResource(compensation);

        // then
        assertThat(output, is(compensation));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/compensation/2"));

    }
}
