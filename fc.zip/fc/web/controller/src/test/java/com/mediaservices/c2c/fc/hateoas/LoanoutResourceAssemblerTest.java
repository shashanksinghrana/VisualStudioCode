package com.mediaservices.c2c.fc.hateoas;

import static org.testng.Assert.assertNotNull;

import org.mockito.InjectMocks;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.LoanoutDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

public class LoanoutResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private LoanoutResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        final LoanoutDto loanoutDto = new LoanoutDto();
        loanoutDto.setDealId(1l);

        // when
        final LoanoutDto output = testee.toResource(loanoutDto);

        assertNotNull(output);
    }
}
