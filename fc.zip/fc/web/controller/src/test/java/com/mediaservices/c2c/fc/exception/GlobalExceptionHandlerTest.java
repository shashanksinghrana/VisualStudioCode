package com.mediaservices.c2c.fc.exception;

import javax.servlet.http.HttpServletRequest;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.enums.ErrorCode;
import com.mediaservices.c2c.fc.error.dto.ErrorResponseDto;
import com.mediaservices.c2c.fc.execption.FcApplicationException;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

/**
 * The Class GlobalExceptionHandlerTest.
 */
public class GlobalExceptionHandlerTest extends MockitoTestWithRequestContext {

    /** The mock. */
    @InjectMocks
    GlobalExceptionHandler mock;

    @Mock
    HttpServletRequest request;
    /**
     * Test exception handler.
     */
    @Test
    public void testExceptionHandler() {
        final ErrorResponseDto error = mock.exceptionHandler(new Exception("Test"),
                request);
        Assert.assertNotNull(error);
    }

    /**
     * Test feature casting application exception handler.
     */
    @Test
    public void testFCApplicationExceptionHandler() {
        final ErrorResponseDto error = mock.FCApplicationExceptionHandler(
                new FcApplicationException("Test", ErrorCode.INTERNAL_SERVER_ERROR),
                request);
        Assert.assertNotNull(error);
    }

    @Test
    public void testHandleHttpMessageNotReadableException() {
        final ErrorResponseDto error = mock.handleHttpMessageNotReadableException(
                new HttpMessageNotReadableException("NOT readable HttpMessageNotReadableException"),
                request);
        Assert.assertNotNull(error);
    }
}
