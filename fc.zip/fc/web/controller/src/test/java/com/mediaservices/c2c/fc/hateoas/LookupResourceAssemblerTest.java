package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.LookupDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

// TODO: Auto-generated Javadoc
/**
 * The Class LookupResourceAssemblerTest.
 */
public class LookupResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private LookupResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        LookupDto lookup = new LookupDto();
        lookup.setLookupId(123l);

        // when
        LookupDto output = testee.toResource(lookup);

        // then
        assertThat(output, is(lookup));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/lookup/123"));

    }
}
