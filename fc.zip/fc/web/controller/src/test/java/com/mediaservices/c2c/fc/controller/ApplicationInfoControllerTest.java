package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.ApplicationInfoDto;
import com.mediaservices.c2c.fc.hateoas.ApplicationInfoResourceAssembler;
import com.mediaservices.c2c.fc.service.ApplicationInfoService;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

// TODO: Auto-generated Javadoc
/**
 * The Class LookupControllerTest.
 */
public class ApplicationInfoControllerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private ApplicationInfoController testee;

    /** The lookup service. */
    @Mock
    private ApplicationInfoService applicationInfoService;

    /** The resource assembler. */
    @Mock
    private ApplicationInfoResourceAssembler resourceAssembler;

    /**
     * Gets the lookup.
     *
     * @return the lookup
     */
    @Test
    public void getLookup() {
        // given
        ApplicationInfoDto appInfo = new ApplicationInfoDto();
        appInfo.setVersionNumber("1.1.5");
        when(applicationInfoService.getVersionInfo()).thenReturn(appInfo);

        ApplicationInfoDto resourcedAppInfo = new ApplicationInfoDto();
        resourcedAppInfo.setVersionNumber("1.1.5");
        when(resourceAssembler.toResource(appInfo)).thenReturn(resourcedAppInfo);

        // when
        ApplicationInfoDto output = testee.getVersionInfo();

        // then
        assertThat(output, is(resourcedAppInfo));
        assertThat(output.getVersionNumber(), is(appInfo.getVersionNumber()));

    }
}
