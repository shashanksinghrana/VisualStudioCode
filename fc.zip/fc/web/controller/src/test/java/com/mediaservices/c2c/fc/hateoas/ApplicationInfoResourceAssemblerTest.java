package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.ApplicationInfoDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

// TODO: Auto-generated Javadoc
/**
 * The Class ApplicationInfoResourceAssemblerTest.
 */
public class ApplicationInfoResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private ApplicationInfoResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        ApplicationInfoDto lookup = new ApplicationInfoDto();

        // when
        ApplicationInfoDto output = testee.toResource(lookup);

        // then
        assertThat(output, is(lookup));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/versionInfo"));

    }
}
