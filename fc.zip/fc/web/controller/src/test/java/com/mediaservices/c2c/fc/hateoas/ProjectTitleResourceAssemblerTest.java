package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.ProjectTitleDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

/**
 * The Class ProjectTitleResourceAssemblerTest2.
 */
public class ProjectTitleResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private ProjectTitleResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        ProjectTitleDto projectTitle = new ProjectTitleDto();
        projectTitle.setProjectTitleId(3L);

        // when
        ProjectTitleDto output = testee.toResource(projectTitle);

        // then
        assertThat(output, is(projectTitle));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/projectTitle/3"));

    }
}
