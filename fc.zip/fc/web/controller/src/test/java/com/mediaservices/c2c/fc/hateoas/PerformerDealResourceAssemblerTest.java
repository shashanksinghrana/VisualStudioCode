package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.PerformerDealDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

// TODO: Auto-generated Javadoc
/**
 * The Class PerformerDealResourceAssemblerTest.
 */
public class PerformerDealResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private PerformerDealResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        PerformerDealDto deal = new PerformerDealDto();
        deal.setDealId(23L);

        // when
        PerformerDealDto output = testee.toResource(deal);

        // then
        assertThat(output, is(deal));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/performerDeal/23"));

    }
}
