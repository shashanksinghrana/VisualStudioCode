package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.AllProjectDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

// TODO: Auto-generated Javadoc
/**
 * The Class AllProjectResourceAssemblerTest.
 */
public class AllProjectResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private AllProjectResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        AllProjectDto project = new AllProjectDto();
        project.setProjectId(23L);

        // when
        AllProjectDto output = testee.toResource(project);

        // then
        assertThat(output, is(project));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/project/23"));

    }
}
