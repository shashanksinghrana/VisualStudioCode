package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.DealDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

/**
 * The Class DealResourceAssemblerTest.
 */
public class DealResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private DealResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        DealDto deal = new DealDto();
        deal.setDealId(12L);

        // when
        DealDto output = testee.toResource(deal);

        // then
        assertThat(output, is(deal));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/deal/12"));

    }
}
