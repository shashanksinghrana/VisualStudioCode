package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.UserDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

// TODO: Auto-generated Javadoc
/**
 * The Class PerformerDealResourceAssemblerTest.
 */
public class UserResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private UserResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        UserDto deal = new UserDto();
        deal.setUserId("user1");

        // when
        UserDto output = testee.toResource(deal);

        // then
        assertThat(output, is(deal));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("http://localhost/api/user"));

    }
}
