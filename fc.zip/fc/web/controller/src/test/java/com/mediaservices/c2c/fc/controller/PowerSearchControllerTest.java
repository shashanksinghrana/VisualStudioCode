package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.mediaservices.c2c.fc.dto.PageContent;
import com.mediaservices.c2c.fc.dto.PowerSearchCriteriaDto;
import com.mediaservices.c2c.fc.dto.PowerSearchDto;
import com.mediaservices.c2c.fc.dto.SavedSearchQueryDto;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.PowerSearchService;

public class PowerSearchControllerTest {

    @InjectMocks
    private PowerSearchController testee;

    @Mock
    private AuthorizationService authorizationService;

    @Mock
    private PowerSearchService powerSearchService;

    @Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    /** The Constant RANDOM. */
    private static final Random RANDOM = new Random();

    @Test
    public void testGetSavedSearchListByUser() {
        final List<SavedSearchQueryDto> savedSearchList = new ArrayList<>();
        when(authorizationService.getLoggedInUserId()).thenReturn(new String());
        final String userId = authorizationService.getLoggedInUserId();
        when(powerSearchService.getSavedSearchListByUser(userId)).thenReturn(new ArrayList<SavedSearchQueryDto>());
        final List<SavedSearchQueryDto> output = testee.getSavedSearchesByUser();

        assertThat(output, is(savedSearchList));

    }

    @Test
    public void testSaveSearchQuery() {
        final SavedSearchQueryDto savedSearch = new SavedSearchQueryDto();
        when(powerSearchService.saveSearchQuery(savedSearch)).thenReturn(savedSearch);
        final SavedSearchQueryDto output = testee.createSavedSearch(savedSearch);

        assertThat(output, is(savedSearch));
    }

    @Test
    public void testDeleteSavedSearch() {
        final Long queryId = RANDOM.nextLong();
        doNothing().when(powerSearchService).deleteSavedSearch(queryId);
        testee.deleteSavedSearch(queryId);

        verify(powerSearchService).deleteSavedSearch(queryId);
    }

    @Test
    public void testGetSavedSearchByQueryId() {
        final Long queryId = RANDOM.nextLong();
        final SavedSearchQueryDto savedSearchDto = new SavedSearchQueryDto();
        when(powerSearchService.getSavedSearchByQueryId(queryId)).thenReturn(savedSearchDto);

        final SavedSearchQueryDto output = testee.getSavedSearchByQueryId(queryId);

        assertThat(output, is(savedSearchDto));
    }

    @Test
    public void testGetPowerSearch() {
        final Pageable pageable = new PageRequest(0, 1);
        when(powerSearchService.getPowerSearch(pageable, new PowerSearchCriteriaDto())).thenReturn(new PageContent<>());

        final PageContent<PowerSearchDto> output = testee.getPowerSearch(pageable, new PowerSearchCriteriaDto());

        assertNull(output);
    }
}
