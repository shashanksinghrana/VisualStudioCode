package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.WizardDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

/**
 * The Class WizardResourceAssemblerTest.
 */
public class WizardResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private WizardResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        WizardDto wizard = new WizardDto();
        wizard.setWizardId(43L);

        // when
        WizardDto output = testee.toResource(wizard);

        // then
        assertThat(output, is(wizard));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/wizard/43"));

    }
}
