package com.mediaservices.c2c.fc.hateoas;

import static org.testng.Assert.assertNotNull;

import org.mockito.InjectMocks;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.PerqDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

public class PerqResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private PerqResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        final PerqDto dto = new PerqDto();

        // when
        final PerqDto output = testee.toResource(dto);

        assertNotNull(output);
    }
}
