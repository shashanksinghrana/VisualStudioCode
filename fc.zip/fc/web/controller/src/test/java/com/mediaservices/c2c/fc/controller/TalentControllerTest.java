package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNull;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.hateoas.Resources;
import org.testng.annotations.Test;

import com.mediaservices.c2c.elasticsearch.dto.GlobalSearchResponseDto;
import com.mediaservices.c2c.elasticsearch.dto.TypeAheadNameSearchDto;
import com.mediaservices.c2c.fc.dto.LoanoutDto;
import com.mediaservices.c2c.fc.dto.PartyDto;
import com.mediaservices.c2c.fc.hateoas.PartyResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.TalentResourceAssembler;
import com.mediaservices.c2c.fc.service.PerformerService;
import com.mediaservices.c2c.fc.service.TalentService;
import com.mediaservices.c2c.fc.test.MockitoTest;
import com.mediaservices.c2c.rollcall.dto.CompanyCommonDto;
import com.mediaservices.c2c.rollcall.dto.PersonCommonDto;
import com.mediaservices.c2c.talent.dto.Party;
import com.mediaservices.c2c.talent.dto.PartyTypeAhead;
import com.mediaservices.c2c.talent.dto.Relation;
import com.mediaservices.c2c.talent.dto.Talent;
import com.mediaservices.c2c.talent.dto.TypeAheadNameDto;
import com.mediaservices.c2c.talent.dto.TypeAheadNameResponseDto;
import com.mediaservices.c2c.talent.enums.RelationType;
import com.mediaservices.c2c.talent.service.PartyService;
import com.mediaservices.c2c.talent.service.TypeAheadNameService;

public class TalentControllerTest extends MockitoTest {

    @InjectMocks
    private TalentController testee;

    @Mock
    private TalentService talentService;

    @Mock
    private PerformerService performerService;

    @Mock
    private PartyService partyService;

    @Mock
    private TypeAheadNameService typeAheadNameService;

    @Mock
    private TalentResourceAssembler talentResourceAssembler;

    @Mock
    private PartyResourceAssembler partyAssembler;

    private static final Random RANDOM = new Random();

    @Test
    public void testGetLoanOutCompanyTypeAhead() {
        final Long performerId = 1L;
        final List<LoanoutDto> parties = new ArrayList<>();
        final Set<LoanoutDto> partySet = new HashSet<>();
        final LoanoutDto loanout = new LoanoutDto();
        partySet.add(loanout);
        parties.add(loanout);

        when(talentService.getLoanoutCompanies(performerId)).thenReturn(parties);
        when(talentResourceAssembler.toResources(partySet)).thenReturn(parties);

        final Resources<LoanoutDto> output = testee.getLoanOutCompanyTypeAhead(performerId);
        assertThat(output.getContent(), hasItem(instanceOf(LoanoutDto.class)));
    }

    @Test
    public void testSaveTalentsLoanout() {

        final List<LoanoutDto> loanOutDtos = new ArrayList<>();

        when(talentService.updateLoanout(Mockito.anyLong(), Mockito.anyList())).thenReturn(loanOutDtos);
        final List<LoanoutDto> output = testee.saveTalentsLoanout(1L, loanOutDtos);

        assertNotNull(output);
    }

    @Test
    public void testGetPerformerAka() {


        when(performerService.getPerformer(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
        .thenReturn(new PartyDto());
        final PartyDto output = testee.getPerformer(1L, 1l, 1l);

        assertNull(output);
    }

    @Test
    public void testvalidatePerson() {
        testee.validatePerson(new Talent());
    }

    @Test
    public void testGetPerformer() {

        when(performerService.getPerformer(Mockito.any())).thenReturn(new PartyDto());
        when(partyAssembler.toResource(Mockito.any())).thenReturn(new PartyDto());
        final PartyDto output = testee.getPerformer(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetGlobalSearchData() {
        final TypeAheadNameSearchDto searchDto = new TypeAheadNameSearchDto();
        when(typeAheadNameService.getGlobalSearchResponse("test", searchDto))
        .thenReturn(new GlobalSearchResponseDto());
        final GlobalSearchResponseDto output = testee.getGlobalSearchData("test", searchDto);

        assertNotNull(output);
    }

    @Test
    public void testSaveRelation() {
        final Relation relation = new Relation();
        relation.setType(RelationType.REPRESENTITIVE);
        testee.saveRelation(relation);
    }

    @Test
    public void testDeleteRelation() {
        final Relation relation = new Relation();
        relation.setType(RelationType.REPRESENTITIVE);
        testee.deleteRelation(relation);
    }

    @Test
    public void testGetTalent() {

        when(talentService.getTalentDetails(Mockito.any())).thenReturn(new Talent());

        final Talent output = testee.getTalent(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetPerformerTypeAhead() {

        when(talentService.searchPerformers(Mockito.any(), Mockito.anyInt(), Mockito.any()))
        .thenReturn(new TypeAheadNameResponseDto());

        final List<TypeAheadNameDto> output = testee.getPerformerTypeAhead(Mockito.any(), Mockito.anyInt(),
                Mockito.any());

        assertNull(output);
    }

    @Test
    public void testSaveTalent() {

        when(talentService.saveTalent(Mockito.any())).thenReturn(new Talent());
        final Talent output = testee.saveTalent(new Talent());

        assertNotNull(output);
    }

    @Test
    public void testGetTalentImage() {

        final byte[] byteArray = new byte[10];

        RANDOM.nextBytes(byteArray);

        when(partyService.getTalentImage(Mockito.any())).thenReturn(byteArray);

        final byte[] output = testee.getTalentImage(Mockito.anyLong());

        assertNotNull(output);
    }

    @Test
    public void testAddTypeAheadName() {

        when(talentService.addTypeAheadName(Mockito.any())).thenReturn(new PartyTypeAhead());
        final PartyTypeAhead output = testee.addTypeAheadName(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testAddNameAsAlias() {

        final List<PartyTypeAhead> partyTypeAheadSet = new ArrayList<>();
        final List<PartyTypeAhead> partyTypeAheadList = new ArrayList<>();
        final PartyTypeAhead dto = new PartyTypeAhead();
        partyTypeAheadSet.add(dto);
        partyTypeAheadList.add(dto);

        when(talentService.addNameAsAlias(partyTypeAheadList)).thenReturn(dto);

        final PartyTypeAhead output = testee.addNameAsAlias(partyTypeAheadList);

        assertNotNull(output);
    }

    public void testGetTalentsContactCompany() {

        when(partyService.getTalentsContactCompany(Mockito.any())).thenReturn(new CompanyCommonDto());

        final CompanyCommonDto output = testee.getTalentsContactCompany(Mockito.any());

        assertNotNull(output);
    }

    /*public void testGetGlobalSearchData() {

		when(typeAheadNameService.getGlobalSearchResponse(Mockito.any(), Mockito.any()))
				.thenReturn(new GlobalSearchResponseDto());
		final GlobalSearchResponseDto output = testee.getGlobalSearchData(Mockito.any(), Mockito.any());
		assertNotNull(output);
	}*/

    /*@Test
	public void testSaveRelation() {

		when(partyService.saveRelation(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.anyLong(),
				Mockito.anyString())).thenReturn(null);
		testee.saveRelation(new Relation());
	}*/

    /*@Test
	public void testDeleteRelation() {

		testee.deleteRelation(new Relation());

		Mockito.verify(talentService, Mockito.atLeastOnce()).deleteRelation(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString());
	}*/

    @Test
    public void testSavePerson() {

        when(partyService.savePerson(Mockito.any(), Mockito.anyString())).thenReturn(new PersonCommonDto());
        final PersonCommonDto output = testee.savePerson(new PersonCommonDto());

        assertNotNull(output);
    }

    @Test
    public void testGetPersonsDetails() {

        when(partyService.getPersonDetails(Mockito.any())).thenReturn(new PersonCommonDto());

        final PersonCommonDto output = testee.getPersonsDetails(Mockito.anyLong());

        assertNotNull(output);
    }

    @Test
    public void testSaveRollcallPerson() {

        when(partyService.saveRollcallPerson(Mockito.any())).thenReturn(new PersonCommonDto());
        final PersonCommonDto output = testee.saveRollcallPerson(new PersonCommonDto());

        assertNotNull(output);
    }

    @Test
    public void testGetPartyDetails() {

        when(partyService.getPartyDetails(Mockito.any())).thenReturn(new Party() {
        });
        final Party output = testee.getPartyDetails(1L);

        assertNotNull(output);
    }

    @Test
    public void testGetAllNamesForParty() {
        final Long id = 1L;
        final List<PartyTypeAhead> partyTypeAheadList = new ArrayList<>();

        final PartyTypeAhead partyTypeAhead = new PartyTypeAhead();

        partyTypeAheadList.add(partyTypeAhead);

        when(typeAheadNameService.getAllNames(id)).thenReturn(partyTypeAheadList);

        final List<PartyTypeAhead> output = testee.getAllNamesForParty(id);
        assertNotNull(output);
    }

    /*@Test
	public void testGetPerformerTypeAhead() {
		final List<TypeAheadNameDto> typeAheadNameDtoList = new ArrayList<>();
		final TypeAheadNameResponseDto typeAheadNameResponseDto = new TypeAheadNameResponseDto();

		final TypeAheadNameDto typeAheadNameDto = new TypeAheadNameDto();

		typeAheadNameDtoList.add(typeAheadNameDto);

		when(talentService.searchPerformers(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
				.thenReturn(typeAheadNameResponseDto);
		//when(typeAheadNameResponseDto.getTypeAheadNames()).thenReturn(typeAheadNameDtoList);

		final List<TypeAheadNameDto> output = testee.getPerformerTypeAhead(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString());
		assertNotNull(output);
	}*/

    @Test
    public void testGetTypeAheadNames() {

        when(talentService.searchPerformers(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
        .thenReturn(new TypeAheadNameResponseDto());

        final TypeAheadNameResponseDto output = testee.getTypeAheadNames(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString());

        assertNotNull(output);
    }

    @Test
    public void testGetContextMetaData() {
        final List<String> contexts = new ArrayList<>();

        final String context = new String();

        contexts.add(context);

        when(typeAheadNameService.getContextMetaData(Mockito.any())).thenReturn(contexts);

        final List<String> output = testee.getContextMetaData(Mockito.any());
        assertNotNull(output);
    }
}
