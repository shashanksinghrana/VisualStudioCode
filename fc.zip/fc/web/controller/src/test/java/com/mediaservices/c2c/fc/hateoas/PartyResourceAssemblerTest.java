package com.mediaservices.c2c.fc.hateoas;

import static org.testng.Assert.assertNotNull;

import org.mockito.InjectMocks;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.PartyDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

public class PartyResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private PartyResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        final PartyDto partyDto = new PartyDto();
        partyDto.setAkaId(1l);

        // when
        final PartyDto output = testee.toResource(partyDto);

        assertNotNull(output);
    }
}
