package com.mediaservices.c2c.fc.exception;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.exception.ErrorTokenGenerator;
import com.mediaservices.c2c.fc.test.MockitoTest;

/**
 * The Class ErrorTokenGeneratorTest.
 */
public class ErrorTokenGeneratorTest extends MockitoTest {

    /**
     * Test get error id.
     */
    @Test
    public void testGetErrorId() {
        String result = ErrorTokenGenerator.getErrorId();
        Assert.assertNotNull(result);

    }

}
