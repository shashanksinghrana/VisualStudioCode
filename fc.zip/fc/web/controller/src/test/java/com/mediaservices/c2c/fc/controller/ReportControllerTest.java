package com.mediaservices.c2c.fc.controller;

import static org.testng.Assert.assertNull;

import java.util.HashMap;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.PowerSearchCriteriaDto;
import com.mediaservices.c2c.fc.service.ReportService;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

public class ReportControllerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private ReportController testee;

    @Mock
    private ReportService reportService;


    @Test
    public void testGetPowerSearchReport() {
        // when
        final ResponseEntity<byte[]> output = testee.getPowerSearchReport(new PowerSearchCriteriaDto(), "test", "test");

        assertNull(output);
    }

    @Test
    public void testGetReport() {
        // when
        final ResponseEntity<byte[]> output = testee.getReport(new HashMap<>());

        assertNull(output);
    }


}
