package com.mediaservices.c2c.fc.controller;

import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;
import com.mediaservices.c2c.rollcall.dto.CompanyCommonDto;
import com.mediaservices.c2c.rollcall.dto.CompanyLocationDto;
import com.mediaservices.c2c.rollcall.dto.CountriesDTO;
import com.mediaservices.c2c.rollcall.dto.PersonCommonDto;
import com.mediaservices.c2c.rollcall.dto.PicklistsDTO;
import com.mediaservices.c2c.rollcall.dto.StateDTO;
import com.mediaservices.c2c.rollcall.service.CompanyService;
import com.mediaservices.c2c.rollcall.service.PeopleService;
import com.mediaservices.c2c.rollcall.service.PicklistService;

public class RollcallControllerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private RollcallController testee;

    @Mock
    private PeopleService peopleService;

    /** The picklist service. */
    @Mock
    private PicklistService picklistService;

    /** The company service. */
    @Mock
    private CompanyService companyService;


    @Test
    public void testSaveContactPerson() {
        when(peopleService.savePerson(Mockito.any())).thenReturn(new PersonCommonDto());
        // when
        final PersonCommonDto output = testee.saveContactPerson(new PersonCommonDto());

        assertNotNull(output);
    }

    @Test
    public void testGetCountriesPickLists() {
        when(picklistService.getCountriesPickLists()).thenReturn(new CountriesDTO());
        // when
        final CountriesDTO output = testee.getCountriesPickLists();

        assertNotNull(output);
    }

    @Test
    public void testGetPickLists() {
        when(picklistService.getPickListsFromType(Mockito.anyString())).thenReturn(new PicklistsDTO());
        // when
        final PicklistsDTO output = testee.getPickLists("test");

        assertNotNull(output);
    }

    @Test
    public void testGetStatesPickLists() {
        when(picklistService.getStatesPickLists(Mockito.anyString())).thenReturn(new ArrayList<>());
        // when
        final List<StateDTO> output = testee.getStatesPickLists("test");

        assertNotNull(output);
    }

    @Test
    public void testGetCompanyDetail() {
        when(companyService.getCompanyDetail(Mockito.any())).thenReturn(new CompanyCommonDto());
        // when
        final CompanyCommonDto output = testee.getCompanyDetail(1l);

        assertNotNull(output);
    }

    @Test
    public void testAddOrEditCompany() {
        when(companyService.addOrEditCompany(Mockito.any())).thenReturn(new CompanyCommonDto());
        // when
        final CompanyCommonDto output = testee.addOrEditCompany(new CompanyCommonDto());

        assertNotNull(output);
    }

    @Test
    public void testGetLocations() {
        when(companyService.getLocations(Mockito.any())).thenReturn(new ArrayList<>());
        // when
        final List<CompanyLocationDto> output = testee.getLocations(1l);

        assertNotNull(output);
    }

    @Test
    public void testSaveLocation() {
        when(companyService.saveLocation(Mockito.any(), Mockito.any())).thenReturn(new CompanyLocationDto());
        // when
        final CompanyLocationDto output = testee.saveLocation(Mockito.any(), Mockito.any());

        assertNotNull(output);
    }


}
