package com.mediaservices.c2c.fc.hateoas;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;

import org.mockito.InjectMocks;
import org.springframework.hateoas.Link;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.ProjectDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

// TODO: Auto-generated Javadoc
/**
 * The Class ParojectResourceAssemblerTest.
 */
public class ProjectResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private ProjectResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        ProjectDto project = new ProjectDto();
        project.setProjectId(123L);

        // when
        ProjectDto output = testee.toResource(project);

        // then
        assertThat(output, is(project));
        assertThat(output.getLinks(), is(iterableWithSize(1)));
        assertThat(output.getLink(Link.REL_SELF).getHref(), containsString("/project/123"));

    }
}
