package com.mediaservices.c2c.fc.controller;

import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNotNull;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.service.TalentService;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;
import com.mediaservices.c2c.talent.dto.AccentedCharacterSet;

public class FCRootControllerTest extends MockitoTestWithRequestContext {

    @InjectMocks
    private FCRootController testee;

    @Mock
    private TalentService talentService;

    @Test
    public void testGetAccentedChars() {
        when(talentService.getAccentedChars(Mockito.anyString())).thenReturn(new AccentedCharacterSet());
        // when
        final AccentedCharacterSet output = testee.getAccentedChars("a");

        assertNotNull(output);
    }

}
