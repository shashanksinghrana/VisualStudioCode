package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resources;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.constants.Constants;
import com.mediaservices.c2c.fc.dto.CompensationDto;
import com.mediaservices.c2c.fc.dto.CreditDto;
import com.mediaservices.c2c.fc.dto.DealDto;
import com.mediaservices.c2c.fc.dto.FormulaDto;
import com.mediaservices.c2c.fc.dto.LoanoutDto;
import com.mediaservices.c2c.fc.dto.PerformerDealDto;
import com.mediaservices.c2c.fc.dto.PerformerGridSearchCriteria;
import com.mediaservices.c2c.fc.dto.PerqDto;
import com.mediaservices.c2c.fc.dto.RepresentationDetailDto;
import com.mediaservices.c2c.fc.dto.RepresentationDto;
import com.mediaservices.c2c.fc.dto.RepresentativeDto;
import com.mediaservices.c2c.fc.dto.RepresentativeMinimalDto;
import com.mediaservices.c2c.fc.dto.WizardDto;
import com.mediaservices.c2c.fc.hateoas.CompensationResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.CreditResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.DealResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.FormulaResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.PerformerDealResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.PerqResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.WizardResourceAssembler;
import com.mediaservices.c2c.fc.service.DealService;
import com.mediaservices.c2c.fc.service.FormulaService;
import com.mediaservices.c2c.fc.service.PerqService;
import com.mediaservices.c2c.fc.service.RepresentationService;
import com.mediaservices.c2c.fc.service.WizardService;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

/**
 * Deal Controller test class which handles testing of all deal related
 * requests.
 */
public class DealControllerTest extends MockitoTestWithRequestContext {

    @InjectMocks
    private DealController testee;

    /** The Deal service. */
    @Mock
    private DealService dealService;

    @Mock
    private PerqService perqService;

    @Mock
    private PerqResourceAssembler perqAssembler;

    @Mock
    private RepresentationService representationService;

    @Mock
    private WizardService wizardService;

    @Mock
    private PerformerDealResourceAssembler performerDealAssembler;

    @Mock
    private PagedResourcesAssembler<PerformerDealDto> pagedPerformerDealAssembler;

    @Mock
    private DealResourceAssembler dealAssembler;

    @Mock
    private CreditResourceAssembler creditAssembler;

    @Mock
    private CompensationResourceAssembler compensationAssembler;

    @Mock
    private WizardResourceAssembler wizardAssembler;

    @Mock
    private FormulaService formulaService;

    @Mock
    private FormulaResourceAssembler formulaAssembler;

    /** The Constant RANDOM. */
    private static final Random RANDOM = new Random();

    @Test
    public void testGetDeal() {
        // given
        final Long id = RANDOM.nextLong();
        final DealDto deal = new DealDto();
        when(dealAssembler.toResource(any(DealDto.class))).thenReturn(deal);
        when(dealService.getDeal(id)).thenReturn(new DealDto());
        // when
        final DealDto output = testee.getDeal(id);

        // then
        assertThat(output, is(deal));
    }

    @Test
    public void testSaveDeal() {
        // given
        final DealDto deal = new DealDto();
        final DealDto resourcedDeal = new DealDto();
        resourcedDeal.add(new ArrayList<Link>());
        when(dealAssembler.toResource(any(DealDto.class))).thenReturn(deal);
        when(dealService.saveDeal(deal)).thenReturn(resourcedDeal);
        // when
        final DealDto output = testee.saveDeal(deal);

        // then
        // assertThat(output, is(resourcedDeal));
        assertNotNull(output);

    }

    @Test
    public void testGetPerformerGrid() {
        // given
        final Page<PerformerDealDto> deals = new PageImpl<>(new ArrayList<>());
        final Pageable pageable = PageRequest.of(1, 20);
        final List<PerformerDealDto> resourcedDeals = new ArrayList<>();
        final PerformerDealDto deal1 = new PerformerDealDto();
        final PerformerDealDto deal2 = new PerformerDealDto();
        resourcedDeals.add(deal2);
        resourcedDeals.add(deal1);
        when(dealService.getPerformerDealsByProjectId(1L, pageable, new PerformerGridSearchCriteria()))
                .thenReturn(deals);

        // when
        final Resources<PerformerDealDto> output = testee.getPerformerGrid(pageable, 1L,
                new PerformerGridSearchCriteria());

        assertNull(output);
    }

    @Test
    public void testGetPerformerDeal() {
        // given
        final Long id = RANDOM.nextLong();
        final PerformerDealDto deal = new PerformerDealDto();
        final PerformerDealDto resourcedDeal = new PerformerDealDto();
        when(dealService.getPerformerDealByDealId(id)).thenReturn(deal);
        when(performerDealAssembler.toResource(deal)).thenReturn(resourcedDeal);

        // when
        final PerformerDealDto output = testee.getPerformerDeal(id);

        // then
        assertThat(output, is(resourcedDeal));
    }

    @Test
    public void testSaveCompensations() {
        // given
        final List<CompensationDto> compensationSet = new ArrayList<>();
        final List<CompensationDto> compensationList = new ArrayList<>();
        final CompensationDto dto = new CompensationDto();
        compensationSet.add(dto);
        compensationList.add(dto);
        final Long dealID = 3L;
        when(compensationAssembler.toResources(compensationSet)).thenReturn(compensationList);
        when(dealService.saveCompensations(compensationSet, Collections.EMPTY_LIST, dealID))
                .thenReturn(compensationSet);
        // when
        final Resources<CompensationDto> output = testee.saveCompensations(compensationSet, dealID);
        // then
        assertThat(output.getContent().size(), is(1));
        assertThat(output.getContent(), hasItem(instanceOf(CompensationDto.class)));
    }

    @Test
    public void testGetWizardPages() {

        // given
        final Long dealId = 1L;
        final Long studioId = 2L;
        final String type = "COMPENSATION";
        final String formType = "WIZARD";
        final Set<WizardDto> wizardSet = new HashSet<>();
        final List<WizardDto> wizardList = new ArrayList<>();
        final WizardDto dto = new WizardDto();
        wizardSet.add(dto);
        wizardList.add(dto);

        when(wizardService.getWizardForDeal(dealId, studioId, type, formType)).thenReturn(wizardSet);
        when(wizardAssembler.toResources(wizardSet)).thenReturn(wizardList);
        // when
        final Resources<WizardDto> output = testee.getWizardPages(formType, type, dealId, studioId);
        // then
        assertThat(output.getContent().size(), is(1));
        assertThat(output.getContent(), hasItem(instanceOf(WizardDto.class)));

    }

    @Test
    public void testGetWizard() {
        // given
        final Long wizardId = 3L;
        final String wizardType = Constants.WIZARD_TYPE_STATUS;
        final WizardDto dto = new WizardDto();

        when(wizardService.getWizardByIdAndType(wizardId, wizardType)).thenReturn(dto);
        when(wizardAssembler.toResource(dto)).thenReturn(dto);

        // when
        final WizardDto output = testee.getWizard(wizardId, wizardType);

        // then
        assertThat(output, is(dto));
    }

    @Test
    public void testDeleteDeal() {

        // when
        testee.deleteDeal(1l);

        Mockito.verify(dealService, Mockito.atLeastOnce()).deleteDeal(Mockito.any());
    }

    @Test
    public void testSaveWizardStatus() {
        final WizardDto dto = new WizardDto();

        when(wizardService.saveWizardStatus(Mockito.any())).thenReturn(dto);
        when(wizardAssembler.toResource(dto)).thenReturn(dto);

        // when
        final WizardDto output = testee.saveWizardStatus(dto);

        // then
        assertThat(output, is(dto));
    }

    @Test
    public void testGetFormulas() {

        when(formulaService.getFormulas(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.any()))
                .thenReturn(new ArrayList<>());
        final Resources<FormulaDto> output = testee.getFormulas(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyLong(), Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetFormula() {

        when(formulaService.getFormulaById(Mockito.anyLong())).thenReturn(new FormulaDto());
        when(formulaAssembler.toResource(Mockito.any())).thenReturn(new FormulaDto());
        final FormulaDto output = testee.getFormula(Mockito.anyLong());

        assertNotNull(output);
    }

    @Test
    public void testGetCompensationsByDealId() {

        when(dealService.getCompensationByDealId(Mockito.anyLong())).thenReturn(new ArrayList<>());
        testee.getCompensationsByDealId(Mockito.anyLong());
        Mockito.verify(dealService, Mockito.atLeastOnce()).getCompensationByDealId(Mockito.any());
    }

    @Test
    public void testSaveCompensation() {

        when(dealService.saveCompensation(Mockito.any())).thenReturn(new CompensationDto());
        when(compensationAssembler.toResource(Mockito.any())).thenReturn(new CompensationDto());
        final CompensationDto output = testee.saveCompensation(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetCompensation() {

        when(dealService.getCompensation(Mockito.any())).thenReturn(new CompensationDto());
        when(compensationAssembler.toResource(Mockito.any())).thenReturn(new CompensationDto());
        final CompensationDto output = testee.getCompensation(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testSaveCredit() {

        when(dealService.saveCredit(Mockito.any())).thenReturn(new CreditDto());
        when(creditAssembler.toResource(Mockito.any())).thenReturn(new CreditDto());
        final CreditDto output = testee.saveCredit(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetCredit() {

        when(dealService.getCredit(Mockito.any())).thenReturn(new CreditDto());
        when(creditAssembler.toResource(Mockito.any())).thenReturn(new CreditDto());
        final CreditDto output = testee.getCredit(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testSavePerqs() {

        when(perqService.savePerqs(Mockito.any(), Mockito.any())).thenReturn(new ArrayList<>());
        final List<PerqDto> output = testee.savePerqs(Mockito.any(), Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetPerqsByDealId() {

        when(perqService.getPerqsByDealId(Mockito.any())).thenReturn(new ArrayList<>());
        testee.getPerqsByDealId(Mockito.any());

        Mockito.verify(perqService, Mockito.atLeastOnce()).getPerqsByDealId(Mockito.any());
    }

    @Test
    public void testGetPerq() {

        when(perqService.getPerq(Mockito.any())).thenReturn(new PerqDto());
        when(perqAssembler.toResource(Mockito.any())).thenReturn(new PerqDto());
        final PerqDto output = testee.getPerq(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetSelectedCompany() {

        when(representationService.getSelectedCompany(Mockito.any())).thenReturn(new RepresentativeMinimalDto());
        final RepresentativeMinimalDto output = testee.getSelectedCompany(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetSelectedRep() {

        when(representationService.getSelectedRepresentative(Mockito.any(), Mockito.any()))
                .thenReturn(new RepresentativeMinimalDto());
        final RepresentativeMinimalDto output = testee.getSelectedRep(Mockito.any(), Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testAddRep() {

        when(representationService.addRepresentative(Mockito.any())).thenReturn(new RepresentativeDto());
        final RepresentativeDto output = testee.addRep(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testRemoveRep() {

        testee.removeRep(Mockito.any(), Mockito.any());

        Mockito.verify(representationService, Mockito.atLeastOnce()).deleteRepresentative(Mockito.any(), Mockito.any());
    }

    @Test
    public void testSaveRepresentation() {

        when(representationService.saveRepresentatives(Mockito.any(), Mockito.any())).thenReturn(new ArrayList<>());
        final List<RepresentationDetailDto> output = testee.saveRepresentation(Mockito.any(), Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testAddRepresentation() {

        when(representationService.addRepresentative(Mockito.any())).thenReturn(new RepresentativeDto());
        final RepresentativeDto output = testee.addRep(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testGetRepresentation() {

        when(representationService.getRepresentatives(Mockito.any())).thenReturn(new RepresentationDto());
        final RepresentationDto output = testee.getRepresentation(Mockito.any());

        assertNotNull(output);
    }

    @Test
    public void testSaveWorkActivities() {

        when(dealService.saveWorkActivities(Mockito.any(), Mockito.any())).thenReturn(new HashSet<>());
        testee.saveWorkActivities(Mockito.any(), Mockito.any());

        Mockito.verify(dealService, Mockito.atLeastOnce()).saveWorkActivities(Mockito.any(), Mockito.any());
    }

    @Test
    public void testGetWorkEligibilityByDealId() {

        when(dealService.getWorkActivityByDealId(Mockito.any())).thenReturn(new ArrayList<>());
        testee.getWorkEligibilityByDealId(Mockito.any());

        Mockito.verify(dealService, Mockito.atLeastOnce()).getWorkActivityByDealId(Mockito.any());
    }

    @Test
    public void testGetLoanout() {

        when(dealService.getDealLoanout(Mockito.any())).thenReturn(new LoanoutDto());
        final LoanoutDto output = testee.getLoanout(Mockito.any());

        assertNotNull(output);
        Mockito.verify(dealService, Mockito.atLeastOnce()).getDealLoanout(Mockito.any());
    }

    @Test
    public void testSaveLoanout() {

        when(dealService.updateDealLoanout(Mockito.any(), Mockito.any())).thenReturn(new DealDto());
        final DealDto output = testee.saveLoanout(Mockito.any(), Mockito.any());

        assertNotNull(output);
        Mockito.verify(dealService, Mockito.atLeastOnce()).updateDealLoanout(Mockito.any(), Mockito.any());
    }
}
