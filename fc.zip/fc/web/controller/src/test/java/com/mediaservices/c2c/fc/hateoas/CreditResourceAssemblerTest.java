package com.mediaservices.c2c.fc.hateoas;

import static org.testng.Assert.assertNotNull;

import org.mockito.InjectMocks;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.CreditDto;
import com.mediaservices.c2c.fc.test.MockitoTestWithRequestContext;

public class CreditResourceAssemblerTest extends MockitoTestWithRequestContext {

    /** The testee. */
    @InjectMocks
    private CreditResourceAssembler testee;

    /**
     * To resource.
     */
    @Test
    public void toResource() {
        // given
        final CreditDto credit = new CreditDto();
        credit.setDealId(1l);

        // when
        final CreditDto output = testee.toResource(credit);

        assertNotNull(output);
    }
}
