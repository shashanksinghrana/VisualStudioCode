/**
 *
 */
package com.mediaservices.c2c.fc.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertNotNull;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mediaservices.c2c.fc.dto.CompensationDto;
import com.mediaservices.c2c.fc.dto.ContractRiderDto;
import com.mediaservices.c2c.fc.dto.DealContractTermDto;
import com.mediaservices.c2c.fc.service.ContractService;

/**
 * @author shashankr
 *
 */
public class ContractControllerTest {

    @InjectMocks
    private ContractController testee;

    @Mock
    private ContractService contractService;

    /** The Constant RANDOM. */
    private static final Random RANDOM = new Random();

    @BeforeClass
    public void createMocks() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for
     * {@link com.mediaservices.c2c.fc.controller.ContractController#saveContractTerm(com.mediaservices.c2c.fc.dto.DealContractTermDto, java.lang.Long)}.
     */
    @Test
    public void testSaveContractTerm() {
        final DealContractTermDto contract = new DealContractTermDto();
        final Long dealId = RANDOM.nextLong();
        // when
        when(contractService.saveContractTerm(contract, dealId)).thenReturn(new DealContractTermDto());
        final DealContractTermDto output = testee.saveContractTerm(contract, dealId);
        // then
        assertThat(output, is(contract));
    }

    /**
     * Test method for
     * {@link com.mediaservices.c2c.fc.controller.ContractController#getContractTerm(java.lang.Long)}.
     */
    @Test
    public void testGetContractTerm() {
        final Long id = RANDOM.nextLong();
        final DealContractTermDto contractTerm = new DealContractTermDto();
        when(contractService.getContractTerm(id)).thenReturn(new DealContractTermDto());
        final DealContractTermDto output = testee.getContractTerm(id);
        assertThat(output, is(contractTerm));
    }

    /**
     * Test method for
     * {@link com.mediaservices.c2c.fc.controller.ContractController#getContractRiders()}.
     */
    @Test
    public void testGetContractRiders() {

        final Set<ContractRiderDto> contractTerm = new HashSet<>();
        when(contractService.getContractRiders()).thenReturn(new HashSet<ContractRiderDto>());
        final Set<ContractRiderDto> output = testee.getContractRiders();
        assertThat(output, is(contractTerm));
    }

    /**
     * Test method for
     * {@link com.mediaservices.c2c.fc.controller.ContractController#generateContract(com.mediaservices.c2c.fc.dto.CompensationDto, java.lang.Long, java.lang.Long)}.
     */
    @Test
    public void testGenerateContract() {
        final byte[] byteArray1 = { 80, 65, 78, 75, 65, 74 };
        when(contractService.generateContract(Mockito.anyLong(), Mockito.anyLong(), Mockito.any()))
        .thenReturn(byteArray1);
        final byte[] byteArray = testee.generateContract(new CompensationDto(), 1l, 1l);
        assertNotNull(byteArray);
    }

}
