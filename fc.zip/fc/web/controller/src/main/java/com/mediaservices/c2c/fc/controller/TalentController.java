package com.mediaservices.c2c.fc.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.hateoas.Resources;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.elasticsearch.dto.GlobalSearchResponseDto;
import com.mediaservices.c2c.elasticsearch.dto.TypeAheadNameSearchDto;
import com.mediaservices.c2c.fc.dto.LoanoutDto;
import com.mediaservices.c2c.fc.dto.PartyDto;
import com.mediaservices.c2c.fc.execption.InvalidArgumentException;
import com.mediaservices.c2c.fc.hateoas.PartyResourceAssembler;
import com.mediaservices.c2c.fc.service.PerformerService;
import com.mediaservices.c2c.fc.service.TalentService;
import com.mediaservices.c2c.rollcall.dto.CompanyCommonDto;
import com.mediaservices.c2c.rollcall.dto.PersonCommonDto;
import com.mediaservices.c2c.talent.constants.TalentConstants;
import com.mediaservices.c2c.talent.dto.Party;
import com.mediaservices.c2c.talent.dto.PartyTypeAhead;
import com.mediaservices.c2c.talent.dto.Relation;
import com.mediaservices.c2c.talent.dto.Talent;
import com.mediaservices.c2c.talent.dto.TypeAheadNameDto;
import com.mediaservices.c2c.talent.dto.TypeAheadNameResponseDto;
import com.mediaservices.c2c.talent.service.PartyService;
import com.mediaservices.c2c.talent.service.TypeAheadNameService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class TalentController.
 */
@RestController()
@Api(tags = { "Feature Casting performer/talent APIs" })
public class TalentController {

    /** The log. */
    private static Logger LOG = LoggerFactory.getLogger(TalentController.class);

    /** The party assembler. */
    @Autowired
    PartyResourceAssembler partyAssembler;

    /** The talent service. */
    @Autowired
    @Qualifier("fcTalentService")
    private TalentService talentService;

    /** The performer service. */
    @Autowired
    private PerformerService performerService;

    /** The party service. */
    @Autowired
    private PartyService partyService;

    /** The type ahead name service. */
    @Autowired
    private TypeAheadNameService typeAheadNameService;

    /**
     * Gets the loan out company type ahead.
     *
     * @param performerId
     *            the performer id
     * @return the loan out company type ahead
     */
    @CrossOrigin
    @RequestMapping(value = "/api/performers/{performerId}/loanoutCompanies", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Resources<LoanoutDto> getLoanOutCompanyTypeAhead(@PathVariable("performerId") Long performerId) {
        LOG.debug("Loanout company typeahead for performerId {}", performerId);
        final List<LoanoutDto> parties = talentService.getLoanoutCompanies(performerId);
        return new Resources<>(parties);
    }

    /**
     * Save talents loanout.
     *
     * @param performerId
     *            the performer id
     * @param loanout
     *            the loanout
     * @return the list
     */
    @CrossOrigin
    @RequestMapping(value = "/api/performers/{performerId}/loanoutCompanies", method = RequestMethod.PUT)
    public List<LoanoutDto> saveTalentsLoanout(@PathVariable("performerId") Long performerId,
            @RequestBody List<LoanoutDto> loanout) {
        LOG.debug(" Save talents loanout for performerId {}", performerId);
        return talentService.updateLoanout(performerId, loanout);
    }

    /**
     * Gets the performer.
     *
     * @param performerId
     *            the performer id
     * @return the performer
     */
    @CrossOrigin
    @RequestMapping(value = "/api/performer/{performerId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public PartyDto getPerformer(@PathVariable("performerId") Long performerId) {
        LOG.debug(" get performer {}", performerId);
        return partyAssembler.toResource(performerService.getPerformer(performerId));
    }

    /**
     * Gets the performer.
     *
     * @param performerId
     *            the performer id
     * @param akaId
     *            the aka id
     * @return the performer
     */
    @CrossOrigin
    @RequestMapping(value = "/api/performer/{performerId}/akas/{akaId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public PartyDto getPerformer(@PathVariable("performerId") Long performerId, @PathVariable("akaId") Long akaId,
            @RequestParam(value = "partyVersion", required = false) Long partyVersion) {
        LOG.debug("Get performer {} for akaid {}", performerId, akaId);
        return partyAssembler.toResource(performerService.getPerformer(performerId, akaId, partyVersion));
    }

    /**
     * Gets the talent.
     *
     * @param partyId
     *            the party id
     * @return the talent
     */
    @CrossOrigin
    @GetMapping(value = "/api/talents/{partyId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Talent getTalent(@PathVariable("partyId") Long partyId) {
        LOG.debug(" get talent {}", partyId);
        return talentService.getTalentDetails(partyId);
    }

    /**
     * Save talent.
     *
     * @param talent
     *            the talent
     * @return the talent
     */
    @CrossOrigin
    @PutMapping(value = "/api/talents", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Talent saveTalent(@RequestBody @Valid Talent talent) {
        LOG.debug("save talent ");
        return talentService.saveTalent(talent);
    }

    /**
     * Gets the talent image.
     *
     * @param partyId
     *            the party id
     * @return the talent image
     */
    @CrossOrigin
    @ApiOperation(value = "Returns a parties image")
    @RequestMapping(value = "/api/party/{partyId}/image", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
    public byte[] getTalentImage(
            @PathVariable @ApiParam(value = "The id of the party to get an image for") long partyId) {
        return partyService.getTalentImage(partyId);
    }

    /**
     * Validate person.
     *
     * @param person
     *            the person
     */
    @CrossOrigin
    @RequestMapping(value = "/api/talents/validate", method = RequestMethod.POST)
    public void validatePerson(@RequestBody Talent person) {
        try {
        LOG.debug("vlidate talent ");
        partyService.validatePartyRequest(person);
        } catch (com.mediaservices.c2c.talent.execption.InvalidArgumentException invalidArgumentException) {
            throw new InvalidArgumentException(invalidArgumentException.getErrors(),
                    invalidArgumentException.getErrors().get(0).getField());
        }

    }

    /**
     * Adds the type ahead name.
     *
     * @param party
     *            the party
     * @return the party type ahead
     */
    @CrossOrigin
    @ApiOperation(value = "Add a party to the database")
    @RequestMapping(path = "/api/addParty", method = RequestMethod.POST, produces = "application/json")
    public PartyTypeAhead addTypeAheadName(@RequestBody PartyTypeAhead party) {
        LOG.debug("Adding Name Called.");
        return talentService.addTypeAheadName(party);
    }

    /**
     * Adds the name as alias.
     *
     * @param listOfParties
     *            the list of parties
     * @return the party type ahead
     */
    @CrossOrigin
    @ApiOperation(value = "Allows an alias to be added to an existing talent")
    @RequestMapping(path = "/addAlias", method = RequestMethod.POST, produces = "application/json")
    public PartyTypeAhead addNameAsAlias(@RequestBody List<PartyTypeAhead> listOfParties) {
        LOG.debug("Adding Name as Alias Called.");
        return talentService.addNameAsAlias(listOfParties);
    }

    /**
     * Gets the talents contact company.
     *
     * @param partyId
     *            the party id
     * @return the talents contact company
     */
    @CrossOrigin
    @RequestMapping(value = "/api/talents/{partyId}/contact-companies", method = RequestMethod.GET)
    public CompanyCommonDto getTalentsContactCompany(
            @PathVariable @ApiParam(value = "The id of the talent to lookup") Long partyId) {
        LOG.debug("get talents contact company {}", partyId);
        return partyService.getTalentsContactCompany(partyId);
    }

    /**
     * Gets the global search data.
     *
     * @param searchDto
     *            the search dto
     * @return the global search data
     */
    @CrossOrigin
    @RequestMapping(value = "/api/global-search/{sourceModule}", method = RequestMethod.GET, produces = "application/json")
    @ApiOperation(value = "Searches for Global Search")
    public GlobalSearchResponseDto getGlobalSearchData(@PathVariable String sourceModule,
            TypeAheadNameSearchDto searchDto) {
        LOG.debug("Global search starts for: {}", searchDto.getTextToBeSearched());
        return typeAheadNameService.getGlobalSearchResponse(sourceModule, searchDto);
    }

    /**
     * Save relation.
     *
     * @param relation
     *            the relation
     */
    @CrossOrigin
    @RequestMapping(value = "/api/party/relation", method = RequestMethod.POST)
    @ApiOperation(value = "Saves a Relation between two parties")
    public void saveRelation(@RequestBody @Valid Relation relation) {
        partyService.saveRelation(relation.getParentPartyId(), relation.getChildPartyId(),
                relation.getType().getTypeName(), relation.getPrimary(), relation.getOccupationId(),
                TalentConstants.MODULE_TALENT);
    }

    /**
     * Delete relation.
     *
     * @param relation
     *            the relation
     */
    @CrossOrigin
    @RequestMapping(value = "/api/party/relation", method = RequestMethod.DELETE)
    @ApiOperation(value = "Removes a relation between two parties")
    public void deleteRelation(@RequestBody @Valid Relation relation) {
        partyService.deleteRelation(relation.getParentPartyId(), relation.getChildPartyId(),
                relation.getType().getTypeName());
    }

    /**
     * Save person.
     *
     * @param person
     *            the person
     * @return the person common dto
     */
    @CrossOrigin
    @RequestMapping(value = "/api/persons", method = RequestMethod.POST)
    public PersonCommonDto savePerson(@RequestBody PersonCommonDto person) {
        return partyService.savePerson(person, TalentConstants.MODULE_TALENT);
    }

    /**
     * Gets the persons details.
     *
     * @param partyId
     *            the party id
     * @return the persons details
     */
    @CrossOrigin
    @ApiOperation(value = "Gets Rollcall Person Detail based on an Id")
    @RequestMapping(value = "/api/persons/{partyId}", method = RequestMethod.GET, produces = "application/json")
    public PersonCommonDto getPersonsDetails(
            @PathVariable @ApiParam(value = "The id of the person to lookup", required = true) long partyId) {
        return partyService.getPersonDetails(partyId);
    }

    /**
     * Save rollcall person.
     *
     * @param dto
     *            the dto
     * @return the person common dto
     */
    @CrossOrigin
    @RequestMapping(value = "/api/contactable-persons", method = RequestMethod.POST)
    @ApiOperation(value = "Save the rollcall person")
    public PersonCommonDto saveRollcallPerson(@RequestBody PersonCommonDto dto) {
        dto.setUpdatedByApp(TalentConstants.MODULE_TALENT);
        return partyService.saveRollcallPerson(dto);
    }

    /**
     * Gets the party details.
     *
     * @param partyId
     *            the party id
     * @return the party details
     */
    @CrossOrigin
    @ApiOperation(value = "Gets Party Detail based on an Id")
    @RequestMapping(value = "/api/party/{partyId}", method = RequestMethod.GET, produces = "application/json")
    public Party getPartyDetails(
            @PathVariable @ApiParam(value = "The id of the talent to lookup", required = true) long partyId) {
        return partyService.getPartyDetails(partyId);
    }

    /**
     * Gets the all names for party.
     *
     * @param id
     *            the id
     * @return the all names for party
     */
    @CrossOrigin
    @ApiOperation(value = "Returns All names for a particular party")
    @RequestMapping(path = "/api/party/{id}/names", method = RequestMethod.GET, produces = "application/json")
    public List<PartyTypeAhead> getAllNamesForParty(
            @PathVariable @ApiParam(value = "The id of the party to get the names of") Long id) {

        return typeAheadNameService.getAllNames(id);
    }

    /**
     * Gets the performer type ahead.
     *
     * @param searchTerm
     *            the search term
     * @param recordCount
     *            the record count
     * @param filterType
     *            the filter type
     * @return the performer type ahead
     */
    @CrossOrigin
    @GetMapping(value = "/api/typeAhead/performers", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<TypeAheadNameDto> getPerformerTypeAhead(@RequestParam String searchTerm, @RequestParam int recordCount,
            @RequestParam(defaultValue = "TALENT_ONLY") String filterType) {
        return talentService.searchPerformers(searchTerm, recordCount, filterType).getTypeAheadNames();
    }

    /**
     * Gets the type ahead names.
     *
     * @param searchTerm
     *            the search term
     * @param recordCount
     *            the record count
     * @param filterType
     *            the filter type
     * @return the type ahead names
     */
    @CrossOrigin
    @GetMapping(value = "/api/typeAheadNames", produces = { MediaType.APPLICATION_JSON_VALUE })
    public TypeAheadNameResponseDto getTypeAheadNames(@RequestParam String searchTerm, @RequestParam int recordCount,
            @RequestParam String filterType) {
        return talentService.searchPerformers(searchTerm, recordCount, filterType);
    }

    /**
     * Gets the context meta data.
     *
     * @param contextName
     *            the context name
     * @return the context meta data
     */
    @CrossOrigin
    @ApiOperation(value = "Searches for meta data fields for given context")
    @RequestMapping(value = "/api/typeahead/{contextName}", method = RequestMethod.GET, produces = "application/json")
    public List<String> getContextMetaData(
            @PathVariable @ApiParam(value = "Searches for meta data of: {}") String contextName) {
        return typeAheadNameService.getContextMetaData(contextName);
    }
}