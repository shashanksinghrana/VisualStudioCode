package com.mediaservices.c2c.fc.controller;

import static com.mediaservices.c2c.elasticsearch.enums.TypeaheadFilterType.COMPANY_ONLY;
import static com.mediaservices.c2c.elasticsearch.enums.TypeaheadFilterType.CONTACT_ONLY;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.dto.LookupDto;
import com.mediaservices.c2c.fc.dto.RoleTypeAheadDto;
import com.mediaservices.c2c.fc.dto.SignatoryUserDto;
import com.mediaservices.c2c.fc.hateoas.LookupResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.SignatoryUserResourceAssembler;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.LookupService;
import com.mediaservices.c2c.fc.service.RepresentationService;
import com.mediaservices.c2c.fc.service.TalentService;
import com.mediaservices.c2c.talent.dto.AccentedCharacterSet;
import com.mediaservices.c2c.talent.dto.PicklistsDTO;
import com.mediaservices.c2c.talent.dto.SystemPropValueDTO;
import com.mediaservices.c2c.talent.dto.TypeAheadNameDto;
import com.mediaservices.c2c.talent.service.CommonService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class LookupController.
 */
@RestController
@RequestMapping("/api")
@Api(tags = { "Feature Casting Lookup APIs" })
public class LookupController {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(LookupController.class);

    private static final String PICKLIST_TYPES = "COMPANY_OCCUPATION,CONTACT_OCCUPATION,GENDER,RACE,CONTACT_TYPE,"
            + "PHONE_TYPE,COMPANY_TYPE,WEBCONTACT_TYPE,CURRENT_STATUS,DEVELOPMENT_STATUS,ADDRESS_TYPE,"
            + "PARTY_CONTACT_TYPE,IMMIGRATION_STATUS,DEPARTMENT_TYPE,STATES,COUNTRIES,GENRE,TALENT_STATUS,REP_TYPE";

    /** The lookup service. */
    @Autowired
    private LookupService lookupService;

    /** The authorization service. */
    @Autowired
    private AuthorizationService authorizationService;

    /** The resource assembler. */
    @Autowired
    private LookupResourceAssembler resourceAssembler;

    /** The signatory user assembler. */
    @Autowired
    private SignatoryUserResourceAssembler signatoryUserAssembler;

    /** The page assembler. */
    @Autowired
    private PagedResourcesAssembler<LookupDto> pageAssembler;

    /** The common service. */
    @Autowired
    CommonService commonService;

    /** The talent service. */
    @Autowired
    @Qualifier("fcTalentService")
    private TalentService talentService;

    @Autowired
    private RepresentationService repService;

    /**
     * Gets the lookup page.
     *
     * @param pageable
     *            the pageable
     * @return the lookup page
     */
    @CrossOrigin
    @RequestMapping(value = "/lookups", method = RequestMethod.GET, params = { "size", "page" }, produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public PagedResources<LookupDto> getLookupPage(Pageable pageable) {
        LOG.debug("Getting the paged data from Lookup with a size of [{}] and page number of [{}].",
                pageable.getPageSize(), pageable.getPageNumber());
        final Page<LookupDto> lookups = lookupService.getLookupsPage(pageable);

        return pageAssembler.toResource(lookups, resourceAssembler);

    }

    /**
     * Gets the lookup.
     *
     * @param id
     *            the id
     * @return the lookup
     */
    @CrossOrigin
    @RequestMapping(value = "/lookup/{id}", method = RequestMethod.GET)
    public LookupDto getLookup(@PathVariable Long id) {
        LOG.debug("Getting the lookup by the ID of [{}].", id);
        return resourceAssembler.toResource(lookupService.getLookupById(id));
    }

    /**
     * Gets the lookups by type.
     *
     * @param type
     *            the type
     * @param studio
     *            the studio
     * @param filter
     *            the filter
     * @return the lookups by type
     */
    @CrossOrigin
    @RequestMapping(value = "/lookup/type/{type}", method = RequestMethod.GET)
    public List<LookupDto> getLookupsByType(@PathVariable String type, @RequestParam(required = false) Long studio,
            @RequestParam(required = false) String filter) {
        LOG.debug("Getting all the data from Lookup with a type of [{}] and studio [{}] and filter [{}].", type, studio,
                filter);
        return resourceAssembler.toResources(lookupService.getLookupsByType(type, studio, filter));
    }

    /**
     * Gets the lookups by pick list.
     *
     * @param type
     *            the type
     * @return the lookups by pick list
     */
    @CrossOrigin
    @RequestMapping(value = "/generic/lookup/{type}", method = RequestMethod.GET)
    public List<SystemPropValueDTO> getLookupsByPickList(@PathVariable String type) {
        LOG.debug("Getting all the data from Lookup with a type of [{}] and studio [{}] and filter [{}].", type);
        if (type.equalsIgnoreCase("REP_TYPE")) {
            return repService.getRepType();
        }
        return commonService.getPickListsBasedOnTypes(type).getPicklists().get(type);
    }

    /**
     * Gets the studio for logged in user.
     *
     * @return the studio for logged in user
     */
    @CrossOrigin
    @RequestMapping(value = "/lookup/studioForUser", method = RequestMethod.GET) // TODO
    // remove
    // once
    // UI
    // has
    // updated
    // to
    // make
    // call
    // from
    // getLookupsByType
    public List<LookupDto> getStudioForLoggedInUser() {
        LOG.debug("Getting Studios from SharedLookup for logged in user");
        final String userId = authorizationService.getLoggedInUserId();
        return resourceAssembler.toResources(lookupService.getStudiosForUser(userId));
    }

    /**
     * Gets the signatory users.
     *
     * @return the signatory users
     */
    @CrossOrigin
    @RequestMapping(value = "/lookup/signatories", method = RequestMethod.GET)
    public List<SignatoryUserDto> getSignatoryUsers() {
        LOG.debug("Getting Signatory Users");
        return signatoryUserAssembler.toResources(lookupService.getSignatoryUsers());
    }

    /**
     * Gets the signatory user.
     *
     * @param id
     *            the id
     * @return the signatory user
     */
    @CrossOrigin
    @RequestMapping(value = "/lookups/signatories/{id}", method = RequestMethod.GET)
    public SignatoryUserDto getSignatoryUser(@PathVariable Long id) {
        LOG.debug("Getting the singatory user by the ID of [{}].", id);
        return signatoryUserAssembler.toResource(lookupService.getSignatoryUserById(id));
    }

    /**
     * Gets the rep name.
     *
     * @param searchTerm
     *            the search term
     * @param recordCount
     *            the record count
     * @return the rep name
     */
    @CrossOrigin
    @RequestMapping(value = "/contacts", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<TypeAheadNameDto> getRepName(@RequestParam String searchTerm, @RequestParam int recordCount) {
        return lookupService.getTypeAheadNames(searchTerm, CONTACT_ONLY, recordCount);
    }

    /**
     * Gets the company name.
     *
     * @param searchTerm
     *            the search term
     * @param recordCount
     *            the record count
     * @return the company name
     */
    @CrossOrigin
    @RequestMapping(value = "/companies", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<TypeAheadNameDto> getCompanyName(@RequestParam String searchTerm, @RequestParam int recordCount) {
        return lookupService.getTypeAheadNames(searchTerm, COMPANY_ONLY, recordCount);
    }

    /**
     * Gets the roles.
     *
     * @param searchTerm
     *            the search term
     * @param recordCount
     *            the record count
     * @return the roles
     */
    @CrossOrigin
    @GetMapping(value = "/typeAhead/roles", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<RoleTypeAheadDto> getRoles(@RequestParam String searchTerm, @RequestParam int recordCount) {
        return lookupService.getAllRoles(searchTerm, recordCount);
    }

    /**
     * Gets the accented chars.
     *
     * @param accentedChar
     *            the accented char
     * @return
     * @return the accented chars
     */
    @CrossOrigin
    @GetMapping(value = "/accents/chars", produces = { MediaType.APPLICATION_JSON_VALUE })
    public AccentedCharacterSet getAccentedChars(@RequestParam(name = "char") String chars) {
        return talentService.getAccentedChars(chars);
    }

    /**
     * Gets the pick list values.
     *
     * @param type
     *            the type
     * @param studioId
     *            the studio id
     * @return the pick list values
     */
    @CrossOrigin
    @ApiOperation(value = "Returns a list of options available for a picklist", response = PicklistsDTO.class)
    @RequestMapping(value = "/picklist/{type}", method = RequestMethod.GET, produces = "application/json")
    public PicklistsDTO getPickListValues(
            @PathVariable @ApiParam(allowableValues = PICKLIST_TYPES, value = "The type of the picklist to return (May have multiple seperated by commas)", required = true) String type,
            @RequestParam(value = "studioId", required = true) @ApiParam(value = "The id of the studio currently being looked at", example = "3911", required = true) Long studioId) {
        LOG.debug("CommonController.getPickListValues() method called");
        return commonService.getPickListsBasedOnStudio(studioId, type);
    }

    /**
     * Gets the pick lists.
     *
     * @param type
     *            the type
     * @return the pick lists
     */
    @CrossOrigin
    @GetMapping("/common/picklist/{type}")
    public com.mediaservices.c2c.rollcall.dto.PicklistsDTO getPickLists(@PathVariable String type) {
        LOG.debug("PicklistController.getPickListValues() method called passing SysPropId as : " + type);
        return commonService.getPickListsFromType(type);
    }
}
