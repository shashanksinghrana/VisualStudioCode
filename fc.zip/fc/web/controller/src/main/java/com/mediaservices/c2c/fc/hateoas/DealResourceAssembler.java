package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.DealController;
import com.mediaservices.c2c.fc.dto.DealDto;

/**
 * The Class DealResourceAssembler.
 */
@Component
public class DealResourceAssembler extends ResourceAssemblerSupport<DealDto, DealDto> {

    /**
     * Instantiates a new Deal resource assembler.
     */
    public DealResourceAssembler() {
        super(DealController.class, DealDto.class);

    }

    @Override
    public DealDto toResource(DealDto deal) {
        deal.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DealController.class).getDeal(deal.getDealId())).withSelfRel());
        return deal;
    }

}
