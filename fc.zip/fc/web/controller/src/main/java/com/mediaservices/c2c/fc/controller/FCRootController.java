package com.mediaservices.c2c.fc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.service.TalentService;
import com.mediaservices.c2c.talent.dto.AccentedCharacterSet;

import io.swagger.annotations.Api;

/**
 * The Class LookupController.
 */
@RestController
@Api(tags = { "Feature Casting Root Controller APIs" })
public class FCRootController {

    /** The talent service. */
    @Autowired
    @Qualifier("fcTalentService")
    private TalentService talentService;


    @CrossOrigin
    @GetMapping(value = "/getAccentedChars", produces = { MediaType.APPLICATION_JSON_VALUE })
    public AccentedCharacterSet getAccentedChars(@RequestParam(name = "accentedChar") String chars) {
        return talentService.getAccentedChars(chars);
    }

    
}
