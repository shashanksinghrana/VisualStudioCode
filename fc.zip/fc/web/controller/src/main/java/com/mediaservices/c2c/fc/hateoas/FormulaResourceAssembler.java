package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.DealController;
import com.mediaservices.c2c.fc.dto.FormulaDto;

/**
 * The Class FormulaResourceAssembler.
 */
@Component
public class FormulaResourceAssembler extends ResourceAssemblerSupport<FormulaDto, FormulaDto> {

    /**
     * Instantiates a new formula resource assembler.
     */
    public FormulaResourceAssembler() {
        super(DealController.class, FormulaDto.class);

    }

    @Override
    public FormulaDto toResource(FormulaDto entity) {
        entity.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DealController.class).getFormula(entity.getFormulaId()))
                .withSelfRel());
        return entity;
    }

}
