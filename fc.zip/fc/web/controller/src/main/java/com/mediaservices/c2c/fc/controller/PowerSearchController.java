package com.mediaservices.c2c.fc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.constants.Constants;
import com.mediaservices.c2c.fc.dto.PageContent;
import com.mediaservices.c2c.fc.dto.PowerSearchCriteriaDto;
import com.mediaservices.c2c.fc.dto.PowerSearchDto;
import com.mediaservices.c2c.fc.dto.SavedSearchQueryDto;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.PowerSearchService;

import io.swagger.annotations.Api;

/**
 * The Class PowerSearchController.
 */

@RestController
@RequestMapping("/api")
@Api(tags = { "Feature Casting Power Search APIs" })
public class PowerSearchController {

    /** The Constant LOG. */
    private static final Logger logger = LoggerFactory.getLogger(PowerSearchController.class);

    /** The authorization service. */
    @Autowired
    private AuthorizationService authorizationService;

    /** The power search service. */
    @Autowired
    private PowerSearchService powerSearchService;

    /**
     * Gets the saved searches by user.
     *
     * @return the saved searches by user
     */
    @CrossOrigin
    @GetMapping(value = "/powersearch/queries", produces = MediaType.APPLICATION_JSON_VALUE)
    List<SavedSearchQueryDto> getSavedSearchesByUser() {
        String userId = authorizationService.getLoggedInUserId();
        List<SavedSearchQueryDto> savedSearchList = null;
        if (userId != null) {
            savedSearchList = powerSearchService.getSavedSearchListByUser(userId);
        }
        logger.info("Saved searches for the User" + userId);
        return savedSearchList;
    }

    /**
     * Gets the power search.
     *
     * @param pageable
     *            the pageable
     * @param criteria
     *            the criteria
     * @return the power search
     */
    @RequestMapping(value = "/powersearch", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public PageContent<PowerSearchDto> getPowerSearch(
            @PageableDefault(size = Constants.DEFAULT_RECORD_COUNT, page = 0, direction = Direction.ASC, sort = "title") Pageable pageable,
            @RequestBody PowerSearchCriteriaDto criteria) {
        logger.info("Power search request");
        return powerSearchService.getPowerSearch(pageable, criteria);

    }

    /**
     * Gets the saved search by id.
     *
     * @param queryId
     *            the query id
     * @return the saved search by id
     */
    @CrossOrigin
    @GetMapping(value = "/powersearch/queries/{queryId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public SavedSearchQueryDto getSavedSearchByQueryId(@PathVariable("queryId") long queryId) {
        return powerSearchService.getSavedSearchByQueryId(queryId);
    }

    /**
     * Creates the saved search.
     *
     * @param searchCriteria
     *            the search criteria
     * @return the saved search criteria dto
     */
    @CrossOrigin
    @PutMapping(value = "/powersearch/queries", produces = MediaType.APPLICATION_JSON_VALUE)
    public SavedSearchQueryDto createSavedSearch(@RequestBody SavedSearchQueryDto searchQuery) {
        return powerSearchService.saveSearchQuery(searchQuery);

    }

    /**
     * Delete saved search.
     *
     * @param queryId
     *            the query id
     */
    @CrossOrigin
    @DeleteMapping(value = "/powersearch/queries/{queryId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public void deleteSavedSearch(@PathVariable("queryId") long queryId) {
        powerSearchService.deleteSavedSearch(queryId);
    }

}
