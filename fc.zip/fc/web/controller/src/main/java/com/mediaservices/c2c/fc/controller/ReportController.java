package com.mediaservices.c2c.fc.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.dto.PowerSearchCriteriaDto;
import com.mediaservices.c2c.fc.service.ReportService;

import io.swagger.annotations.Api;

/**
 * The Class ReportController.
 */
@RestController
@RequestMapping("/api")
@Api(tags = { "Feature Casting Report APIs" })
public class ReportController {

    /** The report service. */
    @Autowired
    private ReportService reportService;

    /**
     * Gets the power search I 9 report.
     *
     * @param criteria
     *            the criteria
     * @param fileType
     *            the file type
     * @param reportType
     *            the report type
     * @return the power search I 9 report
     */
    @CrossOrigin
    @RequestMapping(value = "/reports/powersearch/{reportType}", method = RequestMethod.POST)
    public ResponseEntity<byte[]> getPowerSearchReport(@RequestBody PowerSearchCriteriaDto criteria,
            @RequestParam(name = "fileType") String fileType,
            @PathVariable(name = "reportType", required = true) String reportType) {
        return reportService.getReport(criteria, fileType, reportType);
    }

    public ResponseEntity<byte[]> getReport(@RequestParam(name = "reportParam") Map<String, Object> request) {
        return null;
    }
}
