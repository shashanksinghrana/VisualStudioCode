package com.mediaservices.c2c.fc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.constants.Constants;
import com.mediaservices.c2c.fc.dto.AllProjectDto;
import com.mediaservices.c2c.fc.dto.AllProjectsGridSearchCriteria;
import com.mediaservices.c2c.fc.dto.BillingDto;
import com.mediaservices.c2c.fc.dto.CrewDto;
import com.mediaservices.c2c.fc.dto.CrewRequestDto;
import com.mediaservices.c2c.fc.dto.LocationPeriodDto;
import com.mediaservices.c2c.fc.dto.LookupDto;
import com.mediaservices.c2c.fc.dto.ProjectDetailsDto;
import com.mediaservices.c2c.fc.dto.ProjectDto;
import com.mediaservices.c2c.fc.dto.ProjectStatusDateDto;
import com.mediaservices.c2c.fc.dto.WorkPeriodDto;
import com.mediaservices.c2c.fc.hateoas.AllProjectResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.ProjectDetailsResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.ProjectResourceAssembler;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.ProjectService;
import com.mediaservices.c2c.talent.dto.TypeAheadNameDto;

/**
 * The Class ProjectController.
 */
@RestController()
@RequestMapping("/api")
public class ProjectController {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ProjectController.class);

    /** The project service. */
    @Autowired
    private ProjectService projectService;

    /** The resource assembler. */
    @Autowired
    private ProjectResourceAssembler resourceAssembler;

    /** The project details assembler. */
    @Autowired
    private ProjectDetailsResourceAssembler projectDetailsAssembler;

    /** The all project resources assembler. */
    @Autowired
    private AllProjectResourceAssembler allProjectResourcesAssembler;

    /** The all project assembler. */
    @Autowired
    private PagedResourcesAssembler<AllProjectDto> allProjectAssembler;

    /** The page assembler. */
    @Autowired
    private PagedResourcesAssembler<ProjectDto> pageAssembler;
    
    /** The authorization service. */
    @Autowired
    AuthorizationService authorizationService;

    /**
     * Gets the all projects.
     *
     * @param pageable
     *            the pageable
     * @param criteria
     *            the criteria
     * @return the all projects
     */
    @CrossOrigin
    @GetMapping(value = "/myProjects", produces = { MediaType.APPLICATION_JSON_VALUE })
    public PagedResources<AllProjectDto> getMyProjects(
            @PageableDefault(size = Constants.DEFAULT_RECORD_COUNT, page = 0, direction = Direction.DESC, sort = "updateDate") Pageable pageable,
            AllProjectsGridSearchCriteria criteria) {
        LOG.info("REQUEST MADE MY PROJECTS");
        criteria.setAssignedToUserId(authorizationService.getLoggedInUserId());
        Page<AllProjectDto> projects = projectService.getAllProjects(pageable, criteria);

        return allProjectAssembler.toResource(projects, allProjectResourcesAssembler);
    }
    
    /**
     * Gets the all projects.
     *
     * @param pageable
     *            the pageable
     * @param criteria
     *            the criteria
     * @return the all projects
     */
    @CrossOrigin
    @GetMapping(value = "/allProjects", produces = { MediaType.APPLICATION_JSON_VALUE })
    public PagedResources<AllProjectDto> getAllProjects(
            @PageableDefault(size = Constants.DEFAULT_RECORD_COUNT, page = 0, direction = Direction.DESC, sort = "updateDate") Pageable pageable,
            AllProjectsGridSearchCriteria criteria) {
        LOG.info("REQUEST MADE ALL PROJECTS");
        Page<AllProjectDto> projects = projectService.getAllProjects(pageable, criteria);

        return allProjectAssembler.toResource(projects, allProjectResourcesAssembler);
    }

    /**
     * Gets the project page.
     *
     * @param pageable
     *            the pageable
     * @return the project page
     */
    @CrossOrigin
    @GetMapping(value = "/projects", params = { "size", "page" }, produces = { MediaType.APPLICATION_JSON_VALUE })
    public PagedResources<ProjectDto> getProjectPage(Pageable pageable) {
        LOG.debug("REQUEST MADE");

        Page<ProjectDto> projects = projectService.getProjectsPage(pageable);

        return pageAssembler.toResource(projects, resourceAssembler);

    }

    /**
     * Gets the project.
     *
     * @param id
     *            the id
     * @return the project
     */
    @CrossOrigin
    @GetMapping(value = "/project/{id}")
    public ProjectDto getProject(@PathVariable Long id) {
        return resourceAssembler.toResource(projectService.getProjectById(id));
    }

    /**
     * Gets the project details.
     *
     * @param id
     *            the id
     * @return the project details
     */
    @CrossOrigin
    @GetMapping(value = "/projectDetails/{id}")
    public ProjectDetailsDto getProjectDetails(@PathVariable Long id) {
        return projectDetailsAssembler.toResource(projectService.getProjectDetailsById(id));
    }

    /**
     * Creates the project.
     *
     * @param project
     *            the project
     * @return the project dto
     */
    @CrossOrigin
    @PostMapping(value = "/project")
    public ProjectDto createProject(@RequestBody ProjectDto project) {
        LOG.debug("Create Project called.");
        return resourceAssembler.toResource(projectService.createProject(project));
    }

    /**
     * Update project.
     *
     * @param project
     *            the project
     * @return the project dto
     */
    @CrossOrigin
    @PutMapping(value = "/project")
    public ProjectDto updateProject(@RequestBody ProjectDto project) {
        LOG.debug("Update Project called.");
        return resourceAssembler.toResource(projectService.updateProject(project));

    }

    /**
     * Gets the production company.
     *
     * @param projectId
     *            the project id
     * @return the production company
     */
    @CrossOrigin
    @GetMapping(value = "/project/{projectId}/productionCompany", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<TypeAheadNameDto> getProductionCompany(@PathVariable Long projectId) {
        return projectService.getProductionCompany(projectId);

    }

    /**
     * Gets the union.
     *
     * @param projectId
     *            the project id
     * @param companyId
     *            the company id
     * @return the union
     */
    @CrossOrigin
    @GetMapping(value = "/project/{projectId}/productionCompany/{companyId}/union", produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public List<LookupDto> getUnion(@PathVariable Long projectId, @PathVariable Long companyId) {
        return projectService.getUnion(projectId, companyId);

    }

    /**
     * Gets the billings.
     *
     * @param projectId
     *            the project id
     * @return the billings
     */
    @CrossOrigin
    @GetMapping(value = "/projects/{projectId}/billings", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<BillingDto> getBillings(@PathVariable Long projectId) {
        return projectService.getBillings(projectId);
    }

    /**
     * Save billing.
     *
     * @param billing
     *            the billing
     * @return the billing dto
     */
    @CrossOrigin
    @PutMapping(value = "/projects/{projectId}/deals/{dealId}/billings", consumes = {
            MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
    public BillingDto saveBilling(@RequestBody BillingDto billing) {
        return projectService.saveBilling(billing);
    }

    /**
     * Gets the billing attachment.
     *
     * @param dealId
     *            the deal id
     * @return the billing attachment
     */
    @CrossOrigin
    @PostMapping(value = "/projects/{projectId}/deals/{dealId}/attachments", produces = "text/html")
    public byte[] getBillingAttachment(@PathVariable Long dealId) {
        return projectService.getBillingAttachment(dealId);
    }

    /**
     * Gets the status dates.
     *
     * @param projectId
     *            the project id
     * @return the status dates
     */
    @CrossOrigin
    @GetMapping(value = "/projects/{projectId}/statusDates", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<ProjectStatusDateDto> getStatusDates(@PathVariable Long projectId) {
        return projectService.getProjectStatusDates(projectId);
    }

    /**
     * Save status dates.
     *
     * @param projectStatusDateDto
     *            the project status date dto
     * @param projectId
     *            the project id
     * @return the project status date dto
     */
    @CrossOrigin
    @PutMapping(value = "/projects/{projectId}/statusDates", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ProjectStatusDateDto saveStatusDates(@RequestBody ProjectStatusDateDto projectStatusDateDto,
            @PathVariable Long projectId) {
        return projectService.saveProjectStatusDates(projectStatusDateDto, projectId);
    }

    /**
     * Delete status dates by id.
     *
     * @param id
     *            the id
     */
    @CrossOrigin
    @DeleteMapping(value = "/projects/{projectId}/statusDates/{id}")
    public void deleteStatusDatesById(@PathVariable Long id) {
        projectService.deleteProjectStatusDates(id);
    }

    /**
     * Gets the crew by project id.
     *
     * @param projectId
     *            the project id
     * @return the crew by project id
     */
    @CrossOrigin
    @GetMapping(value = "/projects/{projectId}/crews", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<CrewDto> getCrewByProjectId(final @PathVariable Long projectId) {
        return projectService.getCrewByProjectId(projectId);
    }

    /**
     * Save crew by project id.
     *
     * @param projectId
     *            the project id
     * @param request
     *            the request
     * @return the list
     */
    @CrossOrigin
    @PostMapping(value = "/projects/{projectId}/crews", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public CrewRequestDto saveCrewByProjectId(final @PathVariable Long projectId,
            final @RequestBody CrewRequestDto request) {
        return projectService.saveCrewByProjectId(projectId, request);
    }
    
    /**
     * Gets the crew by project id.
     *
     * @param projectId
     *            the project id
     * @return the crew by project id
     */
    @CrossOrigin
    @GetMapping(value = "/projects/{projectId}/locations", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<LocationPeriodDto> getLocationsByProjectId(final @PathVariable Long projectId) {
        return projectService.getLocationByProjectId(projectId);
    }

    /**
     * Save crew by project id.
     *
     * @param projectId
     *            the project id
     * @param request
     *            the request
     * @return 
     * @return the list
     */
    @CrossOrigin
    @PostMapping(value = "/projects/{projectId}/locations", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public List<LocationPeriodDto> saveLocationsByProjectId(final @PathVariable Long projectId,
            final @RequestBody LocationPeriodDto request) {
        return projectService.saveLocationPeriodsByProjectId(projectId, request);
    }
    
    @CrossOrigin
    @PutMapping(value = "/projects/{projectId}/locations", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public LocationPeriodDto editLocationsByProjectId(final @PathVariable Long projectId,
            final @RequestBody LocationPeriodDto request) {
        return projectService.editLocationPeriodByProjectId(projectId, request);
    }

    /**
     * Gets the project work weeks.
     *
     * @param projectId
     *            the project id
     * @return the project work weeks
     */
    @CrossOrigin
    @GetMapping(value = "/projects/{projectId}/workweeks", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<WorkPeriodDto> getProjectWorkWeeks(@PathVariable Long projectId) {
        return projectService.getProjectWorkWeeks(projectId);
    }

    /**
     * Save project work weeks.
     *
     * @param workPeriod
     *            the work period
     * @return the work period dto
     */
    @CrossOrigin
    @PutMapping(value = "/projects/{projectId}/workweeks", produces = { MediaType.APPLICATION_JSON_VALUE })
    public WorkPeriodDto saveProjectWorkWeek(@RequestBody WorkPeriodDto workPeriod) {
        return projectService.saveProjectWorkWeek(workPeriod);
    }

    /**
     * Delete project work weekby id.
     *
     * @param workPeriodId
     *            the work period id
     */
    @CrossOrigin
    @DeleteMapping(value = "/projects/{projectId}/workweeks/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public void deleteProjectWorkWeekbyId(@PathVariable("id") Long workPeriodId) {
        projectService.deleteProjectWorkWeekbyId(workPeriodId);
    }
}
