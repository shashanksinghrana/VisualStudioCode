package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.UserController;
import com.mediaservices.c2c.fc.dto.UserDto;

// TODO: Auto-generated Javadoc
/**
 * The Class ProjectResourceAssembler.
 */
@Component
public class UserResourceAssembler extends ResourceAssemblerSupport<UserDto, UserDto> {

    /**
     * Instantiates a new party resource assembler.
     */
    public UserResourceAssembler() {
        super(UserController.class, UserDto.class);

    }

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.hateoas.ResourceAssembler#toResource(java.lang.
     * Object)
     */
    @Override
    public UserDto toResource(UserDto project) {
        project.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(UserController.class).getUser())
                .withSelfRel());
        return project;
    }

}
