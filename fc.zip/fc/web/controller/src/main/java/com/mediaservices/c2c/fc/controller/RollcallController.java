package com.mediaservices.c2c.fc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.rollcall.dto.CompanyCommonDto;
import com.mediaservices.c2c.rollcall.dto.CompanyLocationDto;
import com.mediaservices.c2c.rollcall.dto.CountriesDTO;
import com.mediaservices.c2c.rollcall.dto.PersonCommonDto;
import com.mediaservices.c2c.rollcall.dto.StateDTO;
import com.mediaservices.c2c.rollcall.service.CompanyService;
import com.mediaservices.c2c.rollcall.service.PeopleService;
import com.mediaservices.c2c.rollcall.service.PicklistService;

import io.swagger.annotations.Api;

/**
 * The Class RollcallController.
 */
@RestController()
@RequestMapping("/api")
@Api(tags = { "Feature Casting people/company/rollcall APIs" })
public class RollcallController {

    /** The log. */
    private static Logger LOG = LoggerFactory.getLogger(RollcallController.class);

    /** The people service. */
    @Autowired
    private PeopleService peopleService;

    /** The picklist service. */
    @Autowired
    private PicklistService picklistService;

    /** The company service. */
    @Autowired
    private CompanyService companyService;

    /**
     * Save contact person.
     *
     * @param dto
     *            the dto
     * @return the person common dto
     */
    @CrossOrigin
    @RequestMapping(value = "/rollcall/addPerson", method = RequestMethod.POST)
    public PersonCommonDto saveContactPerson(@RequestBody PersonCommonDto dto) {
        LOG.debug("save person");
        return peopleService.savePerson(dto);
    }

    /**
     * Gets the countries pick lists.
     *
     * @return the countries pick lists
     */
    @CrossOrigin
    @GetMapping(value = "/rollcall/picklist/countrystate/COUNTRIES", produces = "application/json")
    public CountriesDTO getCountriesPickLists() {
        LOG.debug("get countries picklists");
        return picklistService.getCountriesPickLists();
    }
    
    @CrossOrigin
	@GetMapping("/rollcall/picklist/{type}")
    public com.mediaservices.c2c.rollcall.dto.PicklistsDTO getPickLists(@PathVariable String type) {
        LOG.debug("PicklistController.getPickListValues() method called passing SysPropId as : "+type);
        return picklistService.getPickListsFromType(type);
    }

    /**
     * Gets the states pick lists.
     *
     * @param countryCode
     *            the country code
     * @return the states pick lists
     */
    @CrossOrigin
    @GetMapping(value = "/rollcall/picklist/countrystate/STATES/{countryCode}", produces = "application/json")
    public List<StateDTO> getStatesPickLists(@PathVariable String countryCode) {
        LOG.debug("get states picklist for country {}", countryCode);
        return picklistService.getStatesPickLists(countryCode);
    }

    /**
     * Gets the company detail.
     *
     * @param partyId
     *            the party id
     * @return the company detail
     */
    @CrossOrigin
    @GetMapping("/companies/{partyId}")
    public CompanyCommonDto getCompanyDetail(@PathVariable Long partyId) {
        return companyService.getCompanyDetail(partyId);
    }

    /**
     * Adds the or edit company.
     *
     * @param companyCreateDto
     *            the company create dto
     * @return the company common dto
     */
    @CrossOrigin
    @RequestMapping(path = "/rollcall/addCompany", method = RequestMethod.POST, produces = "application/json")
    public CompanyCommonDto addOrEditCompany(@RequestBody CompanyCommonDto companyCreateDto) {
        LOG.info("Adding New Company Called.");
        return companyService.addOrEditCompany(companyCreateDto);
    }

    /**
     * Get company locations.
     *
     * @param party
     *            the party
     * @return the party type ahead
     */
    @CrossOrigin
    @GetMapping(path = "/rollcall/company/{id}/locations", produces = "application/hal+json")
    public List<CompanyLocationDto> getLocations(@PathVariable Long id) {
        LOG.info("Get company locations.");
        return companyService.getLocations(id);
    }

    /**
     * Add company location.
     *
     * @param party
     *            the party
     * @return the party type ahead
     */
    @CrossOrigin
    @RequestMapping(path = "/rollcall/company/{id}/addLocation", method = RequestMethod.POST, produces = "application/json")
    public CompanyLocationDto saveLocation(@PathVariable Long id, @RequestBody CompanyLocationDto dto) {
        LOG.info("Add company locations.");
        return companyService.saveLocation(id, dto);
    }
}