package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.DealController;
import com.mediaservices.c2c.fc.dto.CreditDto;

/**
 * The Class CreditResourceAssembler.
 */
@Component
public class CreditResourceAssembler extends ResourceAssemblerSupport<CreditDto, CreditDto> {

	/**
	 * Instantiates a new Credit resource assembler.
	 */
	public CreditResourceAssembler() {
		super(DealController.class, CreditDto.class);

	}

	@Override
	public CreditDto toResource(CreditDto credit) {
		credit.add(ControllerLinkBuilder
				.linkTo(ControllerLinkBuilder.methodOn(DealController.class).getDeal(credit.getDealId()))
				.withSelfRel());
		return credit;
	}

}
