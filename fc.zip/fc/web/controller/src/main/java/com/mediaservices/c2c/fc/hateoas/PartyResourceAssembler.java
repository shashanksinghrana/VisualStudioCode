package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.TalentController;
import com.mediaservices.c2c.fc.dto.PartyDto;

/**
 * The Class PartyResourceAssembler.
 */
@Component
public class PartyResourceAssembler extends ResourceAssemblerSupport<PartyDto, PartyDto> {

    /**
     * Instantiates a new Compensation resource assembler.
     */
    public PartyResourceAssembler() {
        super(TalentController.class, PartyDto.class);

    }

    @Override
    public PartyDto toResource(PartyDto entity) {
        entity.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(TalentController.class).getPerformer(entity.getPartyId()))
                .withSelfRel());
        return entity;
    }

}
