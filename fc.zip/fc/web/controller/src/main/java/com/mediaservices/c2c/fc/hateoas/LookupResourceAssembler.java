package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.LookupController;
import com.mediaservices.c2c.fc.dto.LookupDto;

/**
 * The Class LookupResourceAssembler.
 */
@Component
public class LookupResourceAssembler extends ResourceAssemblerSupport<LookupDto, LookupDto> {

    /**
     * Instantiates a new lookup resource assembler.
     */
    public LookupResourceAssembler() {
        super(LookupController.class, LookupDto.class);

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.hateoas.ResourceAssembler#toResource(java.lang.Object)
     */
    @Override
    public LookupDto toResource(LookupDto lookup) {
        lookup.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(LookupController.class).getLookup(lookup.getLookupId()))
                .withSelfRel());
        return lookup;
    }

}
