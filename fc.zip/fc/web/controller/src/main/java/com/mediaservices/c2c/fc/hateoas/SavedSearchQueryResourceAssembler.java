/*
 * package com.mediaservices.c2c.fc.hateoas;
 * 
 * import org.springframework.hateoas.mvc.ControllerLinkBuilder; import
 * org.springframework.hateoas.mvc.ResourceAssemblerSupport; import
 * org.springframework.stereotype.Component;
 * 
 * import com.mediaservices.c2c.fc.controller.DealController; import
 * com.mediaservices.c2c.fc.controller.PowerSearchController; import
 * com.mediaservices.c2c.fc.dto.PerqDto; import
 * com.mediaservices.c2c.fc.dto.SavedSearchQueryDto;
 * 
 *//**
   * The Class PerqResourceAssembler.
   */
/*
 * @Component public class SavedSearchQueryResourceAssembler extends
 * ResourceAssemblerSupport<SavedSearchQueryDto, SavedSearchQueryDto> {
 * 
 *//**
   * Instantiates a new Compensation resource assembler.
   *//*
     * public SavedSearchQueryResourceAssembler() {
     * super(PowerSearchController.class, SavedSearchQueryDto.class);
     * 
     * }
     * 
     * @Override public SavedSearchQueryDto toResource(SavedSearchQueryDto
     * entity) { entity.add(ControllerLinkBuilder
     * .linkTo(ControllerLinkBuilder.methodOn(PowerSearchController.class).)
     * .withSelfRel()); return entity; }
     * 
     * }
     */