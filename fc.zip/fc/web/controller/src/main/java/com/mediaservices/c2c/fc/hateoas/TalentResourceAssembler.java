package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

import com.mediaservices.c2c.fc.controller.TalentController;
import com.mediaservices.c2c.fc.dto.LoanoutDto;

public class TalentResourceAssembler extends ResourceAssemblerSupport<LoanoutDto, LoanoutDto> {

	public TalentResourceAssembler(){
		super(TalentController.class, LoanoutDto.class);
	}

	@Override
	public LoanoutDto toResource(LoanoutDto entity) {


		entity.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(TalentController.class).getTalent(entity.getPartyID())).withSelfRel());
		return entity;
	}

}
