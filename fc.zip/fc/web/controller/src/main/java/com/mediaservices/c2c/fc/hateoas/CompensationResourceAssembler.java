package com.mediaservices.c2c.fc.hateoas;

import static com.mediaservices.c2c.fc.utils.NumberUtil.stringToLong;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.DealController;
import com.mediaservices.c2c.fc.dto.CompensationDto;

/**
 * The Class CompensationResourceAssembler.
 */
@Component
public class CompensationResourceAssembler extends ResourceAssemblerSupport<CompensationDto, CompensationDto> {

    /**
     * Instantiates a new Compensation resource assembler.
     */
    public CompensationResourceAssembler() {
        super(DealController.class, CompensationDto.class);

    }

    @Override
    public CompensationDto toResource(CompensationDto entity) {
        entity.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(DealController.class)
                .getCompensation(stringToLong(entity.getCompensationId()))).withSelfRel());
        return entity;
    }

}
