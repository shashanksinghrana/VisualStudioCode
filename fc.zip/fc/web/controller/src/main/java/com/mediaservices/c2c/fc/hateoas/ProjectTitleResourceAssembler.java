package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.ProjectTitleController;
import com.mediaservices.c2c.fc.dto.ProjectTitleDto;

/**
 * The Class ProjectTitleResourceAssembler.
 */
@Component
public class ProjectTitleResourceAssembler extends ResourceAssemblerSupport<ProjectTitleDto, ProjectTitleDto> {

    /**
     * Instantiates a new party resource assembler.
     */
    public ProjectTitleResourceAssembler() {
        super(ProjectTitleController.class, ProjectTitleDto.class);

    }

    @Override
    public ProjectTitleDto toResource(ProjectTitleDto title) {
        title.add(ControllerLinkBuilder.linkTo(
                ControllerLinkBuilder.methodOn(ProjectTitleController.class).getProjectTitle(title.getProjectTitleId()))
                .withSelfRel());
        return title;
    }

}
