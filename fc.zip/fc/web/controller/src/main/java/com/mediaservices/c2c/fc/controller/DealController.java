package com.mediaservices.c2c.fc.controller;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.Resources;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.constants.Constants;
import com.mediaservices.c2c.fc.dto.CompensationDto;
import com.mediaservices.c2c.fc.dto.CreditDto;
import com.mediaservices.c2c.fc.dto.DealDto;
import com.mediaservices.c2c.fc.dto.FormulaDto;
import com.mediaservices.c2c.fc.dto.LoanoutDto;
import com.mediaservices.c2c.fc.dto.PerformerDealDto;
import com.mediaservices.c2c.fc.dto.PerformerGridSearchCriteria;
import com.mediaservices.c2c.fc.dto.PerqDto;
import com.mediaservices.c2c.fc.dto.RepresentationDetailDto;
import com.mediaservices.c2c.fc.dto.RepresentationDto;
import com.mediaservices.c2c.fc.dto.RepresentativeDto;
import com.mediaservices.c2c.fc.dto.RepresentativeMinimalDto;
import com.mediaservices.c2c.fc.dto.WizardDto;
import com.mediaservices.c2c.fc.dto.WorkActivityDto;
import com.mediaservices.c2c.fc.hateoas.CompensationResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.CreditResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.DealResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.FormulaResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.PerformerDealResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.PerqResourceAssembler;
import com.mediaservices.c2c.fc.hateoas.WizardResourceAssembler;
import com.mediaservices.c2c.fc.service.DealService;
import com.mediaservices.c2c.fc.service.FormulaService;
import com.mediaservices.c2c.fc.service.PerqService;
import com.mediaservices.c2c.fc.service.RepresentationService;
import com.mediaservices.c2c.fc.service.TalentService;
import com.mediaservices.c2c.fc.service.WizardService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class DealController.
 */
@RestController()
@RequestMapping("/api")
@Api(tags = { "Deals" })
public class DealController {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(DealController.class);

    /** The representation service. */
    @Autowired
    private RepresentationService representationService;

    /** The deal service. */
    @Autowired
    private DealService dealService;

    /** The perq service. */
    @Autowired
    private PerqService perqService;

    /** The wizard service. */
    @Autowired
    private WizardService wizardService;

    /** The formula service. */
    @Autowired
    private FormulaService formulaService;

    /** The deal assembler. */
    @Autowired
    private DealResourceAssembler dealAssembler;

    /** The performer deal assembler. */
    @Autowired
    private PerformerDealResourceAssembler performerDealAssembler;

    /** The paged performer deal assembler. */
    @Autowired
    private PagedResourcesAssembler<PerformerDealDto> pagedPerformerDealAssembler;

    /** The wizard assembler. */
    @Autowired
    private WizardResourceAssembler wizardAssembler;

    /** The formula assembler. */
    @Autowired
    private FormulaResourceAssembler formulaAssembler;

    /** The compensation assembler. */
    @Autowired
    private CompensationResourceAssembler compensationAssembler;

    /** The perq assembler. */
    @Autowired
    private PerqResourceAssembler perqAssembler;

    /** The credit assembler. */
    @Autowired
    private CreditResourceAssembler creditAssembler;

    /** The talent service. */
    @Autowired
    @Qualifier("fcTalentService")
    private TalentService talentService;

    /**
     * Gets the deal.
     *
     * @param id
     *            the id
     * @return the deal
     */
    @CrossOrigin
    @GetMapping(value = "/deal/{id}")
    @ApiOperation(value = "get deal details based on ID")
    public DealDto getDeal(@PathVariable @ApiParam(value = "The id of the get deal details") Long id) {
        return dealAssembler.toResource(dealService.getDeal(id));
    }

    /**
     * Save deal.
     *
     * @param deal
     *            the deal
     * @return the deal dto
     */
    @CrossOrigin
    @PutMapping(value = "/deal", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ApiOperation(value = "Save deal")
    public DealDto saveDeal(@RequestBody DealDto deal) {
        return dealAssembler.toResource(dealService.saveDeal(deal));
    }

    /**
     * Delete deal.
     *
     * @param dealId
     *            the deal id
     */
    @CrossOrigin
    @DeleteMapping(value = "/deals/{dealId}")
    public void deleteDeal(@PathVariable @ApiParam(value = "The id of the deal to be deleted") Long dealId) {
        dealService.deleteDeal(dealId);
    }

    /**
     * Gets the performer grid.
     *
     * @param pageable
     *            the pageable
     * @param id
     *            the id
     * @param criteria
     *            the criteria
     * @return the performer grid
     */
    @CrossOrigin
    @GetMapping(value = "/performerDeals/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })

    public PagedResources<PerformerDealDto> getPerformerGrid(
            @PageableDefault(size = Constants.DEFAULT_RECORD_COUNT, page = 0, direction = Direction.ASC, sort = "performerName") Pageable pageable,
            @PathVariable Long id, PerformerGridSearchCriteria criteria) {
        LOG.debug("Getting Performers Grid for project id {{}}", id);

        final Page<PerformerDealDto> performerDeals = dealService.getPerformerDealsByProjectId(id, pageable, criteria);
        return pagedPerformerDealAssembler.toResource(performerDeals, performerDealAssembler);
    }

    /**
     * Gets the performer deal.
     *
     * @param id
     *            the id
     * @return the performer deal
     */
    @CrossOrigin
    @GetMapping(value = "/performerDeal/{id}")
    public PerformerDealDto getPerformerDeal(@PathVariable Long id) {
        return performerDealAssembler.toResource(dealService.getPerformerDealByDealId(id));
    }

    /**
     * Gets the wizard pages.
     *
     * @param formType
     *            the form type
     * @param type
     *            the type
     * @param id
     *            the id
     * @param studioId
     *            the studio id
     * @return the wizard pages
     */
    @CrossOrigin
    @GetMapping(value = "/wizards", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Resources<WizardDto> getWizardPages(@RequestParam(required = true) String formType,
            @RequestParam(required = true) String type, @RequestParam(required = false) Long id,
            @RequestParam(required = false) Long studioId) {
        final Set<WizardDto> wizards = wizardService.getWizardForDeal(id, studioId, type, formType);
        return new Resources<>(wizardAssembler.toResources(wizards), ControllerLinkBuilder.linkTo(
                ControllerLinkBuilder.methodOn(DealController.class).getWizardPages(formType, type, studioId, id))
                .withSelfRel());
    }

    /**
     * Gets the wizard.
     *
     * @param id
     *            the id
     * @param wizardType
     *            the wizard type
     * @return the wizard
     */
    @CrossOrigin
    @GetMapping(value = "/wizard/{id}")
    public WizardDto getWizard(@PathVariable Long id, @RequestParam(required = true) String wizardType) {
        return wizardAssembler.toResource(wizardService.getWizardByIdAndType(id, wizardType));
    }

    /**
     * Save wizard status.
     *
     * @param wizard
     *            the wizard
     * @return the wizard dto
     */
    @CrossOrigin
    @PutMapping(value = "/wizard", consumes = { MediaType.APPLICATION_JSON_VALUE })
    public WizardDto saveWizardStatus(@RequestBody WizardDto wizard) {
        return wizardAssembler.toResource(wizardService.saveWizardStatus(wizard));

    }

    /**
     * Gets the formulas.
     *
     * @param dealType
     *            the deal type
     * @param pageType
     *            the page type
     * @param feeType
     *            the fee type
     * @param studioId
     *            the studio id
     * @return the formulas
     */
    @CrossOrigin
    @GetMapping(value = "/formulas", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Resources<FormulaDto> getFormulas(@RequestParam(required = true) String dealType,
            @RequestParam(required = true) String pageType, @RequestParam(required = false) Long feeType,
            @RequestParam(required = false) Long studioId) {
        LOG.debug("getFromulas with param: DealType - " + dealType + ", pageType - " + pageType + ", FeeType - "
                + feeType + ", studioId - " + studioId);
        final List<FormulaDto> formulas = formulaService.getFormulas(dealType, pageType, feeType, studioId);
        return new Resources<>(formulaAssembler.toResources(formulas), ControllerLinkBuilder.linkTo(
                ControllerLinkBuilder.methodOn(DealController.class).getFormulas(dealType, pageType, feeType, studioId))
                .withSelfRel());
    }

    /**
     * Gets the formula.
     *
     * @param id
     *            the id
     * @return the formula
     */
    @CrossOrigin
    @GetMapping(value = "/formula/{id}")
    public FormulaDto getFormula(@PathVariable Long id) {
        return formulaAssembler.toResource(formulaService.getFormulaById(id));
    }

    /**
     * Gets the compensations by deal id.
     *
     * @param id
     *            the id
     * @return the compensations by deal id
     */
    @CrossOrigin
    @GetMapping(value = "/compensations/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Resources<CompensationDto> getCompensationsByDealId(@PathVariable("id") Long id) {
        final List<CompensationDto> compSet = dealService.getCompensationByDealId(id);
        return new Resources<>(compensationAssembler.toResources(compSet),
                ControllerLinkBuilder
                        .linkTo(ControllerLinkBuilder.methodOn(DealController.class).getCompensationsByDealId(id))
                        .withSelfRel());

    }

    /**
     * Save compensation.
     *
     * @param compensation
     *            the compensation
     * @return the compensation dto
     */
    @CrossOrigin
    @PutMapping(value = "/compensation", produces = { MediaType.APPLICATION_JSON_VALUE })
    public CompensationDto saveCompensation(@RequestBody CompensationDto compensation) {
        return compensationAssembler.toResource(dealService.saveCompensation(compensation));
    }

    /**
     * Save compensations.
     *
     * @param compensationSet
     *            the compensation set
     * @param dealId
     *            the deal id
     * @return the resources
     */
    @CrossOrigin
    @PutMapping(value = "deals/{dealId}/compensations", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Resources<CompensationDto> saveCompensations(@RequestBody List<CompensationDto> compensationSet,
            @PathVariable("dealId") Long dealId) {
        final List<CompensationDto> savedSet = dealService.saveCompensations(compensationSet, Collections.emptyList(),
                dealId);
        return new Resources<>(compensationAssembler.toResources(savedSet),
                ControllerLinkBuilder.linkTo(
                        ControllerLinkBuilder.methodOn(DealController.class).saveCompensations(compensationSet, dealId))
                        .withSelfRel());
    }

    /**
     * Gets the compensation.
     *
     * @param id
     *            the id
     * @return the compensation
     */
    @CrossOrigin
    @GetMapping(value = "/compensation/{id}")
    public CompensationDto getCompensation(@PathVariable("id") Long id) {
        return compensationAssembler.toResource(dealService.getCompensation(id));
    }

    /**
     * Save credit.
     *
     * @param credit
     *            the credit
     * @return the credit dto
     */
    @CrossOrigin
    @PostMapping(value = "/credit")
    public CreditDto saveCredit(@RequestBody CreditDto credit) {
        return creditAssembler.toResource(dealService.saveCredit(credit));
    }

    /**
     * Gets the credit.
     *
     * @param id
     *            the id
     * @return the credit
     */
    @CrossOrigin
    @GetMapping(value = "/credit/{id}")
    public CreditDto getCredit(@PathVariable("id") Long id) {
        return creditAssembler.toResource(dealService.getCredit(id));
    }

    /**
     * Save perqs.
     *
     * @param id
     *            the id
     * @param perqSet
     *            the perq set
     * @return the list
     */
    @CrossOrigin
    @PutMapping(value = "/perqs/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<PerqDto> savePerqs(@PathVariable Long id, @RequestBody List<PerqDto> perqSet) {
        return perqService.savePerqs(perqSet, id);
    }

    /**
     * Gets the perqs by deal id.
     *
     * @param id
     *            the id
     * @return the perqs by deal id
     */
    @CrossOrigin
    @GetMapping(value = "/perqs/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Resources<PerqDto> getPerqsByDealId(@PathVariable Long id) {
        final List<PerqDto> perqSet = perqService.getPerqsByDealId(id);
        return new Resources<>(perqAssembler.toResources(perqSet), ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DealController.class).getPerqsByDealId(id)).withSelfRel());
    }

    /**
     * Gets the perq.
     *
     * @param id
     *            the id
     * @return the perq
     */
    @CrossOrigin
    @GetMapping(value = "/perq/{id}")
    public PerqDto getPerq(@PathVariable("id") Long id) {
        return perqAssembler.toResource(perqService.getPerq(id));
    }

    /**
     * Gets the selected company.
     *
     * @param id
     *            the id
     * @return the selected company
     */
    @CrossOrigin
    @GetMapping(value = "/company/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public RepresentativeMinimalDto getSelectedCompany(@PathVariable("id") Long id) {
        return representationService.getSelectedCompany(id);
    }

    /**
     * Gets the selected rep.
     *
     * @param dealId
     *            the deal id
     * @param repId
     *            the rep id
     * @return the selected rep
     */
    // Failing
    @CrossOrigin
    @GetMapping(value = "/deal/{dealId}/rep/{repId}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public RepresentativeMinimalDto getSelectedRep(@PathVariable("dealId") Long dealId,
            @PathVariable("repId") Long repId) {
        return representationService.getSelectedRepresentative(dealId, repId);
    }

    /**
     * Adds the rep.
     *
     * @param repDetail
     *            the rep detail
     * @return the representative dto
     */
    @CrossOrigin
    @PutMapping(value = "/rep/add", produces = { MediaType.APPLICATION_JSON_VALUE })
    public RepresentativeDto addRep(@RequestBody RepresentationDetailDto repDetail) {
        return representationService.addRepresentative(repDetail);
    }

    /**
     * Removes the rep.
     *
     * @param dealId
     *            the deal id
     * @param repId
     *            the rep id
     */
    @CrossOrigin
    @DeleteMapping(value = "/deal/{dealId}/rep/{repId}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public void removeRep(@PathVariable("dealId") Long dealId, @PathVariable("repId") Long repId) {
        representationService.deleteRepresentative(dealId, repId);
    }

    /**
     * Save representation.
     *
     * @param dealId
     *            the deal id
     * @param representaionDto
     *            the representaion dto
     * @return the list
     */
    @CrossOrigin
    @PutMapping(value = "deal/{dealId}/reps", produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<RepresentationDetailDto> saveRepresentation(@PathVariable("dealId") Long dealId,
            @RequestBody List<RepresentationDetailDto> representaionDto) {
        return representationService.saveRepresentatives(dealId, representaionDto);
    }

    /**
     * Gets the representation.
     *
     * @param dealId
     *            the deal id
     * @return the representation
     */
    @CrossOrigin
    @GetMapping(value = "/rep/{dealId}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public RepresentationDto getRepresentation(@PathVariable("dealId") Long dealId) {
        return representationService.getRepresentatives(dealId);
    }

    /**
     * Gets the representation.
     *
     * @param repId
     *            the rep id
     * @param typeId
     *            the type id
     * @return the representation
     */
    @CrossOrigin
    @GetMapping(value = "/reps/{repId}/details", produces = { MediaType.APPLICATION_JSON_VALUE })
    public RepresentativeDto getRepresentationDetails(@PathVariable("repId") Long repId,
            @RequestParam(name = "type") String type) {
        return representationService.getRepresentativeDetail(repId, type);
    }

    /**
     * Save work activities.
     *
     * @param dealId
     *            the deal id
     * @param workactivitySet
     *            the workactivity set
     * @return the resources
     */
    @CrossOrigin
    @PutMapping(value = "/deals/{dealId}/workActivities", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Resources<WorkActivityDto> saveWorkActivities(@PathVariable("dealId") Long dealId,
            @RequestBody Set<WorkActivityDto> workactivitySet) {
        final Set<WorkActivityDto> workActivities = dealService.saveWorkActivities(dealId, workactivitySet);
        return new Resources<>(workActivities);
    }

    /**
     * Gets the work eligibility by deal id.
     *
     * @param dealId
     *            the deal id
     * @return the work eligibility by deal id
     */
    @CrossOrigin
    @GetMapping(value = "/deals/{dealId}/workActivities", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Resources<WorkActivityDto> getWorkEligibilityByDealId(@PathVariable("dealId") Long dealId) {
        final List<WorkActivityDto> compSet = dealService.getWorkActivityByDealId(dealId);
        return new Resources<>(compSet);
    }

    /**
     * Gets the loanout.
     *
     * @param dealId
     *            the deal id
     * @return the loanout
     */
    @CrossOrigin
    @GetMapping(value = "/deals/{dealId}/loanouts")
    public LoanoutDto getLoanout(@PathVariable("dealId") Long dealId) {
        return dealService.getDealLoanout(dealId);
    }

    /**
     * Save loanout.
     *
     * @param dealId
     *            the deal id
     * @param loanout
     *            the loanout
     * @return the deal dto
     */
    @CrossOrigin
    @PutMapping(value = "/deals/{dealId}/loanouts")
    public DealDto saveLoanout(@PathVariable("dealId") Long dealId, @RequestBody LoanoutDto loanout) {
        return dealService.updateDealLoanout(loanout, dealId);
    }

}