package com.mediaservices.c2c.fc.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.dto.CompensationDto;
import com.mediaservices.c2c.fc.dto.ContractRiderDto;
import com.mediaservices.c2c.fc.dto.DealContractTermDto;
import com.mediaservices.c2c.fc.service.ContractService;

/**
 * Contract Controller class which handles all project related requests.
 */
@RestController
@RequestMapping("/api")
public class ContractController {

    /**
     * Contract Service
     */
    @Autowired
    private ContractService contractService;

    /**
     * Saves contract.
     *
     * @param contract
     *            the contract
     * @param dealId
     *            the deal id
     * @return contractDto
     */
    @CrossOrigin
    @PutMapping(value = "/deals/{dealId}/contractTerms", produces = { MediaType.APPLICATION_JSON_VALUE })
    public DealContractTermDto saveContractTerm(@RequestBody DealContractTermDto contract,
            @PathVariable("dealId") Long dealId) {
        return contractService.saveContractTerm(contract, dealId);
    }

    /**
     * Saves contract.
     *
     * @param contract
     *            the contract
     * @return contractDto
     */
    @CrossOrigin
    @GetMapping(value = "/deals/{dealId}/contractTerms", produces = { MediaType.APPLICATION_JSON_VALUE })
    public DealContractTermDto getContractTerm(@PathVariable("dealId") Long dealId) {
        return contractService.getContractTerm(dealId);
    }

    /**
     * Get All Contract Riders.
     *
     * @param contract
     *            the contract
     * @return contractDto
     */
    @CrossOrigin
    @GetMapping(value = "/contractRiders", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Set<ContractRiderDto> getContractRiders() {
        return contractService.getContractRiders();
    }

    /**
     * Generate Contract.
     *
     * @param contract
     *            the contract
     * @return contractDto
     */
    @CrossOrigin
    @PostMapping(value = "deals/{dealId}/contracts/{contractLookupId}", produces = { "application/pdf" })
    public byte[] generateContract(@RequestBody CompensationDto compensationDto, @PathVariable("dealId") Long dealId,
            @PathVariable("contractLookupId") Long contractLookupId) {
        return contractService.generateContract(dealId, contractLookupId, compensationDto);
    }
}
