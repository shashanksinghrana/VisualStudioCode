package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.DealController;
import com.mediaservices.c2c.fc.dto.WizardDto;

/**
 * The Class LookupResourceAssembler.
 */
@Component
public class WizardResourceAssembler extends ResourceAssemblerSupport<WizardDto, WizardDto> {

    /**
     * Instantiates a new lookup resource assembler.
     */
    public WizardResourceAssembler() {
        super(DealController.class, WizardDto.class);

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.hateoas.ResourceAssembler#toResource(java.lang.Object)
     */
    @Override
    public WizardDto toResource(WizardDto lookup) {
        lookup.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(DealController.class)
                .getWizard(lookup.getWizardId(), lookup.getWizardType())).withSelfRel());
        return lookup;
    }

}
