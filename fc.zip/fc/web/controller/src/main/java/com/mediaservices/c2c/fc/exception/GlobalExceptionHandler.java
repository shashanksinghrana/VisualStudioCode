package com.mediaservices.c2c.fc.exception;

import static com.mediaservices.c2c.fc.enums.ErrorCode.INTERNAL_SERVER_ERROR;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.mediaservices.c2c.fc.enums.ErrorCode;
import com.mediaservices.c2c.fc.error.dto.ErrorResponseDto;
import com.mediaservices.c2c.fc.execption.FcApplicationException;

@ControllerAdvice
public class GlobalExceptionHandler {

    /** The Constant LOGGER. */
    private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /** The message source. */
    @Autowired
    private MessageSource messageSource;

    /**
     * This method is handler for generic Exceptions.
     *
     * @param exception
     *            that needs to be handled
     * @param request
     *            the request
     * @return ErrorResponse that needs to be send back
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponseDto exceptionHandler(final Exception exception, final HttpServletRequest request) {
        return handleException(exception, INTERNAL_SERVER_ERROR, request, null);
    }

    /**
     * This method is handler for Exceptions arising from an application.
     *
     * @param exception
     *            that has been thrown
     * @param request
     *            the request
     * @return ErrorResponse response to send back
     */
    @ExceptionHandler(FcApplicationException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponseDto FCApplicationExceptionHandler(final FcApplicationException exception,
            final HttpServletRequest request) {
        return handleException(exception, exception.getErrorCode(), request, exception.getField());
    }

    /**
     * Handle http message not readable exception.
     *
     * @param exception
     *            the exception
     * @param request
     *            the request
     * @return the error response
     */
    @ExceptionHandler(value = HttpMessageNotReadableException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponseDto handleHttpMessageNotReadableException(final HttpMessageNotReadableException exception,
            final HttpServletRequest request) {
        ErrorCode errorCode = INTERNAL_SERVER_ERROR;
        ErrorResponseDto response = handleException(exception, errorCode, request, null);
        response.getErrors().get(0).setDetail(exception.getMostSpecificCause().getLocalizedMessage());
        return response;
    }

    /**
     * Validation exception handler.
     *
     * @param exception
     *            validation exception
     * @param request
     *            the request
     * @return ErrorResponse response to send back
     */
    @ExceptionHandler(value = { MethodArgumentNotValidException.class })
    @ResponseBody
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ErrorResponseDto handleValidationException(final MethodArgumentNotValidException exception,
            final HttpServletRequest request) {
        final String errorId = logException(exception, request, INTERNAL_SERVER_ERROR, null);
        final ErrorResponseDto error = processBindingResult(exception.getBindingResult());
        error.setErrorId(errorId);
        return error;
    }

    /**
     * Parameter binding exception handler.
     *
     * @param exception
     *            binding exception
     * @param request
     *            the request
     * @return ErrorResponse response to send back
     */
    @ExceptionHandler(value = { BindException.class })
    @ResponseBody
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ErrorResponseDto handleBindingException(final BindException exception, HttpServletRequest request) {
        final String errorId = logException(exception, request, INTERNAL_SERVER_ERROR, null);
        final ErrorResponseDto error = processBindingResult(exception.getBindingResult());
        error.setErrorId(errorId);
        return error;
    }

    /**
     * Process binding result for error response.
     *
     * @param bindingResult
     *            to operate on
     * @return error response built from binding result
     */
    private ErrorResponseDto processBindingResult(final BindingResult bindingResult) {
        final ErrorResponseDto errorResponse = new ErrorResponseDto();
        sortFieldErrors(bindingResult.getFieldErrors()).stream()
                .forEach(fieldError -> errorResponse.addError(fieldError.getDefaultMessage(),
                        messageSource.getMessage(fieldError.getDefaultMessage(), null, fieldError.getDefaultMessage(),
                                Locale.getDefault()),
                        null));
        return errorResponse;
    }

    /**
     * Sort field errors on each field name.
     *
     * @param validationErrors
     *            the validation errors
     * @return the list
     */
    private List<FieldError> sortFieldErrors(final List<FieldError> validationErrors) {
        final List<FieldError> errors = new ArrayList<>(validationErrors);
        errors.sort(new Comparator<FieldError>() {
            @Override
            public int compare(FieldError fieldError1, FieldError fieldError2) {
                return fieldError1.getField().compareTo(fieldError2.getField());
            }
        });
        return errors;
    }

    /**
     * This method is handler for generic Exceptions.
     *
     * @param exception
     *            that needs to be handled
     * @param errorCode
     *            the error code
     * @param request
     *            the request
     * @param otherErrorLog
     *            the other error log
     * @return ErrorResponse that needs to be send back
     */
    private ErrorResponseDto handleException(final Exception exception, final ErrorCode errorCode,
            HttpServletRequest request, String field) {
        final String errorId = logException(exception, request, errorCode, null);
        final ErrorResponseDto errorResponse = new ErrorResponseDto();
        errorResponse.addError(errorCode.getErrorCode(), exception.getMessage(), field);
        errorResponse.setErrorId(errorId);
        return errorResponse;
    }

    /**
     * This method is used to log Exceptions.
     *
     * @param exception
     *            that needs to be logged
     * @param request
     *            the request
     * @param otherErrorLog
     *            the other error log
     * @return Error id
     */
    private String logException(final Throwable exception, final HttpServletRequest request, final ErrorCode errorCode,
            final String otherErrorLog) {
        if (otherErrorLog != null) {
            LOG.error(otherErrorLog);
        }
        final String errorId = ErrorTokenGenerator.getErrorId();
        final StringBuilder error = new StringBuilder("Error id->" + errorId);
        error.append("\n" + exception.getLocalizedMessage());
        LOG.error(error.toString(), exception);
        return errorId;
    }
}
