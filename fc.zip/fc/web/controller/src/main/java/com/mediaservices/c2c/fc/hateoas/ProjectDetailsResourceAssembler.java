package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.ProjectController;
import com.mediaservices.c2c.fc.dto.ProjectDetailsDto;

// TODO: Auto-generated Javadoc
/**
 * The Class ProjectDetailsResourceAssembler.
 */
@Component
public class ProjectDetailsResourceAssembler extends ResourceAssemblerSupport<ProjectDetailsDto, ProjectDetailsDto> {

    /**
     * Instantiates a new party resource assembler.
     */
    public ProjectDetailsResourceAssembler() {
        super(ProjectController.class, ProjectDetailsDto.class);

    }

    /*
     * (non-Javadoc)
     *
     * @see
     * org.springframework.hateoas.ResourceAssembler#toResource(java.lang.Object)
     */
    @Override
    public ProjectDetailsDto toResource(ProjectDetailsDto project) {
        project.add(ControllerLinkBuilder.linkTo(
                ControllerLinkBuilder.methodOn(ProjectController.class).getProjectDetails(project.getProjectId()))
                .withSelfRel());
        return project;
    }

}
