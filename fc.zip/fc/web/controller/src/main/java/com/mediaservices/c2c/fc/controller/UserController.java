package com.mediaservices.c2c.fc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.Resources;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.constants.Constants;
import com.mediaservices.c2c.fc.dto.FcUser;
import com.mediaservices.c2c.fc.dto.UserDto;
import com.mediaservices.c2c.fc.hateoas.UserResourceAssembler;
import com.mediaservices.c2c.fc.service.AuthorizationService;
import com.mediaservices.c2c.fc.service.UserService;

// TODO: Auto-generated Javadoc
/**
 * The Class UserController.
 */
@RestController()
@RequestMapping("/api")
public class UserController {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(UserController.class);

    /** The user service. */
    @Autowired
    private UserService userService;

    @Autowired
    private AuthorizationService authorizationService;

    /** The resource assembler. */
    @Autowired
    private UserResourceAssembler resourceAssembler;

    /** The page assember. */
    @Autowired
    private PagedResourcesAssembler<UserDto> pageAssembler;

    /**
     * Gets All the User's with Feature Casting Admin or Owner roles.
     *
     * @return All the Users with Feature Casting Admin or Owner roles
     */
    @CrossOrigin
    @RequestMapping(value = "/assignedToUsers", method = RequestMethod.GET, produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public Resources<UserDto> getAssignedToUsers() {
        LOG.debug("Assigned to User - REQUEST MADE");
        List<String> roleList = new ArrayList<>();
        roleList.add(Constants.USER_ROLE_FC_ADMIN);
        roleList.add(Constants.USER_ROLE_FC_OWNER);
        Set<UserDto> users = userService.getUsersByRoles(roleList);

        // add HateosLinks
        return new Resources<>(resourceAssembler.toResources(users), ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(UserController.class).getAssignedToUsers()).withSelfRel());

    }

    /**
     * Gets the user.
     *
     * @param id
     *            the id
     * @return the UserDto
     */
    @CrossOrigin
    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public FcUser getUser() {
        return authorizationService.getLoggedInUser();
    }

    /*    *//**
             * Gets the user info for the logged in User.
             *
             * @return the user info
             */
    /*
     * @CrossOrigin
     *
     * @RequestMapping(value = "/user", method = RequestMethod.GET, produces =
     * "application/json") public FcUser getUserInfo() { return
     * authorizationService.getLoggedInUser(); }
     *
     *//**
       *
       * Gets the username info for the logged in User.
       *
       * @return the user name info
       *//*
         *
         * @CrossOrigin
         *
         * @RequestMapping(value = "/user/username", method = RequestMethod.GET,
         * produces = "application/json") public String getUserNameInfo() {
         *
         * return authorizationService.getLoggedInUserId(); }
         */

}
