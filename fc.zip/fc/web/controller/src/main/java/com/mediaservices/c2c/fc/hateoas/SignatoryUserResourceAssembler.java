package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.LookupController;
import com.mediaservices.c2c.fc.dto.SignatoryUserDto;

/**
 * The Class SignatoryUserResourceAssembler.
 */
@Component
public class SignatoryUserResourceAssembler extends ResourceAssemblerSupport<SignatoryUserDto, SignatoryUserDto> {

    /**
     * Instantiates a new lookup resource assembler.
     */
    public SignatoryUserResourceAssembler() {
        super(LookupController.class, SignatoryUserDto.class);

    }

    @Override
    public SignatoryUserDto toResource(SignatoryUserDto user) {
        user.add(ControllerLinkBuilder.linkTo(
                ControllerLinkBuilder.methodOn(LookupController.class).getSignatoryUser(user.getSignatoryUserId()))
                .withSelfRel());
        return user;
    }

}
