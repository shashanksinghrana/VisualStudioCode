package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.DealController;
import com.mediaservices.c2c.fc.dto.CompensationDto;
import com.mediaservices.c2c.fc.dto.LoanoutDto;

/**
 * The Class CompensationResourceAssembler.
 */
@Component
public class LoanoutResourceAssembler extends ResourceAssemblerSupport<LoanoutDto, LoanoutDto> {

    /**
     * Instantiates a new Compensation resource assembler.
     */
    public LoanoutResourceAssembler() {
        super(DealController.class, LoanoutDto.class);

    }

    @Override
    public LoanoutDto toResource(LoanoutDto entity) {
        entity.add(ControllerLinkBuilder.linkTo(
                ControllerLinkBuilder.methodOn(DealController.class).getLoanout(entity.getDealId()))
                .withSelfRel());
        return entity;
    }    

}
