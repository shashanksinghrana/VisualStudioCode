package com.mediaservices.c2c.fc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.dto.ApplicationInfoDto;
import com.mediaservices.c2c.fc.hateoas.ApplicationInfoResourceAssembler;
import com.mediaservices.c2c.fc.service.ApplicationInfoService;

// TODO: Auto-generated Javadoc
/**
 * The Class ApplicationInfoController.
 */
@RestController()
@RequestMapping("/api")
public class ApplicationInfoController {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory.getLogger(ApplicationInfoController.class);

    /** ApplicationInfo Service */
    @Autowired
    private ApplicationInfoService fcApplicationInfoService;

    /** The resource assembler. */
    @Autowired
    private ApplicationInfoResourceAssembler resourceAssembler;

    /**
     * Gets version inof.
     *
     * @return the ApplicationinfDto
     */
    @CrossOrigin
    @RequestMapping(value = "/versionInfo", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
    public ApplicationInfoDto getVersionInfo() {
        LOG.debug("VERSION INFO REQUEST MADE");

        return resourceAssembler.toResource(fcApplicationInfoService.getVersionInfo());

    }

}
