package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.DealController;
import com.mediaservices.c2c.fc.dto.PerqDto;

/**
 * The Class PerqResourceAssembler.
 */
@Component
public class PerqResourceAssembler extends ResourceAssemblerSupport<PerqDto, PerqDto> {

    /**
     * Instantiates a new Compensation resource assembler.
     */
    public PerqResourceAssembler() {
        super(DealController.class, PerqDto.class);

    }

    @Override
    public PerqDto toResource(PerqDto entity) {
        entity.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DealController.class).getPerq(entity.getPerqId()))
                .withSelfRel());
        return entity;
    }

}
