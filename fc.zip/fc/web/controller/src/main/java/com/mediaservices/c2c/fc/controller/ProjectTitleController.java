package com.mediaservices.c2c.fc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resources;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mediaservices.c2c.fc.dto.ProjectTitleDto;
import com.mediaservices.c2c.fc.hateoas.ProjectTitleResourceAssembler;
import com.mediaservices.c2c.fc.service.ProjectTitleService;

/**
 * Project Title Controller class which handles all project title related
 * requests.
 */
@RestController()
@RequestMapping("/api")
public class ProjectTitleController {

    /** The project service. */
    @Autowired
    private ProjectTitleService projectTitleService;

    /** The resource assembler. */
    @Autowired
    private ProjectTitleResourceAssembler resourceAssembler;

    @CrossOrigin
    @RequestMapping(value = "/typeAhead/projectTitles", method = RequestMethod.GET, produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public Resources<ProjectTitleDto> getProjectTitleTypeAhead(@RequestParam String searchTerm,
            @RequestParam int recordCount) {

        List<ProjectTitleDto> parties = projectTitleService.getProjectTitles(searchTerm, recordCount);

        // add HateosLinks to project list in projects
        return new Resources<>(resourceAssembler.toResources(parties),
                ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(ProjectTitleController.class)
                        .getProjectTitleTypeAhead(searchTerm, recordCount)).withSelfRel());

    }

    /**
     * Gets the project.
     *
     * @param id
     *            the id
     * @return the project
     */
    @CrossOrigin
    @RequestMapping(value = "/projectTitle/{id}", method = RequestMethod.GET)
    public ProjectTitleDto getProjectTitle(@PathVariable Long id) {
        return resourceAssembler.toResource(projectTitleService.getProjectTitleById(id));
    }

    @CrossOrigin
    @RequestMapping(value = "/projectAkas/{id}", method = RequestMethod.GET, produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public Resources<ProjectTitleDto> getProjectAkasByProject(@PathVariable Long id) {
        List<ProjectTitleDto> akas = projectTitleService.getProjectAkasByProjectId(id);
        return new Resources<>(resourceAssembler.toResources(akas),
                ControllerLinkBuilder.linkTo(
                        ControllerLinkBuilder.methodOn(ProjectTitleController.class).getProjectAkasByProject(id))
                        .withSelfRel());
    }

}
