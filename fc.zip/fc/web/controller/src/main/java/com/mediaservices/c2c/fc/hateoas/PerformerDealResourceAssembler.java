package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.DealController;
import com.mediaservices.c2c.fc.dto.PerformerDealDto;

// TODO: Auto-generated Javadoc
/**
 * The Class PerformerDealourceAssembler.
 */
@Component
public class PerformerDealResourceAssembler extends ResourceAssemblerSupport<PerformerDealDto, PerformerDealDto> {

    /**
     * Instantiates a new performer grid resource assembler.
     */
    public PerformerDealResourceAssembler() {
        super(DealController.class, PerformerDealDto.class);

    }

    @Override
    public PerformerDealDto toResource(PerformerDealDto deal) {
        deal.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(DealController.class).getPerformerDeal(deal.getDealId()))
                .withSelfRel());
        return deal;
    }

}
