package com.mediaservices.c2c.fc.hateoas;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.mediaservices.c2c.fc.controller.ApplicationInfoController;
import com.mediaservices.c2c.fc.dto.ApplicationInfoDto;

/**
 * The Class ApplicationInfoResourceAssembler.
 */
@Component
public class ApplicationInfoResourceAssembler extends ResourceAssemblerSupport<ApplicationInfoDto, ApplicationInfoDto> {

    /**
     * Instantiates a new application info resource assembler.
     */
    public ApplicationInfoResourceAssembler() {
        super(ApplicationInfoController.class, ApplicationInfoDto.class);

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.hateoas.ResourceAssembler#toResource(java.lang.Object)
     */
    @Override
    public ApplicationInfoDto toResource(ApplicationInfoDto info) {
        info.add(ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder.methodOn(ApplicationInfoController.class).getVersionInfo())
                .withSelfRel());
        return info;
    }

}
