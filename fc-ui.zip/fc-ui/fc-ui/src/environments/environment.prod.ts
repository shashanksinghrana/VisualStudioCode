export const environment = {
  production: true,
  aot: false,
  context: ''
};
