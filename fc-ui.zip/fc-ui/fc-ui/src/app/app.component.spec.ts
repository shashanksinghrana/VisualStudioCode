import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { SidebarModel, TypeAheadPersistService, TypeAheadDisplayResultModel, ModalGenericComponent, ToasterService, UrlResolverService } from 'c2c-common-lib';
import { SidebarService } from './services/sidebar/sidebar.service';
import { CurrentUserService } from './services/http/users/current-user.service';
import { SessionService } from './services/other/session.service';
import { TalentPersistService } from 'c2c-common-lib/src/app/services/persist/talent-persist.service';
import { UserPermissionService } from './services/http/permission/user-permission.service';
import { UtilsService } from './utils/utils.service';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { Router } from '@angular/router';
import { LoadingIndicatorInterceptorService } from './services/other/loading-indicator-interceptor.service';
import { LoadingIndicatorService } from './services/other/loading-indicator.service';
import { CurrentUserPersistService } from './services/persist/user/current-user-persist.service';
import { AutoLogoutService } from './services/other/autoLogout.service';
describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[
        HttpClientModule,
        HttpModule,
      ],
      declarations: [
        AppComponent
      ],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [SidebarService,
        TypeAheadPersistService,
        UrlResolverService,
        CurrentUserService,
        SessionService,
        UserPermissionService,
        UtilsService,
        ToastsManager,
        ToastOptions,
        ToasterService,
        CurrentUserPersistService,
        AutoLogoutService,

        LoadingIndicatorService,
        { provide: Router, useClass: class { navigate = jasmine.createSpy("navigate"); } }]
    }).compileComponents();
  }));

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

  // it(`should have animationState as 'in'`, async(() => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   const app = fixture.debugElement.componentInstance;
  //   expect(app.animationState).toEqual('in');
  // }));

  it(`should have sidebarCollapsed as 'false'`, async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.sidebarCollapsed).toEqual(false);
  }));


  
  it('should have property moduleLink', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const component = fixture.componentInstance;
    expect(component.moduleLink).toBeTruthy(true);
  });

  it('should have property navLink', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const component = fixture.componentInstance;
    expect(component.navLinks).toBeTruthy(true);
  });
  

  
});


