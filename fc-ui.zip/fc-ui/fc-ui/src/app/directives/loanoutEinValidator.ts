import { Directive, ElementRef, Renderer2, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[loanoutEinValidator]'
})
export class LoanoutEinValidatorDirective {

  /* Input value to validate country */
  @Input() isCountry : boolean;

  constructor(private elementRef: ElementRef, private renderer : Renderer2) { }

  @HostListener("keypress", ["$event"])
    public onKeydown(evt: KeyboardEvent){
        var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
        if (keyID > 31 && (keyID < 48 || keyID > 57) && this.isCountry){
            evt.preventDefault();
            evt.returnValue = false;
            evt.stopPropagation();   
        }else{
            let el : ElementRef = new ElementRef(evt.target);
            el.nativeElement = evt.target
            el.nativeElement.value = this.format(el.nativeElement.value);
        }
    }
  private format(value:any) : any {
    if(value) {
      if(this.isCountry){
        this.renderer.setAttribute(this.elementRef.nativeElement, "maxlength", "10");
        this.renderer.setAttribute(this.elementRef.nativeElement, "pattern", "^\d{2}-\d{7}$");
        let val = value.replace(/[^0-9]/g, '');
        let newVal = '';
        const sizes = [2, 7];
        for (const i in sizes) {
            if (val.length > sizes[i]) {
                if(i === '0')
                newVal += val.substr(0, sizes[i]) + '-';
                else
                newVal += val.substr(0, sizes[i]);
                val = val.substr(sizes[i]);
            } else
                break;
        }
        if(newVal.length < 10)
        newVal += val;
        return newVal.slice(0, 9);
      }
      else{
        this.renderer.setAttribute(this.elementRef.nativeElement, "maxlength", "20");
        this.renderer.setAttribute(this.elementRef.nativeElement, "pattern", "/^[0-9]*$/");
        return value;
      }
    } else {
        return '';
    }
  }
}
