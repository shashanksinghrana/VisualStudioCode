import { Directive, ElementRef, Renderer2, HostListener, Input, SimpleChanges, OnChanges } from '@angular/core';

@Directive({
  selector: '[autoResize]'
})
export class AutoResizeTextAreaDirective implements OnChanges {

  @Input() value : any;

  constructor(private elementRef: ElementRef, private renderer : Renderer2) { }

  ngOnChanges(changes: SimpleChanges){
    if(changes.value){
      this.autoGrow();
    }
  }

  public autoGrow(){
    this.elementRef.nativeElement.style.overflow = 'hidden';
    this.elementRef.nativeElement.style.height = '0px';
    this.elementRef.nativeElement.style.height = this.elementRef.nativeElement.scrollHeight + 'px';
  }
}
