import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryLoanoutComponent } from './summary-loanout.component';

describe('SummaryLoanoutComponent', () => {
  let component: SummaryLoanoutComponent;
  let fixture: ComponentFixture<SummaryLoanoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryLoanoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryLoanoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
