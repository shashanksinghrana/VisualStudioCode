import { Component, Input } from '@angular/core';
import { DealService } from '../../../services/http/deal/deal.service';
import { SharedService } from '../../../services/http/shared/shared.service';

@Component({
  selector: 'fc-summary-loanout',
  templateUrl: './summary-loanout.component.html',
  styleUrls: ['./summary-loanout.component.scss']
})
export class SummaryLoanoutComponent {
  public details = '';
  public deal: any;
  @Input('deal')
  set _dealDetails(dealData: any) {
    if (dealData) {
       this.deal = dealData;
       this.details = '';
       this.getLoanOutDetails();
    }
  }	
	
  response: any = {};
  public countries = [];
  public states = [];
  country: string = '';
  ein: string = '';
  loanoutComp: string = '';
  stateOfInc: string = '';
  constructor(private dealService: DealService,
              private sharedService: SharedService) 
              {
    this.getDropDownOptionsForStates("STATES");
    this.getDropDownOptionsForCountries("COUNTRIES");
  }

  private getLoanOutDetails(): void {
    this.dealService.getLoanout(this.deal.id).subscribe((res) => {
      if (res) {
        let countryName = this.getCountryName(res.countryID);
        let stateName = this.getStateName(res.stateID);
        this.country = countryName !== null ? countryName : '';
        this.ein = res.ein !== null ? res.ein : '';
        this.loanoutComp = res.loanoutComp !== null ? res.loanoutComp : '';
        this.stateOfInc = stateName !== null ? stateName : '';

        this.details = this.details + (!this.isEmpty(this.loanoutComp) ? (this.loanoutComp) : '');
        this.details = this.details + (!this.isEmpty(this.stateOfInc) ? (" | " + this.stateOfInc) : '');
        this.details = this.details + (!this.isEmpty(this.country) ? (" | " + this.country) : '');
        this.details = this.details + (!this.isEmpty(this.ein) ? (" | " + this.ein) : '');
      }
    });
  }

  isEmpty(str: string) {
    if (str === '') {
      return true;
    }
    return false;
  }

  private getDropDownOptionsForStates(type: string) {
    this.sharedService.getGenericLookupDropdown(type).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          this.states.push({
            value: data[i].value,
            id: data[i].id
          });
        }
      }
    )
  }

  private getDropDownOptionsForCountries(type: string) {
    this.sharedService.getGenericLookupDropdown(type).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          this.countries.push({
            value: data[i].value,
            id: data[i].id
          });
        }
      }
    )
  }

  private getCountryName(id){
    let country = "";
    this.countries.forEach((element, i) =>  { 
      if(element.id === id){
        country = element.value;
      }
    });
    return country;
  }

  private getStateName(id){
    let state = "";
    this.states.forEach((element, i) =>  { 
      if(element.id === id){
        state = element.value;
      }
    });
    return state;
  }
}
