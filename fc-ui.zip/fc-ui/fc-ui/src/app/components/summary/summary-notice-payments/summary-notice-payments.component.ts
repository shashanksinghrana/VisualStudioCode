import { Component, Input } from '@angular/core';
import { DealService } from '../../../services/http/deal/deal.service';

@Component({
  selector: 'fc-summary-notice-payments',
  templateUrl: './summary-notice-payments.component.html',
  styleUrls: ['./summary-notice-payments.component.scss']
})
export class SummaryNoticePaymentsComponent {

  public agentInfo: Array<AgentInfo> = [];
  public deal: any;
  @Input('deal')
  set _dealDetails(dealData: any) {
    if (dealData) {
      this.deal = dealData;
      this.agentInfo = [];
      this.getNoticePayments();
    }
  }

  constructor(private dealService: DealService) { }
 
  private getNoticePayments(): void {
    this.agentInfo = [];
    this.dealService.getNotceandPaymentsApi(this.deal.id).subscribe(res => {
      if (res) {
        if (res.representators && res.representators.length !== 0) {
          this.agentInfo = this.getAgentDetails(res.representators);
        }
        if (res.directContact) {
          const temp = this.getAgentDetails(res.directContact);
          temp.forEach((i) => {
            if (this.agentInfo.length > 0 && (i.name !== '' || i.type !== '')) { //commenting the condition after && , if direct contact exists, then it needs to be always displayed along with reps
              this.agentInfo.push(temp[0]);
            } else if (this.agentInfo.length === 0) {
              this.agentInfo = temp;
            }
          });
        }
      }
    });
  }

  public getAgentDetails(agents: Array<any> | any): Array<AgentInfo> {
    let agentArr = [];
    if (Array.isArray(agents)) {
      agentArr = agents.map(agent => {
        const temp = {
          type: agent.repType !== null ? agent.repType : '',
          name: agent.repName !== null ? agent.repName : '',
          agency: agent.companyName !== null ?  agent.companyName: '',
          address: agent.address !== null ? agent.address : [],
          contact: this.getContactDetails(agent.contactInfo)
        };
        return temp;
      });
    } else if (agents instanceof Object) {
      const temp = {
        type: agents.repType !== null ? agents.repType : '',//(agents.address ? agents.address[0].addressType : ''), replace with commented code if address type needs to be shown for direct contact section
        name: agents.repName !== null ? agents.repName : '',
        agency: agents.companyName !== null ?  agents.companyName: '',
        address: (agents.address && (agents.address.length > 0)) ? [this.getAddressBasedOnDropdown(agents.details.directContactId, agents.address)] : [],
        contact: this.getContactDetails(agents.contactInfo)
      };
      agentArr.push(temp);
    }

    return agentArr;
  }

  public getContactDetails(contactInfo): Array<any> {
    const contactArray = [];
    if (contactInfo && contactInfo.length > 0) {
    const phoneInd = contactInfo.findIndex(contact => (contact.type === 'Office' || contact.type === 'Work 1'));
    const emailInd = contactInfo.findIndex(contact => (contact.type === 'Work'));
    const faxInd = contactInfo.findIndex(contact => (contact.type === 'Work Fax'));

    if (phoneInd >= 0) {
      contactInfo[phoneInd].value = contactInfo[phoneInd].value.split('-').join('').split('(').join('').split(')').join('').split(' ').join('');
      contactArray.push(contactInfo[phoneInd]);
    }
    if (emailInd >= 0) {
      contactArray.push(contactInfo[emailInd]);
    }
    if (faxInd >= 0) {
      contactInfo[faxInd].value = contactInfo[faxInd].value.split('-').join('').split('(').join('').split(')').join('').split(' ').join('');
      contactArray.push(contactInfo[faxInd]);
    }
    }
    return contactArray;
  }

  /**
   * Return Address based on drop down value selected
   *
   * @param id AddressId
   */
  public getAddressBasedOnDropdown(id, addressArray): any {
    let address = '';

    addressArray.forEach((item, index) => {
      if (item.addressId === id) {
       address = item;
      }
    });
    return address;
  }

  public formatPhoneNumber(phoneNumber) {
    let formattedNumber = '';
    if (phoneNumber) {
      phoneNumber = phoneNumber.replace(/ +/g, '');
      const length = phoneNumber.length;
      if (phoneNumber.indexOf('-') > -1) {
        phoneNumber = phoneNumber.split('-').join('');
      }

      if (phoneNumber.indexOf('(') > -1) {
        phoneNumber = phoneNumber.split('(').join('');
      }

      if (phoneNumber.indexOf(')') > -1) {
        phoneNumber = phoneNumber.split(')').join('');
      }

      formattedNumber = '(' + phoneNumber.slice(0, 3) + ')-' + phoneNumber.slice(3, 6) + '-' + phoneNumber.slice(6, length);

    }
    return formattedNumber;
  }
}

interface AgentInfo {
  type: string;
  name: string;
  address: Array<any>;
  contact: Array<any>;
}
