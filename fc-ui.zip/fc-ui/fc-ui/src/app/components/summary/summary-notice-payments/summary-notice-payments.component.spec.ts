import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryNoticePaymentsComponent } from './summary-notice-payments.component';

describe('SummaryNoticePaymentsComponent', () => {
  let component: SummaryNoticePaymentsComponent;
  let fixture: ComponentFixture<SummaryNoticePaymentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryNoticePaymentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryNoticePaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
