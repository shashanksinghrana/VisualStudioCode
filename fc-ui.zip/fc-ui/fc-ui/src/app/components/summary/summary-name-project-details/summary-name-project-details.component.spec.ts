import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryNameProjectDetailsComponent } from './summary-name-project-details.component';

describe('SummaryNameProjectDetailsComponent', () => {
  let component: SummaryNameProjectDetailsComponent;
  let fixture: ComponentFixture<SummaryNameProjectDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryNameProjectDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryNameProjectDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
