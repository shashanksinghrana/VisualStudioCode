import { Component, Input } from '@angular/core';
import { DealService } from '../../../services/http/deal/deal.service';
import { SummaryEventService } from '../../../services/events/summary-event.service';

@Component({
  selector: 'fc-summary-name-project-details',
  templateUrl: './summary-name-project-details.component.html',
  styleUrls: ['./summary-name-project-details.component.scss']
})
export class SummaryNameProjectDetailsComponent {

  public deal: any;
  @Input('deal')
  set _dealDetails(dealData: any) {
    if (dealData) {
      this.deal = dealData;
      this.date = dealData.dealDate || '';
      this.projectName = dealData.project.title.title || '';
      this.performerName = this.getFullName(dealData.performer);
      this.minor = this.calculateMinor(dealData.performer.dob);
      this.noQuoteDeal = dealData.noQuoteDeal || false;
      this.summaryEventService.sendNoQuoteDealVal(this.noQuoteDeal);
    }
  }

  public response: any;
  public date: string;
  public projectName: string;
  public performerName: string;
  public minor: boolean = false;
  public noQuoteDeal : boolean = false;
  constructor(private dealService: DealService, private summaryEventService : SummaryEventService) { }

  getFullName(performer): string {
    let name = '';
    name = performer.firstName !== null ? performer.firstName : '';
    name = name + ' ' + (performer.middleName !== null ? performer.middleName : '');
    name = name + ' ' + (performer.lastName !== null ? performer.lastName : '');
    return name;
  }

  public calculateMinor(dob: string) {
    const dealDate = this.date;
    if (dob && dealDate) {
      const ageDiff = new Date(dealDate).getTime() - new Date(dob).getTime();
      const ageDate = new Date(ageDiff);
      const age = Math.abs(ageDate.getUTCFullYear() - 1970);
      if (age < 18) {
        return true;
      } else {
        return false;
      }
    } else {
        return false;
    }
  }

}
