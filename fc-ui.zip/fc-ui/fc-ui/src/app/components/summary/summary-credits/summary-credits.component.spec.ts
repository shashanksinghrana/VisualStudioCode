import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryCreditsComponent } from './summary-credits.component';

describe('SummaryCreditsComponent', () => {
  let component: SummaryCreditsComponent;
  let fixture: ComponentFixture<SummaryCreditsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryCreditsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryCreditsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
