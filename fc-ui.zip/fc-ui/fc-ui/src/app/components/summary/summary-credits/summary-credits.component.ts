import { Component, Input } from '@angular/core';
import { DealService } from '../../../services/http/deal/deal.service';
import { performerNameFormatter } from '../../../utils/formatter/performer-name.format';

@Component({
  selector: 'fc-summary-credits',
  templateUrl: './summary-credits.component.html',
  styleUrls: ['./summary-credits.component.scss'],
  providers: [DealService]
})
export class SummaryCreditsComponent {
  public paramId: string = '';
  public checkLen : boolean = false;
  public performer = "";
  onScreenDetails: Array<{ credits: string }> = [];
  billingTextArr: Array<{ type: string }> = [];

  public deal: any;
  @Input('deal')
  set _dealDetails(dealData: any) {
    if (dealData) {
      this.deal = dealData;
      this.onScreenDetails = [];
      this.billingTextArr = [];
      this.getCreditsDetails();
    }
  }
  
  constructor(private dealService: DealService) { }

  private getCreditsDetails(): void {
    this.performer = performerNameFormatter(this.deal.performer.firstName, this.deal.performer.lastName);//this.deal.performer.typeAheadDisplayName;
    this.dealService.getCreditApi(this.deal.id).subscribe(res => {
      if (res.creditDetail.length > 0) {
        this.checkLen = true;
        this.onScreenDetails = this.getOnScreenDetails(res.creditDetail);
      }
      else if (this.onScreenDetails.length == 0) {
        // this.onScreenDetails.push({ credits: 'None' })
      }
      if (res.creditBilling.length > 0) {
        this.billingTextArr = this.getbillingTextArr(res.creditBilling);
      }
      if (this.billingTextArr.length == 0) {
        // this.billingTextArr.push({ type: 'None' })
      }
    })
  }

  getOnScreenDetails(credits): Array<{ credits: string }> {
    let creditsArr = [];
    creditsArr = credits.map((item) => {
      let temp = {
        credits: '',
        creditedAs : ''
      };

      const title = item.creditTitle !== null ? item.creditTitle.name : '';
      const card = item.card !== null ? item.card.name : '';
      const position = item.position !== null ? item.position.name : '';

      temp.credits = [title, card, position].filter(val => val).join(', ');
      temp.creditedAs = 'Credited As: '+ this.performer;
      return temp;
    })
    return creditsArr;
  }

  public getbillingTextArr(billing): Array<{ type: string }> {
    let billingArr = [];
    billingArr = billing.map(item => {
      const temp = {
         name : item.billingText !== null ? item.billingText : '',
         type : (item.billingLookupText && item.billingLookupText.type) ? item.billingLookupText.type : ''
      };
      return temp;
    });

    return billingArr;
  }
}
