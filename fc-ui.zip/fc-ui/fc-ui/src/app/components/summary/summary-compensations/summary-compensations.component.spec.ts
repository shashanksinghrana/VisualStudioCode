import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryCompensationsComponent } from './summary-compensations.component';

describe('SummaryCompensationsComponent', () => {
  let component: SummaryCompensationsComponent;
  let fixture: ComponentFixture<SummaryCompensationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryCompensationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryCompensationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
