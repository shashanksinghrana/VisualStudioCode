import { Component, Input } from '@angular/core';
import { DealService } from '../../../services/http/deal/deal.service';
import { SharedService } from '../../../services/http/shared/shared.service';


@Component({
  selector: 'fc-summary-compensations',
  templateUrl: './summary-compensations.component.html',
  styleUrls: ['./summary-compensations.component.scss']
})
export class SummaryCompensationsComponent {

  constructor(private sharedService: SharedService, private dealService : DealService) { 
      this.sharedService.getDropdown('FEE_TYPE').subscribe(
        (data) => {
          for (let i = 0; i < Object.keys(data).length; i++) {
            this.feeTypes.push({
              value: data[i].name,
              id: data[i].id,
            });
          }
        }
      );  

      this.sharedService.getDropdown('PRINCIPAL_FREE_TYPE').subscribe(
        (data) => {
          for (let i = 0; i < Object.keys(data).length; i++) {
            this.principalFeeTypes.push({
              value: data[i].name,
              id: data[i].id,
            });
          }
        }
      );  
    }

  public deal: any;
  @Input('deal')
  set _dealDetails(dealData: any) {
    if (dealData) {
      this.deal = dealData;
      this.compData = [];
      this.getContractTerms();
    }
  }	
  public feeTypes = [];
  public principalFeeTypes = [];
  public compData = [];
  public compDataArr = [];
  public riderDataArr = [];
  public riderData = [];
  public totalAmount: string = '';
  public rate: string = '';
  public guaranteed: string = '';
  public startDate: string = '';
  public details: string = '';

  private getContractTerms(): void {
    // Get Compensation and Contract rider data
    this.dealService.getContractTerms(this.deal.id).subscribe(
      (data) => {
        if (data) {
          this.compDataArr = data.compensations;
          this.riderDataArr = data.contracts;
          this.compData = [];
          this.riderData = [];
          this.getCompensationData();
          this.getRiderData();
        }
      },
      (err) => {
        console.error('Error getting compensation details', err);
      }
    );
  }

  /* Method to get fee typ value */
  public getFeeTypeValue(id, principalFreeInterval): string{
    let feeType = "";
    this.feeTypes.forEach((element, i) =>  { 
      if(element.id === id){
        if(element.value.includes("Daily")){
          feeType = "Day";
        }else if(element.value.includes("Weekly")){
          feeType = "Week";
        }else if(element.value === "Schedule F"){
          this.principalFeeTypes.forEach((item, j) =>  { 
              if(item.value === "Days"){
                feeType = "Day";
              }else if(item.value === "Weeks"){
                feeType = "Week";
              }
          });
        }
      }
    });
    return feeType;
  }

  /*Method to get Compensation Data Object */
  public getCompensationData(): void{
    let dataArray = [];
    if(this.compDataArr && this.compDataArr.length > 0){
      this.compDataArr.forEach((item, index) =>  { 
            dataArray = item.data;
            dataArray.forEach((element, i) =>  { 
              const feeType = this.getFeeTypeValue(element.feeTypeId, element.principalFreeInterval); 
              this.compData.push({
                "totalAmount": element.totalAmount ? element.totalAmount : '',
                "rate": {
                  "label": "/" + feeType,
                  "value" : element.rate ? element.rate : '',
                },
                  "guaranteed": this.getGuaranteeNumber(element, feeType),
                  "startDate": {
                  "label": element.startDateQualifierLookup ? (" " + element.startDateQualifierLookup.name + " ") : '',
                  "value": element.startDate? (new Date(element.startDate)) : ''
                }
              });
            });
        });
      }
  }

  public getGuaranteeNumber(element, feeType): string{
    let guarantee = null;
    if(element.guaranteeNumber){
      guarantee = element.guaranteeNumber + " "+ feeType + " Guaranteed";
      if(element.startDateQualifierLookup && element.startDateQualifierLookup.name && element.startDate){
        guarantee += ',';
      }
    }   
    return guarantee;
}

  /*Method to get contract rider data*/
  public getRiderData(): void{
    let rider = [];
    if(this.riderDataArr && this.riderDataArr.length > 0){
        this.riderDataArr.forEach((item, index) =>  { 
          let matchedComp = null;
            if(item.compensationId) {
              matchedComp = this.getMetchedCompensation(item.compensationId, this.compDataArr);
            }
            this.riderData.unshift({
              id: item.id,
              compensationId: item.compensationId,
              dealId: this.deal.id,
              contractLookupId: item.contractLookupId,
              riderTitle: item.contractName,
              voidFlag: matchedComp != null ? matchedComp.voidFlag : false
            });
        });
    }
  }

  /* Method to get exact compensastion for contract rider */
  private getMetchedCompensation(compId, compensations) : any {
    let result = null;
    if(compensations != null){
      compensations.forEach((compObj) => {
        if(compObj.data) {
          compObj.data.forEach((dataObj) => {
            if(compId == dataObj.id) {
              result = dataObj;
            }
          });
        }
      });
      return result;
    }
  }

  /*
  * Method to download Pdf file 
  * @Param riderIndex
  */
 public downloadFile(riderIndex) {
  let compensationObj: any[] = [];
  compensationObj[0] = this.getMetchedCompensation(this.riderData[riderIndex].compensationId,this.compDataArr);
  this.dealService.downloadfile(this.deal.id,this.riderData[riderIndex].contractLookupId,compensationObj)
      .subscribe(
        (data) => {
           //for browser compatibility  
           var ieEDGE = navigator.userAgent.match(/Edge/g);
           var ie = navigator.userAgent.match(/.NET/g); // IE 11+
           var oldIE = navigator.userAgent.match(/MSIE/g); 
           var name = "file";
           var blob = new window.Blob([data], { type: 'application/pdf' });

           if (ie || oldIE || ieEDGE) {
               var fileName = name+'.pdf';
               window.navigator.msSaveBlob(blob, fileName);
           }
           else {
               var file = new Blob([ data ], {
                   type : 'application/pdf'
               });
               var fileURL = URL.createObjectURL(file);
               window.open(fileURL);
           }
        },
        error => {
          console.log("Error downloading the file." + error)
        },
        () => {
          console.log("complete");
        }
      );

}

  /* Method to check empty value*/
  isEmpty(str: string) {
    if (str === '') {
      return true;
    }
    return false;
  }

}
