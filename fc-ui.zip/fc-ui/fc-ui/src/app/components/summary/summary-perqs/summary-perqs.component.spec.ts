import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryPerqsComponent } from './summary-perqs.component';

describe('SummaryPerqsComponent', () => {
  let component: SummaryPerqsComponent;
  let fixture: ComponentFixture<SummaryPerqsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryPerqsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryPerqsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
