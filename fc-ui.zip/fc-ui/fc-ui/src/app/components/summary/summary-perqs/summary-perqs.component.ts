import { Component, Input } from '@angular/core';
import { PerqsService } from '../../../services/http/deal/perqs.service';

@Component({
  selector: 'fc-summary-perqs',
  templateUrl: './summary-perqs.component.html',
  styleUrls: ['./summary-perqs.component.scss']
})
export class SummaryPerqsComponent {

  public deal: any;
  @Input('deal')
  set _dealDetails(dealData: any) {
    if (dealData) {
      this.deal = dealData;
      this.perqDetails = [];
      this.getPerqsDetails();
    }
  }

  @Input() navigation: any;
  perqDetails: Array<{ perqs: string, type: string }> = [];
  constructor(private perqsService: PerqsService) { }

  private getPerqsDetails(): void {
    this.perqsService.getPerqs(this.deal.id).subscribe(res => {
      if (res.perqs) {
        if (res.perqs.length > 0) {
          this.perqDetails = this.onPerqDetails(res.perqs);
        }
      }
    });
  }

  onPerqDetails(perqs): Array<{ perqs: string, type: string }> {
    let perqArr = [];
    perqArr = perqs.map((item) => {
      let temp = {
        perqs: item.perqText !== null ? item.perqText : '',
        type: item.perqTypeLookup.name !== null ? item.perqTypeLookup.name : ''
      };
      return temp;
    })
    return perqArr;
  }

}
