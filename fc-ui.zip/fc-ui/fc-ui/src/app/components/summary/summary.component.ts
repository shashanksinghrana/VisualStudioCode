import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from "@angular/router";
import { CancelButtonModel, DeleteConfirmationService, ModalDeleteConfirmationComponent } from 'c2c-common-lib';
import { WizardModel } from '../../models/deal/wizard.model';
import { LookupModel } from '../../models/shared/lookup.model';
import { DealStatus } from '../../modules/create-deal/deal-status.enum';
import { SummaryEventService } from '../../services/events/summary-event.service';
import { DealService } from '../../services/http/deal/deal.service';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'fc-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {

  public deal: any;
  public dealId;
  public noQuoteDealVal: boolean;
  public currentIndex: number;
  public cancelButtonOptions: CancelButtonModel;
  public wizards: WizardModel[] = [];
  public wizardSections: any[] = [];
  public wizardSubTitles: Array<string> = [];
  public inputRequiredVal: boolean;
  public deleteIndex: any;
  private subscriptions: Subscription = new Subscription();
  public viewPermission: PermissionList = PermissionList.dealCreateEditView
  public editPermission: PermissionList = PermissionList.dealCreateEditEdit
  public disableForm:boolean=false;

  @ViewChild('deleteModal') public deleteModal: ModalDeleteConfirmationComponent;

  constructor(
    private dealService: DealService,
    private router: Router,
    private summaryEventService: SummaryEventService,
    private userPermissionService:UserPermissionService) {
    this.disableForm=this.createEditPermission();
    this.loadService();
    this.subscriptions.add(
      this.dealService.getWizardDetails().subscribe((data: WizardModel[]) => {
        this.wizards = data;
        for (const wizard of data) {
          let pageRoute = wizard.page.name;
          pageRoute = pageRoute.charAt(0).toLowerCase() + pageRoute.substring(1);
          pageRoute = pageRoute.replace(/[\W\s]+/gi, '');
          const obj = { page: null, status: null, route: null };
          obj.page = wizard.page.name;
          obj.status = wizard.status;
          obj.route = pageRoute;
          this.wizardSections.push(obj);
        }
      })
    )
  }

  public navigation(route, id, index) {
    this.summaryEventService.navigate({ pageTo: route, dealID: id });
  }

  private loadService(): void {
   this.subscriptions.add(
      this.dealService.getDealDetails().subscribe((response) => {
        if (response) {
          if (response.id !== this.dealId) {
            this.deal = response;
            this.dealId = response.id;
            this.cancelButtonOptions = new CancelButtonModel('fc', 'summary', 'navigate', `projectDetails/${this.deal.project.id}`);
          }
         /*  this.dealService.getDeal(response.id).subscribe(
            (deal) => {
              this.deal = deal;
              this.dealId = deal.id;
              this.cancelButtonOptions = new CancelButtonModel('fc', 'summary', 'navigate', `projectDetails/${this.deal.project.id}`);
            }
          ); */
        }
      })
    );
  }

  ngOnInit() {
    this.summaryEventService.getEvent().subscribe(value => { this.navigateTab(value.pageTo); });
    this.summaryEventService.getNoQuoteDeal().subscribe(value => { this.noQuoteDealVal = value; });
  }

  public navigateTab(pageTo?: string) {
    pageTo = pageTo.replace(/\//g, " ");
    pageTo = pageTo.replace(/[^A-Z0-9]/ig, ' ');
    let name = pageTo.trim();
    let space = name.indexOf(" ");
    let first = name.substring(0, space);
    if (first !== "") {
      let last = name.substring(space);
      pageTo = first.toLowerCase() + last.replace(/[^A-Z0-9]/ig, '');
    } else {
      let last = name.substring(space);
      pageTo = last.toLowerCase().replace(/[^A-Z0-9]/ig, '');
    }
    this.router.navigate([`createDeal/${this.dealId}/${pageTo}`]);
  }

  public openDeleteConfirmationModal() {
    this.deleteModal.openModal();
  }

  public deleteModalClosed(event) {
    if (event.action === "OK") {
      this.router.navigate(['projectDetails/' + this.deal.project.id + '/performers']);
      this.deleteDeal(this.dealId);
    }
  }

  public deleteDeal(dealId) {
    this.dealService.deleteDeal(this.deal.id).subscribe(
      () => {
      }
    );
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe()
  }


  public createEditPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === false) {
      return true;
    }
    else if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === true) {
      return false;
    }
  }

}

