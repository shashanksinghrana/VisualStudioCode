import { Component, OnInit, Input } from '@angular/core';
import { DealStatus } from './../../../modules/create-deal/deal-status.enum';

@Component({
  selector: 'fc-summary-header',
  templateUrl: './summary-header.component.html',
  styleUrls: ['./summary-header.component.scss']
})
export class SummaryHeaderComponent implements OnInit {

  @Input() title: string;
  @Input() pageStatus: any;
  @Input() navLink: any;
  
  constructor() {}

  ngOnInit() {}

  public getStatusClass(): string {
    if (this.pageStatus) {
      switch (this.pageStatus) {
        case DealStatus.COMPLETE:
          return DealStatus.COMPLETE_CLASS;
        case DealStatus.INCOMPLETE:
          return DealStatus.INCOMPLETE_CLASS;
        case DealStatus.NOT_APPLICABLE:
          return DealStatus.NOT_APPLICABLE_CLASS;
        default:
          return '';
      }
    } else {
      return '';
    }
  }

}
