import { Component, OnInit, OnDestroy, ViewContainerRef, Renderer } from '@angular/core';
import { ColumnDefModel, ToasterService } from 'c2c-common-lib';
import { ActivatedRoute } from '@angular/router';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { ToastsManager } from 'ng2-toastr';
import { StatusDatesEventService } from '../../services/events/status-dates-event.service';
import { Subscription } from 'rxjs';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { SharedService } from '../../services/http/shared/shared.service';

@Component({
  selector: 'fc-status-dates',
  templateUrl: './status-dates.component.html',
  styleUrls: ['./status-dates.component.scss']
})
export class StatusDatesComponent implements OnInit, OnDestroy {
  public pageOptions: {};
  public statusDatesDefs: ColumnDefModel[] = [];
  public statusDatesData: any[];
  public projectId: number;
  public editedRowIndex: number;
  public statusOptions: any[] = [];
  public cellEditingError: any = [];
  public gridApi: any;
  public columnApi: any;
  public statusDatesDataBeforeValidation: any[];

  public editType: any;
  public stopEditingWhenGridLosesFocus: boolean;
  public suppressClickEdit: boolean = true;
  public selectedId: number;
  public cancelSaveClicked: boolean = false;
  public addClicked: boolean = false;

  private saveRowSubscription: Subscription;
  private cancelSaveRowSubscription: Subscription;
  private deleteRowSubscription: Subscription;
  public statusDatesViewPermission: PermissionList = PermissionList.projectDetailsStatusDatesView;
  public statusDatesEditPermission: PermissionList = PermissionList.projectDetailsStatusDatesUpdate;
  public statusDatesAddPermission: PermissionList = PermissionList.projectDetailsStatusDatesCreate;

  /*
  * The Constructor for StatusDatesComponent
  *
  * @param route The active route.
  * @param projectDetailService The Project Details Service for getting data.
  */
  constructor(
    private route: ActivatedRoute,
    private projectDetailService: ProjectDetailService,
    private statusDatesEventService: StatusDatesEventService,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private renderer: Renderer,
    private sharedService: SharedService,
    private userPermissionService: UserPermissionService) {
    this.toaster.setRootViewContainerRef(vcr);
    this.editType = 'fullRow';
    this.stopEditingWhenGridLosesFocus = false;
    this.route.data.subscribe(
      (data) => {
        this.statusOptions = data.options;
        this.projectDetailService.statusOptions = this.statusOptions;
    });
    this.route.parent.params.subscribe(res => this.projectId = res.projectId);
    this.pageOptions = projectDetailService.getStatusDatesPageOptions(this.createPermission());
    this.statusDatesDefs = projectDetailService.createStatusDatesColDefs(this.editPermission());
    this.getStatusDatesData(this.projectId);
  }

  public ngOnInit() {
    this.saveRowSubscription = this.statusDatesEventService.getStatusDatesSavedEvent()
    .subscribe(value => {
      this.saveStatusDatesRecords(value);
    });
    this.cancelSaveRowSubscription = this.statusDatesEventService.getStatusDatesCancelledEvent()
    .subscribe(value => {
      this.cancelSaveStatusDatesRecords(value);
    });
    this.deleteRowSubscription = this.statusDatesEventService.getStatusDatesDeletedEvent()
    .subscribe(value => {
      this.deleteStatusDatesRecords(value);
    });
  }

  /**
* Gets all of the status dates data to be displayed in the Grid.
*
* @param id The project id tied to status dates data to get.
*/
  private getStatusDatesData(id, params?): void {
    if (this.gridApi) {
      this.gridApi.showLoadingOverlay();
    }
    this.projectDetailService.getStatusDates(id, params).subscribe(
      (data) => {
        if (this.gridApi) {
          this.gridApi.hideOverlay();
        }
        data.forEach((element, index) => {
          element.status = element.status ? element.status.name : element.status;
        });
        this.statusDatesData = data;
      },
      (error) => { this.toasterService.error('Error when getting Status Dates', error); }
    );
  }

  /**
   * Refreshes the Grid to get the latest status dates deal data.
   *
   */
  public refreshData(): void {
    this.addClicked = false;
    this.getStatusDatesData(this.projectId);
    this.columnApi.getColumn('startDate').setSort('asc');
  }

  public disableOrEnableGridRows(currRowIndex, disableFlag) {
    const body = document.getElementsByClassName('ag-body-container');
    const list = body[0].children;
    Array.from(list).forEach(element => {
      if (element.getAttribute('row-index') !== currRowIndex.toString()) {
        this.renderer.setElementClass(element, 'c2c-grid-row-read-only', disableFlag);
      }
    });
  }

  public disableAllGridRows() {
    const body = document.getElementsByClassName('ag-body-container');
    const list = body[0].children;
    Array.from(list).forEach(element => {
      this.renderer.setElementClass(element, 'c2c-grid-row-read-only', true);
    });
  }

  public onClickStatusStartDate(params) {
    this.editedRowIndex = this.projectDetailService.editedRowIndex;
    const rowIndex = params.node.rowIndex;
    //removing check with edited rowindex
    if (params.colDef.cellRendererParams.enableRowEditing) {
      this.disableOrEnableGridRows(rowIndex, true);
      params.api.setFocusedCell(rowIndex, 'startDate');
      params.api.startEditingCell({
        rowIndex: rowIndex,
        colKey: 'startDate'
      });
      this.editedRowIndex = rowIndex;
      this.projectDetailService.editedRowIndex = this.editedRowIndex;
      this.addClicked = true;
      this.statusDatesEventService.isAddOrEditRowInProgress = true;
    }
  }

  public onClickAdd(api) {
    if (!this.addClicked) {
      api.setFilterModel(null);
      this.disableAllGridRows();
      this.selectedId = undefined;
      const newItem = this.createNewRowData();
      api.updateRowData({ add: [newItem], addIndex: 0 });
      api.setFocusedCell(0, 'startDate');
      api.startEditingCell({
        rowIndex: 0,
        colKey: 'startDate'
      });
      this.addClicked = true;
      this.statusDatesEventService.isAddOrEditRowInProgress = true;
    }
  }

  public createNewRowData(): any {
    const newData = {
      'startDate': '', // give current date
      'finishDate': '',
      'status': '',
      'desc': ''
    };
    return newData;
  }

  public gridready(params) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
    // commenting bellow line to fix FC-3420
    // this.gridApi.setRowData(this.statusDatesData);
    this.columnApi.getColumn('startDate').setSort('asc');
  }

  public deleteStatusDatesRecords(row) {
    this.addClicked = false;
    this.cancelSaveClicked = false;
    this.disableOrEnableGridRows(row.rowIndex, false);
    this.statusDatesEventService.isAddOrEditRowInProgress = false;
    row.gridApi.showLoadingOverlay();
    // row.gridApi.updateRowData({ remove: [row.data] });//commenting as any error occurs during edit in backend record should not get deleted from UI
    this.projectDetailService.editedRowIndex = '';
    this.gridApi.columnController.gridColumns.forEach(element => {
      if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
        element.colDef.cellRendererParams.showValidationBorder = false;
      }
    });
    if (row.data.id) {
      this.projectDetailService.deleteStatusDatesRecord(row.data.id, this.projectId).subscribe(
        (data) => {
          row.gridApi.updateRowData({ remove: [row.data] });
          row.gridApi.hideOverlay();
          this.statusDatesData.splice(row.rowIndex, 1);
          // this.gridApi.setRowData(this.statusDatesData);commenting as delete with filter should return filtered records alone
          this.statusDatesDataBeforeValidation = null;
        },
        (error) => { this.toasterService.error('Error when deleting status dates row', error); }
      );
    } else {
      row.gridApi.updateRowData({ remove: [row.data] });
      row.gridApi.hideOverlay();
    }
  }

  public cancelSaveStatusDatesRecords(row) {
    this.cancelSaveClicked = true;
    this.addClicked = false;
    this.disableOrEnableGridRows(row.rowIndex, false);
    this.statusDatesEventService.isAddOrEditRowInProgress = false;
    this.gridApi.columnController.gridColumns.forEach(element => {
      if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
        element.colDef.cellRendererParams.showValidationBorder = false;
      }
    });

    if (this.statusDatesDataBeforeValidation) {
      this.statusDatesData = this.statusDatesDataBeforeValidation;
    }
    if (row.data.id) {
      row.gridApi.stopEditing(true);
      this.statusDatesDataBeforeValidation = null;
      this.projectDetailService.editedRowIndex = '';
    } else {
      row.gridApi.updateRowData({ remove: [row.data] });
      this.statusDatesDataBeforeValidation = null;
      this.projectDetailService.editedRowIndex = '';
    }
  }

  public onRowEditingStopped(params) {
    if (this.cellEditingError.length > 0) {
      params.api.redrawRows();
      this.disableOrEnableGridRows(this.cellEditingError[0].rowIndex, true);
      params.api.setFocusedCell(this.cellEditingError[0].rowIndex, this.cellEditingError[0].column);
      params.api.startEditingCell({
        rowIndex: this.cellEditingError[0].rowIndex,
        colKey: this.cellEditingError[0].column
      });
    } else if (!this.cancelSaveClicked) {
      this.callSaveAPI(params);
    }
    this.cellEditingError = [];
  }

  public callSaveAPI(row) {
    if (!this.statusDatesEventService.isAddOrEditRowInProgress) {
      row.api.showLoadingOverlay();
      const reqObj = this.createReqForSave(row);

      this.projectDetailService.editedRowIndex = '';
      this.projectDetailService.saveStatusDates(reqObj, row.data.dealId, this.projectId).subscribe(
        (data) => {
          row.api.hideOverlay();
          data.status = data.status ? data.status.name : data.status;
          this.selectedId = data.id;
          if (!reqObj.id) {
            row.data.id = data.id;
            this.statusDatesData.splice(0, 0, data);
          }

          const model = row.api.getFilterModel();
          const sortModel = row.api.getSortModel();
          row.api.setFilterModel(model);
          row.api.setSortModel(sortModel);
          // this.gridApi.setRowData(this.statusDatesData); commenting as edit-save with filter should return filtered records alone
          this.gridApi.columnController.gridColumns.forEach(element => {
            if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
              element.colDef.cellRendererParams.showValidationBorder = false;
            }
          });
          this.statusDatesDataBeforeValidation = null;
        },
        (error) => { this.toasterService.error('Error when saving status dates', error); }
      );
    }
  }

  public saveStatusDatesRecords(row) {
    this.cancelSaveClicked = false;
    this.addClicked = false;
    this.disableOrEnableGridRows(row.rowIndex, false);
    this.statusDatesEventService.isAddOrEditRowInProgress = false;
    this.gridApi.columnController.gridColumns.forEach(element => {
      if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
        element.colDef.cellRendererParams.showValidationBorder = false;
      }
    });

    this.statusDatesDataBeforeValidation = this.statusDatesData.map(e => ({ ... e }));
    row.gridApi.stopEditing();
  }

  public createReqForSave(row) {
    const rowData = { ...row.data };
    const statusValue = rowData.status;
    const projectId = this.projectId;

    rowData.projectId = projectId;
    rowData.id = rowData.id ? rowData.id : null;

    this.statusOptions.forEach((element, index) => {
      if (element.value === statusValue) {
        rowData.status = element;
      }
    });

    rowData.startDate = this.convertDateToFormat(rowData.startDate);
    rowData.finishDate = this.convertDateToFormat(rowData.finishDate);

    return rowData;
  }

  public cellValueChanged(params) {
    const selectedRowIndex = params.selectedRowIndex;

    if (params.selectedColumn === 'startDate') {
      if (params.newValue === '') {
        this.cellEditingError.push({
          column: 'startDate',
          rowIndex: selectedRowIndex
        });
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else if (!this.performDateValidation(params.newRowData)) {
        this.cellEditingError.push({
          column: 'startDate',
          rowIndex: selectedRowIndex
        });
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else {
        params.cellParams.colDef.cellRendererParams.showValidationBorder = false;
      }
    }

    if (params.selectedColumn === 'finishDate') {
      if (params.newValue === '') {
        this.cellEditingError.push({
          column: 'finishDate',
          rowIndex: selectedRowIndex
        });
        if (!params.cellParams.colDef.cellRendererParams) {
          params.cellParams.colDef.cellRendererParams = {};
        }
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else if (!this.performDateValidation(params.newRowData)) {
        this.cellEditingError.push({
          column: 'finishDate',
          rowIndex: selectedRowIndex
        });
        if (!params.cellParams.colDef.cellRendererParams) {
          params.cellParams.colDef.cellRendererParams = {};
        }
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else {
        if (!params.cellParams.colDef.cellRendererParams) {
          params.cellParams.colDef.cellRendererParams = {};
        }
        params.cellParams.colDef.cellRendererParams.showValidationBorder = false;
      }
    }

    if (params.selectedColumn === 'status') {
      if (params.newValue === '') {
        this.cellEditingError.push({
          column: 'status',
          rowIndex: selectedRowIndex
        });
        if (!params.cellParams.colDef.cellRendererParams) {
          params.cellParams.colDef.cellRendererParams = {};
        }
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else {
        if (!params.cellParams.colDef.cellRendererParams) {
          params.cellParams.colDef.cellRendererParams = {};
        }
        params.cellParams.colDef.cellRendererParams.showValidationBorder = false;
      }
    }
  }

  public performDateValidation(newRowData) {
    const startDate = this.convertDateToFormat(newRowData.startDate);
    const finishDate = this.convertDateToFormat(newRowData.finishDate);
    if (Date.parse(startDate) <= Date.parse(finishDate)) {
      return true;
    } else {
      return false;
    }
  }

  public convertDateToFormat(date) {
    if (date.indexOf('/') > -1) {
      const dateVal = date.split('/');
      return [dateVal[2], dateVal[0], dateVal[1]].join('-');
    } else {
      return date;
    }
  }

  public ngOnDestroy(): void {
    this.saveRowSubscription && this.saveRowSubscription.unsubscribe();
    this.cancelSaveRowSubscription && this.cancelSaveRowSubscription.unsubscribe();
    this.deleteRowSubscription && this.deleteRowSubscription.unsubscribe();
  }

  public createPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.statusDatesViewPermission) === true && this.userPermissionService.hasPermission(this.statusDatesAddPermission) === false) {
      return false;
    } else if (this.userPermissionService.hasPermission(this.statusDatesViewPermission) === true && this.userPermissionService.hasPermission(this.statusDatesAddPermission) === true) {
      return true;
    }
  }


  public editPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.statusDatesViewPermission) === true && this.userPermissionService.hasPermission(this.statusDatesEditPermission) === false) {
      return true;
    } else if (this.userPermissionService.hasPermission(this.statusDatesViewPermission) === true && this.userPermissionService.hasPermission(this.statusDatesEditPermission) === true) {
      return false;
    }
  }
}
