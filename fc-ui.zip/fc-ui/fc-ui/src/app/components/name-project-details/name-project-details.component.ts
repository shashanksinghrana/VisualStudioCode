import { Component, OnInit, ViewContainerRef, Renderer2, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {
  DropdownModel, TypeAheadSaveModel, ToasterService, CancelButtonModel, AddAliasAKAModel,
  UnsavedChangesService, TypeAheadDisplayResultModel, AddAliasModel, EmptyIfNull, TypeAheadMetaData
} from 'c2c-common-lib';
import { ToastsManager } from 'ng2-toastr';
import { SharedService } from '../../services/http/shared/shared.service';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { DealModel } from '../../models/deal/deal.model';
import { DealService } from '../../services/http/deal/deal.service';
import { LoadingIndicatorService } from '../../services/other/loading-indicator.service';
import { Observable } from 'rxjs/Observable';
import { DealEventService } from '../../services/events/deal-event.service';
import { AccentedCharacterService } from '../../services/http/shared/accented-character.service';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { PermissionList } from '../../enums/permission-list.enum';
import { WizardModel } from '../../models/deal/wizard.model';
import * as moment from 'moment';

@Component({
  selector: 'fc-name-project-details',
  templateUrl: './name-project-details.component.html',
  styleUrls: ['./name-project-details.component.scss'],
  providers: [SharedService]
})
export class NameProjectDetailsComponent implements OnInit {
  public accentedCharValues: any;
  // public accentedModalName: string = 'talentAccentedModalHeader';
  @ViewChild('addEditPerformerModal') public addEditPerformerModal: any;
  @ViewChild('performerTypeAhead') public performerTypeAhead: any;
  @ViewChild('addNameCompanyModal') public addNameCompanyModal: any;
  @ViewChild('addPerformerModal') public addPerformerModal: any;
  @ViewChild('accentedChars') private accentedChars: any;

  public cancelButtonOptions: CancelButtonModel;
  public dataResults: any;
  public deal: DealModel;
  public disableTypeAheadOpt: boolean = false;
  //  public displayCompanyDataResults: TypeAheadDisplayResultModel;
  //  public displayDataResults: TypeAheadDisplayResultModel;
  public displayPerformerData: TypeAheadDisplayResultModel;
  public formLoading: boolean = false;
  public i9Status: DropdownModel = new DropdownModel(null, null, null, null, []);
  public immigrationStatusList: any = [];
  public isEditPerformer: boolean = false;
  public isCompanyDisable: boolean = true;
  public loading: boolean = false;
  public nameProjectDetailsForm: FormGroup;
  public numericVal: boolean = true;
  public performerId: any;
  public prodCompany: DropdownModel = new DropdownModel(null, null, null, null, []);
  public sagStatus: DropdownModel = new DropdownModel(null, null, null, null, []);
  public selectedName: any;
  public setAccentedModalChars: any;
  public contractExit: Boolean = false;
  public performerUpdated: boolean = false;
  private newAKAID: string;
  public talentContactTypeahead: TypeAheadDisplayResultModel;
  public typeAheadCompanyModalConfigHeader: any = {
    title: 'Add New Company name',
    label: 'This is a label',
    showAddAlias: false,
    displayNameAs: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'modalCompanyHeaderName'
  };
  @ViewChild('typeAheadFieldHeader') private typeAheadField: ElementRef;
  @ViewChild('noQuoteDeal') public noQuoteDeal: any;
  public typeAheadFocus: boolean = true;
  public typeAheadModalConfigHeader: any = {
    title: 'Add New Talent name',
    label: 'This is a label',
    showAddAlias: true,
    showAlias: false,
    displayNameAs: true,
    additionalFieldsDisplayed: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'modalTalentHeaderName'
  };
  public typeAheadPlaceHolder: string = 'Type Last Name, First Name Middle Name, Suffix';
  public typeAheadModalConfig: any = this.typeAheadModalConfigHeader;
  public typeAheadTitle: string = 'PERFORMER';
  public typeAheadType: string = 'PERSON';
  public union: DropdownModel = new DropdownModel(null, null, null, null, []);
  public viewPermission: PermissionList = PermissionList.dealCreateEditView;
  public editPermission: PermissionList = PermissionList.dealCreateEditEdit;
  public disableForm: boolean = false;
  // Accented modal name Id
  public accentedModalName: string = 'talentAccentedModalHeader';
  public wizardSections: any = [];
  private saveTypeahead: any;

  constructor(
    // private addAliasService: AddAliasService,
    private route: ActivatedRoute,
    private dealService: DealService,
    private dealEventService: DealEventService,
    private sharedService: SharedService,
    private loadingService: LoadingIndicatorService,
    private unsavedChangesService: UnsavedChangesService,
    private fb: FormBuilder,
    private router: Router,
    private service: CommonModuleService,
    private toasterService: ToasterService,
    public accentdCharService: AccentedCharacterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private renderer: Renderer2,
    private userPermissionService: UserPermissionService,
    private talentService: CommonModuleService
  ) {
    this.disableForm = this.createEditPermission();
    this.toaster.setRootViewContainerRef(vcr);
    this.loadingService.onLoadingChanged.subscribe(
      (isLoading) => {
        if (!this.loading) {
          this.formLoading = isLoading;
        }
      });

  }

  public addEditPerformer(): void {
    if (this.performerId) {
      this.addEditPerformerModal.open(this.performerId);
    }
  }

  public calculateMinor(dob: string): any {
    const dealDate = this.nameProjectDetailsForm.get('dealDate').value;
    if (dob && dealDate) {
      const ageDiff = new Date(dealDate).getTime() - new Date(dob).getTime();
      const ageDate = new Date(ageDiff);
      const age = Math.abs(ageDate.getUTCFullYear() - 1970);
      if (age < 18) {
        this.nameProjectDetailsForm.get('minor').patchValue(true);
      } else {
        this.nameProjectDetailsForm.get('minor').patchValue(false);
      }
    } else {
      this.nameProjectDetailsForm.get('minor').patchValue(false);
    }
  }


  /**
   * Determines if the form has any unsaved changes, if so, transition message
   * will be displayed. If user confirms, routing continues to navigate.
   */
  public canDeactivate(): Observable<boolean> | boolean {
   if (!this.disableForm) {
    if (this.nameProjectDetailsForm.dirty && this.nameProjectDetailsForm.touched) {
      this.unsavedChangesService.openModal();
      return this.unsavedChangesService.onCloseModal();
    }
     return true;
   }


return true;
  }

  private dealDateChanges(formGroup): void {
    const dealDate = formGroup.get('dealDate');
    dealDate.valueChanges.subscribe(
      () => {
        const performerDetail = this.dealService.performerDetail;
        if (performerDetail) {
          this.calculateMinor(performerDetail.dob);
        }
      }
    );
  }

  private prepareImmigrationList(list: any[]): void {
    const immigrationList = [];
    if (list && list.length) {
      list.forEach((item) => {
        immigrationList.push(item.value + ', ' + item.expires);
      });
      this.immigrationStatusList = [];
      this.displayImmigrationStatus(immigrationList);
    } else {
      this.immigrationStatusList = [];
    }
  }

  private displayImmigrationStatus(immigrationStatus): any {
    if (immigrationStatus.length > 0) {
      immigrationStatus.forEach(element => {
        const splitArr = element.split(',');
        let statusDate = splitArr[1];
        const isValid = moment(statusDate).isValid();
        if (isValid) {
          statusDate = moment.parseZone(statusDate).format('MM/DD/YYYY');
        } else {
          statusDate = '';
        }
        if (statusDate && moment().isAfter(statusDate)) {
          this.immigrationStatusList.push({
            label: splitArr[0] + ' - ' + statusDate,
            isExpired: true
          });
        } else if (statusDate) {
          this.immigrationStatusList.unshift({
            label: splitArr[0] + ' - ' + statusDate,
            isExpired: false
          });
        } else {
          this.immigrationStatusList.unshift({
            label: splitArr[0],
            isExpired: false
          });
        }
      });
    }
  }

  public getAccentedModalChar(char: any) {
    this.accentdCharService.getAccentedChars(char).subscribe(
      (chars) => {
        this.accentedCharValues = chars;
        this.accentedChars.openAccentedModal(chars);
      }
    );
  }

  public getAccentedModalCompanyChar(char: any) {
    this.accentdCharService.getAccentedChars(char).subscribe(
      (chars) => {
        this.setAccentedModalChars = chars;
      }
    );
  }

  public getServiceResponse(): void {
    this.route.data.subscribe(
      (data: any) => {
        this.deal = data.nameProjects.dealData;
        this.contractExit = this.deal.contractExist;
        this.createPersonMetaData(data.nameProjects.personMetadata);
        this.initializeForm();
      },
      (error) => {
        console.log('Error when getting name project details', error);
      }
    );
  }

  public checkTypeaheadClear(event): void {
    const value = this.performerTypeAhead.typeAheadField.nativeElement.value;
    // Check if typeahead value loss by talent or any other modal
    if (!value) {
      if (this.saveTypeahead) {
        this.setPerformerName(this.saveTypeahead, false);
      } else {
        const details = this.nameProjectDetailsForm.get('performer').value;
        if (details) {
          setTimeout(() => {
            this.performerTypeAhead.typeAheadField.nativeElement.value = details.typeAheadDisplayName;
            this.performerTypeAhead.setTypeaheadBtnDisable();
          }, 300);
        }
      }
    }
    if (event.data) {
      this.performerUpdated = true;
      this.prepareImmigrationList(event.data.immigration);
      this.calculateMinor(event.data.dob);
    }
  }

  private createPersonMetaData(metadata: any): void {
    this.displayPerformerData = this.sharedService.displayDataResults;
    if (metadata && metadata.length > 2) {
      this.displayPerformerData.metaDataColumns['default'] = [TypeAheadMetaData[metadata[metadata.length - 2]],
      TypeAheadMetaData[metadata[metadata.length - 1]]];
    }
  }

  public getDropdownOptions(lookupType: string): any {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.sharedService.getDropdown(lookupType).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          delete data[i].links;
          options.push(data[i]);
        }
      }
    );
    return dropdownModel;
  }

  public getProdCompanyDropdown(projectId): any {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.dealService.getProductionCompaniesByProject(projectId).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          delete data[i].links;
          // options.push(data[i]);
          options.push({
            value: data[i].entityName,
            id: data[i].partyId,
            data: data[i]
          });
        }
      }
    );
    return dropdownModel;
  }

  public getUnionDropdown(projectId, companyId): any {
    this.loading = true;
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.dealService.getUnionByProjectAndCompany(projectId, companyId).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          delete data[i].links;
          options.push(data[i]);
        }
      }
    );
    return dropdownModel;
  }

  public initializeForm(): void {
    this.nameProjectDetailsForm = this.fb.group({
      'id': this.fb.control(this.deal.id),
      'active': this.fb.control(true),
      'loanoutId': this.deal.loanoutId,
      'loanoutIdVer': this.deal.loanoutIdVer,
      'noQuoteDeal': this.fb.control(this.deal.noQuoteDeal),
      'project': this.fb.control(this.deal.project),
      'projectTitle': this.fb.control({ value: this.deal.project.title['title'], disabled: true }, Validators.required),
      'dealDate': this.fb.control(this.deal.dealDate, Validators.required),
      'performer': this.fb.control(this.deal.performer, Validators.required),
      'lead': this.fb.control(this.deal.lead),
      'minor': this.fb.control({ value: false, disabled: true }),
      'performerRoleNumber': this.fb.control(this.deal.performerRoleNumber),
      'performerRole': this.fb.control(this.deal.performerRole),
      'performerNote': this.fb.control(this.deal.performerNote),
      'productionCompany': this.fb.control({
        value: this.deal.productionCompany ? this.deal.productionCompany.entityName : '',
        id: this.deal.productionCompany ? this.deal.productionCompany.partyId : '',
        data: this.deal.productionCompany ? this.deal.productionCompany : ''
      }),
      'unionLookup': this.fb.control({
        value: this.deal.unionLookup,
        disabled: !this.deal.productionCompany
      }),
      'sagStatusLookup': this.fb.control({
        value: this.deal.sagStatusLookup,
        disabled: !this.deal.unionLookup
      }),
      'sagStatusNote': this.fb.control(this.deal.sagStatusNote),
      'performerINineStatus': this.fb.control(this.deal.performerINineStatus),
      'i9StatusNote': this.fb.control(this.deal.i9StatusNote)
    });
    this.dealDateChanges(this.nameProjectDetailsForm);
    this.prodCompanyChanges(this.nameProjectDetailsForm);
    this.unionValueChanges(this.nameProjectDetailsForm);
    if (this.deal.performer) {
      this.performerId = this.deal.performer.partyId;
      const type = this.deal.performer.partyType;
      /* this.typeAheadType = 'PERSON';
      if (type === 'COMPANY') {
        this.typeAheadType = 'COMPANY';
      } */
      this.selectedPerformer(this.deal.performer, false);
      this.isEditPerformer = true;
    }
  }

  public isFormInvalid(formGroup: FormGroup, field: string): boolean {
    return formGroup.get(field).invalid && formGroup.get(field).touched;
  }

  public ngOnInit(): void {
    this.getServiceResponse();
    this.sagStatus = this.getDropdownOptions('SAG_STATUS');
    this.i9Status = this.getDropdownOptions('I9_STATUS');
    this.prodCompany = this.getProdCompanyDropdown(this.deal.project.id);
    this.talentContactTypeahead = this.sharedService.displayTalentContactResults;
    if (this.deal.id) {
      this.cancelButtonOptions = new CancelButtonModel('fc', 'nameProjectDetails', 'navigate', `createDeal/${this.deal.id}/summary`);
    } else {
      this.cancelButtonOptions = new CancelButtonModel('fc', 'nameProjectDetails', 'navigate', `projectDetails/${this.deal.project.id}`);
    }
  }

  /*
  * ngAfterViewInit
  */
 public ngAfterViewInit(): void {
  this.noQuoteDeal.nativeElement.focus();
}

  public onNumericChange(searchValue: any): void {
    if (this.numericVal = isNaN(searchValue)) {
      this.numericVal = false;
    } else {
      this.numericVal = true;
    }
  }

  private getUpdatedWizardDetails() {
  this.dealService.getWizardDetails().subscribe((data: WizardModel[]) => {
    for (const wizard of data) {
      let pageRoute = wizard.page.name;
      pageRoute = pageRoute.charAt(0).toLowerCase() + pageRoute.substring(1);
      pageRoute = pageRoute.replace(/[\W\s]+/gi, '');
      const obj = { page: null, status: null, route: null };
      obj.page = wizard.page.name;
      obj.status = wizard.status;
      obj.route = pageRoute;
      this.wizardSections.push(obj);
    }
    this.dealService.setWizardDetails(this.wizardSections);
  });
}

  public onSubmit(type?: string): void {
    if (this.nameProjectDetailsForm.valid && this.numericVal) {
      const request = this.nameProjectDetailsForm.value;
      if (this.newAKAID) {
        request.performer.akaId = this.newAKAID;
      }
      request.performer.performerUpdated = this.performerUpdated;
      this.dealService.saveDeal(request).subscribe(
        (res: DealModel) => {
          this.nameProjectDetailsForm.markAsPristine();
          this.nameProjectDetailsForm.markAsUntouched();

          if (type === 'continue') {
            this.dealEventService.pageSavedEvent({ type: type, pageTo: 'loanout', dealId: res['id'] });
          } else {
            this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: res['id'] });
          }
          this.dealService.saveWizardSubtitles(this.nameProjectDetailsForm.value);
          this.dealService.setDealId(res['id'].toString());
          this.dealService.deal = this.nameProjectDetailsForm.value;
          this.getUpdatedWizardDetails();

        }, err => {
          this.toasterService.error('Failed to save Name/Project details.', 'Error');
        }
      );
    } else {
      this.validateFormFields(this.nameProjectDetailsForm);
    }
  }

  private prodCompanyChanges(formGroup): void {
    const union = formGroup.get('unionLookup');
    formGroup.get('productionCompany').valueChanges.subscribe(
      (val) => {
        union.patchValue(null);
        if (val) {
          this.union = this.getUnionDropdown(this.deal.project.id, val.id);
          union.enable();
        } else {
          union.disable();
        }
      }
    );
  }

  public onTypeaheadKeyDown(event): void {
    if (!event || (event && typeof event === 'string')) {
      this.newAKAID = null;
      this.performerId = null;
    }
  }

  public savePerformerAlias(event) {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const fields = event.editableFields;
    const vals = this.addPerformerModal.addTalentForm.value;
    const valEditFields = {
      editableFields: {
        firstName: fields.firstName,
        entityName: fields.entityName,
        middleName: fields.middleName,
        suffix: fields.suffix,
      }
    };
    aliasParty.partyType = 'TALENT';
    aliasParty.partyId = (this.addPerformerModal.selectedTypeAheadRecord) ? this.addPerformerModal.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.entity = fields.entityName ? fields.entityName : null;
    aliasParty.name.first = fields.firstName ? fields.firstName : null;
    aliasParty.name.middle = fields.middleName ? fields.middleName : null,
    aliasParty.name.suffix = fields.suffix ? fields.suffix : null;
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(valEditFields));

    const aka: AddAliasAKAModel = new AddAliasAKAModel();
    aka.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    aka.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    aka.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    aka.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    this.talentService.saveAlias(JSON.stringify([aliasParty, aka])).subscribe(
      (res) => {
        if (res && res.name) {
          this.newAKAID = res.name['nameId'];
        }
        this.performerId = res.partyId;
        this.addPerformerModal.successCBAlias(res);
      },
      (err) => {
        const errCode: string = err.error.errors[0].code;
        let message: string = 'Error, Alias did not save';
        if (errCode === 'aka.already.exist') {
          const partyName = EmptyIfNull.check(aliasParty.name.first)
            + ' ' + EmptyIfNull.check(aliasParty.name.middle)
            + ' ' + EmptyIfNull.check(aliasParty.name.entity)
            + ' ' + EmptyIfNull.check(aliasParty.name.suffix);
          message = 'Alias "' + aka.name.entity.trim() + '" for party "' + partyName.trim() + '" already exists!';
        }
        if (errCode === 'data.already.exist') {
          message = err.error.errors[0].detail;
          this.addPerformerModal.failureCBAlias(message);
        }
      }
    );
  }

  /**Method to save Alias name */
  public saveAliascompanyFunc(cName) {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();

    aliasParty.partyType = 'COMPANY';
    aliasParty.displayName = cName.typeAheadCurrentName && cName.typeAheadCurrentName.entityName ?
      cName.typeAheadCurrentName.entityName : cName.formValues.typeAheadCompany;
    aliasParty.name.entity = cName.typeAheadCurrentName && cName.typeAheadCurrentName.entityName ?
      cName.typeAheadCurrentName.entityName : cName.formValues.typeAheadCompany;
    aliasParty.partyId = (cName.typeAheadCurrentName && cName.typeAheadCurrentName.partyId) ? cName.typeAheadCurrentName.partyId : null;

    AKA.name.entity = EmptyIfNull.check(cName.formValues.aliasCompanyName);
    this.service.save(JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        this.addNameCompanyModal.successCB(res);
      },
      (err) => {
        let error = '';
        if (err.error) {
          error = err.error.errors[0].detail;
        }
        this.addNameCompanyModal.failureCB(error);
      }
    );
  }

  public saveCompanyTypeaheadModal(cName) {
    const companyObj: TypeAheadSaveModel = new TypeAheadSaveModel();
    companyObj.name.entity = cName.formValues.companyName;
    companyObj.partyType = 'COMPANY';
    companyObj.createdBy = 'Melissa Tapie';
    companyObj.updatedBy = 'Melissa Tapie';
    companyObj.partyId = null;
    const dataSet = this.talentService.getUserData();
    companyObj.dataSetId = dataSet.masterDataset;
    companyObj.updatedByApp = 'FC';
    this.service.save(JSON.stringify(companyObj)).subscribe(
      (res) => {
        if (res && res.name) {
          this.newAKAID = res.name['nameId'];
        }
        this.addNameCompanyModal.successCB(res);
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addNameCompanyModal.failureCB(errMessage);
      }
    );
  }

  public setPerformerName(event, performerUpdated:boolean): void {
    this.saveTypeahead = event;
    // TODO: WILL REMOVE TIMEOUT LATER
    setTimeout(() => {
      this.performerUpdated = performerUpdated;
      this.nameProjectDetailsForm.get('performer').patchValue(event);
      const first = event.firstName ? event.firstName : '';
      const entity = event.entityName ? ' ' + event.entityName : '';
      this.performerTypeAhead.typeAheadField.nativeElement.value = first + entity;
      this.performerTypeAhead.setTypeaheadBtnDisable();
    }, 300);
  }

  public savePerformer(isEdit: boolean) {
    const vals = this.addPerformerModal.addTalentForm.value;
    const peopleObj: TypeAheadSaveModel = new TypeAheadSaveModel();
    peopleObj.partyId = null;
    peopleObj.name.entity = vals.editableFields.entityName;
    peopleObj.name.first = vals.editableFields.firstName;
    peopleObj.partyType = 'TALENT';
    peopleObj.name.middle = vals.editableFields.middleName;
    peopleObj.name.suffix = vals.editableFields.suffix;
    peopleObj.displayName = this.createDisplayName(vals);
    peopleObj.createdBy = 'Melissa Tapie';
    peopleObj.updatedBy = 'Melissa Tapie';
    this.addPerformerModal.closeTypeaheadModal();
    this.service.save(JSON.stringify(peopleObj)).subscribe(
      (res) => {
        if (res && res.name) {
          this.newAKAID = res.name['nameId'];
        }
        this.performerId = res.partyId;
        this.addPerformerModal.successCB(res);
        if (isEdit) {
          this.addEditPerformer();
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addPerformerModal.failureCB(errMessage);
      }
    );
  }

  private createDisplayName(vals: any): string {
    let name = '';
    if (vals.editableFields.entityName) {
      name += vals.editableFields.entityName;
    }
    if (vals.editableFields.suffix) {
      if (name) {
        name += ', ' + vals.editableFields.suffix;
      } else {
        name += vals.editableFields.suffix;
      }
    }
    if (vals.editableFields.firstName) {
      if (name) {
        name += ', ' + vals.editableFields.firstName;
      } else {
        name += vals.editableFields.firstName;
      }
    }
    if (vals.editableFields.middleName) {
      if (name) {
        name += ', ' + vals.editableFields.middleName;
      } else {
        name += vals.editableFields.middleName;
      }
    }
    return name;
  }

  public selectedPerformer(event: any, performerUpdated: boolean): void {
    this.loading = true;
    this.immigrationStatusList.length = 0;
    this.dealService.getPerformerDetails(event.partyId, event.akaId, event.performerPartyIdVer).subscribe(
      (res) => {
        this.performerUpdated = performerUpdated;
        this.newAKAID = null;
        this.dealService.performerDetail = res;
        this.calculateMinor(res.dob);
        this.performerId = event.partyId;
        this.displayImmigrationStatus(res.immigrationStatusList);
      }
    );
    //  this.disableTypeAheadOpt = true;
  }

  public selectTypeAheadMode(type: string): any {
    // this.typeAheadType = type;
    if (this.deal.performer) {
      this.deal.performer.partyType = type;
    }
    if (type === 'PERSON') {
      this.displayPerformerData = this.sharedService.displayDataResults;
      this.typeAheadPlaceHolder = 'Type Last Name, First Name Middle Name, Suffix';
      this.typeAheadModalConfig = this.typeAheadModalConfigHeader;
    } else {
      this.displayPerformerData = this.sharedService.displayCompanyDataResults;
      this.typeAheadPlaceHolder = 'Type Company Name';
      this.typeAheadModalConfig = this.typeAheadCompanyModalConfigHeader;
    }
  }

  private unionValueChanges(formGroup): void {
    formGroup.get('unionLookup').valueChanges.subscribe(
      (val) => {
        if (val && (val.name === 'SAG' || val.name === 'SAG-AFTRA')) {
          formGroup.get('sagStatusLookup').enable();
        } else {
          formGroup.patchValue({
            sagStatusLookup: null
          });
          formGroup.get('sagStatusLookup').disable();
        }
      }
    );
  }

  /**
   * Called when the form is invalid in order to mark the invalid controls.
   *
   * @param formGroup The FormGroup to mark.
   */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  public createEditPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.viewPermission) === true &&
      this.userPermissionService.hasPermission(this.editPermission) === false) {
      return true;
    } else if (this.userPermissionService.hasPermission(this.viewPermission) === true &&
      this.userPermissionService.hasPermission(this.editPermission) === true) {
      return false;
    }
  }

    /**Method to check box on click of enter key */
    public enterKeyPressed(event: any): void {
      const checkBox = <HTMLInputElement>document.getElementById('fc-lead-checkbox');
      const isChecked = checkBox.checked;
      const keyCode = event.keyCode ? event.keyCode : event.which;
      if (keyCode === 13) {
         if (checkBox.checked) {
          checkBox.classList.add('c2c-input-checkboxes-checked');
         } else {
          checkBox.classList.remove('c2c-input-checkboxes-checked');
         }
      }
     }
}
