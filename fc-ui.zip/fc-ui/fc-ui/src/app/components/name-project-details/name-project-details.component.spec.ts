import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NameProjectDetailsComponent } from './name-project-details.component';

describe('NameProjectDetailsComponent', () => {
  let component: NameProjectDetailsComponent;
  let fixture: ComponentFixture<NameProjectDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NameProjectDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NameProjectDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
