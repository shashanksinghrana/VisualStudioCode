import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerqsComponent } from './perqs.component';

describe('PerqsComponent', () => {
  let component: PerqsComponent;
  let fixture: ComponentFixture<PerqsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerqsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerqsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
