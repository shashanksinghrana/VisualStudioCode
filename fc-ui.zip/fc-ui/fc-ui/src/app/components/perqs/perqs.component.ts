import { Component, OnInit, ViewContainerRef, ViewChild } from '@angular/core';
import { DropdownModel, CheckboxModel, UnsavedChangesService, AddButtonModel, ToasterService, ModalApplicableNotApplicableComponent } from 'c2c-common-lib';
import { FormGroup, Validators, FormArray, FormBuilder } from '@angular/forms';
import { LoadingIndicatorService } from '../../services/other/loading-indicator.service';
import { DealEventService } from '../../services/events/deal-event.service';
import { SharedService } from '../../services/http/shared/shared.service';
import { DealService } from '../../services/http/deal/deal.service';
import { PerqsService } from '../../services/http/deal/perqs.service';
import { ActivatedRoute } from '@angular/router';
import { PerqsModel } from '../../models/deal/perqs.model';
import { DealModel } from '../../models/deal/deal.model';
import { Observable } from 'rxjs/Observable';
import { ToastsManager } from 'ng2-toastr';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';



@Component({
  selector: 'fc-perqs',
  templateUrl: './perqs.component.html',
  styleUrls: ['./perqs.component.scss']
})
export class PerqsComponent implements OnInit {
  public addButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add');
  public checkboxOptions: CheckboxModel =
    new CheckboxModel('thisId', 'thisName', [{ value: 'v5', label: 'Paid Ads', checked: false, showTitle: true }]);
  public perqsForm: FormGroup;
  public deal: DealModel;
  public dealID;
  public perqsTermForm: FormGroup;
  public loading: boolean = false;
  public loanout: any;
  public isEdit: boolean = false;
  public isChecked: boolean = false;
  public isTermArrayEmpty: boolean = false;
  public isTitle: boolean = false;
  public showText: boolean = false;
  public disableBtn: boolean = true;
  public defaultTerm;
  public isCheckBox: boolean = false;
  public editedPerqsList: any = [];
  public perqTypeLookup: DropdownModel = new DropdownModel(null, null, null, null, []);
  public type: string;
  public status: string;
  public skipUnsavedModalEvent: boolean = false;
  public viewPermission:PermissionList=PermissionList.dealCreateEditView
  public editPermission:PermissionList=PermissionList.dealCreateEditEdit
  public disableForm:boolean=false;
  public isEdited: boolean = false;

  @ViewChild('applicableNotApplicableModal') public applicableNotApplicableModal: ModalApplicableNotApplicableComponent;
  @ViewChild('termDropdown') public termDropdown: any;
  @ViewChild('perqNote') public perqNote: any;
  /**
  * Constructor for the PerqsComponent
  *
  * @param router The router to handle all navigation.
  * @param sharedService The Shared Service for common services.
  * @param fb FormBuilder instance for building form elements.
  * @param toasterService The common Toaster Service for calling toast messages.
  */
  constructor(
    private perqsService: PerqsService,
    private sharedService: SharedService,
    private route: ActivatedRoute,
    private dealService: DealService,
    private dealEventService: DealEventService,
    private unsavedChangesService: UnsavedChangesService,
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private loadingService: LoadingIndicatorService,
    private userPermissionService:UserPermissionService
  ) {
    this.disableForm=this.createEditPermission();

    this.toaster.setRootViewContainerRef(vcr);
    this.perqTypeLookup = this.getDropdownOptions('PERQ');
  }

  ngAfterViewInit() {
    if(!this.disableForm)
    {
      this.termDropdown.dropdownButton.nativeElement.focus();
    }
  }

  /**
   * Resets (clears) the given FormGroup.
   *
   * @param formGroup The FormGroup to reset.
   */
  public clearForm(formGroup): void {
    const note = this.removeNoteText(this.perqsTermForm.value.perqText);
    this.perqsTermForm.reset({ 'perqsTermVal': null, 'paidAdInd': null, 'perqText': note });
    this.editedPerqsList.splice(0, 1);
    this.perqsTermForm.markAsUntouched();
    this.isCheckBox = false;
  }

  /* Method to get data from RTE note*/
  public getTextPerqsNote(note) {
    var doc = (new DOMParser()).parseFromString(note, "text/html");
    return doc.body.innerText.trim();
  }

  /**
   * Checks to see if the FormGroup is invalid.
   *
   * @param formGroup The FormGroup to run validation on.
   * @param field The FormControl to check in the given FormGroup.
   */
  public isFormInvalid(formGroup, field): boolean {
    return formGroup.get(field).invalid && formGroup.get(field).touched;
  }

  /*
   * Method to invoke unsaved modal
  */
  public canDeactivate(): Observable<boolean> | boolean {
    const termArray = <FormArray>this.perqsForm.controls.perqsTermOne;
    if (this.perqsTermForm.dirty && this.perqsTermForm.touched && !this.skipUnsavedModalEvent) {
      this.unsavedChangesService.openModal();
      return this.unsavedChangesService.onCloseModal();
    }
    return true;
  }

  /* Method to get data from RTE note*/
  public removeNoteText(note) {
    var doc = (new DOMParser()).parseFromString(note, "text/html");
    var text = doc.body.innerText.trim();
    return '';
  }

  /**
  * Populates the dropdown value when populating the form.
  */
  public getDropdownSelection(type, value, field) {
    let selection = value;
    if (type.options) {
      type.options.forEach((val) => {
        if (value === val[field]) {
          selection = val;
        }
      });
    }
    return selection;
  }

  /* Method to get Dropdown value on change */
  public onChangeTerm(id) {
    if (!this.isEdit) {
      this.defaultTerm = this.perqsTermForm.value['perqsTermVal'].value;
    }
    var paidCheckVal = this.perqsTermForm.value['perqsTermVal'].value;
    (paidCheckVal === 'Paid Ads') ? this.isCheckBox = true : this.isCheckBox = false; this.isChecked = false;
  }

  /* Method to get Dropdown Options and values */
  public getDropdownOptions(lookupType: string) {
    let options: any[] = [];
    let dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.sharedService.getDropdown(lookupType).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
      }
    );
    return dropdownModel;
  }

  public ngOnInit(): void {
    this.perqsForm = this.fb.group({
      'perqsTermOne': this.fb.array([])
    });
    this.perqsTermForm = this.fb.group({
      'perqsTermVal': this.fb.control(this.getDropdownSelection(this.perqTypeLookup, '', 'value'), Validators.required),
      'paidAdInd': this.fb.control(null),
      'perqText': this.fb.control(null)
    });
    this.loadingService.onLoadingChanged.subscribe(
      (isLoading) => this.loading = isLoading
    );
    this.deal = this.dealService.deal;
    this.dealID = this.deal.id;
    this.loanout = this.dealService.loanout;
    if (this.dealID && this.dealID !== 'new') {
      this.disableBtn = false;
      this.getPerqsData();
    }
  }

  /**
  * Called when the form is invalid in order to mark the invalid controls.
  *
  * @param formGroup The FormGroup to mark.
  */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  /**
   * Get all the perqs data.
   */
  public getPerqsData() {
    this.route.data.subscribe(
      (data: { perq: PerqsModel }) => {
        this.perqsForm.setValue({
          'perqsTermOne': this.getTermData(data.perq.perqs)
        });
      },
      (error) => {
        console.log('Error while getting perqs data', error);
      }
    );
  }

  /**
  * Populates the Perq Term section one Array in the form.
  *
  * @param data The existing data to iterate over.
  */
  public getTermData(data): FormArray {
    const perqsTermArray = <FormArray>this.perqsForm.controls.perqsTermOne;
    data.forEach((item) => {
      let perqNote = this.getTextPerqsNote(item.perqText);
      perqNote = (!perqNote || (perqNote === "null")) ? '' : perqNote;
      perqsTermArray.push(this.fb.group({
        'perqsTermVal': this.fb.control({ value: this.getDropdownSelection(this.perqTypeLookup, item.perqTypeLookup.id, 'id'), disabled: true }),
        'perqText': this.fb.control({ value: perqNote, disabled: true }),
        'paidAdInd': this.fb.control({ value: item.paidAdInd, disabled: true }),
        'perqNotesForSave': this.fb.control({ value: item.perqText, disabled: true })
      }));
    });
    return perqsTermArray;
  }

  /* Method to add line with note */
  public addTermLine(): void {
    if (!this.perqsForm.invalid && this.perqsTermForm.value['perqsTermVal']) {
      const termArray = <FormArray>this.perqsForm.controls.perqsTermOne;
      this.editedPerqsList.splice(0, 1);
      let termNote = this.getTextPerqsNote(this.perqsTermForm.value.perqText);
      termNote = (!termNote || (termNote === "null")) ? '' : termNote;
      termArray.push(this.fb.group({
        'perqsTermVal': this.fb.control({ value: this.perqsTermForm.value['perqsTermVal'], disabled: true }),
        'perqText': this.fb.control({ value: termNote, disabled: true }),
        'paidAdInd': this.fb.control({ value: this.perqsTermForm.value['paidAdInd'], disabled: true }),
        'perqNotesForSave': this.fb.control({ value: this.perqsTermForm.value.perqText, disabled: true }),
      }));
      this.isEdit = false;
      this.isTitle = true;
      this.isCheckBox = false;
      const note = this.removeNoteText(this.perqsTermForm.value.perqText);
      this.perqsTermForm.reset({ 'perqText': note, 'paidAdInd': null });
      this.isTermArrayEmpty = false;
      this.perqsTermForm.controls.perqsTermVal.markAsPristine();
      this.perqsTermForm.controls.perqsTermVal.markAsUntouched();
      // this.perqsTermForm.markAsPristine();
      // this.perqsTermForm.markAsUntouched();
    } else {
      this.validateFormFields(this.perqsTermForm);
      //this.toasterService.info('Please enter data', 'Cancel Success');
    }
  }

  /**
    * This function is used to begin the process of term one section edit.
    *
    * @param formGroup The FormGroup to edit.
    */
  public editTermSet(formGroup, index): void {
    this.isEdit = true;
    this.perqsTermForm.reset({
      'perqsTermVal': formGroup.value.perqsTermVal,
      'perqText': formGroup.value.perqNotesForSave,
      'paidAdInd': formGroup.value.paidAdInd
    });
    this.editedPerqsList.push({
      "index": index,
      "value": formGroup.value
    });
    var paidCheckVal = this.perqsTermForm.value['perqsTermVal'].value;
    var paidChecked = this.perqsTermForm.value['paidAdInd'];
    if (paidCheckVal === 'Paid Ads') {
      this.isCheckBox = true;
      this.showText = true;
      this.isChecked = paidChecked;
    } else {
      this.isCheckBox = false;
      this.isChecked = false;
    }
    // this.perqNote.editorDiv.nativeElement.focus();changed as focus is for dropdown
    this.termDropdown.dropdownButton.nativeElement.focus();
    this.removeLineTerm(index);
  }

  /**
   * Removes the given line from list.
   *
   * @param index The position in the array of the row to be removed.
   */
  public removeLineTerm(index) {
    const termArray = <FormArray>this.perqsForm.controls.perqsTermOne;
    termArray.removeAt(index);
    this.isEdited = true;
    this.perqsTermForm.controls.perqText.markAsDirty();//for removing validation error on delete record
    this.perqsTermForm.controls.perqText.markAsTouched();
    this.perqsTermForm.markAsDirty();
    this.perqsTermForm.markAsTouched();
    this.isTermArrayEmpty = true;
    if (!termArray.controls.length) {
      this.validateFormFields(this.perqsTermForm);
      this.perqsTermForm.controls.perqsTermVal.markAsPristine();
      this.perqsTermForm.controls.perqsTermVal.markAsUntouched();
    }
    (termArray.controls.length <= 0) ? this.isTitle = false : this.isTitle = true;
  }


  /* Method to cancel and and display Toaster */
  public cancelPerqs() {
    this.clearForm(this.perqsTermForm);
  }

  /*
  * Submit the perqs form for saving the perqs details.
 */
  public onSubmit(type?: string): void {
    this.skipUnsavedModalEvent = true;
    if (this.dealService.currentWizardPage.status) {
      if (this.perqsForm.value.perqsTermOne.length === 0 && this.dealService.currentWizardPage.status.name !== 'NOT_APPLICABLE') {
        this.type = type;
        this.openApplicableNotApplicableModal();
      }
    }
    if (this.perqsForm.value.perqsTermOne.length === 0 && !this.dealService.currentWizardPage.status) {
      this.type = type;
      this.openApplicableNotApplicableModal();
    } else if (this.perqsForm.value.perqsTermOne.length > 0 || this.dealService.currentWizardPage.status.name == 'NOT_APPLICABLE' || this.isEdited) {
      const dealId: string = this.dealService.getDealId();
      const perqs: any[] = [];
      let perqObj;
      this.perqsForm.value.perqsTermOne.forEach((item, index) => {
        perqs.push({
          "dealId": Number.parseInt(dealId),
          "perqText": item.perqNotesForSave,
          "printRiderInd": false,
          "paidAdInd": item.paidAdInd,
          "perqTypeLookup": {
            "name": item.perqsTermVal.value,
            "type": item.perqsTermVal.data.type,
            "displayOrder": item.perqsTermVal.data.displayOrder,
            "id": item.perqsTermVal.id
          },
          "id": null
        })
        perqObj = {
          perqs
        }
      });

      if (this.editedPerqsList.length > 0) {
        this.editedPerqsList.forEach((element, index) => {
          let val = this.editedPerqsList[index];
          let perqsDropdown = this.getDropdownSelection(this.perqTypeLookup, val.value.perqsTermVal.value, 'id');
          perqs.push({
            "dealId": Number.parseInt(dealId),
            "perqText": val.value.perqText,
            "printRiderInd": false,
            "paidAdInd": val.value.paidAdInd,
            "perqTypeLookup": {
              "name": val.value.perqsTermVal.value,
              "type": val.value.perqsTermVal.data.type,
              "displayOrder": val.value.perqsTermVal.data.displayOrder,
              "id": val.value.perqsTermVal.id
            },
            "id": null
          });
        });
      }
      if (!this.perqsForm.invalid) {
        this.perqsTermForm.markAsPristine();
        this.perqsTermForm.markAsUntouched();
        if (this.perqsForm.controls.perqsTermOne.value.length != 0) {
          this.savePerqs(perqs, this.deal.id, type);
        } if (this.isTermArrayEmpty && this.perqsForm.value.perqsTermOne.length === 0) {
          this.perqsService.savePerqsRecord(perqs, this.deal.id).subscribe(
            res => {
              this.perqsForm.markAsPristine();
              this.perqsForm.markAsUntouched();
            })
        } else if (this.isTermArrayEmpty && this.perqsForm.value.perqsTermOne.length) {
          this.savePerqs(perqs, this.deal.id, type);
        } else {
          this.perqsForm.markAsPristine();
          this.perqsForm.markAsUntouched();
          this.navigatePerqs(type);
        }
      } else {
        this.validateFormFields(this.perqsForm);
      }
    }
  }

  /* Method to save data*/
  public savePerqs(perqs, id, type): void {
    this.perqsService.savePerqsRecord(perqs, id).subscribe(
      res => {
        this.perqsForm.markAsPristine();
        this.perqsForm.markAsUntouched();
        this.navigatePerqs(type);
      }, err => {
        this.toasterService.error('Failed to save Perqs.', 'Error');
        console.error('There was an error', err);
      }
    );
  }

  /*Method to navigate perqs*/
  public navigatePerqs(type): void {
    if (type == 'continue') {
      this.dealEventService.pageSavedEvent({ type: type, pageTo: 'workActivity', dealId: this.dealID, status: (!this.perqsForm.value.perqsTermOne.length) ? this.dealService.currentWizardPage.status.name: 'COMPLETE' });
    } else {
      this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: this.dealID, status: (!this.perqsForm.value.perqsTermOne.length) ? this.dealService.currentWizardPage.status.name: 'COMPLETE' });
    }
  }

  /* Method to open modal popup */
  public openApplicableNotApplicableModal(): void {
    this.applicableNotApplicableModal.openModal();
  }

  public applicableModalClosedEvent(event): void {
    if (event == 'OK') {
      const dealId: string = this.dealService.getDealId();
      if (this.type == 'continue') {
        this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'workActivity', dealId: parseInt(dealId), status: this.status });
      } else {
        this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'summary', dealId: parseInt(dealId), status: this.status });
      }
    }
  }

  public applicableConfVal(event) {
    if (event) {
      if (event === "Skip and complete later?") {
        this.status = 'INCOMPLETE';
      } else {
        this.status = 'NOT_APPLICABLE';
      }
    }
  }
  public createEditPermission():boolean
  {
if(this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === false)
{
return true;
}  
else if(this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === true)
{
  return false;
} 
}
}
