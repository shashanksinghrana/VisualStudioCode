import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { DropdownModel, RadioButtonModel, PowersearchEventService } from 'c2c-common-lib';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'powersearch-comp-work',
  templateUrl: './powersearch-comp-work.component.html',
  styleUrls: ['./powersearch-comp-work.component.scss']
})
export class PowerSearchCompWorkComponent implements OnInit, OnDestroy {
  public rangOptions: DropdownModel;
  public operandOptions: DropdownModel;
  public showRadioOptions: boolean = false;
  private subscriptions: Subscription = new Subscription();

  /** The name of the form to add this control to. Should always be 'powersearchForm' */
  @Input() public formName: FormGroup;

  /** Defines whether the 'choice' is expanded or collapsed (collapsed by default) */
  // @Input() public isOpen: boolean = false;

  /** The name of the array to add to the form. Should share the name of the field in the given 'choice' */
  @Input() public formArrName: string;

  @Input() public displayData: any;

  @Input() public choiceData: any;

  @Input() public isCurrency: boolean = true;

  /** Defines the values to be displayed in the checklist.
   *  Ideally these should be of type {@link LookupModel} to be consistent with the application */

  public initFirstTime: boolean = false;
  public isDataLoaded: boolean = false;
  @Input() public options: any;

  public resetData: any;
  @Input('resetData')
  set _resetData(data: any) {
    if (data && data.reset) {
      // Wait still to load other input properties
      setTimeout(() => {
        this.resetForm();
        this.initFirstTime = false;
      });
    }
  }

  /** Defines whether the 'choice' is expanded or collapsed (collapsed by default) */
  public isOpen: boolean = false;
  @Input('isOpen')
  set _isOpen(open: boolean) {
    this.isOpen = open;
    // Don't reload list again once clicked on list.
    if (this.isOpen && !this.initFirstTime) {
      // Wait still to load other input properties
      setTimeout(() => {
        this.isDataLoaded = true;
        this.initFirstTime = true;
        this.initForm(false);
        const formArr = this.formName.get(this.formArrName) as FormArray;
        if (this.options && this.options.data) {
          formArr.controls = [];
          const length = (this.options.data.length - 1);
          this.options.data.forEach((element, index) => {
            formArr.push(this.buildCriteria(element));
            // check last element operand is selected or not and then push empty element
            if (length === index && element.label && element.label.condition) {
              formArr.push(this.createFormControl(''));
            }
          });
          /* formArr.controls.forEach((control, index) => {
            this.addCriteria(control, index, true);
          }); */
        }
        this.makeFormDirty();
      }, 100);
    } else if (this.isOpen) {
      this.makeFormDirty();
    }
  }

  public radioOptions: RadioButtonModel = new RadioButtonModel(
    'thisRadioTitle',
    [
      {
        title: 'AND',
        checkedByDefault: false,
        disabled: false,
        showTitle: true
      },
      { title: 'OR', checkedByDefault: false, disabled: false, showTitle: true }
    ]
  );

  constructor(private psEventService: PowersearchEventService, private fb: FormBuilder) { }

  public ngOnInit() {
    // this.initForm();
    this.rangOptions = new DropdownModel(null, null, null, null, this.getRangeDropdownOptions());
    this.operandOptions = new DropdownModel(null, null, null, null, this.getOperandDropdownOptions());
    this.addSubscriptions();
  }

  private initForm(reset: boolean): void {
    const arr = this.formName.get(this.formArrName) as FormArray;
    /* if (reset) {
      arr.controls = [];
    } */
    if (!arr.length) {
      arr.push(this.buildCriteria(''));
    }
    const fg: FormGroup = this.fb.group({});
    fg.addControl('value', new FormControl({ value: true, disabled: true }));
    fg.addControl('isRange', new FormControl({ value: true }));
    fg.addControl('showRadioOptions', new FormControl({ value: true }));
  }

  private addSubscriptions(): void {
    this.subscriptions.add(
      this.psEventService.getCategoryRemoved().subscribe(fieldName => {
        if (this.formArrName === fieldName) {
          this.removeAllCriteria(fieldName);
        }
      })
    );
    this.subscriptions.add(
      this.psEventService.getSelectionRemoved().subscribe(event => {
        if (this.formArrName === event.fieldName) {
          this.removeCriteria(event.fieldName, event.index);
        }
      })
    );
  }

  private makeFormDirty(): void {
    const formArr = this.formName.get(this.formArrName) as FormArray;
    formArr.markAsDirty();
    formArr.markAsTouched();
  }

  private clearFormArray(formArray: FormArray): void {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  private resetForm(): void {
    const arr = this.formName.get(this.formArrName) as FormArray;
    this.clearFormArray(arr);
    arr.push(this.createFormControl(''));
    if (this.options) {
      this.options.data = null;
    }
  }

  private createFormControl(val): FormGroup {
    return new FormGroup({
      operation: this.fb.control(this.rangOptions.options[0]),
      type: this.fb.control(this.operandOptions.options[0]),
      value1: this.fb.control(null, Validators.required),
      value2: this.fb.control(null),
      condition: this.fb.control(null),
      value: this.fb.control(val),
      isRange: this.fb.control(true),
      showRadioOptions: this.fb.control(true)
    });
  }

  public buildCriteria(val: any): FormGroup {
    if (!(typeof val === 'string')) {
      return new FormGroup({
        operation: this.fb.control(val.label.operation),
        type: this.fb.control(val.label.type),
        value1: this.fb.control(val.value.value1, Validators.required),
        value2: this.fb.control(val.value.value2 ? val.value.value2 : null),
        condition: this.fb.control(
          val.label.condition ? val.label.condition : null
        ),
        value: this.fb.control(val.value.value),
        isRange: this.fb.control(val.label.isRange ? val.label.isRange : true),
        showRadioOptions: this.fb.control(true)
      });
    } else {
      return this.createFormControl(val);
    }
  }

  /**
   * Adds another work-activity or compensation component to the list when pressing the radio button.
   */
  public addCriteria(criteria, index, skipCriteria?: boolean): void {
    const criterias = this.formName.get(this.formArrName) as FormArray;
    if (criteria.valid) {
      if (index === criterias.controls.length - 1) {
        this.updateCriteria(criteria);
        if (!skipCriteria) {
          criterias.push(this.buildCriteria(''));
        }
      }
    } else {
      this.validateFormFields(criteria);
    }
  }

  private updateCriteria(criteria): void {
    const formValues = criteria.value;
    const value1 = formValues.value1;
    const value2 = formValues.value2;
    if (value1 && isNaN(parseFloat(value1)) || value2 && isNaN(parseFloat(value2))) {
      criteria.get('value').setValue(null);
    } else {
      let formatVal = formValues.type.value + ' ' + formValues.operation.value + ' ' + value1;
      if (value2) {
        formatVal += ' and ' + value2;
      }
      criteria.get('value').setValue({ value: formatVal });
    }
  /*   
    this.formName.markAsDirty();
    this.formName.markAsTouched(); */
  }

  /**
   * Used to remove a item from the 'Your Selections' section. If it's the last one - set value to empty string.
   * Listens to an event from the {@link PowersearchComponent} before removing the item.
   *
   * @param fieldName The name of the field to remove the item from.
   * @param index The index position of the item to remove.
   */
  public removeCriteria(fieldName, index): void {
    const criterias = this.formName.get(fieldName) as FormArray;
    if (criterias) {
      if (criterias.controls.length !== 1) {
        criterias.removeAt(index);
      } else {
        criterias.controls[index].patchValue({ value: '' });
      }
      criterias.controls[criterias.controls.length - 1].patchValue({ condition: false });
    }
  }

  /**
    * Used to remove all items from a particular category from the 'Your Selections' section as well as adding a 'blank' one back in.
    * Listens to an event from the {@link PowersearchComponent} before removing the items.
    *
    * @param fieldName The name of the field (category) to remove the items from.
    */
  public removeAllCriteria(fieldName) {
    const criterias = this.formName.get(fieldName) as FormArray;
    while (criterias.length) {
      criterias.removeAt(0);
    }
    criterias.push(this.buildCriteria(''));
    this.choiceData.isOpen = false;
  }

  public onSelectRange(criteria, index) {
    if (criteria.value.operation.value !== 'Between') {
      criteria.get('value2').setValue('');
      criteria.get('value2').setValidators([]);
      criteria.get('isRange').setValue(false);
    } else {
      criteria.get('isRange').setValue(true);
      criteria.get('value2').setValidators([Validators.required]);
    }
    this.onCriteriaChange(criteria, index);
  }

  public onCriteriaChange(criteria, index) {
    if (criteria && criteria.valid) {
      criteria.get('showRadioOptions').setValue(true);
      this.updateCriteria(criteria);
    } else {
      criteria.get('showRadioOptions').setValue(false);
    }
  }

  /**
   * Called when the given form is invalid in order to mark the invalid controls.
   *
   * @param formGroup The FormGroup to mark.
   */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  /**
   * Method to get dropdown value
   */

  private getRangeDropdownOptions() {
    this.rangOptions = this.options.rangOptions;
    const options: any[] = [];
    for (let i = 0; i < Object.keys(this.rangOptions).length; i++) {
      options.push({
        value: this.rangOptions[i].name,
        id: this.rangOptions[i].id
      });
    }
    return options;
  }

  private getOperandDropdownOptions() {
    this.operandOptions = this.options.operandOptions;
    const options: any[] = [];
    for (let i = 0; i < Object.keys(this.operandOptions).length; i++) {
      options.push({
        value: this.operandOptions[i].name,
        id: this.operandOptions[i].id
      });
    }
    return options;
  }

  public getRangeField(formGroup, field): boolean {
    return formGroup.get(field).value;
  }

  public getRadioField(formGroup, field): boolean {
    return formGroup.get(field).value;
  }

  public onBlur(formGroup, field): void {
    const control = formGroup.get(field);
    if (control && control.value) {
      if (!control.value.match(/^-?\d*(\.\d+)?$/)) {
        control.patchValue(null);
      }
    } else {
      control.patchValue(null);
    }
  }

  public ngOnDestroy(): void {
    this.resetForm();
    this.subscriptions.unsubscribe();
  }
}
