import { Component, OnInit, OnDestroy, ViewChild, ViewContainerRef, Renderer } from '@angular/core';
import { ColumnDefModel, ToasterService } from 'c2c-common-lib';
import { ActivatedRoute, Params } from '@angular/router';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { ToastsManager } from 'ng2-toastr';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { PermissionList } from '../../enums/permission-list.enum';


@Component({
  selector: 'fc-crew',
  templateUrl: './crew.component.html',
  styleUrls: ['./crew.component.scss']
})
export class CrewComponent implements OnInit {

  @ViewChild('addEditPerson') public addEditPerson: any;
  public columnApi: any;
  public crewData: any[];
  public crewDatesDefs: ColumnDefModel[];
  public gridApi: any;
  public isPartyIdSame: boolean = false;
  public isSave: boolean = false;
  public pageOptions: {};
  public projectId: number;
  public crewEditPermission: PermissionList = PermissionList.projectDetailsCrewUpdate;
  public crewViewPermission: PermissionList = PermissionList.projectDetailsCrewView;
  public crewCreatePermission: PermissionList = PermissionList.projectDetailsCrewCreate;
  public createCrew: boolean = true;
  public editPerm:boolean=false;

  /*
   * The Constructor for CrewComponent
   *
   * @param route The active route.
   * @param projectDetailService The Project Details Service for getting data.
   */
  constructor(
    private route: ActivatedRoute,
    private projectDetailService: ProjectDetailService,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private renderer: Renderer,
    private userPermissionService: UserPermissionService
  ) {
   this.editPerm=this.editPermission();
    this.createCrew = this.createPermission();
    this.toaster.setRootViewContainerRef(vcr);
    this.route.parent.params.subscribe(res => this.projectId = res.projectId);
    this.pageOptions = projectDetailService.getStatusDatesPageOptions( this.createCrew);
    this.crewDatesDefs = projectDetailService.crewDataColDefs(this.editPermission());
    this.getCrewData(this.projectId);
   }

   /** Method to perform action on click of grid cell
    * @param cellData complete cell data
    */
   public cellClicked(cellData: any): any {
     if(!this.editPerm)
     {
      if (cellData && cellData.colDef.field) {
        if (cellData.colDef.field === 'lastName') {
           this.addEditPerson.open(cellData.data);
        }
     }
     }
      
   }

public editPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.crewViewPermission) === true &&
      this.userPermissionService.hasPermission(this.crewEditPermission) === false) {
          return true;
    } else if (this.userPermissionService.hasPermission(this.crewViewPermission) === true &&
              this.userPermissionService.hasPermission(this.crewEditPermission) === true) {
          return false;
    }
}

public createPermission(): boolean {
  if (this.userPermissionService.hasPermission(this.crewViewPermission) === true && this.userPermissionService.hasPermission(this.crewEditPermission) === false) {
    return false;
  } else if (this.userPermissionService.hasPermission(this.crewViewPermission) === true && this.userPermissionService.hasPermission(this.crewEditPermission) === true) {
    return true;
  }
}

  /**
   * Gets all of the crew data to be displayed in the Grid.
   *
   * @param id The project id tied to crew data to get.
   */
  private getCrewData(id: number, isRefresh?: boolean): void {
    if (isRefresh && this.gridApi) {
      this.gridApi.showLoadingOverlay();
    }
    this.projectDetailService.getCrewData(id).subscribe(
      (data) => {
        if (this.gridApi) {
          this.gridApi.hideOverlay();
        }
        this.crewData = data;
        this.crewData.forEach(element => {
          if (element.contactDetails !== null && element.contactDetails instanceof Object) {
            const contactArr = [];
            let secondaryContact = [];
            const addStar = element.contactDetails.contacts.length > 0 && element.contactDetails.primaryContacts.length > 0;
            element.contactDetails.primaryContacts.forEach(contactPrimary => {
              let tempContact = '';
              tempContact = contactPrimary.value + ' - ' + contactPrimary.qualifierType;
              if (addStar) {
                tempContact = contactPrimary.isPrimary ? tempContact + '★' : tempContact;
              }
              contactArr.push({ value: tempContact });
            });
            element.contactDetails.contacts.forEach(contact => {
              let tempContact = '';
              tempContact = contact.value + ' - ' + contact.qualifierType;
              tempContact = contact.isPrimary ? tempContact + '★' : tempContact;
              secondaryContact.push({ value: tempContact, contactType: contact.contactType, qualifierType: contact.qualifierType });
            });
            // separating contact type
            if (secondaryContact.length) {
              secondaryContact = secondaryContact.reduce((h, a) => Object.assign(h, {
                [a.contactType]: (h[a.contactType] || []).concat(a)
              }), {});
              // Contact sorting
              Object.entries(secondaryContact).forEach(contacts => {
                contacts[1] = contacts[1].sort((a, b) => {
                  const nameA = a.qualifierType.toLowerCase();
                  const nameB = b.qualifierType.toLowerCase();
                  if (nameA < nameB) { return -1; }
                  if (nameA > nameB) { return 1; }
                  return 0;
                });
                // attaching ordered contacct to contactArr
                contacts[1].forEach(contactOrdered => {
                  contactArr.push(contactOrdered);
                });
              });
            }

            if (contactArr.length === 1) {
              let firstElement = contactArr[0].value;
              if (firstElement.indexOf('★') >= 0) {
                firstElement = firstElement.substr(0, firstElement.indexOf('★'));
                contactArr[0].value = firstElement;
              }
            }

            element.contactDetails = contactArr;
          }
        });
      },
      (error) => {
        if (this.gridApi) {
          this.gridApi.hideOverlay();
        }
        this.toasterService.error('Error when getting Crew', error); 
      }
    );
  }

  /** Method to load data once grid is ready */
  public gridready(params: Params): void {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
   // this.columnApi.getColumn('lastName').setSort('asc');
  }

  ngOnDestroy(): void {

  }

  ngOnInit() {

  }

  /** Method to open modal popup on click of Add button */
  public onClickAdd(): void {
      this.addEditPerson.open();
  }

  /** Method to update crew grid on save Create/Edit form.*/
  public onSubmit(data: any): void {
    if (this.crewData.length) {
       this.crewData.forEach((val) => {
        if (val.partyId === data.peopleData.partyId) {
           this.isPartyIdSame = true;
        } else {
          this.isSave = true;
        }
      });
    } else {
      this.isSave = true;
    }
    this.saveCrew(data);
  }

  /**
   * Refreshes the Grid to get the latest crew data.
   *
   */
  public refreshData(isRefresh?: boolean): void {
    this.getCrewData(this.projectId, isRefresh);
    this.columnApi.getColumn('lastName').setSort('asc');
  }

  /** Method to save crew */
  public saveCrew(data: any): void {
    if (this.isSave && !this.isPartyIdSame) {
      this.projectDetailService.saveCrewData(this.projectId, data.peopleData).subscribe(
        (res) => {
              this.refreshData();
       },
        (err) => {
             console.log('Internal server error', 'Error!');
        });
    } else {
      this.refreshData();
    }
  }
}
