import { Component, OnInit, OnDestroy, ViewChild, ViewContainerRef, Renderer } from '@angular/core';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { LocationEventService } from '../../services/events/location-event.service';
import { ColumnDefModel, ToasterService } from 'c2c-common-lib';
import { ActivatedRoute, Params } from '@angular/router';
import { ToastsManager } from 'ng2-toastr';
import { Subscription } from 'rxjs';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';

@Component({
  selector: 'fc-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.scss']
})
export class LocationsComponent implements OnInit, OnDestroy {

  @ViewChild('addEditCompany') public addEditCompany: any;

  public cancelSaveClicked: boolean = false;
  private cancelSaveRowSubscription: Subscription;
  public cellEditingError: any = [];
  public cellValueChangeData: any = [];
  public columnApi: any;
  public currentRowData: any;
  public editedRowIndex: number;
  public editType: any;
  public gridApi: any;
  public isAddDisable: boolean = false;
  public locationData: any[];
  public locationDefs: ColumnDefModel[];
  public pageOptions: {};
  public projectId: number;
  private saveRowSubscription: Subscription;
  public stopEditingWhenGridLosesFocus: boolean;
  public suppressClickEdit: boolean = true;
  public validFormat: boolean = true;
  public locEditPermission: PermissionList = PermissionList.projectDetailsLocationEdit;
  public locViewPermission: PermissionList = PermissionList.projectDetailsLocationView;
  public locCreatePermission: PermissionList = PermissionList.projectDetailsLocationCreate;
  public createLocation: boolean = true;


  /*
   * The Constructor for LocationComponent
   * @param route The active route.
   * @param projectDetailService The Project Details Service for getting data.
   */
  constructor(
    private route: ActivatedRoute,
    private projectDetailService: ProjectDetailService,
    private toasterService: ToasterService,
    private locationEventService: LocationEventService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private renderer: Renderer,
    private userPermissionService: UserPermissionService) {
    this.createLocation = this.createPermission();
    this.toaster.setRootViewContainerRef(vcr);
    this.route.parent.params.subscribe(res => this.projectId = res.projectId);
    this.pageOptions = projectDetailService.getStatusDatesPageOptions(this.createLocation);
    this.locationDefs = projectDetailService.locationColDefs(this.editPermission());
    this.getLocationData(this.projectId);
   }

  /**Method to handle grid row edit event
  * @param row data
  */
   public cancelSaveLocationRecords(row): any {
    this.cancelSaveClicked = true;
    this.disableOrEnableGridRows(row.rowIndex, false);
    this.projectDetailService.locationGridRowIndex = '';
    this.hideValidationBorder();
    this.resetDataOnCancel(row);
    this.isAddDisable = false;
    row.gridApi.stopEditing(true);
  }

  public companyComponentLoad(): void {
    this.gridApi.hideOverlay();
  }

   /** Method to perform action on click of grid cell
    * @param cellData complete row data
    */
   public cellClicked(cellData: any): any {
       if (cellData.param && cellData.param.colDef.field) {
         // Condition to open modal popup
          if (cellData.param.colDef.field === 'name') {
            // This spinner will hide once company component load
            this.gridApi.showLoadingOverlay();
            this.addEditCompany.open(cellData.param.data, this.projectId, false);
          } else {
            // Condition to open grid edit mode
            this.isAddDisable = true;
            this.editedRowIndex = this.projectDetailService.locationGridRowIndex;
            if (cellData.param.colDef.cellRendererParams.enableRowEditing) {
              // && (this.editedRowIndex !== cellData.param.rowIndex)
              const rowIndex = cellData.param.node.rowIndex;
              this.disableOrEnableGridRows(rowIndex, true);
              cellData.param.api.setFocusedCell(rowIndex, 'startDate', null);
              cellData.param.api.startEditingCell({
                rowIndex: rowIndex,
                colKey: 'startDate'
              });
              this.editedRowIndex = rowIndex;
              this.projectDetailService.locationGridRowIndex = this.editedRowIndex;
            }
          }
       }
   }

  /** Method to handle validation on cell value changes */
  public cellValueChanged(params: any): void {
    const selectedRowIndex = params.selectedRowIndex;
    if (params.selectedColumn === 'startDate') {
      this.onStartDateValueChange(params, selectedRowIndex);
      this.cellValueChangeData.push({ newStartDate: params.newValue, oldStartDate: params.oldValue });
    }
    if (params.selectedColumn === 'toDate') {
      this.onEndDateValueChange(params, selectedRowIndex);
      this.cellValueChangeData.push({ newToDate: params.newValue, oldToDate: params.oldValue });
    }
  }

  /**Method to check date format and validation */
  public checkDateFormat(params): void {
    const regexp = new RegExp('/^((0|1)\d{1})\/((0|1|2)\d{1})\/((19|30)\d{2})$/');
    params.cellParams.colDef.tooltip = (param) => {
        if (!regexp.test(params.newRowData.startDate)) { // Need to handle with Reg Exp
          if ( params.cellParams.colDef.cellRendererParams) {
             params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
          }
          return 'Enter valid date format - MM/DD/YYYY';
        } else {
          if ( params.cellParams.colDef.cellRendererParams) {
           params.cellParams.colDef.cellRendererParams.showValidationBorder = false;
          }
          return params.newRowData.startDate;
        }
      };
  }

  /**Method on company save event*/
  public companySavedEvent(data): void {
    this.projectDetailService.saveLocationData(this.projectId, data.companyData).subscribe(
      (res) => {
         this.refreshData();
      },
      (err) => {
           console.log('Internal server error', 'Error!');
      });
  }

  /**Method to change date format */
  public convertDateToFormat(date): any {
    if (date.indexOf('/') > -1) {
      const dateVal = date.split('/');
      return [dateVal[2], dateVal[0], dateVal[1]].join('-');
    } else {
      return date;
    }
  }

  /**Method to disable row while grid editing is in progress*/
  public disableOrEnableGridRows(currRowIndex, disableFlag): void {
    const body = document.getElementsByClassName('ag-body-container');
    const list = body[0].children;
    const disableField = 'name';
    Array.from(list).forEach(element => {
      if (element.getAttribute('row-id') !== currRowIndex.toString()) {
        this.renderer.setElementClass(element, 'c2c-grid-row-read-only', disableFlag);
      }
      if (element.getAttribute('row-id') === currRowIndex.toString()) {
        this.renderer.setElementClass(element.children[2], 'c2c-grid-disable-cell-link', disableFlag);
      }
    });
   // this.gridApi.rowRenderer.cellNavigationService.gridOptionsWrapper.gridOptions.suppressCellSelection = true;
  }

  /**
   * Gets all of the location data to be displayed in the Grid.
   * @param id The project id tied to location data.
   */
  private getLocationData(id: number, isRefresh?: boolean): void {
    if (isRefresh && this.gridApi) {
      this.gridApi.showLoadingOverlay();
    }
    this.projectDetailService.getLocationData(id).subscribe(
      (data) => {
         this.locationData = data;
         if (this.gridApi) {
          this.gridApi.hideOverlay();
        }
      },
      (error) => { 
         this.toasterService.error('Error when getting Location data', error); 
         if (this.gridApi) {
          this.gridApi.hideOverlay();
        }
      }
    );
  }

  /**
  * Method to load data once grid is ready
  */
  public gridready(params: Params): void {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
  }

  /**Method to handle validation border */
  public hideValidationBorder(): void {
    this.gridApi.columnController.gridColumns.forEach(element => {
      if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
        element.colDef.cellRendererParams.showValidationBorder = false;
      }
    });
  }

  public ngOnDestroy(): void {
    this.saveRowSubscription.unsubscribe();
    this.cancelSaveRowSubscription.unsubscribe();
  }

  public ngOnInit() {
    this.editType = 'fullRow';
    this.stopEditingWhenGridLosesFocus = false;
    this.saveRowSubscription = this.locationEventService.getLocationSavedEvent()
    .subscribe(value => {
      this.saveLocationRecords(value);
    });
    this.cancelSaveRowSubscription = this.locationEventService.getLocationCancelledEvent()
    .subscribe(value => {
      this.cancelSaveLocationRecords(value);
    });
  }

  /** Method to open modal popup on click of Add button */
  public onClickAdd(): void {
    if (!this.isAddDisable) {
      this.addEditCompany.open();
    }
  }

  /**Method to handle end date value change */
  public onEndDateValueChange(params: any, selectedRowIndex: number): any {
    if (params.newRowData.toDate !== '' && !this.performDateValidation(params.newRowData)) {
          this.cellEditingError.push({
            column: 'toDate',
            rowIndex: selectedRowIndex
          });
          if (!params.cellParams.colDef.cellRendererParams) {
            params.cellParams.colDef.cellRendererParams = {};
          }
          params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
    } else {
          if (!params.cellParams.colDef.cellRendererParams) {
            params.cellParams.colDef.cellRendererParams = {};
          }
          params.cellParams.colDef.cellRendererParams.showValidationBorder = false;
    }
  }

  /** Method to perform action once row edditing is stop
   * @param params row data
   */
  public onRowEditingStopped(params: any): void {
    if (this.cellEditingError.length > 0) {
      params.api.redrawRows();
      this.disableOrEnableGridRows(this.cellEditingError[0].rowIndex, true);
      params.api.setFocusedCell(this.cellEditingError[0].rowIndex, this.cellEditingError[0].column);
      params.api.startEditingCell({
        rowIndex: this.cellEditingError[0].rowIndex,
        colKey: this.cellEditingError[0].column
      });
    } else if (!this.cancelSaveClicked) {
      this.saveLocationApiCall(params);
      params.api.redrawRows();
      this.cellValueChangeData = [];
    }
    this.cellEditingError = [];
  }

   /** Method to handle validation for start date value change. */
   public onStartDateValueChange(params: any, selectedRowIndex: number): void {
     this.setDefaultValue(params, this.currentRowData);
     if (params.newRowData.startDate !== '' && !this.performDateValidation(params.newRowData)) {
          this.cellEditingError.push({
            column: 'startDate',
            rowIndex: selectedRowIndex
          });
          params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else {
         params.cellParams.colDef.cellRendererParams.showValidationBorder = false;
    }
  }

  /**
  * Method to handle date validation
  * @param newRowData
  */
  public performDateValidation(newRowData): boolean {
      const startDate = this.convertDateToFormat(newRowData.startDate);
      const toDate = this.convertDateToFormat(newRowData.toDate);
      if ((startDate !== '' && toDate !== '')) {
        if (Date.parse(startDate) <= Date.parse(toDate)) {
            return true;
        } else {
            return false;
        }
      } else { return true; }
  }

  /**
  * Refreshes the Grid to get the latest location data.
  */
  public refreshData(isRefresh?: boolean): void {
    this.getLocationData(this.projectId, isRefresh);
    this.isAddDisable = false;
  }

  /**
   * Method to reset Data on cancel click.
   */
  public resetDataOnCancel(row): any {
    if (this.cellValueChangeData.length) {
      const startDateData = this.cellValueChangeData[0];
      const toDateData = this.cellValueChangeData[1];
   if ((startDateData.newStartDate === null || startDateData.newStartDate === '') &&
      startDateData.oldStartDate === '') {
        row.data.startDate = 'Select';
     } else if ((startDateData.newStartDate !== startDateData.oldStartDate)
          && (startDateData.oldStartDate !== null && startDateData.newStartDate === '')) {
        row.data.startDate = startDateData.oldStartDate;
      }
      if ((toDateData.newToDate === null || toDateData.newToDate === '') &&
         toDateData.oldToDate === '') {
         row.data.toDate = '';
      } else if ((toDateData.newToDate !== toDateData.oldToDate)
            && toDateData.oldToDate !== null) {
         row.data.toDate = toDateData.oldToDate;
      }
      this.cellValueChangeData = [];
    }
  }

   /** Method to call Location grid save API call
   * After edit mode
   */
  public saveLocationApiCall(row): any {
    row.api.showLoadingOverlay();
    this.projectDetailService.locationGridRowIndex = '';
    this.projectDetailService.saveLocationGridData(row.data, this.projectId).subscribe(
      (data) => {
        row.api.hideOverlay();
        const model = row.api.getFilterModel();
        const sortModel = row.api.getSortModel();
        row.api.setFilterModel(model);
        row.api.setSortModel(sortModel);
      },
      (error) => { this.toasterService.error('Error when saving Location date', error); }
    );
  }

  /**
  *  Method to save Location grid edit data
  */
  public saveLocationRecords(row): any {
    this.cancelSaveClicked = false;
    this.disableOrEnableGridRows(row.rowIndex, false);
    this.hideValidationBorder();
    this.currentRowData = row;
    this.isAddDisable = false;
    this.cellValueChangeData = [];
    row.gridApi.stopEditing();
  }

    /**Method to set Default value for start date */
    public setDefaultValue(param: any, row: any): void {
      if (param.newValue === '') {
        row.data.startDate = 'Select';
      }
      this.currentRowData = [];
    }

    public createPermission(): boolean {
      if (this.userPermissionService.hasPermission(this.locViewPermission) === true &&
      this.userPermissionService.hasPermission(this.locCreatePermission) === false) {
        return false;
      } else if (this.userPermissionService.hasPermission(this.locViewPermission) === true &&
      this.userPermissionService.hasPermission(this.locCreatePermission) === true) {
        return true;
      }
    }

    public editPermission(): boolean {
      if (this.userPermissionService.hasPermission(this.locViewPermission) === true &&
        this.userPermissionService.hasPermission(this.locEditPermission) === false) {
            return true;
      } else if (this.userPermissionService.hasPermission(this.locViewPermission) === true &&
                this.userPermissionService.hasPermission(this.locEditPermission) === true) {
            return false;
      }
  }


}



