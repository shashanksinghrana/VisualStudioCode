import { Component, OnInit, ViewContainerRef, ViewChild, ViewChildren} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DropdownModel, AddButtonModel, ToasterService, ModalApplicableNotApplicableComponent, UnsavedChangesService } from 'c2c-common-lib';
import { SharedService } from '../../services/http/shared/shared.service';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { ToastsManager } from '../../../../node_modules/ng2-toastr';
import { DealService } from '../../services/http/deal/deal.service';
import { DealModel } from '../../models/deal/deal.model';
import { CreditModel } from '../../models/deal/credit.model';
import { DealEventService } from '../../services/events/deal-event.service';
import { LoanoutModel } from '../../models/deal/loanout.model';
import { performerNameFormatter } from '../../utils/formatter/performer-name.format';
import { Observable } from 'rxjs/Observable';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { UtilsService } from '../../utils/utils.service';

/**
 * The CreditComponent.
 *
 * This component is used to add credits for a new or existing performer.
 */
@Component({
  selector: 'fc-credit',
  templateUrl: './credit.component.html',
  styleUrls: ['./credit.component.scss']
})
export class CreditComponent implements OnInit {
  public addBillingTextForm: FormGroup;
  public addButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add');
  public addCreditsForm: FormGroup;
  public billingTextOptions: DropdownModel = new DropdownModel('', '', '', '', []);
  public cardOptions: DropdownModel = new DropdownModel('', '', '', '', []);
  public creditForm: FormGroup;
  public deal: DealModel;
  public defaultBillingNotesValue: string;
  public isEdit: boolean = false;
  public loanout: LoanoutModel;
  public mainEndTitleOptions: DropdownModel = new DropdownModel('', '', '', '', []);
  public performerName: string = '';
  public positionOptions: DropdownModel = new DropdownModel('', '', '', '', []);
  public showBillingNotesSection: boolean = false;
  public showCreditPage: boolean = false;
  public showCreditRecordError: boolean = false;
  public showModal: boolean = false;
  public allCreditDetailsDeleted: boolean = false;
  public allCreditBillingsDeleted: boolean = false;
  public editedCreditsArray: any = [];
  public editedBillingArray: any = [];
  public type: string;
  public status: string;
  public skipUnsavedModalEvent: boolean = false;
  public mergedCreditBillingArray: any = [];
  public viewPermission: PermissionList = PermissionList.dealCreateEditView
  public editPermission: PermissionList = PermissionList.dealCreateEditEdit
  public disableForm: boolean = false;
  public isEdited: boolean = false;
  public ETCountAtSave: number = 0;
  public MTCountAtSave: number = 0;
  public ETCountAtGet: number = 0;
  public MTCountAtGet: number = 0;
  public contractRiders: DropdownModel = new DropdownModel(null, null, null, null, []);
  public compensations: any = [];
  public contracts: any[] = [];

  @ViewChild('applicableNotApplicableModal') public applicableNotApplicableModal: ModalApplicableNotApplicableComponent;
  @ViewChild('mainEndTitle') public mainEndTitle: any;
  // @ViewChild('billingRTENote') public billingRTENote: any;
  @ViewChild('billingNoteDropdown') public billingNoteDropdown: any;
  @ViewChildren('editedMainTitle') public editedMainTitle: any;

  /**
   * Constructor for the CreateEditProjectComponent
   *
   * @param route The active route.
   * @param sharedService The Shared Service for common services.
   * @param dealService The Create Deal Service for deal related services.
   * @param fb FormBuilder instance for building form elements.
   * @param dealEventService The Deal Event Sevice for routing after Save/Save & Continue
   * @param toasterService The common Toaster Service for calling toast messages.
   * @param toaster ToastManager instance for handling the currenct view container.
   * @param vcr A reference of the current view container.
   */
  constructor(
    private route: ActivatedRoute,
    private sharedService: SharedService,
    private dealService: DealService,
    private fb: FormBuilder,
    private dealEventService: DealEventService,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private unsavedChangesService: UnsavedChangesService,
    private userPermissionService: UserPermissionService,
    private utilService: UtilsService
  ) {
    this.disableForm = this.createEditPermission();
    this.toaster.setRootViewContainerRef(vcr);
    this.mainEndTitleOptions = this.getDropdownOptions('MAIN_END_TITLE');
    this.cardOptions = this.getDropdownOptions('CARD');
    this.positionOptions = this.getDropdownOptions('POSITION');
    this.billingTextOptions = this.getDropdownOptions('BILLING_TEXT');
    this.contractRiders = this.getDropdownOptions('RIDER');
  }

  /**
   * Sets up local variables for current and new credit.
   */
  public ngOnInit(): void {
    this.deal = this.dealService.deal;
    this.loanout = this.dealService.loanout;
    if (this.deal.id) {
      this.performerName = performerNameFormatter(this.deal.performer.firstName, this.deal.performer.lastName);// this.deal.performer.typeAheadDisplayName;
      this.showCreditPage = true;
      this.getContractTerms(this.deal.id);
    }

    this.creditForm = this.fb.group({
      'creditSet': this.fb.array([]),
      'billingSet': this.fb.array([])
    });

    this.initializeAddCreditsForm();
    this.initializeAddBillingTextForm();

    if (this.deal.id) {
      this.getCreditData();
    }
  }

  ngAfterViewInit() {
    if(!this.disableForm)
    {
      this.mainEndTitle.dropdownButton.nativeElement.focus();
    }
  }

  public initializeAddCreditsForm(): void {
    this.addCreditsForm = this.fb.group({
      'creditedName': this.fb.control({ value: this.performerName, disabled: true }),
      'mainEndTitle': this.fb.control(null),
      'card': this.fb.control(null),
      'position': this.fb.control(null),
      'creditNote': this.fb.control(null)
    });
  }

  public initializeAddBillingTextForm(): void {
    this.addBillingTextForm = this.fb.group({
      'billingText': this.fb.control(null),
      'billingNotes': this.fb.control(null)
    });
  }

  /**
   * Get all the data related to credit and assigns it to component properties.
   */
  public getCreditData(): void {
    this.route.data.subscribe(
      (data: { credit: CreditModel }) => {
        const creditedName = this.performerName;
        this.creditForm.setValue({
          'creditSet': this.getCreditSet(creditedName, data.credit.creditDetail),
          'billingSet': this.getBillingSet(data.credit.creditBilling)
        });
      },
      (error) => {
        console.log('Error when getting credit details', error);
      }
    );
  }

  /**
  * Populates the Credit Array in the form.
  *
  * @param creditedName credited name from data to iterate over.
  *
  * @param data The existing data to iterate over.
  */
  public getCreditSet(creditedName, data): FormArray {
    const creditArray = <FormArray>this.creditForm.controls.creditSet;
    data.forEach((item) => {
      if(item.creditTitle){
        if(item.creditTitle.name === 'End Title'){
          this.ETCountAtGet++;
        }
        if(item.creditTitle.name === 'Main Title'){
          this.MTCountAtGet ++;
        }
      }
      creditArray.push(this.fb.group({
        'creditedName': this.fb.control({ value: creditedName, disabled: true }),
        'mainEndTitle': this.fb.control({ value: (item.creditTitle ? item.creditTitle.id : null), disabled: true }),
        'card': this.fb.control({ value: (item.card ? item.card.id : null), disabled: true }),
        'position': this.fb.control({ value: (item.position ? item.position.id : null), disabled: true }),
        'creditNote': this.fb.control({ value: item.note, disabled: true }),
        'creditValid': this.fb.control({ value: true, disabled: true })
      }));
    });
    return creditArray;
  }

  /**
   * Populates the Billing Array in the form.
   *
   * @param data The existing data to iterate over.
   */
  public getBillingSet(data): FormArray {
    const billingArray = <FormArray>this.creditForm.controls.billingSet;
    data.forEach((item) => {
      const bllngNote = this.getTextFromBillingNotes(item.billingText)
      billingArray.push(this.fb.group({
        'billingText': this.fb.control({ value: item.billingText, disabled: true }),
        'billingNotes': this.fb.control({ value: bllngNote, disabled: true }),
        'billingNotesForSave': this.fb.control({ value: item.billingText, disabled: true })
      }));
    });
    return billingArray;
  }

  /**
   * Method to get dropdown value 
   *
   * @param lookup type of dropdown
   */
  public getDropdownOptions(lookupType: string): DropdownModel {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.sharedService.getDropdown(lookupType).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
      }
    );
    return dropdownModel;
  }

  /**
   * Adds another line of values to the credit set based on the dropdowns
   * selected for Main/End Title, Card, Position and Credit Notes. Line is added by getting
   * and setting these values to the Project model.
   */
  public addLine(): void {
    if (this.addCreditsForm.valid && (this.addCreditsForm.value['mainEndTitle'] || this.addCreditsForm.value['card'] || this.addCreditsForm.value['position'])) {
      const creditArray = <FormArray>this.creditForm.controls.creditSet;
      if (this.validateCreditRecord(creditArray)) {
        this.showCreditRecordError = false;
        creditArray.push(this.fb.group({
          'creditedName': this.fb.control({ value: this.performerName, disabled: true }),
          'mainEndTitle': this.fb.control({ value: this.addCreditsForm.value['mainEndTitle'], disabled: true }),
          'card': this.fb.control({ value: this.addCreditsForm.value['card'], disabled: true }),
          'position': this.fb.control({ value: this.addCreditsForm.value['position'], disabled: true }),
          'creditNote': this.fb.control({ value: this.addCreditsForm.value['creditNote'], disabled: true }),
          'creditValid': this.fb.control({ value: true, disabled: true })
        }));
        this.addCreditsForm.reset({ 'creditedName': this.performerName });

      } else {
        this.showCreditRecordError = true;
        // this.addCreditsForm.controls["creditedName"].setErrors({ 'invalid': true });
        // this.addCreditsForm.controls["creditedName"].markAsTouched();
      }
    } else {
      this.addCreditsForm.markAsUntouched();
      this.addCreditsForm.markAsPristine();
      this.validateFormFields(this.addCreditsForm);
    }
  }

  /**
   * Validates credit record to prevent Duplicate entry
   * parameter combination of Main/End Title, Card and Position is compared
   */
  public validateCreditRecord(creditArray): boolean {
    let flag = true;
    const newObj = {
      'creditedName': this.performerName,
      'mainEndTitle': this.addCreditsForm.value['mainEndTitle'],
      'card': this.addCreditsForm.value['card'],
      'position': this.addCreditsForm.value['position'],
      'creditValid': true
    };

    creditArray.value.forEach((item, index) => {
      //delete item["creditNote"];
      let { creditNote, ...a } = item;
      if (JSON.stringify(newObj).toLowerCase() === JSON.stringify(a).toLowerCase()) {
        flag = false;
        return flag;
      }
    });
    return flag;
  }

  /**
   * Determines if the form has any unsaved changes, if so, transition message
   * will be displayed. If user confirms, routing continues to navigate.
   */
  public canDeactivate(): Observable<boolean> | boolean {
    if(!this.disableForm)
    {
      if ((this.addCreditsForm.dirty && this.addCreditsForm.touched && !this.skipUnsavedModalEvent) || (this.addBillingTextForm.dirty && this.addBillingTextForm.touched && !this.skipUnsavedModalEvent)) {
        this.unsavedChangesService.openModal();
        return this.unsavedChangesService.onCloseModal();
      }
      return true;
    }
return true;
  }

  /**
   * Populates the dropdown value when populating the form.
   *
   * @param type The DropdownModel to iterate over.
   * @param value The value to set on the dropdown.
   * @param field The field name to compare against.
   */
  public getDropdownSelection(type, value, field) {
    let selection = value;
    if (type.options) {
      type.options.forEach((val) => {
        if (value === val[field]) {
          selection = val;
        }
      });
    }
    return selection;
  }

  /**
   * Removes the given line from the credit set when the minus (-) icon is clicked.
   *
   * @param index The position in the array of the row to be removed.
   */
  public removeLineItem(index): void {
    const creditArray = <FormArray>this.creditForm.controls.creditSet;
    creditArray.removeAt(index);
    if (this.creditForm.dirty && this.creditForm.touched) {
      this.addCreditsForm.markAsDirty();
      this.addCreditsForm.markAsTouched();
    }
    if (!creditArray.controls.length) {
      this.allCreditDetailsDeleted = true;
      this.isEdited = true;
      this.validateFormFields(this.addCreditsForm);
    }
    this.billingNoteDropdown.dropdownButton.nativeElement.focus();
  }

  /**
   * This function is used to begin the process of editing a credit set.
   *
   * @param formGroup The FormGroup to edit.
   */
  public enableCreditSetEdit(formGroup, index): void {
    this.addCreditsForm.markAsDirty();
    this.addCreditsForm.markAsTouched();
    formGroup.currentState = { ...formGroup };
    formGroup.enable();
    this.editedCreditsArray[index] = {
      'index': index,
      'value': formGroup.getRawValue()
    };
    let array = this.editedMainTitle.toArray(); 
    let mainTitleDropdown: HTMLInputElement ;
    for (let i = 0; i < array.length; i++) {
      const element = array[i];
      if (i === index) {
        mainTitleDropdown = element.dropdownButton.nativeElement;
      }
    }
    console.log(mainTitleDropdown);
    setTimeout(() => mainTitleDropdown.focus());
  }

  /**
   * This function is run for disabling the ability to edit a credit set.
   *
   * @param formGroup The FormGroup to disable.
   */
  public disableCreditSetEdit(formGroup, index): void {
    this.showCreditRecordError = false;
    formGroup.reset(formGroup.currentState.value);
    Object.keys(formGroup.controls).forEach((field) => {
      formGroup.controls[field].disable();
    });
    this.editedCreditsArray.splice(index, 1);
  }

  /**
   * This function saves the credit set.
   *
   * @param formGroup The FormGroup to save.
   */
  public saveEditedCreditSet(formGroup, i): void {
    const creditArray = <FormArray>this.creditForm.controls.creditSet;
    this.addCreditsForm.markAsDirty();
    this.addCreditsForm.markAsTouched();
    this.editedCreditsArray.splice(i, 1);
    if (formGroup.valid) {
      if (this.validateCreditRecordForEditedSet(creditArray, formGroup, i)) {
          formGroup.get('creditValid').patchValue(true);
        Object.keys(formGroup.controls).forEach((field) => {
          formGroup.controls[field].disable();
        });
      } else {
          formGroup.get('creditValid').patchValue(false);
      }
    } else {
      this.validateFormFields(formGroup);
    }
  }

  /**
   * Validates Credit record to prevent Duplicate entry
   * @param creditArray form list.
   * @param formGroup The FormGroup to save.
   * @param i Index
   */
  public validateCreditRecordForEditedSet(creditArray, formGroup, i): boolean {
    let flag = true;
    const newObj = {
      'creditedName': this.performerName,
      'mainEndTitle': formGroup.value['mainEndTitle'],
      'card': formGroup.value['card'],
      'position': formGroup.value['position'],
      'creditValid': true
    };

    creditArray.controls.forEach((item, index) => {
      if (i !== index) {
        let { creditNote, ...a } = item.value;
        if (JSON.stringify(newObj).toLowerCase() === JSON.stringify(a).toLowerCase()) {
          // Allow user to add multiple similar entry//removing comment
          flag = false;
          return flag;
        }
      }
    });
    return flag;
  }

  /**
   * Checks to see if the FormGroup is invalid.
   *
   * @param formGroup The FormGroup to run validation on.
   * @param field The FormControl to check in the given FormGroup.
   */
  public isFormInvalid(formGroup, field): boolean {
    return formGroup.get(field).invalid && formGroup.get(field).touched;
  }


  /**
   * Called when the form is invalid in order to mark the invalid controls.
   *
   * @param formGroup The FormGroup to mark.
   */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  /**
   * Resets (clears) the given FormGroup.
   *
   * @param formGroup The FormGroup to reset.
   */
  public clearForm(formGroup): void {
    this.defaultBillingNotesValue = '';
    this.showCreditRecordError = false;
    this.isEdit = false;
    this.editedBillingArray.splice(0, 1);
    formGroup.reset({ 'creditedName': this.performerName, 'billingNotes': '', 'billingNotesForSave': '' });
    formGroup.markAsUntouched();
  }

  public getCreditRecordField(fieldValue) {
    let value: any;
    if (fieldValue) {
      value = {
        'id': fieldValue.id,
        'name': fieldValue.value,
        'type': fieldValue.data.type,
        'displayOrder': fieldValue.data.displayOrder
      };
    } else {
      value = null;
    }
    return value;
  }

  /**
 * Submits the credits form for saving the credit details.
 */
  public onSubmit(type?: string): void {
    this.skipUnsavedModalEvent = true;
    const creditArray = <FormArray>this.creditForm.controls.creditSet;
    const billingArray = <FormArray>this.creditForm.controls.billingSet;
    let creditRawArray = creditArray.getRawValue();
    let billingRawArray = billingArray.getRawValue();
    this.mergedCreditBillingArray = creditRawArray.concat(billingRawArray);
    this.prepareMainEndTitleForSaveObj(creditRawArray);    
    if (this.dealService.currentWizardPage.status) {
      if (this.dealService.currentWizardPage.status.name !== 'NOT_APPLICABLE' && this.mergedCreditBillingArray.length === 0) {
        this.type = type;
        this.openApplicableNotApplicableModal();
      }
    }
    if (this.mergedCreditBillingArray.length === 0 && !this.dealService.currentWizardPage.status) {
      this.type = type;
      this.openApplicableNotApplicableModal();
    } else if (this.mergedCreditBillingArray.length || this.dealService.currentWizardPage.status.name == 'NOT_APPLICABLE' || this.isEdited) {
      const dealId: string = this.dealService.getDealId();
      this.dealService.saveWizardSubtitles(this.creditForm.value);
      let reqObj = {
        'dealId': dealId,
        'creditDetail': [],
        'creditBilling': []
      };
      if (creditArray.length) {
        creditArray.controls.forEach((element, index) => {
          const item = <FormGroup>element;
          if (this.editedCreditsArray && this.editedCreditsArray[index]) {
            reqObj.creditDetail.push({
              'creditTitle': this.getCreditRecordField(this.editedCreditsArray[index].value.mainEndTitle),
              'card': this.getCreditRecordField(this.editedCreditsArray[index].value.card),
              'position': this.getCreditRecordField(this.editedCreditsArray[index].value.position),
              'note': this.editedCreditsArray[index].value.creditNote
            });
          } else {
            reqObj.creditDetail.push({
              'creditTitle': this.getCreditRecordField(item.controls['mainEndTitle'].value),
              'card': this.getCreditRecordField(item.controls['card'].value),
              'position': this.getCreditRecordField(item.controls['position'].value),
              'note': item.controls['creditNote'].value
            });
          }
        });
      }

      if (billingArray.length) {
        billingArray.controls.forEach((element, index) => {
          const item = <FormGroup>element;
          const billingText = item.controls['billingText'].value;
          if (billingText) {
            reqObj.creditBilling.push({
              'billingText': item.controls['billingNotesForSave'].value              
            });
          }
        });
        if (this.editedBillingArray.length > 0) {
          this.editedBillingArray.forEach((element, index) => {
            const val = this.editedBillingArray[index];
            reqObj.creditBilling.push({
              'billingText': val.value.billingNotesForSave
            });
          });
        }
      }
      if (!this.creditForm.invalid && !this.showCreditRecordError) {
        this.addCreditsForm.markAsPristine();
        this.addCreditsForm.markAsUntouched();
        this.addBillingTextForm.markAsPristine();
        this.addBillingTextForm.markAsUntouched();
        if (this.isEdited && this.mergedCreditBillingArray.length === 0) {
          this.dealService.saveCredit(reqObj).subscribe(
            res => {
              this.creditForm.markAsPristine();
              this.creditForm.markAsUntouched();
            })
        } else if ((this.isEdited && this.mergedCreditBillingArray.length) || creditArray.length || billingArray.length || this.dealService.currentWizardPage.status.name === 'NOT_APPLICABLE') {
          this.saveCredits(type, reqObj);
        }
        this.dealService.saveCompensation(this.compensations,this.contracts).subscribe(res => {
        }, err => {
          console.log(err);
          this.toasterService.error('Failed to save Compensation details.', 'Error');
        });
      }
    } else {
      this.validateFormFields(this.creditForm);
    }
  }

  /**
  * API call for save
  */
  public saveCredits(type, reqObj) {
    this.dealService.saveCredit(reqObj).subscribe(
      res => {
        this.creditForm.markAsPristine();
        this.creditForm.markAsUntouched();
        this.dealEventService.pageSavedEvent({ type: type, pageTo: 'perqs', dealId: res['dealId'], status: (!this.mergedCreditBillingArray.length) ? this.dealService.currentWizardPage.status.name : 'COMPLETE' });
      }, err => {
        this.toasterService.error('Failed to save Credit Details.', 'Error');
      }
    );
  }

  /**
  * set default billing text value
  */
  public onChangeBillingText(id): void {
    if (!this.isEdit) {
      this.defaultBillingNotesValue = this.addBillingTextForm.value['billingText'].value;
    }
  }

  /**
  * Adds another line of values to the billing set based on the dropdowns
  * selected for Billing Text and Billing Notes. Line is added by getting
  * and setting these values to the Project model.
  */
  public addLineForBillingText(): void {
    if (this.addBillingTextForm.valid && (this.addBillingTextForm.value['billingText'] || this.addBillingTextForm.value['billingNotes'])) {
      const billingArray = <FormArray>this.creditForm.controls.billingSet;
      this.editedBillingArray.splice(0, 1);
      // this.defaultBillingNotesValue = this.addBillingTextForm.value['billingText'].value;
      const bllngNote = this.getTextFromBillingNotes(this.addBillingTextForm.value.billingNotes);
      billingArray.push(this.fb.group({
        'billingText': this.fb.control({ value: this.addBillingTextForm.value['billingText'], disabled: true }),
        'billingNotes': this.fb.control({ value: bllngNote, disabled: true }),
        'billingNotesForSave': this.fb.control({ value: this.addBillingTextForm.value.billingNotes, disabled: true })
      }));
      this.isEdit = false;
      this.addBillingTextForm.reset({ 'billingNotes': '', 'billingNotesForSave': '' });
      // this.addBillingTextForm.markAsUntouched();
      // this.addBillingTextForm.markAsPristine();
      this.defaultBillingNotesValue = '';
    } else {
      this.addBillingTextForm.markAsUntouched();
      this.addBillingTextForm.markAsPristine();
      this.validateFormFields(this.addBillingTextForm);
    }
  }

  /**
    * get text from RTE edited format for display
    * @param note RTE text
    */
  public getTextFromBillingNotes(note): string {
    const doc = (new DOMParser()).parseFromString(note, 'text/html');
    return doc.body.innerText.trim();
  }

  /**
   * Removes the given line from the credit set when the minus (-) icon is clicked.
   *
   * @param index The position in the array of the row to be removed.
   */
  public removeLineItemForBillingNotes(index): void {
    const billingArray = <FormArray>this.creditForm.controls.billingSet;
    billingArray.removeAt(index);
    if (this.creditForm.dirty && this.creditForm.touched) {
      this.addBillingTextForm.markAsDirty();
      this.addBillingTextForm.markAsTouched();
    }
    if (!billingArray.controls.length) {
      this.allCreditBillingsDeleted = true;
      this.isEdited = true;
      this.validateFormFields(this.addBillingTextForm);
    }
    setTimeout(() => document.getElementById('continueBtn').focus());
  }

  /**
  * This function is used to begin the process of editing a billing set.
  *
  * @param formGroup The FormGroup to edit.
  */
  public enableBillingSetEdit(formGroup, index): void {
    this.isEdit = true;
    this.addBillingTextForm.reset({
      'billingText': formGroup.value.billingText,
      'billingNotes': formGroup.value.billingNotesForSave,
    });
    this.editedBillingArray.push({
      "index": index,
      "value": formGroup.value
    });
    this.billingNoteDropdown.dropdownButton.nativeElement.focus();
    // this.billingRTENote.editorDiv.nativeElement.focus();
    this.removeLineItemForBillingNotes(index);
  }

  /* Method to open modal popup */
  public openApplicableNotApplicableModal(): void {
    this.applicableNotApplicableModal.openModal();
  }

  public applicableModalClosedEvent(event): void {
    if (event == 'OK') {
      const dealId: string = this.dealService.getDealId();
      if (this.type == 'continue') {
        this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'perqs', dealId: parseInt(dealId), status: this.status });
      } else {
        this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'summary', dealId: parseInt(dealId), status: this.status });
      }
    }
  }

  public applicableConfVal(event) {
    if (event) {
      if (event === "Skip and complete later?") {
        this.status = 'INCOMPLETE';
      } else {
        this.status = 'NOT_APPLICABLE';
      }
    }
  }

  public createEditPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === false) {
      return true;
    }
    else if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === true) {
      return false;
    }
  }

  private getContractTerms(dealId:number): void {
    this.dealService.getContractTerms(dealId).subscribe(
      (data) => {
        if (data) {
          if(data.compensations){
            this.compensations =data.compensations;
          }
          if(data.contracts){
            this.contracts = data.contracts;
          }
        }
      },
      (err) => {
        console.error('Error getting compensation details', err);
        this.toasterService.error('There was a problem getting compensation details', 'ERROR');
      }
    );
  }

  private addContractObj(mainEndFlag):any{
    let contractsObj:any;
    if(mainEndFlag === 'End Title'){
      contractsObj = {
            id: null,
            compensationId: null,
            dealId: this.dealService.getDealId(),
            contractLookupId:this.utilService.getIdByProperty(this.contractRiders.options,'value','Exhibit A - End Title')
          };
      }else if(mainEndFlag === 'Main Title'){
        contractsObj = {
            id: null,
            compensationId: null,
            dealId: this.dealService.getDealId(),
            contractLookupId:this.utilService.getIdByProperty(this.contractRiders.options,'value','Exhibit A - Main Title')
        };
      }
    return contractsObj;
  }

  private prepareMainEndTitleForSaveObj(creditRawArray: any[]) {
    creditRawArray.forEach(
      (item) => {
        if(item.mainEndTitle){
          if(item.mainEndTitle.value === 'End Title'){
            this.ETCountAtSave++;
          }
          if(item.mainEndTitle.value === 'Main Title'){
            this.MTCountAtSave ++;
          }
        }
    });
    if(this.ETCountAtSave > this.ETCountAtGet){
      if(this.ETCountAtSave > 0 && !this.checkForExistingContracts(this.contracts,'Exhibit A - End Title')){      
          this.contracts.push(this.addContractObj('End Title'));     
      }
    }else if(this.ETCountAtSave < this.ETCountAtGet){
      if(this.ETCountAtSave == 0 && this.checkForExistingContracts(this.contracts,'Exhibit A - End Title')){       
        this.deleteContractWithValue(this.contracts,'Exhibit A - End Title');
      }
    }     
    if(this.MTCountAtSave > this.MTCountAtGet){
      if(this.MTCountAtSave > 0 && !this.checkForExistingContracts(this.contracts,'Exhibit A - Main Title')){        
          this.contracts.push(this.addContractObj('Main Title'));       
      }     
    } else if(this.MTCountAtSave < this.MTCountAtGet){
      if(this.MTCountAtSave == 0 && this.checkForExistingContracts(this.contracts,'Exhibit A - Main Title')){      
        this.deleteContractWithValue(this.contracts,'Exhibit A - Main Title');
      }
    }
    
  } 

  private checkForExistingContracts(contracts: any[], value:string){
    let flag:Boolean = false;
    if(contracts){
      contracts.forEach(item => {
        if(item['contractName'] === value){
          flag = true;
        }
      });
    }
    return flag;
  }

  private deleteContractWithValue(contracts: any[], value:string){
    if(contracts){      
        for(let contract of this.contracts){
          if(contract['contractName'] === value){
            contracts.splice(contracts.indexOf(contract), 1);
            break;
          }
      } 
    }  
  }
}
