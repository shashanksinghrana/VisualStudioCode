import { Component } from '@angular/core';
import {
  AddButtonModel, ColumnDefModel, GridPageOptionsModel,
  UrlResolverService, NavBarEventService, NavBarHistoryModel
} from 'c2c-common-lib';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { ActivatedRoute } from '@angular/router';
import { HttpParams } from '../../../../node_modules/@angular/common/http';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { PermissionList } from '../../enums/permission-list.enum';
import { DealService } from '../../services/http/deal/deal.service';

/**
 * The Performers Component
 *
 * Component for displaying Grid of each performer deal on a particular project.
 */
@Component({
  selector: 'fc-performers',
  templateUrl: './performers.component.html',
  styleUrls: ['./performers.component.scss']
})
export class PerformersComponent {
  public addButtonOptions: AddButtonModel = new AddButtonModel('fc', 'projectDetails', 'navigate',
    '/createDeal/new/namesProjectDetails', '', 'Add');
  public pageOptions: {};
  public pagination: any;
  public performersData: any[];
  public performersDefs: ColumnDefModel[];
  public projectId: number;
  public viewAddButton: boolean = true;
  public performerView: PermissionList = PermissionList.performerView;
  public performerEdit: PermissionList = PermissionList.performerEdit;
  public dealId: any;
  public contractLookupId: any;

  /**
 * The Constructor for PerformersComponent
 *
 * @param route The active route.
 * @param projectDetailService The Project Details Service for getting data.
 */
  constructor(private route: ActivatedRoute,
    private urlResolverService: UrlResolverService,
    private navBarEventService: NavBarEventService,
    private projectDetailService: ProjectDetailService,
    private userPermissionService: UserPermissionService,
    private dealService: DealService
  ) {
    this.route.parent.params.subscribe((res) => {
      this.projectId = res.projectId;
      this.getPerformersData(this.projectId);
    });
    this.viewAddButton = this.createPermission();
    this.pageOptions = projectDetailService.getPageOptions(this.viewAddButton);
    this.performersDefs = projectDetailService.createPerformersColDefs();
  }

  /** Method to get click history items*/
  public getClickedEvent(evt: any): void {
    const url = this.urlResolverService.getServiceEndpointUrl(`#${evt.route}`);
    const title = evt.subtitle ? `${evt.title} (${evt.subtitle})` : evt.title;
    const historyItem: NavBarHistoryModel = new NavBarHistoryModel();

    historyItem.destinationUrl = url;
    historyItem.historyLabel = title;
    historyItem.iconClass = 'navbar-projector';
    historyItem.source = 'FC';

    this.navBarEventService.setNavBarHistory(historyItem);
  }

  /**
 * Gets all of the performers data to be displayed in the Grid.
 *
 * @param id The project id tied to performer deals to get.
 */
  private getPerformersData(id, params?): void {
    this.projectDetailService.getPerformers(id, params).subscribe(
      (data) => {
        data.performerDeals.forEach((element, index) => {
          if (element.performerNote) {
            element.performerNote = this.getTextFromPerformerNotes(element.performerNote);
          }
        });
        this.performersData = data.performerDeals;
        this.pagination = data.pagination;
      },
      (error) => { console.log('Error when getting performers', error); } // TODO: Throw toaster error. Better error handling.
    );
  }

  /**
   * gets string from html data in RTE editor
   *
   */
  public getTextFromPerformerNotes(note): string {
    const doc = (new DOMParser()).parseFromString(note, 'text/html');
    return doc.body.innerText.trim();
  }

  /**
 * Listens for the Grid's sort/filter/pagination event and performs server-side operations on the data.
 *
 * @param params The HttpParams to send to the back-end for the server-side operations.
 */
  public onDataChanged(params: HttpParams): void {
    this.getPerformersData(this.projectId, params);
  }

  /**
  * Refreshes the Grid to get the latest performers deal data.
  *
  * TODO: get cell refresh to work
  */
  public refreshData(): void {
    this.getPerformersData(this.projectId);
  }

  public createPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.performerView) === true && this.userPermissionService.hasPermission(this.performerEdit) === false) {
      return false;
    }
    else if (this.userPermissionService.hasPermission(this.performerView) === true && this.userPermissionService.hasPermission(this.performerEdit) === true) {
      return true;
    }
  }

  public downloadFile(params) {
    let compensationObj = [];
    params.value.data.contracts.forEach(element => {
      if (element.contractName === params.event) {
      this.dealId = element.dealId;
      this.contractLookupId =  element.contractLookupId;
      }
    });
    this.dealService.downloadfile(this.dealId, this.contractLookupId, compensationObj)
      .subscribe(
        (data) => {
          //for browser compatibility  
          var ieEDGE = navigator.userAgent.match(/Edge/g);
          var ie = navigator.userAgent.match(/.NET/g); // IE 11+
          var oldIE = navigator.userAgent.match(/MSIE/g);
          var name = "file";
          var blob = new window.Blob([data], { type: 'application/pdf' });

          if (ie || oldIE || ieEDGE) {
            var fileName = name + '.pdf';
            window.navigator.msSaveBlob(blob, fileName);
          }
          else {
            var file = new Blob([data], {
              type: 'application/pdf'
            });
            var fileURL = URL.createObjectURL(file);
            window.open(fileURL);
          }
        },
        error => {
          console.log("Error downloading the file." + error)
        },
        () => {
          console.log("complete");
        }
      );
  }
}
