import { Component, OnInit, ChangeDetectorRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import {
  CancelButtonModel, DropdownModel, CheckboxModel, AddButtonModel, ToasterService,
  ModalDeleteConfirmationComponent, ModalApplicableNotApplicableComponent, UnsavedChangesService
} from 'c2c-common-lib';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder } from '@angular/forms';
import { SharedService } from '../../services/http/shared/shared.service';
import { DealService } from '../../services/http/deal/deal.service';
import { ToastsManager } from 'ng2-toastr';
import { LoadingIndicatorService } from '../../services/other/loading-indicator.service';
import { DealEventService } from '../../services/events/deal-event.service';
import { DealModel } from '../../models/deal/deal.model';
import { Observable } from 'rxjs/Observable';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { forkJoin } from 'rxjs/observable/forkJoin';
import * as moment from 'moment';

/**
 * The CompensationComponent
 *
 * Component for displaying the Compensation section of the Deal Wizard.
 * Handles the fees and contracts associated with a performer.
 */
@Component({
  selector: 'fc-compensation',
  templateUrl: './compensation.component.html',
  styleUrls: ['./compensation.component.scss']
})
export class CompensationComponent implements OnInit {
  public isDescriptChecked: boolean = false;
  public addButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add');
  public cancelButtonOptions: CancelButtonModel;
  public checkForChanges: boolean = false;
  public checkForSavedChanges: boolean = false;
  public compensationForm: FormGroup;
  public contractRiders: DropdownModel = new DropdownModel(null, null, null, null, []);
  public cRForm: FormGroup;
  public currentFeeType: any;
  @ViewChild('saveAndContinue') public saveAndContinue: any;
  public deal: DealModel;
  @ViewChild('deleteModal') public deleteModal: ModalDeleteConfirmationComponent;
  public detailGroups: any[];
  public editedFeeTypeArray: any[] = [];
  public feeTypeAndContractMap: any[] = [];
  public feeTypeForm: FormGroup;
  public feeTypes: DropdownModel = new DropdownModel(null, null, null, null, []);
  public formula: any;
  public isContractRemoved: boolean = false;
  public isContractSelected: boolean = false;
  public isEdited: boolean = false;
  public isFormBlank: boolean = false;
  public isFormulaRemoved: boolean = false;
  public itemsArray: any[];
  public loading: boolean = false;
  public loanout: any;
  public riderIndex: number;
  public riders: any[] = [];
  public showDescript: boolean = false;
  public tempCompId: any;
  public type: string;
  public status: string;
  public skipUnsavedModalEvent: boolean = false;
  public rowData: boolean = false;
  public viewPermission: PermissionList = PermissionList.dealCreateEditView;
  public editPermission: PermissionList = PermissionList.dealCreateEditEdit;
  public disableForm: boolean = false;
  public removeRiderRow: boolean = false;

  @ViewChild('applicableNotApplicableModal') public applicableNotApplicableModal: ModalApplicableNotApplicableComponent;
  @ViewChild('feeTypeDropDown') public feeTypeDropDown: any;
  @ViewChild('criteriaGroup') public criteriaGroup: ElementRef;

  /**
   * Constructor for the CompensationComponent
   *
   * @param router The router to handle all navigation.
   * @param sharedService The Shared Service for common services.
   * @param dealService The Create Deal Service for deal related services.
   * @param compensationService The Compensation Service for compensation services.
   * @param changeDetector Runs change detection on the component.
   * @param fb FormBuilder instance for building form elements.
   * @param toasterService The common Toaster Service for calling toast messages.
   * @param toaster ToastManager instance for handling the currenct view container.
   * @param vcr A reference of the current view container.
   */
  constructor(
    private sharedService: SharedService,
    private unsavedChangesService: UnsavedChangesService,
    private dealService: DealService,
    private dealEventService: DealEventService,
    private changeDetector: ChangeDetectorRef,
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private loadingService: LoadingIndicatorService,
    private userPermissionService: UserPermissionService
  ) {
    this.disableForm = this.createEditPermission();
    this.toaster.setRootViewContainerRef(vcr);
    this.loadingService.onLoadingChanged.subscribe(
      (isLoading) => this.loading = isLoading
    );
    this.sharedService.getDropdown('FEE_TYPE').subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          this.feeTypes.options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
      }
    );
    this.sharedService.getDropdown('CONTRACT').subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          this.contractRiders.options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
      }
    );
    this.sharedService.getDropdown('RIDER').subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          this.contractRiders.options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
        this.contractRiders.options.sort(function(a,b){
          return a.value.localeCompare(b.value);
      })
      }
    );
    this.dealService.getContractRiders().subscribe(
      (res: any) => {
        if (res !== null) {
          this.feeTypeAndContractMap = res;
        }
      });
      
  }

  /**
   * If feeTypeForm is valid, adds a new fee to the list of fees (when clicking the 'add' icon).
   */
  public addItem(): void {
    if (this.feeTypeForm.valid) {
      if (!this.compensationForm.controls[this.currentFeeType]) {
        this.buildFeeGroups(this.currentFeeType, this.detailGroups.slice());
      }
      let i: number;
      this.itemsArray.forEach((feeArray, index) => {
        if (feeArray.id === this.currentFeeType) {
          i = index;
        }
      });
      this.itemsArray[i].formArray.push(this.buildItem(this.formula, this.feeTypeForm.value));
      this.addRiderFromCompensationAdd();
      this.isContractRemoved = false;
      this.clearItem();
      this.getFormula();
      this.compensationForm.get('feeType').setValue(null);
    } else {
      this.validateFormFields(this.feeTypeForm);
    }
  }

  /**
   * Creates a new FormGroup (and controls) for adding a new fee to the compensation details.
   *
   * @param formula The feeType formula that acts as a blueprint for creating the FormControls.
   * @param data The feeTypeForm data to pull the values out of.
   */
  public buildItem(formula: any, data: any): FormGroup {
    const fg: FormGroup = this.fb.group({});
    formula.details.forEach(detail => {
      const validator = (detail.requiredFlag === true) ? [Validators.required] : [];
      if (detail.validationExpression) {
        validator.push(Validators.pattern(new RegExp(detail.validationExpression)));
      }
      fg.addControl(detail.fieldName, new FormControl({ value: data[detail.fieldName], disabled: true }, validator));
    });

    let compId;
    if (data.id == null) {
      fg.addControl('isNew', new FormControl({ value: true, disabled: true }));
      this.tempCompId = this.generateUniqueId();
      compId = this.tempCompId;
    } else {
      compId = data.id;
    }
    fg.addControl('id', new FormControl({ value: compId, disabled: true }));

    this.getValueChanges(fg);
    return fg;
  }

  /*
  * Method to invoke unsaved modal
 */
  public canDeactivate(): Observable<boolean> | boolean {
    if (this.compensationForm.dirty && this.compensationForm.touched && !this.skipUnsavedModalEvent && this.feeTypeForm.dirty && this.feeTypeForm.touched || (this.checkForChanges && !this.checkForSavedChanges)) {
      this.unsavedChangesService.openModal();
      return this.unsavedChangesService.onCloseModal();
    }
    return true;
  }

  public getContractTerms(dealId): void {
    this.dealService.getContractTerms(dealId).subscribe(
      (data) => {
        if (data) {
          this.setCompensationDetails(data.compensations);
          this.setRiders(dealId, data.contracts, data.compensations);
        }
        this.focusOnload();
      },
      (err) => {
        console.error('Error getting compensation details', err);
        this.toasterService.error('There was a problem getting compensation details', 'ERROR');
      }
    );
  }

  private getMetchedCompensation(compId, compensations): any {
    let result = null;
    compensations.forEach((compObj) => {
      if (compObj.data) {
        compObj.data.forEach((dataObj) => {
          if (compId === dataObj.id) {
            result = dataObj;
          }
        });
      }
    });
    return result;
  }

  /**
   * Checks to see if the FormGroup is invalid.
   *
   * @param formGroup The FormGroup to check.
   * @param field The FormControl to check in the given FormGroup.
   */
  public isFormInvalid(formGroup, field): boolean {
    return formGroup.get(field).invalid && formGroup.get(field).touched;
  }

  public isNumberInvalid(formGroup, field): boolean {
    const guaranteeNumber = formGroup.get('guaranteeNumber');
    if (guaranteeNumber) {
      if (isNaN(guaranteeNumber.value)) {
        guaranteeNumber.setErrors({ 'invalid': true });
      } else {
        guaranteeNumber.setErrors({ 'required': true });
        if (guaranteeNumber.value || guaranteeNumber.value === 0) {
          guaranteeNumber.setErrors(null);
          guaranteeNumber.setValue(parseInt(guaranteeNumber.value));
        }
      }
    }
    return this.isFormInvalid(formGroup, field);
  }

  /**
   * NgInit built in lifecycle that gets called once the component has been initialized.
   * Sets up the forms and initiates load of existing data if dealId exists
   */
  public ngOnInit(): void {
    const dealId: string = this.dealService.getDealId();
    this.deal = this.dealService.deal;
    this.loanout = this.dealService.loanout;
    this.itemsArray = [];
    this.feeTypeForm = this.fb.group({
    });
    if (dealId !== null && dealId !== 'new') {
      this.getContractTerms(dealId);
      this.cancelButtonOptions = new CancelButtonModel('fc', 'compensation', 'navigate', `createDeal/${dealId}/summary`);
    }
    if (this.dealService.deal.performerRole) {
      this.showDescript = this.dealService.deal.performerRole.toLowerCase() === 'stunt';
    }
    this.initializeForm();
  }

  initializeForm() {
    this.compensationForm = this.fb.group({
      'feeType': new FormControl(this.feeTypes.options[0]),
      'contractRider': new FormControl(null),
      'descript': new FormControl(this.isDescriptChecked),
    });
  }

  /*
   * ngAfterViewInit
   */
  public ngAfterViewInit(): void {
    this.focusOnload();
  }

  public focusOnload() {
    if (!this.disableForm) {
      setTimeout(() => {
        this.feeTypeDropDown.dropdownButton.nativeElement.focus();
        this.feeTypeDropDown.dropdownButton.nativeElement.autofocus = true;
      },1500);
    }
  }

  /**
   * Gets all compensation details related to the Deal.
   *
   * @param dealId The dealId of the compensation details to get.
   */
  public setCompensationDetails(compensations): void {
    if (compensations) {
      compensations.forEach((obj) => {
        const currId = obj.id.toString();
        this.currentFeeType = currId;
        this.feeTypes.options.forEach((fee) => {
          if (obj.id === fee.id) {
            obj.feeType = obj.id;
          }
        });
        let newFormula: any;
        this.compensationForm.controls[currId] = this.fb.array([]);
        obj.data.forEach(element => {
          if (element.descript) {
            this.isDescriptChecked = element.descript;
            this.compensationForm.get('descript').patchValue(this.isDescriptChecked);
          }
        });
        this.dealService.getFormula(obj.feeType).subscribe(
          (formulaData: any) => {
            newFormula = formulaData[0];
            this.detailGroups = this.groupDetails(newFormula.details.slice());

            this.itemsArray.push({
              id: currId,
              formArray: this.compensationForm.get(currId) as FormArray,
              grouping: this.detailGroups
            });
            obj.data.forEach((o) => {
              this.itemsArray[this.itemsArray.length - 1].formArray.push(this.buildItem(newFormula, o));
            });
            this.focusOnload();
          }
        );
      });
    }
  }

  public setRiders(dealId, contracts, compensations): void {
    // Set contracts in this.riders
    if (contracts) {
      contracts.forEach((contract) => {
        let matchedComp = null;
        if (contract.compensationId) {
          matchedComp = this.getMetchedCompensation(contract.compensationId, compensations);
        }
        // Add to riders
        this.riders.unshift({
          id: contract.id,
          compensationId: contract.compensationId,
          dealId: dealId,
          contractLookupId: contract.contractLookupId,
          riderTitle: contract.contractName,
          date: (matchedComp && matchedComp.startDate ? this.formatDate(matchedComp.startDate) : null),
          isVoid: (matchedComp ? matchedComp.voidFlag : null),
          isNew: false
        });
      });
    }
  }

  /**
   * Called when the given form is invalid in order to mark the invalid controls.
   *
   * @param formGroup The FormGroup to mark.
   */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  /**
   * Checks whether the given FormControl allows a negative or zero value.
   *
   * @param field The FormControl to check.
   * @param allowNegative Boolean for allowing negative values.
   * @param allowZero Boolean for allowing zero values.
   */
  public checkValue(field, allowNegative, allowZero): void {
    if (!allowZero) { this.containsZero(field); }
    if (!allowNegative) { this.containsNegative(field); }
  }

  /**
   * Checks if the given FormControl has a value of zero, and if so - sets it to null to prevent user from entering zeroes.
   *
   * @param field The FormControl to prevent zeroes on.
   */
  private containsZero(field): void {
    if (this.feeTypeForm.get(field).value === 0 || this.feeTypeForm.get(field).value === null) {
      this.feeTypeForm.get(field).setValue(null);
    }
  }

  /**
   * Checks if the given FormControl has a negative value, and if so - sets it to null to prevent user from entering negative values.
   *
   * @param field The FormControl to prevent negative values on.
   */
  private containsNegative(field): void {
    if (this.feeTypeForm.get(field).value < 0) {
      this.feeTypeForm.get(field).setValue(null);
    }
  }

  /**
   * Clears (resets) the FormGroup.
   */
  public clearItem(): void {
    this.feeTypeForm.reset();
  }

  public cancelRow() {
    this.compensationForm.get('feeType').setValue('');
  }

  /**
   * When the 'cancel' icon (x) is pressed, resets the given FormGroup's value to the original value.
   *
   * @param formGroup The FormGroup to reset previous values on.
   */
  public cancelItem(formGroup, itemsArrayIndex, controlsIndex, isDisable?): void {
    formGroup.patchValue(formGroup.currentState.value);
    this.editedFeeTypeArray.splice(this.itemsArray[itemsArrayIndex].id, 1);
    for (const group of this.detailGroups) {
      for (const detail of group.details) {
        if (detail.fieldType.name === 'DROP_DOWN') {
          const key = detail.fieldName;
          if (detail.options.dropdownValue != null) {
            detail.options.dropdownValue = formGroup.value[key];
            if (detail.options.dropdownValue != null) {
              detail.options.selection = detail.options.dropdownValue.value;
              detail.selection = detail.options.dropdownValue.value;
            } else {
              detail.options.selection = null;
              detail.selection = null;
            }
          }
        }
      }
    }
    if (isDisable) {
      Object.keys(formGroup.controls).forEach((field) => {
        formGroup.controls[field].disable();
      });
    } else {
      Object.keys(formGroup.controls).forEach((field) => {
        formGroup.controls[field].markAsUntouched();
      });
    }
  }

  /**
   * When the 'delete' icon (-) is pressed, removes the fee from the compensation list.
   *
   * @param itemsArrayIndex The index of the array of this specific fee type.
   * @param controlsIndex The index of the FormGroup to remove.
   */
  public deleteItem(itemsArrayIndex: number, controlsIndex: number): void {
    if (this.checkForSavedChanges === false) {
      this.checkForChanges = true;
    }
    this.isContractRemoved = true;
    const removedItem = this.itemsArray[itemsArrayIndex].formArray.controls.splice(controlsIndex, 1);
    this.isEdited = true;
    this.removeRiderById(removedItem[0].value.id);
  }

  /**
   * When the 'edit' icon (pencil) is pressed, enables the given FormGroup in edit mode (no longer disabled).
   *
   * @param formGroup The FormGroup to edit.
   */
  public editItem(formGroup, itemsArrayIndex, controlsIndex): void {
    this.setCurrentState(formGroup);
    formGroup.enable();
    this.checkForChanges = true;
    const item = this.itemsArray[itemsArrayIndex];
    this.editedFeeTypeArray[item.id] = {
      'index': controlsIndex,
      'value': formGroup.getRawValue()
    };
    this.foucsOnEditField(item.grouping, itemsArrayIndex);
  }

  /** This function is used to specifically foucs on selected rows first field */
  private foucsOnEditField(items, index): void {
    if (items) {
      let found = null;
      for (const item of items) {
        for (const detail of item.details) {
          const elem = this.criteriaGroup.nativeElement.querySelector('#date_' + index + '_' + detail.id);
          if (elem) {
            found = elem.querySelector('.jq-selector');
            setTimeout(() => {
              found.focus();
            });
            break;
          }
        }
        if (found) {
          break;
        }
      }
    }
  }

  public setCurrentState(formGroup): void {
    formGroup.currentState = { ...formGroup };
  }

  /**
   * When the 'add' icon (+) is pressed on the given (editable) FormGroup, updates the FormGroup to the values input by user.
   *
   * @param formGroup The FormGroup to update.
   */
  public updateItem(formGroup, itemsArrayIndex, controlsIndex): void {
    if (formGroup.valid) {
      Object.keys(formGroup.controls).forEach((field) => {
        formGroup.controls[field].disable();
      });
      this.editedFeeTypeArray.splice(this.itemsArray[itemsArrayIndex].id, 1);
      this.updateRider(formGroup.value.id, formGroup.value.voidFlag, formGroup.value.startDate);
    } else {
      this.validateFormFields(formGroup);
    }
  }

  /**
   * Gets the Formula for the given fee type, for dynamically populating the form elements based off of the defined formula.
   *
   * @param type The fee type to get the Formula for.
   */
  public getFormula(feeTypeId?): void {
    if (feeTypeId) {
      this.dealService.getFormula(feeTypeId).subscribe(
        (data: any) => {
          this.formula = data[0];
          this.formula.details.forEach((detail) => {
            if (detail.fieldType.name === 'CHECK_BOX') {
              detail.defaultValue = (detail.defaultValue === 'false' || detail.defaultValue === null) ? false : detail.defaultValue;
            }
          });
          this.currentFeeType = this.compensationForm.get('feeType').value.id.toString();
          if (feeTypeId === this.currentFeeType) {
            this.feeTypeForm = this.feeTypeForm;
          } else if (this.deal.performerRoleNumber && this.deal.performerRoleNumber.toString() === '888') {
            this.feeTypeForm = this.fb.group({
              contractDate: this.fb.control(Date.now())
            });
          } else {
            this.feeTypeForm = this.fb.group({
              contractDate: this.fb.control(this.deal.dealDate)
            });
          }
          this.detailGroups = this.groupDetails(this.formula.details.slice());
          this.changeDetector.detectChanges();
        }
      );
    }
  }

  /**
   * Creates a new FormArray for a unique fee type. This is for grouping the same fee types together in the UI.
   *
   * @param feeType The fee type to build FormArray on.
   * @param groups The current grouping of formula details.
   */
  public buildFeeGroups(feeType, groups): void {
    this.compensationForm.controls[feeType] = this.fb.array([], Validators.required);
    this.itemsArray.push({
      id: feeType,
      formArray: this.compensationForm.get(feeType) as FormArray,
      grouping: groups
    });
  }

  /**
   * Reads the current formula and groups each FormControl by their groupType. This is needed for grouping FormControls that
   *  have a label that spans multiple elements, and are related in some capacity.
   *
   * @param details The formula details to loop over and group together.
   */
  public groupDetails(details: Array<any>): any[] {
    let currGroupNum: number;
    let prevGroupNum: number;
    const groups: any[] = [];

    let i = details.shift();
    while (i !== undefined) {
      const validator = (i.requiredFlag === true) ? [Validators.required] : [];
      if (i.validationExpression) {
        validator.push(Validators.pattern(new RegExp(i.validationExpression)));
      }
      this.feeTypeForm.addControl(i.fieldName, new FormControl(i.defaultValue, validator));

      if (i.fieldType.name === 'DROP_DOWN') {
        i.options = this.getDropdownOptions(i.fieldTypeLookupType);
      }

      if (i.groupType) {
        currGroupNum = i.groupType.id;
        if (currGroupNum !== prevGroupNum) { // If different, then new group
          groups.push({ name: i.groupType.name, array: this.currentFeeType, details: [i] });
        } else {                             // If same, add to current group
          groups[(groups.length - 1)].details.push(i);
        }
        prevGroupNum = i.groupType.id;
      } else {
        groups.push({ name: i.label, array: this.currentFeeType, details: [i] }); // Single group
      }
      i = details.shift();
    }
    this.getValueChanges(this.feeTypeForm);
    this.setCurrentState(this.feeTypeForm);
    return groups;
  }

  /**
  * Populates the dropdown value when populating the form.
  *
  * @param type The DropdownModel to iterate over.
  * @param value The value to set on the dropdown.
  * @param field The field name to compare against.
  */
  public getDropdownSelection(type, value, field) {
    let selection = value;
    if (type.options) {
      type.options.forEach((val) => {
        if (value === val.data[field]) {
          selection = val;
        }
      });
    }
    return selection;
  }

  /**
   * Calculates and returns the bootstrap grid class (i.e. 'col-1', 'col-6', etc.) for the group.
   * This gives dynamic control to handle many different formula structures.
   *
   * TODO: Calculate the amount of groups and distribute evenly across all columns (i.e. bootstrap columns should add up to 12)
   *
   * @param group The group to calculate the class on.
   */
  public getFormulaClass(group): string {
    const colSize: number = group.details.length > 1 ? group.details.length : 1;
    let size: number = colSize <= 4 ? colSize : 4;

    if (this.isLastElement(group)) {
      size = 2;
    }

    return 'col-' + size;
  }

  public getSubClassForDatepicker(detail, group): string {
    let cssClass = '';
    if (detail.label === 'Sent' || detail.label === 'Returned' || detail.label === 'Revised') {
      cssClass = 'pull-left';
    }

    return cssClass;
  }

  /**
   * Calculates and returns the bootstrap grid class (i.e. 'col-1', 'col-6', etc.) for the inner group details.
   * This gives dynamic control to handle many different formula structures.
   *
   * @param detail The formula detail (individual FormControl) to calculate size on.
   * @param group The group that the detail belongs to.
   */
  public getSubFormulaClass(detail, group): string {
    let count: number = 0;
    group.details.forEach((g) => {
      if (g.fieldType.name === 'CHECK_BOX' || g.fieldType.name === 'TEXT_AREA') {
        count++;
      }
    });
    const numOfCols: number = group.details.length - count;
    const avg: number = Math.round((12 - count) / numOfCols);
    let size: number;
    if (detail.fieldType.name === 'CHECK_BOX' || detail.fieldType.name === 'TEXT_AREA') {
      size = 1;
    } else {
      size = avg;
    }

    if (detail.label === 'Total Amount') {
      return 'd-inherit col-' + size;
    }
    if (detail.label === 'Info') {
      return 'col-1 note-label-style';
    }
    if (detail.label === 'Void') {
      return 'col-1 void-label-style';
    }
    if (detail.label === 'Text') {
      return 'col-1 text-label-style';
    }
    return 'col-' + size;
  }

  /**
   * Determines what label will be displayed for the FormControl (Group name that spans, or individual element name).
   *
   * @param group The given group to retrieve label from.
   */
  public getFormulaLabel(group): string {
    return group.name ? group.name : group.details[0].label;
  }

  /**
   * Sets up the calculations for the fee type formulas (i.e. rate x guarantee = totalAmount).
   *
   * @param formGroup The FormGroup to setup calculations on.
   */
  private getValueChanges(formGroup): void {
    const totalAmount = formGroup.get('totalAmount');
    if (formGroup.get('rate') && formGroup.get('guaranteeNumber')) {
      const rate = formGroup.get('rate');
      const guarantee = formGroup.get('guaranteeNumber');
      rate.valueChanges.subscribe(val => {
        const total = (rate.value * guarantee.value).toString();
        if (!total.includes('-') && val !== formGroup.value['rate']) {
          totalAmount.setValue(parseFloat(total).toFixed(2));
        }
        if (isNaN(parseFloat(total))) {
          totalAmount.setValue(parseFloat('0').toFixed(2));
        }
      });
      guarantee.valueChanges.subscribe(val => {
        const total = (rate.value * guarantee.value).toString();
        if (!total.includes('-') && val !== formGroup.value['guaranteeNumber']) {
          totalAmount.setValue(parseFloat(total).toFixed(2));
        }
        if (isNaN(parseFloat(total))) {
          totalAmount.setValue(parseFloat('0').toFixed(2));
        }
      });
    } else {
      if (!totalAmount.value) {
        totalAmount.setValue(parseFloat('0').toFixed(2));
      }
    }
  }

  public isLastElement(group): boolean {
    return (group.name === this.detailGroups[this.detailGroups.length - 1].name);
  }

  /**
   * Saves / Updates the compensation details when the user clicks the 'Save' or 'Save & Continue' icon.
   *
   * @param type The navigation type to take.
   */
  public saveCompensation(type?): void {
    this.skipUnsavedModalEvent = true;
    const compValue = this.compensationForm.getRawValue();
    for (const property in compValue) {
      if (!isNaN(parseFloat(property)) || this.riders.length) {
        if (compValue[property] && compValue[property].length || this.riders.length) {
          this.rowData = true;
        }
      }
    }
    if (this.dealService.currentWizardPage.status) {
      if (!this.rowData && this.dealService.currentWizardPage.status.name !== 'NOT_APPLICABLE') {
        this.type = type;
        this.openApplicableNotApplicableModal();
      }
    }
    if (!this.rowData && !this.dealService.currentWizardPage.status) {
      this.type = type;
      this.openApplicableNotApplicableModal();
    } else if (this.rowData || this.dealService.currentWizardPage.status.name === 'NOT_APPLICABLE' || this.checkForSavedChanges || this.isContractRemoved) {
      if (this.compensationForm.valid) {
        this.checkForSavedChanges = true;
        if (this.isContractRemoved && !this.rowData) {
          const compData = this.getDataForSave();
          this.dealService.saveCompensation(compData, this.getRidersToSave()).subscribe(res => {
          }, err => {
            console.log(err);
            this.toasterService.error('Failed to save Compensation details.', 'Error');
          });
        } else if ((this.isContractRemoved && this.rowData) || this.rowData || this.dealService.currentWizardPage.status.name === 'NOT_APPLICABLE') {
          this.saveCompApiCall(type);
        }
      } else {
        this.validateFormFields(this.compensationForm);
      }
    }
  }

  public getDataForSave() {
    const compData = this.compensationForm.getRawValue();
    (compData.feeType === null) ? this.isFormBlank = true : this.isFormBlank = false;
    Object.keys(compData).forEach((key: string) => {
      if (this.editedFeeTypeArray && this.editedFeeTypeArray[key]) {
        compData[key] = [this.editedFeeTypeArray[key].value];
      }
    });
    return compData;
  }

  /* Method to save compensastion data API call*/
  public saveCompApiCall(type): void {
    const compData = this.getDataForSave();
    this.isContractSelected = false;
    if (!this.isFormBlank || this.getRidersToSave().length > 0 || this.removeRiderRow || this.checkForSavedChanges || this.isContractRemoved) {
      this.dealService.saveCompensation(compData, this.getRidersToSave()).subscribe(res => {
        this.navigateOnSave(type);
      }, err => {
        console.log(err);
        this.toasterService.error('Failed to save Compensation details.', 'Error');
      });
    } else {
      this.navigateOnSave(type);
    }
  }

  /* Method to navigate on click of save and save continue*/
  public navigateOnSave(type): void {
    if (type === 'continue') {
      this.dealEventService.pageSavedEvent({ type: type, pageTo: 'credit', dealId: this.deal.id, status: (!this.rowData && this.dealService.currentWizardPage.status) ? this.dealService.currentWizardPage.status.name : 'COMPLETE' });
    } else {
      this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: this.deal.id, status: (!this.rowData && this.dealService.currentWizardPage.status) ? this.dealService.currentWizardPage.status.name : 'COMPLETE' });
    }
    this.compensationForm.markAsUntouched();
    this.compensationForm.markAsPristine();
  }

  /**
   * When the cancel icon (x) at the top of the page is pressed, returns user to last history item.
   * TODO: hook this up once deal flow is ready.
   */
  public cancelCompensation() {
    this.toasterService.info('Navigating', 'Cancel Success');
    // this.clearItem();
  }

  /**
   * Method to open delete confirmation modal
  */
  public openDeleteConfirmationModal(index) {
    this.deleteModal.openModal();
    this.riderIndex = index;
    this.saveAndContinue.setFocus();
  }

  /**
   * Method to handle modal "OK" click event
  */
  public deleteModalClosed(event) {
    if (event.action === 'OK') {
      if (this.riderIndex != null) {
        this.removeRider(this.riderIndex);
        this.removeRiderRow = true;
      }
    }
  }

  /**
   * Gets the dropdown options for each dropdown in the form.
   *
   * @param lookupType The dropdown type to get based on the lookupType.
   */
  public getDropdownOptions(lookupType: string): DropdownModel {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.sharedService.getDropdown(lookupType).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
        if (lookupType === 'START_DATE_QUALIFIER_TYPE') {
          this.populateStartDateQualifier(dropdownModel);
        } else if (lookupType === 'PERIOD_TYPE') {
          // Entering blank option
          options.unshift({
            value: '',
            route: '',
            id: 'lookup_' + lookupType,
            data: ''
          });
        }

      }
    );
    return dropdownModel;
  }

  public populateStartDateQualifier(dropdownModel) {
    const startDateQualifier = this.feeTypeForm.get('startDateQualifierId');
    if (!startDateQualifier.value) {
      const selection = this.getDropdownSelection(dropdownModel, 'Approx', 'name');
      startDateQualifier.setValue(selection);
    }
  }

  /**
   * Removes a contract/rider from the current list in the compensation form.
   *
   * @param contract The given contract/rider to remove.
   */
  public removeRider(riderIndex): void {
    if (this.checkForSavedChanges === false) {
      this.checkForChanges = true;
    }
    this.riders.splice(riderIndex, 1);
    this.isContractRemoved = true;
    let element = document.getElementById('deleteContractButton'+(riderIndex+1));
    if (element) {
      let span = <HTMLElement> element.children[0];
      setTimeout(()  => {
        span.focus()},1000);
    }
  }

  public removeRiderById(compensationId) {
    if (compensationId) {
      const riderId = this.riders.map(function (item: any) { return item.compensationId; }).indexOf(compensationId);
      this.riders.splice(riderId, 1);
    }
    this.isContractRemoved = true;
  }

  /**
   * Adds new contract/rider to compensation form.
   */
  public addRider(): void {
    const contract = this.compensationForm.value.contractRider;
    if (contract !== null && contract.value !== null && contract !== undefined && contract !== '') {
      const dealId: string = this.dealService.getDealId();
      this.isContractSelected = false;
      // Add to riders
      this.riders.unshift({
        id: null,
        compensationId: null,
        dealId: dealId,
        contractLookupId: this.compensationForm.value.contractRider.id,
        riderTitle: this.compensationForm.value.contractRider.value,
        date: null,
        isVoid: false,
        isNew: true
      });
      // after adding set dropdown to empty
      this.compensationForm.get('contractRider').setValue('');
    } else {
      this.isContractSelected = true;
    }
  }

  /* Method to validate contract rider field on select*/
  public onSelectContract(): void {
    this.isContractSelected = false;
  }

  /* Method to create compensation object to get PDF file */
  public getCompensationData(compensationId) {
    let matchedCompForm: any[] = [];
    if (compensationId) {
      this.itemsArray.forEach((item) => {
        if (matchedCompForm.length === 0) {
          matchedCompForm = item.formArray.value.filter(val => val.id === compensationId);
        }
      });
    }
    return matchedCompForm;
  }

  public printAll(): void {
    const request = [];
    if (this.riders && this.riders.length) {
      this.riders.forEach((rider, index) => {
        const compensationObj = this.getCompensationData(rider.compensationId);
        request.push(this.dealService.downloadfile(this.deal.id, rider.contractLookupId, compensationObj));
      });
      forkJoin(request).subscribe(results => {
        if (results) {
          results.forEach(blob => {
            this.download(blob);
          });
        }
      });
    }
  }

  private download(blobObj): void {
    // For browser compatibility
    const ieEDGE = navigator.userAgent.match(/Edge/g);
    const ie = navigator.userAgent.match(/.NET/g); // IE 11+
    const oldIE = navigator.userAgent.match(/MSIE/g);
    if (ie || oldIE || ieEDGE) {
      const blob = new window.Blob([blobObj], { type: 'application/pdf' });
      window.navigator.msSaveBlob(blob, name + 'file.pdf');
    } else {
      const file = new Blob([blobObj], { type: 'application/pdf' });
      const fileURL = URL.createObjectURL(file);
      window.open(fileURL);
    }
  }

  /*
  * Method to download Pdf file
  * @Param riderIndex
  */
  public downloadFile(riderIndex) {
    const compensationObj = this.getCompensationData(this.riders[riderIndex].compensationId);
    this.dealService.downloadfile(this.deal.id, this.riders[riderIndex].contractLookupId, compensationObj)
      .subscribe(
        (data) => {
          // for browser compatibility
          const ieEDGE = navigator.userAgent.match(/Edge/g);
          const ie = navigator.userAgent.match(/.NET/g); // IE 11+
          const oldIE = navigator.userAgent.match(/MSIE/g);
          const name = 'file';
          const blob = new window.Blob([data], { type: 'application/pdf' });

          if (ie || oldIE || ieEDGE) {
            const fileName = name + '.pdf';
            window.navigator.msSaveBlob(blob, fileName);
          } else {
            const file = new Blob([data], {
              type: 'application/pdf'
            });
            const fileURL = URL.createObjectURL(file);
            window.open(fileURL);
          }
        },
        error => {
          console.log('Error downloading the file.' + error);
        },
        () => {
          console.log('complete');
        }
      );

  }

  private updateRider(id, isVoid, startDate): void {
    if (id) {
      this.riders.forEach((rider) => {
        if (rider.compensationId === id) {
          rider.isVoid = isVoid;
          if (startDate !== null) {
            rider.date = this.formatDate(startDate);
          } else {
            rider.date = null;
          }
        }
      });
    }
  }

  private addRiderFromCompensationAdd() {
    // Eval contract title based on fee type
    const contract = this.getContractByFeetype();
    if (this.feeTypeAndContractMap != null && contract !== null) {
      let startDate: any;
      let isVoid: boolean;
      const dealId: string = this.dealService.getDealId();
      // Get start date
      if (this.feeTypeForm.controls.startDate.value !== null) {
        startDate = this.formatDate(this.feeTypeForm.controls.startDate.value);
      }

      // Eval is void
      if (this.feeTypeForm.controls.voidFlag.value === true) {
        isVoid = true;
      }

      // Add to riders
      this.riders.unshift({
        id: null,
        compensationId: this.tempCompId,
        dealId: dealId,
        contractLookupId: contract.contractLookupId,
        riderTitle: contract.contractName,
        date: startDate,
        isVoid: isVoid,
        isNew: true
      });
    }

  }

  private getContractByFeetype() {
    const contracts: any[] = [];
    let result;
    this.feeTypeAndContractMap.forEach((item) => {
      if (this.currentFeeType === item.feetypeLookupId.toString()) {
        contracts.push(item);
      }
    });
    if (contracts.length === 0) {
      result = null;
    } else if (contracts.length === 1) {
      result = contracts[0];
    } else {
      if (this.deal.loanoutId) {
        result = this.getContractByFilter('LOANOUT', contracts);
      } else {
        result = this.getContractByFilter(null, contracts);
      }
    }
    return result;
  }

  private getContractByFilter(filter: string, contracts: any[]) {
    let result: any;
    contracts.forEach((item) => {
      if (item.filter === filter) {
        result = item;
      }
    });
    return result;
  }

  private getRidersToSave() {
    const saveRidersObj: any[] = [];
    this.riders.forEach((rider) => {
      saveRidersObj.unshift({
        id: rider.id,
        compensationId: rider.compensationId,
        dealId: rider.dealId,
        contractLookupId: rider.contractLookupId
      });
    });
    return saveRidersObj;
  }

  /* Method to format date */
  private formatDate(date) {
    let format = null;
    const isValid = moment(date).isValid();
    if (isValid) {
      format = moment.parseZone(date).format('MM/DD/YYYY');
    }
    return format;
  }

  public generateUniqueId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  /* Method to open modal popup */
  public openApplicableNotApplicableModal(): void {
    this.applicableNotApplicableModal.openModal();
  }

  public applicableModalClosedEvent(event): void {
    if (event === 'OK') {
      const dealId: string = this.dealService.getDealId();
      if (this.type === 'continue') {
        this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'credit', dealId: parseInt(dealId), status: this.status });
      } else {
        this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'summary', dealId: parseInt(dealId), status: this.status });
      }
    }
  }

  public applicableConfVal(event) {
    if (event) {
      if (event === 'Skip and complete later?') {
        this.status = 'INCOMPLETE';
      } else {
        this.status = 'NOT_APPLICABLE';
      }
    }
  }

  public createEditPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === false) {
      return true;
    } else if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === true) {
      return false;
    }
  }

  public onEnterKeyPressed(formGroup, event) {
    if (event) {
      const contractDate = formGroup.get('contractDate');
      contractDate.patchValue(event);
    }
  }
}

