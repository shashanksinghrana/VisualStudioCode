import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompensationComponent } from './compensation.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { RouterModule, Router } from '@angular/router';
import { NO_ERRORS_SCHEMA, DebugElement } from '@angular/core';
import { TypeAheadPersistService, UrlResolverService, ToasterService, UnsavedChangesService } from 'c2c-common-lib';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { SharedService } from '../../services/http/shared/shared.service';
import { BillingEventService } from '../../services/events/billing-event.service';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { StatusDatesEventService } from '../../services/events/status-dates-event.service';
import { LocationEventService } from '../../services/events/location-event.service';
import { WorkWeekEventService } from '../../services/events/work-week-event.service';
import { DealService } from '../../services/http/deal/deal.service';
import { CurrentUserPersistService } from '../../services/persist/user/current-user-persist.service';
import { DealEventService } from '../../services/events/deal-event.service';
import { FormBuilder } from '@angular/forms';
import { LoadingIndicatorService } from '../../services/other/loading-indicator.service';
import { IterableChangeRecord_ } from '@angular/core/src/change_detection/differs/default_iterable_differ';

describe('CompensationComponent', () => {
  let component:CompensationComponent;
  let fixture:ComponentFixture<CompensationComponent>
let de:DebugElement;
let el:HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompensationComponent ],
      imports:[
        HttpClientModule,
        HttpModule,
        RouterModule
      ],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        TypeAheadPersistService,
        UrlResolverService,
        ToastsManager,
        ToastOptions,
        ToasterService,
        ProjectDetailService,
        SharedService,
        BillingEventService,
        UserPermissionService,
        StatusDatesEventService,
        LocationEventService,
        WorkWeekEventService,
        UnsavedChangesService,
        DealService,
        CurrentUserPersistService,
        DealEventService,
        FormBuilder,
        LoadingIndicatorService,
       { provide: Router, useClass: class { navigate = jasmine.createSpy("navigate"); } }]
    })
    .compileComponents().then(()=>{
      fixture = TestBed.createComponent(CompensationComponent);
      component=fixture.componentInstance;
    });
  }));


  // it('should create the app', async(() => {
  //   const fixture = TestBed.createComponent(CompensationComponent);
  //   const app = fixture.debugElement.componentInstance;
  //   expect(app).toBeTruthy();
  // }));

  // it('should have property contractRiders', () => {
  //   let fixture = TestBed.createComponent(CompensationComponent);
  //   let component = fixture.componentInstance;
  //   expect(component.contractRiders).toBeTruthy(true);
  // });

  // it('should have property contractRiders', () => {
  //   const fixture = TestBed.createComponent(CompensationComponent);
  //   const component = fixture.componentInstance;
  //   expect(component.viewPermission).toEqual('FeatureCasting.DealCreateEdit.VIEW');
  // });

  it('should have property edit deal', () => {
    
   
    expect(component.editPermission).toEqual('FeatureCasting.DealCreateEdit.UPDATE');
  });

  it('should have property view deal', () => {   
    let fixture = TestBed.createComponent(CompensationComponent);
    let component = fixture.componentInstance;
    expect(component.viewPermission).toEqual('FeatureCasting.DealCreateEdit.VIEW');
  });

    it('should not disable form',()=>{
      let fixture = TestBed.createComponent(CompensationComponent);
      let component = fixture.componentInstance;
      expect(component.disableForm).toBeFalsy();
});


  // it('form should be invalid',()=>{
  //   const fixture = TestBed.createComponent(CompensationComponent);
  //   const component = fixture.componentInstance;
  //  //component.compensationForm['feeType'].setValue('');
  //   component.compensationForm['contractRider'].setValue('');
  //   component.compensationForm['descript'].setValue('');
  //   expect(component.compensationForm.valid).toBeFalsy();
  // })


  // it('should call save method', () => {
  //   const fixture = TestBed.createComponent(CompensationComponent);
  //   const component = fixture.componentInstance;
  // component.saveCompensation();
  // expect(component.skipUnsavedModalEvent).toBeTruthy();
  // });

  it('should create app', () => {
    let fixture = TestBed.createComponent(CompensationComponent);
    let component = fixture.componentInstance;
    expect(component).toBeTruthy();
  });
 });
