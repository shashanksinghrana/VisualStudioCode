import { Component, OnInit, OnDestroy, ViewContainerRef, Renderer } from '@angular/core';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { ActivatedRoute } from '@angular/router';
import { ColumnDefModel, ToasterService } from 'c2c-common-lib';
import { SharedService } from '../../services/http/shared/shared.service';
import { Subscription } from 'rxjs';
import { BillingEventService } from '../../services/events/billing-event.service';
import { ToastsManager } from 'ng2-toastr';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';

@Component({
  selector: 'fc-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.scss']
})
export class BillingComponent implements OnInit, OnDestroy {
  public pageOptions: {};
  public billingDefs: ColumnDefModel[] = [];
  public billingData: any[];
  public projectId: number;
  public editType: any;
  public stopEditingWhenGridLosesFocus: boolean;
  public editedRowIndex: number;
  public gridApi: any;
  public confirmedByOptions: any[] = [];
  public cellValueChanged: boolean = false;
  public suppressClickEdit: boolean = true;
  private subscriptions: Subscription = new Subscription();

  public billingEditPermission: PermissionList = PermissionList.projectDetailsBillingEdit;
  public billingViewPermission: PermissionList = PermissionList.projectDetailsBillingView;

  public isGridRefreshed: boolean = false;


  /*
   * The Constructor for BillingComponent
   *
   * @param route The active route.
   * @param projectDetailService The Project Details Service for getting data.
   */
  constructor(
    private route: ActivatedRoute,
    private projectDetailService: ProjectDetailService,
    private sharedService: SharedService,
    private billingEventService: BillingEventService,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private renderer: Renderer,
    private userPermissionService: UserPermissionService
  ) {
    this.toaster.setRootViewContainerRef(vcr);
    this.route.data.subscribe(
      (data) => {
        this.confirmedByOptions = data.options;
        this.projectDetailService.confirmedByOptions = this.confirmedByOptions;
      });
    this.route.parent.params.subscribe(res => this.projectId = res.projectId);
    this.pageOptions = projectDetailService.getBillingPageOptions();
    this.billingDefs = projectDetailService.createBillingColDefs(this.editPermission());
    this.getBillingData(this.projectId);
  }

  public ngOnInit() {
    this.editType = 'fullRow';
    this.stopEditingWhenGridLosesFocus = false;
    this.subscriptions.add(this.billingEventService.getBillingSavedEvent()
      .subscribe(value => {
        this.saveBillingRecords(value);
      }));
    this.subscriptions.add(this.billingEventService.getBillingCancelledEvent()
      .subscribe(value => {
        this.cancelSaveBillingRecords(value);
      }));
  }

  private resetFilterOptions(): void {
    if (this.gridApi) {
      this.gridApi.getFilterInstance('mainTitle').setModel();
      this.gridApi.getFilterInstance('endTitle').setModel();
      this.gridApi.getFilterInstance('paidAd').setModel();
      this.gridApi.getFilterInstance('cutFlag').setModel();
      this.gridApi.getFilterInstance('notCredited').setModel();
      this.gridApi.getFilterInstance('attachment').setModel();
    }
  }

  /**
   * Refreshes the Grid to get the latest billing data.
   *
   */
  public refreshData(): void {
    this.resetFilterOptions();
    this.getBillingData(this.projectId);
    this.isGridRefreshed = true;

  }

  /**
* Gets all of the billing data to be displayed in the Grid.
*
* @param id The project id tied to billing data to get.
*/
  private getBillingData(id): void {
    if (this.gridApi) {
      this.gridApi.showLoadingOverlay();
    }
    this.projectDetailService.getBilling(id).subscribe(
      (data) => {
        data.forEach((element, index) => {
          element.confirmedBy = element.confirmedBy ? element.confirmedBy.name : element.confirmedBy;
          element.subTitles = [];
          const pkaValue = element.pka ? element.pka : null;
          const creditedAsValue = element.creditAs ? element.creditAs : null;
          if (pkaValue && creditedAsValue) {
            element.subTitles.push({
              'PKA': pkaValue,
              'Credited As': creditedAsValue
            });
          } else if (pkaValue && !creditedAsValue) {
            element.subTitles.push({
              'PKA': pkaValue
            });
          } else if (!pkaValue && creditedAsValue) {
            element.subTitles.push({
              'Credited As': creditedAsValue
            });
          }

          if (element.creditBillingText && element.creditBillingText.length > 0) {
            element.creditBillingText.forEach((ele) => {
              ele = this.getTextFromPerformerNotes(ele);
            });
          }
        });
        this.billingData = data;
        if (this.gridApi) {
          this.gridApi.hideOverlay();
        }
      },
      (error) => { this.toasterService.error('Error when getting billing', error); }
    );
  }
  /**
  * gets string from html data in RTE editor
  *
  */
  public getTextFromPerformerNotes(note): string {
    const doc = (new DOMParser()).parseFromString(note, 'text/html');
    return doc.body.innerText.trim();
  }

  public gridready(params) {
    this.gridApi = params.api;
    // commenting bellow line to fix FC-3420
   // this.gridApi.setRowData(this.billingData);
  }

  public disableOrEnableGridRows(currRowIndex, disableFlag) {
    const body = document.getElementsByClassName('ag-body-container');
    const list = body[0].children;
    Array.from(list).forEach(element => {
      if (element.getAttribute('row-index') !== currRowIndex.toString()) {
        this.renderer.setElementClass(element, 'c2c-grid-row-read-only', disableFlag);
      }
    });
  }

  public onClickPerformer(params) {
    this.editedRowIndex = this.isGridRefreshed ? null : this.projectDetailService.editedRowIndex;
    //  && (this.editedRowIndex !== params.rowIndex)
    // removing above condition to fix FC-3251
    if (params.colDef.cellRendererParams.enableRowEditing) {
      const rowIndex = params.node.rowIndex;
      this.disableOrEnableGridRows(rowIndex, true);
      params.api.setFocusedCell(rowIndex, 'firstName');
      params.api.startEditingCell({
        rowIndex: rowIndex,
        colKey: 'firstName'
      });

      this.editedRowIndex = rowIndex;
      this.projectDetailService.editedRowIndex = this.editedRowIndex;
    }
  }

  public cancelSaveBillingRecords(row) {
    this.disableOrEnableGridRows(row.rowIndex, false);
    row.gridApi.stopEditing(true);
    this.projectDetailService.editedRowIndex = '';
  }

  public saveBillingRecords(row) {
    this.disableOrEnableGridRows(row.rowIndex, false);
    row.gridApi.stopEditing();
    row.gridApi.showLoadingOverlay();
    const reqObj = this.createReqForSave(row);

    this.projectDetailService.editedRowIndex = '';
    this.projectDetailService.saveBilling(reqObj, row.data.dealId, this.projectId).subscribe(
      (data) => {
        row.gridApi.hideOverlay();
        const model = row.gridApi.getFilterModel();
        const sortModel = row.gridApi.getSortModel();
        row.gridApi.setFilterModel(model);
        row.gridApi.setSortModel(sortModel);
      },
      (error) => { this.toasterService.error('Error when saving billing', error); }
    );
  }

  public createReqForSave(row) {
    const rowData = { ...row.data };
    const confirmedByValue = rowData.confirmedBy;

    this.confirmedByOptions.forEach((element, index) => {
      if (element.value === confirmedByValue) {
        rowData.confirmedBy = element;
      }
    });
    rowData.subTitles.forEach(element => {
      if (element['Credited As']) {
        rowData.creditAs = element['Credited As'];
      }

      if (element['PKA']) {
        rowData.pka = element['PKA'];
      }
    });
    delete rowData['subTitles'];

    return rowData;
  }

  public downloadFile(params) {
    const dealId = params.data.dealId;
    this.projectDetailService.getBillingAttachment(dealId, this.projectId).subscribe(
      (data) => {
        const contentType = 'text/html';
        const fileName = this.billingData[params.rowIndex].attachment.name;
        // for browser compatibility
        const ieEDGE = navigator.userAgent.match(/Edge/g);
        const ie = navigator.userAgent.match(/.NET/g); // IE 11+
        const oldIE = navigator.userAgent.match(/MSIE/g);

        if (ie || oldIE || ieEDGE) {
          const blob = new window.Blob([data], { type: contentType });
          window.navigator.msSaveBlob(blob, fileName);
        } else {
          const file = new Blob([data], { type: contentType });
          const fileURL = URL.createObjectURL(file);

          const a: HTMLAnchorElement = document.createElement('a') as HTMLAnchorElement;
          a.href = fileURL;
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(fileURL);
        }
      },
      (error) => { this.toasterService.error('Error when downloading file', error); }
    );
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public editPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.billingViewPermission) === true &&
      this.userPermissionService.hasPermission(this.billingEditPermission) === false) {
      return true;
    } else if (this.userPermissionService.hasPermission(this.billingViewPermission) === true &&
      this.userPermissionService.hasPermission(this.billingEditPermission) === true) {
      return false;
    }
  }
}
