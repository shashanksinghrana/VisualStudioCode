import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BillingComponent } from './billing.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TypeAheadPersistService, UrlResolverService, ToasterService } from 'c2c-common-lib';
import { SharedService } from '../../services/http/shared/shared.service';
import { ToastsManager, ToastOptions } from 'ng2-toastr';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { Observable } from 'rxjs';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { BillingEventService } from '../../services/events/billing-event.service';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { StatusDatesEventService } from '../../services/events/status-dates-event.service';
import { LocationEventService } from '../../services/events/location-event.service';
import { WorkWeekEventService } from '../../services/events/work-week-event.service';


describe('BillingComponent', () => {


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[
        HttpClientModule,
        HttpModule,
        RouterModule
      ],
      declarations: [ BillingComponent ],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        TypeAheadPersistService,
        UrlResolverService,
        ToastsManager,
        ToastOptions,
        ToasterService,
        ProjectDetailService,
        SharedService,
        BillingEventService,
        UserPermissionService,
        StatusDatesEventService,
        LocationEventService,
        WorkWeekEventService,
       { provide: Router, useClass: class { navigate = jasmine.createSpy("navigate"); } },
       {
        provide: ActivatedRoute,
        useValue: {
          params: Observable.from([{id: 1}]),
        },
      },]
    })
    .compileComponents();
  }));

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(BillingComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(BillingComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));


  
});
