import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealPerformerCardComponent } from './deal-performer-card.component';

describe('DealPerformerCardComponent', () => {
  let component: DealPerformerCardComponent;
  let fixture: ComponentFixture<DealPerformerCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealPerformerCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealPerformerCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
