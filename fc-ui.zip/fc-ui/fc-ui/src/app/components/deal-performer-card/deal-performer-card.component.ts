import { Component, OnInit, Input, EventEmitter, Output, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { performerNameFormatter } from '../../utils/formatter/performer-name.format';
import { CancelButtonModel } from 'c2c-common-lib';
import { DealModel } from '../../models/deal/deal.model';
import { LoanoutModel } from '../../models/deal/loanout.model';

@Component({
  selector: 'fc-deal-performer-card',
  templateUrl: './deal-performer-card.component.html',
  styleUrls: ['./deal-performer-card.component.scss']
})
export class DealPerformerCardComponent implements OnInit {
  public cancelButtonOptions: CancelButtonModel;
  public performerName: string;

  @Input() public deal: DealModel;

  @Input() public loanout: LoanoutModel;

  @Input() public disableButtons:boolean=false;
  @Input() public tabIndex;

  @Output() public save: EventEmitter<string> = new EventEmitter<string>();
  @ViewChild('saveAndContinue') saveAndContinue: ElementRef;

  constructor() { }

  public ngOnInit(): void {
    this.cancelButtonOptions = new CancelButtonModel('fc', null, 'navigate', `createDeal/${this.deal.id}/summary`);
    this.performerName = performerNameFormatter(
      this.deal.performer.firstName,
      this.deal.performer.lastName
    );
  }

  public saveAction(type?: string): void {
    this.save.emit(type);
  }

  public setFocus() {
    this.saveAndContinue.nativeElement.querySelector('#continueBtn').focus();
  }

}
