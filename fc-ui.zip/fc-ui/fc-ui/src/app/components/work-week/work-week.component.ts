import { Component, OnInit, ViewContainerRef, Renderer } from '@angular/core';
import { ColumnDefModel, ToasterService } from 'c2c-common-lib';
import { ActivatedRoute } from '@angular/router';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { ToastsManager } from 'ng2-toastr';
import { WorkWeekEventService } from '../../services/events/work-week-event.service';
import { Subscription } from 'rxjs/';
import * as moment_ from 'moment';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';

const moment = moment_;

@Component({
  selector: 'fc-work-week',
  templateUrl: './work-week.component.html',
  styleUrls: ['./work-week.component.scss']
})
export class WorkWeekComponent implements OnInit {
  public pageOptions: {};
  public workWeekDefs: ColumnDefModel[];
  public workWeekData: any[];
  public projectId: number;
  public editedRowIndex: number;
  public cellEditingError: any = [];
  public gridApi: any;
  public columnApi: any;
  public totalWorkDays: number = 0;
  public workWeekDataBeforeValidation: any[];

  public editType: any;
  public stopEditingWhenGridLosesFocus: boolean;
  public suppressClickEdit: boolean = true;
  public selectedId: number;
  public cancelSaveClicked: boolean = false;
  public addClicked: boolean = false;
  public rowValidated: boolean = false;
  public saveClicked: boolean = false;

  private saveRowSubscription: Subscription;
  private cancelSaveRowSubscription: Subscription;
  private deleteRowSubscription: Subscription;
  public createWorkWeek: boolean = true;
  public workWeekViewPermission: PermissionList = PermissionList.projectDetailsWorkWeakView;
  public workWeekAddPermission: PermissionList = PermissionList.projectDetailsWorkWeakCreate;
  public workWeekEditPermission: PermissionList = PermissionList.projectDetailsWorkWeekEdit;


  /*
  * The Constructor for WorkWeekComponent
  *
  * @param route The active route.
  * @param projectDetailService The Project Details Service for getting data.
  * @param workWeekEventService The work week event services for events.
  * @param toasterService The toaster service 
  * @param toaster toast manager
  * @param vcr ViewContainerRef for accessing the view
  * @param renderer renderer for accessing elements
  */
  constructor(
    private route: ActivatedRoute,
    private projectDetailService: ProjectDetailService,
    private workWeekEventService: WorkWeekEventService,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private renderer: Renderer,
    private userPermissionService: UserPermissionService
  ) {
    this.createWorkWeek = this.createPermission();
    this.toaster.setRootViewContainerRef(vcr);
    this.route.parent.params.subscribe(res => this.projectId = res.projectId);
    this.pageOptions = projectDetailService.getWorkWeekPageOptions(this.createWorkWeek);
    this.workWeekDefs = projectDetailService.createWorkWeekColDefs(this.editPermission());
    this.getWorkWeekData(this.projectId);
  }

  ngOnInit() {
    this.editType = 'fullRow';
    this.stopEditingWhenGridLosesFocus = false;

    this.saveRowSubscription = this.workWeekEventService.getWorkWeekSavedEvent()
      .subscribe(value => {
        this.saveWorkWeekRecords(value);
      });
    this.cancelSaveRowSubscription = this.workWeekEventService.getWorkWeekCancelledEvent()
      .subscribe(value => {
        this.cancelSaveWorkWeekRecords(value);
      });
    this.deleteRowSubscription = this.workWeekEventService.getWorkWeekDeletedEvent()
      .subscribe(value => {
        this.deleteWorkWeekRecords(value);
      });
  }

  /**
* Gets all of the work week data to be displayed in the Grid.
*
* @param id The project id tied to work week data to get.
*/
  private getWorkWeekData(id, params?): void {
    if (this.gridApi) {
      this.gridApi.showLoadingOverlay();
    }
    this.projectDetailService.getWorkWeek(id, params).subscribe(
      (data) => {
        let totalWorkDays = 0;
        if (this.gridApi) {
          this.gridApi.hideOverlay();
        }
        data.forEach((element, index) => {
          let returnData = this.createDataForGrid(element);

          element.workWeekDays = returnData.workWeekDays;
          element.days = returnData.days;

          totalWorkDays = totalWorkDays + element.days;
        });
        this.totalWorkDays = totalWorkDays;
        this.workWeekData = data;
      },
      (error) => { this.toasterService.error('Error when getting Work week data', error); }
    );
  }

  public createDataForGrid(data) {
    let returnData: any;
    let difference = 0;

    let start = moment(data.startDate);
    let finish = moment(data.finishDate);

    const businessDays = [];
    let isWeekend = false;
    const isDaySelected = false;

    while (start.isSameOrBefore(finish, 'day')) {
      if (start.day() != 0 && start.day() != 6) {
        isWeekend = false;
      } else {
        isWeekend = true;
      }

      businessDays.push({
        'day': start.date(),
        'dates': start.format('MM/DD/YYYY'),
        'isWeekend': isWeekend,
        'isDaySelected': true,
        'isWeekendHist': isWeekend,
        'workPeriodDetailId': ''
      })
      start.add(1, 'd');
    }

    businessDays.forEach(day => {
      data.workPeriodDetails.forEach(element => {
        const offDay = moment(element.offDay);
        if (day.dates === offDay.format('MM/DD/YYYY')) {
          day.isWeekend = false;
          day.isDaySelected = false;
          day.workPeriodDetailId = element.workPeriodDetailId ? element.workPeriodDetailId : 0;
        }
      });
    });

    businessDays.forEach(day => {
      if (day.isDaySelected) {
        difference++;
      }
    });

    returnData = {
      'workWeekDays': businessDays ? businessDays : [],
      'days': !isNaN(difference) ? difference : 0
    };
    return returnData;
  }

  public addUserSelectionToBusinessDays(data, businessDays) {
    let difference = 0;
    let returnData = {};
    data.workPeriodDetails.forEach(element => {
      const offDay = moment(element.offDay);
      businessDays.forEach(day => {
        if (offDay.format('MM/DD/YYYY') === day.dates) {
          businessDays.isWeekend = false;
          businessDays.isDaySelected = true;
        }

        if (!businessDays.isWeekend && businessDays.isDaySelected) {
          difference++;
        }
      });
    });

    returnData = {
      'workWeekDays': businessDays,
      'days': !isNaN(difference) ? difference : 0
    };

    return returnData;
  }

  /**
   * Refreshes the Grid to get the latest work week deal data.
   *
   */
  public refreshData(): void {
    this.addClicked = false;
    this.getWorkWeekData(this.projectId);
    this.columnApi.getColumn('startDate').setSort('asc');
  }

  /**
   * disables or enables the Grid rows based on the current row index being edited.
   *
   */
  public disableOrEnableGridRows(currRowIndex, disableFlag) {
    const body = document.getElementsByClassName('ag-body-container');
    const list = body[0].children;
    Array.from(list).forEach(element => {
      if (element.getAttribute('row-index') !== currRowIndex.toString()) {
        this.renderer.setElementClass(element, 'c2c-grid-row-read-only', disableFlag);
      }
    });
  }

  /**
   * disables or enables the Grid rows when new row is being added.
   *
   */
  public disableAllGridRows() {
    const body = document.getElementsByClassName('ag-body-container');
    const list = body[0].children;
    Array.from(list).forEach(element => {
      this.renderer.setElementClass(element, 'c2c-grid-row-read-only', true);
    });
  }

  public onClickWorkWeekStartDate(params) {
    this.editedRowIndex = this.projectDetailService.editedRowIndex;
    this.rowValidated = true;
    const rowIndex = params.node.rowIndex;
    this.workWeekDataBeforeValidation = this.workWeekData.map(e => ({ ... e }));
    //removing check with edited rowindex
    if (params.colDef.cellRendererParams.enableRowEditing) {
      this.disableOrEnableGridRows(rowIndex, true);
      params.api.setFocusedCell(rowIndex, 'startDate');
      params.api.startEditingCell({
        rowIndex: rowIndex,
        colKey: 'startDate'
      });
      this.editedRowIndex = rowIndex;
      this.projectDetailService.editedRowIndex = this.editedRowIndex;
      this.addClicked = true;
      this.workWeekEventService.isAddOrEditRowInProgress = true;
    }
  }

  public onClickAdd(api) {
    if (!this.addClicked) {
      api.setFilterModel(null);
      this.rowValidated = false;
      this.disableAllGridRows();
      this.selectedId = undefined;
      const newItem = this.createNewRowData();
      api.updateRowData({ add: [newItem], addIndex: 0 });
      api.setFocusedCell(0, 'startDate');
      api.startEditingCell({
        rowIndex: 0,
        colKey: 'startDate'
      });
      this.addClicked = true;
      this.workWeekEventService.isAddOrEditRowInProgress = true;
    }
  }

  public createNewRowData(): any {
    const newData = {
      'startDate': '', // give current date
      'finishDate': '',
      'days': ''
    };
    return newData;
  }

  public gridready(params) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
    // commenting bellow line to fix FC-3420
  //  this.gridApi.setRowData(this.workWeekData);
    this.columnApi.getColumn('startDate').setSort('asc');
  }

  public deleteWorkWeekRecords(row) {
    this.addClicked = false;
    this.cancelSaveClicked = false;
    this.disableOrEnableGridRows(row.rowIndex, false);
    this.workWeekEventService.isAddOrEditRowInProgress = false;
    row.gridApi.showLoadingOverlay();
    // row.gridApi.updateRowData({ remove: [row.data] });//commenting as any error occurs during edit in backend record should not get deleted from UI
    this.projectDetailService.editedRowIndex = '';
    this.gridApi.columnController.gridColumns.forEach(element => {
      if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
        element.colDef.cellRendererParams.showValidationBorder = false;
      }
    });
    if (row.data.workPeriodId) {
      this.projectDetailService.deleteWorkWeekRecord(row.data.workPeriodId, this.projectId).subscribe(
        (data) => {
          row.gridApi.hideOverlay();
          row.gridApi.updateRowData({ remove: [row.data] });
          this.rowValidated = false;
          let deletedIndex;
          this.workWeekData.forEach((element, index) => {
            if (element.workPeriodId === row.data.workPeriodId) {
              deletedIndex = index;
            }
          });
          this.workWeekData.splice(deletedIndex, 1);
          this.setTotalWorkDays();
          // this.gridApi.setRowData(this.workWeekData);commenting as delete with filter should return filtered records alone
          this.workWeekDataBeforeValidation = null;
        },
        (error) => { this.toasterService.error('Error when deleting work week row', error); }
      );
    }else{
      row.gridApi.updateRowData({ remove: [row.data] });
      row.gridApi.hideOverlay();
    }
  }

  /**
   * sets total work days
   *
   */
  public setTotalWorkDays() {
    let totalWorkDays = 0;
    if (this.workWeekData) {
      this.workWeekData.forEach(element => {
        totalWorkDays = totalWorkDays + element.days;
        this.totalWorkDays = totalWorkDays;
      });
    }
    this.totalWorkDays = totalWorkDays;
  }

  public cancelSaveWorkWeekRecords(row) {
    this.cancelSaveClicked = true;
    this.rowValidated = false;
    this.addClicked = false;
    this.disableOrEnableGridRows(row.rowIndex, false);
    this.workWeekEventService.isAddOrEditRowInProgress = false;
    this.gridApi.columnController.gridColumns.forEach(element => {
      if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
        element.colDef.cellRendererParams.showValidationBorder = false;
      }
    });
    if(this.workWeekDataBeforeValidation){
      this.workWeekData = this.workWeekDataBeforeValidation;
    }
    if (row.data.workPeriodId) {
      row.gridApi.stopEditing(true);
      this.workWeekDataBeforeValidation = null;
      this.projectDetailService.editedRowIndex = '';
    } else {
      row.gridApi.updateRowData({ remove: [row.data] });
      this.workWeekDataBeforeValidation = null;
      this.projectDetailService.editedRowIndex = '';
    }
  }

  public onRowEditingStopped(params) {
    if (this.cellEditingError.length > 0) {
      this.rowValidated = false;
      this.saveClicked = false;
      params.api.redrawRows();
      this.disableOrEnableGridRows(this.cellEditingError[0].rowIndex, true);
      params.api.setFocusedCell(this.cellEditingError[0].rowIndex, this.cellEditingError[1].column);
      params.api.startEditingCell({
        rowIndex: this.cellEditingError[0].rowIndex,
        colKey: 'days'
      });
    } else{
      if (!this.cancelSaveClicked) {
      // this.callSaveAPI(params)
      this.rowValidated = true;
      }
      
      if(this.saveClicked && this.rowValidated){
        this.callSaveAPI(params);
      }else{
        this.saveClicked = false;
      }
    }
    this.cellEditingError = [];
  }

  public callSaveAPI(row) {
    if (!this.workWeekEventService.isAddOrEditRowInProgress) {
      row.api.showLoadingOverlay();
      const reqObj = this.createReqForSave(row);

      this.projectDetailService.editedRowIndex = '';
      this.projectDetailService.saveWorkWeek(reqObj, row.data.dealId, this.projectId).subscribe(
        (data) => {
          this.rowValidated = false;
          this.saveClicked = false;
          row.api.hideOverlay();
          const returnData = this.createDataForGrid(data);
          const totalWorkDays = 0;

          data.workWeekDays = returnData.workWeekDays;
          data.days = returnData.days;

          this.selectedId = data.workPeriodId;
          if (!reqObj.workPeriodId) {
            row.data.workPeriodId = data.workPeriodId;
            this.workWeekData.splice(0, 0, data);
          }

          this.setTotalWorkDays();

          const model = row.api.getFilterModel();
          const sortModel = row.api.getSortModel();
          row.api.setFilterModel(model);
          row.api.setSortModel(sortModel);
          row.api.redrawRows();
          // this.gridApi.setRowData(this.workWeekData);commenting as delete with filter should return filtered records alone
          this.gridApi.columnController.gridColumns.forEach(element => {
            if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
              element.colDef.cellRendererParams.showValidationBorder = false;
            }
          });
          this.workWeekDataBeforeValidation = null;
        },
        (error) => { this.toasterService.error('Error when saving work week', error); }
      );
    }
  }

  public saveWorkWeekRecords(row) {
    this.cancelSaveClicked = false;
    this.addClicked = false;
    this.saveClicked = true
    this.disableOrEnableGridRows(row.rowIndex, false);
    this.workWeekEventService.isAddOrEditRowInProgress = false;
    this.gridApi.columnController.gridColumns.forEach(element => {
      if (element.colDef.cellRendererParams && element.colDef.cellRendererParams.showValidationBorder) {
        element.colDef.cellRendererParams.showValidationBorder = false;
      }
    });
    row.gridApi.stopEditing();
    // if (this.rowValidated) {
    //   this.callSaveAPI(row);
    // }
  }

  public createReqForSave(row) {
    const rowData = { ...row.data };
    const projectId = this.projectId;

    rowData.projectId = projectId;
    rowData.workPeriodId = rowData.workPeriodId ? rowData.workPeriodId : null;
    rowData.workPeriodDetails = [];
    // if(!rowData.workPeriodDetails){
    //   rowData.workPeriodDetails = [];
    // }

    rowData.startDate = this.convertDateToFormat(rowData.startDate);
    rowData.finishDate = this.convertDateToFormat(rowData.finishDate);

    rowData.workWeekDays.forEach((element, index) => {
      if (!(element.isDaySelected)) {//removed comdition for weekend
        const formattedOffDay = this.convertDateToFormat(element.dates);
        rowData.workPeriodDetails.push({
          'offDay': formattedOffDay,
          'workPeriodDetailId': element.workPeriodDetailId ? element.workPeriodDetailId : 0
        });
      }
    });

    delete rowData['workWeekDays'];

    return rowData;
  }

  public cellValueChanged(params) {
    const selectedRowIndex = params.selectedRowIndex;

    if (params.selectedColumn === 'startDate') {
      if (params.newValue === '') {
        this.cellEditingError.push({
          column: 'startDate',
          rowIndex: selectedRowIndex
        });
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else if (!this.performDateValidation(params.newRowData)) {
        this.cellEditingError.push({
          column: 'startDate',
          rowIndex: selectedRowIndex
        });
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else {
        params.cellParams.colDef.cellRendererParams.showValidationBorder = false;
      }
    }

    if (params.selectedColumn === 'finishDate') {
      if (params.newValue === '') {
        this.cellEditingError.push({
          column: 'finishDate',
          rowIndex: selectedRowIndex
        });
        if (!params.cellParams.colDef.cellRendererParams) {
          params.cellParams.colDef.cellRendererParams = {};
        }
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else if (!this.performDateValidation(params.newRowData)) {
        this.cellEditingError.push({
          column: 'finishDate',
          rowIndex: selectedRowIndex
        });
        if (!params.cellParams.colDef.cellRendererParams) {
          params.cellParams.colDef.cellRendererParams = {};
        }
        params.cellParams.colDef.cellRendererParams.showValidationBorder = true;
      } else {
        if (!params.cellParams.colDef.cellRendererParams) {
          params.cellParams.colDef.cellRendererParams = {};
        }
        params.cellParams.colDef.cellRendererParams.showValidationBorder = false;
      }
    }

    if(this.cellEditingError.length === 0){
      this.rowValidated = true;
    }

  }

  /**
   * validates whether start date is before finish date or not
   *
   */
  public performDateValidation(newRowData) {
    // if(newRowData.startDate !== '' && newRowData.finishDate !== ''){
    const startDate = this.convertDateToFormat(newRowData.startDate);
    const finishDate = this.convertDateToFormat(newRowData.finishDate);
    if (Date.parse(startDate) <= Date.parse(finishDate)) {
      return true;
    } else {
      return false;
    }
    // }else{
    //   return true;
    // }
  }

  /**
   * converts the given date to 'YYYY-MM-DD'
   *
   */
  public convertDateToFormat(date) {
    if (date.indexOf('/') > -1) {
      const dateVal = date.split('/');
      return [dateVal[2], dateVal[0], dateVal[1]].join('-');
    } else {
      return date;
    }
  }

  public ngOnDestroy(): void {
    this.saveRowSubscription && this.saveRowSubscription.unsubscribe();
    this.cancelSaveRowSubscription && this.cancelSaveRowSubscription.unsubscribe();
    this.deleteRowSubscription && this.deleteRowSubscription.unsubscribe();
  }

  public createPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.workWeekViewPermission) === true && this.userPermissionService.hasPermission(this.workWeekAddPermission) === false) {
      return false;
    } else if (this.userPermissionService.hasPermission(this.workWeekViewPermission) === true && this.userPermissionService.hasPermission(this.workWeekAddPermission) === true) {
      return true;
    }
  }


  public editPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.workWeekViewPermission) === true && this.userPermissionService.hasPermission(this.workWeekEditPermission) === false) {
      return true;
    } else if (this.userPermissionService.hasPermission(this.workWeekViewPermission) === true && this.userPermissionService.hasPermission(this.workWeekEditPermission) === true) {
      return false;
    }
  }

}
