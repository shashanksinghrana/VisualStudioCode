import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { DropdownModel, AddButtonModel, TypeAheadDisplayResultModel, UnsavedChangesService, ToasterService, RadioButtonModel, ModalDeleteConfirmationComponent, ModalApplicableNotApplicableComponent, TypeAheadSaveModel, AddAliasModel, AddAliasAKAModel, EmptyIfNull, TypeAheadModel } from 'c2c-common-lib';
import { SharedService } from '../../services/http/shared/shared.service';
import { ModalGenericComponent } from 'c2c-common-lib';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { ToastsManager } from 'ng2-toastr';
import { DealService } from '../../services/http/deal/deal.service';
import { DealModel } from '../../models/deal/deal.model';
import { DealEventService } from '../../services/events/deal-event.service';
import { NoticesPaymentsModel } from '../../models/deal/notices-payments.model';
import { NoticesPaymentsService } from '../../services/http/deal/notices-payments.service';
import { LoanoutModel } from '../../models/deal/loanout.model';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { AccentedCharacterService } from '../../services/http/shared/accented-character.service';

/**
 * The NoticesPaymentsComponent.
 *
 * This component is used to add notices and payments for a new or existing performer.
 */
@Component({
  selector: 'fc-notices-payments',
  templateUrl: './notices-payments.component.html',
  styleUrls: ['./notices-payments.component.scss']
})
export class NoticesPaymentsComponent implements OnInit {
  public addButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add');
  public addNewContactRecord: boolean = false;
  public addNewRepRecord: boolean = false;
  public addRepForm: FormGroup;
  public contactInfoOptions: DropdownModel = new DropdownModel('', '', '', '', []);
  public deal: DealModel;
  public deleteIndex: any;
  public directContactDetails: any;
  public displayCompanyDataResults: TypeAheadDisplayResultModel;
  public displayRepNameDataResults: TypeAheadDisplayResultModel;
  public loanout: LoanoutModel;
  public noticesAndPaymentsForm: FormGroup;
  public performer: any = '';
  public radioOptions: RadioButtonModel;
  public representators: any;
  public repTypeOptions: DropdownModel = new DropdownModel('', '', '', '', []);
  public showDirectContact: boolean = true;
  public allRepsDeleted: boolean = false;
  public allContactsDeleted: boolean = false;
  public contractAddressChanged: boolean = false;
  public primaryRepChanged: boolean = false;
  public contractAddressForContactInfoChanged: boolean = false;
  public noPhoneNumberForContactInfoChanged: boolean = false;
  public type: string;
  public status: string;
  public skipUnsavedModalEvent: boolean = false;
  public repArray: any = [];
  public viewPermission: PermissionList = PermissionList.dealCreateEditView
  public editPermission: PermissionList = PermissionList.dealCreateEditEdit
  public disableForm: boolean = false;
  public isEdited: boolean = false;
  public typeAheadTitle: string = 'REP NAME';
  public typeAheadType: string = 'PERSON';
  public accentedCharValues: any;
  public setAccentedModalChars: any;
  public typeAheadTitleComp: string = 'COMPANY';
  public isCompanyModalOpen: boolean = false;
  public directContactValue: any;

  @ViewChild('saveAndContinue') public saveAndContinue: any;
  @ViewChild('addNameCompanyModal') public addNameCompanyModal: any;
  @ViewChild('addRepModal') public addRepModal: any;
  @ViewChild('accentedChars') private accentedChars: any;
  @ViewChild('accentedCompModal') private accentedCompModal: any;
  @ViewChild('repNameTypeAhead') repNameTypeAhead: any;
  @ViewChild('companyTypeAhead') companyTypeAhead: any;
  @ViewChild('repType') public repType: any;

  public typeAheadModalConfigHeader: any = {
    title: 'Add New Rep name',
    label: 'This is a label',
    showAddAlias: true,
    displayNameAs: true,
    additionalFieldsDisplayed: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'modalTalentHeaderName'
  };
  public typeAheadModalConfig: object = this.typeAheadModalConfigHeader;

  public typeAheadCompanyModalConfigHeader: any = {
    title: 'Add New Company name',
    label: 'This is a label',
    showAddAlias: true,
    displayNameAs: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'modalCompanyHeaderName'
  };
  public typeAheadCompanyModalConfig: object = this.typeAheadCompanyModalConfigHeader;
  public accentedRepModalName = 'talentAccentedModalRep';
  public accentedComModalName = 'talentAccentedModalComp';
  public displayProdCompanyData: TypeAheadDisplayResultModel;
  public repEdited: boolean = false;
  public directContactEdited: boolean = false;

  @ViewChild('applicableNotApplicableModal') public applicableNotApplicableModal: ModalApplicableNotApplicableComponent;
  @ViewChild('deleteModal') public deleteModal: ModalDeleteConfirmationComponent;
  @ViewChild('genericModal') public genericModal: ModalGenericComponent;
  @ViewChild('addEditPerson') public addEditPerson: any;
  @ViewChild('addEditCompany') public addEditCompany: any;
  /**
   * Constructor for the NoticesPaymentsComponent
   *
   * @param route The active route.
   * @param sharedService The Shared Service for common services.
   * @param dealService The Create Deal Service for deal related services.
   * @param noticesPaymentsService The Notices Payments Service for the Notices and payments related services.
   * @param dealEventService The Deal Event Sevice for routing after Save/Save & Continue
   * @param fb FormBuilder instance for building form elements.
   * @param toasterService The common Toaster Service for calling toast messages.
   * @param toaster ToastManager instance for handling the currenct view container.
   * @param vcr A reference of the current view container.
   */
  constructor(
    private route: ActivatedRoute,
    private sharedService: SharedService,
    private dealService: DealService,
    private noticesPaymentsService: NoticesPaymentsService,
    private dealEventService: DealEventService,
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private unsavedChangesService: UnsavedChangesService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private userPermissionService: UserPermissionService,
    private commonModuleService: CommonModuleService,
    public accentdCharService: AccentedCharacterService
  ) {
    this.disableForm = this.createEditPermission();
    this.toaster.setRootViewContainerRef(vcr);
    this.repTypeOptions = this.getGenericLookupDropdown('REP_TYPE');
  }

  /**
   * Sets up local variables.
   */
  public ngOnInit(): void {
    this.deal = this.dealService.deal;
    this.loanout = this.dealService.loanout;
    this.performer = this.deal.performer.typeAheadDisplayName;
    this.noticesAndPaymentsForm = this.fb.group({
      'repSet': this.fb.array([]),
      'contactInfoDropdown': this.fb.control(null),
      'isContractAddressForContactInfo': this.fb.control(true),
      'isNoPhoneNumber': this.fb.control(true),
      'contactInfoAddress': this.fb.control(null),
      'contactInfoPhone': this.fb.control(null),
      'contactInfoFax': this.fb.control(null),
      'contactInfoEMail': this.fb.control({ value: null, disabled: true }),
      'isContractNumberHome': this.fb.control(5),
      'isContractNumberFax': this.fb.control(true)
    });

    this.addRepForm = this.fb.group({
      'repName': this.fb.control(null, Validators.required),
      'repType': this.fb.control(null),
      'company': this.fb.control(null),
      'isContractAddress': this.fb.control(true),
      'isPrimaryRep': this.fb.control(true),
      'repAddress': this.fb.control(null),
      'repPhone': this.fb.control(null),
      'repFax': this.fb.control(null),
      'repEMail': this.fb.control(null)
    });

    this.displayRepNameDataResults = this.sharedService.displayRepNamesData;
    this.displayCompanyDataResults = this.sharedService.displayCompanyMetadataResults;

    if (this.deal.id) {
      this.getNoticesPaymentSData();
    }
  }

  /**
   * Method to get dropdown value 
   *
   * @param lookup type of dropdown
   */
  public getGenericLookupDropdown(lookup): DropdownModel {
    let options: any[] = [];
    let dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.sharedService.getGenericLookupDropdown(lookup).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          options.push({
            value: data[i].value,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
      }
    );
    return dropdownModel;
  }

  /**
   * Method to get dropdown value for Contact Info 
   *
   * @param data The value from response
   */
  public getContactInfoDropdownOptions(data) {
    let options: any[] = [];
    let dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    for (let i = 0; i < Object.keys(data).length; i++) {
      options.push({
        value: data[i].addressType,
        route: '',
        id: data[i].addressId,
        data: data[i]
      });
    }
    return dropdownModel;
  }

  /**
   * Return Address based on drop down value selected
   *
   * @param id AddressId
   */
  public getAddressIdBasedOnDropdown(id): any {
    let address = '';

    this.directContactDetails.address.forEach((item, index) => {
      if (item.addressId === id) {
        address = item;
      }
    });
    return address;
  }

  /**
   * Format Address based on the response
   *
   * @param item The value from response
   */
  public getAddress(item): any {
    let address = '';
    if (item.firstLine) {
      address = item.firstLine + ' ';
    }
    if (item.secondLine) {
      address = address + item.secondLine + ' ';
    }
    if (item.thirdLine) {
      address = address + item.thirdLine + ' ';
    }
    if (item.city) {
      address = address + item.city + ' ';
    }
    if (item.state) {
      address = address + item.state + ' ';
    }
    if (item.zip) {
      address = address + item.zip + ' ';
    }
    if (item.country) {
      address = address + item.country + ' ';
    }
    return address;
  }

  /**
    * Get all the data related to notices and payments data and assigns it to component properties.
    */
  public getNoticesPaymentSData(): void {
    this.route.data.subscribe(
      (data: { noticesPayments: NoticesPaymentsModel }) => {
        this.setData(data);
      },
      (error) => {
        console.log('Error when getting notices and payments details', error);
      }
    );
  }

  public setData(data) {
    this.representators = data.noticesPayments ? data.noticesPayments.representators : data.representators;
    this.directContactDetails = data.noticesPayments ? data.noticesPayments.directContact : data.directContact;
    const noticesAndPaymentsForm = <FormGroup>this.noticesAndPaymentsForm;
    if (this.directContactDetails.address.length) {
      // if (!this.directContactDetails.details.directContactId) {
      //   this.directContactDetails.details.directContactId = this.directContactDetails.address[0] ? this.directContactDetails.address[0].addressId : null;
      // }
      this.contactInfoOptions = this.getContactInfoDropdownOptions(this.directContactDetails.address);
    }
    let contactArray = this.getContactDetailsFromData(this.directContactDetails.contactInfo);
    let directContactId = this.directContactDetails.details.directContactId;
    let addressId = null;
    if (directContactId) {
      addressId = this.getAddressIdforDirectContact(this.noticesAndPaymentsForm.controls.contactInfoDropdown.value);
    }

    const addressObj = this.getAddressIdBasedOnDropdown(addressId);
    let address = this.getAddress(addressObj);
    this.noticesAndPaymentsForm.patchValue(
      this.fb.group({ 'repSet': this.getRepSet(data.noticesPayments ? data.noticesPayments.representators : data.representators) }),
    );

    if (this.directContactDetails.details.directContactId) {
      this.addNewContactRecord = true;
      this.noticesAndPaymentsForm.patchValue({
        'contactInfoDropdown': { value: addressObj.addressType },
        'isContractAddressForContactInfo': this.directContactDetails.contractAddress,
        'isNoPhoneNumber': this.directContactDetails.phoneOnContract,
        'contactInfoAddress': this.directContactDetails.address ? this.directContactDetails.address[0] : null,
        'contactInfoPhone': contactArray['repPhone'],
        'contactInfoFax': contactArray['repFax'],
        'contactInfoEMail': contactArray['repEMail'],
        'isContractNumberHome': 5,
        'isContractNumberFax': false// replace with the value for phone,fax or null(is no phone number is checked)
      });

      if (this.directContactDetails.contractAddress) {
        this.noticesAndPaymentsForm.get('isContractAddressForContactInfo').patchValue(3);
      }
      if (this.directContactDetails.phoneOnContract) {
        this.noticesAndPaymentsForm.get('isNoPhoneNumber').patchValue(4);
      }
    }
    this.noticesAndPaymentsForm.markAsPristine();
    this.noticesAndPaymentsForm.markAsUntouched();
  }

  /**
   * set values into rep form list
   *
   * @param data The value from response
   */
  public getRepSet(data): FormArray {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    if (repArray.controls.length > 0) {
      repArray.controls = [];
    }
    data.forEach((item, index) => {
      this.addNewRepRecord = true;
      let repAddress = '';
      if (item.address) {
        repAddress = this.getAddress(item.address[0]);
      }
      const contactArray = this.getContactDetailsFromData(item.contactInfo);
      repArray.push(this.fb.group({
        'repName': this.fb.control({ value: item.repName, disabled: true }, Validators.required),
        'repType': this.fb.control({ value: item.details.typeId, disabled: true }),
        'company': this.fb.control({ value: item.companyName, disabled: true }),
        'repAddress': this.fb.control({ value: item.address ? item.address[0] : null, disabled: true }),
        'repPhone': this.fb.control({ value: contactArray['repPhone'], disabled: true }),
        'repFax': this.fb.control({ value: contactArray['repFax'], disabled: true }),
        'repEMail': this.fb.control({ value: contactArray['repEMail'], disabled: true }),
        'isContractAddress': this.fb.control({ value: item.contractAddress }),
        'isPrimaryRep': this.fb.control({ value: item.primaryRep })
      }));
      if (item.contractAddress) {
        repArray.controls[index].get('isContractAddress').patchValue(2);
      }
      if (item.primaryRep) {
        repArray.controls[index].get('isPrimaryRep').patchValue(1);
      }
    });
    this.noticesAndPaymentsForm.get('repSet').markAsPristine();
    this.noticesAndPaymentsForm.get('repSet').markAsUntouched();
    return repArray;
  }

  /**
   * set values into rep type and company fields based on rep name selected
   *
   * @param event fired on selecting from typeahead
   */
  public onChangeRepName(event): void {
    this.noticesPaymentsService.getRepType(event.partyId, this.deal.id).subscribe(
      (data) => {
        this.addRepForm.controls['repType'].setValue(this.getDropdownSelection(this.repTypeOptions, data.detail.typeId, 'id'));
        this.addRepForm.controls['company'].setValue({ 'typeAheadDisplayName': data.companyName, 'partyId': data.detail.compId, 'companyDetails': data.detail });
      }
    );
  }

  /**
  * Populates the dropdown value when populating the form.
  *
  * @param type The DropdownModel to iterate over.
  * @param value The value to set on the dropdown.
  * @param field The field name to compare against.
  */
  public getDropdownSelection(type, value, field): any {
    let selection = value;
    if (type.options) {
      type.options.forEach((val) => {
        if (value === val[field]) {
          selection = val;
        }
      });
    }
    return selection;
  }

  /**
   * get values from primary rep for returning in api request
   *
   * @param value value from form
   */
  public getPrimaryRepValueFromRadio(value): boolean {
    let primaryRep = value;
    if (value === 1) {
      primaryRep = true;
    } else {
      primaryRep = false;
    }
    return primaryRep;
  }

  /**
   * get values from Use For Contract for returning in api request
   *
   * @param value value from form
   */
  public getUseForContractValueFromRadio(value): boolean {
    let useForContractAddress = value;
    if (value === 2) {
      useForContractAddress = true;
    } else {
      useForContractAddress = false;
    }
    return useForContractAddress;
  }

  /**
   * get values from No Phone Number for returning in api request
   *
   * @param value value from form
   */
  public getNoPhoneNumberValueFromRadio(value): boolean {
    let noPhoneNumber = value;
    if (value === 4) {
      noPhoneNumber = true;
    } else {
      noPhoneNumber = false;
    }
    return noPhoneNumber;
  }

  /**
   * get values from Use For Contract for Cotact Info for returning in api request
   *
   * @param value value from form
   */
  public getUseForContractContactInfoValueFromRadio(value): boolean {
    let useForContractAddress = value;
    if (value === 3) {
      useForContractAddress = true;
    } else {
      useForContractAddress = false;
    }
    return useForContractAddress;
  }

  public getDirectContactId() {
    let contactInfoValue = this.noticesAndPaymentsForm.controls['contactInfoDropdown'].value;

    if (contactInfoValue) {
      if (!contactInfoValue.id) {
        contactInfoValue = this.directContactDetails.address[0].addressId;
      } else {
        contactInfoValue = contactInfoValue.id;
      }
    } else {
      contactInfoValue = null;
    }
    return contactInfoValue;
  }

  /**
   * Submits the notices & payments form for saving the credit details.
   */
  public onSubmit(type?: string): void {
    this.skipUnsavedModalEvent = true;
    this.repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    if (<FormArray>this.noticesAndPaymentsForm.value.contactInfoDropdown) {
      this.directContactValue = <FormArray>this.noticesAndPaymentsForm.value.contactInfoDropdown.value;
    }
    if (this.dealService.currentWizardPage.status) {
      if (this.repArray.length === 0 && this.dealService.currentWizardPage.status.name !== 'NOT_APPLICABLE' && this.directContactValue === undefined) {
        this.type = type;
        this.openApplicableNotApplicableModal();
      }
    }
    if (this.repArray.length === 0 && !this.dealService.currentWizardPage.status && this.directContactValue === undefined) {
      this.type = type;
      this.openApplicableNotApplicableModal();
    } else if (this.repArray.length || (this.dealService.currentWizardPage.status && this.dealService.currentWizardPage.status.name === 'NOT_APPLICABLE') || this.allContactsDeleted || this.directContactValue) {
      const reqObj = [];
      this.repArray.controls.forEach((element, index) => {
        const item = <FormGroup>element;
        reqObj.push({
          'representationId': this.representators[index].details.representationId ? this.representators[index].details.representationId : null,
          'dealId': this.deal.id,
          'repId': this.representators[index].details.repId ? this.representators[index].details.repId : null,
          'akaId': this.representators[index].details.akaId ? this.representators[index].details.akaId : null,
          'compAkaId': this.representators[index].details.compAkaId ? this.representators[index].details.compAkaId : null,
          'typeId': this.representators[index].details.typeId ? this.representators[index].details.typeId : null,
          'compId': this.representators[index].details.compId ? this.representators[index].details.compId : null,
          'primaryRep': this.getPrimaryRepValueFromRadio(item.controls['isPrimaryRep'].value),
          'useForContractAdd': this.getUseForContractValueFromRadio(item.controls['isContractAddress'].value),
          'directContactId': this.allContactsDeleted ? null : this.representators[index].details.directContactId,// this.representators[index].details.directContactId ? this.representators[index].details.directContactId : null,
          'repCompRelId': this.representators[index].details.repCompRelId ? this.representators[index].details.repCompRelId : null,
          'repIdVer': this.representators[index].details.repIdVer,
          'compIdVer': this.representators[index].details.compIdVer,
          'repUpdated':this.representators[index].details.repIdVer ? false: true

        });
      });
      if (this.directContactDetails.address.length !== 0) {
        reqObj.push({
          'representationId': this.directContactDetails.details.representationId ? this.directContactDetails.details.representationId : null,
          'dealId': this.deal.id,
          'repId': this.directContactDetails.details ? this.directContactDetails.details.repId : null,
          'akaId': this.directContactDetails.details.akaId ? this.directContactDetails.details.akaId : null,
          'compAkaId': this.directContactDetails.details.compAkaId ? this.directContactDetails.details.compAkaId : null,
          'typeId': this.directContactDetails.details.typeId ? this.directContactDetails.details.typeId : null,
          'compId': this.directContactDetails.details.compId ? this.directContactDetails.details.compId : null,
          'primaryRep': this.getNoPhoneNumberValueFromRadio(this.noticesAndPaymentsForm.controls['isNoPhoneNumber'].value),
          'useForContractAdd': this.getUseForContractContactInfoValueFromRadio(this.noticesAndPaymentsForm.controls['isContractAddressForContactInfo'].value),
          'directContactId': this.getDirectContactId(),
          'repCompRelId': this.directContactDetails.details.repCompRelId ? this.directContactDetails.details.repCompRelId : null,
          'repIdVer': this.directContactDetails.details.repIdVer,
          'compIdVer': this.directContactDetails.details.compIdVer,
          'repUpdated':this.directContactDetails.details.repIdVer ? false: true
        });
      }

      if (!this.noticesAndPaymentsForm.invalid) {
        this.addRepForm.markAsPristine();
        this.addRepForm.markAsUntouched();
        this.contractAddressChanged = false;
        this.primaryRepChanged = false;
        this.contractAddressForContactInfoChanged = false;
        this.noPhoneNumberForContactInfoChanged = false;
        if (this.repArray.length || this.directContactValue || this.dealService.currentWizardPage.status.name === 'NOT_APPLICABLE') {
          this.saveNoticesAndPayments(type, reqObj);
        } else if (this.allRepsDeleted || this.allContactsDeleted) {
          this.noticesPaymentsService.saveNoticesAndPayments(reqObj, this.deal.id).subscribe(
            res => {
              this.contractAddressChanged = false;
              this.primaryRepChanged = false;
              this.contractAddressForContactInfoChanged = false;
              this.noPhoneNumberForContactInfoChanged = false;
              this.noticesAndPaymentsForm.markAsPristine();
              this.noticesAndPaymentsForm.markAsUntouched();
            }, err => {
              this.toasterService.error('Failed to save Notices and Payments Details.', 'Error');
              console.error('There was an error', err);
            }
          );
        }
        else {
          this.noticesAndPaymentsForm.markAsPristine();
          this.noticesAndPaymentsForm.markAsUntouched();
          this.dealEventService.pageSavedEvent({ type: type, pageTo: 'compensation', dealId: this.deal.id, status: this.status });
        }
      } else {
        this.validateFormFields(this.noticesAndPaymentsForm);
      }
    }
  }

  /**
   * API call for save
   */
  public saveNoticesAndPayments(type, reqObj) {
    const dealId: string = this.dealService.getDealId();
    this.noticesPaymentsService.saveNoticesAndPayments(reqObj, this.deal.id).subscribe(
      res => {
        this.contractAddressChanged = false;
        this.primaryRepChanged = false;
        this.contractAddressForContactInfoChanged = false;
        this.noPhoneNumberForContactInfoChanged = false;
        this.noticesAndPaymentsForm.markAsPristine();
        this.noticesAndPaymentsForm.markAsUntouched();
        if (type) {
          this.dealEventService.pageSavedEvent({ type: type, pageTo: 'compensation', dealId: res[0] ? res[0].dealId : dealId, status: (!this.repArray.length && this.dealService.currentWizardPage.status) ? this.dealService.currentWizardPage.status.name : 'COMPLETE' });
        } else {
          this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: res[0] ? res[0].dealId : dealId, status: (!this.repArray.length && this.dealService.currentWizardPage.status) ? this.dealService.currentWizardPage.status.name : 'COMPLETE' });
        }
      }, err => {
        this.toasterService.error('Failed to save Notices and Payments Details.', 'Error');
        console.error('There was an error', err);
      }
    );
  }

  /**
  * Validates Rep record to prevent Duplicate entry
  * parameter combination of Rep Name, Rep Type and Company is compared
  */
  public validateRepRecord(dataFromResponse): boolean {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    const repArrayVal = repArray.getRawValue();
    let flag = true;
    const newObj = {
      'repName': dataFromResponse.repName,
      'repType': dataFromResponse.repType ? dataFromResponse.repType : '',
      'company': dataFromResponse.companyName
    };

    repArrayVal.forEach((item, index) => {
      const existingObj = {
        'repName': item.repName,
        'repType': item.repType ? item.repType.value : '',
        'company': item.company
      };
      if (JSON.stringify(newObj).toLowerCase() === JSON.stringify(existingObj).toLowerCase()) {
        flag = false;
        return flag;
      }
    });
    return flag;
  }

  /**
  * returns index if rep name already exists in form list
  * parameter combination of Rep Name, Rep Type and Company is compared
  */
  public validateDuplicateRepName(dataFromResponse): number {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    const repIndex = repArray.controls.findIndex(rep => (rep.get('repName').value.toLowerCase() === dataFromResponse.repName.toLowerCase()));

    return repIndex;
  }

  public validateAliasForRepName(repName){
    const repIndex = this.representators.findIndex(rep => (rep.details.repId === (repName.partyId ? repName.partyId : repName.details.repId)));
    return repIndex;
  }

  /**
   * Adds another line of values to the Representative set based on the dropdowns
   * selected for Rep Name, Rep Type and Company. Line is added by getting
   * and setting these values to the notices-payments model.
   */
  public addLine(data, reqObj): void {
    const repIndex = this.validateDuplicateRepName(data);
    const aliasIndex = this.validateAliasForRepName(data);
    // if (this.validateRepRecord(data)) {
      this.addNewRepRecord = true;
      let repAddress = '';
      const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
      if (repIndex !== -1) {
        repArray.controls.splice(repIndex, 1);
      }else if (aliasIndex !== -1) {
        repArray.controls.splice(aliasIndex, 1);
      }

      if (data.address) {
        repAddress = this.getAddress(data.address[0]);
      }
      const contactArray = this.getContactDetailsFromData(data.contactInfo);

      repArray.push(this.fb.group({
        'repName': this.fb.control({ value: data.repName, disabled: true }),
        'repType': this.fb.control({ value: this.getDropdownSelection(this.repTypeOptions, reqObj.typeId, 'id'), disabled: true }),
        'company': this.fb.control({ value: data.companyName, disabled: true }),
        'repAddress': this.fb.control({ value: (data.address ? data.address[0] : null), disabled: true }),
        'repPhone': this.fb.control({ value: contactArray['repPhone'], disabled: true }),
        'repFax': this.fb.control({ value: contactArray['repFax'], disabled: true }),
        'repEMail': this.fb.control({ value: contactArray['repEMail'], disabled: true }),
        'isContractAddress': this.fb.control({ value: data.contractAddress }),
        'isPrimaryRep': this.fb.control({ value: data.primaryRep }),
      }));
      if (data.contractAddress) {
        repArray.controls[repArray.length].get('isContractAddress').patchValue(2);
        this.updateIsContractAddress(repArray.controls.length - 1);
      }
      if (data.primaryRep) {
        repArray.controls[repArray.length].get('isPrimaryRep').patchValue(1);
        this.updateIsPrimaryRep(repArray.controls.length - 1);
      }
      let dataIndex;
      let dataExists = this.representators.some(function (el, index) {
        dataIndex = index;
        return el.repName === data.repName;
      });
      if(dataExists){
        this.representators[dataIndex] = data;
      }else if(aliasIndex > -1){
        this.representators[aliasIndex] = data;
      }else{
      this.representators.push(data);
      }

      this.addRepForm.reset();
      this.addRepForm.markAsUntouched();
    // }
  }

  /**
   * returns contact numbers for display
   *
   * @param data value from response
   */
  public getContactDetailsFromData(data): any {
    const contactArray = {
      'repAddress': '',
      'repEMail': '',
      'repPhone': '',
      'repFax': ''
    };
    if (data.length) {
      data.forEach(element => {
        if (element.type === 'Work') {
          contactArray['repEMail'] = element.value;
        } else if (element.type === 'Work 1' || element.type === 'Office') {
          contactArray['repPhone'] = this.formatPhoneNumber(element.value);
        } else if (element.type === 'Work Fax') {
          contactArray['repFax'] = element.value;
        }

      });
    }
    return contactArray;
  }


  public formatPhoneNumber(phoneNumber) {
    let formattedNumber = '';
    if (phoneNumber) {
      phoneNumber = phoneNumber.replace(/ +/g, '');
    const length = phoneNumber.length;
    if (phoneNumber.indexOf('-') > -1) {
      phoneNumber = phoneNumber.split('-').join('');
    }

    if (phoneNumber.indexOf('(') > -1) {
      phoneNumber = phoneNumber.split('(').join('');
    }

    if (phoneNumber.indexOf(')') > -1) {
      phoneNumber = phoneNumber.split(')').join('');
    }

    formattedNumber = '(' + phoneNumber.slice(0, 3) + ')-' + phoneNumber.slice(3, 6) + '-' + phoneNumber.slice(6, length);

    }
    return formattedNumber;
  }

  /**
  * Updates the Primary Rep for the representative set when the 'Is Primary Rep'
  * radio button changes to another record.
  *
  * @param index The index of the new 'Is Primary Rep' radio button set.
  */
  public updateIsPrimaryRep(index?: number): void {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    const rep = <FormGroup>repArray.controls[index];
    this.primaryRepChanged = true;
    const repTypeFromUser = rep.controls['repType'].value ? (rep.controls['repType'].value.value.toLowerCase()) : null;

    if (repArray.controls[index].get('isPrimaryRep').value !== 1) {
      repArray.controls.forEach((element, i) => {
        if (i !== index && ((element.get('repType').value ? element.get('repType').value.value.toLowerCase() : null) === repTypeFromUser)) {
          element.get('isPrimaryRep').patchValue(null);
        } else if (i === index) {
          element.get('isPrimaryRep').patchValue(1);
        }
      });
    } else {
      repArray.controls[index].get('isPrimaryRep').patchValue(1);
    }
  }


  /**
  * Updates the contract address for the representative set when the 'Is Contract Address'
  * radio button changes to another record.
  *
  * @param index The index of the new 'Is Contract Address' radio button set.
  */
  public updateIsContractAddress(index?: number): void {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    this.contractAddressChanged = true;
    let currentContractAddressValue;
    if (repArray.controls[index].get('isContractAddress').value) {
      if (repArray.controls[index].get('isContractAddress').value.value) {
        currentContractAddressValue = repArray.controls[index].get('isContractAddress').value.value;
      } else {
        currentContractAddressValue = repArray.controls[index].get('isContractAddress').value;
      }
    } else {
      currentContractAddressValue = repArray.controls[index].get('isContractAddress').value;
    }

    for (let i = 0; i < repArray.controls.length; i++) {
      if (currentContractAddressValue === 2) {
        if (i !== index) {
          repArray.controls[i].get('isContractAddress').patchValue(null);
          this.noticesAndPaymentsForm.get('isContractAddressForContactInfo').patchValue(null);
        } else {
          repArray.controls[i].get('isContractAddress').patchValue(2);
        }
      } else {
        repArray.controls[i].get('isContractAddress').patchValue(2);
        this.noticesAndPaymentsForm.get('isContractAddressForContactInfo').patchValue(null);
        for (let i = 0; i < repArray.controls.length; i++) {
          if (i !== index) {
            repArray.controls[i].get('isContractAddress').patchValue(null);
          }
        }
      }

    }
  }

  public getAddressIdforDirectContact(dropdownVal) {
    let addressId;
    if (dropdownVal) {
      if (dropdownVal.id) {
        addressId = dropdownVal.id;
      } else {
        addressId = this.directContactDetails.details.directContactId;
      }
    } else {
      addressId = this.directContactDetails.details.directContactId;
    }
    return addressId;
  }

  /**
  * Adds line of values to the Direct Contact based on the dropdowns
  */
  public addLineForContactInfo(data?: any): void {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    let contractAddressVal, isNoPhoneNumberVal, dropdownVal;
    dropdownVal = this.noticesAndPaymentsForm.value['contactInfoDropdown'];
    if (this.noticesAndPaymentsForm.value['contactInfoDropdown']) {
      this.addNewContactRecord = true;

      const addressId = this.getAddressIdforDirectContact(this.noticesAndPaymentsForm.value['contactInfoDropdown']);
      const contactArray = this.getContactDetailsFromData(data ? data.contactInfo : this.directContactDetails.contactInfo);
      let addressObj = this.getAddressIdBasedOnDropdown(addressId);
      if (data) {
        this.directContactEdited = false;
        this.noticesAndPaymentsForm.get('contactInfoDropdown').setValue(dropdownVal);
        contractAddressVal = this.noticesAndPaymentsForm.value['isContractAddressForContactInfo'].value;
        isNoPhoneNumberVal = this.noticesAndPaymentsForm.value['isNoPhoneNumber'].value;
        data.address.forEach(element => {
          if (element.addressId === addressId) {
            addressObj = element;
          }
        });
        this.directContactDetails.address = data.address;
        this.directContactDetails.contactInfo = data.contactInfo;
      }

      const address = this.getAddress(addressObj);
      this.noticesAndPaymentsForm.patchValue({
        'isContractAddressForContactInfo': contractAddressVal ? contractAddressVal : this.directContactDetails.contractAddress,
        'isNoPhoneNumber': isNoPhoneNumberVal ? isNoPhoneNumberVal : false,
        'contactInfoAddress': addressObj,
        'contactInfoPhone': contactArray['repPhone'],
        'contactInfoFax': contactArray['repFax'],
        'contactInfoEMail': contactArray['repEMail'],
        'isContractNumberHome': 5,//contactArray['repPhone'],
        'isContractNumberFax': false// replace with the value for phone,fax or null(is no phone number is checked)
      });

      this.radioOptions = new RadioButtonModel('Contract', [
        { title: 'Home 1 ' + this.noticesAndPaymentsForm.value['contactInfoPhone'], checkedByDefault: true, disabled: false, showTitle: true },
        { title: 'Fax    ' + this.noticesAndPaymentsForm.value['contactInfoFax'], checkedByDefault: false, disabled: false, showTitle: true }
      ]);
      if (contractAddressVal ? contractAddressVal : this.directContactDetails.contractAddress) {
        this.noticesAndPaymentsForm.get('isContractAddressForContactInfo').patchValue(3);
      }
      if (isNoPhoneNumberVal ? isNoPhoneNumberVal : this.directContactDetails.isNoPhoneNumber) {
        this.noticesAndPaymentsForm.get('isNoPhoneNumber').patchValue(4);
      }
      this.noticesAndPaymentsForm.markAsUntouched();
    }
  }

  /**
    * Change event for Is Contract Address for Contact Info Radio
    */
  public onChangeIsContractAddressForContactInfo(event, index): void {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    this.contractAddressForContactInfoChanged = true;
    if (this.noticesAndPaymentsForm.get('isContractAddressForContactInfo').value === 3) {
      // if(index != 0){
      // this.noticesAndPaymentsForm.get('isContractAddressForContactInfo').patchValue(null);no unselection needed
      // }
    } else {
      this.noticesAndPaymentsForm.get('isContractAddressForContactInfo').patchValue(3);
      for (let i = 0; i < repArray.controls.length; i++) {
        repArray.controls[i].get('isContractAddress').patchValue(null);
      }
    }
  }

  /**
   * Change event for Is No Phone Number Radio
   */
  public onChangeIsNoPhoneNumber(event, index): void {
    this.noPhoneNumberForContactInfoChanged = true;
    if (this.noticesAndPaymentsForm.get('isNoPhoneNumber').value === 4) {
      // this.noticesAndPaymentsForm.get('isNoPhoneNumber').patchValue(null);//no unselection needed
    } else {
      this.noticesAndPaymentsForm.get('isNoPhoneNumber').patchValue(4);
      this.noticesAndPaymentsForm.get('isContractNumberHome').patchValue(null);
      this.noticesAndPaymentsForm.get('isContractNumberFax').patchValue(null);
    }
  }

  /**
   * Determines if the form has any unsaved changes, if so, transition message
   * will be displayed. If user confirms, routing continues to navigate.
   */
  public canDeactivate(): Observable<boolean> | boolean {
    if ((this.noticesAndPaymentsForm.dirty && this.noticesAndPaymentsForm.touched && !this.skipUnsavedModalEvent) ||
      (this.addRepForm.dirty && this.addRepForm.touched && !this.skipUnsavedModalEvent)
      || this.contractAddressChanged || this.primaryRepChanged || this.contractAddressForContactInfoChanged || this.noPhoneNumberForContactInfoChanged && !this.skipUnsavedModalEvent) {
      this.unsavedChangesService.openModal();
      return this.unsavedChangesService.onCloseModal();
    }
    return true;
  }

  /**
   * API  call for deleting rep
   */
  public deleteRep(index): void {
    this.noticesPaymentsService.deleteRepresentative(this.deal.id, this.representators[this.deleteIndex].details.repId).subscribe(
      () => {
        this.removeLineItem(this.deleteIndex);
      }
    );
    let element = document.getElementById('deleteRepButton'+(index+1));
    if (element) {
      let span = <HTMLElement>element.children[0];
      setTimeout(() => { span.focus() }, 1000);
    }
  }

  /**
   * Removes the given line from the rep set when the minus (-) icon is clicked.
   *
   * @param index The position in the array of the row to be removed.
   */
  public removeLineItem(index): void {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    if (repArray.length === 1 && index === 0) {
      this.addNewRepRecord = false;
      this.allRepsDeleted = true;
    }
    this.addRepForm.markAsDirty();
    this.addRepForm.markAsTouched();
    this.representators.splice(index, 1);
    repArray.removeAt(index);
    let element = document.getElementById('deleteRepButton'+(index+1));
    let span = <HTMLElement> element.children[0];
    setTimeout(() => span.focus());
  }

  /**
   * This function is used to begin the process of editing a rep set.//FUTURE IMPLEMENTATION
   *
   * @param formGroup The FormGroup to edit.
   */
  public enableRepSetEdit(formGroup): void {
    formGroup.currentState = { ...formGroup };
    formGroup.enable();
  }

  /**
   * This function is run for disabling the ability to edit a rep set.//FUTURE IMPLEMENTATION
   *
   * @param formGroup The FormGroup to disable.
   */
  public disableRepSetEdit(formGroup): void {
    formGroup.reset(formGroup.currentState.value);
    Object.keys(formGroup.controls).forEach((field) => {
      formGroup.controls[field].disable();
    });
  }

  /**
   * This function saves the rep set.//FUTURE IMPLEMENTATION
   *
   * @param formGroup The FormGroup to save.
   */
  public saveEditedRepSet(formGroup): void {
    if (formGroup.valid) {
      Object.keys(formGroup.controls).forEach((field) => {
        formGroup.controls[field].disable();
      });
    } else {
      this.validateFormFields(formGroup);
    }
  }

  /**
   * Checks to see if the FormGroup is invalid.
   *
   * @param formGroup The FormGroup to run validation on.
   * @param field The FormControl to check in the given FormGroup.
   */
  public isFormInvalid(formGroup, field): boolean {
    return formGroup.get(field).invalid && formGroup.get(field).touched;
  }


  /**
   * Called when the form is invalid in order to mark the invalid controls.
   *
   * @param formGroup The FormGroup to mark.
   */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  /**
   * Resets (clears) the given FormGroup.
   *
   * @param formGroup The FormGroup to reset.
   */
  public clearForm(formGroup): void {
    formGroup.reset();
    formGroup.markAsUntouched();
  }

  /**
   * Open Add Rep Modal on click of '+' button
   */
  public openAddRepModal(event): void {
    if (this.addRepForm.valid && this.addRepForm.dirty && this.addRepForm.touched) {
      const data = {
        repName: this.addRepForm.value.repName.typeAheadDisplayName,
        repType: this.addRepForm.value.repType ? this.addRepForm.value.repType.value : null,
        companyName: this.addRepForm.value.company ? this.addRepForm.value.company.typeAheadDisplayName : null//as no fields are mandatory when adding rep name alone
      };
      const duplicateRepRecordExists = !this.validateRepRecord(data);//true if duplicate
      // const aliasForRepExists = (this.validateAliasForRepName(this.addRepForm.value.repName) === -1) ? false : true;//true if alis exists
      // const duplicateRepNameExists = (this.validateDuplicateRepName(data) === -1) ? false : true;//true if name exists

      if(duplicateRepRecordExists){
        this.modalClosedEvent('OKAY');
      }else{
        this.genericModal.open();
      }
      // if (!duplicateRepNameExists) {
      //   if (!duplicateRepRecordExists) {
      //     if(!aliasForRepExists){
      //         this.modalClosedEvent('OKAY');
      //     }
      //   }
      // } else {
      //   this.genericModal.open();
      // }
    } else {
      this.validateFormFields(this.addRepForm);
    }
  }

  /**
   * Open Delete Rep Modal on click of '-' button
   */
  public openDeleteRepModal(i): void {
    this.deleteIndex = i;
    this.deleteModal.openModal();
    this.saveAndContinue.setFocus();
  }

  /**
   * Event fired on close of Delete Rep Modal after user input
   */
  public deleteModalClosed(event): void {
    if (event.action === 'OK') {
      if (event.value.toLowerCase() === 'yes') {
        this.deleteRep(this.deleteIndex);
      } else {
        this.removeLineItem(this.deleteIndex);
      }
    }
  }

  public getCompanyAKAId(repDetails) {
    let compAkaId = null;
    if (repDetails.repName.nameId) {
      compAkaId = repDetails.repName.nameId;
    } else {
      if (repDetails.company.companyDetails) {
        compAkaId = repDetails.company.companyDetails.akaId;
      } else {
        compAkaId = repDetails.company.akaId;
      }
    }
    return compAkaId;
  }

  /**
  * Event fired on close of Add Rep Modal after user confirmation
  */
  public modalClosedEvent(event): void {
    const repDetails = this.addRepForm.value;
    if (event === 'OKAY' && this.addRepForm.valid) {
      const reqObj = {
        'representationId': (repDetails.company && repDetails.company.companyDetails) ? repDetails.company.companyDetails.representationId : null,
        'dealId': this.deal.id,
        'repId': repDetails.repName.name ? repDetails.repName.name.nameId : repDetails.repName.partyId, // replace this aliasid
        'companyName': repDetails.company ? repDetails.company.typeAheadDisplayName : null,
        'akaId': repDetails.repName.nameId ? repDetails.repName.nameId : repDetails.repName.akaId,
        'compAkaId': this.getCompanyAKAId(repDetails),//repDetails.company.nameId ? repDetails.company.nameId : repDetails.company.companyDetails.akaId,
        'typeId': repDetails.repType ? repDetails.repType.id : '',
        'compId': repDetails.company ? repDetails.company.partyId : null,
        'primaryRep': (repDetails.company && repDetails.company.companyDetails) ? repDetails.company.companyDetails.primaryRep : repDetails.isPrimaryRep,
        'useForContractAdd': repDetails.isContractAddress,
        'directContactId': (repDetails.company && repDetails.company.companyDetails) ? repDetails.company.companyDetails.directContactId : null,
        'repCompRelId': (repDetails.company && repDetails.company.companyDetails) ? repDetails.company.companyDetails.repCompRelId : null,
        'links': [

        ]
      };

      if (this.addRepForm.valid) {
        this.noticesPaymentsService.addRepresentative(reqObj).subscribe(
          (data) => {
            this.addLine(data, reqObj);
          }
        );
      } else {
        this.validateFormFields(this.addRepForm);
      }
    }
  }

  /**
   * Removes the given line from the contact info set when the minus (-) icon is clicked.
   *
   * @param index The position in the array of the row to be removed.
   */
  public removeLineItemForContactInfo(index): void {
    if (index === 0) {
      this.addNewContactRecord = false;
      this.allContactsDeleted = true;
    }
    this.noticesAndPaymentsForm.patchValue({
      'contactInfoDropdown': '',
      'isContractAddressForContactInfo': false,
      'isNoPhoneNumber': false,
      'contactInfoAddress': '',
      'contactInfoPhone': '',
      'contactInfoFax': '',
      'contactInfoEMail': { value: '', disabled: true },
      'isContractNumberHome': false,
      'isContractNumberFax': false// replace with the value for phone,fax or null(is no phone number is checked)
    });
  }

  /**
   * This function is used to begin the process of editing a contact set.//FUTURE IMPLEMENTATION
   *
   * @param formGroup The FormGroup to edit.
   */
  public enableContactSetEdit(formGroup): void {
    // formGroup.currentState = { ...formGroup };
    // formGroup.enable();//uncomment for editing
  }

  /**
  * Updates the Contract indicator for the Contact when the 'Contract'
  * radio button changes to another record.
  *
  * @param index The index of the new 'Contract' radio button.
  */
  public onContractChangeHome(index?: number): void {
    const contractPhone = this.noticesAndPaymentsForm.value['isContractNumberHome'];
    if (contractPhone !== 5) {
      this.noticesAndPaymentsForm.get('isContractNumberHome').patchValue(5);
      this.noticesAndPaymentsForm.get('isContractNumberFax').patchValue(null);
      this.noticesAndPaymentsForm.get('isNoPhoneNumber').patchValue(null);
    }
  }

  public onContractChangeFax(index?: number): void {
    const contractPhone = this.noticesAndPaymentsForm.value['isContractNumberFax'];
    if (contractPhone !== 6) {
      this.noticesAndPaymentsForm.get('isContractNumberFax').patchValue(6);
      this.noticesAndPaymentsForm.get('isContractNumberHome').patchValue(null);
      this.noticesAndPaymentsForm.get('isNoPhoneNumber').patchValue(null);
    }
  }

  /* Method to open modal popup */
  public openApplicableNotApplicableModal(): void {
    this.applicableNotApplicableModal.openModal();
  }

  public applicableModalClosedEvent(event, type?: string): void {
    if (event === 'OK') {
      const dealId: string = this.dealService.getDealId();
      if (this.allRepsDeleted || this.allContactsDeleted) {
        const reqObj = [];
        this.repArray.controls.forEach((element, index) => {
          const item = <FormGroup>element;
          reqObj.push({
            'representationId': this.representators[index].details.representationId ? this.representators[index].details.representationId : null,
            'dealId': this.deal.id,
            'repId': this.representators[index].details.repId ? this.representators[index].details.repId : null,
            'akaId': this.representators[index].details.akaId ? this.representators[index].details.akaId : null,
            'compAkaId': this.representators[index].details.compAkaId ? this.representators[index].details.compAkaId : null,
            'typeId': this.representators[index].details.typeId ? this.representators[index].details.typeId : null,
            'compId': this.representators[index].details.compId ? this.representators[index].details.compId : null,
            'primaryRep': this.getPrimaryRepValueFromRadio(item.controls['isPrimaryRep'].value),
            'useForContractAdd': this.getUseForContractValueFromRadio(item.controls['isContractAddress'].value),
            'directContactId': this.allContactsDeleted ? null : this.representators[index].details.directContactId,// this.representators[index].details.directContactId ? this.representators[index].details.directContactId : null,
            'repCompRelId': this.representators[index].details.repCompRelId ? this.representators[index].details.repCompRelId : null,
          });
        });
        if (this.directContactDetails.address.length !== 0) {
          reqObj.push({
            'representationId': this.directContactDetails.details.representationId ? this.directContactDetails.details.representationId : null,
            'dealId': this.deal.id,
            'repId': this.directContactDetails.details ? this.directContactDetails.details.repId : null,
            'akaId': this.directContactDetails.details.akaId ? this.directContactDetails.details.akaId : null,
            'compAkaId': this.directContactDetails.details.compAkaId ? this.directContactDetails.details.compAkaId : null,
            'typeId': this.directContactDetails.details.typeId ? this.directContactDetails.details.typeId : null,
            'compId': this.directContactDetails.details.compId ? this.directContactDetails.details.compId : null,
            'primaryRep': this.getNoPhoneNumberValueFromRadio(this.noticesAndPaymentsForm.controls['isNoPhoneNumber'].value),
            'useForContractAdd': this.getUseForContractContactInfoValueFromRadio(this.noticesAndPaymentsForm.controls['isContractAddressForContactInfo'].value),
            'directContactId': this.getDirectContactId(),
            'repCompRelId': this.directContactDetails.details.repCompRelId ? this.directContactDetails.details.repCompRelId : null,
          });
        }
        const dealId: string = this.dealService.getDealId();
        this.noticesPaymentsService.saveNoticesAndPayments(reqObj, this.deal.id).subscribe(
          res => {
            this.contractAddressChanged = false;
            this.primaryRepChanged = false;
            this.contractAddressForContactInfoChanged = false;
            this.noPhoneNumberForContactInfoChanged = false;
            this.noticesAndPaymentsForm.markAsPristine();
            this.noticesAndPaymentsForm.markAsUntouched();
            if (type) {
              this.dealEventService.pageSavedEvent({ type: type, pageTo: 'compensation', dealId: res[0] ? res[0].dealId : dealId, status: this.status});
            } else {
              this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: res[0] ? res[0].dealId : dealId, status: this.status});
            }
          }, err => {
            this.toasterService.error('Failed to save Notices and Payments Details.', 'Error');
            console.error('There was an error', err);
          }
        );
      } else {
        if (this.type === 'continue') {
          this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'compensation', dealId: parseInt(dealId), status: this.status });
        } else {
          this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'summary', dealId: parseInt(dealId), status: this.status });
        }
      }
    }
  }

  public applicableConfVal(event) {
    if (event) {
      if (event === 'Skip and complete later?') {
        this.status = 'INCOMPLETE';
      } else {
        this.status = 'NOT_APPLICABLE';
      }
    }
  }

  public createEditPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.viewPermission) === true &&
      this.userPermissionService.hasPermission(this.editPermission) === false) {
      return true;
    } else if (this.userPermissionService.hasPermission(this.viewPermission) === true &&
      this.userPermissionService.hasPermission(this.editPermission) === true) {
      return false;
    }
  }

  /** Method to create or save  rep name */
  public saveTypeaheadPersonModal(event, isEditMode?: boolean): void {
    const tName: TypeAheadSaveModel = new TypeAheadSaveModel();
    const vals = this.addRepModal.addTalentForm.value;

    tName.partyId = null;
    tName.name.entity = vals.editableFields.entityName;
    tName.name.first = vals.editableFields.firstName;

    tName.partyType = 'CONTACT';
    tName.name.middle = vals.editableFields.middleName;
    tName.name.suffix = vals.editableFields.suffix;
    tName.displayName = this.createDisplayName(vals);
    tName.createdBy = 'Melissa Tapie';
    tName.updatedBy = 'Melissa Tapie';

    this.commonModuleService.save(JSON.stringify(tName)).subscribe(
      (partySaved: any) => {
        this.addRepModal.successCB(partySaved);
        if (isEditMode) {
          this.getCreateEditDetails({ res: partySaved, event: 'onContactEdit' }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addRepModal.failureCB(errMessage);
      }
    );
  }

  /**Method to save Alias name for add new rep name modal*/
  public saveRepAliasModal(event, isEditMode?: boolean): void {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();
    const vals = this.addRepModal.addTalentForm.value;

    aliasParty.partyType = 'CONTACT';
    aliasParty.partyId = (this.addRepModal.selectedTypeAheadRecord) ? this.addRepModal.selectedTypeAheadRecord.partyId : null;
    aliasParty.name.first = EmptyIfNull.check(vals.editableFields.firstName);
    aliasParty.name.middle = EmptyIfNull.check(vals.editableFields.middleName);
    aliasParty.name.entity = EmptyIfNull.check(vals.editableFields.entityName);
    aliasParty.name.suffix = EmptyIfNull.check(vals.editableFields.suffix);
    aliasParty.displayName = EmptyIfNull.check(this.createDisplayName(vals));

    AKA.name.entity = EmptyIfNull.check(vals.aliasFields.aliasentityName);
    AKA.name.first = EmptyIfNull.check(vals.aliasFields.aliasFirstName);
    AKA.name.middle = EmptyIfNull.check(vals.aliasFields.aliasMiddleName);
    AKA.name.suffix = EmptyIfNull.check(vals.aliasFields.aliasSuffix);

    this.commonModuleService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
      (partySaved) => {
        this.addRepModal.successCB(partySaved);
        if (isEditMode) {
          this.getCreateEditDetails({ res: partySaved, event: 'onContactEditAlias' }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addRepModal.failureCB(errMessage);
      }
    );
  }

  public getCreateEditDetails(partySaved, isEditMode) {
    this.commonModuleService.getRepDetails(partySaved.res.partyId).subscribe(
      (res) => {
        if (isEditMode) {
          setTimeout(() => {
            this.addEditPerson.open({ partyId: res.partyId });
          }, 200);
        }
      });
  }

  /** Method to create or save  company */
  public saveTypeaheadModal(event, isEditMode?: boolean) {
    const tName: TypeAheadSaveModel = new TypeAheadSaveModel();
    const vals = this.addNameCompanyModal.addCompanyForm.value;
    tName.name.entity = vals.companyName;
    tName.partyType = 'COMPANY';
    tName.createdBy = 'Melissa Tapie';
    tName.updatedBy = 'Melissa Tapie';
    tName.partyId = null;

    this.commonModuleService.save(JSON.stringify(tName)).subscribe(
      (res) => {
        this.addNameCompanyModal.successCB(res);
        if (isEditMode) {
          this.getCreateEditCompany({ res: res, event: 'companyEdit' }, true);
        }
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addNameCompanyModal.failureCB(errMessage);
      }
    );
  }

  public getCreateEditCompany(res, isEditMode) {
    this.commonModuleService.getCompanyDetails(res.res.partyId).subscribe((data) => {
      if (isEditMode) {
        setTimeout(() => {
          this.addEditCompany.open({ partyId: data.partyId }, null, true);
        }, 200);
      }
    });
  }

  private createDisplayName(vals: any): string {
    return vals.editableFields.entityName + ', ' +
      vals.editableFields.suffix + ', ' +
      vals.editableFields.firstName + ' ' +
      vals.editableFields.middleName;
  }

  /**Method to save Alias name for add new company modal*/
  public saveAliascompanyFunc(cName, isEditMode?: boolean) {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();

    aliasParty.partyType = 'COMPANY';
    aliasParty.displayName = cName.typeAheadCurrentName && cName.typeAheadCurrentName.entityName ?
      cName.typeAheadCurrentName.entityName : cName.formValues.typeAheadCompany;
    aliasParty.name.entity = cName.typeAheadCurrentName && cName.typeAheadCurrentName.entityName ?
      cName.typeAheadCurrentName.entityName : cName.formValues.typeAheadCompany;
    aliasParty.partyId = (cName.typeAheadCurrentName && cName.typeAheadCurrentName.partyId) ? cName.typeAheadCurrentName.partyId : null;

    AKA.name.entity = EmptyIfNull.check(cName.formValues.aliasCompanyName);
    this.commonModuleService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        this.addNameCompanyModal.successCB(res);
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addNameCompanyModal.failureCB(errMessage);
      }
    );
  }

  public getAccentedModalChar(char: any) {
    this.accentdCharService.getAccentedChars(char).subscribe(
      (chars) => {
        this.accentedCharValues = chars;
        this.accentedChars.openAccentedModal(chars);
      }
    );
  }

  public getAccentedModalCompanyChar(char: any) {
    this.accentdCharService.getAccentedChars(char).subscribe(
      (chars) => {
        this.setAccentedModalChars = chars;
        this.accentedCompModal.openAccentedModal(chars);
      }
    );
  }

  /** Method triggerred on click of edit button in add new rep name modal */
  public OnEditClick(event): void {
    this.saveTypeaheadPersonModal(event, true);
  }

  /** Method triggerred on save of add new rep name popup and sets the saved rep name into the typeahead field 'Rep Name' */
  public saveNameTalentEvent(evt: TypeAheadModel): void {
    const repNameFromTypeahead = this.getFullName(evt);
    this.addRepForm.patchValue({
      repName: evt
    });
    this.repNameTypeAhead.typeAheadField.nativeElement.value = repNameFromTypeahead;
    this.repType.dropdownButton.nativeElement.focus();
  }

  public getFullName(item) {
    let name = '';
    name = !this.isEmpty(item.firstName) ? item.firstName : '';
    name = name + ' ' + (!this.isEmpty(item.middleName) ? item.middleName : '');
    name = name + ' ' + (!this.isEmpty(item.entityName) ? item.entityName : '');
    name = name + (!this.isEmpty(item.suffix) ? ', ' + item.suffix : '');
    return name;
  }

  public isEmpty(str: string) {
    if (str === '' || str === null || str === undefined) {
      return true;
    }
    return false;
  }

  /** Method triggerred on save of add new company popup and sets the saved company name into the typeahead field 'Company' */
  public saveCompanyNameEvent(evt: TypeAheadModel): void {
    const typeAheadValueCompany = evt.typeAheadDisplayName;
    this.addRepForm.patchValue({
      company: evt
    });
    this.companyTypeAhead.typeAheadField.nativeElement.value = typeAheadValueCompany;
    let element = document.getElementById('addLineButton');
    let span = <HTMLElement> element.children[0];
    setTimeout(() => span.focus());
  }

  /** Method triggerred on click of edit button in add new company modal */
  public onCompanyEdit(event) {
    const companyName = this.addNameCompanyModal.addCompanyForm.value.companyName;
    this.saveTypeaheadModal(event, true);
  }

  /** Method to show edit person modal on click of edit button for represenatives */
  public showEditPopup(formGroup, i) {
    this.repEdited = true;
    this.addEditPerson.open({ partyId: this.representators[i].details.repId });
  }

  /** Method triggerred on save of edit person modal */
  public onSubmitCreateEditPersonModal(peopleData) {
    let editedIndex, type, contactInfoDropDownVal;
    this.representators.forEach((element, index) => {
      if (element.details.repId === peopleData.peopleData.partyId) {
        editedIndex = index;
        element.details.repIdVer = null;
      }
    });
    if (this.repEdited) {
      type = 'REP';
    } else if (this.directContactEdited) {
      // contactInfoDropDownVal = this.noticesAndPaymentsForm.get('contactInfoDropdown').value.value;
      type = 'DIRECT_CONTACT';
      this.directContactDetails.details.repIdVer=null;
    }
    this.noticesPaymentsService.getRepDetailsAfterEdit(peopleData.peopleData.partyId, type).subscribe(
      (data) => {
        if (this.repEdited) {
          this.populateEditedRepDetails(data, editedIndex)
        } else if (this.directContactEdited) {
          this.contactInfoOptions = this.getContactInfoDropdownOptions(data.address);
          data.address.forEach(element => {
            if (element.addressId === data.details.directContactId) {
              this.noticesAndPaymentsForm.value['contactInfoDropdown'] = { id: element.addressId, value: element.addressType };
            }
          });
          this.addLineForContactInfo(data)
        }else{
          this.onChangeRepName(peopleData.peopleData);
        }
      }
    );
  }

  public populateEditedRepDetails(data, editedIndex) {
    const repArray = <FormArray>this.noticesAndPaymentsForm.controls.repSet;
    let repAddress, contactArray;
    let repArrayVal = repArray.getRawValue();

    this.repEdited = false;

    repArray.controls = [];

    this.representators.forEach((item, index) => {
      if (index === editedIndex) {
        if (data.address) {//changed from item.address to data.address
          repAddress = data.address ? data.address[0] : null;//this.getAddress(data.address[0]);
          item.address = data.address;
        }else{
          repAddress = null;
        }
        contactArray = this.getContactDetailsFromData(data.contactInfo);
        item.contactInfo = data.contactInfo;
        item.details.compId = data.details.compId; // changes for change i primary company
        item.companyName = data.companyName;
        item.details.akaId = data.details.akaId;

      } else {
        if (item.address) {
          repAddress = item.address[0];//this.getAddress(item.address[0]);
        }else{
          repAddress = null;
        }
        contactArray = this.getContactDetailsFromData(item.contactInfo);
      }
      repArray.push(this.fb.group({
        'repName': this.fb.control({ value: item.repName, disabled: true }, Validators.required),
        'repType': this.fb.control({ value: item.details.typeId, disabled: true }),
        'company': this.fb.control({ value: item.companyName, disabled: true }),
        'repAddress': this.fb.control({ value: repAddress, disabled: true }),
        'repPhone': this.fb.control({ value: contactArray['repPhone'], disabled: true }),
        'repFax': this.fb.control({ value: contactArray['repFax'], disabled: true }),
        'repEMail': this.fb.control({ value: contactArray['repEMail'], disabled: true }),
        'isContractAddress': this.fb.control(repArrayVal[index].isContractAddress),
        'isPrimaryRep': this.fb.control(repArrayVal[index].isPrimaryRep)
      }));
    });
  }

  /** Method to show edit person modal on click of edit/add button for performer in Direct Contact Section*/
  public showEditPopupForDirectContact() {
    this.directContactEdited = true;
    this.addEditPerson.open({ partyId: this.deal.performer.partyId });
  }

  /** Method to handle unsaved modal popup when Add/Edit company modal is open */
  public companySavedModalEvent(event): void {
    if (event === 'close') {
      this.isCompanyModalOpen = true;
    } else {
      this.isCompanyModalOpen = false;
    }
  }

  public onCancel() {
    this.repNameTypeAhead.typeAheadField.nativeElement.focus();
  }

  public onCancelModal() {
    this.companyTypeAhead.typeAheadField.nativeElement.focus();
  }
}
