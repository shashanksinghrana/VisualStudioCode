import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticesPaymentsComponent } from './notices-payments.component';

describe('NoticesPaymentsComponent', () => {
  let component: NoticesPaymentsComponent;
  let fixture: ComponentFixture<NoticesPaymentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoticesPaymentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoticesPaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
