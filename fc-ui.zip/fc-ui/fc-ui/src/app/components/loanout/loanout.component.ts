import { Component, OnInit, AfterViewInit, ViewChild, ViewContainerRef, ElementRef, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject, Subscription } from 'rxjs';
import { DropdownModel, AddButtonModel, UnsavedChangesService, TypeAheadDisplayResultModel, ToasterService, ModalApplicableNotApplicableComponent } from 'c2c-common-lib';
import { SharedService } from '../../services/http/shared/shared.service';
import { ModalGenericComponent } from 'c2c-common-lib';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { ToastsManager } from '../../../../node_modules/ng2-toastr';
import { DealService } from '../../services/http/deal/deal.service';
import { DealModel } from '../../models/deal/deal.model';
import { DealEventService } from '../../services/events/deal-event.service';
import { LoanoutModel } from '../../models/deal/loanout.model';
import { debounceTime, distinctUntilChanged, filter, map, merge } from 'rxjs/operators';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';

/**
 * The LoanoutComponent.
 *
 * This component is used to add loanout for a new or existing performer.
 */
@Component({
  selector: 'fc-loanout',
  templateUrl: './loanout.component.html',
  styleUrls: ['./loanout.component.scss']
})

export class LoanoutComponent implements OnInit, OnDestroy, AfterViewInit {
  public deal: DealModel;
  public addButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add');
  public countries: DropdownModel = new DropdownModel(null, null, null, null, []);
  public loanoutCompanies: DropdownModel = new DropdownModel(null, null, null, null, []);
  public states: DropdownModel = new DropdownModel(null, null, null, null, []);
  public displayLoanOutCompanyData: TypeAheadDisplayResultModel;
  public placeholder: string = 'XX-XXXXXXXX';
  public showLoanoutError: boolean = false;
  public isEqual: boolean = false;
  public isStateChange: boolean = false;
  public isCountryChange: boolean = false;
  public showModal: boolean = false;
  public loanoutForm: FormGroup;
  public addLoanoutForm: FormGroup;
  public companyList: any[] = [];
  public primaryRecord: any[] = [];
  public loanoutArr: any[] = [];
  public relationID: number;
  public isEinValid: boolean = false;
  public isUSCountrySelected: boolean = false;
  public isCountryUS: boolean = false;
  public einChange: Boolean = false;
  public einRequiredFormat: Boolean = false;
  public isCompany: boolean = false;
  public isItemRemoved: boolean = false;
  public partyIdVal;
  public message: string;
  public loanout: LoanoutModel;
  public performerPartyId: number;
  public type: string;
  public status: string;
  public skipUnsavedModalEvent: boolean = false;
  public viewPermission:PermissionList=PermissionList.dealCreateEditView
  public editPermission:PermissionList=PermissionList.dealCreateEditEdit
  public disableForm:boolean=false;
  private dealSubscriptions: Subscription = new Subscription();
  public loanoutUpdated: boolean = false;

  @ViewChild('applicableNotApplicableModal') public applicableNotApplicableModal: ModalApplicableNotApplicableComponent;
  @ViewChild('saveAndContinue') public saveAndContinue: any;
  @ViewChild('genericConfirmationModal') public genericConfirmationModal: ModalGenericComponent;
  @ViewChild('newLoanoutConfirmationModal') public newLoanoutConfirmationModal: ModalGenericComponent;
  @ViewChild('instance') public instance: NgbTypeahead;
  @ViewChild('loanOutCompany') public loanOutCompany: ElementRef;

  /**
   * Constructor for the CreateEditProjectComponent
   *
   * @param route The active route.
   * @param sharedService The Shared Service for common services.
   * @param dealService The Create Deal Service for deal related services.
   * @param fb FormBuilder instance for building form elements.
   */
  constructor(
    private route: ActivatedRoute,
    private sharedService: SharedService,
    private unsavedChangesService: UnsavedChangesService,
    private dealService: DealService,
    private fb: FormBuilder,
    private dealEventService: DealEventService,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private userPermissionService:UserPermissionService
  ) {
    this.disableForm=this.createEditPermission();
    this.toaster.setRootViewContainerRef(vcr);
  }

  /*
  * Set loanout data onInit.
  */
  public ngOnInit(): void {
    this.loadService();
  }

  private loadService(): void {
    if (this.dealService.deal) {
      this.getDealDetails();
    } else {
      this.dealSubscriptions.add(
        this.dealService.getDealDetails().subscribe((deal) => {
          this.getDealDetails();
        })
      );
    }
  }

  private getDealDetails(): void {
    this.performerPartyId = this.dealService.deal.performer.partyId;
    this.getCompTypeOptions(this.performerPartyId);
    this.route.data.subscribe(
      (data: { dropdowns: any }) => {
        this.states = data.dropdowns.states;
        this.countries = data.dropdowns.countries;
      });
    this.deal = this.dealService.deal;
    this.loanout = this.dealService.loanout;
    this.loanoutForm = this.fb.group({
      'loanoutSet': this.fb.array([]),
    });
    this.initializeAddLoanoutForm();
    if (this.deal.id) {
      this.getLoanoutData();
    }
  }

  /* Method to open modal popup */
  public openConfirmationModal(): void {
    this.setMessage();
    this.genericConfirmationModal.open();
  }

  /* Method to open modal popup */
  public openNewLoanoutConfirmationModal(): void {
    if (this.partyIdVal === undefined) {
      this.newLoanoutConfirmationModal.open();
    }
  }

  /*
  * ngAfterViewInit
  */
  public ngAfterViewInit(): void {
    this.sharedService.dealId = this.deal.id;
    this.sharedService.performerPartyId = this.performerPartyId;
    if(!this.disableForm)
    {
      this.loanOutCompany.nativeElement.focus();

    }
  
  }

  /*
  * Method to initialize add loanout form
  */
  public initializeAddLoanoutForm(): void {
    this.addLoanoutForm = this.fb.group({
      'loanOutCompany': this.fb.control(''),
      'stateOfInc': this.fb.control(this.getDropdownSelection(this.states, '', 'value')),
      'countryOfInc': this.fb.control(this.getDropdownSelection(this.countries, '', 'value')),
      'EIN': this.fb.control('')
    });
  }

  /**
  * Get all the data related to loanout and assigns it to component properties.
  */
  public getLoanoutData(): void {
    this.route.data.subscribe(
      (data: { loanout: LoanoutModel[] }) => {
        if (data.loanout != null) {
          this.setLoanoutList(data)
        }
      },
      (error) => {
        console.log('Error when getting loanout details', error);
      }
    );
  }

  /*
  * Method to get Loanout Typeahead dropdown data
  * @param id of performer party
  */
  public getCompTypeOptions(id): void {
    var record = [];
    this.sharedService.getLoanOutCompany(id).subscribe(
      (data) => {
        this.companyList = data;
        for (let i = 0; i < Object.keys(data).length; i++) {
          this.loanoutArr.push({
            value: data[i].loanoutComp,
            route: '',
            id: data[i].relationID,
            data: data[i]
          });
          if (data[i].primary) {
            record.push({ data });
          }
        }
        // this.primaryRecord = record.slice(0,1);
        (record[0].data[0]) ? this.primaryRecord[0] = record[0].data[0] : '';
        (this.deal.loanoutId == null) ? this.setAddLoanoutForm() : '';
      });
  }

  /* 
  * Method to set value in form array as grid list
  * @param data model
  */
  public setLoanoutList(data): void {
    const loanoutArray = <FormArray>this.loanoutForm.controls.loanoutSet;
    loanoutArray.push(this.fb.group({
      'loanOutCompany': this.fb.control({ value: data.loanout.loanoutComp, disabled: true }),
      'stateOfInc': this.fb.control({ value: this.getValueById(this.states, data.loanout.stateID), disabled: true }),
      'countryOfInc': this.fb.control({ value: this.getValueById(this.countries, data.loanout.countryID), disabled: true }),
      'EIN': this.fb.control({ value: data.loanout.ein, disabled: true })
    }));
    this.relationID = data.loanout.relationID;
    this.partyIdVal = data.loanout.partyID;
  }

  private markFormAsUnchanged(): void {
    this.addLoanoutForm.markAsPristine();
    this.addLoanoutForm.markAsUntouched();
  }

  /* 
  *  Method to set value in form field
  */
  public setAddLoanoutForm(): void {
    if (this.primaryRecord.length > 0) {
      const data = this.primaryRecord[0];
      this.addLoanoutForm.get('loanOutCompany').setValue({ value: data.loanoutComp, data: data });
      this.addLoanoutForm.get('countryOfInc').setValue({ value: this.getValueById(this.countries, this.primaryRecord[0].countryID), id: this.primaryRecord[0].countryID });
      this.addLoanoutForm.get('stateOfInc').setValue({ value: this.getValueById(this.states, this.primaryRecord[0].stateID), id: this.primaryRecord[0].stateID });
      this.addLoanoutForm.get('EIN').setValue(data.ein);
      this.relationID = this.primaryRecord[0].relationID;
      this.partyIdVal = this.primaryRecord[0].partyID;
      this.markFormAsUnchanged();
    }
  }

  /*
  * Method to perform action on state select event
  * @param state dropdown value
  * @param formName form name
  */
  public onSelectState(state: any, formName: string, inputType: string): void {
    if (Object.keys(state).length > 0 ||
      (Object.keys(state).length === 0 && this[formName].get('countryOfInc').value &&
        this[formName].get('countryOfInc').value.value === 'United States')) {
      const country = this.countries.options.find(countryItem => countryItem.value === 'United States');
      (country) ? this[formName].get('countryOfInc').setValue(country) : '';
      this.isCountryUS = false;
    }
  }

  /*
  *  Method to perform action on country select event
  */
  public onSelectCountry(country: any, formName: string, inputType: string): void {
    let einVal = this.addLoanoutForm.controls['EIN'].value;
    if (Object.keys(country).length > 0 &&
      (this[formName].get('countryOfInc').value &&
        this[formName].get('countryOfInc').value.value === 'United States')) {
      this.isUSCountrySelected = true;
      if (!this.addLoanoutForm.value['stateOfInc']) {
        this.isCountryUS = true;
        (einVal != "") ? this[formName].get('EIN').setValue('') : '';
      }
    } else if (Object.keys(country).length > 0 && this[formName].get('countryOfInc').value.value !== 'United States') {
      this[formName].get('stateOfInc').setValue('');
      (einVal != "") ? this[formName].get('EIN').setValue('') : '';
      (this.addLoanoutForm.controls['EIN'].valueChanges && einVal != "") ? this.onEinChange() : '';
      this.isUSCountrySelected = false;
      this.isCountryUS = false;
    }
  }

  /*
  * Method to check country dropdown value chnages
  */
  public countryChange(): void {
    if (this.addLoanoutForm.value['countryOfInc']) {
      let count = this.addLoanoutForm.value['countryOfInc'].value;
      this.addLoanoutForm.get('countryOfInc').valueChanges.subscribe(country => {
        if (country.value !== count) {
          this.isCountryChange = true
          this.stateChanged();
        } else {
          this.isCountryChange = false;
        }
      });
    } else {
      this.isCountryChange = false;
    }
  }

  /*
  * Method to check state dropdown value chnages
  */
  public stateChanged(): void {
    if (this.addLoanoutForm.value['stateOfInc']) {
      let state = this.addLoanoutForm.value['stateOfInc'].value;
      this.addLoanoutForm.get('stateOfInc').valueChanges.subscribe(stateVal => {
        if (stateVal.value !== state) {
          this.isStateChange = true
        } else {
          this.isStateChange = false;
        }
      });
    } else {
      this.isStateChange = false;
    }
  }

  /* Set modal popup message based on value changes */
  public setMessage(): void {
    if (this.einChange && this.isCountryChange && this.isStateChange) {
      this.message = "Fields State of incorporation, Country and EIN are changed. Do you wish to proceed?";
    } else if (this.isCountryChange && this.isStateChange) {
      this.message = "Fields State of incorporation and Country are changed. Do you wish to proceed?";
    } else if (this.einChange && this.isCountryChange) {
      this.message = "Fields Country and EIN are changed. Do you wish to proceed?";
    } else if (this.einChange && this.isStateChange) {
      this.message = 'Fields State of incorporation and EIN are changed. Do you wish to proceed?';
    } else if (this.einChange) {
      this.message = "Field EIN is changed. Do you wish to proceed?";
    } else if (this.isCountryChange) {
      this.message = "Field Country is changed. Do you wish to proceed?";
    } else if (this.isStateChange) {
      this.message = "Field State of incorporation is changed. Do you wish to proceed?";
    }
  }

  /* 
  * Method to get dropdown value 
  */
  public getDropdownOptions(lookupType: string): DropdownModel {
    let options: any[] = [];
    let dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.sharedService.getGenericLookupDropdown(lookupType).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          options.push({
            value: data[i].value,
            abbr: data[i].abbreviation,
            id: data[i].id,
            data: data[i]
          });
        }
      }
    );
    return dropdownModel;
  }

  /* Method to check EIN field value change */
  public onEinChange(): void {
    if (this.addLoanoutForm.controls['EIN'].valueChanges) {
      this.einChange = true;
    } else {
      this.einChange = false;
    }
    this.checkEinOnCountryBase();
  }

  /* Method to check EIN field based on dropdown values */
  public checkEinOnCountryBase(): boolean {
    var ein = this.addLoanoutForm.value['EIN'];
    var country = this.addLoanoutForm.value['countryOfInc'].value;
    if (ein && country && country === 'United States') {
      if (ein.length == 10) {
        this.einRequiredFormat = false;
        return true;
      } else {
        this.einRequiredFormat = true;
        return false;
      }
    }
    else {
      this.einRequiredFormat = false;
      return true;
    }
  }

  /* 
   * Method to get value from value id
   * @param id
  */
  public getValueById(dropdown: DropdownModel, id: number) {
    for (let i = 0; i < dropdown.options.length; i++) {
      if (dropdown.options[i].id === id) {
        return dropdown.options[i].value;
      }
    }
    return null;
  }

  /* Method to get ID from dropdown value */
  public getIdByValue(dropdown: DropdownModel, value: string) {
    for (let i = 0; i < dropdown.options.length; i++) {
      if (dropdown.options[i].value === value) {
        return dropdown.options[i].id;
      }
    }
    return null;
  }


  /*
  * Method called onSelect loanout company from dropdown
  * Used to set country, state and EIN value based on selected company value
  */
  public onSelectedLoanOutCompany(company: any, formName: string, inputType: string): void {
    if (Object.keys(company).length > 0) {
      this.isCompany = false;
      const selectedState = this.states.options.find(countryItem => countryItem.value === this.getValueById(this.states, company.item.data.stateID));
      if (selectedState) {
        this[formName].get('stateOfInc').setValue(selectedState);
      } else {
        this[formName].get('stateOfInc').setValue('');
      }
      const selectedCountry = this.countries.options.find(countryItem => countryItem.value === this.getValueById(this.countries, company.item.data.countryID));
      if (selectedCountry) {
        this[formName].get('countryOfInc').setValue(selectedCountry);
      } else {
        this[formName].get('countryOfInc').setValue('');
      }
      company.item.data.ein ? this[formName].get('EIN').setValue(company.item.data.ein) : this[formName].get('EIN').setValue('');
      this.relationID = (company.item.data.relationID ? company.item.data.relationID : this.relationID);
      this.partyIdVal = (company.item.data.partyID ? company.item.data.partyID : this.partyIdVal);
    }
  }


  /* 
  * Called on click of 'plus' icon
  * To open Modal popup based on value changes
  */
  public onAddLine(): void {
    (!this.addLoanoutForm.value['loanOutCompany']) ? this.isCompany = true : this.isCompany = false;
    if (this.addLoanoutForm.valid && 
        this.addLoanoutForm.value['loanOutCompany'] &&
        this.checkStateForUS()) {
      if ((this.einChange || this.isCountryChange || this.isStateChange) && this.partyIdVal) {
        this.checkEinOnCountryBase() ? this.openConfirmationModal() : '';
      } else if (!this.partyIdVal) {
        if(this.isCountryChange || this.isStateChange)
        {
          this.checkEinOnCountryBase() ? this.addLine() : '';
        }
        else
        this.checkEinOnCountryBase() ? this.openNewLoanoutConfirmationModal() : '';
      } else {
        this.checkEinOnCountryBase() ? this.addLine() : '';
      }
    }
  }

  public checkStateForUS():boolean{
    if (this.isUSCountrySelected){
      if(this.addLoanoutForm.value['stateOfInc']){
        return true;
      }
      return false
    }
    return true;
  }

  /* 
  * Method of modal popup event
  * Called on click of 'OK' icon
  */
  public modalClosedEvent(event): void {
    if (event === "OKAY") {
      (this.addLoanoutForm.valid) ? this.addLine() : this.validateFormFields(this.addLoanoutForm);
      this.resetForm();
    }
  }

  /* 
  * Method of modal popup event  
  * Called on click of 'OK' icon
  */
  public modalNewLoanoutEvent(event): void {
    if (event === "OKAY") {
      (this.addLoanoutForm.valid) ? this.addLine() : this.validateFormFields(this.addLoanoutForm);
      this.resetForm();
    }
  }

  /*
  * Method to Adds line of values to the loanout set based on the dropdowns
  */
  public addLine(): void {
    if (this.addLoanoutForm.valid && (this.addLoanoutForm.value['loanOutCompany'].value || this.addLoanoutForm.value['loanOutCompany'])) {
      const loanoutArray = <FormArray>this.loanoutForm.controls.loanoutSet;
      loanoutArray.removeAt(0);
      if (this.validateLoanoutRecord(loanoutArray)) {
        this.showLoanoutError = false;
        const newCompName = (this.addLoanoutForm.value['loanOutCompany'].value) ? (this.addLoanoutForm.value['loanOutCompany'].value) : (this.addLoanoutForm.value['loanOutCompany']);
        loanoutArray.push(this.fb.group({
          'loanOutCompany': this.fb.control({ value: newCompName, disabled: true }) ? this.fb.control({ value: newCompName, disabled: true }) : this.fb.control({ value: '', disabled: true }),
          'stateOfInc': this.addLoanoutForm.value['stateOfInc'] ? this.fb.control({ value: this.addLoanoutForm.value['stateOfInc'].value, disabled: true }) : this.fb.control({ value: '', disabled: true }),
          'countryOfInc': this.addLoanoutForm.value['countryOfInc'] ? this.fb.control({ value: this.addLoanoutForm.value['countryOfInc'].value, disabled: true }) : this.fb.control({ value: '', disabled: true }),
          'EIN': this.addLoanoutForm.value['EIN'] ? this.fb.control({ value: this.addLoanoutForm.value['EIN'], disabled: true }) : this.fb.control({ value: '', disabled: true })
        }));
        const selectedObj = {
          'loanOutComp': this.addLoanoutForm.controls['loanOutCompany'],
          'stateID': this.addLoanoutForm.controls['stateOfInc'],
          'contryID': this.addLoanoutForm.controls['countryOfInc'],
          'ein': this.addLoanoutForm.controls['EIN']
        };
        this.updatedCompanyData(selectedObj);
        this.resetForm();
        this.isItemRemoved = false;
        // this.addLoanoutForm.markAsPristine();
        // this.addLoanoutForm.markAsUntouched();
      } else {
        this.showLoanoutError = true;
      }
    } else {
      this.validateFormFields(this.addLoanoutForm);
    }
  }

  /* Method to reset Form field */
  public resetForm(): void {
    this.addLoanoutForm.reset({ 'loanOutCompany': '', 'stateOfInc': '', 'countryOfInc': '', 'EIN': '' });
    this.isCountryChange = false;
    this.einChange = false;
    this.isStateChange = false;
  }

  /**
  * Validates loanout record to prevent Duplicate entry
  * parameter combination of Main/End Title, Card and Position is compared
  */
  public validateLoanoutRecord(loanoutArray): boolean {
    const flag = true;
    const newObj = {
      'loanOutCompany': this.addLoanoutForm.value['loanOutCompany'],
      'stateOfInc': this.addLoanoutForm.value['stateOfInc'],
      'countryOfInc': this.addLoanoutForm.value['countryOfInc'],
      'EIN': this.addLoanoutForm.value['countryOfInc']
    };
    return flag;
  }

  /**
   * Determines if the form has any unsaved changes, if so, transition message
   * will be displayed. If user confirms, routing continues to navigate.
   */
  public canDeactivate(): Observable<boolean> | boolean {
    if (this.addLoanoutForm.dirty && this.addLoanoutForm.touched && !this.skipUnsavedModalEvent) {
      this.unsavedChangesService.openModal();
      return this.unsavedChangesService.onCloseModal();
    }
    return true;
  }

  /**
   * Populates the dropdown value when populating the form.
   *
   * @param type The DropdownModel to iterate over.
   * @param value The value to set on the dropdown.
   * @param field The field name to compare against.
   */
  public getDropdownSelection(type, value, field) {
    let selection = value;
    if (type.options) {
      type.options.forEach((val) => {
        if (value === val[field]) {
          selection = val;
        }
      });
    }
    return selection;
  }

  /**
  * Removes the given line from the loanout set when the minus (-) icon is clicked.
  *
  * @param index The countryOfInc in the array of the row to be removed.
  */
  public removeLineItem(index): void {
    const loanoutArray = <FormArray>this.loanoutForm.controls.loanoutSet;
    loanoutArray.removeAt(index);
    this.addLoanoutForm.markAsDirty();
    this.addLoanoutForm.markAsTouched();
    this.isItemRemoved = true;
    this.saveAndContinue.setFocus();
  }


  /**
  * Checks to see if the FormGroup is invalid.
  * @param formGroup The FormGroup to run validation on.
  * @param field The FormControl to check in the given FormGroup.
  */
  public isFormInvalid(formGroup, field): boolean {
    return formGroup.get(field).invalid && formGroup.get(field).touched;
  }

  /**
   * Called when the form is invalid in order to mark the invalid controls.
   *
   * @param formGroup The FormGroup to mark.
   */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  /* Method to check Party ID value */
  public checkPartyId(selectedObj): any {
    let id;
    if (this.partyIdVal !== undefined) {
      return id = this.partyIdVal;
    } else if (selectedObj.loanOutComp.value) {
      (selectedObj.loanOutComp.value.data) ?
        id = selectedObj.loanOutComp.value.data.partyID : id = null;
      return id;
    } else {
      return id = null;
    }
  }

  /* 
  * Method to create object of updated company details
  * @param selectedObj
  */
  public updatedCompanyData(selectedObj): void {
    this.loanoutUpdated = true;
    let id = this.checkPartyId(selectedObj);
    if (id != null || id != undefined) {
      for (let i = 0; i < this.companyList.length; i++) {
        if (this.companyList[i].partyID === id) {
          this.companyList[i].dealId = this.deal.id ? this.deal.id : '';
          this.companyList[i].loanoutComp = (selectedObj.loanOutComp.value.value) ? selectedObj.loanOutComp.value.value : selectedObj.loanOutComp.value;
          this.companyList[i].stateID = (selectedObj.stateID.value) ? selectedObj.stateID.value.id : null;
          this.companyList[i].countryID = (selectedObj.contryID.value) ? selectedObj.contryID.value.id : null;
          this.companyList[i].ein = (selectedObj.ein.value) ? selectedObj.ein.value : '';
          this.isEqual = true;
        }
        (this.companyList[i].partyID !== id) ? this.companyList[i].primary = false : this.companyList[i].primary = true;
      }
      (this.isEqual) ? this.saveUpdatedLoanout(this.performerPartyId, this.companyList) : '';
    } else {
      for (let i = 0; i < this.companyList.length; i++) {
        this.companyList[i].primary = false;
      }
      const obj = {
        'talent_partyID': this.performerPartyId,
        'dealId': this.deal.id ? this.deal.id : '',
        'stateID': selectedObj.stateID.value ? selectedObj.stateID.value.id : null,
        'countryID': selectedObj.contryID.value ? selectedObj.contryID.value.id : null,
        'ein': selectedObj.ein.value ? selectedObj.ein.value : '',
        'loanoutComp': (selectedObj.loanOutComp.value.value) ? selectedObj.loanOutComp.value.value : selectedObj.loanOutComp.value,
        'primary': true
      };
      this.companyList.push(obj);
      this.saveUpdatedLoanout(this.performerPartyId, this.companyList);
    }
  }

  /*
   * Method to updated company details
  */
  public saveUpdatedLoanout(id, loanOutCompData): void {
    var data;
    this.sharedService.updateLoanOutCompany(id, loanOutCompData).subscribe(
      res => {
        data = res;
        this.getRelationId(data);
      }, err => {
        console.error('There was an error', err);
      }
    );
  }

  /*
  * Method to get relationId of new Loanout company
  */
  public getRelationId(data): void {
    if (data.length > 0) {
      for (let i = 0; i < data.length; i++) {
        if (data[i].primary) {
          this.relationID = data[i].relationID;
          this.partyIdVal = data[i].partyID;
        }
      }
    }
  }

  /* 
  * Method to create loanout details object to submit
  */
  public onSubmit(type?: string): void {
    this.skipUnsavedModalEvent = true;
    if (this.dealService.currentWizardPage.status) {
      if (this.loanoutForm.value.loanoutSet.length === 0 && this.dealService.currentWizardPage.status.name !== 'NOT_APPLICABLE') {
        this.type = type;
        this.openApplicableNotApplicableModal();
      }
    }
    if (!this.dealService.currentWizardPage.status && this.loanoutForm.value.loanoutSet.length === 0) {
      this.type = type;
      this.openApplicableNotApplicableModal();
    } else if (this.loanoutForm.value.loanoutSet.length > 0 || this.dealService.currentWizardPage.status.name == 'NOT_APPLICABLE' || this.isItemRemoved) {
      const dealId: string = this.dealService.getDealId();
      const loanoutArray = <FormArray>this.loanoutForm.controls.loanoutSet;
      var loanOut = {};
      if (!this.loanoutForm.invalid && !this.showLoanoutError) {
        this.addLoanoutForm.markAsPristine();
        this.addLoanoutForm.markAsUntouched();
        if (loanoutArray.length > 0) {
          loanOut = {
            'relationID': (loanoutArray.value[0].relationID) ? (loanoutArray.value[0].relationID) : this.relationID,
            'talent_partyID': (loanoutArray.value[0].talent_partyID) ? (loanoutArray.value[0].talent_partyID) : this.performerPartyId,
            'stateID': this.getIdByValue(this.states, loanoutArray.value[0].stateOfInc) ? this.getIdByValue(this.states, loanoutArray.value[0].stateOfInc) : null,
            'countryID': this.getIdByValue(this.countries, loanoutArray.value[0].countryOfInc) ? this.getIdByValue(this.countries, loanoutArray.value[0].countryOfInc) : null,
            'partyID': this.partyIdVal ? this.partyIdVal : null,
            'dealId': this.deal.id ? this.deal.id : null,
            'ein': loanoutArray.value[0].EIN ? loanoutArray.value[0].EIN : '',
            'loanoutComp': loanoutArray.value[0].loanOutCompany,
            'primary': loanoutArray.value[0].primary ? loanoutArray.value[0].primary : true,
            'loanoutUpdated': this.loanoutUpdated
          };
          this.saveLoanoutData(loanOut, type);
        } if (this.isItemRemoved && this.loanoutForm.value.loanoutSet.length === 0) {
          this.dealService.saveLoanout(this.deal.id, loanOut).subscribe(
            res => {
              this.addLoanoutForm.markAsPristine();
              this.addLoanoutForm.markAsUntouched();
            })
        } else if (this.isItemRemoved && this.loanoutForm.value.loanoutSet.length > 0) {
          this.saveLoanoutData(loanOut, type);
        } else {
          this.addLoanoutForm.markAsPristine();
          this.addLoanoutForm.markAsUntouched();
          if (type == 'continue') {
            this.dealEventService.pageSavedEvent({ type: type, pageTo: 'noticesPayments', dealId: this.deal.id, status: (!this.loanoutForm.value.loanoutSet.length) ? this.dealService.currentWizardPage.status.name: 'COMPLETE' });
          } else {
            this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: this.deal.id, status: (!this.loanoutForm.value.loanoutSet.length) ? this.dealService.currentWizardPage.status.name: 'COMPLETE' });
          }
        }
      } else {
        this.validateFormFields(this.loanoutForm);
      }
    }
  }

  /* Method to submit Loanout data and api call 
  *  @param  data
  *  @param type
  */
  public saveLoanoutData(data?: any, type?: string): void {
    this.dealService.saveLoanout(this.deal.id, data).subscribe(
      res => {
        this.addLoanoutForm.markAsPristine();
        this.addLoanoutForm.markAsUntouched();
        if (type == 'continue') {
          this.dealEventService.pageSavedEvent({ type: type, pageTo: 'noticesPayments', dealId: res['id'], status: (!this.loanoutForm.value.loanoutSet.length) ? this.dealService.currentWizardPage.status.name: 'COMPLETE'});
        } else {
          this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: res['id'], status: (!this.loanoutForm.value.loanoutSet.length) ? this.dealService.currentWizardPage.status.name: 'COMPLETE'});
        }
      }, err => {
        this.toasterService.error('Failed to save Loanout Details.', 'Error');
        console.error('There was an error', err);
      }
    );
  }

  /*
  * Method to handle Loanout company Typeahead on click and
  * onFocus event.
  */
  public focus$ = new Subject<string>();
  click$ = new Subject<string>();
  public search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      merge(this.focus$),
      merge(this.click$.pipe(filter(() => !this.instance.isPopupOpen() || this.instance.isPopupOpen()))),
      map(term => (term === '' ? this.loanoutArr
        : this.loanoutArr.filter(v => v.value.toLowerCase().indexOf(term.toLowerCase()) > -1)))
    );
  public inputFormatter = (x: { value: string }) => x.value;
  public formatter = (x: { value: string }) => x.value;

  public onClickDropdownIcon(event){
    this.loanOutCompany.nativeElement.dispatchEvent(new Event('input'));
    this.loanOutCompany.nativeElement.focus();
  }
  /*
  * Method to clear all form field if Comapany field is empty
  * Handled on company field keyup event
  */
  public checkFormField() {
    (!this.addLoanoutForm.value['loanOutCompany']) ? this.resetForm() : this.isCompany = false;
    this.relationID = undefined;
    this.partyIdVal = undefined;
    this.isStateChange = false;
    this.isCountryChange = false;
    this.einChange = false;
  }

  /* Method to open modal popup */
  public openApplicableNotApplicableModal(): void {
    this.applicableNotApplicableModal.openModal();
  }

  public applicableModalClosedEvent(event): void {
    if (event == 'OK') {
      const dealId: string = this.dealService.getDealId();
      if (this.type == 'continue') {
        this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'noticesPayments', dealId: parseInt(dealId), status: this.status });
      } else {
        this.dealEventService.pageSavedEvent({ type: this.type, pageTo: 'summary', dealId: parseInt(dealId), status: this.status });
      }
    }
  }

  public applicableConfVal(event) {
    if (event) {
      if (event === "Skip and complete later?") {
        this.status = 'INCOMPLETE';
      } else {
        this.status = 'NOT_APPLICABLE';
      }
    }
  }

  public createEditPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === false) {
      return true;
    }
    else if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === true) {
      return false;
    }
  }

  public ngOnDestroy(): void {
    this.dealSubscriptions.unsubscribe();
  }
}
