import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanoutComponent } from './loanout.component';

describe('LoanoutComponent', () => {
  let component: LoanoutComponent;
  let fixture: ComponentFixture<LoanoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoanoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
