import { Component, Input, OnDestroy , EventEmitter, Output, TemplateRef, ViewChild, OnInit } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ModalService } from '../../../services/events/modal-event-service';

@Component({
  selector: 'powersearch-modal',
  templateUrl: './powersearch-report-modal.html',
  styleUrls: ['./powersearch-report-modal.scss']
})
export class PowersearchModal implements OnInit, OnDestroy {

  public isEmpty: boolean = true;
  public isEndDate: boolean = false;
  public isStartDate: boolean = false;

  public modal: NgbModalRef;

   /** Defines Option for modal window */
   private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-size-300'
  };

  public modalReference: any;

  @Input() public modalTitle: string = 'Report Detail Station-12';

  /** The content of the modal to be displayed when opened. */
  @ViewChild('powersearchModalContent') private powersearchModalContent: TemplateRef<any>;

  @Output() public powersearchReportModalEvent: any = new EventEmitter<any>();

  @Input() public showButton: boolean = false;

  public station12ReportForm: FormGroup;

  constructor(private modalService: NgbModal, private fb: FormBuilder, private eventService: ModalService) {
  }

  public close(event?: Event): void {
    this.modalReference.close(event);
    this.isStartDate = false;
    this.isEndDate = false;
    this.station12ReportForm.reset();
  }

  public ngOnInit() {
    this.station12ReportForm = this.fb.group({
      'fromDate': this.fb.control(null),
      'toDate': this.fb.control(null)
    });
  }

  public ngOnDestroy(): void {
  }

  public onValueSelect(): void {
    const startDate = this.station12ReportForm.controls['fromDate'].value;
    const endDate = this.station12ReportForm.controls['toDate'].value;
    if (endDate === null || startDate === null) {
      this.isEndDate = true;
      this.isStartDate = true;
    }  else if (new Date(endDate) < new Date(startDate)) {
      this.isStartDate = true;
      this.isEndDate = true;
    } else {
      this.isStartDate = false;
      this.isEndDate = false;
      this.isEmpty = false;
    }
  }

  public open() {
    this.isEmpty = true;
    this.modalReference = this.modalService.open(this.powersearchModalContent, this.modalOptions);
    this.eventService.openModal();
  }

  public submit(event?: Event): void {
    this.onValueSelect();
    if (!this.isStartDate && !this.isEndDate) {
        this.powersearchReportModalEvent.emit({formData: this.station12ReportForm.value, action: event});
        this.modalReference.close();
        this.station12ReportForm.reset();
    }
  }
}
