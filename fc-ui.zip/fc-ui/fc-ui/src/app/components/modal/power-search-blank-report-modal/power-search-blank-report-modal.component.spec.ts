import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PowerSearchBlankReportModal } from './power-search-blank-report-modal.component';

describe('PowerSearchBlankReportModal', () => {
  let component: PowerSearchBlankReportModal;
  let fixture: ComponentFixture<PowerSearchBlankReportModal>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PowerSearchBlankReportModal ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PowerSearchBlankReportModal);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
