import { Component, Input, EventEmitter, Output, TemplateRef, ViewChild, OnInit } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray, ValidatorFn, AbstractControl } from '@angular/forms';
import { ModalService } from '../../../services/events/modal-event-service';
import { ProjectTitleModel } from '../../../models/project/project-title.model';
import { FormValidators } from '../../../utils/validation/form-validators';
import { TypeAheadDisplayResultModel, DropdownTypeAheadModel } from 'c2c-common-lib';
import { SharedService } from '../../../services/http/shared/shared.service';
import { DealService } from '../../../services/http/deal/deal.service';
import { CommonModuleService } from '../../../services/http/deal/add-edit-performer/common-module.service';
import { ActivatedRoute } from '@angular/router';
import { BlankContractModel } from '../../../models/power-search/blankContract.model';





@Component({
  selector: 'power-search-blank-report-modal',
  templateUrl: './power-search-blank-report-modal.component.html',
  styleUrls: ['./power-search-blank-report-modal.component.scss']
})
export class PowerSearchBlankReportModal implements OnInit {
  //variables to be used
  public modal: NgbModalRef;
  public modalReference: any;
  public contractType: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
  public prodCompany: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, []);
  public addressOptions: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, []);
  public blankContractForm: FormGroup
  public displayProjectTitleData: TypeAheadDisplayResultModel;
  public projectId: any;
  public contractTypeList: Array<object> = [];
  public addressList: Array<Object> = [];
  public productionList: Array<Object> = [];
  public signatoriesList: Array<Object> = []
  public locations = [];
  public signatories: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, []);
  public isAddress: string = '';
  public isSaveDisabled: boolean = false;
  public productionDisabled: boolean = false;
  public addressDisabled: boolean = false;
  public selection: any = [];




  /** Defines Option for modal window */
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false
  };

  @Input() public modalTitle: string = 'Report Detail - Blank Contract';

  /** The content of the modal to be displayed when opened. */
  @ViewChild('powersearchBlankReportModalContent') private powersearchBlankReportModalContent: TemplateRef<any>;

  @Output() public powersearchBlankReportModalEvent: any = new EventEmitter<any>();

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private eventService: ModalService,
    private sharedService: SharedService,
    private dealService: DealService,
    private commonModuleService: CommonModuleService,
    private route: ActivatedRoute

  ) {
    /**To get the signatories data from the resolver service for the dropdown typeAhead  */
    this.route.data.subscribe(
      (data: { powersearch: any }) => {
        this.signatories = data.powersearch.signatories;
      }
    );
    /**Get contract type from the API*/
    this.contractType = this.getDropdownOptions('CONTRACT');
  }

  public close(event?: Event): void {
    this.blankContractForm.reset();
    this.modalReference.close(event);
  }

  public open() {
    this.modalReference = this.modalService.open(this.powersearchBlankReportModalContent, this.modalOptions);
    this.eventService.openModal();
    /**disable the save button and the other fields as the window opens */
    this.isSaveDisabled = true;
    this.productionDisabled = true;
    this.addressDisabled = true;
  }

  public ngOnInit(): void {
    this.displayProjectTitleData = this.sharedService.displayProjectTitleData;
    /**Creating the contract form*/
    this.blankContractForm = this.fb.group({
      'title': this.fb.control(new ProjectTitleModel()),
      'contractType': this.fb.control(null),
      'production': this.fb.control(null),
      'address': this.fb.control(null),
      'signatories': this.fb.control(null)
    });
  }

  /**Creating the dropdown options for contract type */
  public getDropdownOptions(lookupType: string) {
    let options: any[] = [];
    let newOptions:any[]=[];
    let dropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null,options );
    this.sharedService.getDropdown(lookupType).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
     let newOptions=  options.filter(x=>['Employment of a Day Performer','Loanout of a Day Performer'].includes(x.value))
        dropdownModel.options = newOptions;
      }
    );
    
    return dropdownModel;
  }


  /**Sets the title fields of the form */
  public selectedProjectTitle(event): void {
    this.projectId = null;
    this.blankContractForm.get('title').setValue(new ProjectTitleModel('N', event.projectId, event.id, event.title));
    let projectTitle = this.blankContractForm.get('title').value;
    this.projectId = projectTitle.projectId;
    this.getProdCompanyDropdown(this.projectId);/**gets the prod company data by sending the project id of the project title */
    this.productionDisabled = false;
    this.addressOptions=new DropdownTypeAheadModel(null, null, null, null, []);
  }

  public getProdCompanyDropdown(projectId): any {
    const options: any[] = [];
    let dropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, options);
    this.dealService.getProductionCompaniesByProject(projectId).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          delete data[i].links;
          options.push({
            value: data[i].entityName,
            id: data[i].partyId,
            data: data[i]
          });
        }
        dropdownModel.options = options;
       this.prodCompany = dropdownModel;
      }
    );
  }

  /**Gets address options for the dropdown */
  public getAddress(companyPartyId) {
    let options: any = []
    let dropdownModel: DropdownTypeAheadModel = new DropdownTypeAheadModel(null, null, null, null, options);
    this.commonModuleService.getCompanyDetailsFromDb(companyPartyId).subscribe(
      (data) => {
        if (data) {
          for (let i = 0; i < Object.keys(data).length; i++) {
            delete data[i].links;
            options.push(
              data[i].name
            );
          }
          dropdownModel.options = options
          this.addressOptions = dropdownModel
        }
        else
     this.addressOptions=new DropdownTypeAheadModel(null, null, null, null, []);
      }
    );
  }

  /**Select method for typeahead dropdown which is common for all the dropdowns */
  public onSelectOccupationEvent(selectedVal: any, fControl: string, listName: string): void {
    if (fControl === 'contractType' && selectedVal!==null) {
      this.isSaveDisabled = false;
    }
    else if (fControl === 'contractType' && selectedVal===null) {
      this.isSaveDisabled = true;
    }

    else if(fControl === 'production')
    {
      if(selectedVal)
      {
    this.getAddress(selectedVal.id)
    this.addressDisabled=false;
      }
     else if(selectedVal===null)
      {
        this.addressOptions=new DropdownTypeAheadModel(null, null, null, null, []);
        this.blankContractForm.get('address').setValue(null);
      }
   
    }
    this.blankContractForm.get(fControl).patchValue(selectedVal);
  }

  public saveProject(event?: Event): void {
    if (this.blankContractForm.valid) {
      const project = this.convertToProject(this.blankContractForm.getRawValue());
      this.powersearchBlankReportModalEvent.emit({ formData: project, action: event })
      this.close();
    }
    else {
      this.validateFormFields(this.blankContractForm);
    }
  }

  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  /**To fetch the form values from the form and store it ProjectTitleModelinto an object */
  private convertToProject(data): BlankContractModel {
    let title:string=null
    if(data.title)
{
  if(data.title.title !== undefined)
  {
    title=data.title.title 
  }

  else if(typeof data.title !=='object' && data.title !==null)
  {
   title=data.title;
  }
}

    let contractType = data.contractType ? data.contractType.id : null
    let production = data.production ? data.production.value : null
    let signatories = data.signatories ? data.signatories.value : null
    return new BlankContractModel(
      data.address,
      contractType,
      production,
      signatories,
      title
    );
  }

  public static validateModelValue(field: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      if (control.value[field] === null || control.value[field] === undefined) {
        return { 'noModelValue': { value: control.value[field] } };
      } else {
        return null;
      }
    };
  }

}
