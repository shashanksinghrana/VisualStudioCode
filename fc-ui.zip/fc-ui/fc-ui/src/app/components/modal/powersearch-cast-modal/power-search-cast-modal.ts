import { Component, Input, OnDestroy, EventEmitter, Output, TemplateRef, ViewChild, OnInit } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder } from '@angular/forms';
import { ModalService } from '../../../services/events/modal-event-service';

@Component({
  selector: 'powersearch-cast-modal',
  templateUrl: './power-search-cast-modal.html',
  styleUrls: ['./powersearch-cast-modal.scss']
})
export class PowersearchCastModal implements OnInit, OnDestroy {


  public modal: NgbModalRef;
  public selection: any[] = [];

  /** Defines Option for modal window */
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-size-300'
  };

  @Input() public isChecked;
  @Input() public label;
  @Input() public singleButton;

  public modalReference: any;

  @Input() public modalTitle: string = 'Report Detail - Cast List';

  /** The content of the modal to be displayed when opened. */
  @ViewChild('powersearchCastModalContent') private powersearchCastModalContent: TemplateRef<any>;

  @Output() public powersearchCastReportModalEvent: any = new EventEmitter<any>();

  @Input() public showButton: boolean = false;

  constructor(private modalService: NgbModal, private fb: FormBuilder, private eventService: ModalService) {
    // this.eventService.onOpenModal()
    //   .subscribe(value => {
    //     this.modal = this.modalService.open(this.eventService);
    //   });
    // this.eventService.onCloseModal()
    //   .subscribe(value => {
    //     this.modal.close();
    //   });
  }

  public close(event?: Event): void {
    this.modalReference.close(event);
  }


  public ngOnInit() {
    this.selection.push('IncludePerformerAddress');
    this.selection.push('IncludeDealInfo');
  }

  public ngOnDestroy(): void {
  }

  public selectOption(event: any, type: string): any {
    const check = event.currentTarget ? event.currentTarget.checked : false;
    if (check) {
      this.selection.push(type);
    } else {
      const index: number = this.selection.indexOf(type);
      if (index !== -1) {
        this.selection.splice(index, 1);
      }
    }

  }

  public open() {
    this.modalReference = this.modalService.open(this.powersearchCastModalContent, this.modalOptions);
    this.eventService.openModal();
  }

  public submit(event?: Event): void {
    if (this.selection.length !== 0) {
      this.powersearchCastReportModalEvent.emit({ formData: this.selection, action: event });
      this.modalReference.close();
    }
  }
}
