import { Component, Input, EventEmitter, Output, TemplateRef, ViewChild } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder } from '@angular/forms';
import { ModalService } from '../../../services/events/modal-event-service';

@Component({
  selector: 'powersearch-billing-modal',
  templateUrl: './power-search-billing-modal.html',
  styleUrls: ['./powersearch-billing-modal.scss']
})
export class PowersearchBillingModal {
  public modal: NgbModalRef;

  /** Defines Option for modal window */
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-size-300'
  };

  public modalReference: any;

  @Input() public modalTitle: string = 'Report Detail - Billing List';

  /** The content of the modal to be displayed when opened. */
  @ViewChild('powersearchBillingModalContent') private powersearchBillingModalContent: TemplateRef<any>;

  @Output() public powersearchBllingReportModalEvent: any = new EventEmitter<any>();

  @Input() public showButton: boolean = false;

  constructor(private modalService: NgbModal, private fb: FormBuilder, private eventService: ModalService) {
  }

  public close(event?: Event): void {
    this.modalReference.close(event);
  }

  public sortingOrderSelected: string;

  public selectType(type: string): any {
    if (type.length !== 0) {
      this.sortingOrderSelected = type;
    }
  }

  public open() {
    this.sortingOrderSelected = 'LastName';
    this.modalReference = this.modalService.open(this.powersearchBillingModalContent, this.modalOptions);
    this.eventService.openModal();
  }

  public submit(event?: Event): void {
    if (this.sortingOrderSelected.length !== 0) {
      this.powersearchBllingReportModalEvent.emit({ formData: this.sortingOrderSelected, action: event });
      this.modalReference.close();
    }
  }
}
