import { Component, Input, OnDestroy, EventEmitter, Output, TemplateRef, ViewChild, OnInit } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ModalService } from '../../../services/events/modal-event-service';
import { CurrentUserPersistService } from '../../../services/persist/user/current-user-persist.service';

@Component({
  selector: 'powersearch-casting-data-modal',
  templateUrl: './powersearch-casting-data-modal.html',
  styleUrls: ['./powersearch-casting-data-modal.scss']
})
export class PowersearchCastingDataModal implements OnInit, OnDestroy {


  public modal: NgbModalRef;
  public selection: any[] = [];
  public castingDataForm: FormGroup;

  /** Defines Option for modal window */
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-size-300'
  };

  @Input() public isChecked;
  @Input() public label;
  @Input() public singleButton;

  public modalReference: any;
  public mask: any = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  @Input() public modalTitle: string = 'Report Detail - Casting Data';

  /** The content of the modal to be displayed when opened. */
  @ViewChild('powersearchCastingDataModalContent') private powersearchCastingDataModalContent: TemplateRef<any>;

  @Output() public powersearchCastingDataReportModalEvent: any = new EventEmitter<any>();

  @Input() public showButton: boolean = false;

  constructor(private modalService: NgbModal, private fb: FormBuilder, private eventService: ModalService, private currentUser: CurrentUserPersistService) {}

  public close(event?: Event): void {
    this.castingDataForm.reset();
    this.modalReference.close(event);
  }


  public ngOnInit() {
    this.selection.push('stuntOnly');
    this.castingDataForm = this.fb.group({
      'submittedBy': this.fb.control(this.currentUser.getCurrentUser().firstName + ' ' + this.currentUser.getCurrentUser().lastName),
      'phoneNo': this.fb.control(null),
      'stuntOnly': this.fb.control(null),
    });
  }

  public ngOnDestroy(): void {
  }

  public open() {
    this.modalReference = this.modalService.open(this.powersearchCastingDataModalContent, this.modalOptions);
    this.eventService.openModal();
    this.castingDataForm.get('submittedBy').patchValue(this.currentUser.getCurrentUser().firstName + ' ' + this.currentUser.getCurrentUser().lastName);
  }

  public submit(event?: Event): void {
    if (this.selection.length !== 0) {
      const project = this.castingDataForm.getRawValue();
      this.powersearchCastingDataReportModalEvent.emit({ formData: project, action: event });
      this.castingDataForm.reset();
      this.modalReference.close();
    }
  }
}
