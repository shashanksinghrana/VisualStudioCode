import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { RadioButtonModel, PowersearchEventService } from 'c2c-common-lib';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'fc-powersearch-textfields',
  templateUrl: './powersearch-textfields.component.html',
  styleUrls: ['./powersearch-textfields.component.scss']
})
export class PowerSearchTextFieldsComponent implements OnInit, OnDestroy {

  public initFirstTime: boolean = false;

  /** The name of the form to add this control to. Should probably always be 'powersearchForm' */
  @Input() public formName: FormGroup;

  /** The name of the array to add to the form. Should share the name of the field in the given 'choice' */
  @Input() public formArrName: string;

  @Input() public choiceData: any;

  private isAllChecked: boolean = true;

  public resetData: any;
  @Input('resetData')
  set _resetData(data: any) {
    this.clearFields(data);
  }

  /** Defines whether the 'choice' is expanded or collapsed (collapsed by default) */
  public isOpen: boolean = false;
  @Input('isOpen')
  set _isOpen(open: boolean) {
    this.isOpen = open;
    // Don't reload list again once clicked on list.
    if (open && !this.initFirstTime) {
      // Wait still option load
      setTimeout(() => {
        this.initFirstTime = true;
        const formArr = this.formName.get(this.formArrName) as FormArray;
        const criteria = formArr.controls[0];
        criteria.patchValue({ formChanged: true });
        this.buildForm();
        formArr.markAsDirty();
        formArr.markAsTouched();
      }, 100);
    }
  }

  /** Defines the values to be displayed in the checklist.
   *  Ideally these should be of type {@link LookupModel} to be consistent with the application */
  public options: any[] = [];

  @Input() public textfieldData: any;

  public operation: any;
  public radioMultiOptions: RadioButtonModel =
    new RadioButtonModel('thisRadioTitle', [
      { title: 'Contains', checkedByDefault: true, disabled: false, showTitle: true },
      { title: 'Exactly Equals', checkedByDefault: false, disabled: false, showTitle: true }
    ]);

  public radioOptions: RadioButtonModel =
    new RadioButtonModel('Add criteria', [{ title: 'OR', checkedByDefault: false, disabled: false, showTitle: true }]);

  private subscriptions: Subscription = new Subscription();

  constructor(private psEventService: PowersearchEventService, private fb: FormBuilder) {
  }

  public ngOnInit() {
    this.addSubscriptions();
    this.options = this.textfieldData.options;
    this.createFormControl();
  }

  private buildForm(): void {
    const formArr = this.formName.get(this.formArrName) as FormArray;
    const controls = formArr.controls[0];
    const textOptionArr = this.textfieldData.searchTextValues;
    this.options = this.textfieldData.options;
    this.prepareChecklist(true);
    controls.patchValue({ allchecked: this.isAllChecked });

    // Edit case
    if (textOptionArr) {
      const items = controls.get('items') as FormArray;
      this.clearFormArray(items);
      textOptionArr.forEach(opt => {
        items.push(this.buildCriteria(opt));
      });
      this.prepareCriteriaObj(controls);
    }
  }

  private prepareChecklist(conditional: boolean, checked?: boolean) {
    this.isAllChecked = true;
    if (conditional) {
      this.options.forEach((option) => {
        option.checked = (option.checked === false) ? false : true;
        if (!option.checked) {
          this.isAllChecked = false;
        }
      });
    } else {
      this.options.forEach((option) => {
        option.checked = checked;
      });
    }
  }

  public trackByID(index, item): number {
    return item ? item.id : undefined;
  }

  private addSubscriptions(): void {
    this.subscriptions.add(
      this.psEventService.getCategoryRemoved().subscribe(fieldName => {
        if (this.formArrName === fieldName) {
          this.resetFormFields();
        }
      })
    );
    this.subscriptions.add(
      this.psEventService.getCustomCategoryRemoved().subscribe(
        (response) => {
          if (this.formArrName === response.field) {
            this.removeSelection(response.item);
            this.patchAllChecked();
          }
        }
      ));
  }

  private removeSelection(item) {
    this.options.forEach((option) => {
      if (option.name === item.optionValue) {
        option.checked = false;
        return false;
      }
    });
  }

  private clearFormArray(formArray: FormArray): void {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  private createFormControl(): void {
    const formGroup = this.formName.get(this.formArrName) as FormArray;
    this.clearFormArray(formGroup);
    formGroup.push(this.fb.group({
      values: this.fb.array([]),
      optionValue: new FormControl(null),
      allchecked: new FormControl(true),
      options: this.fb.array(this.options),
      items: this.fb.array([this.buildCriteria()]),
      value: true,
      formChanged: new FormControl(false)
    }));

  }

  public prepareCriteriaObj(criteria, data?: any): void {
    const items = criteria.get('items');
    let itemStr = '';
    if (!data) {
      for (const item of items.controls) {
        const text = item.get('searchTxt').value;
        this.operation = item.get('operation').value;
        if (text) {
          if (itemStr) {
            itemStr += ' OR ' + ' ' + (this.operation ? this.operation + ' ' : '') + text;
          } else {
            itemStr = (this.operation ? this.operation + ' ' : '') + text;
          }
        }
      }
      this.clearFormArray(criteria.get('values'));
      if (itemStr) {
        this.options.forEach((option) => {
          if (option.checked) {
            criteria.get('values').push(this.fb.group({
              value: option.name + ' ' + itemStr,
              operation: this.operation,
              condition: 'OR',
              optionValue: option.name
            }));
          }
        });
      }
    } else {
      this.clearFormArray(criteria.get('values'));
      this.options.forEach((option) => {
        if (option.checked) {
          data.forEach(element => {
            if (option.name === element.optionValue) {
              criteria.get('values').push(this.fb.group({
                value: element.value,
                operation: element.operation,
                condition: element.condition,
                optionValue: element.optionValue
              }));
            }
          });
        }
      });
    }
  }

  public addCriteria(criteria, data?: any): void {
    const items = criteria.get('items') as FormArray;
    if (!data) {
      items.push(this.buildCriteria());
    } else {
      items.push(this.buildCriteria(data));
    }
  }

  public buildCriteria(data?: any): FormGroup {
    if (!data) {
      return this.fb.group({
        operand: '',
        operation: 'Contains',
        searchTxt: new FormControl('', Validators.required)
      });
    } else {
      return this.fb.group({
        operand: data.operand,
        operation: data.operation,
        searchTxt: new FormControl(data.searchTxt, Validators.required)
      });
    }
  }

  /* Handle the functionality of the "Select All" checkbox when any check box unchecked*/
  public changeSelectAll(selectAll, checked, criteria): void {
    if (selectAll) {
      this.prepareChecklist(false, checked);
      criteria.patchValue({ allchecked: checked });
    } else {
      if (!checked) {
        criteria.patchValue({ allchecked: false });
      } else {
        let isValid = true;
        this.options.forEach((option) => {
          if (!option.checked) {
            isValid = false;
            return false;
          }
        });
        if (isValid) {
          criteria.patchValue({ allchecked: true });
        }
      }
    }

    this.prepareCriteriaObj(criteria);
  }

  private clearFields(data: any) {
    if (data && data.reset) {
      if (this.textfieldData) {
        this.textfieldData.searchTextValues = null;
        this.textfieldData.checkBoxValues = [];
        this.options = this.textfieldData.options;
        this.prepareChecklist(false, true);
      }
      this.createFormControl();
      this.initFirstTime = false;
    }
  }

  private resetFormFields(): void {
    this.isOpen = false;
    this.choiceData.isOpen = false;
    this.clearFields({ reset: true });
    const formArr = this.formName.get(this.formArrName) as FormArray;
    formArr.markAsPristine();
    formArr.markAsUntouched();
  }

  /**
   * Used to remove a item from the 'Your Selections' section as well as unchecking it.
   * Listens to an event from the {@link PowersearchComponent} before removing the item.
   *
   * @param fieldName The name of the field to remove the item from.
   * @param index The index position of the item to remove.
   */
  public patchAllChecked(): void {
    const formArray = this.formName.get(this.formArrName) as FormArray;
    const criteria = formArray.controls[0];
    criteria.patchValue({ allchecked: false });
    this.prepareCriteriaObj(criteria);
  }

  public removeItem(criteria, index): void {
    const formArray = criteria.get('items') as FormArray;
    if (index !== 0) {
      const preIndex = index - 1;
      formArray.at(preIndex).patchValue({ operand: null });
    }
    formArray.removeAt(index);
    this.prepareCriteriaObj(criteria);
  }

  public ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

}
