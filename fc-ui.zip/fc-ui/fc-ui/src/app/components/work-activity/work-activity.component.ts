import { Component, OnInit, ViewChild, ViewChildren, ElementRef } from '@angular/core';
import { DropdownModel, AddButtonModel, ToasterService, UnsavedChangesService } from 'c2c-common-lib';
import { SharedService } from '../../services/http/shared/shared.service';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder } from '@angular/forms';
import { DealService } from '../../services/http/deal/deal.service';
import { DealModel } from '../../models/deal/deal.model';
import { DealEventService } from '../../services/events/deal-event.service';
import { Observable } from 'rxjs/Observable';
import { PermissionList } from '../../enums/permission-list.enum';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';

@Component({
  selector: 'fc-work-activity',
  templateUrl: './work-activity.component.html',
  styleUrls: ['./work-activity.component.scss']
})
export class WorkActivityComponent implements OnInit {
  public addButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add');
  public detailGroups: any[];
  public formula: any;
  public deal: DealModel;
  public dealID: any;
  public itemsArray: any;
  public loading: boolean = false;
  public loanout: any;
  public check: boolean = true;
  public items: any[] = [];
  public workActivityForm: FormGroup;
  public performer: any;
  public data: any;
  public myClass = [];
  public isActivity: boolean = false;
  public showDescript: boolean = false;
  public activityForm: FormGroup;
  public event: string;
  public desc: any;
  public editedActivityArray: any[] = [];
  public viewPermission: PermissionList = PermissionList.dealCreateEditView;
  public editPermission: PermissionList = PermissionList.dealCreateEditEdit;
  public disableForm: boolean = false;
  @ViewChild('defaultSpan') public defaultSpan: any;
  @ViewChild('saveAndContinue') public saveAndContinue: any;
  @ViewChildren('editedDatefield') public editedDatefield: any;
  @ViewChildren('scrollToTop') public scrollToTop: any;

  constructor(
    private fb: FormBuilder,
    private sharedService: SharedService,
    private toasterService: ToasterService,
    private unsavedChangesService: UnsavedChangesService,
    private dealService: DealService,
    private dealEventService: DealEventService,
    private userPermissionService: UserPermissionService) {
    this.disableForm = this.createEditPermission();
  }

  public ngOnInit(): void {
    this.workActivityForm = this.fb.group({
      'activityForm': this.fb.array([]),
    });
    this.activityForm = this.fb.group({});
    this.deal = this.dealService.deal;
    this.loanout = this.dealService.loanout;
    this.getWorkActivityFormula();
  }

  /*
  * ngAfterViewInit
  */
  public ngAfterViewInit(): void {
    this.defaultSpan.nativeElement.focus();
  }

  public loadWorkActivityDetails(): void {
    const dealId: string = this.dealService.getDealId();
    this.dealID = dealId;
    if (dealId !== null && dealId !== 'new') {
      this.getWorkActivityDetails(dealId);
    }
  }
  public getWorkActivityDetails(dealId): void {
    this.dealService.getWorkActivityDetails(dealId).subscribe(
      (data) => {
        if (data) {
          data.forEach((obj) => {
            const currId = obj.id.toString();
            this.workActivityForm.controls[currId] = this.fb.array([]);
            this.itemsArray = {
              id: currId,
              formArray: this.workActivityForm.get(currId) as FormArray
            };
            obj.data.forEach((o) => {
              this.itemsArray.formArray.push(this.buildItem(this.formula, o));
            });
          });
        }
      },
      (err) => {
        console.error('Error getting Work Activity details', err);
        this.toasterService.error('There was a problem getting Work Activity details', 'ERROR');
      }
    );
  }

  /**
   * Determines if the form has any unsaved changes, if so, transition message
   * will be displayed. If user confirms, routing continues to navigate.
   */
  public canDeactivate(): Observable<boolean> | boolean {
    if (this.activityForm.dirty || this.activityForm.touched) {
      this.unsavedChangesService.openModal();
      return this.unsavedChangesService.onCloseModal();
    }
    return true;
  }

  /**
  * Gets the Formula, for dynamically populating the form elements based off of the defined formula.
  *
  */
  public getWorkActivityFormula(): void {
    this.dealService.getWorkActivityFormula().subscribe(
      (res: any) => {
        this.data = res;
        this.formula = this.data[0];
        this.activityForm = this.fb.group({});
        this.detailGroups = this.groupDetails(this.formula.details.slice());
        this.loadWorkActivityDetails();
      }
    );
  }

  public isLastElement(group): boolean {
    return (group.name === this.detailGroups[this.detailGroups.length - 1].name);
  }

  /**
   * Calculates and returns the bootstrap grid class (i.e. 'col-1', 'col-6', etc.) for the group.
   * This gives dynamic control to handle many different formula structures.
   *
   *
   * @param group The group to calculate the class on.
   */
  public getFormulaClass(group): string {
    const colSize: number = group.details.length > 1 ? group.details.length : 1;
    let size: number = colSize <= 4 ? colSize : 4;
    if (this.isLastElement(group)) {
      size = 2;
    }
    if (group.name === 'Description') {
      size = 3;
    }
    return 'col-' + size;
  }

  /**
   * Determines what label will be displayed for the FormControl (Group name that spans, or individual element name).
   *
   * @param group The given group to retrieve label from.
   */
  public getFormulaLabel(group): string {
    return group.name ? group.name : group.details[0].label;
  }

  /**
   * Reads the current formula and groups each FormControl by their groupType. This is needed for grouping FormControls that
   *  have a label that spans multiple elements, and are related in some capacity.
   *
   * @param details The formula details to loop over and group together.
   */
  public groupDetails(details: Array<any>): any[] {
    let currGroupNum: number;
    let prevGroupNum: number;
    const groups: any[] = [];

    let i = details.shift();
    while (i !== undefined) {
      const validator = (i.requiredFlag === true) ? [Validators.required] : [];
      if (i.validationExpression) {
        validator.push(Validators.pattern(new RegExp(i.validationExpression)));
      }

      this.activityForm.addControl(i.fieldName, new FormControl(i.defaultValue, validator));

      if (i.fieldType.name === 'DROP_DOWN') {
        i.options = this.getDropdownOptions(i.fieldTypeLookupType);
      }

      if (i.groupType) {
        currGroupNum = i.groupType.id;
        if (currGroupNum !== prevGroupNum) { // If different, then new group
          groups.push({ name: i.groupType.name, details: [i] });
        } else {                             // If same, add to current group
          groups[(groups.length - 1)].details.push(i);
        }
        prevGroupNum = i.groupType.id;
      } else {
        groups.push({ name: i.label, details: [i] }); // Single group
      }
      i = details.shift();
    }
    this.getChanges(this.activityForm);
    this.setCurrentState(this.activityForm);
    return groups;
  }

  /**
   * Calculates and returns the bootstrap grid class (i.e. 'col-1', 'col-6', etc.) for the inner group details.
   * This gives dynamic control to handle many different formula structures.
   *
   * @param detail The formula detail (individual FormControl) to calculate size on.
   * @param group The group that the detail belongs to.
   */
  public getSubFormulaClass(detail, group): string {
    let count: number = 0;
    group.details.forEach((g) => {
      if (g.fieldType.name === 'TEXT_AREA') {
        count++;
      }
    });
    const numOfCols: number = group.details.length - count;
    const avg: number = Math.round((12 - count) / numOfCols);
    let size: number;
    if (detail.fieldType.name === 'TEXT_AREA') {
      size = 1;
    } else {
      size = avg;
    }
    if (detail.label === 'Note') {
      return 'd-inherit col-' + size;
    }

    return 'col-' + size;
  }

  /**
   * Checks to see if the FormGroup is invalid.
   *
   * @param formGroup The FormGroup to check.
   * @param field The FormControl to check in the given FormGroup.
   */
  public isFormInvalid(formGroup, field): boolean {
    return formGroup.get(field).invalid && formGroup.get(field).touched;
  }

  /**
  * Gets the dropdown options for each dropdown in the form.
  *
  * @param lookupType The dropdown type to get based on the lookupType.
  */
  public getDropdownOptions(lookupType: string): DropdownModel {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.sharedService.getDropdown(lookupType).subscribe(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            data: data[i]
          });
        }
      }
    );
    return dropdownModel;
  }

  /**
   * When the 'edit' icon (pencil) is pressed, enables the given FormGroup in edit mode (no longer disabled).
   *
   * @param formGroup The FormGroup to edit.
   */
  public editItem(formGroup, index): void {
    this.activityForm.markAsDirty();
    this.activityForm.markAsTouched();
    this.setCurrentState(formGroup);
    formGroup.enable();
    this.editedActivityArray[index] = {
      'index': index,
      'value': formGroup.getRawValue()
    };

    let array = this.editedDatefield.toArray(); 
    let dateField: HTMLInputElement ;
    for (let i = 0; i < array.length; i++) {
      const element = array[i];
      if (i === index) {
        dateField = element.datetimepicker.nativeElement;
      }
    }
    setTimeout(() => dateField.focus());
  }

  public setCurrentState(formGroup): void {
    formGroup.currentState = { ...formGroup };
  }

  /**
   * Clears (resets) the FormGroup.
   */
  public clearItem(): void {
    this.activityForm.reset();
  }

  /**
   * When the 'cancel' icon (x) is pressed, resets the given FormGroup's value to the original value.
   *
   * @param formGroup The FormGroup to reset previous values on.
   */
  public cancelItem(formGroup, index, isDisable?): void {
    formGroup.patchValue(formGroup.currentState.value);
    this.editedActivityArray.splice(index, 1);
    for (const group of this.detailGroups) {
      for (const detail of group.details) {
        if (detail.fieldType.name === 'DROP_DOWN') {
          const key = detail.fieldName;
          if (detail.options.dropdownValue != null) {
            detail.options.dropdownValue = formGroup.value[key];
            if (detail.options.dropdownValue != null) {
              detail.options.selection = detail.options.dropdownValue.value;
              detail.selection = detail.options.dropdownValue.value;
            } else {
              detail.options.selection = null;
              detail.selection = null;
            }
          }
        }
      }
    }
    if (isDisable) {
      Object.keys(formGroup.controls).forEach((field) => {
        formGroup.controls[field].disable();
      });
    } else {
      Object.keys(formGroup.controls).forEach((field) => {
        formGroup.controls[field].markAsUntouched();
      });
    }
  }

  /**
   *
   * @param work The work to build FormArray on.
   * @param groups The current grouping of formula details.
   */
  public buildFeeGroups(groups): void {
    if (!this.itemsArray) {
      const termArray = <FormArray>this.workActivityForm.controls.activityForm;
      this.itemsArray = {
        formArray: termArray,
      };
    }
  }

  /**
   *
   * @param formula The  formula that acts as a blueprint for creating the FormControls.
   * @param data The Form data to pull the values out of.
   */
  public buildItem(formula: any, data: any): FormGroup {
    const fg: FormGroup = this.fb.group({});
    formula.details.forEach(detail => {
      const validator = (detail.requiredFlag === true) ? Validators.required : [];
      fg.addControl(detail.fieldName, new FormControl({ value: data[detail.fieldName], disabled: true }, validator));
    });
    fg.addControl('id', new FormControl({ value: data.id, disabled: true }));
    this.getChanges(fg);
    return fg;
  }

  /**
  * Sets up the calculations for the fee type formulas (i.e. rate x guarantee = totalAmount).
  *
  * @param formGroup The FormGroup to setup calculations on.
  */
  private getChanges(formGroup): void {
    this.desc = formGroup.get('description');
    if (formGroup.get('activityLookupId')) {
      const activityLookup = formGroup.get('activityLookupId');
      activityLookup.valueChanges.subscribe(val => {
        this.desc = formGroup.get('description');
        const descLabel = (activityLookup.value) ? activityLookup.value.data.displayLabel : '';
        if (descLabel.length > 0) {
          this.desc.setValue(descLabel);
        } else {
          this.desc.setValue(null);
        }
      });
    }
  }

  /**
   * When the cancel icon (x) at the top of the page is pressed, returns user to last history item.
   * TODO: hook this up once deal flow is ready.
   */
  public cancelWorkActivity() {
    this.toasterService.info('Navigating back', 'Cancel Success');
  }

  public addItem(): void {
    if (this.activityForm.valid) {
      this.buildFeeGroups(this.detailGroups.slice());
      this.sortByDate(false, this.activityForm.value);
      this.clearItem();
      Object.keys(this.activityForm.controls).forEach((field) => {
        const control = this.activityForm.get(field);
        control.markAsUntouched();
      });
    } else {
      this.validateFormFields(this.activityForm);
    }
  }

  public getWorkActivityData() {
    let activityData = [];
    if (this.itemsArray && this.itemsArray.formArray) {
      activityData = this.itemsArray.formArray.getRawValue();
      if (this.editedActivityArray.length) {
        this.editedActivityArray.forEach((value, index) => {
          if (value) {
            activityData[index] = value.value;
          }
        });
      }
    }
    return activityData;
  }

  /**
   * Saves / Updates the workdata details when the user clicks the 'Save' or 'Save & Continue' icon.
   *
   * @param type The navigation type to take.
   */
  public saveWorkActivity(type?): void {
    this.activityForm.markAsUntouched();
    this.activityForm.markAsPristine();
    const activityData = this.getWorkActivityData();
    if (activityData) {
      this.dealService.saveWorkActivity(activityData).subscribe(res => {
        if (type === 'continue') {
          this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: this.dealID });
        } else {
          this.dealEventService.pageSavedEvent({ type: type, pageTo: 'summary', dealId: this.dealID });
        }
        this.workActivityForm.markAsUntouched();
        this.workActivityForm.markAsPristine();
        this.toasterService.success('Successfully saved Work Activity details.', 'Save Success');
      }, err => {
        console.log(err);
        this.toasterService.error('Failed to save Work Activity details.', 'Error');
      });
    }
  }


  public deleteItem(controlsIndex: number): void {
    let j: number;
    const itemsArrayIndex = [];
    itemsArrayIndex.push(this.itemsArray);
    this.sortByDate(true);
    for (const item in itemsArrayIndex) {
      itemsArrayIndex[Number(item)].formArray.controls.splice(0, 1);
      itemsArrayIndex[Number(item)].formArray.value.splice(0, 1);
    }
    let element = document.getElementById('deleteItemButton'+(controlsIndex+1));
    if (element !== null) {
      let span = <HTMLElement>element.children[0];
      setTimeout(() => span.focus());
    } else {
      this.saveAndContinue.setFocus();
    }
    this.activityForm.markAsDirty();
    this.activityForm.markAsTouched();
  }

  /**
  * When the 'add' icon (+) is pressed on the given (editable) FormGroup, updates the FormGroup to the values input by user.
  *
  * @param formGroup The FormGroup to update.
  */
  public updateItem(formGroup, index): void {
    this.activityForm.markAsDirty();
    this.activityForm.markAsTouched();
    if (formGroup.valid) {
      Object.keys(formGroup.controls).forEach((field) => {
        formGroup.controls[field].disable();
      });
      this.sortByDate(true);
      this.editedActivityArray.splice(index, 1);
    } else {
      this.validateFormFields(formGroup);
    }
  }
  /**
   * Called when the given form is invalid in order to mark the invalid controls.
   *
   * @param formGroup The FormGroup to mark.
   */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  public createEditPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === false) {
      return true;
    } else if (this.userPermissionService.hasPermission(this.viewPermission) === true && this.userPermissionService.hasPermission(this.editPermission) === true) {
      return false;
    }
  }

  public onEnterKeyPressed(formGroup, event) {
    if (event) {
      const startDate = formGroup.get('startDate');
      startDate.patchValue(event);
    }
  }

  /**
   * Called to sort all the rows by date in Descending order.
   *
   */
  public sortByDate(isEditMode: boolean, activityForm?: any) {
    const formArr = this.itemsArray.formArray as FormArray;
    const arr: any[] = formArr.value;
    while (formArr.length) {
      formArr.removeAt(0);
    }
    if(!isEditMode) {
      arr.push(activityForm);
    }
    arr.sort((a, b) => {
      return <any>new Date(b.startDate) - <any>new Date(a.startDate);
    });
    arr.forEach(item => {
      this.itemsArray.formArray.push(this.buildItem(this.formula, item));
    });
  }

  public onSelectDropdown() {
    this.scrollToTop.first.nativeElement.scrollIntoView({behavior: "smooth", block: "start", inline: "start"});
  }
}
