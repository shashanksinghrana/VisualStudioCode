import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppResolver } from './app-resolver';
import { AllProjectsComponent } from './modules/all-projects/all-projects.component';
import { MyProjectsComponent } from './modules/my-projects/my-projects.component';
import { DealsAndContractsComponent } from './modules/deals-and-contracts/deals-and-contracts.component';
import { PowersearchReportsComponent } from './modules/powersearch-reports/powersearch-reports.component';
import { HomeComponent } from './modules/home/home.component';
import { UserAdminComponent } from './modules/user-admin/user-admin.component';
import { ProjectDetailComponent } from './modules/project-detail/project-detail.component';
import { CreateEditProjectComponent } from './modules/create-edit-project/create-edit-project.component';
import { PerformersComponent } from './components/performers/performers.component';
import { BillingComponent } from './components/billing/billing.component';
import { LocationsComponent } from './components/locations/locations.component';
import { WorkWeekComponent } from './components/work-week/work-week.component';
import { CrewComponent } from './components/crew/crew.component';
import { CanDeactivateGuard } from './services/guards/can-deactivate-guard.service';
import { CreateDealComponent } from './modules/create-deal/create-deal.component';
import { StatusDatesComponent } from './components/status-dates/status-dates.component';
import { NameProjectDetailsComponent } from './components/name-project-details/name-project-details.component';
import { CompensationComponent } from './components/compensation/compensation.component';
import { LoanoutComponent } from './components/loanout/loanout.component';
import { NoticesPaymentsComponent } from './components/notices-payments/notices-payments.component';
import { CreditComponent } from './components/credit/credit.component';
import { PerqsComponent } from './components/perqs/perqs.component';
import { WorkActivityComponent } from './components/work-activity/work-activity.component';
import { SummaryComponent } from './components/summary/summary.component';
import { ProjectResolverService } from './services/resolvers/project-resolver.service';
import { ProjectTypeDropdownResolver } from './services/resolvers/dropdown/project-type-dropdown-resolver.service';
import { StudioDropdownResolver } from './services/resolvers/dropdown/studio-dropdown-resolver.service';
import { CreateEditProjectResolver } from './services/resolvers/create-edit-project-resolver.service';
import { ConfirmedByDropdownResolver } from './services/resolvers/dropdown/confirmed-by-dropdown-resolver.service';
import { StatusDropdownResolver } from './services/resolvers/dropdown/status-dropdown-resolver.service';
import { DealResolverService} from './services/resolvers/deal-resolver.service';
import { PerqsResolverService } from './services/resolvers/perq-resolver.service';
import { CreditResolverService } from './services/resolvers/credit-resolver.service';
import { LoanoutResolverService } from './services/resolvers/loanout-resolver.service';
import { NameProjectsResolverService } from './services/resolvers/name-projects-resolver.service';
import { LoanoutDropdownService } from './services/resolvers/dropdown/loanout-dropdowns-resolver.service';
import { NoticesPaymentsResolverService } from './services/resolvers/notices-payments-resolver.service';
import { CanActivateDealGuard } from './services/guards/can-activate-deal-guard.service';
import { PowersearchResolverService } from './services/resolvers/powersearch-resolver.service';
import { AccentedCharacterService } from './services/http/shared/accented-character.service';

/** Routes object that contains each route definition in FeatureCasting */
const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'useradmin', component: UserAdminComponent },
  { path: 'allProjects', component: AllProjectsComponent },
  { path: 'myProjects', component: MyProjectsComponent },
  { path: 'dealsContracts', component: DealsAndContractsComponent },
  { path: 'powersearch', component: PowersearchReportsComponent,
                         resolve: { powersearch: PowersearchResolverService } },
  { path: 'projectDetails/:projectId', component: ProjectDetailComponent, resolve: { detail: ProjectResolverService },
    children: [
      { path: 'performers', component: PerformersComponent },
      { path: 'billing', component: BillingComponent, resolve: { options: ConfirmedByDropdownResolver } },
      { path: 'locations', component: LocationsComponent, resolve: { resolve: AppResolver } },
      { path: 'workWeek', component: WorkWeekComponent },
      { path: 'crew', component: CrewComponent, resolve: { resolve: AppResolver } },
      { path: 'statusDates', component: StatusDatesComponent, resolve: { options: StatusDropdownResolver } },
      { path: '', redirectTo: 'performers', pathMatch: 'full' }
    ]
  },
  { path: 'createEditProject',
        component: CreateEditProjectComponent,
        canDeactivate: [CanDeactivateGuard],
        resolve: { dropdowns: CreateEditProjectResolver, resolve: AppResolver }
  },
  { path: 'createEditProject/:projectId', component: CreateEditProjectComponent, canDeactivate: [CanDeactivateGuard],
                                          resolve: { dropdowns: CreateEditProjectResolver, companyModalData: AppResolver } },
  { path: 'createDeal/:dealId', component: CreateDealComponent, resolve: { deal: DealResolverService },
    children: [
      {
        path: 'namesProjectDetails', component: NameProjectDetailsComponent,
        canDeactivate: [CanDeactivateGuard],
        resolve: { nameProjects: NameProjectsResolverService, resolve: AppResolver }
      },
      {
        path: 'loanout', component: LoanoutComponent,
        canActivate: [CanActivateDealGuard], canDeactivate: [CanDeactivateGuard],
        resolve: { loanout: LoanoutResolverService, dropdowns: LoanoutDropdownService }
      },
      {
        path: 'noticesPayments', component: NoticesPaymentsComponent,
        canActivate: [CanActivateDealGuard], canDeactivate: [CanDeactivateGuard],
        resolve: { noticesPayments: NoticesPaymentsResolverService, resolve: AppResolver }
      },
      {
        path: 'compensation', component: CompensationComponent,
        canActivate: [CanActivateDealGuard], canDeactivate: [CanDeactivateGuard]
      },
      {
        path: 'credit', component: CreditComponent,
        canActivate: [CanActivateDealGuard], canDeactivate: [CanDeactivateGuard],
        resolve: { credit: CreditResolverService }
      },
      {
        path: 'perqs', component: PerqsComponent,
        canActivate: [CanActivateDealGuard], canDeactivate: [CanDeactivateGuard],
        resolve: { perq : PerqsResolverService }
      },
      {
        path: 'workActivity', component: WorkActivityComponent,
        canActivate: [CanActivateDealGuard], canDeactivate: [CanDeactivateGuard]
      },
      {
        path: 'summary', component: SummaryComponent,
        canActivate: [CanActivateDealGuard]
      }
    ]
  },
  { path: '', redirectTo: 'allProjects', pathMatch: 'full' },
];

/**
 * The AppRoutingModule
 *
 * Contains all Routing information for the FeatureCasting application.
 * We use hashes in URLs to fix problems with refreshing, and individual URL targeting.
 */
@NgModule({
  imports: [
    NgbModule.forRoot(),
    RouterModule.forRoot(appRoutes, {useHash: true})
  ],
  exports: [
    RouterModule
  ],
  providers: [
    AppResolver,
    CanActivateDealGuard,
    CanDeactivateGuard,
    ProjectResolverService,
    CreateEditProjectResolver,
    ProjectTypeDropdownResolver,
    StudioDropdownResolver,
    DealResolverService,
    PerqsResolverService,
    LoanoutResolverService,
    LoanoutDropdownService,
    CreditResolverService,
    NoticesPaymentsResolverService,
    NameProjectsResolverService,
    PowersearchResolverService,
    AccentedCharacterService,
    ConfirmedByDropdownResolver,
    StatusDropdownResolver
  ]
})
export class AppRoutingModule { }
