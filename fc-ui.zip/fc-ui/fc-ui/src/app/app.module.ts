import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { DatePipe } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppResolver } from './app-resolver';
import { UtilsService } from './utils/utils.service';
import { CommonModuleService } from './services/http/deal/add-edit-performer/common-module.service';
import { UserPermissionService } from './services/http/permission/user-permission.service';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HeaderModule, FooterModule, GridModule, SidebarModule, WizardModule,
         ToasterService, CommonSharedModule, ModalModule, TypeAheadModule, FormModule } from 'c2c-common-lib';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AllProjectsModule } from './modules/all-projects/all-projects.module';
import { SharedCreateEditPersonModule } from './modules/shared-create-edit-person/shared-create-edit.module';
import { AddEditPerformerModule } from './modules/add-edit-performer/add-edit-performer.module';
// import { CreateCompanyModule } from './modules/create-production-company/create-company.module';
import { MyProjectsModule } from './modules/my-projects/my-projects.module';
import { DealsAndContractsModule } from './modules/deals-and-contracts/deals-and-contracts.module';
import { PowersearchReportsModule } from './modules/powersearch-reports/powersearch-reports.module';
import { HomeModule } from './modules/home/home.module';
import { UserAdminModule } from './modules/user-admin/user-admin.module';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CreateEditProjectModule } from './modules/create-edit-project/create-edit-project.module';
import { ProjectDetailModule } from './modules/project-detail/project-detail.module';
import { CreateDealModule } from './modules/create-deal/create-deal.module';
import { SharedService } from './services/http/shared/shared.service';
import { CurrentUserService } from './services/http/users/current-user.service';
import { SummaryEventService } from './services/events/summary-event.service';
import { PowersearchModalService } from './services/events/powersearch-modal-event-service';
import { ModalService } from './services/events/modal-event-service';
import { ToastModule } from 'ng2-toastr';
import { LoadingIndicatorService } from './services/other/loading-indicator.service';
import { CurrentUserPersistService } from './services/persist/user/current-user-persist.service';
import { LoadingIndicatorInterceptorService } from './services/other/loading-indicator-interceptor.service';
import { AutoLogoutService } from './services/other/autoLogout.service';
import { SessionService } from './services/other/session.service';





@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRoutingModule,
    FooterModule,
    SidebarModule.forRoot(),
    WizardModule.forRoot(),
    GridModule.forRoot(),
    NgbModule.forRoot(),
    HeaderModule.forRoot(),
    FormModule,
    HomeModule,
    AllProjectsModule,
    SharedCreateEditPersonModule,
    AddEditPerformerModule,
    CreateEditProjectModule,
   // CreateCompanyModule,
    MyProjectsModule,
    DealsAndContractsModule,
    PowersearchReportsModule,
    ProjectDetailModule,
    UserAdminModule,
    CreateDealModule,
    ToastModule.forRoot(),
    ModalModule.forRoot(),
    CommonSharedModule,
    TypeAheadModule.forRoot()
  ],
  providers: [HttpClient, AppResolver, DatePipe, SharedService, CurrentUserService, CurrentUserPersistService,
              ToasterService, LoadingIndicatorService, UtilsService, SummaryEventService, UserPermissionService,
              AutoLogoutService,
              SessionService,
              ModalService, PowersearchModalService, CommonModuleService, {
      provide: HTTP_INTERCEPTORS,
      useFactory: (service: LoadingIndicatorService) => new LoadingIndicatorInterceptorService(service),
      multi: true,
      deps: [LoadingIndicatorService]
    }
  ],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule { }
