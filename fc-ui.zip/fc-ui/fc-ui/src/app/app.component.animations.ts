import { trigger, state, style, transition, animate, group, AnimationTriggerMetadata } from '@angular/animations';

export const SlideInOutAnimation: AnimationTriggerMetadata = trigger('slideInOut', [
      state('in', style({
        'transform': 'scale(1)',
        'transform-origin': 'left'
      })),
      state('out', style({
        'transform': 'scale(0, 1)',
        'transform-origin': 'left',
        'width': '0px'
      })),
      transition('in => out', [group([
          animate('500ms ease-in-out', style({
        'transform': 'scale(0, 1)',
        'transform-origin': 'left',
        'width': '0px'
          }))
      ]
      )]),
      transition('out => in', [group([
          animate('500ms ease-in-out', style({
        'transform': 'scale(1)',
        'transform-origin': 'left',
        'width': '250px'
          }))
      ]
      )])
  ]);
