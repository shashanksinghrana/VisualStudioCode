import { Component, Input, OnDestroy , ChangeDetectorRef, EventEmitter,
         Output, TemplateRef, ViewChild, ViewContainerRef, Renderer2 } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { PeopleModelDetails, PeopleOutputParamsModel, PeopleInputParamsModel,
         ToasterService, TypeAheadDisplayResultModel, DropdownModel } from 'c2c-common-lib';
import { AccentedCharacterService } from '../../services/http/shared/accented-character.service';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { PowersearchModalService } from '../../services/events/powersearch-modal-event-service';
import { Subscription } from 'rxjs/Subscription';
import { ToastsManager } from 'ng2-toastr';

@Component({
  selector: 'fc-create-edit-person-modal',
  templateUrl: './shared-create-edit-person-modal.html',
  styleUrls: ['./shared-create-edit-person-modal.scss'],
  providers: [CommonModuleService, ToasterService, AccentedCharacterService]
})
export class CreateEditPersonModal implements OnDestroy {

   /** The content of the modal . */
   @ViewChild('addEditPersonContent') private addEditPersonContent: TemplateRef<any>;

  public companyDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public displayCompanyDataResults: TypeAheadDisplayResultModel;
  public displayContactDataResults: TypeAheadDisplayResultModel;
  public displayPeopleDataResults: TypeAheadDisplayResultModel;
  public emailDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public entityTypeCompanies: any = [];
  public entityTypePeople: any = [];
  public isDataLoaded: boolean = false;
  @Input() public isDefaultOccupation: boolean = false;
  public locationDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public modal: NgbModalRef;
   /** Defines Option for modal window */
   private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-full-screen'
  };
  public modalReference: any;
  public occupationDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public peopleData: PeopleModelDetails = new PeopleModelDetails();
  public peopleParamModel: PeopleInputParamsModel;
  @Output() public personCancel: EventEmitter<any> = new EventEmitter();
  @Output() public personSaved: EventEmitter<any> = new EventEmitter();
  public phoneDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public pickListData: any;
  @Output() public powersearchReportModalEvent: any = new EventEmitter<any>();
  public projectId: any;
  public repId: any;
  public selectCountryAddDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public selectStateAddDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public selectTypeAddDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public socialMediaDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  private subscription: Subscription = new Subscription();
  public typeDropdown: DropdownModel = new DropdownModel('', '', '', '', []);


  constructor(public changeDetector: ChangeDetectorRef,
              private vRef: ViewContainerRef,
              public commonService: CommonModuleService,
              private modalService: NgbModal,
              private accentedCharacterService: AccentedCharacterService,
              private eventService: PowersearchModalService,
              private toasterService: ToasterService,
              private toastr: ToastsManager,
              private renderer: Renderer2) {
                this.toastr.setRootViewContainerRef(vRef);
                this.initTypeahead();
  }

  /**Method to add crew ad default occupation */
  public addDefaultOccupation(peopleData): void {
      if ((peopleData.occupations === undefined ||
          !peopleData.occupations.length) && this.isDefaultOccupation) {
          peopleData.occupations[0] = { 'id': '',
                                     'occupationId': 1498,
                                     'partyId': '',
                                     'occupationName': 'Crew'};
      this.peopleData.occupations = peopleData.occupations;
    } else {
       return;
    }
  }

  public cancelEvent(outParams: PeopleOutputParamsModel): void {
    this.commonService.navigatePage(`/projectDetails/${this.projectId}/crew`);
    this.close();
  }

  public close(event?: Event): void {
     this.modalReference.close(event);
     this.repId = '';
  }

   /** Method to call the lookup services   */
   private getDropdownLookupData(): any {
    this.occupationDropdown = this.commonService.getDropDownOptionsList('CONTACT_OCCUPATION');
    this.typeDropdown = this.commonService.getDropDownOptionsList('CONTACT_TYPE');
    this.phoneDropdown = this.commonService.getDropDownOptionsList('PHONE_TYPE');
    this.emailDropdown = this.commonService.getDropDownOptionsList('EMAIL');
    this.socialMediaDropdown = this.commonService.getDropDownOptionsList('SOCIAL_MEDIA');
    this.selectStateAddDropdown = this.commonService.getDropDownOptionsList('countrystate/STATES/US');
    this.selectTypeAddDropdown = this.commonService.getDropDownOptionsList('ADDRESS_TYPE');
    this.selectCountryAddDropdown = this.commonService.getCountryOptionsList('countrystate/COUNTRIES');
    this.entityTypePeople = this.commonService.getOptionsList('CONTACT_ENTITY_TYPE');
    this.entityTypeCompanies = null;
  }
  
  /** Get Dropdown options list and sort it in proper manner */
  public getDropdownOptions(lookupType: string) {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    this.commonService.getDropDownOptionsList(lookupType).subscribe(
      (data) => {
        this.pickListData = data.picklists.sort((a, b) => {
            const nameA = a.value.toLowerCase();
            const nameB = b.value.toLowerCase();
            if (nameA < nameB) { return -1; }
            if (nameA > nameB) { return 1; }
            return 0;
        });
        for (let i = 0; i < Object.keys(this.pickListData).length; i++) {
          options.push({
              value: this.pickListData[i].value,
              route: '',
              id: this.pickListData[i].id,
              data: this.pickListData[i]
          });
        }
      }
    );
    return dropdownModel;
  }

  private getRepData(id): void {
    this.commonService.getRepDetails(id).subscribe(res => {
      this.setDataonLoad();
      this.modalReference = this.modalService.open(this.addEditPersonContent, this.modalOptions);
      this.eventService.openModal();
    });
  }

  private initTypeahead(): any {
    this.displayPeopleDataResults = {
      filterType: 'CONTACT_ONLY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'teamMembers'],
        display: '`${data.primaryName ?` (alias for ${data.primaryName}) `:` (team of ${data.teamMembers})`}`',
        notAllColumnsRequired: true
      },
      metaDataColumns: {
        BUSINESS_CREATIVE: ['occupation', 'agency'],
        PRODUCTION: ['occupation', 'ssnEndChars'],
        CASTING: ['agency', 'ssnEndChars'],
        default: ['occupation', 'ssnEndChars']
      },
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.commonService,
        get: 'getContactOnly'
      }
    };

    this.displayCompanyDataResults = {
      filterType: 'COMPANY_ONLY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`'
      },
      metaDataColumns: {
        BUSINESS_CREATIVE: ['occupation', 'agency'],
        PRODUCTION: ['occupation', 'ssnEndChars'],
        CASTING: ['agency', 'ssnEndChars'],
        default: ['occupation', 'ssnEndChars']
      },
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.commonService,
        get: 'getCompany'
      }
    };

    this.displayContactDataResults = {
      filterType: 'CONTACT_ONLY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`'
      },
      metaDataColumns: {
        BUSINESS_CREATIVE: ['occupation', 'agency'],
        PRODUCTION: ['occupation', 'ssnEndChars'],
        CASTING: ['agency', 'ssnEndChars'],
        default: ['occupation', 'ssnEndChars']
      },
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.commonService,
        get: 'getContactOnly'
      }
    };
  }

  public ngOnInit(): any {
    this.isDataLoaded = true;
  }

  public open(data?: any): void {
    if (data) {
        this.projectId = data ? data.projectId : '';
        this.repId = data ? data.partyId : '';
        this.getRepData(this.repId);
    } else {
      this.modalReference = this.modalService.open(this.addEditPersonContent, this.modalOptions);
      this.eventService.openModal();
      this.setDataonLoad();
    }
  }


  public setDataonLoad() {
    if (this.repId) {
      this.peopleData = this.commonService.getPersonData();
    } else {
      this.peopleData = new PeopleModelDetails();
    }

    if (!this.peopleData.entityTypeId) {
      this.peopleData.entityTypeId = 1279;
    }

    const companyTypeAheadService = {
      serviceClass: this.commonService,
      serviceAccentedClass: this.accentedCharacterService,
      getCompanyDetailsFromDb: 'getCompanyDetailsFromDb',
      saveParty: 'saveParty',
      saveAlias: 'saveAlias',
      getTalentDetails: 'getTalentDetails',
      getStateListFromDb: 'getStateListFromDb',
      getaccentedCharacters: 'getAccentedChars',
      saveCompanyAlias: 'saveAlias',
      saveCompany: 'saveParty',
      saveLocationCompanies: 'saveLocationCompanies',
      getNames: 'getNames'
    };

    this.getDropdownLookupData();
    const peopleTypeAheadService = {
      serviceClass: this.commonService,
      getPeopleDetailsFromDb: 'getRepDetails'
    };
    this.peopleParamModel = new PeopleInputParamsModel(this.peopleData, this.occupationDropdown,
      this.typeDropdown, this.displayPeopleDataResults,
      this.displayCompanyDataResults, this.locationDropdown, this.entityTypePeople, this.entityTypeCompanies,
      this.phoneDropdown, this.emailDropdown,
      this.socialMediaDropdown, this.displayContactDataResults, this.selectTypeAddDropdown, this.selectStateAddDropdown,
      this.selectCountryAddDropdown, companyTypeAheadService, peopleTypeAheadService);
    this.isDataLoaded = true;
    this.changeDetector.detectChanges();
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.repId = '';
  }

  public submit(outParams: PeopleOutputParamsModel): void {
    if (null !== outParams && null !== outParams.peopleData && outParams.validPeople !== false) {
      this.peopleData = outParams.peopleData;
      this.peopleData.updatedByApp = 'Feature Casting';
      this.repId = '';
      const dataSet = this.commonService.getUserData();
      this.peopleData.dataSet = dataSet.masterDataset;
      this.addDefaultOccupation(outParams.peopleData);
      this.renderer.addClass(document.body, 'c2c-window-modal');
      this.commonService.insertUpdatePeopleDetails(this.peopleData).subscribe(
        (res) => {
          this.renderer.removeClass(document.body, 'c2c-window-modal');
          this.toasterService.success('Record Saved', 'Success!');
          this.personSaved.emit({peopleData: res});
          this.close();
        },
        (err) => {
          this.renderer.removeClass(document.body, 'c2c-window-modal');
          this.toasterService.error('Internal server error', 'Error!');
        });
    }
  }
}
