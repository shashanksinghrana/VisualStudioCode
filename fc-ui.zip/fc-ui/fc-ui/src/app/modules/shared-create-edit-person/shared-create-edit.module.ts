import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PeopleModule } from 'c2c-common-lib';
import { CreateEditPersonModal } from './shared-create-edit-person-modal';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { PowersearchModalService } from '../../services/events/powersearch-modal-event-service';

@NgModule({
  imports: [
    CommonModule,
    PeopleModule
  ],
  declarations: [CreateEditPersonModal],
  providers: [CommonModuleService, PowersearchModalService],
  exports: [
    CreateEditPersonModal
  ]
})
export class SharedCreateEditPersonModule { }
