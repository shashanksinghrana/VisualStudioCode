import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectDetailComponent } from './project-detail.component';
import { ButtonModule, AuditModule, GridModule, ModalModule, ToasterService } from 'c2c-common-lib';
import { AppRoutingModule } from '../../app-routing.module';
import { PerformersComponent } from '../../components/performers/performers.component';
import { BillingComponent } from '../../components/billing/billing.component';
import { LocationsComponent } from '../../components/locations/locations.component';
import { WorkWeekComponent } from '../../components/work-week/work-week.component';
import { CrewComponent } from '../../components/crew/crew.component';
import { StatusDatesComponent } from '../../components/status-dates/status-dates.component';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { BillingEventService } from '../../services/events/billing-event.service';
import { LocationEventService } from '../../services/events/location-event.service';
import { StatusDatesEventService } from '../../services/events/status-dates-event.service';
import { SharedCreateEditPersonModule } from '../../modules/shared-create-edit-person/shared-create-edit.module';
import { WorkWeekEventService } from '../../services/events/work-week-event.service';
import { CreateCompanyModule } from '../../modules/create-production-company/create-company.module';
/**z
 * The ProjectDetailModule
 *
 * Module that contains all Project Detail related components.
 */
@NgModule({
  imports: [
    CommonModule,
    AppRoutingModule,
    ButtonModule,
    AuditModule,
    ModalModule,
    GridModule,
    SharedCreateEditPersonModule,
    CreateCompanyModule
  ],
  declarations: [
    ProjectDetailComponent,
    PerformersComponent,
    BillingComponent,
    LocationsComponent,
    WorkWeekComponent,
    CrewComponent,
    StatusDatesComponent
  ],
  providers: [ProjectDetailService,
              BillingEventService,
              LocationEventService,
              ToasterService,
              StatusDatesEventService,
              WorkWeekEventService]
})
export class ProjectDetailModule { }
