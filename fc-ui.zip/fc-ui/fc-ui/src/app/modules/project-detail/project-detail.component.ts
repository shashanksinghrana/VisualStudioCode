import { Component, ViewContainerRef, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuditModel, CancelButtonModel } from 'c2c-common-lib';
import { ProjectDetailModel } from '../../models/project/project-detail.model';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';
import { ToastsManager } from 'ng2-toastr';
import { Router } from '@angular/router';
import { SharedService } from '../../services/http/shared/shared.service';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { PermissionList } from '../../enums/permission-list.enum';

/**
 * The ProjectDetailComponent
 *
 * Component for displaying details related to a specific project.
 */
@Component({
  selector: 'fc-project-detail',
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.scss']
})
export class ProjectDetailComponent {
  public audit: AuditModel;
  public cancelButtonOptions: CancelButtonModel = new CancelButtonModel('fc', 'projectDetails', 'navigate', '/allProjects');
  public editProjectRoute: string;
  public projectDetails: any;
  private projectId: number;
  public tabs: Array<Object>;
  public disabledEdit: boolean = false;
  public projectDetailView: PermissionList = PermissionList.projectDetailView;
  public projectDetailEdit: PermissionList = PermissionList.projectDetailUpdate;


  /**
   * The Constructor for ProjectDetailComponent
   *
   * @param route The active route.
   * @param projectDetailService The Project Details Service for getting data.
   */
  constructor(
    private router: Router,
    private sharedService: SharedService,
    private route: ActivatedRoute,
    private projectDetailService: ProjectDetailService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private userPermissionService: UserPermissionService
  ) {
    this.toaster.setRootViewContainerRef(vcr);
    this.route.params.subscribe(res => this.projectId = res.projectId);
    this.tabs = this.projectDetailService.getTabItems();
    this.getProjectDetailsData();
    this.disabledEdit = this.editPermission();
  }

  public ngOnInit(): void {
    this.sharedService.projectDetailsStorageObject = [];
  }

  /**
   * Get all the data related to project details and assigns it to component properties.
   */
  public getProjectDetailsData() {
    this.route.data.subscribe(
      (data: { detail: ProjectDetailModel }) => {
        this.projectDetails = data.detail;
        this.audit = new AuditModel(data.detail.createDate, data.detail.createdBy, data.detail.updateDate, data.detail.updatedBy);
        this.editProjectRoute = 'createEditProject/' + this.projectId;
      },
      (error) => {
        console.log('Error when getting project details', error);
      }
    );
  }

  public toNavigate() {
    this.sharedService.projectDetailsStorageObject.push({
      value: {
        'aka': this.projectDetails.title.aka,
        'id': this.projectDetails.title.id,
        'projectId': this.projectDetails.title.projectId,
        'title': this.projectDetails.title.title
      }
    });
    this.router.navigate(['/powersearch']);
  }

  public editPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.projectDetailView) === true &&
      this.userPermissionService.hasPermission(this.projectDetailEdit) === false) {
      return true;
    } else if (this.userPermissionService.hasPermission(this.projectDetailView) === true &&
      this.userPermissionService.hasPermission(this.projectDetailEdit) === true) {
      return false;
    }
  }


}
