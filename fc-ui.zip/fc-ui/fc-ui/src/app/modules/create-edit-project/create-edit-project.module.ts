import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CreateEditProjectComponent } from './create-edit-project.component';
import { FormModule, ButtonModule, TypeAheadModule, TypeAheadEventService, UrlResolverService,
         CommonSharedModule, ModalModule, TypeAheadModalModule, TypeAheadPersistService, TypeAheadNameListingModule } from 'c2c-common-lib';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateCompanyModule } from '../create-production-company/create-company.module';
import { CreateEditProjectService } from '../../services/http/create-edit-project/create-edit-project.service';
import { SummaryEventService } from '../../services/events/summary-event.service';
/**
 * The CreateEditProjectModule
 *
 * Module that contains all Create/Edit Project related components.
 */
@NgModule({
  imports: [
    CommonModule,
    ButtonModule,
    FormModule,
    FormsModule,
    ModalModule.forRoot(),
    TypeAheadModule,
    ReactiveFormsModule,
    CreateCompanyModule,
    NgbModule.forRoot(),
    TypeAheadModalModule.forRoot(),
    TypeAheadNameListingModule.forRoot(),
    CommonSharedModule.forRoot()
  ],
  declarations: [CreateEditProjectComponent],
  providers: [CreateEditProjectService, TypeAheadEventService, TypeAheadPersistService, SummaryEventService, UrlResolverService]
})
export class CreateEditProjectModule { }
