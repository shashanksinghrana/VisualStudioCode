import { CurrentUserPersistService } from './../../services/persist/user/current-user-persist.service';
import { Component, OnInit, ElementRef, ViewChild, ViewContainerRef, Renderer2, ViewChildren } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ProjectModel } from '../../models/project/project.model';
import { CancelButtonModel, DropdownModel, TypeAheadModel, AddButtonModel, UnsavedChangesService, AddAliasAKAModel,
         TypeAheadDisplayResultModel, TypeAheadSaveModel, AddAliasModel, ToasterService, EmptyIfNull,
         TypeAheadEventService } from 'c2c-common-lib';
import { CreateEditProjectService } from '../../services/http/create-edit-project/create-edit-project.service';
import { SharedService } from '../../services/http/shared/shared.service';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { ModalGenericComponent } from 'c2c-common-lib';
import { AccentedCharacterService } from '../../services/http/shared/accented-character.service';
import { FormGroup, FormBuilder, Validators, FormArray, AbstractControl } from '@angular/forms';
import { ToastsManager } from '../../../../node_modules/ng2-toastr';
import { ProjectTitleModel } from '../../models/project/project-title.model';
import { FormValidators } from '../../utils/validation/form-validators';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { PermissionList } from '../../enums/permission-list.enum';
import { TypeAheadService } from '../../services/http/type-ahead/type-ahead.service';
import { VALID } from '../../../../node_modules/@angular/forms/src/model';

const DEFAULT_TYPE: string = 'Feature';


/**
 * The CreateEditProjectComponent.
 *
 * This component is used to create and edit a new or existing project. Edit Project is determined by
 * passing an ID in the URL to the page.
 */
@Component({
  selector: 'fc-create-edit-project',
  templateUrl: './create-edit-project.component.html',
  styleUrls: ['./create-edit-project.component.scss'],
  providers: [TypeAheadService]
})
export class CreateEditProjectComponent implements OnInit {

  @ViewChild('accentedChars') private accentedChars: any;
  public accentedCharValues: any;
  @ViewChild('accentedTitleModal') private accentedTitleModal: any;
  public accentedModalName: string = 'AccentedModalHeader';
  public addButtonOptions: AddButtonModel = new AddButtonModel('', '', '', '', '', 'Add');
  /** modal reference */
  @ViewChild('addEditComapny') public addEditComapny: any;
  @ViewChild('addNameCompanyModal') public addNameCompanyModal: any;
  public addProdCompanyForm: FormGroup;
  public assignedToUsers: DropdownModel = new DropdownModel('', '', '', '', []);
  public cancelButtonOptions: CancelButtonModel;
  public createdByApp: String;
  public createEditForm: FormGroup;
  public displayProdCompanyData: TypeAheadDisplayResultModel;
  public displayProjectTitleData: TypeAheadDisplayResultModel;
  public editModalCompData: any;
  public isCompanyModalOpen: boolean = false;
  public isEdit: boolean = false;
  public prodCompany: boolean = true;
  public initialFocus: boolean = true;
  @ViewChild('prodCompTypeAhead')  public prodCompTypeAhead: any;
  public productionCompanies: DropdownModel = new DropdownModel('', '', '', '', []);
  public projectId: number;
  public projectTypes: DropdownModel;
  @ViewChild('sameTitleModal') public sameTitleModal: ModalGenericComponent;
  public signatories: DropdownModel = new DropdownModel('', '', '', '', []);
  public statuses: DropdownModel = new DropdownModel('', '', '', '', []);
  public studios: DropdownModel;
  @ViewChild('top') public top: ElementRef;
  /** Type ahead modal configurtion */
  public typeAheadCompanyModalConfig: object = {
      title: 'Add New Company name',
      label: 'This is a label',
      showAddAlias: true,
      displayNameAs: true,
      allowOnlyOneAlias: true,
      checkAddAsAlias: true,
      modalName: 'modalCompanyHeaderName'
  };
  public typeAheadType: string = 'COMPANY';
  public typeAheadValueCompany: any;
  public unions: DropdownModel = new DropdownModel('', '', '', '', []);
  public disableForm: boolean = false;
  public createEditProjectEdit: PermissionList = PermissionList.createEditProjectEdit;
  public createEditProjectView: PermissionList = PermissionList.createEditProjectView;
  public formDisabled: boolean = false;
  public validateAddedProdCompany: boolean = true;
  public typeAheadTitleForProjectTitle: string = 'Title';
  public typeAheadTypeForProjectTitle: string = 'COMPANY';
  public typeAheadAddSameName: boolean = true;
  public disableSearchName: boolean = false;
  public hasNoResultsCallback: boolean = false;
  public projectTitleListNameResult: any[] = [];
  public showTypeAhead: boolean = false;
  public typeAheadDataService: any;
  public typeAheadFocus: boolean = true;
  public selectedName: any;
  public disabledFields: boolean = false;

  public radioBtnOpt: any = { name: 'talentName', id: 'talentIdName' };
  public selectedTitleData: any;
  public listNameTitle: string = 'Click radio button to indicate current name';
  private listTalent: Array<object> = [];
  public confirmDuplicateName: boolean = false;
  private resolverAssignedList: any;
  public disableAka: boolean = false;

  public typeAheadTitleModalConfig: any = {
    title: 'Add New Project name',
    label: 'This is a label',
    showAddAlias: false,
    displayNameAs: true,
    additionalFieldsDisplayed: true,
    allowOnlyOneAlias: true,
    checkAddAsAlias: true,
    modalName: 'projectTitleTypeaheadModal',
    hideTypeAhead: true
  };

  public fieldNameForTitleModal = 'Project';

  public DEFAULT_STUDIO:string='';

  @ViewChild('accentedCharsForProjectTitle') public accentedCharsForProjectTitle: any;
  public accentedCharValuesForProjectTitle: any;
  public accentedModalNameForProjectTitle: string = 'AccentedModalHeaderTitle';

  @ViewChild('typeAheadModalForProjectTitle') public typeAheadModalForProjectTitle: any;
  @ViewChild('titleTypeAhead') public titleTypeAhead: any;
  @ViewChild('creationDate') public creationDate: any;
  @ViewChild('defaultSpan') public defaultSpan: any;
  @ViewChild('unionDropdown') public unionDropdown: any;
  @ViewChildren('prodCompTypeAheadAdded') public prodCompTypeAheadAdded: any;
  /**
   * Constructor for the CreateEditProjectComponent
   *
   * @param route The active route.
   * @param createEditProjectService The Create/Edit Project Service for all project-related services.
   * @param router The router to handle all navigation.
   * @param sharedService The Shared Service for common services.
   * @param unsavedChangesService The Unsaved Changes Service for the unsaved changes modal.
   * @param fb FormBuilder instance for building form elements.
   */
  constructor(
    private route: ActivatedRoute,
    private createEditProjectService: CreateEditProjectService,
    private router: Router,
    private sharedService: SharedService,
    private unsavedChangesService: UnsavedChangesService,
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef,
    private talentService: CommonModuleService,
    public accentdCharService: AccentedCharacterService,
    private renderer: Renderer2,
    private userPermissionService: UserPermissionService,
    private currentUser: CurrentUserPersistService,
    private typeAheadEventService: TypeAheadEventService,
    private currentUserPersistService:CurrentUserPersistService
  ) {
    this.toaster.setRootViewContainerRef(vcr);
    this.route.params.subscribe((res) => {
      this.projectId = res.projectId;
      this.isEdit = this.projectId ? true : false;
      this.addSubscriptions();
    });
    this.disableForm = this.createPermission();
    this.typeAheadEventService.getCurrentItemSelected().subscribe(item => {
      if (item.item && item.listName === 'mainListTitle') {
        const title = this.createEditForm.get('title').value;
        const akaNames = this.createEditForm.get('akaNames').value;
        this.createEditForm.get('title').setValue(new ProjectTitleModel('N', null, null, item.item.typeAheadDisplayName ? item.item.typeAheadDisplayName : item.item.title));

        const akaIndexForDelete = akaNames.findIndex(aka => (aka.title === item.item.typeAheadDisplayName));

        if (akaIndexForDelete > -1) {
          akaNames.splice(akaIndexForDelete, 1);
          akaNames.push(title);
        }
      }
    });
  }

  private addSubscriptions(): void {
    let defaultStudio:any;
    this.route.data.subscribe(
      (data: { dropdowns: any }) => {
        this.projectTypes = data.dropdowns.types;
        this.studios = data.dropdowns.studios;
        defaultStudio= this.studios.options.filter(x => x.id === this.currentUserPersistService.getCurrentUser().studioId)
        this.DEFAULT_STUDIO = defaultStudio[0].value;
        this.studios.options.sort(function(a,b){
          return a.value.localeCompare(b.value);
      });
        this.statuses = data.dropdowns.statuses;
        this.resolverAssignedList = data.dropdowns.assignedTo;
        if (!this.isEdit) {
          this.assignedToUsers = this.resolverAssignedList;
        }
        this.productionCompanies = data.dropdowns.productionCompanies;
        this.unions = data.dropdowns.unions;
        this.signatories = data.dropdowns.signatories;
      }
    );
  }

  /**
   * This is called when the user enters an AKA name and hits 'Enter'. Adds the AKA
   * name the the 'akaNames' list.
   *
   * @param name The AKA name entered.
   */
  public addAka(name: string) {
    if (name && name.match(/\S/g)) {
      this.createEditForm.get('akaNames').value.push(new ProjectTitleModel('Y', null, null, name.trim()));
    }
  }

    /**
   * Adds another line of values to the casting company set based on the dropdowns
   * selected for Production Company, Union and Signatory. Line is added by getting
   * and setting these values to the Project model.
   */
  public addLine(): void {
    if (this.addProdCompanyForm.valid && this.prodCompany && this.validateAddedProdCompany) {
      const prodArray = <FormArray>this.createEditForm.controls.castingCompanySet;
      let primaryInd = this.addProdCompanyForm.get('primary').value ? this.addProdCompanyForm.get('primary').value : false;
      if (!prodArray.controls.length) {
        primaryInd = true;
      }
      prodArray.push(this.fb.group({
        'productionCompany': this.fb.control({ value: this.addProdCompanyForm.value['productionCompany'], disabled: true }),
        'union': this.fb.control({ value: this.addProdCompanyForm.value['union'], disabled: true }),
        'unionNote': this.fb.control({ value: this.addProdCompanyForm.value['unionNote'], disabled: true }),
        'signatoryUser': this.fb.control({ value: this.addProdCompanyForm.value['signatoryUser'], disabled: true }),
        'primaryInd': this.fb.control({ value: primaryInd, disabled: true })
      }));
      this.addProdCompanyForm.reset();
      this.addProdCompanyForm.markAsUntouched();
      if (primaryInd) {
        this.updatePrimaryIndicator(prodArray.controls.length - 1);
      }
      this.prodCompany = false;
    } else {
      if (!this.addProdCompanyForm.get('productionCompany').value) {
        this.validateAddedProdCompany = false;
      }
      this.validateFormFields(this.addProdCompanyForm);
    }
  }

  /**
   * Determines if the form has any unsaved changes, if so, transition message
   * will be displayed. If user confirms, routing continues to navigate.
  */
  public canDeactivate(): Observable<boolean> | boolean {
    if(!this.disableForm){
      if ((this.createEditForm.dirty || this.createEditForm.touched) ||
      (this.addProdCompanyForm.dirty && this.addProdCompanyForm.touched && !this.isCompanyModalOpen) ||
          (this.createEditForm.get('castingCompanySet').dirty && this.createEditForm.get('castingCompanySet').touched)) {
            this.unsavedChangesService.openModal();
            return this.unsavedChangesService.onCloseModal();
      }
      return true;
    }
    return true;
  }

  /**
   * Resets (clears) the given FormGroup.
   *
   * @param formGroup The FormGroup to reset.
   */
  public clearForm(formGroup): void {
    formGroup.reset();
    this.validateAddedProdCompany = true;
    formGroup.markAsUntouched();
  }

  public close(): void {
    this.sameTitleModal.close();
    // reset typeahead
  }

  public closeProjectTitleModal(event) {
    const projectTitle = this.createEditForm.get('title');
    if (event === 'CANCEL') {
      this.titleTypeAhead.typeAheadField.nativeElement.value = '';
      projectTitle.setValue(new ProjectTitleModel());
    } else {
      this.typeAheadEventService.duplicateNameConfirmed({config: this.typeAheadTitleModalConfig, type: this.typeAheadTypeForProjectTitle });
    }
  }

  /** Method to handle unsaved modal popup when Add/Edit company modal is open */
  public companyModalCloseEvent(event): void {
     if (event === 'close') {
       this.isCompanyModalOpen = true;
     } else {
       this.isCompanyModalOpen = false;
     }
     setTimeout(() => document.getElementById('clearBtn').focus());
  }

  /**
   * This function converts the date from string "yyyy-mm-dd" to date when getting from back end.
   *
   * @param stringDate The date to convert.
   */
  public convertToDate(stringDate): Date {
    const dateArray = stringDate.split('-');
    return new Date(dateArray[0], dateArray[1], dateArray[2]);
  }

  /**
   * Converts the createEditForm to a persistable object for saving/updating Project.
   *
   * @param data The form data to convert.
   */
  private convertToProject(data): ProjectModel {
    return new ProjectModel(
      data.akaNames,
      data.creationDate,
      this.projectId,
      data.notes,
      data.castingCompanySet,
      data.title,
      data.releaseDate,
      data.sagProdId,
      data.sapCode,
      data.startDate,
      data.status? data.status.id: null,
      data.studio,
      data.type?data.type.id:null,
      data.wrapDate,
      data.assignedTo.userId
    );
  }

  /**
   * This function is run for disabling the ability to edit a casting company set.
   *
   * @param formGroup The FormGroup to disable.
   */
  public disableCastingCompanySetEdit(formGroup): void {
    formGroup.reset(formGroup.currentState.value);
    Object.keys(formGroup.controls).forEach((field) => {
      formGroup.controls[field].disable();
    });
  }

  public disableFieldsForProjectsOfDiffModules(): void {
    if (this.isEdit && this.createdByApp !== 'Feature Casting') {
      this.createEditForm.controls['creationDate'].disable();
      this.createEditForm.controls['title'].disable();
      this.createEditForm.controls['akaNames'].disable();
      this.createEditForm.controls['startDate'].disable();
      this.createEditForm.controls['wrapDate'].disable();
      this.createEditForm.controls['releaseDate'].disable();
      this.createEditForm.controls['studio'].disable();
      this.createEditForm.controls['status'].disable();
      this.createEditForm.controls['type'].disable();
      this.disableAka = true || this.disableForm;
    }
  }

  public enableFieldsForDiffModule(): void {
    if (this.isEdit && this.createdByApp !== 'Feature Casting') {
      this.createEditForm.controls['creationDate'].setErrors(null);

      this.createEditForm.controls['title'].setErrors(null);

      this.createEditForm.controls['akaNames'].setErrors(null);
      this.createEditForm.controls['startDate'].setErrors(null);
      this.createEditForm.controls['wrapDate'].setErrors(null);
      this.createEditForm.controls['releaseDate'].setErrors(null);
      this.createEditForm.controls['studio'].setErrors(null);
      this.createEditForm.controls['status'].setErrors(null);
      this.createEditForm.controls['type'].setErrors(null);
    }
  }

  /** Method to open modal popup for addig new prod company */
  public editProdCompany(formGroup: any): void {
    const prodCompanyData = formGroup.controls['productionCompany'].value;
    this.addEditComapny.open(prodCompanyData, this.projectId, true);
  }

  /**
   * This function is used to begin the process of editing a casting company set.
   *
   * @param formGroup The FormGroup to edit.
   */
  public enableCastingCompanySetEdit(formGroup, index): void {
    formGroup.currentState = { ...formGroup };
    formGroup.enable();
    this.prodCompany = true;
    formGroup.markAsDirty();
    formGroup.markAsTouched();

    let array = this.prodCompTypeAheadAdded.toArray();
    let prodCompanyTypeahead: HTMLInputElement ;
    for (let i = 0; i < array.length; i++) {
      const element = array[i];
      if (i === index) {
        prodCompanyTypeahead = element.typeAheadField.nativeElement;
      }
    }
    setTimeout(() => prodCompanyTypeahead.focus());
  }

  /** Method to get Accented char for title modal popup*/
  public getAccentedTitleModalChar(char: any) {
    this.accentdCharService.getAccentedChars(char).subscribe(
     (chars) => {
       this.accentedCharsForProjectTitle = chars;
       this.accentedTitleModal.openAccentedModal(chars);
     }
   );
}

  /**Method to get Accented char for company modal popup*/
  public getAccentedModalChar(char: any) {
    this.accentdCharService.getAccentedChars(char).subscribe(
     (chars) => {
      this.accentedCharValues = chars;
       this.accentedChars.openAccentedModal(chars);
     }
   );
}

  /**
   * Populates the Casting Company Array in the form.
   *
   * @param data The existing data to iterate over.
   */
  public getCastingCompanySet(data): FormArray {
    const castingCompanies = <FormArray>this.createEditForm.controls.castingCompanySet;
    if (castingCompanies.controls.length !== 0) {
      castingCompanies.controls = [];
    }
    data.forEach((item) => {
      const signatory = item.signatoryUser && item.signatoryUser.id ?
                        this.getDropdownSelection(this.signatories, item.signatoryUser.id, 'id') : null;
      castingCompanies.push(this.fb.group({
        'productionCompany': this.fb.control({ value: item.productionCompany, disabled: true }),
        'union': this.fb.control({ value: this.getDropdownSelection(this.unions, item.union.id, 'id'), disabled: true }),
        'unionNote': this.fb.control({ value: item.unionNote, disabled: true }),
        'signatoryUser': this.fb.control({ value: signatory, disabled: true }),
        'primaryInd': this.fb.control({ value: item.primaryInd, disabled: true })
      }));
    });
    return castingCompanies;
  }

 /**
   * Populates the dropdown value when populating the form.
   *
   * @param type The DropdownModel to iterate over.
   * @param value The value to set on the dropdown.
   * @param field The field name to compare against.
   */
  public getDropdownSelection(type, value, field) {
    let selection = value;
    if (type.options) {
      type.options.forEach((val) => {
        if (value === val[field]) {
          selection = val;
        }
      });
    }
    return selection;
  }

    /**
   * Gets the current existing project when the user navigates to edit a project.
   */
  public getProject(projectId?: any) {
    if (projectId) {
      this.projectId = projectId;
    }
    this.createEditProjectService.getProject(this.projectId).subscribe(
      (data) => {
        this.assignedToUsers = this.resolverAssignedList;
        if (data.assignedToUser && !data.assignedToUser.active) {
          this.assignedToUsers.options.unshift({
            value: data.assignedToUser.firstName + ' ' + data.assignedToUser.lastName,
            route: '',
            userId: data.assignedToUser.userId
          });
        }
        let studioFlag = false;
        let studioArray = [];
        studioArray = this.studios.options;
        studioArray.forEach(element => {
          if(element.id===data.studio.id){
            studioFlag = true;
          }
        });

        if(!studioFlag){
          this.studios.options.unshift({
            value: data.studio.name ,
            id: data.studio.id
          });
        }
        
        this.createEditForm.patchValue(
          this.fb.group({ 'castingCompanySet': this.getCastingCompanySet(data.castingCompanySet) })
        );
        this.createEditForm.patchValue({
          'creationDate': data.creationDate,
          'title': data.title,
          'akaNames': data.akaNames,
          'startDate': data.startDate,
          'wrapDate': data.wrapDate,
          'releaseDate': data.releaseDate,
          'assignedTo': this.getDropdownSelection(this.assignedToUsers, (data.assignedToUser ? data.assignedToUser.userId :data.assignedToUser), 'userId'),
          'studio': this.getDropdownSelection(this.studios, data.studio.id, 'id'),
          'status': this.getDropdownSelection(this.statuses, data.projectStatusId, 'id'),
          'sapCode': data.sapCode,
          'type': this.getDropdownSelection(this.projectTypes, data.projectTypeId, 'id'),
          'sagProdId': data.sagProdId,
          'notes': data.note,
        });

        this.setTitleAndAkaFields(data);

        this.createEditForm.markAsPristine();
        this.createEditForm.markAsUntouched();
        this.validateAddedProdCompany = true;
        this.createdByApp = data.createdByApp;
        this.disableFieldsForProjectsOfDiffModules();
      },
      (error) => { console.log('Error when getting existing project', error); } // TODO: Throw toaster error. Better error handling.
    );
  }

  public setTitleAndAkaFields(data) {
     const talentListData: TypeAheadModel = new TypeAheadModel();
     talentListData.entityName = data.title.title;
     talentListData.firstName = data.title.first;
     talentListData.nameId = data.title.id;
     talentListData.typeAheadDisplayName = data.title.title;
    //  talentListData.selectedItemInList = true;

     this.listTalent.push(talentListData);

     this.selectedName = talentListData; // check if needed
     this.typeAheadEventService.currentItemSelected({ item: talentListData, listName: 'mainListTitle' });

     if (data.akaNames) {
       data.akaNames.forEach((element, index) => {
         const talentListData: TypeAheadModel = new TypeAheadModel();
         talentListData.entityName = element.title;
         talentListData.firstName = element.first;
         talentListData.nameId = element.id;
         talentListData.typeAheadDisplayName = element.title;
        //  talentListData.selectedItemInList = false;

         this.listTalent.push(talentListData);
       });
     }

     this.typeAheadEventService.listNameToLook('mainListTitle');
     this.typeAheadEventService.populateList(this.listTalent);
  }

  /**
   * Checks to see if the FormGroup is invalid.
   *
   * @param formGroup The FormGroup to run validation on.
   * @param field The FormControl to check in the given FormGroup.
   */
  public isFormInvalid(formGroup, field): boolean {
    if(field === "productionCompany") {
      return formGroup.get(field).invalid && formGroup.get(field).touched && !this.validateAddedProdCompany; // added check so that validation disappears on select of typeahead value(prod company) itself.
    }else if((field === "studio" || field === "status" || field === "type") && (this.isEdit && this.createdByApp !== 'Feature Casting')){
       return false;
       }
    return formGroup.get(field).invalid && formGroup.get(field).touched;
  }

  /**Method to open RC page on click of company edit icon */
  public onEditClick(): void {
    this.saveTypeaheahModal(true);
  }

  /**
   * Sets up local variables for current and new project.
   */
  public ngOnInit(): void {
    this.displayProdCompanyData = this.sharedService.displayCompanyMetadataResults;
    this.displayProjectTitleData = this.sharedService.displayProjectTitleData;
    const assignedUser = this.getDropdownSelection(this.assignedToUsers, this.currentUser.getCurrentUser().username, 'userId');
    this.createEditForm = this.fb.group({
      'creationDate': this.fb.control(new Date()),
      'title': this.fb.control(new ProjectTitleModel(), [Validators.required, FormValidators.validateModelValue('title')]),
      'akaNames': this.fb.control([]),
      'startDate': this.fb.control(null),
      'wrapDate': this.fb.control(null),
      'releaseDate': this.fb.control(null),
      'assignedTo': this.fb.control(assignedUser, Validators.required),
      'castingCompanySet': this.fb.array([], Validators.required),
      'studio': this.fb.control(this.getDropdownSelection(this.studios, this.DEFAULT_STUDIO, 'value'), Validators.required),
      'status': this.fb.control(null, Validators.required),
      'sapCode': this.fb.control(null),
      'type': this.fb.control(this.getDropdownSelection(this.projectTypes, DEFAULT_TYPE, 'value'), Validators.required),
      'sagProdId': this.fb.control(null),
      'notes': this.fb.control(null)
    });

    this.addProdCompanyForm = this.fb.group({
      'productionCompany': this.fb.control(null, Validators.required),
      'union': this.fb.control(null, Validators.required),
      'unionNote': this.fb.control(null),
      'signatoryUser': this.fb.control(null),
      'primary': this.fb.control(false)
    });

    if (this.isEdit) {
      this.getProject();
      this.showTypeAhead = true;
      this.cancelButtonOptions = new CancelButtonModel('fc', 'createEditProject', 'navigate', `/projectDetails/${this.projectId}`);
    } else {
      this.showTypeAhead = true;
      this.validateAddedProdCompany = true;
      this.cancelButtonOptions = new CancelButtonModel('fc', 'createEditProject', 'navigate', '/allProjects');
      setTimeout(() => {
        this.createEditForm.markAsPristine();
        this.createEditForm.markAsUntouched();
      });
    }
  }

  public ngAfterViewInit() {
    if(!this.isEdit){
      this.titleTypeAhead.typeAheadField.nativeElement.focus();
    }else{
      this.defaultSpan.nativeElement.focus();
    }
  }

  public tabToCreationDate(){
    this.defaultSpan.nativeElement.focus();
  }

  public onKeyup(key): void {
    if (key === 'Tab') {
      this.top.nativeElement.scrollIntoView();
    }
  }

  /**
   * Sets the value of the primary radio when clicked.
   *
   * @param primary The element getting changed.
   */
  public onPrimaryChange(primary): void {
    if (primary.checked) {
      this.addProdCompanyForm.get('primary').patchValue(true);
      primary.checked = true;
    }
  }

  public openModal(): void {
    this.sameTitleModal.open();
  }

   /**
   * This is called when the close button is clicked on the AKA tile. Removes the specific
   * AKA name from the 'akaNames' list.
   *
   * @param index The position in the Array to remove./****not needed*****//*
   */
  public removeAka(index: string): void {
    this.createEditForm.get('akaNames').value.splice(index, 1);
  }

  /**
   * Removes the given line from the casting company set when the minus (-) icon is clicked.
   *
   * @param index The position in the array of the row to be removed.
   */
  public removeLineItem(index) {
    const prodArray = <FormArray>this.createEditForm.controls.castingCompanySet;
    prodArray.removeAt(index);
    prodArray.value.forEach(element => {
      if (element.primaryInd !== true) {
        element.primaryInd = true;
        this.updatePrimaryIndicator(0);
      }
    });
    if (!prodArray.controls.length) {
      this.validateFormFields(this.addProdCompanyForm);
    }
  }

    /** Method to save Alias name */
  public saveAliasCompany(cName: any, isEdit: boolean): any {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();
    aliasParty.partyType = 'COMPANY';
    aliasParty.displayName = cName.typeAheadCurrentName && cName.typeAheadCurrentName.entityName ?
      cName.typeAheadCurrentName.entityName : cName.formValues.typeAheadCompany;
    aliasParty.name.entity = cName.typeAheadCurrentName && cName.typeAheadCurrentName.entityName ?
      cName.typeAheadCurrentName.entityName : cName.formValues.typeAheadCompany;
    aliasParty.partyId = (cName.typeAheadCurrentName && cName.typeAheadCurrentName.partyId) ? cName.typeAheadCurrentName.partyId : null;
    const akaName = cName.formValues ? cName.formValues.aliasCompanyName : cName.aliasCompanyName;
    AKA.name.entity = EmptyIfNull.check(akaName);

    this.talentService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
      (res) => {
        this.addNameCompanyModal.successCB(res);
        if (isEdit) {
          const prodCompanyData = res;
          this.addEditComapny.open(prodCompanyData, this.projectId);
        }
        setTimeout(() => document.getElementById('clearBtn').focus());
      },
      (err) => {
        const errMessage: string = err.error.errors[0].detail;
        this.addNameCompanyModal.failureCB(errMessage);
      }
    );
  }

    /** Save new production company name */
    public saveCompanyModal(cName: any, isEdit: boolean): any {
      const companyName: TypeAheadSaveModel = new TypeAheadSaveModel();
      companyName.name.entity = cName.formValues ? cName.formValues.companyName : cName.companyName;
      companyName.partyType = 'COMPANY';
      companyName.createdBy = 'Melissa Tapie';
      companyName.updatedBy = 'Melissa Tapie';
      companyName.partyId = null;
      const dataSet = this.talentService.getUserData();
      companyName.dataSetId = dataSet.masterDataset;
      companyName.updatedByApp = 'Feature Casting';
      this.talentService.save(JSON.stringify(companyName)).subscribe(
        (res) => {
          this.addNameCompanyModal.successCB(res);
          if (isEdit) {
            const prodCompanyData = res;
            this.addEditComapny.open(prodCompanyData, this.projectId);
          }
          setTimeout(() => document.getElementById('clearBtn').focus());
        },
        (err) => {
          const errMessage: string = err.error.errors[0].detail;
          this.addNameCompanyModal.failureCB(errMessage);
        }
      );
    }

  /**Method to patch value to Prod company filed */
  public saveCompanyNameEvent(evt: TypeAheadModel): void {
      this.addProdCompanyForm.get('productionCompany').patchValue({
            entityName: evt.typeAheadDisplayName,
            partyId: evt.partyId,
            partyType: 'COMPANY',
            typeAheadDisplayName: evt.typeAheadDisplayName
        });
      this.prodCompany = true;
      this.validateAddedProdCompany = true;
  }


   /**
   * This function saves the casting company set.
   *
   * @param formGroup The FormGroup to save.
   */
  public saveEditedCastingCompanySet(formGroup): void {
    if (formGroup.valid && this.prodCompany) {
      Object.keys(formGroup.controls).forEach((field) => {
        formGroup.controls[field].disable();
      });
      this.prodCompany = false;
    } else {
      this.validateFormFields(formGroup);
    }
  }

   /**
   * Saves / Updates the project when the user clicks the Save icon. This function
   * will set the necessary data that isn't already set in the Project model.
   */
  public saveProject() {
    const prodArray = <FormArray>this.createEditForm.controls.castingCompanySet;
    this.enableFieldsForDiffModule();
    if (this.createEditForm.valid && prodArray.controls.length) {
      let project = this.convertToProject(this.createEditForm.getRawValue());
      project = { ...project };
      if (!this.isEdit) {
        if (this.projectId) {
          this.createEditProjectService.updateProject(project).subscribe(res => {
            this.createEditForm.markAsPristine();
            this.createEditForm.markAsUntouched();
            this.router.navigate(['/allProjects']);
          }, err => {
            console.log(err);
            this.toasterService.error('There was a problem updating the Project', 'ERROR');
          });
        } else {
          project.createdByApp = 'Feature Casting';
          this.createEditProjectService.saveProject(project).subscribe(res => {
            this.createEditForm.markAsPristine();
            this.createEditForm.markAsUntouched();
            this.router.navigate(['/allProjects']);
          }, err => {
            console.log(err);
            this.toasterService.error('There was a problem saving the Project', 'ERROR');
          });
        }
      } else {
        this.createEditProjectService.updateProject(project).subscribe(res => {
          this.createEditForm.markAsPristine();
          this.createEditForm.markAsUntouched();
          this.router.navigate([`/projectDetails/${this.projectId}`]);
        }, err => {
          console.log(err);
          this.toasterService.error('There was a problem updating the Project', 'ERROR');
        });
      }
    } else {
      this.validateFormFields(this.createEditForm);
    }
  }

  /**Method to save data onclick of edit click */
  public saveTypeaheahModal(isEditMode): void {
      const vals = this.addNameCompanyModal.addCompanyForm.value;
      vals['typeAheadCurrentName'] = this.addNameCompanyModal.selectedTypeAheadRecord || {};
      if (!vals.aliasCheckbox) {
        this.saveCompanyModal(vals, isEditMode);
      } else {
        this.saveAliasCompany(vals, isEditMode);
      }
  }

  public selectedProdCompany(event): void {
    if (event) {
      this.prodCompany = true;
      this.validateAddedProdCompany = true;
      const prodCompanyValue = this.addProdCompanyForm.get('productionCompany').value;
    } else {
      this.prodCompany = false;
      this.validateAddedProdCompany = false;
    }
  }

  /**
   * Updates the primary indicator for the casting company set when the 'Primary'
   * radio button changes to another record.
   *
   * @param index The index of the new 'Primary' radio button set.
   */
  public updatePrimaryIndicator(index?: number): void {
    const prodArray = <FormArray>this.createEditForm.controls.castingCompanySet;
    for (let i = 0; i < prodArray.controls.length; i++) {
      if (i !== index) {
        prodArray.controls[i].get('primaryInd').patchValue(false);
      } else {
        prodArray.controls[i].get('primaryInd').patchValue(true);
      }
    }
  }

  /**
   * Called when the form is invalid in order to mark the invalid controls.
   *
   * @param formGroup The FormGroup to mark.
   */
  public validateFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

  public createPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.createEditProjectView) === true &&
    this.userPermissionService.hasPermission(this.createEditProjectEdit) === false) {
    return true;
    } else if (this.userPermissionService.hasPermission(this.createEditProjectView) === true &&
    this.userPermissionService.hasPermission(this.createEditProjectEdit) === true) {
      return false;
    }
  }

  public hideTypeAheadHeader(evt: any) {
    this.showTypeAhead = false;
  }

  /* event fired when an option is selected from typeahead */
  public selectedTitleTypeAheadRecord(evt: any) {
    this.typeAheadEventService.removeListItems('mainListTitle');
    this.getProject(evt.projectId);

    this.selectedTitleData = evt;
  }

  /* event fired on successful save of new Title */
  public listNamesAdded(evtListName: Array<TypeAheadModel>): void {
    if (evtListName && evtListName.length) {
      this.typeAheadTitleModalConfig.title = 'Add Alias';
      this.showTypeAhead = false;
      this.projectTitleListNameResult = evtListName;
    }
  }

  /* event fired on clicking 'Add Alias'*/
  public addAliasName(evt: any): void {
    this.typeAheadTitleForProjectTitle = 'Enter alias and press enter';
    this.showTypeAhead = true;
    this.typeAheadAddSameName = false;
    this.disableSearchName = true;
    this.hasNoResultsCallback = false;
  }

  // This object prepartion required to set once talent saved and the name listing component to reflect the changes
  private prepareNewProjectTitle(partyDetails: any): void {
    const projectTitleObj: TypeAheadModel = new TypeAheadModel();

    projectTitleObj.entityName = partyDetails.name.entity;
    // performerObj.partyId = partyRespose.partyId;
    // performerObj.nameId = partyRespose.name.nameId;
    projectTitleObj.typeAheadDisplayName = partyDetails.name.entity;
    // performerObj.selectedItemInList = true;
    this.typeAheadEventService.listNameToLook('mainListTitle');
    this.typeAheadEventService.currentItemSelected({ item: projectTitleObj, listName: 'mainListTitle' });
  }

    /** Method to create or save new project title */
    public saveTypeaheadTitleModal(cName): void {
      const companyName: TypeAheadSaveModel = new TypeAheadSaveModel();

      companyName.name.entity = cName.formValues.companyName;
      companyName.partyType = 'COMPANY';
      companyName.createdBy = 'Melissa Tapie';
      companyName.updatedBy = 'Melissa Tapie';
      companyName.partyId = null;

      this.prepareNewProjectTitle(companyName);
      this.typeAheadModalForProjectTitle.successCB(companyName);

      // commenting as save as company is not required for project title
      // this.talentService.save(JSON.stringify(companyName)).subscribe(
      //   (partySaved: any) => {
      //     this.prepareNewProjectTitle(partySaved);
      //     this.typeAheadModalForProjectTitle.successCB(partySaved);
      //   },
      //   (err) => {
      //     const errMessage: string = err.error.errors[0].detail;
      //     this.typeAheadModalForProjectTitle.failureCB(errMessage);
      //   }
      // );
    }

    private createDisplayName(vals: any): string {
      return vals.editableFields.entityName + ', ' +
        vals.editableFields.suffix + ', ' +
        vals.editableFields.firstName + ' ' +
        vals.editableFields.middleName;
    }

    /* event fired on save of new Title or AKA/Alias names */
    public onSaveAddNewTitle(evt: TypeAheadModel): void {
      this.selectedTitleData = evt;
    }

  /**Method to save Alias/AKA names */
  public saveTitleAliasModal(cName): void {
    const aliasParty: AddAliasModel = new AddAliasModel();
    const AKA: AddAliasAKAModel = new AddAliasAKAModel();

    // aliasParty.partyType = 'COMPANY';
    // aliasParty.displayName = cName.typeAheadCurrentName.entityName || cName.formValues.companyName;
    // aliasParty.name.entity = cName.typeAheadCurrentName.entityName || cName.formValues.companyName;
    // aliasParty.partyId = (cName.typeAheadCurrentName && cName.typeAheadCurrentName.partyId) ? cName.typeAheadCurrentName.partyId : null;

    AKA.name.entity = EmptyIfNull.check(cName.formValues.aliasCompanyName);

    this.typeAheadModalForProjectTitle.successCB({displayName : AKA.name.entity, name: AKA.name});
    this.addAka(AKA.name.entity);

    // commenting as save as company is not required for project title
    // this.talentService.saveAlias(JSON.stringify([aliasParty, AKA])).subscribe(
    //   (partySaved) => {
    //     this.typeAheadModalForProjectTitle.successCB(partySaved);
    //     this.addAka(partySaved.displayName);
    //   },
    //   (err) => {
    //     const errMessage: string = err.error.errors[0].detail;
    //     this.typeAheadModalForProjectTitle.failureCB(errMessage);
    //   }
    // );
  }

  /*event fired when 'Add as new' is clicked and duplicate name exists in typeahead results*/
  public confirmDuplicateNameEvent(event) {
    this.confirmDuplicateName = false;
    this.openModal();
  }

  /* check for duplicate typeahead record on typing*/
  public typeAheadReturnResults(event) {
    const typeaheadValue = this.titleTypeAhead.typeAheadField.nativeElement.value;
    this.confirmDuplicateName = false;
    // iteration over event may be needed if any case returns the equals value at index other than 0, skipping for now
    if (typeaheadValue.toUpperCase() === event[0].title.toUpperCase()) {
      this.confirmDuplicateName = true;
    }
  }

  public noSearchResultsReturnedForTitle(event) {
    this.confirmDuplicateName = false;
  }

  public typeAheadReturnResultsForProdCompany(event) {
    this.validateAddedProdCompany = false;
  }

  public noSearchResultsReturnedForProdCompany(event) {
    this.validateAddedProdCompany = false;
  }
}
