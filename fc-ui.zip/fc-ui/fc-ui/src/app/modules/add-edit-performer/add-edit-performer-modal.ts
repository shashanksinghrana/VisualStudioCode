import { Component, OnDestroy , EventEmitter, Output, TemplateRef, ViewChild, OnInit } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { PowersearchModalService } from '../../services/events/powersearch-modal-event-service';

@Component({
  selector: 'add-edit-performer-modal',
  templateUrl: './add-edit-performer-modal.html',
  styleUrls: ['./add-edit-performer-modal.scss'],
  providers: [CommonModuleService]
})
export class AddEditPerformerModal implements OnInit, OnDestroy {

  /** The content of the modal to be displayed when opened. */
  @ViewChild('addEditPerformerContent') private addEditPerformerModalContent: TemplateRef<any>;

  public data: any = { isRouteChanged: false, activeTab: null };
  public eventRoute: any;
  public isDataLoaded: boolean = false;
  public modal: NgbModalRef;
   /** Defines Option for modal window */
   private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-full-screen'
  };
  public modalReference: any;
  @Output() public closeModalEvent: any = new EventEmitter<any>();
  public routeParams: any;
  private subscription: Subscription = new Subscription();

  constructor(public talentService: CommonModuleService, private modalService: NgbModal, private eventService: PowersearchModalService,
              private router: Router) {
  }

  public close(event?: Event): void {
    this.modalReference.close(event);
  }

  public ngOnInit(): any {
    this.isDataLoaded = true;
    this.addSubscriptions();
  }

  public open(id?: number): void {
    // this.routeParams = { 0: { path: 'addPerformerModal' }, param: id };
    this.routeParams = { 0: { path: 'addTalent' }, param: id };
    this.talentService.setRoutesParams(this.routeParams);
    this.modalReference = this.modalService.open(this.addEditPerformerModalContent, this.modalOptions);
    this.eventService.openModal();
  }

  private addSubscriptions(): void {
    this.subscription.add(
      this.router.events.subscribe((eventRoute) => {
        if (eventRoute instanceof NavigationStart) {
          this.eventRoute = eventRoute;
        }
      })
    );
    this.subscription.add(
      this.talentService.getCloseModalEvent().subscribe((response) => {
        if (response && response.close) {
          this.modalReference.close();
          this.closeModalEvent.emit(response);
        }
      })
    );
  }

  public ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
