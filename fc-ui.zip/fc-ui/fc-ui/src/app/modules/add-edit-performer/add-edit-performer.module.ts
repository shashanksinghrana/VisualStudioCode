import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TalentModule } from 'c2c-common-lib';
import { AddEditPerformerModal } from './add-edit-performer-modal';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { PowersearchModalService } from '../../services/events/powersearch-modal-event-service';

@NgModule({
  imports: [
    CommonModule,
    TalentModule
  ],
  declarations: [AddEditPerformerModal],
  providers: [CommonModuleService, PowersearchModalService],
  exports: [
    AddEditPerformerModal
  ]
})
export class AddEditPerformerModule { }
