import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealsAndContractsComponent } from './deals-and-contracts.component';

describe('DealsAndContractsComponent', () => {
  let component: DealsAndContractsComponent;
  let fixture: ComponentFixture<DealsAndContractsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealsAndContractsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealsAndContractsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
