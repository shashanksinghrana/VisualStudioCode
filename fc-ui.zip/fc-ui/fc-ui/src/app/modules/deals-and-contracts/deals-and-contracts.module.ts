import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DealsAndContractsComponent } from './deals-and-contracts.component';
import { GridModule } from 'c2c-common-lib';
import { DealsAndContractsService } from '../../services/http/deals-and-contracts/deals-and-contracts.service';

@NgModule({
  imports: [
    CommonModule,
    GridModule.forRoot()
  ],
  declarations: [DealsAndContractsComponent],
  providers: [DealsAndContractsService]
})
export class DealsAndContractsModule { }
