import { Component } from '@angular/core';
import { ColumnDefModel } from 'c2c-common-lib';
import { DealsAndContractsService } from '../../services/http/deals-and-contracts/deals-and-contracts.service';

@Component({
  selector: 'fc-deals-and-contracts',
  templateUrl: './deals-and-contracts.component.html',
  styleUrls: ['./deals-and-contracts.component.scss']
})
export class DealsAndContractsComponent {
  public dealContractsColDefs: ColumnDefModel[];
  public dealContractsData: any[];
  public pageOptions: {};

  constructor(private dealsContractsService: DealsAndContractsService) {
    this.dealContractsColDefs = dealsContractsService.getColumnDefs();
    this.dealContractsData = dealsContractsService.getAllDealsAndContracts();
    this.pageOptions = dealsContractsService.getPageOptions();
  }

}
