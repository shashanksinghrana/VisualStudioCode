import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllProjectsComponent } from './all-projects.component';
import { GridModule } from 'c2c-common-lib';
import { AllProjectsService } from '../../services/http/all-projects/all-projects.service';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    GridModule.forRoot()
  ],
  declarations: [AllProjectsComponent],
  providers: [AllProjectsService]
})
export class AllProjectsModule { }
