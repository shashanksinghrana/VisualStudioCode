import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import {
  AddButtonModel, ColumnDefModel,
  NavBarEventService, UrlResolverService, NavBarHistoryModel
} from 'c2c-common-lib';
import { AllProjectsService } from '../../services/http/all-projects/all-projects.service';
import { HttpParams } from '@angular/common/http';
import { UserPermissionService } from '../../services/http/permission/user-permission.service';
import { PermissionList } from '../../enums/permission-list.enum';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';

@Component({
  selector: 'fc-all-projects',
  templateUrl: './all-projects.component.html',
  styleUrls: ['./all-projects.component.scss']
})
export class AllProjectsComponent implements OnDestroy {
  public addButtonOptions: AddButtonModel =
    new AddButtonModel('fc', 'allProject', 'navigate', '/createEditProject');
  // public refreshButtonOptions: RefreshButtonModel =
  //   new RefreshButtonModel('fc', 'allProjects');

  public allProjectsData: any[];
  public pageOptions: {};
  public pagination: any;
  public projectListDefs: ColumnDefModel[];
  public createProjectPermission: boolean = true;
  private permissionSubscription: Subscription = new Subscription();
  public allProjectsView: PermissionList = PermissionList.allProjectView;
  public allProjectsEdit: PermissionList = PermissionList.allProjectEdit;
  public dataLoaded: boolean = false;

  constructor(private allProjectsService: AllProjectsService,
    private urlResolverService: UrlResolverService,
    private navBarEventService: NavBarEventService,
    private userPermissionService: UserPermissionService,
    private projectDetailService: ProjectDetailService) {
    this.addSubscriptions();
    this.projectListDefs = allProjectsService.createColumnDefs();
    this.getAllProjectsData();
    this.addButtonOptions.tooltip = 'Create Project';
    this.projectDetailService.project = {};
  }

  public getAllProjectsData(params?: HttpParams) {
    this.allProjectsService.getAllProjects(params).subscribe(
      (data) => {
        this.allProjectsData = data.projects;
        this.pagination = data.pagination;
      }
    );
  }

  private addSubscriptions(): void {
    this.permissionSubscription.add(
      this.userPermissionService.getUserPermission().subscribe((permission) => {
        if (permission && permission.length) {
          this.createProjectPermission = this.createPermission();
          this.pageOptions = this.allProjectsService.getPageOptions(this.createProjectPermission);
          this.dataLoaded = true;
        }
      })
    );
  }

  public createPermission(): boolean {
    if (this.userPermissionService.hasPermission(this.allProjectsView) === true &&
    this.userPermissionService.hasPermission(this.allProjectsEdit) === false) {
      return false;
    } else if (this.userPermissionService.hasPermission(this.allProjectsView) === true &&
    this.userPermissionService.hasPermission(this.allProjectsEdit) === true) {
      return true;
    }
  }

  /** Method to add item for history link*/
  public getProjectClicked(evt: any): void {
    let url;
    if (evt.route.endsWith('summary')) {
      url = this.urlResolverService.getServiceEndpointUrl(`#${evt.route}`);
    } else {
      url = this.urlResolverService.getServiceEndpointUrl(`#${evt.route}/performers`);
    }
    const title = evt.subtitle ? `${evt.title} (${evt.subtitle})` : evt.title;
    const historyItem: NavBarHistoryModel = new NavBarHistoryModel();

    historyItem.destinationUrl = url;
    historyItem.historyLabel = title;
    historyItem.iconClass = 'navbar-projector';
    historyItem.source = 'FC';

    this.navBarEventService.setNavBarHistory(historyItem);
  }

  /**
   * Listens for the Grid's sort/filter/pagination event and performs server-side operations on the data.
   *
   * @param params The HttpParams to send to the back-end for the server-side operations.
   */
  public onDataChanged(params: HttpParams): void {
    this.getAllProjectsData(params);
  }

  public refreshGridData() {
    // reset filtering and reset sorting taken care of by the grid...
    // implement any additional desired functionality here for when refresh button clicked...
  }

  ngOnDestroy(): void {
    this.permissionSubscription.unsubscribe();
  }


}
