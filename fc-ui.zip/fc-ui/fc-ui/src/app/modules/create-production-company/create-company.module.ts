import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyModule } from 'c2c-common-lib';
import { CreateCompanyModal } from './create-company-modal';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { PowersearchModalService } from '../../services/events/powersearch-modal-event-service';

@NgModule({
  imports: [
    CommonModule,
    CompanyModule
  ],
  declarations: [CreateCompanyModal],
  providers: [CommonModuleService, PowersearchModalService],
  exports: [
    CreateCompanyModal
  ]
})
export class CreateCompanyModule { }
