import { Component, OnDestroy , ChangeDetectorRef, EventEmitter,
         Output, TemplateRef, ViewChild, ViewContainerRef, Renderer2 } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { CompanyOutputParamsModel, CompanyInputParamsModel, CompaniesDetailModel,
         ToasterService, TypeAheadDisplayResultModel, DropdownModel, CompanyComponent } from 'c2c-common-lib';
import { AccentedCharacterService } from '../../services/http/shared/accented-character.service';
import { CommonModuleService } from '../../services/http/deal/add-edit-performer/common-module.service';
import { PowersearchModalService } from '../../services/events/powersearch-modal-event-service';
import { ToastsManager } from 'ng2-toastr';

@Component({
  selector: 'fc-create-company-modal',
  templateUrl: './create-company-modal.html',
  styleUrls: ['./create-company-modal.scss'],
  providers: [CommonModuleService, ToasterService, AccentedCharacterService]
})
export class CreateCompanyModal implements OnDestroy {

   /** The content of the modal . */
   @ViewChild('addEditCompany') private addEditCompany: TemplateRef<any>;
   public addServiceInitiated: boolean = false;
   @Output() public companyCancel: EventEmitter<any> = new EventEmitter();
   @Output() public isComponentLoad: EventEmitter<boolean> = new EventEmitter<boolean>();
   @ViewChild('companyComponent') public companyComponent: CompanyComponent;
   public companyData: CompaniesDetailModel = new CompaniesDetailModel();
  //  @Input() public companyDetails: any;
   public companyDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
   public companyEntityTypes: any;
   public companyId: number;
   @Output() public companyModalClosed: EventEmitter<any> = new EventEmitter();
   public companyParamModel: CompanyInputParamsModel;
   @Output() public companySaveEvent: EventEmitter<any> = new EventEmitter();
   public companyTypeAheadService: any;
  public displayCompanyDataResults: TypeAheadDisplayResultModel;
  public entityTypeValue: string;
  public isDataLoaded: boolean = false;
  public modal: NgbModalRef;
   /** Defines Option for modal window */
   private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-full-screen'
  };
  public modalReference: any;
  public occupationDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public phoneDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public pickListData: any;
  @Output() public powersearchReportModalEvent: any = new EventEmitter<any>();
  public projectId: any;
  public selectCountryDropdown: DropdownModel = new DropdownModel('', 'United States', '', '', []);
  public selectStateDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public socialmediaDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public typesDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
  public validCompanyName: boolean = true;

  constructor(public changeDetector: ChangeDetectorRef,
              private vRef: ViewContainerRef,
              public service: CommonModuleService,
              private modalService: NgbModal,
              private accentedCharacterService: AccentedCharacterService,
              private eventService: PowersearchModalService,
              private toasterService: ToasterService,
              private toastr: ToastsManager,
              private renderer: Renderer2) {
                this.toastr.setRootViewContainerRef(vRef);
                this.initTypeahead();
                this.getDropdownLookupData();
  }

  private addEditProdCompany(showLoading?: boolean): any {
    if (this.companyId !== null && this.companyId > 0) {
      this.service.getCompanyDetails(this.companyId.toString(), showLoading).subscribe((data) => {
        this.companyData = data;
        this.entityTypeValue = this.companyData.entityTypeValue;
        this.openCompanyComponent();
      });
    } else {
      this.entityTypeValue = 'Company';
      this.openCompanyComponent();
    }
  }

  public cancelEvent(outParams: CompanyOutputParamsModel): void {
    this.close();
  }

  public close(event?: Event): void {
    this.companyId = null;
    this.companyData = new CompaniesDetailModel();
    this.companyModalClosed.emit('close');
    this.modalReference.close(event);
  }

  private getDropdownLookupData(): void {
    this.occupationDropdown = this.service.getDropDownOptionsList('COMPANY_OCCUPATION');
    this.typesDropdown = this.service.getDropDownOptionsList('COMPANY_TYPE');
    this.socialmediaDropdown = this.service.getDropDownOptionsList('SOCIAL_MEDIA');
    this.phoneDropdown = this.service.getDropDownOptionsList('PHONE_TYPE');
    this.selectStateDropdown = this.service.getDropDownOptionsList('countrystate/STATES/US');
    this.companyEntityTypes = this.service.getOptionsList('COMPANY_ENTITY_TYPE');
    this.selectCountryDropdown = this.service.getCountryOptionsList('countrystate/COUNTRIES');
  }

  private initTypeahead(): void {
    this.companyTypeAheadService = {
      serviceClass: this.service,
      serviceAccentedClass: this.accentedCharacterService,
      getCompanyDetails: 'getCompanyDetails',
      saveCompany: 'saveParty',
      saveCompanyAlias: 'saveAlias',
      getTalentDetails: 'getTalentDetails',
      getStateListFromDb: 'getStateListFromDb',
      getaccentedCharacters: 'getAccentedChars',
      getNames: 'getNames'
    };

    this.displayCompanyDataResults = {
      filterType: 'COMPANY_ONLY&context=COMPANY',
      primaryDisplayColumn: 'typeAheadDisplayName',
      secondaryDisplay: {
        secondaryColumns: ['primaryName', 'partyType'],
        display: '`(alias for ${data.primaryName})`'
      },
      metaDataColumns: {
        BUSINESS_CREATIVE: ['occupation', 'agency'],
        PRODUCTION: ['occupation', 'ssnEndChars'],
        CASTING: ['agency', 'ssnEndChars'],
        default: ['occupation', 'ssnEndChars']
      },
      noRecordsToReturn: '10',
      service: {
        serviceClass: this.service,
        get: 'getCompany'
      }
    };
  }

  public ngOnInit() { }

  public open(data?: any, id?: number, showLoading?: boolean): void {
     if (data !== undefined) {
          this.companyId = data.partyId ? data.partyId : data.companyId;
          this.companyData.displayName = data.entityName ? data.entityName : data.displayName;
      } else {
        this.companyId = null;
      }
      this.projectId = id ? id : '';
      this.addEditProdCompany(showLoading);
  }

  /**Method to open Modal popup to display Company component */
  public openCompanyComponent(): void {
    this.modalReference = this.modalService.open(this.addEditCompany, this.modalOptions);
    this.eventService.openModal();
    this.setCompanyParams();
    this.isDataLoaded = true;
    this.isComponentLoad.emit(true);
  }

  public ngOnDestroy(): void {

  }

  public saveCompany(outParams: CompanyOutputParamsModel): void {
      if (null !== outParams && null !== outParams.companyData && outParams.validCompany !== undefined) {
        this.companyData = outParams.companyData;
        this.validCompanyName = outParams.validCompany;
        if (this.validCompanyName) {
          this.companyData['updatedByApp'] = 'Feature Casting';
          const dataSet = this.service.getUserData();
          this.companyData['dataSet'] = dataSet.masterDataset;
          this.renderer.addClass(document.body, 'c2c-window-modal');
          this.service.insertUpdateCompanyDetails(this.companyData).subscribe(
            (res) => {
              this.renderer.removeClass(document.body, 'c2c-window-modal');
              this.companyId = res.partyId;
              this.toasterService.success('Record Saved', 'Success!');
              this.companySaveEvent.emit({companyData: res});
              this.close();
            },
            (err) => {
              this.renderer.removeClass(document.body, 'c2c-window-modal');
              this.toasterService.error('Error on saving Company data.', 'Error');
            });
        }
      } else {
        this.validCompanyName = false;
      }
  }

  /** Method to set company component parameter */
  private setCompanyParams(): void {
      this.companyParamModel = new CompanyInputParamsModel(this.displayCompanyDataResults, this.companyData,
      this.companyEntityTypes, this.occupationDropdown, this.typesDropdown, this.socialmediaDropdown,
      this.phoneDropdown, this.selectCountryDropdown, this.selectStateDropdown, this.companyTypeAheadService);
  }
}
