import { Component } from '@angular/core';
import { AuditModel, RadioButtonModel, CheckboxModel } from 'c2c-common-lib';
import { DropdownModel } from 'c2c-common-lib/src/app/models/dropdown/dropdown.model';

@Component({
  selector: 'fc-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  public audit: AuditModel = new AuditModel('01/01/2018', 'FCEnterUser', '12/31/2018', 'FCUpdateUser');

  public inputRequiredVal : boolean;
  
  public checkboxOptions: CheckboxModel =
  new CheckboxModel('thisId', 'thisName', [
    {value: 'v1', label: 'Value 1', checked: false, showTitle: true},
    {value: 'v2', label: 'Value 2', checked: false, showTitle: true},
    {value: 'v3', label: 'Value 3', checked: false, showTitle: true},
    {value: 'v4', label: 'Value 4 (checked by default)', checked: true, showTitle: true},
    {value: 'v5', label: 'Value 5', checked: false, showTitle: true},
  ]);

  public choiceDropdownOptions: DropdownModel = {
    action: '',
    title: '',
    dropdownValue: '',
    selection: '',
    options: [
      {
        value: 'Choice 1',
        route: ''
      },
      {
        value: 'Choice 2',
        route: ''
      }
    ]
  };

  public linkDropdownOptions: DropdownModel = {
    action: 'navigate',
    title: 'Link Dropdown',
    dropdownValue: '',
    selection: '',
    options: [
      {
        value: 'Link 1',
        route: 'test_route_1'
      },
      {
        value: 'Link 2',
        route: 'test_route_2'
      }
    ]
  };

  public radioOptions: RadioButtonModel =
  new RadioButtonModel('thisRadioTitle', [
    {title: 'Option 1', checkedByDefault: false, disabled: false, showTitle: true},
    {title: 'Option 2', checkedByDefault: false, disabled: false, showTitle: true},
    {title: 'Option 3', checkedByDefault: false, disabled: false, showTitle: true},
    {title: 'checked by default', checkedByDefault: true, disabled: false, showTitle: true},
    {title: 'disabled by default', checkedByDefault: false, disabled: true, showTitle: true}
  ]);

  public value: Date;

  constructor() {
    this.value = new Date('07/17/1989');
  }

}
