import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home.component';
import { AuditModule, FormModule, ButtonModule, CommonSharedModule, ModalModule } from 'c2c-common-lib';

@NgModule({
  imports: [
    CommonModule,
    FormModule,
    AuditModule,
    ButtonModule,
    ModalModule,
    FormsModule,
    CommonSharedModule
  ],
  declarations: [HomeComponent]
})
export class HomeModule { }
