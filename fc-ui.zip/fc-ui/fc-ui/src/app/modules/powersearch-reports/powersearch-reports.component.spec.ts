import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PowersearchReportsComponent } from './powersearch-reports.component';

describe('PowersearchReportsComponent', () => {
  let component: PowersearchReportsComponent;
  let fixture: ComponentFixture<PowersearchReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PowersearchReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PowersearchReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
