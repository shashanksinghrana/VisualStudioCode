import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormModule, ButtonModule, PowersearchModule, TypeAheadModule, TypeAheadModalModule, DropDownTypeAheadModule } from 'c2c-common-lib';
import { PowersearchReportsComponent } from './powersearch-reports.component';
import { PowerSearchCompWorkComponent } from '../../components/powersearch-compensation-workactivity/powersearch-comp-work.component';
import { PowersearchService } from '../../services/http/powersearch/powersearch.service';
import { PowersearchModal } from '../../components/modal/powersearch-report-modal/powersearch-report-modal';
import { PowerSearchTextFieldsComponent } from '../../components/powersearch-textfields/powersearch-textfields.component';
import { NumberOnlyDirective } from '../../utils/formatter/numberonly-input.directive';
import { PowersearchBillingModal } from '../../components/modal/powersearch-billing-modal/power-search-billing-modal';
import { PowersearchCastModal } from '../../components/modal/powersearch-cast-modal/power-search-cast-modal';
import { PowerSearchBlankReportModal } from '../../components/modal/power-search-blank-report-modal/power-search-blank-report-modal.component';
import { PowersearchCastingDataModal } from '../../components/modal/powersearch-casting-data-modal/powersearch-casting-data-modal';
import { TextMaskModule } from 'angular2-text-mask';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    FormModule,
    ButtonModule,
    PowersearchModule.forRoot(),
    TypeAheadModule,
    DropDownTypeAheadModule,
    TypeAheadModalModule.forRoot(),
    TextMaskModule
  ],
  declarations: [PowersearchReportsComponent,
                 PowerSearchCompWorkComponent,
                 PowerSearchTextFieldsComponent,
                 NumberOnlyDirective,
                 PowersearchModal,
                 PowersearchBillingModal,
                 PowersearchCastModal,
                PowerSearchBlankReportModal,
                PowersearchCastingDataModal
                ],
  providers: [PowersearchService]
})
export class PowersearchReportsModule { }
