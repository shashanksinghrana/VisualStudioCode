import { Component, OnInit, OnDestroy, ViewChild, TemplateRef, Output, EventEmitter, Input } from '@angular/core';
import {
  PowersearchGenericChoiceModel, PowersearchChoiceModel, ColumnDefModel,
  GridPageOptionsModel, DropdownModel, PowersearchEventService
} from 'c2c-common-lib';
import { PowersearchService } from '../../services/http/powersearch/powersearch.service';
import { ActivatedRoute } from '@angular/router';
import { PowersearchModal } from '../../components/modal/powersearch-report-modal/powersearch-report-modal';
import { LookupModel } from '../../models/shared/lookup.model';
import { SharedService } from '../../services/http/shared/shared.service';
import { PowersearchBillingModal } from '../../components/modal/powersearch-billing-modal/power-search-billing-modal';
import { PowersearchCastModal } from '../../components/modal/powersearch-cast-modal/power-search-cast-modal';
import * as moment from 'moment';
import { PowerSearchBlankReportModal } from '../../components/modal/power-search-blank-report-modal/power-search-blank-report-modal.component';
import { PowersearchCastingDataModal } from '../../components/modal/powersearch-casting-data-modal/powersearch-casting-data-modal';
import { BlankContractModel } from '../../models/power-search/blankContract.model';
import { DealService } from '../../services/http/deal/deal.service';
/**
 * The PowersearchReportsComponent
 *
 * Component for handling the implementation of the Powersearch common component.
 */
@Component({
  selector: 'fc-powersearch-reports',
  templateUrl: './powersearch-reports.component.html',
  styleUrls: ['./powersearch-reports.component.scss']
})
export class PowersearchReportsComponent implements OnInit, OnDestroy {
  public billingData: LookupModel[];
  public choices: PowersearchChoiceModel[];
  public compensationData: any;
  public compensationOperandOptions: any[];
  public selectedExportType: any;
  public defaultProjectTitle: any = {};
  public rangOptions: any[];
  public reportFormData: LookupModel[];
  public resultsData: any[];
  public resultsDefs: ColumnDefModel[];
  public resultsPageOptions: GridPageOptionsModel;
  public resultsPagination: any;
  public textFieldsData: LookupModel[];
  public unionData: LookupModel[];
  public projectStatusData: LookupModel[];
  public workActivityData: any;
  public workOperandOptions: any[];
  public powerSearchFormData: any;
  public selectedReportdisplayLabel: string;
  public stationReportStartDate: any;
  public stationReportEndDate: any;
  public exportOptions: DropdownModel;
  public saveSearchModalInput: string = '';
  public previouslySavedSearchOptions: DropdownModel;
  public setSearchOption: any;
  public isEditMode: boolean = false;
  public navigatedProjectTitleObject: any[] = [];
  public castingDataReportData: any[] = [];
  public dateValuesFromPowerSearch: any = { startDate: 'All', endDate: 'All' };
  public sortingOrder: string;
  public castSelections: any[] = [];
  public triggerSearch: any;
  public enableExportButton: boolean = false;
  public blankReportData: BlankContractModel;

  @ViewChild('compensation')
  private compensationTemplateRef: TemplateRef<any>;

  @ViewChild('station12ReportModal') public station12ReportModal: PowersearchModal;

  @ViewChild('billingListModal') public billingListModal: PowersearchBillingModal;

  @ViewChild('blankContractModal') public blankContractModal: PowerSearchBlankReportModal;

  @ViewChild('castListModal') public castListModal: PowersearchCastModal;

  @ViewChild('castingDataModal') public castingDataModal: PowersearchCastingDataModal;

  @ViewChild('workActivity')
  private workActivityTemplateRef: TemplateRef<any>;

  @ViewChild('textFields')
  private textFieldsTemplateRef: TemplateRef<any>;

  /**
  * Constructor for the PowersearchReportsComponent
  * @param powersearchService Service for handling powersearch http calls
  * @param route The activated route.
  */
  constructor(
    private powersearchService: PowersearchService,
    private psEventService: PowersearchEventService,
    private route: ActivatedRoute,
    private sharedService: SharedService,
    private dealService: DealService
  ) {
    this.navigatedProjectTitleObject = this.sharedService.projectDetailsStorageObject;
    this.route.data.subscribe(
      (data: { powersearch: any }) => {
        this.billingData = data.powersearch.billing;
        this.unionData = data.powersearch.unions;
        this.reportFormData = data.powersearch.reportFormData;
        this.workOperandOptions = data.powersearch.workOperandOptions;
        this.rangOptions = data.powersearch.rangOptions;
        this.compensationOperandOptions = data.powersearch.compensationOperandOptions;
        this.textFieldsData = data.powersearch.textFields;
        this.exportOptions = this.getDropdownOptions(data.powersearch.exportOptions);
        this.previouslySavedSearchOptions = this.getDropdownOptionsForPrevSavedSearch(data.powersearch.previouslySavedSearchOptions);
        this.projectStatusData = data.powersearch.projectStatus;
      }
    );
    this.compensationData = {
      operandOptions: this.compensationOperandOptions,
      rangOptions: this.rangOptions
    };
    this.workActivityData = {
      operandOptions: this.workOperandOptions,
      rangOptions: this.rangOptions
    };
  }

  /**
  * Angular lifecycle hook for initialization logic.
  * Used here to initialize variables.
  */
  public ngOnInit(): void {
    this.createPowerSearch();
    this.resultsData = [];
    this.resultsDefs = this.powersearchService.createColumnDefs();
    this.resultsPageOptions = this.powersearchService.getPageOptions(this.resultsData);
  }

  /* Method to get Dropdown Options and values */
  public getDropdownOptions(data) {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    options.push({ value: '', route: '', id: '', disabled: false });
    for (let i = 0; i < Object.keys(data).length; i++) {
      let disabled = true;
      if (data[i].name === 'Excel') {
        disabled = false;
      }
      options.push({
        value: data[i].name,
        route: '',
        id: data[i].id,
        data: data[i],
        disabled: disabled
      });
    }
    return dropdownModel;
  }

  public getDropdownOptionsForPrevSavedSearch(data) {
    const options: any[] = [];
    const dropdownModel: DropdownModel = new DropdownModel(null, null, null, null, options);
    for (let i = 0; i < Object.keys(data).length; i++) {
      const item = data[i];
      options.push({
        value: item.queryName,
        route: '',
        id: item.queryId,
        data: {
          'queryName': item.queryName,
          'queryId': item.queryName
        }
      });
    }
    return dropdownModel;
  }

  private transformData(response: any): void {
    if (response) {
      response.forEach(item => {
        if (item.deals) {
          item.deals.forEach(deal => {
            const valid = moment(deal.dealDate).isValid();
            if (valid) {
              deal.dealDate = moment.parseZone(deal.dealDate).format('MM/DD/YYYY');
            }
          });
        }
      });
    }
    this.resultsData = response;
  }

  /**
  * Handles the search functionality for querying the system for specific results.
  * @param value The value of the powersearch form.
  */
  public getSearchResults(value): void {
    this.powerSearchFormData = value;
    this.powersearchService.getSearchResultData(value).subscribe((result) => {
      this.transformData(result.gridData);
      this.resultsPagination = result.pagination;
      this.resultsPageOptions = this.powersearchService.getPageOptions(this.resultsData);
    }, error => {
      console.log('Error to get narrow search data.' + error);
    });
  }

  public selectedExportOption(choice): void {
    if (this.selectedReportdisplayLabel === 'I-9 Report' ||
      this.selectedReportdisplayLabel === 'Contract Status Report' ||
      this.selectedReportdisplayLabel === 'Post Sync Time Log' ||
      this.selectedReportdisplayLabel === 'Missing Birthdate Report' ||
      this.selectedReportdisplayLabel === 'Crew list Worksheet' ||
      this.selectedReportdisplayLabel === 'Talent Voucher') {
      this.downloadSelectedExportOpt(choice);
    } else if (this.selectedReportdisplayLabel === 'Station 12 Report') {
      this.selectedExportType = choice;
      this.station12ReportModal.open();
    } else if (this.selectedReportdisplayLabel === 'Billing List') {
      this.selectedExportType = choice;
      this.billingListModal.open();
    } else if (this.selectedReportdisplayLabel === 'Cast List') {
      this.selectedExportType = choice;
      this.castListModal.open();
    } else if (this.selectedReportdisplayLabel === 'Blank Contract') {
      this.selectedExportType = choice;
      this.blankContractModal.open();
    } else if (this.selectedReportdisplayLabel === 'Casting Data Report') {
      this.selectedExportType = choice;
      this.castingDataModal.open();
    }
  }

  public downloadSelectedExportOpt(choice): void {
    choice = choice.toLowerCase();
    this.powersearchService.downloadfile(this.selectedReportdisplayLabel, choice, this.powerSearchFormData,
      this.stationReportStartDate, this.stationReportEndDate, this.sortingOrder, this.castSelections, this.blankReportData, this.castingDataReportData)
      .subscribe((data) => {
        const contentType = data.headers.get('content-type');
        const contentDisposition = data.headers.get('content-disposition');
        const fileName = contentDisposition.split(';')[1].trim().split('=')[1];
        // for browser compatibility
        const ieEDGE = navigator.userAgent.match(/Edge/g);
        const ie = navigator.userAgent.match(/.NET/g); // IE 11+
        const oldIE = navigator.userAgent.match(/MSIE/g);

        if (ie || oldIE || ieEDGE) {
          const blob = new window.Blob([data.body], { type: contentType });
          window.navigator.msSaveBlob(blob, fileName);
        } else {
          const file = new Blob([data.body], { type: contentType });
          const fileURL = URL.createObjectURL(file);
          const hVal = window.screen.height - 200;
          if (choice !== 'pdf') {
            const a: HTMLAnchorElement = document.createElement('a') as HTMLAnchorElement;
            a.href = fileURL;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(fileURL);
          } else {
            window.open(fileURL, '_blank', 'status=1,scrollbars=1,width=500,height=' + hVal + 'top=50,left=200', false);
          }
        }
      },
        error => {
          console.log('Error downloading the file.' + error);
        },
        () => {
          console.log('Success!');
        }
      );
  }

  private prepareChecklist(source, newData): any {
    if (newData) {
      const clonedData = source.map(x => Object.assign({}, x));
      clonedData.forEach(element => {
        let found = false;
        if (element.id) {
          const num = element.id.toString();
          newData.forEach(item => {
            if (num === item.id) {
              found = true;
              return false;
            }
          });
        }
        element.checked = found;
      });
      return clonedData;
    }
    return source;
  }

  private createPowerSearch(data?: any): void {
    const projectConfig = {
      endpoint: 'api/typeAhead/projectTitles',
      displayName: 'title'
    };
    const companyConfig = {
      endpoint: 'api/companies',
      displayName: 'typeAheadDisplayName'
    };
    const performerConfig = {
      endpoint: 'api/typeAhead/performers',
      displayName: 'typeAheadDisplayName'
    };
    const roleConfig = {
      endpoint: 'api/typeAhead/roles',
      displayName: 'typeAheadDisplayName'
    };

    if (!data) {
      const projectTitle = this.navigatedProjectTitleObject;
      let projectTitleOpen = false;
      if (projectTitle && projectTitle.length) {
        projectTitleOpen = true;
      }
      const statusData = { startDate: null, endDate: null, allchecked: true, values: this.projectStatusData };
      this.isEditMode = false;
      this.choices = [
        new PowersearchChoiceModel('projectTitle', projectTitleOpen, 'Project Title', 'typeahead',
          (projectTitle.length > 0 ? projectTitle : null), projectConfig),
        new PowersearchChoiceModel('productionCompany', false, 'Production Company', 'typeahead', null, companyConfig),
        new PowersearchChoiceModel('union', false, 'Union', 'checklist', this.unionData, null),
        new PowersearchChoiceModel('performer', false, 'Performer', 'typeahead', null, performerConfig),
        new PowersearchChoiceModel('role', false, 'Role', 'typeahead', null, roleConfig),
        new PowersearchChoiceModel('billing', false, 'Billing', 'checklist', this.billingData, null),
        new PowersearchGenericChoiceModel('textFields', false, 'Text Fields', 'checklistTextbox',
          { options: this.textFieldsData }, null, this.textFieldsTemplateRef),
        new PowersearchGenericChoiceModel('compensation', false, 'Compensation', 'generic',
          this.compensationData, null, this.compensationTemplateRef),
        new PowersearchGenericChoiceModel('workActivity', false, 'Work Activity', 'generic',
          this.workActivityData, null, this.workActivityTemplateRef),
        new PowersearchChoiceModel('statusDate', false, 'Status', 'statusDate', statusData, null)
      ];
    } else {
      this.isEditMode = true;
      const unionObj = this.prepareChecklist(this.unionData, data['union'] ? data['union'] : null);
      const billingObj = this.prepareChecklist(this.billingData, data['billing'] ? data['billing'] : null);

      let compensation = data['compensation'];
      if (compensation) {
        compensation = { data: compensation.data, operandOptions: compensation.operandOptions, rangOptions: compensation.rangOptions };
      } else {
        compensation = this.compensationData;
      }

      let workActivity = data['workActivity'];
      if (workActivity) {
        workActivity = { data: workActivity.data, operandOptions: workActivity.operandOptions, rangOptions: workActivity.rangOptions };
      } else {
        workActivity = this.workActivityData;
      }
      let statusData = { startDate: null, endDate: null, allchecked: true, values: this.projectStatusData };
      let isStatusOpen = false;
      if (data['statusDate']) {
        statusData = data['statusDate'];
        isStatusOpen = true;
      }

      let textfieldData = { options: this.textFieldsData };
      let isTextfieldOpen = false;
      if (data['textFields']) {
        textfieldData = data['textFields'];
        if (!textfieldData.options.length) {
          textfieldData.options = this.textFieldsData;
        }
        isTextfieldOpen = true;
      }
      const unionMode = (data['union'] ? true : false);
      const billingMode = (data['billing'] ? true : false);
      this.choices = [];
      this.choices = [
        new PowersearchChoiceModel('projectTitle', ((data['projectTitle']) ? true : false),
          'Project Title', 'typeahead', (data['projectTitle'] ? data['projectTitle'] : null), projectConfig),
        new PowersearchChoiceModel('productionCompany', ((data['productionCompany']) ? true : false),
          'Production Company', 'typeahead', (data['productionCompany'] ? data['productionCompany'] : null), companyConfig),
        new PowersearchChoiceModel('union', unionMode, 'Union', 'checklist', unionObj, null, unionMode),
        new PowersearchChoiceModel('performer', ((data['performer']) ? true : false), 'Performer',
          'typeahead', (data['performer'] ? data['performer'] : null), performerConfig),
        new PowersearchChoiceModel('role', ((data['role']) ? true : false), 'Role', 'typeahead',
          (data['role'] ? data['role'] : null), roleConfig),
        new PowersearchChoiceModel('billing', billingMode, 'Billing', 'checklist', billingObj, null, billingMode),
        new PowersearchGenericChoiceModel('textFields', isTextfieldOpen, 'Text Fields', 'checklistTextbox',
          textfieldData, null, this.textFieldsTemplateRef),
        new PowersearchGenericChoiceModel('compensation', ((data['compensation']) ? true : false), 'Compensation', 'generic',
          compensation, null, this.compensationTemplateRef),
        new PowersearchGenericChoiceModel('workActivity', ((data['workActivity']) ? true : false), 'Work Activity', 'generic',
          workActivity, null, this.workActivityTemplateRef),
        new PowersearchChoiceModel('statusDate', isStatusOpen, 'Status', 'statusDate', statusData, null, isStatusOpen)
      ];
    }
  }

  public disableExportOptions(reportType) {
    if (reportType) {
      this.exportOptions.options.forEach(element => {
        element.disabled = false;
      });
      if (reportType.name === 'Blank Contract') {
        this.exportOptions.options.forEach(element => {
          if (element.value === 'Excel' || element.value === 'Word') {
            element.disabled = true;
          } else {
            element.disabled = false;
          }
        });
      } else if (reportType.name === 'Talent Voucher') {
        this.exportOptions.options.forEach(element => {
          if (element.value === 'Excel') {
            element.disabled = true;
          } else {
            element.disabled = false;
          }
        });
      }
    } else {
      this.exportOptions.options.forEach(element => {
        if (element.value === 'Excel') {
          element.disabled = false;
        } else {
          element.disabled = true;
        }
      });
    }
    this.exportOptions = new DropdownModel(null, null, null, null, this.exportOptions.options);
  }

  public selectedEventForReportForm(event) {
    if (event) {
      this.selectedReportdisplayLabel = event.displayLabel;
      this.disableExportOptions(event);
      if (event.name === 'Talent Voucher' || event.name === 'Blank Contract') {
        this.enableExportButton = true;
        this.psEventService.setReportFormDetails(this.enableExportButton);
      } else {
        this.enableExportButton = false;
        this.psEventService.setReportFormDetails(this.enableExportButton);
      }
    }
  }

  public selectedEventForPrevSavedSearch(event) {
    if (event && event.id) {
      this.powersearchService.getPrevSavedSearchById(event.id).subscribe((result) => {
        this.createPowerSearch(this.createObjFromResponseForDisplay(result.saveSearchCriteriaList));
        // Wait still stable formcontrol value iterations
        setTimeout(() => {
          this.triggerSearch = { search: true };
        }, 500);
      }, error => {
        console.log('Error in saving search' + error);
      });
    }/*  else {
      this.psEventService.resetFormEvent('reset');
    } */
  }

  public createObjFromResponseForDisplay(data) {
    const formObj = {};
    data.forEach(element => {
      if (element.criteriaName === 'startDate' || element.criteriaName === 'endDate') {
        let startDate, endDate = new Date();
        if (element.criteriaName === 'startDate') {
          startDate = new Date(element.criteriaValue as any);
        } else if (element.criteriaName === 'endDate') {
          endDate = new Date(element.criteriaValue as any);
        }
        this.dateValuesFromPowerSearch = {
          label: element.criteriaLabel,
          startDate: (element.criteriaValue === 'All') ? element.criteriaValue : startDate,
          endDate: (element.criteriaValue === 'All') ? element.criteriaValue : endDate
        };
        this.psEventService.onChangeDateValuesEvent(this.dateValuesFromPowerSearch);
      } else {
        if (!formObj[element.criteriaName]) {
          formObj[element.criteriaName] = [];
        }
        if (element.criteriaName === 'union' || element.criteriaName === 'billing') {
          if (element.criteriaLabel === 'true') {
            formObj[element.criteriaName].push({
              id: element.criteriaValue,
              value: true,
              name: this.getLabelById(element.criteriaValue, element.criteriaName)
            });
          }
        } else if (element.criteriaName === 'textFields') {
          formObj[element.criteriaName] = {
            condition: element.criteriaCondition,
            options: JSON.parse(element.criteriaValue).options,
            checkBoxValues: JSON.parse(element.criteriaValue).checkBoxValues,
            searchTextValues: JSON.parse(element.criteriaValue).items,
            allChecked: element.criteriaLabel
          };
        } else if (element.criteriaName === 'projectTitle' || element.criteriaName === 'performer'
          || element.criteriaName === 'productionCompany' || element.criteriaName === 'role') {
          formObj[element.criteriaName].push({
            value: JSON.parse(element.criteriaValue),
            condition: element.criteriaCondition
          });
        } else if (element.criteriaName === 'compensation') {
          if (!formObj[element.criteriaName].data) {
            formObj[element.criteriaName].data = [];
          }
          formObj[element.criteriaName].data.push({
            value: JSON.parse(element.criteriaValue),
            condition: element.criteriaCondition,
            label: JSON.parse(element.criteriaLabel)
          });
        } else if (element.criteriaName === 'workActivity') {
          if (!formObj[element.criteriaName].data) {
            formObj[element.criteriaName].data = [];
          }
          formObj[element.criteriaName].data.push({
            value: JSON.parse(element.criteriaValue),
            condition: element.criteriaCondition,
            label: JSON.parse(element.criteriaLabel)
          });
        } else if (element.criteriaName === 'statusDate') {
          formObj[element.criteriaName] = (JSON.parse(element.criteriaValue));
        }
      }
    });
    if (formObj['compensation']) {
      formObj['compensation'].rangOptions = this.compensationData.rangOptions;
      formObj['compensation'].operandOptions = this.compensationData.operandOptions;
    }
    if (formObj['workActivity']) {
      formObj['workActivity'].rangOptions = this.workActivityData.rangOptions;
      formObj['workActivity'].operandOptions = this.workActivityData.operandOptions;
    }
    return formObj;
  }

  public getLabelById(id, name) {
    let label = '';
    let valArray;
    if (name === 'union' || name === 'textFields') {
      valArray = this.unionData;
    } else if (name === 'billing') {
      valArray = this.billingData;
    }

    valArray.forEach(element => {
      if (element.id && element.id.toString() === id) {
        label = element.name;
      }
    });
    return label;
  }

  private createCriteriaObj(criteria: any): any {
    const reqObj = {
      criteriaName: criteria.key,
      criteriaCondition: criteria.condition ? criteria.condition : null,
      criteriaLabel: criteria.label ? (typeof criteria.label === 'object' ? JSON.stringify(criteria.label) : criteria.label) : null,
      criteriaValue: criteria.obj ? (typeof criteria.obj === 'object' ? JSON.stringify(criteria.obj) : criteria.obj) : null,
      clauseCondition: null,
      defaultCriteria: true,
      queryCriteriaId: null
    };
    return reqObj;
  }

  public createReqObjForSaveSearch(data) {
    let id;
    this.previouslySavedSearchOptions.options.forEach(element => {
      if (element.value === data.event.value) {
        id = element.id;
      }
    });
    const reqObj = {
      queryId: id ? id : null,
      queryName: data.event.value,
      saveSearchCriteriaList: []
    };
    const skipCheck = ['union', 'billing', 'statusDate'];
    for (const [key, value] of Object.entries(data.formData)) {
      if (Array.isArray(value)) {
        value.forEach(element => {
          if (skipCheck.includes(key) || element.value) {
            let requestObj = { key: key, condition: element.condition, label: null, obj: null };
            if (key === 'projectTitle' || key === 'productionCompany' || key === 'performer') {
              requestObj = { ...requestObj, label: element.value.value, obj: element.value.data };
              reqObj.saveSearchCriteriaList.push(this.createCriteriaObj(requestObj));
            } else if (key === 'union') {
              if (element.id) {
                requestObj = { ...requestObj, label: element.value, obj: element.id };
                reqObj.saveSearchCriteriaList.push(this.createCriteriaObj(requestObj));
              }
            } else if (key === 'role') {
              requestObj = {
                ...requestObj, label: element.value.value,
                obj: { typeAheadDisplayName: element.value.value }
              };
              reqObj.saveSearchCriteriaList.push(this.createCriteriaObj(requestObj));
            } else if (key === 'billing') {
              if (element.id) {
                requestObj = { ...requestObj, label: element.value, obj: element.id };
                reqObj.saveSearchCriteriaList.push(this.createCriteriaObj(requestObj));
              }
            } else if (key === 'textFields') {
              if (element.formChanged) {
                const checkArr =  (element.values && element.values.length) ? element.values : [];
                requestObj = {
                  ...requestObj,
                  label: element.allchecked,
                  obj: {
                    options: element.options,
                    checkBoxValues: checkArr,
                    items: element.items
                  }
                };
                reqObj.saveSearchCriteriaList.push(this.createCriteriaObj(requestObj));
              }
            } else if (key === 'statusDate') {
              if (element.values && element.values.length) {
                requestObj = { ...requestObj, obj: element };
                reqObj.saveSearchCriteriaList.push(this.createCriteriaObj(requestObj));
              }
            } else if (key === 'compensation' || key === 'workActivity') {
              const criteriaObj = {
                value: element.value ? element.value.value : null,
                value1: element.value1 ? element.value1 : null,
                value2: element.value2 ? element.value2 : null
              };
              if (criteriaObj.value || criteriaObj.value1 || criteriaObj.value2) {
                requestObj = {
                  ...requestObj,
                  label: {
                    type: element.type,
                    operation: element.operation,
                    isRange: element.isRange,
                    condition: element.condition
                  },
                  obj: criteriaObj
                };
                reqObj.saveSearchCriteriaList.push(this.createCriteriaObj(requestObj));
              }
            }
          }
        });

      }

      if (key === 'startDate' || key === 'endDate') {
        const isValid = moment(value).isValid();
        let date = null;
        if (isValid) {
          date = moment.parseZone(value).format();
        }
        const requestObj = { key: key, label: this.getDateRange(data.dateRange), obj: (value === 'All' || !value) ? 'All' : date };
        reqObj.saveSearchCriteriaList.push(this.createCriteriaObj(requestObj));
      }
    }
    return reqObj;
  }

  public getDateRange(dateRange) {
    let range: any = 'All';
    if (dateRange) {
      if (dateRange.indexOf('30') > -1) {
        range = 30;
      } else if (dateRange.indexOf('60') > -1) {
        range = 60;
      } else if (dateRange.indexOf('90') > -1) {
        range = 90;
      } else if (dateRange.indexOf('180') > -1) {
        range = 180;
      } else if (dateRange.indexOf('Custom') > -1) {
        range = 'custom';
      }
    }
    return range;
  }

  public refreshPrevSavedSearchValues() {
    this.powersearchService.getPrevSavedSearchesForUser().subscribe((result) => {
      this.previouslySavedSearchOptions = this.getDropdownOptionsForPrevSavedSearch(result);
    }, error => {
      console.log('Error in getting previous/saved search values' + error);
    });
  }


  public saveSearch(event) {
    if (event.event.action === 'OK') {
      const reqObj = this.createReqObjForSaveSearch(event);
      this.powersearchService.savePrevSavedSearch(reqObj).subscribe((result) => {
        this.setSearchOption = {
          data: { queryName: result.queryName, queryId: result.queryId },
          id: result.queryId,
          value: result.queryName
        };

        this.refreshPrevSavedSearchValues();
      }, error => {
        console.log('Error in saving search' + error);
      });
    }
  }

  public deleteSearch(event) {
    this.powersearchService.deletePrevSavedSearch(event.id).subscribe((result) => {
      this.psEventService.resetFormEvent('reset');
    }, error => {
      this.psEventService.resetFormEvent('reset');
      console.log('Error in deleting previous/saved search value' + error);
    });
  }

  public displaySavedSearchName(event) {
    this.saveSearchModalInput = event;
  }

  /** Method to get Station12 report date range*/
  public stationReportSelection(event) {
    if (event.action === 'Ok') {
      this.stationReportStartDate = this.removeTimezone(event.formData.fromDate);
      this.stationReportEndDate = this.removeTimezone(event.formData.toDate);
      if (this.stationReportEndDate != null && this.stationReportStartDate != null) {
        this.downloadSelectedExportOpt(this.selectedExportType);
      }
    }
    this.stationReportEndDate = null;
    this.stationReportStartDate = null;
  }
  public sortOrderSelection(event) {
    this.sortingOrder = '';
    if (event.action === 'Ok') {
      this.sortingOrder = event.formData;
    }
    this.downloadSelectedExportOpt(this.selectedExportType);
  }

  public castingDataReportSelection(event) {
    if (event.action === 'Ok') {
      this.castingDataReportData = event.formData;
    }
    this.downloadSelectedExportOpt(this.selectedExportType);
  }


  public blankReportSelection(event) {
    this.blankReportData = new BlankContractModel();
    this.blankReportData = event.formData;
    this.dealService.downloadfile(-1, this.blankReportData.contractType, this.blankReportData, true).subscribe(
      (data) => {
        // for browser compatibility
        const ieEDGE = navigator.userAgent.match(/Edge/g);
        const ie = navigator.userAgent.match(/.NET/g); // IE 11+
        const oldIE = navigator.userAgent.match(/MSIE/g);
        const name = 'file';
        const blob = new window.Blob([data], { type: 'application/pdf' });

        if (ie || oldIE || ieEDGE) {
          const fileName = name + '.pdf';
          window.navigator.msSaveBlob(blob, fileName);
        } else {
          const file = new Blob([data], {
            type: 'application/pdf'
          });
          const fileURL = URL.createObjectURL(file);
          window.open(fileURL);
        }
      },
      error => {
        console.log('Error downloading the file.' + error);
      },
      () => {
        console.log('complete');
      }
    );
    // this.downloadSelectedExportOpt(this.selectedExportType);

  }

  public includeSelection(event) {
    if (event.action === 'Ok') {
      this.castSelections = event.formData;
    }
    this.downloadSelectedExportOpt(this.selectedExportType);
  }

  /* Method to remove timezone from date*/
  public removeTimezone(date) {
    let format = null;
    const isValid = moment(date).isValid();
    if (isValid) {
      format = moment.parseZone(date).format('YYYY-MM-DD');
    }
    return format;
  }

  public ngOnDestroy(): void {
    this.navigatedProjectTitleObject.length = 0;
  }

}
