import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { CreateDealComponent } from './create-deal.component';
import { NgbTypeaheadConfig } from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { WizardModule, FormModule, ButtonModule, TypeAheadModule, TypeAheadEventService,
         TypeAheadPersistService, ModalModule, CommonSharedModule, TypeAheadModalModule } from 'c2c-common-lib';
import { NameProjectDetailsComponent } from '../../components/name-project-details/name-project-details.component';
import { CompensationComponent } from '../../components/compensation/compensation.component';
import { LoanoutComponent } from '../../components/loanout/loanout.component';
import { NoticesPaymentsComponent } from '../../components/notices-payments/notices-payments.component';
import { CreditComponent } from '../../components/credit/credit.component';
import { PerqsComponent } from '../../components/perqs/perqs.component';
import { SummaryComponent } from '../../components/summary/summary.component';
import { WorkActivityComponent } from '../../components/work-activity/work-activity.component';
import { DealService } from '../../services/http/deal/deal.service';
import { CompensationService } from '../../services/http/deal/compensation.service';
import { PerqsService } from '../../services/http/deal/perqs.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DealEventService } from '../../services/events/deal-event.service';
import { SummaryHeaderComponent } from '../../components/summary/summary-header/summary-header.component';
import { SummaryNameProjectDetailsComponent } from '../../components/summary/summary-name-project-details/summary-name-project-details.component';
import { SummaryLoanoutComponent } from '../../components/summary/summary-loanout/summary-loanout.component';
import { SummaryCreditsComponent } from '../../components/summary/summary-credits/summary-credits.component';
import { SummaryPerqsComponent } from '../../components/summary/summary-perqs/summary-perqs.component';
import { SummaryCompensationsComponent } from '../../components/summary/summary-compensations/summary-compensations.component';
import { SummaryNoticePaymentsComponent } from '../../components/summary/summary-notice-payments/summary-notice-payments.component';
import { NoticesPaymentsService } from '../../services/http/deal/notices-payments.service';
import { DealPerformerCardComponent } from '../../components/deal-performer-card/deal-performer-card.component';
import { LoanoutEinValidatorDirective } from '../../directives/loanoutEinValidator';
import { AutoResizeTextAreaDirective } from '../../directives/auto-resize-text-area-directive';
import { SanitizeHtmlPipe } from '../../pipes/sanitize-html';
import { AddEditPerformerModule } from '../add-edit-performer/add-edit-performer.module';
import { SharedCreateEditPersonModule } from '../shared-create-edit-person/shared-create-edit.module';
import { CreateCompanyModule } from '../create-production-company/create-company.module';
/**
 * The CreateDealModule
 *
 * Module that contains all Deal/Contract (creation) related components.
 */
@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    WizardModule,
    FormModule,
    ButtonModule,
    BrowserModule,
    ModalModule,
    TypeAheadModule,
    CommonSharedModule,
    NgbModule.forRoot(),
    TypeAheadModalModule.forRoot(),
    AddEditPerformerModule,
    SharedCreateEditPersonModule,
    CreateCompanyModule
  ],
  declarations: [
    CreateDealComponent,
    NameProjectDetailsComponent,
    CompensationComponent,
    LoanoutComponent,
    NoticesPaymentsComponent,
    CreditComponent,
    PerqsComponent,
    WorkActivityComponent,
    SummaryComponent,
    SummaryHeaderComponent,
    SummaryNameProjectDetailsComponent,
    SummaryLoanoutComponent,
    SummaryCreditsComponent,
    SummaryPerqsComponent,
    SummaryCompensationsComponent,
    SummaryNoticePaymentsComponent,
    DealPerformerCardComponent,
    LoanoutEinValidatorDirective,
    AutoResizeTextAreaDirective,
    SanitizeHtmlPipe
  ],
  providers: [DealService, NgbTypeaheadConfig, DealEventService, CompensationService,
              PerqsService, NoticesPaymentsService, TypeAheadEventService, TypeAheadPersistService]
})
export class CreateDealModule { }
