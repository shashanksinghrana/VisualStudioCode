import { Component, OnInit, ViewContainerRef, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuditModel } from 'c2c-common-lib';
import { DealService } from '../../services/http/deal/deal.service';
import { DealStatus } from './deal-status.enum';
import { WizardModel } from '../../models/deal/wizard.model';
import { DealEventService } from '../../services/events/deal-event.service';
import { LookupModel } from '../../models/shared/lookup.model';
import { ToastsManager } from '../../../../node_modules/ng2-toastr';
import { Subscription } from 'rxjs';

@Component({
  selector: 'fc-create-deal',
  templateUrl: './create-deal.component.html',
  styleUrls: ['./create-deal.component.scss']
})

/**
 * The CreateDealComponent
 *
 * Component for displaying deal creation page for a specific project.
 */
export class CreateDealComponent implements OnInit, OnDestroy {
  public audit: AuditModel;
  public currentIndex: number;
  public dealId: string;
  public wizards: WizardModel[] = [];
  public wizardSections: any[] = [];
  public wizardSubTitles: Array<string> = [];
  public wizardTitle: string = 'Deal Memo';
  private subscriptions: Subscription = new Subscription();
  /**
  * The Constructor for CreateDealComponent
  *
  * @param dealService The Create Deal Service for getting data.
  */
  constructor(
    private dealService: DealService,
    private dealEventService: DealEventService,
    private route: ActivatedRoute,
    private router: Router,
    private toaster: ToastsManager,
    private vcr: ViewContainerRef

  ) {
    this.toaster.setRootViewContainerRef(vcr);
    this.route.params.subscribe(res => {
      this.dealService.setDealId(res.dealId);
      this.dealId = res.dealId;
    });
    this.subscriptions.add(
      this.dealService.getWizardDetails().subscribe((data: WizardModel[]) => {
        this.wizards = data;
        for (const wizard of data) {
          let pageRoute = wizard.page.name;
          pageRoute = pageRoute.charAt(0).toLowerCase() + pageRoute.substring(1);
          pageRoute = pageRoute.replace(/[\W\s]+/gi, '');

          const obj = { page: null, status: null, route: null };
          obj.page = wizard.page.name;
          obj.status = wizard.status;
          obj.route = pageRoute;

          this.wizardSections.push(obj);
        }
      })
    )

    this.subscriptions.add(
      this.dealEventService.getPageSavedEvent()
        .subscribe(value => {
          this.updateWizard(value.type, value.pageTo, value.dealId, value.status);
          if (this.dealService.currentWizardPage.page.name === 'Names/Project Details') {
            this.dealService.saveWizardSubtitles(this.dealService.deal);
          }
          else if (this.dealService.currentWizardPage.page.name === 'Work Activity') {
            this.navigateDeal(value.type, value.pageTo);
          }
        })
    )
  }

  public ngOnInit(): void {
    this.addSubscriptions();
    this.route.data.subscribe(
      (data: { deal: any }) => {
        this.dealService.deal = data.deal;
        this.dealService.saveWizardSubtitles(this.dealService.deal);
        this.wizardSubTitles = this.dealService.wizardSubTitles;
        this.audit = this.dealService.audit ? this.dealService.audit : new AuditModel(null, null, null, null);
      },
      (error) => {
        console.log('Error when getting deal', error);
      }
    );
  }

  private addSubscriptions(): void {
    this.subscriptions.add(this.dealService.getWizardDetail().subscribe(res => 
      {
        this.wizardSections = []
        this.wizardSections = res;
    }))
  }

  /**
   * We will use this function for updating the status of the wizard tile when we
   * begin implementing the pages for the wizard.
   *
   * @param wizard the wizard to be updated
   */
  public updateWizard(type, pageTo?, dealId?, status?) {
    if (dealId) { this.dealId = dealId; }
    this.dealService.currentWizardPage.dealId = Number.parseInt(this.dealId);
    this.dealService.currentWizardPage.status = new LookupModel(null, null, (status !== null && status !== undefined) ? status : DealStatus.COMPLETE, 'WIZARD_INDICATOR');
    this.dealService.currentWizardPage.wizardType = 'STATUS';
    this.subscriptions.add(
      this.dealService.updateWizardDetails(this.dealService.currentWizardPage).subscribe(
        (res) => {
          this.wizardSections[this.currentIndex].status = res.status;
          this.navigateDeal(type, pageTo);
          this.wizardSubTitles = this.dealService.wizardSubTitles;
          this.dealService.getDeal(this.dealId).subscribe(
            (deal) => {
              this.dealService.deal = deal;
              this.dealService.setDealId(this.dealId);
              this.audit = this.dealService.audit;
            }
          );
        },
        (err) => {
          console.error('There was an error', err);
        }
      )
    )
  }

  public navigateDeal(type?: string, pageTo?: string) {
    // let nextRoute: string = this.wizardSections[this.currentIndex + 1].route; // TODO
    switch (type) {
      case 'continue':
        this.router.navigate([`createDeal/${this.dealId}/${pageTo}`]);
        break;
      default:
        this.router.navigate([`createDeal/${this.dealId}/summary`]);
        break;
    }
  }

  public pageIndexEvent(index) {
    this.dealService.currentWizardPage = this.wizards[index - 1];
    this.currentIndex = index - 1;
  }

  public ngOnDestroy(): void {
    this.dealService.deal = null;
    this.dealService.dealId = null;
    this.dealService.wizardSubTitles = null;
    this.wizardSubTitles = null;
    this.wizardSections[this.currentIndex].status = null;
    this.wizards = null;
    this.subscriptions.unsubscribe();
  }
}
