import { AllProjectsService } from './../../services/http/all-projects/all-projects.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyProjectsComponent } from './my-projects.component';
import { GridModule } from 'c2c-common-lib';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    GridModule.forRoot()
  ],
  declarations: [MyProjectsComponent],
  providers: [AllProjectsService]
})
export class MyProjectsModule { }
