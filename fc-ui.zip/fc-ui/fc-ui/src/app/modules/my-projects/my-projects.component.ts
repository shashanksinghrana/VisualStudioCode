import { Component } from '@angular/core';
import {
  AddButtonModel, ColumnDefModel,
  UrlResolverService, NavBarEventService, NavBarHistoryModel
} from 'c2c-common-lib';
import { AllProjectsService } from '../../services/http/all-projects/all-projects.service';
import { HttpParams } from '@angular/common/http';
import { ProjectDetailService } from '../../services/http/project-detail/project-detail.service';

@Component({
  selector: 'fc-my-projects',
  templateUrl: './my-projects.component.html',
  styleUrls: ['./my-projects.component.scss']
})
export class MyProjectsComponent {
  public addButtonOptions: AddButtonModel =
    new AddButtonModel('fc', 'myProject', 'navigate', '/createEditProject');
  // public refreshButtonOptions: RefreshButtonModel =
  //   new RefreshButtonModel('fc', 'allProjects');

  public allProjectsData: any[];
  public pageOptions: {};
  public pagination: any;
  public projectListDefs: ColumnDefModel[];

  constructor(private allProjectsService: AllProjectsService,
    private urlResolverService: UrlResolverService,
    private navBarEventService: NavBarEventService,
    private projectDetailService: ProjectDetailService) {
    this.pageOptions = allProjectsService.getPageOptions(true);
    this.projectListDefs = allProjectsService.createColumnDefs();
    this.getMyProjectsData();
    this.addButtonOptions.tooltip = 'Create Project';
    this.projectDetailService.project = {};
  }

  public getMyProjectsData(params?: HttpParams) {
    this.allProjectsService.getMyProjects(params).subscribe(
      (data) => {
        this.allProjectsData = data.projects;
        this.pagination = data.pagination;
      }
    );
  }

  /** Method to define history items*/
  public getPerformerClicked(evt: any): void {
    const url = this.urlResolverService.getServiceEndpointUrl(`#${evt.route}/performers`);
    const title = evt.subtitle ? `${evt.title} (${evt.subtitle})` : evt.title;
    const historyItem: NavBarHistoryModel = new NavBarHistoryModel();

    historyItem.destinationUrl = url;
    historyItem.historyLabel = title;
    historyItem.iconClass = 'navbar-projector';
    historyItem.source = 'FC';

    this.navBarEventService.setNavBarHistory(historyItem);
  }

  /**
   * Listens for the Grid's sort/filter/pagination event and performs server-side operations on the data.
   *
   * @param params The HttpParams to send to the back-end for the server-side operations.
   */
  public onDataChanged(params: HttpParams): void {
    this.getMyProjectsData(params);
  }

  public refreshGridData() {
    // reset filtering and reset sorting taken care of by the grid...
    // implement any additional desired functionality here for when refresh button clicked...
  }
}
