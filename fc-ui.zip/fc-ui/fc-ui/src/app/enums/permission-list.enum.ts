export enum PermissionList {
    allProjectEdit = 'FeatureCasting.AllProjects.CREATE',
    allProjectView = 'FeatureCasting.AllProjects.VIEW',
    performerView = 'FeatureCasting.ProjectDetails.Performers.VIEW',
    performerEdit = 'FeatureCasting.ProjectDetails.Performers.CREATE',
    createEditProjectCreate = 'FeatureCasting.CreateEditProject.CREATE',
    createEditProjectView = 'FeatureCasting.CreateEditProject.VIEW',
    createEditProjectEdit = 'FeatureCasting.CreateEditProject.UPDATE',
    projectDetailView = 'FeatureCasting.ProjectDetails.VIEW',
    projectDetailUpdate = 'FeatureCasting.ProjectDetails.UPDATE',
    projectDetailsBillingView = 'FeatureCasting.ProjectDetails.Billing.VIEW',
    projectDetailsBillingEdit = 'FeatureCasting.ProjectDetails.Billing.UPDATE',
    projectDetailsWorkWeakCreate = 'FeatureCasting.ProjectDetails.WorkWeek.CREATE',
    projectDetailsWorkWeakView = 'FeatureCasting.ProjectDetails.WorkWeek.VIEW',
    projectDetailsWorkWeekEdit = 'FeatureCasting.ProjectDetails.WorkWeek.UPDATE',
    projectDetailsCrewCreate = 'FeatureCasting.ProjectDetails.Crew.CREATE',
    projectDetailsCrewUpdate = 'FeatureCasting.ProjectDetails.Crew.UPDATE',
    projectDetailsCrewView = 'FeatureCasting.ProjectDetails.Crew.VIEW',
    projectDetailsStatusDatesCreate = 'FeatureCasting.ProjectDetails.StatusDates.CREATE',
    projectDetailsStatusDatesUpdate = 'FeatureCasting.ProjectDetails.StatusDates.UPDATE',
    projectDetailsStatusDatesView = 'FeatureCasting.ProjectDetails.StatusDates.VIEW',
    projectDetailsLocationView = 'FeatureCasting.ProjectDetails.Locations.VIEW',
    projectDetailsLocationCreate = 'FeatureCasting.ProjectDetails.Locations.CREATE',
    projectDetailsLocationEdit = 'FeatureCasting.ProjectDetails.Locations.UPDATE',
    
    dealCreateEditView = 'FeatureCasting.DealCreateEdit.VIEW',
    dealCreateEditEdit = 'FeatureCasting.DealCreateEdit.UPDATE',
    dealCreateEditCreate = 'FeatureCasting.DealCreateEdit.CREATE'
}


// {authority: "FeatureCasting.ProjectDetails.Locations.CREATE"}
// 25: {authority: "FeatureCasting.ProjectDetails.Locations.DELETE"}
// 26: {authority: "FeatureCasting.ProjectDetails.Locations.UPDATE"}
// 27: {authority: "FeatureCasting.ProjectDetails.Locations.VIEW"}
// {authority: "FeatureCasting.DealCreateEdit.CREATE"},
// {authority: "FeatureCasting.DealCreateEdit.DELETE"},
// {authority: "FeatureCasting.DealCreateEdit.UPDATE"},
// {authority: "FeatureCasting.DealCreateEdit.VIEW"},

// {authority: "FeatureCasting.AllProjects.CREATE"},
// {authority: "FeatureCasting.AllProjects.DELETE"},
// {authority: "FeatureCasting.AllProjects.UPDATE"},
// {authority: "FeatureCasting.AllProjects.VIEW"},

// {authority: "FeatureCasting.CreateEditProject.CREATE"},
// {authority: "FeatureCasting.CreateEditProject.DELETE"},
// {authority: "FeatureCasting.CreateEditProject.UPDATE"},
// {authority: "FeatureCasting.CreateEditProject.VIEW"},

// {authority: "FeatureCasting.ProjectDetails.CREATE"},
// {authority: "FeatureCasting.ProjectDetails.DELETE"},
// {authority: "FeatureCasting.ProjectDetails.UPDATE"},
// {authority: "FeatureCasting.ProjectDetails.VIEW"},


// {authority: "FeatureCasting.ProjectDetails.Performers.CREATE"},
// {authority: "FeatureCasting.ProjectDetails.Performers.DELETE"},
// {authority: "FeatureCasting.ProjectDetails.Performers.UPDATE"},
// {authority: "FeatureCasting.ProjectDetails.Performers.VIEW"},

// {authority: "FeatureCasting.ProjectDetails.Billing.CREATE"},
// {authority: "FeatureCasting.ProjectDetails.Billing.DELETE"},
// {authority: "FeatureCasting.ProjectDetails.Billing.UPDATE"},
// {authority: "FeatureCasting.ProjectDetails.Billing.VIEW"},


// {authority: "FeatureCasting.ProjectDetails.Locations.CREATE"},
// {authority: "FeatureCasting.ProjectDetails.Locations.DELETE"},
// {authority: "FeatureCasting.ProjectDetails.Locations.UPDATE"},
// {authority: "FeatureCasting.ProjectDetails.Locations.VIEW"},

// {authority: "FeatureCasting.ProjectDetails.WorkWeek.CREATE"},
// {authority: "FeatureCasting.ProjectDetails.WorkWeek.DELETE"},
// {authority: "FeatureCasting.ProjectDetails.WorkWeek.UPDATE"},
// {authority: "FeatureCasting.ProjectDetails.WorkWeek.VIEW"},

// {authority: "FeatureCasting.ProjectDetails.Crew.CREATE"},
// {authority: "FeatureCasting.ProjectDetails.Crew.DELETE"},
// {authority: "FeatureCasting.ProjectDetails.Crew.UPDATE"},
// {authority: "FeatureCasting.ProjectDetails.Crew.VIEW"},

// {authority: "FeatureCasting.ProjectDetails.StatusDates.CREATE"},
// {authority: "FeatureCasting.ProjectDetails.StatusDates.DELETE"},
// {authority: "FeatureCasting.ProjectDetails.StatusDates.UPDATE"},
// {authority: "FeatureCasting.ProjectDetails.StatusDates.VIEW"},

// {authority: "FeatureCasting.CreateEditProject.CREATE"},
// {authority: "FeatureCasting.CreateEditProject.DELETE"},
// {authority: "FeatureCasting.CreateEditProject.UPDATE"},
// {authority: "FeatureCasting.CreateEditProject.VIEW"},

