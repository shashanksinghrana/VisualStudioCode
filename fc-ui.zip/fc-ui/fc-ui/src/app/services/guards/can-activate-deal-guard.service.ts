import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { CanActivate } from '@angular/router';
import { DealService } from '../http/deal/deal.service';

/**
 * The CanActivateDealGuard
 *
 * Prevents user from navigating to other parts of the deal flow, if the 'Name/Project Details' page hasn't been saved.
 */
@Injectable()
export class CanActivateDealGuard implements CanActivate {
  constructor(private dealService: DealService) { }

  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
    return this.dealService.dealId !== 'new' ? true : false;
  }

}
