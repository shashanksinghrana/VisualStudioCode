import { Injectable, Inject } from '@angular/core';;
import { TypeAheadPersistService } from 'c2c-common-lib';
import { CurrentUser } from '../../../models/users/current-user.model';

@Injectable()
export class CurrentUserPersistService {

  private _currentUser: CurrentUser = new CurrentUser();

 constructor(@Inject(TypeAheadPersistService) private typeAheadPersistService: TypeAheadPersistService) {}

  getCurrentUser(): CurrentUser {
    return this._currentUser;
  }

  setCurrentUser(val: CurrentUser) {
    this._currentUser = val;
    this.typeAheadPersistService.setUserRole(val.role);
  }
}
