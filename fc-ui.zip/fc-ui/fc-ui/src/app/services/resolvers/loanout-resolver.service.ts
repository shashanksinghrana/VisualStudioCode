import { Injectable } from '@angular/core';

import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';

import { SharedService } from '../http/shared/shared.service';

import { FormBuilder } from '@angular/forms';

import { DealService } from '../http/deal/deal.service';
import { ProjectDetailService } from '../http/project-detail/project-detail.service';
import { map, take } from 'rxjs/operators';
import { LoanoutModel } from '../../models/deal/loanout.model';


@Injectable()
export class LoanoutResolverService implements Resolve<LoanoutModel> {

  constructor(
    private dealService: DealService,
    private sharedService: SharedService,
    private projectDetailService: ProjectDetailService,
    private router: Router,
    private fb: FormBuilder) { }

  public resolve(route: ActivatedRouteSnapshot): any {
    const dealId = route.parent.paramMap.get('dealId') ? route.parent.paramMap.get('dealId') : 'new';
    if (dealId !== 'new') {
      return this.dealService.getLoanout(+dealId).pipe(
        take(1),
        map((loanout: LoanoutModel[]) => {
          if (loanout) {
             return loanout;
          } else {
            return null;
          }
        })
      );
    } else {
      return new LoanoutModel(null, null, null, null, null, null, null, null, null);
    }
  }
}
