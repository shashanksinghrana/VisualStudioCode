import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { DealService } from '../http/deal/deal.service';
import { ProjectDetailService } from '../http/project-detail/project-detail.service';
import { map, take } from 'rxjs/operators';
import { CreditModel } from '../../models/deal/credit.model';
import { BillingSetModel } from '../../models/deal/billing-set.model';
import { CreditSetModel } from '../../models/deal/credit-set.model';

@Injectable()
export class CreditResolverService implements Resolve<CreditModel> {

  constructor(
    private dealService: DealService,
    private projectDetailService: ProjectDetailService,
    private router: Router,
    private fb: FormBuilder) { }

  public resolve(route: ActivatedRouteSnapshot): any {
    const dealId = route.parent.paramMap.get('dealId') ? route.parent.paramMap.get('dealId') : 'new';
    /* const project = this.projectDetailService.project;
    if (project === undefined) {
      this.router.navigate(['/allProjects']);
      return;
    } */

    if (dealId !== 'new') {
      return this.dealService.getCredit(+dealId).pipe(
        take(1),
        map((credit: CreditModel) => {
          if (credit) {
            credit.creditedName = 'Static Name';
            credit.creditDetail = credit.creditDetail ? credit.creditDetail : new CreditSetModel(null, null, null);
            credit.creditBilling = credit.creditBilling ? credit.creditBilling : new BillingSetModel(null, null);
            return credit;
          } else {
            return null;
          }
        })
      );
    } else {
      return new CreditModel('Static Name',
        new CreditSetModel(null, null, null),
        new BillingSetModel(null, null)
      );
    }
  }
}
