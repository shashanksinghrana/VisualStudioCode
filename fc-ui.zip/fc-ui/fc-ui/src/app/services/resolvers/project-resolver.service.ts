import { Injectable } from '@angular/core';
import { ProjectDetailModel } from '../../models/project/project-detail.model';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { ProjectDetailService } from '../http/project-detail/project-detail.service';
import { Observable } from 'rxjs/Observable';
import { map, take } from 'rxjs/operators';

@Injectable()
export class ProjectResolverService implements Resolve<ProjectDetailModel> {

  constructor(private projectDetailService: ProjectDetailService) { }

  public resolve(route: ActivatedRouteSnapshot): Observable<ProjectDetailModel> {
    const id = route.paramMap.get('projectId');

    return this.projectDetailService.getProjectDetails(+id).pipe(
      take(1),
      map(detail => {
        if (detail) {
          return detail;
        } else {
          return null;
        }
      })
    );

  }
}
