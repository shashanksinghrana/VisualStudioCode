import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { DropdownModel } from 'c2c-common-lib';
import { SharedService } from '../../http/shared/shared.service';
import { forkJoin } from 'rxjs/observable/forkJoin';


@Injectable()
export class LoanoutDropdownService implements Resolve<DropdownModel> {

  constructor(private sharedService: SharedService) { }

  public resolve(route: ActivatedRouteSnapshot): any {
    const states = this.getDropdownValue('STATES').map(studioData => studioData);
    const countries = this.getDropdownValue('COUNTRIES').map(statusData => statusData);
    
    return forkJoin([states, countries]).map(
      (res) => {
        return {
          'states': res[0],
          'countries': res[1]          
        };
      }
    );
  }

  private getDropdownValue(type: string) {
    const dropdown: DropdownModel = new DropdownModel('', '', '', '', []);
    return this.sharedService.getGenericLookupDropdown(type).map(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          dropdown.options.push({
            value: data[i].value,
            abbr: data[i].abbreviation,
            id: data[i].id,
            data: data[i]
          });
        }
        return dropdown;
      }
    )
  }
}
