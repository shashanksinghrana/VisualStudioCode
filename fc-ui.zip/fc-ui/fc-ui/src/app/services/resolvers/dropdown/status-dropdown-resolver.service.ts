import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { SharedService } from '../../http/shared/shared.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class StatusDropdownResolver implements Resolve<any[]> {

    constructor(private sharedService: SharedService) { }

    public resolve(): Observable<any[]> {
        const options: any[] = [];
        options.push({ value: '', route: '', id: '' });
        return this.sharedService.getDropdown('PROJECT_STATUS').map(
            (data) => {
                for (let i = 0; i < Object.keys(data).length; i++) {
                    options.push({
                        value: data[i].name,
                        route: '',
                        id: data[i].id
                    });
                }
                return options;
            }
        );
    }
}
