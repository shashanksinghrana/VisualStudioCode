import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { SharedService } from '../../http/shared/shared.service';
import { DropdownModel } from 'c2c-common-lib';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class StudioDropdownResolver implements Resolve<DropdownModel> {

  constructor(private sharedService: SharedService) { }

  public resolve(): Observable<DropdownModel> {
    const studioDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
    return this.sharedService.getDropdown('USER_STUDIOS').map(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          studioDropdown.options.push({
            value: data[i].name,
            route: '',
            id: data[i].id,
            type: data[i].type,
            displayOrder: data[i].displayOrder
          });
        }
        return studioDropdown;
      }
    );
  }
}
