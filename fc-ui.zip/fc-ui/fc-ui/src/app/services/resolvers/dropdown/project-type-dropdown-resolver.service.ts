import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { SharedService } from '../../http/shared/shared.service';
import { DropdownModel } from 'c2c-common-lib';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ProjectTypeDropdownResolver implements Resolve<DropdownModel> {

  constructor(private sharedService: SharedService) { }

  public resolve(): Observable<DropdownModel> {
    const typeDropdown: DropdownModel = new DropdownModel('', '', '', '', []);
    return this.sharedService.getDropdown('PROJECT_TYPE').map(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          typeDropdown.options.push({
            value: data[i].name,
            route: '',
            id: data[i].id
          });
        }
        return typeDropdown;
      }
    );
  }
}
