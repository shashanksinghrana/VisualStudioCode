import { Injectable } from '@angular/core';
import { ProjectDetailModel } from '../../models/project/project-detail.model';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { CreateEditProjectService } from '../http/create-edit-project/create-edit-project.service';
import { SharedService } from '../http/shared/shared.service';
import { DropdownModel } from 'c2c-common-lib';
import { FormBuilder } from '@angular/forms';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Injectable()
export class CreateEditProjectResolver implements Resolve<any> {

  constructor(private createEditProjectService: CreateEditProjectService, private sharedService: SharedService, private fb: FormBuilder) { }

  public resolve(route: ActivatedRouteSnapshot): any {
    const studios = this.getDropdownValue('USER_STUDIOS').map(studioData => studioData);
    const statuses = this.getDropdownValue('PROJECT_STATUS').map(statusData => statusData);
    const types = this.getDropdownValue('PROJECT_TYPE').map(typesData => typesData);
    const assignedToUsers = this.getAssignedToDropdownValue('assignedToUsers').map(usersData => usersData);
    const productionCompanies = this.getDropdownValue('PROD_COMPANY').map(companiesData => companiesData);
    const unions = this.getDropdownValue('UNION').map(unionData => unionData);
    const signatories = this.getSignatoryDropdownValue('lookup/signatories').map(signatoryData => signatoryData);

    return forkJoin([studios, statuses, types, assignedToUsers, productionCompanies, unions, signatories]).map(
      (res) => {
        return {
          'studios': res[0],
          'statuses': res[1],
          'types': res[2],
          'assignedTo': res[3],
          'productionCompanies': res[4],
          'unions': res[5],
          'signatories': res[6]
        };
      }
    );
  }

  // public resolve(route: ActivatedRouteSnapshot): any {
  //   const id = route.paramMap.get('projectId');
  //   const project = this.getProject(+id).map(projectData => projectData);
  //   const studios = this.getDropdownValue('USER_STUDIOS').map(studioData => studioData);
  //   const statuses = this.getDropdownValue('PROJECT_STATUS').map(statusData => statusData);
  //   const types = this.getDropdownValue('PROJECT_TYPE').map(typesData => typesData);
  //   const assignedToUsers = this.getAssignedToDropdownValue('assignedToUsers').map(usersData => usersData);
  //   const productionCompanies = this.getDropdownValue('PROD_COMPANY').map(companiesData => companiesData);
  //   const unions = this.getDropdownValue('UNION').map(unionData => unionData);
  //   const signatories = this.getSignatoryDropdownValue('lookup/signatories').map(signatoryData => signatoryData);

  //   return forkJoin([project, studios, statuses, types, assignedToUsers, productionCompanies, unions, signatories]).map(
  //     (res) => {
  //       console.log(res);
  //       res[0].studio = this.getDropdownSelection(res[1], res[0].studio, 'id');
  //       res[0].status = this.getDropdownSelection(res[2], res[0].status, 'id');
  //       res[0].type = this.getDropdownSelection(res[3], res[0].type, 'id');
  //       res[0].assignedTo = this.getDropdownSelection(res[4], res[0].assignedTo, 'userId');
  //       res[0].productionCompanies = this.getCastingCompanySet(res[0].productionCompanies, res[5], res[6], res[7]);
  //       return res[0];
  //     }
  //   );
  // }

  private getProject(id: number) {
    return this.createEditProjectService.getProject(id).map(
      (data) => {
        return {
          'creationDate': data.creationDate,
          'title': data.title,
          'akaNames': data.akaNames,
          'startDate': data.startDate,
          'wrapDate': data.wrapDate,
          'releaseDate': data.releaseDate,
          'assignedTo': data.assignToUserId,
          'productionCompanies': data.castingCompanySet,
          'studio': data.studio.id,
          'status': data.projectStatusId,
          'sapCode': data.sapCode,
          'type': data.projectTypeId,
          'sagProdId': data.sagProdId,
          'notes': data.projectNote
        };
      }
    );
  }

  private getDropdownValue(type: string) {
    const dropdown: DropdownModel = new DropdownModel('', '', '', '', []);
    return this.sharedService.getDropdown(type).map(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          dropdown.options.push({
            value: data[i].name,
            route: '',
            id: data[i].id
          });
        }
        return dropdown;
      }
    )
  }

  private getAssignedToDropdownValue(type: string) {
    const dropdown: DropdownModel = new DropdownModel('', '', '', '', []);
    return this.sharedService.getNonLookupDropdown(type).map(
      (data) => {
        let users = (<any>data)._embedded.users;
        for(let i = 0; i < Object.keys(users).length; i++) {
          dropdown.options.push({
            value: users[i].firstName + ' ' + users[i].lastName,
            route: '',
            userId: users[i].userId
          });
        }
        return dropdown;
      }
    )
  }

  private getSignatoryDropdownValue(type: string) {
    const dropdown: DropdownModel = new DropdownModel('', '', '', '', []);
    return this.sharedService.getNonLookupDropdown(type).map(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          dropdown.options.push({
            value: data[i].firstName + ' ' + data[i].lastName + (data[i].title !== null ? ', ' + data[i].title : ''),
            route: '',
            id: data[i].id
          });
        }
        return dropdown;
      }
    )
  }

  private getCastingCompanySet(data, productionCompanies, unions, signatories) {
    const castingCompanies = this.fb.array([]);
    data.forEach((item) => {
      castingCompanies.push(this.fb.group({
        'productionCompany': this.fb.control({ value: this.getDropdownSelection(productionCompanies, item.productionCompany.id, 'id'), disabled: true }),
        'union': this.fb.control({ value: this.getDropdownSelection(unions, item.union.id, 'id'), disabled: true }),
        'unionNotes': this.fb.control({ value: item.unionNotes, disabled: true }),
        'signatory': this.fb.control({ value: this.getDropdownSelection(signatories, item.signatoryUser.id, 'id'), disabled: true }),
        'primary': this.fb.control({ value: item.primaryInd, disabled: true })
      }));
    });
    return castingCompanies;
  }

  private getDropdownSelection(options, value, field) {
    let selection = value;
    if (options) {
      options.forEach((val) => {
        if (value === val[field]) {
          selection = val;
        }
      });
    }
    return selection;
  }

}
