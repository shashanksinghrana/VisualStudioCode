import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { map, take } from 'rxjs/operators';
import 'rxjs/add/operator/pairwise';
import { DealService } from '../http/deal/deal.service';
import { ProjectDetailService } from '../http/project-detail/project-detail.service';
import { DealModel } from '../../models/deal/deal.model';
import { LookupModel } from '../../models/shared/lookup.model';
import { performerNameFormatter } from '../../utils/formatter/performer-name.format';

@Injectable()
export class DealResolverService implements Resolve<DealModel> {

  constructor(private dealService: DealService, private projectDetailService: ProjectDetailService, private router: Router) { }

  public resolve(route: ActivatedRouteSnapshot): Observable<DealModel> | DealModel {
    const dealId = route.paramMap.get('dealId') ? route.paramMap.get('dealId') : 'new';
    const project = this.projectDetailService.project;
    /* if (project === undefined) {
      this.router.navigate(['/allProjects']);
      return;
    } */

    if (dealId !== 'new') {
      return this.dealService.getDeal(+dealId).pipe(
        take(1),
        map((deal: DealModel) => {
          if (deal) {
            deal.sagStatusLookup = deal.sagStatusLookup ? deal.sagStatusLookup : new LookupModel();
            deal.performerINineStatus = deal.performerINineStatus ? deal.performerINineStatus : new LookupModel();
            deal.performer.typeAheadDisplayName = performerNameFormatter(deal.performer.firstName, deal.performer.lastName);
            return deal;
          } else {
            return null;
          }
        })
      );
    } else {
      return new DealModel(
        new Date(),
        null,
        project,
        null,
        null,
        false,
        null,
        false,
        new LookupModel(),
        null,
        null,
        null,
        null,
        new LookupModel(),
        null,
        new LookupModel()
      );
    }

  }
}
