import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { ProjectDetailService } from '../http/project-detail/project-detail.service';
import { map, take } from 'rxjs/operators';
import { NoticesPaymentsModel } from '../../models/deal/notices-payments.model';
import { RepSetModel } from '../../models/deal/rep-set.model';
import { NoticesPaymentsService } from '../http/deal/notices-payments.service';
import { RepAddressModel } from '../../models/deal/rep-address.model';
import { DirectContactModel } from '../../models/deal/direct-contact.model';
import { RepContactModel } from '../../models/deal/rep-contact.model';

@Injectable()
export class NoticesPaymentsResolverService implements Resolve<NoticesPaymentsModel> {

  constructor(
    private noticesPaymentsService: NoticesPaymentsService,
    private projectDetailService: ProjectDetailService,
    private router: Router) { }

  public resolve(route: ActivatedRouteSnapshot): any {
    const dealId = route.parent.paramMap.get('dealId') ? route.parent.paramMap.get('dealId') : 'new';
    /* const project = this.projectDetailService.project;
    if (project === undefined) {
      this.router.navigate(['/allProjects']);
      return;
    } */

    if (dealId !== 'new') {
      return this.noticesPaymentsService.getNoticesPayments(+dealId).pipe(
        take(1),
        map((noticesPayments: NoticesPaymentsModel) => {
          if (noticesPayments) {
            noticesPayments.representators = noticesPayments.representators ? noticesPayments.representators : null;
            noticesPayments.directContact = noticesPayments.directContact ? noticesPayments.directContact : null;
            return noticesPayments;
          } else {
            return null;
          }
        })
      );
    } else {
      return new NoticesPaymentsModel(
        new RepSetModel(null, null, null, new RepAddressModel( null, null, null, null,  null, null, null, null,  null, null), new RepContactModel(null, null, null, false, null, null, null), false, false, false),
        new DirectContactModel(null, null, null, new RepAddressModel( null, null, null, null,  null, null, null, null,  null, null), new RepContactModel(null, null, null, false, null, null, null), false, false, false)
      );
    }
  }
}
