import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { PerqsService } from '../http/deal/perqs.service';
import { map, take } from 'rxjs/operators';
import { PerqsModel } from '../../models/deal/perqs.model';
import { perqs } from '../../models/deal/perqs-type-one.model';

@Injectable()
export class PerqsResolverService implements Resolve<PerqsModel> {

  constructor(
    private perqsService: PerqsService) { }

  public resolve(route: ActivatedRouteSnapshot): any {
    const dealId = route.parent.paramMap.get('dealId') ? route.parent.paramMap.get('dealId') : 'new';
    if (dealId !== 'new') {
      return this.perqsService.getPerqs(+dealId).pipe(
        take(1),
        map((perqModel: PerqsModel) => {
          if (perqModel) {
            perqModel.perqs = perqModel.perqs ? perqModel.perqs : new perqs( null, null, null);

            return perqModel;
          } else {
            return null;
          }
        })
      );
    } else {
      return new PerqsModel(
        new perqs( null, null, null)
      );
    }
  }
}
