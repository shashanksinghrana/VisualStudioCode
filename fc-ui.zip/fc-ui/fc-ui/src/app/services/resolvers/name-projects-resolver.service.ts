import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/pairwise';
import { DealService } from '../http/deal/deal.service';
import { ProjectDetailService } from '../http/project-detail/project-detail.service';
import { DealModel } from '../../models/deal/deal.model';
import { performerNameFormatter } from '../../utils/formatter/performer-name.format';
import { CommonModuleService } from '../http/deal/add-edit-performer/common-module.service';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Injectable()
export class NameProjectsResolverService implements Resolve<DealModel> {

  constructor(private dealService: DealService, private projectDetailService: ProjectDetailService, private router: Router,
    private talentService: CommonModuleService) { }

  public resolve(route: ActivatedRouteSnapshot): Observable<any> | any {
    const dealId = route.parent.paramMap.get('dealId') ? route.parent.paramMap.get('dealId') : 'new';
    const project = this.projectDetailService.project;
    /* if (project === undefined) {
      this.router.navigate(['/allProjects']);
      return;
    } */

    let dealResponse: any = new DealModel(new Date(), null, project, null, null, false, null, false,
      null, null, null, null, null, null, null, null);
    const serviceArr = [];
    const personMetadata = this.talentService.getMetaDataFields('TALENT_PERSON').map(data => data);
    serviceArr.push(personMetadata);
    if (dealId !== 'new') {
      dealResponse = this.dealService.getDeal(+dealId).map(data => data);
      serviceArr.push(dealResponse);
    }
    return forkJoin(serviceArr).map(
      (response) => {
        // If deal response then process otherwise return default one
        const serviceResponse = { dealData: null, personMetadata: null };
        if (response[1]) {
          const deal: any = response[1];
          deal.sagStatusLookup = deal.sagStatusLookup ? deal.sagStatusLookup : null;
          deal.performerINineStatus = deal.performerINineStatus ? deal.performerINineStatus : null;
          deal.performer.typeAheadDisplayName = performerNameFormatter(deal.performer.firstName, deal.performer.lastName);
          serviceResponse.dealData = deal;
        } else {
          serviceResponse.dealData = dealResponse;
        }
        if (!serviceResponse.dealData.project) {
          this.router.navigate(['/allProjects']);
          return;
        }
        serviceResponse.personMetadata = response[0];
        return serviceResponse;
      }
    );
  }

}
