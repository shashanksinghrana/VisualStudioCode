import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { SharedService } from '../http/shared/shared.service';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { UrlResolverService, DropdownTypeAheadModel} from 'c2c-common-lib';
import { HttpClient} from '@angular/common/http';
import { PowersearchService } from '../http/powersearch/powersearch.service';

/**
 * The PowersearchResolverService
 *
 * Service for handling (resolving) initial data loads for Powersearch.
 * Once data has finished loading - navigates to the Powersearch page.
 */
@Injectable()
export class PowersearchResolverService implements Resolve<any> {

  /**
   * Constructor for the PowersearchResolverService
   *
   * @param sharedService The Shared Service for common services.
   */
  constructor(private sharedService: SharedService, private powersearchService: PowersearchService, 
    private urlResolverService: UrlResolverService, private http: HttpClient) { }

  /**
   * Calls services necessary to load data and returns everything as one object.
   */
  public resolve(): Observable<any> | any {
    // TODO: Add rest of data for typeaheads, checklists, etc.
    const unions = this.getLookupValue('UNION').map(data => data);
    const billing = this.getLookupValue('BILLING').map(data => data);
    const reportFormData = this.getLookupValue('REPORT').map(data => data);
    const rangOptions = this.getDropdown('RANGE').map(options => options);
    const compensationOperandOptions = this.getDropdown('POWER_FEE_TYPE').map(options => options);
    const workOperandOptions = this.getDropdown('POWER_ACTIVITY').map(options => options);
    const textFields =  this.getLookupValue('TEXT_FIELD').map(fields => fields);
    const exportOptions = this.getLookupValue('EXPORT_TYPE').map(exportData => exportData);
    const previouslySavedSearchOptions = this.getPrevSavedSearchesForUser().map(prevSavedSearchData => prevSavedSearchData);
    const projectStatus = this.getLookupValue('PROJECT_STATUS').map(data => data);
    const signatories = this.getSignatoryDropdownValue('lookup/signatories').map(signatoryData => signatoryData);

    return forkJoin([unions, billing, reportFormData, rangOptions, compensationOperandOptions, workOperandOptions, textFields,
      exportOptions, previouslySavedSearchOptions, projectStatus,signatories]).map(
      (res) => {
        return {
          unions: res[0],
          billing: res[1],
          reportFormData: res[2],
          rangOptions: res[3],
          compensationOperandOptions: res[4],
          workOperandOptions: res[5],
          textFields: res[6],
          exportOptions: res[7],
          previouslySavedSearchOptions: res[8],
          projectStatus: res[9],
          signatories:res[10]
          
        };
      }
    );

  }

  /**
   * Calls the service to get a list of lookups.
   *
   * @param type The lookup type to get.
   */
  private getLookupValue(type: string) {
    return this.sharedService.getDropdown(type).map(
      (data) => {
        return data;
      }
    );
  }

  /**
   * Returns dropdown values.
   *
   * @param lookup The type of lookup value of the dropdown.
   */
  public getDropdown(lookup: string) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/lookup/type/') + lookup)
      .map(data => {
        return data;
      });
  }

    /**
   * Calls the service to get a list of Prev/Saved Searches.
   *
   */
  private getPrevSavedSearchesForUser() {
    return this.powersearchService.getPrevSavedSearchesForUser().map(
      (data) => {
        return data;
      }
    );
  }

  private getSignatoryDropdownValue(type: string) {
    const dropdown: DropdownTypeAheadModel = new DropdownTypeAheadModel('', '', '', '', []);
    return this.sharedService.getNonLookupDropdown(type).map(
      (data) => {
        for (let i = 0; i < Object.keys(data).length; i++) {
          dropdown.options.push({
            value: data[i].firstName + ' ' + data[i].lastName + (data[i].title !== null ? ', ' + data[i].title : ''),
            route: '',
            id: data[i].id
          });
        }
        return dropdown;
      }
    )
  }

  

}
