import { Injectable, EventEmitter } from '@angular/core';

/**
 * The DealEventService
 *
 * Service for handling all events within the Deal Wizard Flow.
 */
@Injectable()
export class DealEventService {
  private pageSaved: EventEmitter<any> = new EventEmitter<any>();

  /**
   * Constructor for the DealEventService
   */
  constructor() {}

  public pageSavedEvent(value: {type: string, pageTo?: string, dealId?: number, status?: string}): void {
    this.pageSaved.emit(value);
  }

  public getPageSavedEvent(): EventEmitter<any> {
    return this.pageSaved;
  }
}
