import { Injectable, EventEmitter } from '@angular/core';

/**
 * The BillingEventService
 *
 * Service for handling all events within Billing Grid Editing
 */
@Injectable()
export class BillingEventService {
  private billingSaved: EventEmitter<any> = new EventEmitter<any>();
  private billingCancelled: EventEmitter<any> = new EventEmitter<any>();

  /**
   * Constructor for the BillingEventService
   */
  constructor() {}

  public billingSavedEvent(value): void {
    this.billingSaved.emit(value);
  }

  public getBillingSavedEvent(): EventEmitter<any> {
    return this.billingSaved;
  }

  public billingCancelledEvent(value: {row: any, event: any}): void {
    this.billingCancelled.emit(value);
  }

  public getBillingCancelledEvent(): EventEmitter<any> {
    return this.billingCancelled;
  }
}
