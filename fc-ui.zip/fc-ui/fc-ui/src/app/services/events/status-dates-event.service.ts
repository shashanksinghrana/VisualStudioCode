import { Injectable, EventEmitter } from '@angular/core';

/**
 * The StatusDatesEventService
 *
 * Service for handling all events within Status Dates Grid Editing
 */
@Injectable()
export class StatusDatesEventService {
  private statusDatesSaved: EventEmitter<any> = new EventEmitter<any>();
  private statusDatesCancelled: EventEmitter<any> = new EventEmitter<any>();
  private statusDatesDeleted: EventEmitter<any> = new EventEmitter<any>();
  private _isAddOrEditRowInProgress = false;

  /**
   * Constructor for the StatusDatesEventService
   */
  constructor() {}

  public get isAddOrEditRowInProgress() {
    return this._isAddOrEditRowInProgress;
  }
  public set isAddOrEditRowInProgress(value) {
    this._isAddOrEditRowInProgress = value;
  }

  public statusDatesSavedEvent(value): void {
    this.statusDatesSaved.emit(value);
  }

  public getStatusDatesSavedEvent(): EventEmitter<any> {
    return this.statusDatesSaved;
  }

  public statusDatesCancelledEvent(value: {row: any, event: any}): void {
    this.statusDatesCancelled.emit(value);
  }

  public getStatusDatesCancelledEvent(): EventEmitter<any> {
    return this.statusDatesCancelled;
  }

  public statusDatesDeletedEvent(value: {row: any, event: any}): void {
    this.statusDatesDeleted.emit(value);
  }

  public getStatusDatesDeletedEvent(): EventEmitter<any> {
    return this.statusDatesDeleted;
  }
}
