import { Injectable, EventEmitter } from '@angular/core';

/**
 * The LocationEventService
 *
 * Service for handling all events within location Grid Editing
 */
@Injectable()
export class LocationEventService {

  private locationCancelled: EventEmitter<any> = new EventEmitter<any>();
  private locationSaved: EventEmitter<any> = new EventEmitter<any>();


  /**
   * Constructor for the LocationEventService
   */
  constructor() {}

  public getLocationCancelledEvent(): EventEmitter<any> {
    return this.locationCancelled;
  }

  public getLocationSavedEvent(): EventEmitter<any> {
    return this.locationSaved;
  }

  public locationCancelledEvent(value: {row: any, event: any}): void {
    this.locationCancelled.emit(value);
  }

  public locationSavedEvent(value): void {
    this.locationSaved.emit(value);
  }

}
