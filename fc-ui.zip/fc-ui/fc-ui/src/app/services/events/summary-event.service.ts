import { Injectable, EventEmitter } from '@angular/core';

/**
 * The Summary Service
 *
 * Service for handling all events within the Deal Wizard Flow.
 */
@Injectable()
export class SummaryEventService {
  private emiteClickEvent: EventEmitter<any> = new EventEmitter<any>();
  private noQuotekEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

  /**
   * Constructor for the SummaryEventService
   */
  constructor() {}

  public navigate(value: {pageTo?: string, dealID?: any}): void {
    this.emiteClickEvent.emit(value);
  }

  public getEvent(): EventEmitter<any> {
    return this.emiteClickEvent;
  }

  public sendNoQuoteDealVal(noQuoteVal? : boolean){
      this.noQuotekEvent.emit(noQuoteVal);
  }

  public getNoQuoteDeal(): EventEmitter<boolean> {
      return this.noQuotekEvent;
  }
}