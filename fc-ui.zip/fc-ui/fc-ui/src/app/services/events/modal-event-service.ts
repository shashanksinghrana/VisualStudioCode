import { Injectable, EventEmitter } from '@angular/core';


@Injectable()
export class ModalService {

    private closeModalEvent = new EventEmitter<any>();
    private openModalEvent = new EventEmitter<any>();

    constructor() { }

    public closeModal(value): void {
        this.closeModalEvent.emit(value);
    }

    public onCloseModal(): EventEmitter<any> {
        return this.closeModalEvent;
    }

    public onOpenModal(): EventEmitter<any> {
        return this.openModalEvent;
    }

    public openModal(): void {
        this.openModalEvent.emit('open');
    }

}
