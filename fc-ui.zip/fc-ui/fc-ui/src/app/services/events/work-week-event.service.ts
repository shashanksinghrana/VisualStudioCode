import { Injectable, EventEmitter } from '@angular/core';

/**
 * The StatusDatesEventService
 *
 * Service for handling all events within Status Dates Grid Editing
 */
@Injectable()
export class WorkWeekEventService {
  private addOrEditRowInProgress: boolean = false;
  private statusDatesCancelled: EventEmitter<any> = new EventEmitter<any>();
  private statusDatesDeleted: EventEmitter<any> = new EventEmitter<any>();
  private statusDatesSaved: EventEmitter<any> = new EventEmitter<any>();

  /**
   * Constructor for the StatusDatesEventService
   */
  constructor() {}

  public get isAddOrEditRowInProgress() {
    return this.addOrEditRowInProgress;
  }
  public set isAddOrEditRowInProgress(value) {
    this.addOrEditRowInProgress = value;
  }

  public getWorkWeekCancelledEvent(): EventEmitter<any> {
    return this.statusDatesCancelled;
  }

  public getWorkWeekDeletedEvent(): EventEmitter<any> {
    return this.statusDatesDeleted;
  }

  public getWorkWeekSavedEvent(): EventEmitter<any> {
    return this.statusDatesSaved;
  }

  public workWeekCancelledEvent(value: {event: any, row: any}): void {
    this.statusDatesCancelled.emit(value);
  }

  public workWeekDeletedEvent(value: {event: any, row: any}): void {
    this.statusDatesDeleted.emit(value);
  }

  public workWeekSavedEvent(value): void {
    this.statusDatesSaved.emit(value);
  }
}
