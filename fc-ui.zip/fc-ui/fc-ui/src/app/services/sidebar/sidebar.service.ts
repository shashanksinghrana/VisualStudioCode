import { CurrentUser } from './../../models/users/current-user.model';
import { CurrentUserService } from './../http/users/current-user.service';
import { Injectable } from '@angular/core';
import { SidebarModel } from 'c2c-common-lib';

@Injectable()
export class SidebarService {
  public navItems: Array<SidebarModel> = [];
  constructor() {
    
  }
  public setNavItems(): void {
    this.navItems.push(new SidebarModel('HOME', 1.0, 'home', false)); 
    this.navItems.push(new SidebarModel('PROJECTS', 2.0, 'allProjects', false));  
    this.navItems.push(new SidebarModel('POWER SEARCH/REPORTS', 3.0, 'powersearch', false));  
  }  

  public getNavItems(): Array<SidebarModel> {
    return this.navItems;
  }    
}
