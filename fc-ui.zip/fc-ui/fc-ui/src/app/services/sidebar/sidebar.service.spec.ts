import { TestBed, inject } from '@angular/core/testing';
import { SidebarModel } from 'c2c-common-lib';

import { SidebarService } from './sidebar.service';

describe('SidebarService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SidebarService]
    });
  });

  it('should be created', inject([SidebarService], (service: SidebarService) => {
    expect(service).toBeTruthy();
  }));

  it('should have an array that contains 5 sidebar models', inject([SidebarService], (service: SidebarService) => {
    const navItem: SidebarModel = new SidebarModel('HOME', 1.0, 'home', false, undefined);
    expect(service.navItems).toBeTruthy();
    expect(service.navItems).not.toBeNull();
    expect(typeof(service.navItems[0])).toEqual(typeof(navItem)); // make sure objects are of type SidebarModel
    expect(service.navItems.length).toEqual(5); // make sure there are 5 navigation items
  }));

  it('should return the navigation items when called', inject([SidebarService], (service: SidebarService) => {
    const navItems = service.getNavItems();
    expect(service.getNavItems().length).toEqual(5); // make sure it returns 5 items
  }));
});
