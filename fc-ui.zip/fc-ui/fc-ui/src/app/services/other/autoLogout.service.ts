import { Injectable } from "@angular/core";
import { Router } from '@angular/router'
import { SessionService } from "./session.service";
// import {} from ''
// const store = require('store');

// const MINUTES_UNITL_AUTO_LOGOUT = 60 // in mins
// const CHECK_INTERVAL = 15000 // in ms
// const STORE_KEY =  'lastAction';
@Injectable()
export class AutoLogoutService {
  public sessionExpiredMessageShown = false;
  

  checkTimeStamp = () => {
  const FINAL_REQUEST_SENT_TIMESTAMP = parseInt(localStorage.getItem("LAST_REQUEST_SENT_TIMESTAMP"));

  let LAST_REQUEST_SENT_TIMESTAMP = parseInt(localStorage.getItem("LAST_REQUEST_SENT_TIMESTAMP"));
    if (LAST_REQUEST_SENT_TIMESTAMP) {
      let currentTimeStamp: any = new Date().getTime();
      let lastReqTimeStamp: any = new Date(LAST_REQUEST_SENT_TIMESTAMP).getTime();

      let diff: number = lastReqTimeStamp - currentTimeStamp;
      diff = Math.abs(diff / 1000);
     if (diff > this.sessionService.sessionTimeoutSeconds && !this.sessionExpiredMessageShown) {
        console.error('Session has expired');
        this.sessionExpiredMessageShown = true;
        this.sessionService.logOutEvent();
        return null;
      }
     
    }
  }



  constructor(private router: Router, private sessionService: SessionService) {

 }
}