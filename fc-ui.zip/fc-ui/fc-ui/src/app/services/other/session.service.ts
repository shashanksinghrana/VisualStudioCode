import { Injectable, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class SessionService {
  private data: any = "shared Data";
  public logoutClicked = false;
  public sessionTimeoutSeconds = 3600;

  public isModalOpen: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  public getLogoutClicked = () => {
    return this.logoutClicked;
  }

  public setLogoutClicked = (logoutClickedParam) => {
    this.logoutClicked = logoutClickedParam

  }

  public getSessionTimeoutSeconds = () => {
    return this.sessionTimeoutSeconds;
  }


  public setSessionTimeoutSeconds = (sessionTimeoutSecondsParam) => {
    if (sessionTimeoutSecondsParam) {
      this.sessionTimeoutSeconds = parseInt(sessionTimeoutSecondsParam);
    }
  }
 public logOutEvent = () => {
    this.isModalOpen.next(true);
    localStorage.clear();

  }
 constructor(private router: Router) { }

}
