import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoadingIndicatorService } from './loading-indicator.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/finally';
import { AutoLogoutService } from './autoLogout.service';


/**
 * The LoadingIndicatorInterceptorService
 *
 * For every incoming HTTP request, this will intercept it and call the {@link LoadingIndicatorService} to start the loading spinner.
 */
@Injectable()
export class LoadingIndicatorInterceptorService implements HttpInterceptor {

  /** Add any service urls here if you want to don't want the loading spinner triggered */
  private readonly ignoreRequests: Array<string> = [
    'api/allProjects',
    'api/myProjects',
    'api/performerDeals',
    'api/companies',
    'api/typeAhead/performers',
    'accents/chars',
    'api/typeAhead/productionCompanies',
    'api/typeAhead/projectTitles',
    'api/contacts',
    'typeAheadNames',
    'api/projects'
  ];

  /**
   * Constructor for the LoadingIndicatorInterceptorService
   *
   * @param loadingService The LoadingIndicatorService that triggers the loading spinner.
   */
  constructor(private loadingService: LoadingIndicatorService) { }

  /**
   * Implementation of the HttpInterceptor 'intercept' function that will get all incoming HTTP requests.
   *
   * @param req The HttpRequest to be intercepted.
   * @param next The HttpHandler that will handle each request.
   */
  public intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let ignore: boolean = false;
    this.ignoreRequests.forEach((ir) => {
      if (req.url.indexOf(ir) >= 0) {
        ignore = true;
      }
    });
    // Check if skipLoading true in specific conditions
    const skipLoading = req.headers.get('skipLoading');
    if (skipLoading) {
      if (skipLoading === 'true') {
        ignore = true;
      } else {
        ignore = false;
      }
    }

    if (!ignore) {
      this.loadingService.onStarted(req);
    }

    return next.handle(req)
      .finally(() => this.loadingService.onFinished(req));
  }
}
