import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {UrlResolverService} from 'c2c-common-lib';
import 'rxjs/add/operator/catch';

@Injectable()
export class NavigationItemsService {

  constructor(private httpClient: HttpClient, private urlResolverService: UrlResolverService) { }


  /** Method to define navigation items */
  public getNavigationItem<T>(moduleName: any): Observable<T> {
    const url = this.urlResolverService.getServiceEndpointUrl('/api/module-access?moduleName=' + moduleName);
    return this.httpClient.get<T>(url).map((res) => {
      return res as T;
    });
  }

}
