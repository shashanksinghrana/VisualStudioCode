import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import {
  UrlResolverService,
  ColumnDefModel,
  GridIconParamsModel,
  GridLinkParamsModel,
  GridListParamsModel,
  GridListDefModel,
  GridPageOptionsModel,
  GridIconDefModel,
  GridLinkDefModel,
  GridCheckBoxDefModel,
  GridCheckBoxParamsModel,
  GridTitlesDefModel,
  GridTitlesParamsModel,
  GridDropdownEditDefModel,
  GridCarouselDefModel,
  GridCarouselParamsModel,
  GridDatePickerDefModel
} from 'c2c-common-lib';
import { performerNameFormatter } from '../../../utils/formatter/performer-name.format';
import { BillingEventService } from '../../events/billing-event.service';
import { StatusDatesEventService } from '../../events/status-dates-event.service';
import { LocationEventService } from '../../events/location-event.service';
import { WorkWeekEventService } from '../../events/work-week-event.service';


/**
 * The ProjectDetailService
 *
 * Gets all of the data related to Project Details, and handles logic as needed.
 */
@Injectable()
export class ProjectDetailService {
  private billingDetails: any;
  private confirmedByOptionsData: any;
  private crewOptionsData: any;
  private editedRowIndexData: any;
  private locationGridRowIndexData: any;
  private projectData: any;
  private statusOptionsData: any;

  public get project() {
    return this.projectData;
  }
  public set project(value) {
    this.projectData = value;
  }

  public get editedRowIndex() {
    return this.editedRowIndexData;
  }
  public set editedRowIndex(value) {
    this.editedRowIndexData = value;
  }

  public get locationGridRowIndex() {
    return this.locationGridRowIndexData;
  }
  public set locationGridRowIndex(value) {
    this.locationGridRowIndexData = value;
  }

  public get billingData() {
    return this.billingDetails;
  }
  public set billingData(value) {
    this.billingDetails = value;
  }

  public get confirmedByOptions() {
    return this.confirmedByOptionsData;
  }
  public set confirmedByOptions(value) {
    this.confirmedByOptionsData = value;
  }

  public get statusOptions() {
    return this.statusOptionsData;
  }
  public set statusOptions(value) {
    this.statusOptionsData = value;
  }

  public get crewOptions() {
    return this.crewOptionsData;
  }

  public set crewOptions(value) {
    this.crewOptionsData = value;
  }

  public DEFAULT_CONFIRMED_BY_OPTIONS: any[] = [
    { value: '', route: '', id: '', type: 'CONFIRMED_BY' },
    { value: 'Email', id: 681, route: '', type: 'CONFIRMED_BY' },
    { value: 'Phone', id: 682, route: '', type: 'CONFIRMED_BY' }
  ];

  /**
   * Constructor for the ProjectDetailService
   *
   * @param http The HttpClient service.
   */
  constructor(
    private http: HttpClient,
    private urlResolverService: UrlResolverService,
    private billingEventService: BillingEventService,
    private statusDatesEventService: StatusDatesEventService,
    private locationEventService: LocationEventService,
    private workWeekEventService: WorkWeekEventService) { }

  /**
   * Defines all of Column Definitions used in the performers Grid.
   */
  public createPerformersColDefs(): ColumnDefModel[] {
    return [
      new GridLinkDefModel('Performer', 'performerName',
        new GridLinkParamsModel('/createDeal', 'id', 'summary'), {
          comparator: { name: 'propertyValueComparator', key: 'performer.lastName' }
        }
      ),
      new ColumnDefModel('#', 'roleNumber', null, {
        comparator: { name: 'numberComparator' },
        config: { width: 70 }
      }, 'performerRoleNumber'
      ),
      new ColumnDefModel('Role', 'role', null, {
        config: { width: 80 }
      }, 'performerRole'),
      new ColumnDefModel('Union', 'unionName', null, {
        config: { width: 80 }
      }, 'unionLookup.name'
      ),
      new ColumnDefModel('Deal Date', 'dealDate', null, {
        comparator: { name: 'dateComparator' },
        formatter: 'dateFormatter',
        valGetter: 'dateGetter',
        config: { width: 100 }
      }
      ),
      new GridListDefModel('Contract', 'contract',
        new GridListParamsModel({
          iterable: 'contracts',
          keys: ['contractName']
        }, true, null, null, null, null, null, true)
      ),
      new ColumnDefModel('Performer Notes', 'performerNote', null, {
        config: { width: 180 }
      }
      )
    ];
  }

  /**
* Gets location data .
*
* @param id The id of the project to get location data.
*/
  public getLocationData(id: number) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/projects/' + id + '/locations'))
      .map((res: any) => {
        if (res !== null) {
          res.forEach(element => {
            // format phone data
            if (element.phone !== null) {
              element.phone.forEach(phone => {
                const phoneValueFormat = phone.displayValue;
                phone.displayValue = phoneValueFormat.split('|').join('-');
              });
            }
          });
        }
        return res;
      });
  }

  /**
   * Gets/defines all the page options for customizing the performers Grid.
   */
  public getPageOptions(viewAddButton?: boolean) {
    return new GridPageOptionsModel(false, null, true, false, false, false, viewAddButton, false);
  }

  /**
   * Gets all of the performer data related to a particular project.
   *
   * @param id The id of the project to get performer deals from.
   */
  public getPerformers(id: number, params?: HttpParams) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/performerDeals/') + id, { params: params })
      .map((res: any) => {
        const pagination = res.page;
        let performerDeals = [];

        if (res._embedded) {
          performerDeals = res._embedded.performerDeals;

          performerDeals.forEach((deal) => {
            deal.performerName = performerNameFormatter(deal.performer.firstName, deal.performer.lastName);
          });
        }
        return { pagination, performerDeals };
      });
  }

  /**
   * Gets the project details data which includes title/card information and slider data.
   *
   * @param id The id of the project to get details on.
   */
  public getProjectDetails(id: number) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/projectDetails/') + id)
      .map(
        (res: any) => {
          this.project = Object.assign({}, res);
          res.akaNames = res.akaNames.map((aka) => aka.title).join('; ');
          res.castingCompanySet = res.castingCompanySet.map((comp) => {
            return [comp.productionCompanyName, comp.unionLookupName,
            [comp.signatoryUserFirstName, comp.signatoryUserLastName].filter(Boolean).join(' '),
            comp.signatoryUserTitle].filter(Boolean).join(' | ');
          });
          return res;
        }
      );
  }

  /**
   * Gets each tab item and route to use for tabular navigation.
   */
  public getTabItems(): Array<Object> {
    return [
      { label: 'Performers', route: 'performers' },
      { label: 'Billing', route: 'billing' },
      { label: 'Locations', route: 'locations' },
      { label: 'Work Week', route: 'workWeek' },
      { label: 'Crew', route: 'crew' },
      { label: 'Status Dates', route: 'statusDates' }
    ];
  }

  /**
   * Defines all of Column Definitions used in the billing Grid.
   */
  public createBillingColDefs(editPermission?: boolean): ColumnDefModel[] {
    return [
      new GridTitlesDefModel('Performer', 'firstName',
        new GridTitlesParamsModel({ keys: ['firstName', 'lastName'], routing: new GridLinkParamsModel('', '') },
          'subTitles', true, true, editPermission),
        {
          comparator: { name: 'propertyValueComparator', key: 'lastName' },
          config: { editable: true }
        }
      ),
      new ColumnDefModel('#', 'roleNo', null, {
        comparator: { name: 'numberComparator' },
        config: { width: 50 }
      }, 'roleNo'
      ),
      new ColumnDefModel('Role', 'role', null, {
        comparator: { name: 'stringComparator' },
        config: { width: 90 }
      }, 'role'),
      new ColumnDefModel('Union', 'union', null, {
        comparator: { name: 'stringComparator' },
        config: { width: 80 }
      }, 'union'
      ),
      new ColumnDefModel('Deal Date', 'dealDate', null, {
        comparator: { name: 'dateComparator' },
        formatter: 'dateFormatter',
        valGetter: 'dateGetter',
        config: { width: 100 }
      }
      ),
      new GridCheckBoxDefModel('MT', 'mainTitle',
        new GridCheckBoxParamsModel(
          { titleKey: 'creditBillingText', showLabel: false, toggleEditMode: false }
        ),
        { comparator: { name: 'booleanComparator' }, config: { width: 60, editable: true } },
        {
          filter: 'columnFilter', filterParams: {
            textFilter: false,
            columnKey: 'mainTitle',
            options: [
              { text: 'Checked', value: true, checked: true },
              { text: 'Unchecked', value: false, checked: true }
            ]
          }
        }
      ),
      new GridCheckBoxDefModel('ET', 'endTitle',
        new GridCheckBoxParamsModel(
          { titleKey: 'creditBillingText', showLabel: false, toggleEditMode: false }
        ),
        { comparator: { name: 'booleanComparator' }, config: { width: 60, editable: true } },
        {
          filter: 'columnFilter', filterParams: {
            textFilter: false,
            columnKey: 'endTitle',
            options: [
              { text: 'Checked', value: true, checked: true },
              { text: 'Unchecked', value: false, checked: true }
            ]
          }
        }
      ),
      new GridCheckBoxDefModel('PA', 'paidAd',
        new GridCheckBoxParamsModel(
          { showLabel: false, toggleEditMode: false }
        ),
        { comparator: { name: 'booleanComparator' }, config: { width: 60 } },
        {
          filter: 'columnFilter', filterParams: {
            textFilter: false,
            columnKey: 'paidAd',
            options: [
              { text: 'Checked', value: true, checked: true },
              { text: 'Unchecked', value: false, checked: true }
            ]
          }
        }
      ),
      new GridCheckBoxDefModel('Cut', 'cutFlag',
        new GridCheckBoxParamsModel(
          { showLabel: false, toggleEditMode: false }
        ),
        { comparator: { name: 'booleanComparator' }, config: { width: 65, editable: true } },
        {
          filter: 'columnFilter', filterParams: {
            textFilter: false,
            columnKey: 'cutFlag',
            options: [
              { text: 'Checked', value: true, checked: true },
              { text: 'Unchecked', value: false, checked: true }
            ]
          }
        }
      ),
      new GridCheckBoxDefModel('NC', 'notCredited',
        new GridCheckBoxParamsModel(
          { showLabel: false, toggleEditMode: false }
        ),
        { comparator: { name: 'booleanComparator' }, config: { width: 60, editable: true } },
        {
          filter: 'columnFilter', filterParams: {
            textFilter: false,
            columnKey: 'notCredited',
            options: [
              { text: 'Checked', value: true, checked: true },
              { text: 'Unchecked', value: false, checked: true }
            ]
          }
        }
      ),
      new GridDropdownEditDefModel('Confirm', 'confirmedBy', null, this.confirmedByOptions, false, 90, true
      ),
      new GridLinkDefModel('Attach', 'attachment',
        new GridLinkParamsModel('fileDownload', '', '', '', false, true, false, false, false, editPermission),
        { comparator: { name: 'booleanComparator' }, config: { width: 70, editable: true } },
        {
          filter: 'columnFilter', filterParams: {
            textFilter: false,
            columnKey: 'attachment',
            options: [
              { text: 'Attachment', value: true, checked: true },
              { text: 'No Attachment', value: false, checked: true }
            ]
          }
        }

      ),
      new GridIconDefModel('Billing Status Notes', 'billingStatusNote',
        new GridIconParamsModel(null, null, null, {
          visible: true, action: (row) => {
            this.billingEventService.billingSavedEvent(row);
          }, showIconsOnNextLine: true
        }, {
            visible: true, action: (row) => {
              this.billingEventService.billingCancelledEvent(row);
            }, showIconsOnNextLine: true
          }, 'Enter Billing Notes', true
        ),
        { config: { width: 210, editable: true } }
      )
    ];
  }

  /**
   * Gets/defines all the page options for customizing the billing Grid.
   */
  public getBillingPageOptions() {
    return new GridPageOptionsModel(false, null, true, false, false, false, false, false);
  }

  /**
  * Gets all of the billing data related to a particular project.
  *
  * @param id The id of the project to get billing data from.
  */
  public getBilling(id: number, params?: HttpParams) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/projects/' + id + '/billings'), { params: params })
      .map((res: any) => {
        return res;
      });
  }


  /**
 * Defines all of Column Definitions used in the location Grid.
 */
  public locationColDefs(isDisabled?: boolean): ColumnDefModel[] {
    return [
      new GridLinkDefModel('From', 'startDate',
        new GridLinkParamsModel('', '', '', '', false, false, true, true, false, isDisabled), {
          comparator: { name: 'dateComparator' },
          config: { width: 100, editable: true }
        }
      ),
      new GridDatePickerDefModel('To', 'toDate', { useDatePickerEditor: true }, {
        comparator: { name: 'dateComparator' },
        formatter: 'dateFormatter',
        valGetter: 'dateGetter'
      }, 100, true),
      new GridTitlesDefModel('Location', 'name',
        new GridTitlesParamsModel({
          keys: ['name'],
          routing: new GridLinkParamsModel('', '', '', '', false, false, false)
        }, '', true, false, isDisabled),
        {
          comparator: { name: 'propertyValueComparator', key: 'name' },
          config: { width: 100 }
        }
      ),
      new GridListDefModel('Contact Information', 'addressLine',
        new GridListParamsModel({
          iterable: 'addressLine',
          keys: ['line']
        }, true, null, null, null),
        {
          config: { width: 120, suppressFilter: true, suppressSorting: true }
        }
      ),
      new GridListDefModel('', 'phone',
        new GridListParamsModel({
          iterable: 'phone',
          keys: ['displayValue']
        }, true, null, null, null),
        {
          config: { width: 120, suppressFilter: true, suppressSorting: true }
        }
      ),
      new GridIconDefModel('', 'saveCancel',
        new GridIconParamsModel(null, null, null, {
          visible: true, action: (row) => {
            this.locationEventService.locationSavedEvent(row);
          }, showIconsOnNextLine: false
        }, {
            visible: true, action: (row) => {
              this.locationEventService.locationCancelledEvent(row);
            }, showIconsOnNextLine: false
          }, ' '
        ),
        { config: { width: 30, suppressFilter: true, suppressSorting: true, editable: true } }
      )
    ];
  }

  /** Method to create Location grid Data for save call
   * @param rowData
   */
  public createLocationGridData(rowData): any {
    // rowData.location.locationAddress.addressId,
    let startDate, endDate, requestObj;
    if (rowData.startDate === 'Select' && (rowData.toDate === '' || rowData.toDate === null)) {
      startDate = '';
      endDate = '';
    } else {
      startDate = rowData.startDate;
      endDate = rowData.toDate;
    }
    return requestObj = {
      'addressId': rowData.addressId,
      'companyId': rowData.companyId,
      'startDate': startDate,
      'toDate': endDate
    };
  }

  /** Method to save Location grid data
   * @param locationData the Location grid form data
  */
  public saveLocationGridData(rowData: any, projectId: any): any {
    const requestObj = this.createLocationGridData(rowData);
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('/api/projects/' + projectId + '/locations'), requestObj)
      .map((res: any) => res);
  }
  /**
 * THis method will save any changes.
 * @param billingData the billingData form data.
 */
  public saveBilling(billingData: any, dealId, projectId) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/projects/' + projectId + '/deals/' +
      dealId + '/billings'), billingData)
      .map((res: any) => res);
  }

  /**
* Save all of the crew data related to a particular project.
*
* @param ProjectId The id of the project to get crew data from.
*/
  public saveCrewData(id: number, data?: any): Observable<any> {
    const crewData = { 'partyId': data.partyId };
    const url = this.urlResolverService.getServiceEndpointUrl('api/projects/' + id + '/crews');
    return this.http.post('api/projects/' + id + '/crews', crewData)
      .map((res) => {
        return res;
      });
  }

  /**
* Save all of the location data related to a particular project.
*
* @param ProjectId The id of the project
*/
  public saveLocationData(id: number, data?: any): Observable<any> {
    const locationData = { 'companyId': data.partyId };
    return this.http.post('api/projects/' + id + '/locations', locationData)
      .map((res) => {
        return res;
      });
  }

  /**
   * Gets the billing attachment related to a particular deal.
   *
   * @param id The id of the deal to get billing attachment from.
   */
  public getBillingAttachment(dealId: number, projectId) {
    return this.http.post('api/projects/' + projectId + '/deals/' + dealId + '/attachments', null, { responseType: 'arraybuffer' });
  }


  /**
  * Defines all of Column Definitions used in the status dates Grid.
  */
  public createStatusDatesColDefs(disableLink?: boolean): ColumnDefModel[] {
    return [
      new GridLinkDefModel('Start', 'startDate',
        new GridLinkParamsModel('enableEditing', '', '', '', false, false, true, true, false, disableLink), {
          comparator: { name: 'dateComparator' },
          formatter: 'dateFormatter',
          valGetter: 'dateGetter',
          config: { width: 100, editable: true }
        }
      ),
      new GridDatePickerDefModel('Finish', 'finishDate', { useDatePickerEditor: true }, {
        comparator: { name: 'dateComparator' },
        formatter: 'dateFormatter',
        valGetter: 'dateGetter'
      }, 100, true),
      new GridDropdownEditDefModel('Status', 'status', null, this.statusOptions, false, 90, true),
      new GridIconDefModel('Description', 'desc',
        new GridIconParamsModel({
          visible: true, action: (row) => {
            this.statusDatesEventService.statusDatesDeletedEvent(row);
          }, showIconsOnNextLine: false
        }, null, null, {
            visible: true, action: (row) => {
              this.statusDatesEventService.statusDatesSavedEvent(row);
            }, showIconsOnNextLine: false
          }, {
            visible: true, action: (row) => {
              this.statusDatesEventService.statusDatesCancelledEvent(row);
            }, showIconsOnNextLine: false
          }, 'Enter Description', null, false
        ),
        { config: { width: 300, editable: true } }
      )
    ];
  }


  /**
  * Defines all of Column Definitions used in the Crew Grid.
  */
  public crewDataColDefs(editPermission?: boolean): ColumnDefModel[] {
    return [
      new GridTitlesDefModel('Name', 'lastName',
        new GridTitlesParamsModel({ keys: ['firstName', 'lastName'], routing: new GridLinkParamsModel('', '') }, '',
          true, true, editPermission),
        {
          comparator: { name: 'propertyValueComparator', key: 'lastName' },
          config: { width: 100 }
        }
      ),
      new ColumnDefModel('Title', 'occupation', null,
        { config: { width: 100 } }
      ),
      new GridListDefModel('Phone#', 'contact',
        new GridListParamsModel({
          iterable: 'contactDetails',
          keys: ['value']
        }, true, null, null, 'value'),
        {
          config: { width: 150 }
        }
      ),
      new ColumnDefModel('Email', 'email', null,
        { config: { width: 100 } }
      )
    ];
  }

  /**
 * Gets all of the crew data related to a particular project.
 *
 * @param id The id of the project to get crew data from.
 */
  public getCrewData(id: number) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/projects/' + id + '/crews'))
      .map((res: any) => {
        return res;
      });
  }

  /**
   * Gets/defines all the page options for customizing the status dates Grid.
   */
  public getStatusDatesPageOptions(addButton?: boolean) {

    return new GridPageOptionsModel(false, null, true, false, false, false, addButton, false);

  }

  /**
* Gets all of the status dates data related to a particular project.
*
* @param id The id of the project to get status dates data from.
*/
  public getStatusDates(id: number, params?: HttpParams) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/projects/' + id + '/statusDates'), { params: params })
      .map((res: any) => {
        return res;
      });
  }

  /**
  * THis method will save any changes.
  * @param statusDatesData the status dates form data.
  */
  public saveStatusDates(statusDatesData: any, dealId, projectId) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/projects/' + projectId + '/statusDates'), statusDatesData)
      .map((res: any) => res);
  }

  /**
* THis method will delete status dates row
*/
  public deleteStatusDatesRecord(id, projectId) {
    return this.http.delete(this.urlResolverService.getServiceEndpointUrl('api/projects/' + projectId + '/statusDates/' + id))
      .map((res: any) => res);
  }

  public createWorkWeekColDefs(disableLink?: boolean): ColumnDefModel[] {
    return [
      new GridLinkDefModel('Start', 'startDate',
        new GridLinkParamsModel('enableEditing', '', '', '', false, false, true, true, true, disableLink), {
          comparator: { name: 'dateComparator' },
          formatter: 'dateFormatter',
          valGetter: 'dateGetter',
          config: { width: 70, editable: true }
        }
      ),
      new GridDatePickerDefModel('Finish', 'finishDate', { useDatePickerEditor: true, showCarousel: true }, {
        comparator: { name: 'dateComparator' },
        formatter: 'dateFormatter',
        valGetter: 'dateGetter'
      }, 70, true),
      new ColumnDefModel('#Days', 'days', null, {
        comparator: { name: 'numberComparator' },
        config: { width: 50 }
      }, '', false),
      new GridCarouselDefModel('', 'workWeekDays',
        new GridCarouselParamsModel({
          visible: true, action: (row) => {
            this.workWeekEventService.workWeekDeletedEvent(row);
          }, showIconsOnNextLine: false
        }, null, null, {
            visible: true, action: (row) => {
              this.workWeekEventService.workWeekSavedEvent(row);
            }, showIconsOnNextLine: false
          }, {
            visible: true, action: (row) => {
              this.workWeekEventService.workWeekCancelledEvent(row);
            }, showIconsOnNextLine: false
          }, '', null, true
        ),
        { config: { suppressFilter: true, suppressSorting: true, width: 200, editable: true } }
      )
    ];
  }

  /**
   * Gets/defines all the page options for customizing the work week Grid.
   */
  public getWorkWeekPageOptions(addButton?: boolean) {
    return new GridPageOptionsModel(false, null, true, false, false, false, addButton, false);
  }

  /**
  * Gets all of the work week data related to a particular project.
  *
  * @param id The id of the project to get status dates data from.
  */
  public getWorkWeek(id: number, params?: HttpParams) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/projects/' + id + '/workweeks'), { params: params })
      .map((res: any) => {
        return res;
      });
  }

  /**
  * THis method will save any changes.
  * @param workWeekData the work week form data.
  */
  public saveWorkWeek(workWeekData: any, dealId, projectId) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/projects/' + projectId + '/workweeks'), workWeekData)
      .map((res: any) => res);
  }

  /**
  * THis method will delete work week row
  */
  public deleteWorkWeekRecord(id, projectId) {
    return this.http.delete(this.urlResolverService.getServiceEndpointUrl('api/projects/' + projectId + '/workweeks/' + id))
      .map((res: any) => res);
  }

}
