import { TestBed, inject, async } from '@angular/core/testing';

import { ProjectDetailService } from './project-detail.service';
import { HttpClientModule, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SharedService } from '../shared/shared.service';
import { UrlResolverService } from 'c2c-common-lib';
import { BillingEventService } from '../../events/billing-event.service';
import { StatusDatesEventService } from '../../events/status-dates-event.service';

describe('ProjectDetailService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule, HttpClientTestingModule ],
      providers: [SharedService, ProjectDetailService, UrlResolverService, BillingEventService, StatusDatesEventService]
    });
  });

  it('should be created', inject([ProjectDetailService], (service: ProjectDetailService) => {
    expect(service).toBeTruthy();
  }));

  it(`should issue a get billing data request`,
  inject([HttpTestingController, ProjectDetailService, UrlResolverService], 
    (httpMock: HttpTestingController, service: ProjectDetailService, urlService: UrlResolverService) => {
     const id = 1;
     const mockResponse = [{"dealId":167,"billingId":26,"firstName":"Chris","lastName":"Cain","pka":null,"roleNo":"35","role":"Lead Cowgirl","mainTitle":false,"endTitle":false,"paidAd":null,"cutFlag":false,"notCredited":false,"confirmedBy":{"name":"Phone","type":"CONFIRMED_BY","displayLabel":"Phone","displayOrder":2,"id":682},"attachment":{"name":"RE Name Confirmation - Superintelligence - Melissa McCarthy.msg","data":null},"attachmentType":null,"billingStatusNote":null,"creditBillingText":[],"creditAs":"Blah blah test","dealDate":"2018-07-25","union":"NON-UNION"}];

     service.getBilling(id).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const req = httpMock.expectOne(urlService.getServiceEndpointUrl('api/projects/' + id +'/billings'));
    expect(req.request.method).toEqual('GET');

    req.flush(mockResponse);
  })
  );

  afterEach(inject([HttpTestingController], (httpMock: HttpTestingController) => {
    httpMock.verify();
  }));

  it(`should issue save billing row request`,
  inject([HttpTestingController, ProjectDetailService, UrlResolverService], 
    (httpMock: HttpTestingController, service: ProjectDetailService, urlService: UrlResolverService) => {
     const id = 1;
     const projectId = 0;
     const billingData = {"dealId":167,"billingId":26,"firstName":"Chris","lastName":"Cain","pka":null,"roleNo":"35","role":"Lead Cowgirl","mainTitle":false,"endTitle":false,"paidAd":null,"cutFlag":false,"notCredited":false,"confirmedBy":{"value":"Email","route":"","id":681},"attachment":{"name":"RE Name Confirmation - Superintelligence - Melissa McCarthy.msg","data":null},"attachmentType":null,"billingStatusNote":"testing","creditBillingText":[],"creditAs":"Blah blah test","dealDate":"2018-07-25","union":"NON-UNION"};
     const mockResponse = {"dealId":167,"billingId":26,"firstName":null,"lastName":null,"pka":null,"roleNo":null,"role":null,"mainTitle":false,"endTitle":false,"paidAd":null,"cutFlag":false,"notCredited":false,"confirmedBy":{"name":"Phone","type":"CONFIRMED_BY","displayLabel":"Phone","displayOrder":2,"id":682},"attachment":{"name":"RE Name Confirmation - Superintelligence - Melissa McCarthy.msg","data":null},"attachmentType":null,"billingStatusNote":"testing","creditBillingText":null,"creditAs":"Blah blah test","dealDate":null,"union":null};
    
    service.saveBilling(billingData, id, projectId).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const saveBillingReq = httpMock.expectOne((request: HttpRequest<any>) => {
      return request.method == 'PUT'
        && request.url == urlService.getServiceEndpointUrl('api/projects/' + projectId +'/deals/'+ id +'/billings')
        && JSON.stringify(request.body) == JSON.stringify(billingData)
    });
    
    saveBillingReq.flush(mockResponse);
  })
  );

//   it(`should issue get billing attachment request`,
//   inject([HttpTestingController, ProjectDetailService, UrlResolverService],
//     (httpMock: HttpTestingController, service: ProjectDetailService, urlService: UrlResolverService) => {
//       const data = null;
//       const id = 1;
//       const projectId = 0;

//       service.getBillingAttachment(id, projectId).subscribe(data => {
//         expect(data).toBeNull();
//       });

//       const getBillingAttachmentReq = httpMock.expectOne((request: HttpRequest<any>) => {
//         return request.method == 'POST'
//           && request.url == urlService.getServiceEndpointUrl('api/projects/'+projectId+'/deals/' + id +'/attachments')
//           && JSON.stringify(request.responseType) === 'arraybuffer'
//       });
//       //expect(getBillingAttachmentReq.request.method).toEqual('POST');
//       getBillingAttachmentReq.flush(null);
//     })
// );

it(`should issue save status dates row request`,
inject([HttpTestingController, ProjectDetailService, UrlResolverService], 
  (httpMock: HttpTestingController, service: ProjectDetailService, urlService: UrlResolverService) => {
   const id = 1;
   const projectId = 0;
   const statusDatesData = {"projectId":1010774,"startDate":"2018-11-13","finishDate":"2018-11-29","status":{"value":"Post Production","route":"","id":360},"desc":"testing new","id":99};
   const mockResponse = {"projectId":1010774,"startDate":"2018-11-13","finishDate":"2018-11-29","status":{"name":"Post Production","type":null,"displayLabel":null,"displayOrder":null,"id":360},"desc":"testing new","id":99};

  service.saveStatusDates(statusDatesData, id, projectId).subscribe(data => {
    expect(data).toEqual(mockResponse);
  });
 
  const saveBillingReq = httpMock.expectOne((request: HttpRequest<any>) => {
    return request.method == 'PUT'
      && request.url == urlService.getServiceEndpointUrl('api/projects/'+projectId+'/statusDates')
      && JSON.stringify(request.body) == JSON.stringify(statusDatesData)
  });
  
  saveBillingReq.flush(mockResponse);
})
);

  it(`should issue a get status dates data request`,
  inject([HttpTestingController, ProjectDetailService, UrlResolverService], 
    (httpMock: HttpTestingController, service: ProjectDetailService, urlService: UrlResolverService) => {
    const id = 1;
    const mockResponse = [{"projectId":1010774,"startDate":"2018-11-13","finishDate":"2018-11-29","status":{"name":"Post Production","type":null,"displayLabel":null,"displayOrder":null,"id":360},"desc":"testing","id":99},{"projectId":1010774,"startDate":"2018-11-14","finishDate":"2018-11-29","status":{"name":"Added Scenes","type":null,"displayLabel":null,"displayOrder":null,"id":346},"desc":"testing","id":100}];

    service.getStatusDates(id).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
  
    const req = httpMock.expectOne(urlService.getServiceEndpointUrl('api/projects/' + id +'/statusDates'));
    expect(req.request.method).toEqual('GET');

    req.flush(mockResponse);
  })
  );

  it(`should issue a delete status dates row request`,
    inject([HttpTestingController, ProjectDetailService, UrlResolverService], 
      (httpMock: HttpTestingController, service: ProjectDetailService, urlService: UrlResolverService) => {
      const id = 1;
      const projectId = 0;
    
      service.deleteStatusDatesRecord(id, projectId).subscribe(data => {
        expect(data).toBeNull();
      });
    
      const delRepTypeReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/projects/'+projectId+'/statusDates/'+id));
      expect(delRepTypeReq.request.method).toEqual('DELETE');
    })
    );
  
});

