import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { catchError } from 'rxjs/operators';
import { Observer } from 'rxjs';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';

import { UrlResolverService, TypeAheadModel } from 'c2c-common-lib';


@Injectable()
export class TypeAheadService {

  constructor(private httpClient: HttpClient, private urlResolverService: UrlResolverService) { }

  /**
 * Convert returned response data
 * @param res
 */
  private mapData(res: TypeAheadModel[]): Array<TypeAheadModel> {
    let nta: Array<TypeAheadModel> = [];
    nta = res['typeAheadNames'];

    return nta;
  };

  /**
  * http service is to get the trackinglists for typeahead in create tracking list page
  */
  public getTrackinglist(searchTerm: string, noOfRecordsToBeReturned: string, filterType: string): Observable<TypeAheadModel[]> {
    let params = new HttpParams();
    params = params.append('textToBeSearched', searchTerm);
    params = params.append('noOfRecordsToBeReturned', noOfRecordsToBeReturned);
    const url = this.urlResolverService.getServiceEndpointUrl('/talenttracking/typeAheadNamesForTrackingList?filterType=' + filterType);
    return this.httpClient.get<TypeAheadModel[]>(url, { params: params })
      .map((res: TypeAheadModel[]) => this.mapData(res));
  };
  /**
  * http service is to get the projectlists for typeahead in create tracking list page
  */
  public getProjectlist(searchTerm: string, noOfRecordsToBeReturned: string, filterType: string): Observable<TypeAheadModel[]> {
    let params = new HttpParams();
    params = params.append('textToBeSearched', searchTerm);
    params = params.append('noOfRecordsToBeReturned', noOfRecordsToBeReturned);
    const url = this.urlResolverService.getServiceEndpointUrl('/talenttracking/typeAheadNamesForProjects?filterType=' + filterType);
    return this.httpClient.get<TypeAheadModel[]>(url, { params: params })
      .map((res: TypeAheadModel[]) => this.mapData(res));
  };
  /**
   * http service is to get the USERS LIST (sharewith) for typeahead in create tracking list page
   */
  public getUserlist(searchTerm: string, noOfRecordsToBeReturned: string, filterType: string): Observable<TypeAheadModel[]> {
    let params = new HttpParams();
    params = params.append('textToBeSearched', searchTerm);
    params = params.append('noOfRecordsToBeReturned', noOfRecordsToBeReturned);
    const url = this.urlResolverService.getServiceEndpointUrl('/talenttracking/typeAheadNamesForUsers?filterType=' + filterType);
    return this.httpClient.get<TypeAheadModel[]>(url, { params: params })
      .map((res: TypeAheadModel[]) => this.mapData(res));
  };
}


