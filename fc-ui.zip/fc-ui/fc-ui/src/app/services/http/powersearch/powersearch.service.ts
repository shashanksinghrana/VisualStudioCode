import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UrlResolverService } from 'c2c-common-lib';
import * as moment from 'moment';
import {
  ColumnDefModel, GridTitlesDefModel, GridTitlesParamsModel, GridPageOptionsModel,
  GridLinkParamsModel, GridListDefModel, GridListParamsModel
} from 'c2c-common-lib';
import { BlankContractModel } from '../../../models/power-search/blankContract.model';
import { isArray } from 'util';

/**
 * The Power searchService
 *
 * Handles all the service related functionality for Power search.
 */
@Injectable()
export class PowersearchService {

  public resultData: any = [];
  public totalRecords: number;

  /**
   * Constructor for the Power searchService
   */
  constructor(private http: HttpClient, private urlResolverService: UrlResolverService) { }

  /**
   * Defines all of Column Definitions used in the Powersearch Results Grid.
   */
  public createColumnDefs(): ColumnDefModel[] {
    return [
      new GridTitlesDefModel('Project Title', 'title',
        new GridTitlesParamsModel({ keys: ['title'], routing: new GridLinkParamsModel('/projectDetails', 'id') }, 'akaNames'),
        {
          config: { width: 210 }
        }
      ),
      new GridListDefModel('Performer', 'performerName',
        new GridListParamsModel({
          iterable: 'deals',
          keys: ['firstName', 'lastName'],
          routing: new GridLinkParamsModel('/createDeal', 'id', 'summary')
        }, true, false, 'performer.agencyList', 'lastName', false, true),
        {
          config: { width: 205 }
        }
      ),
      new GridListDefModel('Role', 'role',
        new GridListParamsModel({
          iterable: 'deals',
          keys: ['role']
        }, false, false, 'performer.agencyList', 'role'),
        {
          config: { width: 170 }
        }
      ),
      new GridListDefModel('Union', 'union',
        new GridListParamsModel({
          iterable: 'deals',
          keys: ['unionLookup.name']
        }, false, false, 'performer.agencyList', 'unionLookup.name'),
        {
          config: { width: 90 }
        }
      ),
      new GridListDefModel('Deal Date', 'dealDate',
        new GridListParamsModel({
          iterable: 'deals',
          keys: ['dealDate']
        }, false, false, 'performer.agencyList', 'dealDate'),
        {
          comparator: { name: 'dateComparator' },
          config: { width: 105 },
          formatter: 'dateFormatter',
          valGetter: 'dateGetter'
        })
    ];
  }

  /**  Method to format Date.  **/
  public formatDate(date: string): string {
    const isValid = moment(date).isValid();
    if (isValid) {
      return moment.parseZone(date).format('DD-MMM-YY');
    } else {
      return '';
    }
  }

  /*
 * Gets/defines all the page options for customizing the All Projects Grid.
 */
  public getPageOptions(resultsData) {
    const resultLength = resultsData ? this.totalRecords : 0;
    return new GridPageOptionsModel(true, `Search Results: ${resultLength}
  Items Found`, true, false, false, true, false, false, true, true);
  }

  /*
  *  Method to call Search result api
  */
  public getSearchResultData(data) {
    const searchData = this.processSearchData(data);
    let headers = new HttpHeaders();
    if (data.isRefresh) {
      headers = headers.set('skipLoading', 'true');
    }
    return this.http.post(this.urlResolverService.getServiceEndpointUrl('api/powersearch'), searchData.request,
    { params: searchData.param, headers: headers })
      .map((res: any) => {
        if (res) {
          const gridData = (res._embedded) ? res._embedded.content : res.content;
          const pagination = this.setPagination(res);
          return { pagination, gridData };
        }
      });
  }

  /** This method is used to allow uncheck records */
  private performBlankCheck(data: any[], key: string, returnKey: string): any[] {
    const requestArr = [];
    let isUncheckAll = true;
    let isSelectAll = true;
    data.map(val => {
      if (val) {
        if (val[key]) {
          isUncheckAll = false;
          requestArr.push(val[returnKey]);
        } else {
          isSelectAll = false;
        }
      }
    });
    return ( isUncheckAll || isSelectAll )  ? [] : requestArr;
  }

  /**
   * Method to process power search form data.
  **/
  public processSearchData(data) {
    const request: any = {};
    const param: any = {};
    request.projectTitles = [];
    request.performers = [];
    request.productionCompanies = [];
    request.unions = [];
    request.billings = [];
    request.roles = [];
    request.workActivities = [];
    request.compensations = [];
    request.textFields = {};
    request.statusDates = {};
    if (data) {
      for (const [key, value] of Object.entries(data.formData)) {
        if (Array.isArray(value)) {
          if (key === 'projectTitle') {
            value.map(val => {
              if (val.value) {
                if (request.projectTitles.indexOf(val.value.data.projectId) === -1) {
                  request.projectTitles.push(val.value.data.projectId);
                }
              }
            });
          } else if (key === 'productionCompany') {
            value.map(val => {
              if (val.value) {
                if (request.productionCompanies.indexOf(val.value.data.partyId) === -1) {
                  request.productionCompanies.push(val.value.data.partyId);
                }
              }
            });
          } else if (key === 'performer') {
            value.map(val => {
              if (val.value) {
                if (request.performers.indexOf(val.value.data.partyId) === -1) {
                  request.performers.push(val.value.data.partyId);
                }
              }
            });
          } else if (key === 'union') {
            request.unions = this.performBlankCheck(value, 'value', 'id');
          } else if (key === 'role') {
            value.map(val => {
              if (val.value) {
                if (request.roles.indexOf(val.value.value) === -1) {
                  request.roles.push(val.value.value);
                }
              }
            });
          } else if (key === 'billing') {
            request.billings = this.performBlankCheck(value, 'value', 'label');
          } else if (key === 'statusDate') {
            value.map(val => {
              const arr = val.values;
              if (arr && arr.length) {
                const ids = this.performBlankCheck(arr, 'value', 'id');
                let endDate = val.endDate;
                let startDate = val.startDate;
                if (startDate) {
                  startDate = moment.parseZone(startDate).format('DD-MMM-YY');
                }
                if (endDate) {
                  endDate = moment.parseZone(endDate).format('DD-MMM-YY');
                }
                request.statusDates = {
                  'startDate': startDate,
                  'endDate': endDate,
                  'projectStatusLookups': ids
                };
              }
            });
          } else if (key === 'workActivity') {
            value.map(val => {
              if (val && val.value1 !== null) {
                request.workActivities.push({
                  'type': val.type.value,
                  'operation': val.operation.value,
                  'value1': val.value1,
                  'value2': val.value2,
                  'condition': val.condition
                });
              }
            });
          } else if (key === 'compensation') {
            value.map(val => {
              if (val && val.value1) {
                request.compensations.push({
                  'type': val.type.value,
                  'operation': val.operation.value,
                  'value1': val.value1,
                  'value2': val.value2,
                  'condition': val.condition
                });
              }
            });
          } else if (key === 'textFields') {
            if (value.length && value[0].formChanged) {
              value.map(val => {
                if (val && val.options) {
                  request.textFields.textFields = [];
                  request.textFields.criteria = [];
                  request.textFields.textFields = this.performBlankCheck(val.options, 'checked', 'displayLabel');
                  val.items.forEach(item => {
                    request.textFields.criteria.push({
                      'operation': item.operation,
                      'value': item.searchTxt,
                      'condition': item.operand
                    });
                  });
                }
              });
            } else {
              request.textFields = null;
            }
          }
        }
      }
    }
    if (data) {
      if ((data.formData.startDate) && (data.formData.startDate) !== 'All') {
        request.startDate = this.formatDate(data.formData.startDate);
      } else {
        request.startDate = '';
      }
      if ((data.formData.endDate) && (data.formData.endDate) !== 'All') {
        request.endDate = this.formatDate(data.formData.endDate);
      } else {
        request.endDate = '';
      }
    }
    if (data) {
      if (data.filterParams) {
        data.filterParams.updates.forEach(element => {
          switch (element.param) {
            case 'title':
              request.gridTitle = element.value;
              break;
            case 'performerName':
              request.gridPerformer = element.value;
              break;
            case 'role':
              request.gridRole = element.value;
              break;
            case 'union':
              request.gridUnion = element.value;
              break;
            case 'dealDate':
              request.gridDealDate = element.value;
              break;
            case 'page':
              param.page = element.value;
              break;
            case 'size':
              param.size = element.value;
              break;
            // case 'sort':// not needed as we are using a different parameter
            //   param.sort = element.value;
            //   break;
            case 'multiColumnSort':
              if(!isArray(param.sort)){
                param.sort = [];
              }
              param.sort.push(element.value);
              break;
            default:
              break;
          }
        });
      }
    }
    return { request, param };
  }

  /*
  * Method to generate pagination data from response value.
  */
  public setPagination(res) {
    const pagination = {
      number: res.currentPageNumber,
      size: res.pageSize,
      totalElements: res.totalRecords,
      totalPages: res.totalPages
    };
    this.totalRecords = res.totalRecords;
    return pagination;
  }


  /**
  * This method will fetch Previous/Saved Searches values for dropdown
  */
  public getPrevSavedSearchesForUser() {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/powersearch/queries'))
      .map((res: any) => {
        return res;
      });
  }


  /**
  * This method will fetch Previous/Saved Searches Criteria based on Id
  * @param id saved search Id
  */
  public getPrevSavedSearchById(id) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/powersearch/queries/' + id))
      .map((res: any) => {
        return res;
      });
  }

  /**
  * This method will save searches
  * @param searchList search criteria
  */
  public savePrevSavedSearch(searchList: any) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/powersearch/queries'), searchList)
      .map((res: any) => res);
  }

  /**
   * THis method will delete Previous/Saved Searches
   * @param id
   */
  public deletePrevSavedSearch(id) {
    return this.http.delete(this.urlResolverService.getServiceEndpointUrl('api/powersearch/queries/' + id))
      .map((res: any) => res);
  }

  /** Method to add parameter for report */
  public reportParam(reportName: any, psFormData?: any, reportSelectionData?: any, startDate?: any, endDate?: any, sortingOrder?: any, blankReportdata?: BlankContractModel, castingDataReportData?: any): any {
    const request = this.processSearchData(psFormData).request;
    request.reportParams = {};
    if (reportName === 'Cast List') {
      reportSelectionData.forEach(value => {
        request.reportParams[value] = 'true';
      });
    } else if (reportName === 'Station 12 Report') {
      request.reportParams['StartDate'] = this.formatDate(startDate);
      request.reportParams['EndDate'] = this.formatDate(endDate);
    } else if (reportName === 'Billing List') {
      request.reportParams['SortKey'] = sortingOrder;
    } else if (reportName === 'Blank Contract') {
      request.reportParams['ContractType'] = blankReportdata.contractType;
      request.reportParams['ProjectName'] = blankReportdata.title;
      request.reportParams['ProductionCo'] = blankReportdata.production;
      request.reportParams['Address'] = blankReportdata.address;
      request.reportParams['Signatory'] = blankReportdata.signatories;
    }
    else if (reportName === 'Casting Data Report') {
      request.reportParams['SubmittedBy'] = castingDataReportData.submittedBy;
      request.reportParams['Phone'] = castingDataReportData.phoneNo;
      request.reportParams['StuntOnly'] = (castingDataReportData.stuntOnly !== null) ? castingDataReportData.stuntOnly : false;
    }

    return request;
  }

  public downloadfile(reportName, choice, formData, startDate?, endDate?, sortingOrder?, castSelection?, blankReportData?: BlankContractModel, castingDataReportData?) {
    const param = this.processSearchData(formData).param;
    const searchRequest = this.reportParam(reportName, formData, castSelection, startDate, endDate, sortingOrder, blankReportData, castingDataReportData);
    const url = this.setUrlAsReportType(reportName, choice);
    return this.http.post(this.urlResolverService.getServiceEndpointUrl('api/reports/powersearch/' + url),
      searchRequest, { params: param, responseType: 'blob', observe: 'response' })
      .map((res: any) => res);
  }

  public setUrlAsReportType(reportName: any, choice: any): any {

    let url: any;

    switch (reportName) {
      case 'I-9 Report':
        url = 'I9_STATUS?fileType=' + choice;
        break;
      case 'Missing Birthdate Report':
        url = 'MISSING_BIRTHDATE?fileType=' + choice;
        break;
      case 'Station 12 Report':
        url = 'STATION12?fileType=' + choice;
        break;
      case 'Contract Status Report':
        url = 'CONTRACT_STATUS?fileType=' + choice;
        break;
      case 'Post Sync Time Log':
        url = 'POST_SYNC_TIME_LOG?fileType=' + choice;
        break;
      case 'Billing List':
        url = 'BILLING_LIST?fileType=' + choice;
        break;
      case 'Cast List':
        url = 'CAST_LIST?fileType=' + choice;
        break;
      case 'Crew list Worksheet':
        url = 'CREW_LIST?fileType=' + choice;
        break;
      case 'Blank Contract':
        url = 'BLANK_CONTRACT?fileType=' + choice;
        break;
      case 'Talent Voucher':
        url = 'TALENT_VOUCHER?fileType=' + choice;
        break;
      case 'Casting Data Report':
        url = 'CASTING_DATA?fileType=' + choice;
        break;
      default:
        url = 'undefined';
    }
    return url;
  }
}
