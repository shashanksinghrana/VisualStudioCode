import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { UrlResolverService, TypeAheadModel } from 'c2c-common-lib';
import { PerqsResolverService } from '../../resolvers/perq-resolver.service';

/**
 * The Perqs Save Service
 *
 */
@Injectable()
export class PerqsService {

  /**
   * Constructor for the  class
   *
   * @param http The HttpClient service.
   */
  constructor(private http: HttpClient, private urlResolverService: UrlResolverService) { }

  
    /**
   * Get the perqs record.
   *  @param id 
   */
  public getPerqs(id : number) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/perqs/' + id))
      .map((res: any) => {
        if (res._embedded) {
          res = res._embedded;
        } else {
          res = [];
        }
        return res;
      });
  }

  /**
   * Saves the perqs record.
   * @param perqsData the perq form data
   */
  public savePerqsRecord(perqsData,id) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/perqs/'+id), perqsData)
      .map((res: any) => res);
  }
  
}
