import { TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DealService } from './deal.service';
import { UrlResolverService, TypeAheadPersistService } from 'c2c-common-lib';
import { CurrentUserPersistService } from '../../persist/user/current-user-persist.service';

describe('DealService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [DealService, UrlResolverService,CurrentUserPersistService,TypeAheadPersistService]
    });
  });

  afterEach(inject([HttpTestingController], (httpMock: HttpTestingController) => {
    httpMock.verify();
  }));

  it('should be created', inject([DealService], (service: DealService) => {
    expect(service).toBeTruthy();
  }));

  it(`should issue a get credit request`,
    inject([HttpTestingController, DealService, UrlResolverService],
      (httpMock: HttpTestingController, service: DealService, urlService: UrlResolverService) => {
        const id = 1;
        const mockResponse = { "dealId": 251, "creditDetail": [{ "creditTitle": { "name": "End Title", "type": "MAIN_END_TITLE", "displayLabel": null, "displayOrder": 2, "id": 182 }, "card": { "name": "Single", "type": "CARD", "displayLabel": null, "displayOrder": 1, "id": 186 }, "position": { "name": "1st Position", "type": "POSITION", "displayLabel": null, "displayOrder": 1, "id": 189 }, "note": null, "creditId": 501 }], "creditBilling": [{ "billingText": "<div>Guaranteed billing on a separate card, in the main titles (if any), size equal to all other cast members receiving credit on a separate card.</div>", "billingLookupText": { "name": "Guaranteed billing on a separate card, in the main titles (if any), size equal to all other cast members receiving credit on a separate card.", "type": "BILLING_TEXT", "displayLabel": null, "displayOrder": 6, "id": 200 }, "creditBillingId": 462 }], "_links": { "self": { "href": "http://dev.concept2alize.com/fc/dev1/fc/api/deal/251" } } };

        service.getCredit(id).subscribe(data => {
          expect(data).toEqual(mockResponse);
        });

        const getCreditReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/credit/' + id));
        expect(getCreditReq.request.method).toEqual('GET');

        getCreditReq.flush(mockResponse);
      })
  );

  it(`should issue submit Credit request`,
    inject([HttpTestingController, DealService, UrlResolverService],
      (httpMock: HttpTestingController, service: DealService, urlService: UrlResolverService) => {
        const credit = { "dealId": "251", "creditDetail": [{ "creditTitle": { "id": 182, "name": "End Title", "type": "MAIN_END_TITLE", "displayOrder": 2 }, "card": { "id": 186, "name": "Single", "type": "CARD", "displayOrder": 1 }, "position": { "id": 189, "name": "1st Position", "type": "POSITION", "displayOrder": 1 }, "note": null }], "creditBilling": [{ "billingText": "<div>Guaranteed billing on a separate card, in the main titles (if any), size equal to all other cast members receiving credit on a separate card.</div>", "billingLookupText": { "id": 200, "name": "Guaranteed billing on a separate card, in the main titles (if any), size equal to all other cast members receiving credit on a separate card.", "type": "BILLING_TEXT", "displayOrder": 6 } }, { "billingText": "<div>Guaranteed billing in the end titles to appear as</div>", "billingLookupText": { "id": 197, "name": "Guaranteed billing in the end titles to appear as", "type": "BILLING_TEXT", "displayOrder": 3 } }] };
        const mockResponse = { "dealId": 251, "creditDetail": [{ "creditTitle": { "name": "End Title", "type": "MAIN_END_TITLE", "displayLabel": null, "displayOrder": 2, "id": 182 }, "card": { "name": "Single", "type": "CARD", "displayLabel": null, "displayOrder": 1, "id": 186 }, "position": { "name": "1st Position", "type": "POSITION", "displayLabel": null, "displayOrder": 1, "id": 189 }, "note": null, "creditId": 502 }], "creditBilling": [{ "billingText": "<div>Guaranteed billing on a separate card, in the main titles (if any), size equal to all other cast members receiving credit on a separate card.</div>", "billingLookupText": { "name": "Guaranteed billing on a separate card, in the main titles (if any), size equal to all other cast members receiving credit on a separate card.", "type": "BILLING_TEXT", "displayLabel": null, "displayOrder": 6, "id": 200 }, "creditBillingId": 463 }, { "billingText": "<div>Guaranteed billing in the end titles to appear as</div>", "billingLookupText": { "name": "Guaranteed billing in the end titles to appear as", "type": "BILLING_TEXT", "displayLabel": null, "displayOrder": 3, "id": 197 }, "creditBillingId": 464 }], "_links": { "self": { "href": "http://dev.concept2alize.com/fc/dev1/fc/api/deal/251" } } };

        service.saveCredit(credit).subscribe(data => {
          expect(data).toEqual(mockResponse);
        });

        const saveCrediteq = httpMock.expectOne((request: HttpRequest<any>) => {
          return request.method == 'POST'
            && request.url == urlService.getServiceEndpointUrl('api/credit/')
            && JSON.stringify(request.body) == JSON.stringify(credit)
        });

        saveCrediteq.flush(mockResponse);
      })
  );

  it(`should issue a get workactivity request`,
    inject([HttpTestingController, DealService, UrlResolverService],
      (httpMock: HttpTestingController, service: DealService, urlService: UrlResolverService) => {
        const dealId = 251;
        const mockResponse = [
          {
            "workActivityId": 1081,
            "dealId": 330,
            "activityLookupId": 246,
            "startDate": "2018-10-10",
            "note": "hkm,m,m",
            "princFreeLookupId": 497,
            "postFreeLookupId": 500,
            "guranteeLookupId": 495,
            "description": "ADR"
          }]
        service.getWorkActivityDetails(dealId).subscribe(data => {
          expect(data).toEqual(mockResponse);
        });
        const getWorkActivityReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/deals/' + dealId + '/workActivities'));
        expect(getWorkActivityReq.request.method).toEqual('GET');

      })
  )

  it(`should issue submit workactivity request`,
    inject([HttpTestingController, DealService, UrlResolverService],
      (httpMock: HttpTestingController, service: DealService, urlService: UrlResolverService) => {
        const work = [
          {
            "workActivityId": 1081,
            "dealId": 330,
            "activityLookupId": 246,
            "startDate": "2018-10-10",
            "note": "hkm,m,m",
            "princFreeLookupId": 497,
            "postFreeLookupId": 500,
            "guranteeLookupId": 495,
            "description": "ADR"
          }]
        const mockResponse = [
          {
            "workActivityId": 1081,
            "dealId": 330,
            "activityLookupId": 246,
            "startDate": "2018-10-10",
            "note": "hkm,m,m",
            "princFreeLookupId": 497,
            "postFreeLookupId": 500,
            "guranteeLookupId": 495,
            "description": "ADR"
          }]
        const dealId = 251;
        service.saveWorkActivity(work).subscribe(data => {
          expect(data).toEqual(mockResponse);
        });

        const saveWorkActivityReq = httpMock.expectOne((request: HttpRequest<any>) => {
          return request.method == 'PUT'
            && request.url == urlService.getServiceEndpointUrl('api/deals/' + dealId + '/workActivities')
            && JSON.stringify(request.body) == JSON.stringify(work)
        });

        saveWorkActivityReq.flush(mockResponse);
      })
  );

  it(`should issue a get compensation request`,
    inject([HttpTestingController, DealService, UrlResolverService],
      (httpMock: HttpTestingController, service: DealService, urlService: UrlResolverService) => {
        const dealId = 251;
        const mockResponse = [
          {
            "compensations": [{
              "dealId": 166,
              "guaranteeNumber": 7,
              "guaranteeType": null,
              "feeTypeId": 85,
              "rate": 3239.0,
              "descript": null,
              "startDate": "2018-10-24",
              "periodId": 91,
              "periodLookup": {
                "name": "First",
                "type": "PERIOD_TYPE",
                "displayLabel": null,
                "displayOrder": 1,
                "id": 91
              },
              "interval": null,
              "contractReturnedDate": "2018-10-16",
              "contractRevisedDate": "2018-10-15",
              "contractSentDate": "2018-10-17",
              "contractText": "<!DOCTYPE html>\n<html>\n<head>\n</head>\n<body style=\"font-family: Arial;font-size: 10pt;\">\n<div>73367</div>\n</body>\n</html>",
              "contractInfo": "<!DOCTYPE html>\n<html>\n<head>\n</head>\n<body style=\"font-family: Arial;font-size: 10pt;\">\n<div>737</div>\n</body>\n</html>",
              "totalAmount": 22673.0,
              "voidFlag": true,
              "principalFree": null,
              "principalFreeInterval": null,
              "postFree": null,
              "postFreeInterval": null,
              "adjustmentInterval": null,
              "startDateQualifierLookup": {
                "name": "Approx",
                "type": "START_DATE_QUALIFIER_TYPE",
                "displayLabel": null,
                "displayOrder": 1,
                "id": 95
              },
              "operationsSet": [],
              "conditionsSet": [],
              "id": "601",
              "startDateDropdown": 95,
              "isNew": false
            }],
            "contracts": [{
              "id": 221,
              "compensationId": "601",
              "dealId": 166,
              "contractLookupId": 582,
              "contractName": "Minimum Freelance Contract"
            }]
          }
        ]
        service.getCompensationDetails(dealId).subscribe(data => {
          expect(data).toEqual(mockResponse);
        });
        const getCompensationReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/compensations/') + dealId);
        expect(getCompensationReq.request.method).toEqual('GET');

      })
  )

  it(`should issue submit compensation request`,
    inject([HttpTestingController, DealService, UrlResolverService],
      (httpMock: HttpTestingController, service: DealService, urlService: UrlResolverService) => {
        const dealId = 251;
        const comp = [
          {
            "compensations": [{
              "dealId": 166,
              "guaranteeNumber": 7,
              "guaranteeType": null,
              "feeTypeId": 85,
              "rate": 3239.0,
              "descript": null,
              "startDate": "2018-10-24",
              "periodId": 91,
              "periodLookup": {
                "name": "First",
                "type": "PERIOD_TYPE",
                "displayLabel": null,
                "displayOrder": 1,
                "id": 91
              },
              "interval": null,
              "contractReturnedDate": "2018-10-16",
              "contractRevisedDate": "2018-10-15",
              "contractSentDate": "2018-10-17",
              "contractText": "<!DOCTYPE html>\n<html>\n<head>\n</head>\n<body style=\"font-family: Arial;font-size: 10pt;\">\n<div>73367</div>\n</body>\n</html>",
              "contractInfo": "<!DOCTYPE html>\n<html>\n<head>\n</head>\n<body style=\"font-family: Arial;font-size: 10pt;\">\n<div>737</div>\n</body>\n</html>",
              "totalAmount": 22673.0,
              "voidFlag": true,
              "principalFree": null,
              "principalFreeInterval": null,
              "postFree": null,
              "postFreeInterval": null,
              "adjustmentInterval": null,
              "startDateQualifierLookup": {
                "name": "Approx",
                "type": "START_DATE_QUALIFIER_TYPE",
                "displayLabel": null,
                "displayOrder": 1,
                "id": 95
              },
              "operationsSet": [],
              "conditionsSet": [],
              "id": "601",
              "startDateDropdown": 95,
              "isNew": false
            }]
          }
        ]

        const riders = [
          {
            "contracts": [{
              "id": 221,
              "compensationId": "601",
              "dealId": 166,
              "contractLookupId": 582,
              "contractName": "Minimum Freelance Contract"
            }]
          }
        ]

        const mockResponse = [
          {
            "compensations": [{
              "dealId": 166,
              "guaranteeNumber": 7,
              "guaranteeType": null,
              "feeTypeId": 85,
              "rate": 3239.0,
              "descript": null,
              "startDate": "2018-10-24",
              "periodId": 91,
              "periodLookup": {
                "name": "First",
                "type": "PERIOD_TYPE",
                "displayLabel": null,
                "displayOrder": 1,
                "id": 91
              },
              "interval": null,
              "contractReturnedDate": "2018-10-16",
              "contractRevisedDate": "2018-10-15",
              "contractSentDate": "2018-10-17",
              "contractText": "<!DOCTYPE html>\n<html>\n<head>\n</head>\n<body style=\"font-family: Arial;font-size: 10pt;\">\n<div>73367</div>\n</body>\n</html>",
              "contractInfo": "<!DOCTYPE html>\n<html>\n<head>\n</head>\n<body style=\"font-family: Arial;font-size: 10pt;\">\n<div>737</div>\n</body>\n</html>",
              "totalAmount": 22673.0,
              "voidFlag": true,
              "principalFree": null,
              "principalFreeInterval": null,
              "postFree": null,
              "postFreeInterval": null,
              "adjustmentInterval": null,
              "startDateQualifierLookup": {
                "name": "Approx",
                "type": "START_DATE_QUALIFIER_TYPE",
                "displayLabel": null,
                "displayOrder": 1,
                "id": 95
              },
              "operationsSet": [],
              "conditionsSet": [],
              "id": "601",
              "startDateDropdown": 95,
              "isNew": false
            }],
            "contracts": [{
              "id": 221,
              "compensationId": "601",
              "dealId": 166,
              "contractLookupId": 582,
              "contractName": "Minimum Freelance Contract"
            }]
          }
        ]
        service.saveCompensation(comp, riders).subscribe(data => {
          expect(data).toEqual(mockResponse);
        });

        const saveCompensationReq = httpMock.expectOne((request: HttpRequest<any>) => {
          return request.method == 'PUT'
            && request.url == urlService.getServiceEndpointUrl('api/deals/' + dealId + '/contractTerms')
            && JSON.stringify(request.body) == JSON.stringify(comp)
            && JSON.stringify(request.body) == JSON.stringify(riders)
        });

        saveCompensationReq.flush(mockResponse);
      })
  );
});
