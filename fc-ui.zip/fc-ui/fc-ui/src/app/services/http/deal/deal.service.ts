import { Injectable, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpParams } from '@angular/common/http';
import { UrlResolverService, AuditModel } from 'c2c-common-lib';
import { DealModel } from '../../../models/deal/deal.model';
import { Observable } from '../../../../../node_modules/rxjs/Observable';
import { WizardModel } from '../../../models/deal/wizard.model';
import { performerNameFormatter } from '../../../utils/formatter/performer-name.format';
import { stringToDateFormatter } from '../../../utils/formatter/string-to-date.format';
import { LoanoutModel } from '../../../models/deal/loanout.model';
import { CurrentUserPersistService } from '../../persist/user/current-user-persist.service';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class DealService {
  public dealId: string;

  private _audit: AuditModel;
  private _currentWizardPage: WizardModel;
  private _deal: DealModel;
  private _loanout: LoanoutModel;
  private _performerDetail: any;
  private _project;
  private _wizardSubTitles: Array<string>;
  private _dealDetails = new BehaviorSubject(null);
  private namesProjectUpdated = new EventEmitter<any>();

  constructor(private http: HttpClient,
    private urlResolverService: UrlResolverService,
    private currentUserPersistService: CurrentUserPersistService, ) {
  }

  public get audit(): AuditModel {
    return this._audit;
  }

  public set audit(value: AuditModel) {
    this._audit = value;
  }

  public get currentWizardPage(): WizardModel {
    return this._currentWizardPage;
  }

  public set currentWizardPage(value: WizardModel) {
    this._currentWizardPage = value;
  }

  public get deal(): DealModel {
    return this._deal;
  }

  public set deal(value: DealModel) {
    this._deal = value;
    this.setDealDetails(value);
  }

  public get loanout(): LoanoutModel {
    return this._loanout;
  }

  public set loanout(value: LoanoutModel) {
    this._loanout = value;
  }

  public get performerDetail(): any {
    return this._performerDetail;
  }

  public set performerDetail(value: any) {
    this._performerDetail = value;
  }

  public get project() {
    return this._project;
  }

  public set project(value) {
    this._project = value;
  }

  public get wizardSubTitles(): Array<string> {
    return this._wizardSubTitles;
  }

  public set wizardSubTitles(value: Array<string>) {
    this._wizardSubTitles = value;
  }

  public getDealId(): string {
    return this.dealId;
  }

  public setDealId(dealId: string): void {
    this.dealId = dealId;
  }

  public setWizardDetails(performerNameChanged) {
    this.namesProjectUpdated.emit(performerNameChanged);
  }

  public getWizardDetail(): EventEmitter<any> {
    return this.namesProjectUpdated;
  }

  public setDealDetails(deal: any) {
    this._dealDetails.next(deal);
  }

  public getDealDetails(): Observable<any> {
    return this._dealDetails;
  }

  public getDeal(id) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/deal/' + id))
      .map((res: any) => {
        res.dealDate = res.dealDate ? stringToDateFormatter(res.dealDate) : null;
        this.audit = new AuditModel(res.createDate, res.createdBy, res.updateDate, res.updateBy);
        this.performerDetail = this.getPerformerDetails(res.performer.partyId, res.performer.akaId, res.performer.performerPartyIdVer);
        return res;
      });
  }

  private formatDate(date) {
    let format = null;
    const isValid = moment(date).isValid();
    if (isValid) {
      format = moment.parseZone(date).format('YYYY-MM-DD');
    }
    return format;
  }

  public saveDeal(deal) {
    if (deal.productionCompany != null && deal.productionCompany['value'].length !== 0) {
      deal.productionCompany = deal.productionCompany.data;
    } else {
      deal.productionCompany = null;
    }
    deal.dealDate = this.formatDate(deal.dealDate);
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/deal'), deal)
      .map((res: any) => {
        if (res) {
          this.audit = new AuditModel(null, null, res.updateDate, res.updateBy);
        }
        return res;
      });
  }

  public getPerformerDetails(performerId: number, akaId: number, performerVersionId?: number) {
    let url = 'api/performer/' + performerId + '/akas/' + akaId;
    if(performerVersionId) {
       url += '?partyVersion='+ performerVersionId;
    }
    console.log(this.urlResolverService.getServiceEndpointUrl(url));
    return this.http.get(this.urlResolverService.getServiceEndpointUrl(url))
      .map((res: any) => res);
  }

  public getFormula(feeTypeId: string) {
    // TODO: Delete studioId variable - Needed to hard-code studio ID until security is in place
    const studioId = this.currentUserPersistService.getCurrentUser().studioId;
    let params = new HttpParams();
    params = params.append('dealType', 'DEAL');
    params = params.append('pageType', 'Compensation');
    params = params.append('studioId', studioId);
    params = params.append('feeType', feeTypeId);

    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/formulas'), { params: params })
      .map((res: any) => res._embedded.formulas);
  }

  public getWorkActivityFormula() {
    // TODO: Delete studioId variable - Needed to hard-code studio ID until security is in place
    // let studioId = this.urlResolverService.getServiceEndpointUrl('').indexOf('wb-reg') >= 0 ? '11753' : '5373';
    const studioId = this.currentUserPersistService.getCurrentUser().studioId;
    let params = new HttpParams();
    params = params.append('dealType', 'DEAL');
    params = params.append('pageType', 'Work Activity');
    params = params.append('studioId', studioId);

    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/formulas'), { params: params })
      .map((res: any) => res._embedded.formulas);
  }


  public getWizardDetails(): Observable<WizardModel[]> {
    let params = new HttpParams();
    params = params.append('formType', 'WIZARD');
    params = params.append('type', 'DEAL');
    if (this.dealId !== 'new') {
      params = params.append('id', this.dealId);
    }
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/wizards'), { params: params })
      .map((res: any) => {
        res._embedded.wizards = this.sortData(res._embedded.wizards);
        return res._embedded.wizards;
      });
  }

  public updateWizardDetails(wizard: WizardModel) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/wizard'), wizard)
      .map((res: any) => res);
  }

  public saveWizardSubtitles(deal: DealModel) {
    if (deal.id) {
      this.wizardSubTitles = [
        deal.project.title['title'],
        new DatePipe('en-US').transform(deal.dealDate, 'MM/dd/yyyy'),
        performerNameFormatter(deal.performer.firstName, deal.performer.lastName, deal.performer.typeAheadDisplayName)
      ];
    }
  }

  public getProductionCompaniesByProject(projectId: number) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/project/' + projectId + '/productionCompany'))
      .map((res: any[]) => res);
  }

  public getUnionByProjectAndCompany(projectId: number, companyId: number) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/project/' + projectId + '/productionCompany/' + companyId + '/union'))
      .map((res: any[]) => res);
  }

  public getCreditApi(dealId) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/credit/') + dealId)
      .map((res: any) => res);
  }

  public getNotceandPaymentsApi(dealId) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/rep/') + dealId)
      .map((res: any) => res);
  }

  public getContractTerms(dealId) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/deals/' + dealId + '/contractTerms'))
      .map((res: any) => {
        const result = {
          compensations: null,
          contracts: null
        };
        // set compensation data
        if (res && res.compensations.length > 0) {
          const compArr: any[] = [];
          let ids: string[] = [];
          res.compensations.forEach((fee) => {
            ids.push(fee.feeTypeId);
          });

          ids = Array.from(new Set(ids));
          ids.forEach((id) => {
            compArr.push({ id: id, feeType: null, data: [] });
          });

          compArr.forEach((comp) => {
            res.compensations.forEach((fee) => {
              if (fee.feeTypeId === comp.id) {
                comp.data.push(fee);
              }
              if (fee.startDateDropdown) {
                fee.startDateQualifierId = fee.startDateDropdown;
              }
            });
          });

          result.compensations = compArr;
        }

        // set contract data
        if (res && res.contracts.length > 0) {
          result.contracts = res.contracts;
        }
        return result;
      });
  }

  public getCompensationDetails(dealId) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/compensations/') + dealId)
      .map((res: any) => {
        if (res._embedded && res._embedded.compensations.length > 0) {
          const compArr: any[] = [];
          let ids: string[] = [];
          res._embedded.compensations.forEach((fee) => {
            ids.push(fee.feeTypeId);
          });

          ids = Array.from(new Set(ids));
          ids.forEach((id) => {
            compArr.push({ id: id, feeType: null, data: [] });
          });

          compArr.forEach((comp) => {
            res._embedded.compensations.forEach((fee) => {
              if (fee.feeTypeId === comp.id) {
                comp.data.push(fee);
              }
              if (fee.startDateDropdown) {
                fee.startDateQualifierId = fee.startDateDropdown;
              }
            });
          });

          return compArr;
        } else {
          return null;
        }
      });
  }

  public getWorkActivityDetails(dealId) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/deals/' + dealId + '/workActivities'))
      .map((res: any) => {
        if (res._embedded && res._embedded.workActivities.length > 0) {
          const workArr: any[] = [];
          let ids: string[] = [];
          res._embedded.workActivities.forEach((fee) => {
            ids.push(fee.workActivityId);
          });

          ids = Array.from(new Set(ids));
          ids.forEach((id) => {
            workArr.push({ id: id, data: [] });
          });

          workArr.forEach((work) => {
            res._embedded.workActivities.forEach((fee) => {
              if (work.id) {
                work.data.push(fee);
              }
            });
          });

          return workArr;
        } else {
          return null;
        }
      });
  }

  public getContractRiders() {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/contractRiders'))
      .map((res: any) => res);
  }

  /**
   * THis method will save, update and delete any changes.
   * @param compensation the compensation form data.
   */
  public saveCompensation(compensation: any, riders: any) {
    delete compensation['feeType'];
    delete compensation['contractRider'];
    const dealId: string = this.getDealId();
    let compensationSaveObj: any[] = [];
    if (compensation instanceof Array) {
      compensationSaveObj = compensation['data'];
    } else {
      for (const [key, value] of Object.entries(compensation)) {
        if (Array.isArray(value)) {
          value.forEach((val) => {
            val.feeTypeId = Number.parseInt(key);
          });
          compensationSaveObj = compensationSaveObj.concat(value);
        }
      }

      compensationSaveObj.forEach((obj) => {
        obj.dealId = Number.parseInt(this.dealId);
        obj.rate = Number.parseFloat(obj.rate);
        obj.totalAmount = Number.parseFloat(obj.totalAmount);
        obj.operationsSet = [];
        obj.conditionsSet = [];
        obj.descript = compensation.descript;
        if (obj.contractDate) {
          obj.contractDate = this.formatDate(obj.contractDate);
        }
        if (obj.startDate) {
          obj.startDate = this.formatDate(obj.startDate);
        }
        if (obj.contractSentDate) {
          obj.contractSentDate = this.formatDate(obj.contractSentDate);
        }
        if (obj.contractRevisedDate) {
          obj.contractRevisedDate = this.formatDate(obj.contractRevisedDate);
        }
        if (obj.contractReturnedDate) {
          obj.contractReturnedDate = this.formatDate(obj.contractReturnedDate);
        }
        if (obj.periodId) {
          obj.periodId = obj.periodId.id;
        }
        if (obj.startDateQualifierId) {
          obj.startDateDropdown = obj.startDateQualifierId.id;
        }
        if (obj.interval) {
          obj.interval = obj.interval.id;
        }
        if (obj.postFreeInterval) {
          obj.postFreeInterval = obj.postFreeInterval.id;
        }
        if (obj.principalFreeInterval) {
          obj.principalFreeInterval = obj.principalFreeInterval.id;
        }
      });
    }
    const contractTerms = {
      compensations: compensationSaveObj,
      contracts: riders
    };
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/deals/' + dealId + '/contractTerms'), contractTerms)
      .map((res: any) => res);
  }

  /**
   * THis method will save, update and delete any changes.
   * @param work the work activity form data.
   */
  public saveWorkActivity(saveObj: any) {
    const dealId: string = this.getDealId();
    saveObj.forEach((obj) => {
      obj.dealId = Number.parseInt(this.dealId);
      if (obj.startDate) {
        obj.startDate = this.formatDate(obj.startDate);
      }
      if (obj.activityLookupId) {
        obj.activityLookupId = obj.activityLookupId.id;
      }
      if (obj.guranteeLookupId) {
        obj.guranteeLookupId = obj.guranteeLookupId.id;
      }
      if (obj.princFreeLookupId) {
        obj.princFreeLookupId = obj.princFreeLookupId.id;
      }
      if (obj.postFreeLookupId) {
        obj.postFreeLookupId = obj.postFreeLookupId.id;
      }
    });
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/deals/' + dealId + '/workActivities'), saveObj)
      .map((res: any) => res);
  }

  /**
   * Sorts the wizards tiles based on the displayOrder property in the returned JSON.
   *
   * @param data the wizard tile data from the api.
   */
  public sortData(data: any) {
    data.sort((a, b): number => {
      if (a.page.displayOrder < b.page.displayOrder) {
        return -1;
      }
      if (a.page.displayOrder > b.page.displayOrder) {
        return 1;
      }
      return 0;
    });
    return data;
  }

  /**
  * THis method will save, update and delete any changes.
  * @param credit the credit form data.
  */
  public saveCredit(credit: any) {
    return this.http.post(this.urlResolverService.getServiceEndpointUrl('api/credit/'), credit)
      .map((res: any) => res);
  }

  /**
   * THis method will fetch credit details.
   * @param id deal id.
   */
  public getCredit(id) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/credit/' + id))
      .map((res: any) => {
        return res;
      });
  }

  /**
   * THis method will save Loanout data.
   * @param id deal id.
   * @param loanout data.
   */
  public saveLoanout(id, loanout) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl(`api/deals/${id}/loanouts`), loanout)
      .map((res: any) => {
        if (res) {
          this.loanout = loanout;
        }
        return res;
      });
  }

  /**
   * THis method will get Loanout data.
   * @param this.dealID deal id.
   */
  public getLoanout(dealID: number) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/deals/' + dealID + '/loanouts'))
      .map((res: any) => {
        this.loanout = res;
        return res;
      });
  }

  /**
  * THis method will delete rep
  * @param rep the rep form data.
  */
  public deleteDeal(dealId) {
    return this.http.delete(this.urlResolverService.getServiceEndpointUrl('/api/deals/' + dealId))
      .map((res: any) => {
        const data = res;
      });
  }

  /**
    * Method to download Contract rider pdf file
    * @param  contractData compensation form data.
    * @param dealID deal Id
    * @param lookupId contract rider lookup id
    */
  public downloadfile(dealID, lookupId, contractData?: any, isReport?:boolean) {
    const compensationObj: any = {};
   
    if(isReport ){
      compensationObj.reportParams = {};
      compensationObj.reportParams['ContractType'] = contractData.contractType;
      compensationObj.reportParams['ProjectName'] = contractData.title;
      compensationObj.reportParams['ProductionCo'] = contractData.production;
      compensationObj.reportParams['Address'] = contractData.address;
      compensationObj.reportParams['Signatory'] = contractData.signatories;
    }
    if (contractData.length && contractData[0] !== null) {
      compensationObj.dealId = this.deal.id;
      compensationObj.rate = Number.parseFloat(contractData[0].rate).toFixed(2);
      compensationObj.totalAmount = contractData[0].totalAmount ? contractData[0].totalAmount : Number.parseFloat(contractData[0].totalAmount);
      compensationObj.guaranteeNumber = contractData[0].guaranteeNumber;
      if (contractData[0].startDate) {
        compensationObj.startDate = this.formatDate(contractData[0].startDate);
      } else {
        compensationObj.startDate = contractData[0].startDate;
      }
      compensationObj.voidFlag = contractData[0].voidFlag;
      compensationObj.contractInfo = contractData[0].contractInfo;
      if (contractData[0].contractReturnedDate) {
        compensationObj.contractReturnedDate = this.formatDate(contractData[0].contractReturnedDate);
      } else {
        compensationObj.contractReturnedDate = contractData[0].contractReturnedDate;
      }
      if (contractData[0].contractRevisedDate) {
        compensationObj.contractRevisedDate = this.formatDate(contractData[0].contractRevisedDate);
      } else {
        compensationObj.contractRevisedDate = contractData[0].contractRevisedDate;
      }
      compensationObj.contractSentDate = contractData[0].contractSentDate;
      if (contractData[0].contractSentDate) {
        compensationObj.contractSentDate = this.formatDate(contractData[0].contractSentDate);
      } else {
        compensationObj.contractSentDate = contractData[0].contractSentDate;
      }
      compensationObj.contractText = contractData[0].contractText;
      compensationObj.periodId = contractData[0].periodId;
      compensationObj.id = contractData[0].id;
      compensationObj.totalAmount = contractData[0].totalAmount;
      compensationObj.operationsSet = [];
      compensationObj.conditionsSet = [];

      if (contractData[0].periodId) {
        compensationObj.periodId = contractData[0].periodId.id;
      }
      if (contractData[0].startDateQualifierId) {
        compensationObj.startDateQualifierLookup = contractData[0].startDateQualifierId.data;
      }
      if (contractData[0].interval) {
        compensationObj.interval = contractData[0].interval.id;
      }
      if (contractData[0].postFreeInterval) {
        compensationObj.postFreeInterval = contractData[0].postFreeInterval.id;
      }
      if (contractData[0].principalFreeInterval) {
        compensationObj.principalFreeInterval = contractData[0].principalFreeInterval.id;
      }
    }
    return this.http.post('api/deals/' + dealID + '/contracts/' + lookupId, compensationObj, { responseType: 'arraybuffer' });
  }

}


