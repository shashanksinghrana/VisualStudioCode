import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CompensationModel } from '../../../models/deal/compensation.model';


/**
 * The Compesation get, save,edit Service
 *
 * Gets all of the data related to Creating/Editing compensation, and handles logic as needed.
 */
@Injectable()
export class CompensationService {

  /**
   * Constructor for the  class
   *
   * @param http The HttpClient service.
   */
  constructor(private http: HttpClient) { }

  /**
   * Gets an existing project to be loaded into form for editing.
   *
   * @param id The id of the deal-compensation to get.
   */
  public getCompensationDetails(id : number) {

    // return this.http.get('./api/getCompensation/' + id)
    //   .map((res: any) => {
    //     if (res._embedded) {
    //       res = res._embedded;
    //     } else {
    //       res = [];
    //     }
    //     return res;
    //   });

    return {
      dealId: 121,
        guaranteeNumber: 12,
        guaranteeType: "gtype",
        feeTypeId: 22,
        rate: "rate",
        descript: "",
        startDate: null,
        periodId: null,
        interval: null,
        contractReturnedDate: null,
        contractRevisiedDate: null,
        contractSentDate: null,
        contractText: "test",
        contractInfo: "test",
        totalAmount: 1312,
        voidFlag: null,
        principalFree: null,
        principalFreeInterval: null,
        postFree: null,
        postFreeInterval: null,
        adjustmentInterval: null,
        startDateQualifierId: null,
        id: 33
    };
  }

  /**
   * Saves the compensation record.
   *
   * @param compensation The compensation data to be saved.
   */
  public saveCompensation(compensation: CompensationModel) {
    // return this.http.post('http://dev.concept2alize.com/fc/dev1/fc/api/project', compensation)
    return this.http.post('./api/project', compensation)
      .map((res: any) => res);
  }

  /**
   * Updates the compensartion records.
   *
   * @param compensation The compensation record to be updated.
   */
  public updateCompensation(compensation: CompensationModel) {
    // return this.http.put('http://dev.concept2alize.com/fc/dev1/fc/api/project', compensation)
    return this.http.put('./api/project', compensation)
      .map((res: any) => res);
  }

  public getContractRiderDropdown() {
    return [
      {
        value: 'Loanout of a Day Performer',
        route: '',
        id: 1,
        data: null
      },
      {
        value: 'Employment of a Day Performer',
        route: '',
        id: 2,
        data: null
      },
      {
        value: 'Minimum Freelance Contract',
        route: '',
        id: 3,
        data: null
      },
      {
        value: 'Minimum Freeance Loanout Contract',
        route: '',
        id: 4,
        data: null
      },
      {
        value: 'Non-Union Day Performer Agreement (Straight Hire)',
        route: '',
        id: 5,
        data: null
      },
      {
        value: 'Non-Union Day Performer Agreement (Loanout)',
        route: '',
        id: 6,
        data: null
      },
      {
        value: 'Parental Agreement (Loanout – CA – 2 Parents)',
        route: '',
        id: 7,
        data: null
      },
      {
        value: 'Parental Agreement (Loanout – CA – 1 Parent)',
        route: '',
        id: 8,
        data: null
      },
      {
        value: 'Parental Agreement (Loanout – Non-CA – 2 Parents)',
        route: '',
        id: 9,
        data: null
      },
      {
        value: 'Parental Agreement (Loanout – Non-CA – 1 Parent)',
        route: '',
        id: 10,
        data: null
      },
      {
        value: 'Parental Agreement (Individual – CA – 2 Parents)',
        route: '',
        id: 11,
        data: null
      },
      {
        value: 'Parental Agreement (Individual – CA – 1 Parent)',
        route: '',
        id: 12,
        data: null
      },
      {
        value: 'Parental Agreement (Individual – Non-CA – 2 Parents)',
        route: '',
        id: 13,
        data: null
      },
      {
        value: 'Parental Agreement (Individual – Non-CA – 1 Parent)',
        route: '',
        id: 14,
        data: null
      },
      {
        value: 'TBD',
        route: '',
        id: 15,
        data: null
      },
    ]
  }
}
