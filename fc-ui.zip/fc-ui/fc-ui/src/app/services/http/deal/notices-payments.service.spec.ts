import { TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SharedService } from '../shared/shared.service';
import { UrlResolverService } from 'c2c-common-lib';
import { NoticesPaymentsService } from './notices-payments.service';

describe('NoticesPaymentsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule, HttpClientTestingModule ],
      providers: [SharedService, NoticesPaymentsService, UrlResolverService]
    });
  });

  it('should be created', inject([NoticesPaymentsService], (service: NoticesPaymentsService) => {
    expect(service).toBeTruthy();
  }));

  it(`should issue a notices-payments data request`,
  inject([HttpTestingController, NoticesPaymentsService, UrlResolverService], 
    (httpMock: HttpTestingController, service: NoticesPaymentsService, urlService: UrlResolverService) => {
     const id = 1;
     const mockResponse = {"dealId":251,"representators":[{"dealId":251,"repName":"Peter Adamsson, Partner","repType":"Attorney","companyName":"South Side Taco Productions","address":null,"contactInfo":[],"contractAddress":true,"primaryRep":false,"phoneOnContract":false,"details":{"representationId":365,"dealId":251,"repId":3486855,"typeId":8,"compId":3487005,"primaryRep":false,"useForContractAdd":false,"directContactId":null,"repCompRelId":null}},{"dealId":251,"repName":"Nick Styne","repType":"Agent","companyName":"Creative Artists Agency (CAA LA)","address":null,"contactInfo":[],"contractAddress":false,"primaryRep":true,"phoneOnContract":false,"details":{"representationId":366,"dealId":251,"repId":3486764,"typeId":7,"compId":3486885,"primaryRep":false,"useForContractAdd":false,"directContactId":null,"repCompRelId":null}},{"dealId":251,"repName":"Tom Hansen","repType":"Deal Direct","companyName":"Grundstenen AB aka Yellow Bird US Rights AB","address":null,"contactInfo":[],"contractAddress":false,"primaryRep":true,"phoneOnContract":false,"details":{"representationId":367,"dealId":251,"repId":3486858,"typeId":404,"compId":3486967,"primaryRep":false,"useForContractAdd":false,"directContactId":null,"repCompRelId":null}}],"directContact":{"dealId":251,"repName":null,"repType":null,"companyName":null,"address":[],"contactInfo":[],"contractAddress":false,"primaryRep":false,"phoneOnContract":false,"details":{"representationId":null,"dealId":251,"repId":null,"typeId":null,"compId":null,"primaryRep":false,"useForContractAdd":false,"directContactId":3486660,"repCompRelId":null}}};

     service.getNoticesPayments(id).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const req = httpMock.expectOne(urlService.getServiceEndpointUrl('api/rep/' + id));
    expect(req.request.method).toEqual('GET');

    req.flush(mockResponse);
  })
  );

  afterEach(inject([HttpTestingController], (httpMock: HttpTestingController) => {
    httpMock.verify();
  }));

  it(`should issue a rep types data request`,
  inject([HttpTestingController, NoticesPaymentsService, UrlResolverService], 
    (httpMock: HttpTestingController, service: NoticesPaymentsService, urlService: UrlResolverService) => {
     const id = 1;
     const repId = 2;
     const mockResponse = {"dealId":null,"repName":"Adam Levine","repType":"Deal Direct","companyName":"Verve","detail":{"representationId":null,"dealId":251,"repId":3486786,"typeId":404,"compId":3486942,"primaryRep":false,"useForContractAdd":false,"directContactId":null,"repCompRelId":1094207}};

    service.getRepType(repId, id).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const getRepTypeReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/deal/' + id +'/rep/'+repId));
    expect(getRepTypeReq.request.method).toEqual('GET');

    getRepTypeReq.flush(mockResponse);
  })
  );

  it(`should issue a delete rep request`,
  inject([HttpTestingController, NoticesPaymentsService, UrlResolverService], 
    (httpMock: HttpTestingController, service: NoticesPaymentsService, urlService: UrlResolverService) => {
     const id = 1;
     const repId = 2;
  
    service.deleteRepresentative(id, repId).subscribe(data => {
      expect(data).toBeNull();
    });
   
    const delRepTypeReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/deal/'+id+'/rep/'+repId));
    expect(delRepTypeReq.request.method).toEqual('DELETE');
  })
  );

  it(`should issue add rep put request`,
  inject([HttpTestingController, NoticesPaymentsService, UrlResolverService], 
    (httpMock: HttpTestingController, service: NoticesPaymentsService, urlService: UrlResolverService) => {
     const rep = {"dealId":996,"primaryRep":false,"representationId":null,"repId":3486769,"typeId":7,"compId":3486878,"useForContractAdd":true,"directContactId":null,"repCompRelId":1094075,"links":[]};
     const mockResponse = {"dealId":996,"primaryRep":false,"repName":"Norman Kurland","repType":"Agent","companyName":"Broder, Webb, Chervin, Silbermann Agency","address":null,"contactInfo":[],"contractAddress":false,"phoneOnContract":false,"details":{"representationId":null,"dealId":996,"repId":3486769,"typeId":7,"compId":3486878,"primaryRep":false,"useForContractAdd":false,"directContactId":null,"repCompRelId":null}};

    service.addRepresentative(rep).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const addRepeq = httpMock.expectOne((request: HttpRequest<any>) => {
      return request.method == 'PUT'
        && request.url == urlService.getServiceEndpointUrl('api/rep/add/')
        && JSON.stringify(request.body) == JSON.stringify(rep)
    });
    
    addRepeq.flush(mockResponse);
  })
  );

  it(`should issue submit notices-payments request`,
  inject([HttpTestingController, NoticesPaymentsService, UrlResolverService], 
    (httpMock: HttpTestingController, service: NoticesPaymentsService, urlService: UrlResolverService) => {
     const id = 1;
     const rep = [{"representationId":367,"dealId":251,"repId":3486858,"typeId":404,"compId":3486967,"primaryRep":true,"useForContractAdd":false,"directContactId":null,"repCompRelId":null}];
     const mockResponse = [{"representationId":367,"dealId":251,"repId":3486858,"typeId":404,"compId":3486967,"primaryRep":true,"useForContractAdd":false,"directContactId":null,"repCompRelId":null,"links":[]}];

    service.saveNoticesAndPayments(rep, id).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const addRepeq = httpMock.expectOne((request: HttpRequest<any>) => {
      return request.method == 'PUT'
        && request.url == urlService.getServiceEndpointUrl('api/deal/' + id +'/reps/')
        && JSON.stringify(request.body) == JSON.stringify(rep)
    });
    
    addRepeq.flush(mockResponse);
  })
  );
  
});
