import { UserPermissionService } from '../../permission/user-permission.service';
import { CurrentUserService } from '../../users/current-user.service';
import { Injectable, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { UrlResolverService, TypeAheadModel, GlobalSearchModel, ITalentEvents, AccentedCharsModel } from 'c2c-common-lib';
import { Observable } from 'rxjs/Observable';
import { UtilsService } from '../../../../utils/utils.service';
import {  TabsModel } from '../../../../models/talent-detail/tabs.model';
import { CurrentUserPersistService } from '../../../persist/user/current-user-persist.service';

@Injectable() export class CommonModuleService implements ITalentEvents {

    private personData: any;
    private companyData: any;
    private routeParams: any;
    private closeModalEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private router: Router, private httpClient: HttpClient, private urlResolverService: UrlResolverService,
        private userService: CurrentUserService, private permissionService: UserPermissionService,
        private utilService: UtilsService, private currentUser: CurrentUserPersistService) { }

    public addPersontoRollCallfromTalent(repData: any): Observable<any> {
            const url = this.urlResolverService.getServiceEndpointUrl('/api/persons');
            return this.httpClient.post(url, repData)
                .map((res) => {
                    return res;
                });
    }

    public addRepresentativeToRollCall(repData: any): Observable<any> {
            const url = this.urlResolverService.getServiceEndpointUrl('/rollcall/addPerson');
            return this.httpClient.post(url, repData)
                .map((res) => {
                    return res;
                });
    }

    public deleteRelation(relationData: any): Observable<ArrayBuffer> {
            const url = this.urlResolverService.getServiceEndpointUrl('/api/party/relation');
            return this.httpClient.delete(url, relationData)
                .map((res) => {
                    return res as ArrayBuffer;
                });
    }

    public getCompany(searchTerm: string, noOfRecordsToBeReturned: string, filterType: string): Observable<TypeAheadModel[]> {

            let params = new HttpParams();
            params = params.append('searchTerm', searchTerm);
            params = params.append('recordCount', noOfRecordsToBeReturned);
            const url = this.urlResolverService.getServiceEndpointUrl('/api/typeAhead/performers?filterType=' + filterType);

            return this.httpClient.get<TypeAheadModel[]>(url, { params: params })
                .map((res: TypeAheadModel[]) => this.mapData(res));
    }

    public getCompanyData(): any {
        if (this.companyData) {
            const length = Object.keys(this.companyData.locations).length;
            if (length === 1 && JSON.stringify(this.companyData.locations).length === 4) {
                this.companyData.locations = [];
            }
            return this.companyData;
        }
        return null;
    }

    public getCompanyDetails(companyId: string, showSpinner?: boolean): Observable<any> {
        let headers = new HttpHeaders();
        // This method spinner skip through loading interceptor so active for particular case
        if (showSpinner) {
            headers = headers.set('skipLoading', 'false');
        }
        const url = this.urlResolverService.getServiceEndpointUrl('/api/companies/' + companyId);
        return this.httpClient.get(url, { headers: headers})
            .map((res) => {
                this.setCompanyData(res);
                return res;
            });
    }

    public getCompanyDetailsFromDb(companyPartyId): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/rollcall/company/') + companyPartyId + '/locations/';
        return this.httpClient.get(url)
            .map((res: any) => res);
    }

    public getContactOnly(searchTerm: string, noOfRecordsToBeReturned: string, filterType: string): Observable<TypeAheadModel[]> {

        let params = new HttpParams();
        params = params.append('searchTerm', searchTerm);
        params = params.append('recordCount', noOfRecordsToBeReturned);
        const url = this.urlResolverService.getServiceEndpointUrl('/api/typeAhead/performers?filterType=' + filterType);
        return this.httpClient.get<TypeAheadModel[]>(url, { params: params })
            .map((res: TypeAheadModel[]) => this.mapData(res));
    }

    public getCountries(): Observable<any> {
            let params = new HttpParams();
            params = params.append('studioId', '3911');
            const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/COUNTRIES');
            return this.httpClient.get(url, { params: params })
                .map((res) => {
                    return res;
                });
    }

    public getCountryOptionsList(type): any {
        return this.utilService.getCountryOptionsList(type);
    }

    public getDropDownOptionsData(type: string): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/common/picklist/' + type);
        return this.httpClient.get(url).map((res) => {
            return res;
        });
    }

    public getDropDownOptionsList(type): any {
        return this.utilService.getDropDownOptionsList(type);
    }

    public getGenders(): Observable<any> {
            let params = new HttpParams();
            params = params.append('studioId', '3911');
            const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/GENDER');
            return this.httpClient.get(url, { params: params })
                .map((res) => {
                    return res;
                });
    }

    public getGenre(): Observable<any> {
        let params = new HttpParams();
        params = params.append('studioId', '3911');
        const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/GENRE');
        return this.httpClient.get(url, { params: params })
            .map((res) => {
                return res;
            });
    }

    private getHeaders(): HttpHeaders {
        let headers: HttpHeaders = new HttpHeaders();
        headers = headers.append('Accept', 'application/json');
        headers = headers.append('Content-Type', 'application/json');
        headers = headers.append('Access-Control-Allow-Origin', '*');
        headers = headers.append('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS');
        headers = headers.append('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Auth-Token');
        return headers;
    }

    public getImmigrationStatus(): Observable<any> {
        let params = new HttpParams();
        params = params.append('studioId', '3911');
        const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/IMMIGRATION_STATUS');
        return this.httpClient.get(url, { params: params })
            .map((res) => {
                return res;
            });
    }

    public getMetaDataFields(context: string): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/typeahead/' + context );
        return this.httpClient.get<any>(url).map((res) => res);
    }

    public getNames(partyId: number): Observable<TypeAheadModel[]> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/party/' + partyId + '/names');
        return this.httpClient.get<TypeAheadModel[]>(url)
            .map((res) => res);
    }

    public getOccupation(): Observable<any> {
        let params = new HttpParams();
        params = params.append('studioId', '3911');
        const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/STAFF_LEVEL');
        return this.httpClient.get(url, { params: params })
            .map((res) => {
                return res;
            });
    }

    public getOptionsList(type): any {
        return this.utilService.getOptionsList(type);
    }

    public getPartyDetails(partyId: number): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/party/' + partyId);
        return this.httpClient.get(url)
            .map((res) => res);
    }

    public getPersonData() {
        return this.personData;
    }

    public getPersonDetail(partyId: number): Observable<any> {
        const url: string = this.urlResolverService.getServiceEndpointUrl('/api/persons/' + partyId);
        return this.httpClient.get(url)
            .map((res) => res);
    }

    public getRaces(): Observable<any> {
        let params = new HttpParams();
        params = params.append('studioId', '3911');
        const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/RACE');
        return this.httpClient.get(url, { params: params })
            .map((res) => {
                return res;
            });
    }

    public getRepDetails(repId: number | string): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/persons/' + repId);
        return this.httpClient.get(url)
            .map((response) => {
                this.personData = response;
                return response;
            });
    }

    public getRepPhoneType(): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/rollcall/picklist/PHONE_TYPE');
        return this.httpClient.get(url)
            .map((res) => {
                return res;
            });
    }

    public getRepType(): Observable<any> {
        let params = new HttpParams();
        params = params.append('studioId', '3911');
        const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/REP_TYPE');
        return this.httpClient.get(url, { params: params })
            .map((res) => {
                return res;
            });
    }

    public getRollCallPersonDetail(talentId: number): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/talents/' + talentId + '/contact-companies');

        return this.httpClient.get(url)
            .map((res) => res);
    }

    public getRoutesParams(): any {
        return this.routeParams;
    }

    public getStateListFromDb(countryID: string): Observable<any> {
        return this.httpClient.get(this.urlResolverService.getServiceEndpointUrl('/api/rollcall/picklist/countrystate/STATES/') + countryID)
            .map((res: any) => res);
    }

    public getStates(): Observable<any> {
        let params = new HttpParams();
        params = params.append('studioId', '3911');
        const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/STATES');
        return this.httpClient.get(url, { params: params })
            .map((res) => {
                return res;
            });
    }

    public getStatus(): Observable<any> {
        let params = new HttpParams();
        params = params.append('studioId', '3911');
        const url = this.urlResolverService.getServiceEndpointUrl('/api/picklist/TALENT_STATUS');
        return this.httpClient.get(url, { params: params })
            .map((res) => {
                return res;
            });
    }

    /**
     * Gets each tab item and route to use for tabular navigation.
     */
    public getSubTabItems(): Array<TabsModel> {
        return [
            { label: 'Submissions', route: 'submission' },
            { label: 'Projects', route: 'projects' },
            { label: 'Deals', route: 'deals' },
            { label: 'Casting', route: 'casting' },
            { label: 'Timeline', route: 'timeline' },
            { label: 'Tracking', route: 'trackingtab' },
            { label: 'Lists', route: 'lists' }
        ];
    }

    public getTabItems(): Array<Object> {
        return [
            { label: 'Personal', route: 'personal' },
            { label: 'Representation', route: 'representation' },
            { label: 'Contact', route: 'contact' },
            { label: 'Team', route: 'Team' }
        ];
    }

    public getTalentByID(talentId: number): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/talents/' + talentId);
        return this.httpClient.get(url)
            .map((res) => res);
    }

    public getTalentDetails(talentId: number): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/talents/' + talentId);
        return this.httpClient.get(url)
            .map((res) => {
                return res;
            });
    }

        /**
   * Records returned for typeahead search
   * @param textToBeSearched : search term
   * @param userRole : type of user
   * @param searchDataMethodology : CONTAINS or STARTS_WITH
   * @param noOfRecordsToBeReturned
   */
  public getTalentOnly(searchTerm: string, noOfRecordsToBeReturned: string, filterType: string): Observable<TypeAheadModel[]> {
    if (searchTerm.length === 1) {
        if (searchTerm === '+') {
            searchTerm = searchTerm.replace(searchTerm, '%2B');
        } else if (searchTerm === ',') {
            searchTerm = searchTerm.replace(searchTerm, '%2C');
        }
    }

    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', noOfRecordsToBeReturned);
    const url = this.urlResolverService.getServiceEndpointUrl('/api/typeAhead/performers?filterType=' + filterType);
    return this.httpClient.get<TypeAheadModel[]>(url, { params: params })
        .map((res: TypeAheadModel[]) => this.mapData(res));
}

public getUserData(): any {
    return this.userService.user;
}

public getValidations(talentData: any): Observable<any> {
        const headers: HttpHeaders = this.getHeaders();
        const url = this.urlResolverService.getServiceEndpointUrl('/api/talents/validate');
        return this.httpClient.post(url, talentData, { headers: headers })
            .map((res) => {
                return res;
            });
}

public globalSearch(textToBeSearched: string, noOfRecordsToBeReturned: string, filterType?: string): Observable<GlobalSearchModel> {
        if (textToBeSearched.length === 1) {
            if (textToBeSearched === '+') {
                textToBeSearched = textToBeSearched.replace(textToBeSearched, '%2B');
            } else if (textToBeSearched === ',') {
                textToBeSearched = textToBeSearched.replace(textToBeSearched, '%2C');
            }
        }

        let params = new HttpParams();
        params = params.append('noOfRecordsToBeReturned', noOfRecordsToBeReturned);

        const url = this.urlResolverService.getServiceEndpointUrl('/api/global-search?textToBeSearched=' + textToBeSearched);
        return this.httpClient.get<any>(url, { params: params })
            .map((res: GlobalSearchModel) => res);
    }

    public hasPermission(key): boolean {
        // TODO ONCE PERMISSION DONE THIS HARDCODED SHOULD REMOVE
        if (key === 'Talent.CreateEdit.Teams.VIEW' || key === 'Talent.CreateEdit.Teams.UPDATE') {
            return false;
        } else if (key === 'Talent.PII') {
            return true;
        } else {
            return true;
        }
        // return this.permissionService.hasPermission(key);
    }

    public insertUpdateCompanyDetails(data: any): Observable<any> {
        const headers: HttpHeaders = this.getHeaders();
        const companyJson = JSON.stringify(data);
        const url = this.urlResolverService.getServiceEndpointUrl('/api/rollcall/addCompany');
        return this.httpClient.post(url, companyJson, { headers: headers }).map((res: any) => res);
    }

    public insertUpdatePeopleDetails(data: any): Observable<any> {
        const headers: HttpHeaders = this.getHeaders();
        const url = this.urlResolverService.getServiceEndpointUrl('/api/contactable-persons');
        return this.httpClient.post(url, data, { headers: headers })
            .map((res: any) => {
                return res;
            });
    }

    private mapData(res: TypeAheadModel[]): Array<TypeAheadModel> {
        let nta: Array<TypeAheadModel> = [];
        nta = res;
        return nta;
    }

    public navigatePage(path: string): void {
        this.router.navigateByUrl(path);
    }

    public save(tName: string): Observable<any> {
        const headers: HttpHeaders = this.getHeaders();
        const url = this.urlResolverService.getServiceEndpointUrl('/api/addParty');
        return this.httpClient.post(url, tName, { headers: headers })
            .map((res) => {
                return res;
            });
    }

    public saveAlias(partyContract: any): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/addAlias');
        const headers: HttpHeaders = this.getHeaders();
        return this.httpClient.post(url, partyContract, { headers: headers })
            .map((res) => {
                return res;
            });
    }


    public saveContact(saveContact): Observable<any> {

        const url = this.urlResolverService.getServiceEndpointUrl('/api/rollcall/addPerson');
        return this.httpClient.post(url, saveContact)
            .map((res) => {
                return res;
            });
    }

    public saveLocationCompanies(companyData: any, companyId: any): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/rollcall/company/' + companyId + '/addLocation');
        return this.httpClient.post(url, companyData)
            .map((res) => {
                return res;
            });
    }

    public saveParty(tName: any): Observable<any> {
        const user: any = this.getUserData();
        const data = JSON.parse(tName);
        data.createdByApp = 'Talent2';
        data.updatedByApp = 'Talent2';
        data.dataSetId = user.masterDataset;
        const headers: HttpHeaders = this.getHeaders();
        const url = this.urlResolverService.getServiceEndpointUrl('/api/addParty');

        return this.httpClient.post(url, data, { headers: headers })
            .map((res) => {
                return res;
            });
    }

    public saveRelation(relationData: any): Observable<any> {
        const url = this.urlResolverService.getServiceEndpointUrl('/api/party/relation');
        return this.httpClient.post(url, relationData)
            .map((res) => {
                return res;
            });
    }


    public saveTalent(talentData: any): Observable<any> {
        const headers: HttpHeaders = this.getHeaders();
        const url = this.urlResolverService.getServiceEndpointUrl('/api/talents');
        return this.httpClient.put(url, talentData, { headers: headers })
            .map((res) => {
                return res;
            });
    }

    public setCompanyData(companyData): void {
        this.companyData = companyData;
    }

    public setRoutesParams(params): any {
        return this.routeParams = params;
    }

    public getCloseModalEvent(): EventEmitter<any> {
        return this.closeModalEvent;
      }

    public closeModal(response?: any): void {
      this.closeModalEvent.emit({close: true, status: response.status, data: response.data});
    }

    public getStudioID() {
        return this.currentUser.getCurrentUser().studioId;
    }

}
