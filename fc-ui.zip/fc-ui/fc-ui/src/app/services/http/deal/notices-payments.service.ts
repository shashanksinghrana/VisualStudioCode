import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { SharedService } from '../shared/shared.service';
import { UrlResolverService } from 'c2c-common-lib';


/**
 * The Compesation get, save,edit Service
 *
 * Gets all of the data related to Creating/Editing Name Project Details, and handles logic as needed.
 */
@Injectable()
export class NoticesPaymentsService {

  /**
   * Constructor for the  class
   *
   * @param http The HttpClient service.
   */
  constructor(private http: HttpClient,
    private sharedService : SharedService,
    private urlResolverService: UrlResolverService ) { }

  /**
   * THis method will add rep
   * @param rep the rep form data.
   */
  public addRepresentative(rep: any) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/rep/add/'), rep)
      .map((res: any) => res);
  }

  /**
   * THis method will delete rep
   * @param rep the rep form data.
   */
  public deleteRepresentative(dealId, repId) {
    return this.http.delete(this.urlResolverService.getServiceEndpointUrl('api/deal/'+dealId+'/rep/'+repId))
      .map((res: any) => res);
  }


   /**
   * THis method will fetch Notices and Payments details.
   * @param id deal id.
   */
  public getNoticesPayments(id) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/rep/' + id))
      .map((res: any) => {
        return res;
      });
  }

   /**
   * THis method will fetch Rep Type for selected Rep Name in Notices and Payments details.
   * * @param repId Rep Id.
   * @param id deal id.
   */
  public getRepType(repId, id) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/deal/' + id +'/rep/'+repId))
      .map((res: any) => {
        // return this.getDummyDataForRepType();
        return res;
      });
  }

  private getDummyDataForRepType(){
    return {
      "dealId": 1,
      "repName": "ABC",
      "repType": "Prod. Entity",
      "companyName": "Agency for the Performing Arts (APA LA)",
      "detail": {
        "representationId": null,
        "dealId": 1,
        "repId": 3486721,
        "typeId": 10,
        "compId": 3486873,
        "primaryRep": false,
        "directContactId": null,
        "repCompRelId": null
      }
    }
  }

  /**
   * THis method will save notices and payments data
   * @param rep the rep form data.
   */
  public saveNoticesAndPayments(rep: any, dealId) {
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/deal/' + dealId +'/reps/'), rep)
      .map((res: any) => res);
  }

   /**
   * THis method will get notices and payments data after editing the details
   * @param repId repId
   */
  public getRepDetailsAfterEdit(repId, type) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/reps/'+repId+'/details/?type='+type))
      .map((res: any) => {
        return res;
      });
    }
    
}
