import { TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { PerqsService } from './perqs.service';
import { UrlResolverService } from 'c2c-common-lib';

describe('PerqsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule, HttpClientTestingModule ],
      providers: [PerqsService, UrlResolverService]
    });
  });

  afterEach(inject([HttpTestingController], (httpMock: HttpTestingController) => {
    httpMock.verify();
  }));

  it('perqs service should be created', inject([PerqsService], (service: PerqsService) => {
    expect(service).toBeTruthy();
  }));

  it(`should get perqs request`,
  inject([HttpTestingController, PerqsService, UrlResolverService], 
    (httpMock: HttpTestingController, service: PerqsService, urlService: UrlResolverService) => {
     const id = 251;
     const mockResponse =  {"_embedded": {"perqs":[{"dealId":441,"perqText":"Dummy Perqs Text","printRiderInd": false,"paidAdInd": null,"perqTypeLookup": {"name": "Compensation","type": "PERQS","displayOrder": 1,"id":222},"id": 2}]}};

    service.getPerqs(id).subscribe(data => {
      expect(data);
      //.toEqual(mockResponse);
    });
   
    const getPerqsRecord = httpMock.expectOne(urlService.getServiceEndpointUrl('api/perqs/' + id));
    expect(getPerqsRecord.request.method).toEqual('GET');

    getPerqsRecord.flush(mockResponse);
  })
  );

  it(`should submit perqs request`,
  inject([HttpTestingController, PerqsService, UrlResolverService], 
    (httpMock: HttpTestingController, service: PerqsService, urlService: UrlResolverService) => {
     const perqs = {"perqs": [{"dealId": 441,"perqText": "Dummy Perqs Text","printRiderInd": false,"paidAdInd": null,"perqTypeLookup": {"name": "Compensation","type": "PERQS","displayOrder": 1,"id":222},"id": 2}]};

     const mockResponse = [{"perqs": [{"dealId": 441,"perqText": "Dummy Perqs Text","printRiderInd": false,"paidAdInd": null,"perqTypeLookup": {"name": "Compensation","type": "PERQS","displayOrder": 1,"id":222},"id": 2}]}];
     const id = 251;
    service.savePerqsRecord(perqs,id).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
    const savePerqs = httpMock.expectOne((request: HttpRequest<any>) => {
      return request.method == 'PUT'
        && request.url == urlService.getServiceEndpointUrl('api/perqs/'+id)
        && JSON.stringify(request.body) == JSON.stringify(perqs)
    });
    savePerqs.flush(mockResponse);
  })
  );
});
