import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { UrlResolverService, ColumnDefModel, GridTitlesDefModel, GridTitlesParamsModel,
         GridLinkParamsModel, GridListDefModel, GridListParamsModel, GridPageOptionsModel } from 'c2c-common-lib';

/**
 * The AllProjectsService
 *
 * Gets all of the data related to All Projects, and handles logic as needed.
 */
@Injectable()
export class AllProjectsService {

  /**
   * Constructor for the AllProjectsService
   *
   * @param http The HttpClient service.
   */
  constructor(private http: HttpClient, private urlResolverService: UrlResolverService) { }

  /**
   * Defines all of Column Definitions used in the All Projects Grid.
   */
  public createColumnDefs(): ColumnDefModel[] {
    return [
      new GridTitlesDefModel('Title', 'title',
        new GridTitlesParamsModel({ keys: ['title'], routing: new GridLinkParamsModel('/projectDetails', 'id') }, 'akaNames')
      ),
      new GridListDefModel('Performer', 'performerName',
        new GridListParamsModel({
          iterable: 'deals',
          keys: ['performer.firstName', 'performer.lastName'],
          routing: new GridLinkParamsModel('/createDeal', 'id', 'summary')
        }, true, false, 'performer.agencyList', 'performer.lastName'),
      ),
      new GridListDefModel('Role', 'role',
        new GridListParamsModel({
          iterable: 'deals',
          keys: ['performerRole']
        }, false, false, 'performer.agencyList', 'performerRole')
      ),
      new GridListDefModel('Agency', 'agency',
        new GridListParamsModel({
          iterable: 'deals',
          keys: ['performer.agencyList']
        }, false, true, null, 'performer.agencyList')
      ),
      new GridListDefModel('Union', 'union',
        new GridListParamsModel({
          iterable: 'deals',
          keys: ['unionLookup.name']
        }, false, false, 'performer.agencyList', 'unionLookup.name')
      ),
      new ColumnDefModel('SAP/GL Code', 'sapCode', null,
        {
          comparator: { name: 'numberComparator' }
        }
      )
    ];
  }

  /**
   * Gets all projects data for displaying in the Grid.
   */
  public getAllProjects(params?: HttpParams) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/allProjects'), {params: params})
      .map((res: any) => {
        const pagination = res.page;
        let projects = [];

        if (res._embedded) {
          projects = res._embedded.projects;
        }
        return {pagination, projects};
      });
  }

  /**
   * Gets all projects data for displaying in the Grid.
   */
  public getMyProjects(params?: HttpParams) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/myProjects'), {params: params})
      .map((res: any) => {
        const pagination = res.page;
        let projects = [];

        if (res._embedded) {
          projects = res._embedded.projects;
        }
        return {pagination, projects};
      });
  }

  /**
   * Gets/defines all the page options for customizing the All Projects Grid.
   */
  public getPageOptions(viewButton?:any) {
    return new GridPageOptionsModel(true, '', true, false, false, false, viewButton);
  }
}
