import { TestBed, inject } from '@angular/core/testing';

import { AllProjectsService } from './all-projects.service';

describe('AllProjectsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AllProjectsService]
    });
  });

  it('should be created', inject([AllProjectsService], (service: AllProjectsService) => {
    expect(service).toBeTruthy();
  }));
});
