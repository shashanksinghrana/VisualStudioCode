import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable'

@Injectable()
export class UserPermissionService {
  private _permissionList = new BehaviorSubject([]);
  public permissionList = [];

  constructor() { }

  public getUserPermission(): Observable<any> {
    return this._permissionList;
  }

  public setPermissions = (response) => {
    if (response) {
      let tempArray = response.authorities
      tempArray.forEach(element => {
        this.permissionList.push(element)
      });
      this._permissionList.next(this.permissionList);
    }
  }

  getPermissions() {
    if (this.permissionList.length !== 0) {
      return this.permissionList
    }
  }

  public hasPermission = (permissionName) => {
    let permission = false;
    let permissionList = this.getPermissions();
    if (permissionList) {
      for (let i = 0; i < permissionList.length; i++) {
        if (permissionList[i].authority.indexOf(permissionName) > -1) {
          permission = true;
        }
      }
    }
    return permission;
  }

}

