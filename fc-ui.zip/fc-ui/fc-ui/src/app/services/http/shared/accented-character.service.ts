import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { UrlResolverService, AccentedCharsModel } from 'c2c-common-lib';


@Injectable()
export class AccentedCharacterService {

  constructor(private httpClient: HttpClient,
              private urlResolverService: UrlResolverService) { }

  /**
   * @param val the character in the type ahead behind the cursor that can be searched
   * @return array of foreign characters that will match the english character
   */
  public getAccentedChars(val: string): Observable<AccentedCharsModel[]> {
    val = val.toLowerCase();
    let params = new HttpParams();
        params = params.append('char', val);

    const url = this.urlResolverService.getServiceEndpointUrl('/api/accents/chars');

    return this.httpClient.get<AccentedCharsModel[]>(url, {params: params})
    .map((res: AccentedCharsModel[]) => this.mapData(res));
  }

  /**
     * Convert returned response data
     * @param res
     */
  private mapData(res: AccentedCharsModel[]): Array<AccentedCharsModel> {
    const nta = [];
    let obj = {};
    for (const o in res['type']) {
      if (o) {
        obj = new AccentedCharsModel(res['type'][o]);
        obj['heading'] = o;
        nta.push(obj);
        obj = {};
      }
    }
    return nta;
  }
}
