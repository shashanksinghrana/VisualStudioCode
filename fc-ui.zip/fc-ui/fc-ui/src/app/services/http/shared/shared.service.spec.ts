import { TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { UrlResolverService } from 'c2c-common-lib';
import { SharedService } from './shared.service';

describe('SharedService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule, HttpClientTestingModule ],
      providers: [SharedService, UrlResolverService]
    });
  });

  it('should be created', inject([SharedService], (service: SharedService) => {
    expect(service).toBeTruthy();
  }));

  afterEach(inject([HttpTestingController], (httpMock: HttpTestingController) => {
    httpMock.verify();
  }));

  // it(`should issue a get rep types dropdown data request`,
  // inject([HttpTestingController, SharedService, UrlResolverService], 
  //   (httpMock: HttpTestingController, service: SharedService, urlService: UrlResolverService) => {
  //    const mockResponse = {"picklists":{"CONTACT_OCCUPATION":[{"id":403,"value":"Business Rep","abbreviation":null,"sortOrder":1},{"id":9,"value":"Manager","abbreviation":null,"sortOrder":1},{"id":14,"value":"Union","abbreviation":null,"sortOrder":1},{"id":15,"value":"Producer","abbreviation":null,"sortOrder":1}]}};

  //   service.getRepTypeDropdownOptions().subscribe(data => {
  //     expect(data).toEqual(mockResponse['picklists']['CONTACT_OCCUPATION']);
  //   });
   
  //   const getRepTypeDropdownReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/rep/type'));
  //   expect(getRepTypeDropdownReq.request.method).toEqual('GET');

  //   getRepTypeDropdownReq.flush(mockResponse);
  // })
  // );

  it(`should issue a rep names data request`,
  inject([HttpTestingController, SharedService, UrlResolverService], 
    (httpMock: HttpTestingController, service: SharedService, urlService: UrlResolverService) => {
     const searchTerm = "an";
     const recordCount = "2";
     const mockResponse = [{"partyId":3486721,"partyType":"CONTACT","firstName":"Chris","entityName":"Andrews","ssnEndChars":null,"occupation":"Agent","agency":"Creative Artists Agency (CAA LA)","typeAheadDisplayName":"Chris Andrews","primaryName":null,"teamMembers":null,"akaId":141,"links":[]},{"partyId":3486740,"partyType":"CONTACT","firstName":"Annette","entityName":"Van Duren","ssnEndChars":null,"occupation":"Attorney","agency":"The Van Duren Agency","typeAheadDisplayName":"Annette Van Duren","primaryName":null,"teamMembers":null,"akaId":160,"links":[]}];

    service.getRepNamesTypeahead(searchTerm, recordCount).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const getRepNamesReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/contacts?searchTerm='+searchTerm+'&recordCount='+recordCount));
    expect(getRepNamesReq.request.method).toEqual('GET');

    getRepNamesReq.flush(mockResponse);
  })
  );

  it(`should issue company data request`,
  inject([HttpTestingController, SharedService, UrlResolverService], 
    (httpMock: HttpTestingController, service: SharedService, urlService: UrlResolverService) => {
     const searchTerm = "at";
     const recordCount = "1";
     const mockResponse = [{"partyId":3486978,"partyType":"COMPANY","firstName":null,"entityName":"Atlas Entertainment, LLC","ssnEndChars":null,"occupation":null,"agency":null,"typeAheadDisplayName":"Atlas Entertainment, LLC","primaryName":null,"teamMembers":null,"akaId":587,"links":[]}];

    service.getCompaniesTypeahead(searchTerm, recordCount).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const getCompaniesReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/companies?searchTerm='+searchTerm+'&recordCount='+recordCount));
    expect(getCompaniesReq.request.method).toEqual('GET');

    getCompaniesReq.flush(mockResponse);
  })
  );  

  it(`should issue get dropdown data request`,
  inject([HttpTestingController, SharedService, UrlResolverService], 
    (httpMock: HttpTestingController, service: SharedService, urlService: UrlResolverService) => {
     const lookup = 'MAIN_END_TITLE';
     const mockResponse = [{"name":"Main Title","type":"MAIN_END_TITLE","displayLabel":null,"displayOrder":1,"links":[{"rel":"self","href":"http://dev.concept2alize.com/fc/dev1/fc/api/lookup/181","hreflang":null,"media":null,"title":null,"type":null,"deprecation":null}],"id":181},{"name":"End Title","type":"MAIN_END_TITLE","displayLabel":null,"displayOrder":2,"links":[{"rel":"self","href":"http://dev.concept2alize.com/fc/dev1/fc/api/lookup/182","hreflang":null,"media":null,"title":null,"type":null,"deprecation":null}],"id":182},{"name":"Main Title - Guaranteed","type":"MAIN_END_TITLE","displayLabel":null,"displayOrder":3,"links":[{"rel":"self","href":"http://dev.concept2alize.com/fc/dev1/fc/api/lookup/183","hreflang":null,"media":null,"title":null,"type":null,"deprecation":null}],"id":183},{"name":"End Title - Guaranteed","type":"MAIN_END_TITLE","displayLabel":null,"displayOrder":4,"links":[{"rel":"self","href":"http://dev.concept2alize.com/fc/dev1/fc/api/lookup/184","hreflang":null,"media":null,"title":null,"type":null,"deprecation":null}],"id":184},{"name":"N/A","type":"MAIN_END_TITLE","displayLabel":null,"displayOrder":5,"links":[{"rel":"self","href":"http://dev.concept2alize.com/fc/dev1/fc/api/lookup/185","hreflang":null,"media":null,"title":null,"type":null,"deprecation":null}],"id":185}];

    service.getDropdown(lookup).subscribe(data => {
      expect(data).toEqual(mockResponse);
    });
   
    const getDropdownReq = httpMock.expectOne(urlService.getServiceEndpointUrl('api/lookup/type/'+ lookup));
    expect(getDropdownReq.request.method).toEqual('GET');

    getDropdownReq.flush(mockResponse);
  })
  );  
});
