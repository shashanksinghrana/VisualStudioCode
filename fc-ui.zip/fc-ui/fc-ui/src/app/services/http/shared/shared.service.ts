import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Http, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { UrlResolverService, TypeAheadDisplayResultModel, TypeAheadModel, AccentedCharsModel } from 'c2c-common-lib';


@Injectable()
export class SharedService {

  public dealId: number;
  public displayCompaniesData: TypeAheadDisplayResultModel = {
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: [],
      display: ''
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: [],
      PRODUCTION: [],
      CASTING: [],
      default: []
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getCompaniesTypeahead'
    }
  };

  public displayCompanyMetadataResults: TypeAheadDisplayResultModel = {
    // filterType: 'COMPANY_ONLY&context=COMPANY',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: [],
      display: '` | ${data.occupation} | ${data.companyLocations}`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'companyLocations']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getCompaniesTypeahead'
    }
  };

  public displayCompanyDataResults: TypeAheadDisplayResultModel = {
    filterType: 'COMPANY_ONLY',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'partyType'],
      display: '`(alias for ${data.primaryName})`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'companyLocations']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getPerformersCompanyTypeahead'
    }
  };

  /** New Typeahead model added for add edit performer typeahead */
  public displayDataResults: TypeAheadDisplayResultModel = {
    filterType: 'TALENT_CONTACT',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'teamMembers'],
      display: '`${data.primaryName ?` (alias for ${data.primaryName}) `:` (team of ${data.teamMembers})`}`',
      notAllColumnsRequired: true
    },
    metaDataColumns: {
      default: []
     },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getPerformersTypeahead'
    }
  };

  public displayLoanOutCompanyData: TypeAheadDisplayResultModel = {
    primaryDisplayColumn: 'name',
   filterType : '',
     secondaryDisplay: {
      secondaryColumns: [],
      display: ''
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: [],
      PRODUCTION: [],
      CASTING: [],
      default: []
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getLoanOutCompanyTypeahead'
    }
  };

  public displayPerformerData: TypeAheadDisplayResultModel = {
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['ssnEndChars'],
      display: '` | ${data.ssnEndChars}`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: [],
      PRODUCTION: [],
      CASTING: [],
      default: []
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getPerformersTypeahead'
    }
  };

  public displayProjectTitleData: TypeAheadDisplayResultModel = {
    primaryDisplayColumn: 'title',
    secondaryDisplay: {
      secondaryColumns: [],
      display: ''
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: [],
      PRODUCTION: [],
      CASTING: [],
      default: []
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getProjectTitlesTypeahead'
    }
  };

  public displayRepNamesData: TypeAheadDisplayResultModel = {
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: [],
      display: '`${data.occupation} | ${data.agency}`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: [],
      PRODUCTION: [],
      CASTING: [],
      default: ['occupation', 'agency']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getRepNamesTypeahead'
    }
  };

  public displayTalentContactResults: TypeAheadDisplayResultModel = {
    filterType: 'TALENT_CONTACT',
    primaryDisplayColumn: 'typeAheadDisplayName',
    secondaryDisplay: {
      secondaryColumns: ['primaryName', 'partyType'],
      display: '`(alias for ${data.primaryName})`'
    },
    metaDataColumns: {
      BUSINESS_CREATIVE: ['occupation', 'agency'],
      PRODUCTION: ['occupation', 'ssnEndChars'],
      CASTING: ['agency', 'ssnEndChars'],
      default: ['occupation', 'ssnEndChars']
    },
    noRecordsToReturn: '10',
    service: {
      serviceClass: this,
      get: 'getTalentContactTypeahead'
    }
  };
  /** */
  public performerPartyId: number;
  public projectDetailsStorageObject: any[] = [];


  constructor(private http: HttpClient, private urlResolverService: UrlResolverService) { }

  public getCompaniesMetadataTypeahead(searchTerm: string, returnedRecordCount: string, filterType?: string) {
    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', returnedRecordCount); // 'api/typeAhead/company' replace url
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/typeAheadNames?filterType=' + filterType), {params: params})
      .map((res: any[]) => {
        return res;
      });
  }

  public getCompaniesTypeahead(searchTerm: string, returnedRecordCount: string, filterType?: string) {
    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', returnedRecordCount); // 'api/typeAhead/company' replace url
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/companies'), {params: params})
      .map((res: any[]) => {
        return res;
      });
  }

  /**
   * Returns dropdown values.
   *
   * @param lookup The type of lookup value of the dropdown.
   */
  public getDropdown(lookup: string, skipLoading?: boolean) {
    let headers = new HttpHeaders();
    if (skipLoading) {
      headers = headers.set('skipLoading', 'true');
    }
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/lookup/type/') + lookup, { headers: headers})
      .map(data => {
        return data;
      });
  }

  public getSignatoryDropDown() {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/lookup/signatories'))
      .map(data => {
        return data;
      });
  }

  /**
   * Returns specific dropdown values.
   *
   * @param lookup The type of lookup value of the dropdown.
   */
  public getGenericLookupDropdown(lookup: string): any {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/generic/lookup/') + lookup)
    .map(data => {
      return data;
    });
  }

  public getLoanOutCompany(id: any): any {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/performers/' + id + '/loanoutCompanies'))
      .map(res => {
        if (res !== {}) {
          return res['_embedded']['loanouts'];
        } else {
          return res;
        }
      });
  }

  /**
   * Returns specific dropdown values.
   *
   * @param lookup The type of lookup value of the dropdown.
   */
  public getNonLookupDropdown(lookup: string) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/') + lookup)
    .map(data => {
      return data;
    });
  }

  public getPerformersCompanyTypeahead(searchTerm: string, recordCount: string, filterType: string): Observable<TypeAheadModel[]> {
    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', recordCount);
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/typeAhead/performers?filterType=' + filterType),
       {params: params})
      .map((res: TypeAheadModel[]) => {
        return res;
      });
  }

  public getPerformersTypeahead(searchTerm: string, recordCount: string, filterType?: string): Observable<TypeAheadModel[]> {
    if (searchTerm.length === 1) {
        if (searchTerm === '+') {
            searchTerm = searchTerm.replace(searchTerm, '%2B');
        } else if (searchTerm === ',') {
            searchTerm = searchTerm.replace(searchTerm, '%2C');
        }
    }
    let url = '/api/typeAhead/performers';
    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', recordCount);
    if (filterType !== undefined) {
      url = '/api/typeAhead/performers?filterType=' + filterType;
    }
    return this.http.get(this.urlResolverService.getServiceEndpointUrl(url),
     {params: params})
      .map((res: TypeAheadModel[]) => {
        return res;
      });
  }

  public getProjectTitlesTypeahead(searchTerm: string, returnedRecordCount: string, filterType?: string) {
    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', returnedRecordCount);
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/typeAhead/projectTitles'), {params: params})
      .map((res: any[]) => {
        if (res['_embedded']) {
          return res['_embedded']['projectTitles'];
        } else {
          return [];
        }

      });
  }

  public getRepNamesTypeahead(searchTerm: string, returnedRecordCount: string, filterType?: string) {
    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', returnedRecordCount); // 'api/typeAhead/rep' replace url
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/contacts'), {params: params})
      .map((res: any[]) => {
        return res;
      });
  }

  public getTalentContactTypeahead(searchTerm: string, recordCount: string, filterType: string): Observable<TypeAheadModel[]> {
    let params = new HttpParams();
    params = params.append('searchTerm', searchTerm);
    params = params.append('recordCount', recordCount);
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('/api/typeAheadNames?filterType=' + filterType),
       {params: params})
      .map((res: TypeAheadModel[]) => {
        return res;
      });
  }

public updateLoanOutCompany(id: any, loanotCompany: any): any {
     return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/performers/' + id + '/loanoutCompanies'), loanotCompany)
       .map(res => {
         return res;
       });
 }

}
