import { TestBed, inject } from '@angular/core/testing';

import { DealsAndContractsService } from './deals-and-contracts.service';

describe('DealsAndContractsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DealsAndContractsService]
    });
  });

  it('should be created', inject([DealsAndContractsService], (service: DealsAndContractsService) => {
    expect(service).toBeTruthy();
  }));
});
