import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ColumnDefModel, GridPageOptionsModel, GridImageDefModel, GridImageParamsModel, GridLinkParamsModel, GridListDefModel, GridListParamsModel } from 'c2c-common-lib';

@Injectable()
export class DealsAndContractsService {

  constructor(private http: HttpClient) { }

  // TODO: Temporary until Deals and Contracts is ready for development.
  public getColumnDefs(): ColumnDefModel[] {
    return [
      new GridImageDefModel('Name', 'name',
        new GridImageParamsModel('talent.image', {
          keys: ['talent.firstName', 'talent.lastName'],
          routing: new GridLinkParamsModel('/talent', 'partyId', 'summary')
        }, 'talent.akaNames')
      ),
      new GridListDefModel('Projects', 'projectName',
        new GridListParamsModel({
          iterable: 'projects',
          keys: ['projectName']
        }, true)
      ),
      new ColumnDefModel('ID #', 'id'),
      new ColumnDefModel('Representative', 'representative'),
      new ColumnDefModel('Company', 'company'),
    ];
  }

  public getPageOptions() {
    return new GridPageOptionsModel(true, 'Default title', true, false, false, false, true);
  }

  public getAllDealsAndContracts() {
    return [
      { talent: { firstName: 'Leonardo', lastName: 'DiCaprio', akaNames: ['Leo DiCaprio'],
                  image: 'https://upload.wikimedia.org/wikipedia/commons/2/25/Leonardo_DiCaprio_2014.jpg' },
        projects: [
          { projectName: 'The Revenant' },
          { projectName: 'Live By Night' },
          { projectName: 'The Wolf of Wall Street' },
          { projectName: 'The Great Gatsby' },
          { projectName: 'Red Riding Hood' },
          { projectName: 'The Titanic' },
          { projectName: 'Inception' },
        ], id: '382654325', representative: 'Rick Yorn', company: 'LBI Entertainment', date: '1432252800000'
      },
      { talent: { firstName: 'Scott', lastName: 'Diggs (K)', akaNames: ['Taye Diggs', 'T Diggs'],
                  image: 'http://images2.fanpop.com/images/photos/2700000/Taye-Diggs-taye-diggs-2709366-1923-2560.jpg' },
        projects: [
          { projectName: 'Empire' },
          { projectName: 'Murder in the First' },
          { projectName: 'Opening Night' },
          { projectName: 'NCIS' },
          { projectName: 'Rosewood' }
        ], id: '123985467', representative: 'Tom Bradenton', company: 'GRC Creative', date: '1443352800000'
      },
      { talent: { firstName: 'Maggie', lastName: 'Gyllenhaal', akaNames: null,
                  image: 'http://amominredhighheels.com/wp-content/uploads/2008/07/maggie_gyllenhaal.jpg' },
        projects: [
          { projectName: 'The Deuce' },
          { projectName: '' },
          { projectName: 'Home' },
          { projectName: 'The New Empress' },
          { projectName: 'Beauty Mark' },
          { projectName: 'The Dark Knight' }
        ], id: '213526644', representative: 'Sam Tavitz', company: 'Gavern Entertainment', date: '1532252800000'
      },
      { talent: { firstName: 'Kirsten', lastName: 'Dunst', akaNames: null,
                  image: 'https://ia.media-imdb.com/images/M/MV5BMTQ3NzkwNzM1MV5BMl5BanBnXkFtZTgwMzE2MTQ3MjE@._V1_UY317_CR12,0,214,317_AL_.jpg' },
        projects: [
          { projectName: 'The Bell Jar' },
          { projectName: 'Midnight Special' },
          { projectName: 'Porlandia' },
          { projectName: 'Upside Down' },
          { projectName: 'Melancholia' },
          { projectName: 'Spider Man 1' },
          { projectName: 'Spider Man 2' },
          { projectName: 'Spider Man 3' }
        ], id: '527663987', representative: 'Alec Nimitz', company: 'GRC Creative', date: '1443352800000'
      },
      { talent: { firstName: 'Andy', lastName: 'Garcia', akaNames: ['Andrés Arturo García Menéndez'],
                  image: 'http://www.independent.org/images/bios_hirez/garcia_andy_700.jpg' },
        projects: [
          { projectName: 'What about Love' },
          { projectName: 'Max Steel' },
          { projectName: 'The Pink Panther 2' }
        ], id: '192933353', representative: 'Luke Ovitz', company: 'Creative Artists Agency', date: '1542152800000'
      }
    ];
  }
}
