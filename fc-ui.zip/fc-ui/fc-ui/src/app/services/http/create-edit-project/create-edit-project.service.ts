import { Injectable } from '@angular/core';
import { ProjectModel } from '../../../models/project/project.model';
import { HttpClient, HttpParams } from '@angular/common/http';
import { UrlResolverService } from 'c2c-common-lib';
import { stringToDateFormatter } from '../../../utils/formatter/string-to-date.format';
import * as moment from 'moment';

/**
 * The CreateEditProjectService
 *
 * Gets all of the data related to Creating/Editing a Project, and handles logic as needed.
 */
@Injectable()
export class CreateEditProjectService {

  /**
   * Constructor for the CreateEditProjectService
   *
   * @param http The HttpClient service.
   */
  constructor(private http: HttpClient, private urlResolverService: UrlResolverService) { }

  /**
   * Gets an existing project to be loaded into form for editing.
   *
   * @param id The id of the project to get.
   */

  public getProject(id: number) {
    return this.http.get(this.urlResolverService.getServiceEndpointUrl('api/project/') + id)
      .map((res: any) => {
        res.creationDate = res.creationDate != null ? stringToDateFormatter(res.creationDate) : null;
        res.startDate = res.startDate != null ? stringToDateFormatter(res.startDate) : null;
        res.wrapDate = res.wrapDate != null ? stringToDateFormatter(res.wrapDate) : null;
        res.releaseDate = res.releaseDate != null ? stringToDateFormatter(res.releaseDate) : null;
        return res;
      });
  }

  private updateProjectDates(project: ProjectModel): void {
    const format = 'YYYY-MM-DD';
    if (project.creationDate && moment(project.creationDate).isValid()) {
      project.creationDate = moment.parseZone(project.creationDate).format(format);
    } else {
      project.creationDate = null;
    }
    if (project.startDate && moment(project.startDate).isValid()) {
      project.startDate = moment.parseZone(project.startDate).format(format);
    } else {
      project.startDate = null;
    }
    if (project.releaseDate && moment(project.releaseDate).isValid()) {
      project.releaseDate = moment.parseZone(project.releaseDate).format(format);
    } else {
      project.releaseDate = null;
    }
    if (project.wrapDate && moment(project.wrapDate).isValid()) {
      project.wrapDate = moment.parseZone(project.wrapDate).format(format);
    } else {
      project.wrapDate = null;
    }
  }

  /**
   * Saves the project.
   *
   * @param project The project to be saved.
   */
  public saveProject(project: ProjectModel) {
    this.updateProjectDates(project);
    return this.http.post(this.urlResolverService.getServiceEndpointUrl('api/project/'), project)
      .map((res: any) => res);
  }

  /**
   * Updates the project.
   *
   * @param project The project to be updated.
   */
  public updateProject(project: ProjectModel) {
    this.updateProjectDates(project);
    return this.http.put(this.urlResolverService.getServiceEndpointUrl('api/project/'), project)
      .map((res: any) => res);
  }
}
