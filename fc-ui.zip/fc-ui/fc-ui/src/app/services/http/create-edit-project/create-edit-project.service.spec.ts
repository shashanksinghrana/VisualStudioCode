import { TestBed, inject } from '@angular/core/testing';

import { CreateEditProjectService } from './create-edit-project.service';

describe('CreateEditProjectService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateEditProjectService]
    });
  });

  it('should be created', inject([CreateEditProjectService], (service: CreateEditProjectService) => {
    expect(service).toBeTruthy();
  }));
});
