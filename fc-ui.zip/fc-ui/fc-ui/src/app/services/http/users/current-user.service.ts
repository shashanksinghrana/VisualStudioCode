import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';

import { UrlResolverService } from 'c2c-common-lib';
import { CurrentUser } from '../../../models/users/current-user.model';

@Injectable()
export class CurrentUserService {

  public user: string;

  constructor(private httpClient: HttpClient, private urlResolverService: UrlResolverService) { }
  /**
   * Get current user
   */
  public get(): Observable<CurrentUser> {
    const url = this.urlResolverService.getServiceEndpointUrl('/api/user');
    return this.httpClient.get<CurrentUser>(url).map((res) => {
      this.setUserData(res);
      return res;
    });
  }

  public setUserData(data) {
    this.user = data;
  }

}