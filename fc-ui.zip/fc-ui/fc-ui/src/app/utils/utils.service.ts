import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { UrlResolverService, DropdownModel } from 'c2c-common-lib';


@Injectable()
export class UtilsService {

  private _isDataResolved: boolean = false;
  public countryOptionsList: any[] = [];
  public dropdownOptionsList: any[] = [];
  public optionsList: any[] = [];


  constructor(private httpClient: HttpClient, private urlResolverService: UrlResolverService) { }

  private LIST_CONSTANT: any = {
    CONTACT_OCCUPATION: 'CONTACT_OCCUPATION', STAFF_LEVEL: 'COMPANY_OCCUPATION',
    CONTACT_TYPE: 'CONTACT_TYPE', COMPANY_TYPE: 'COMPANY_TYPE', SOCIAL_MEDIA: 'SOCIAL_MEDIA', PHONE_TYPE: 'PHONE_TYPE',
    STATES: 'countrystate/STATES/US', EMAIL: 'EMAIL', ADDRESS_TYPE: 'ADDRESS_TYPE',
    COUNTRIES: 'countrystate/COUNTRIES', COMPANY_ENTITY_TYPE: 'COMPANY_ENTITY_TYPE',
    CONTACT_ENTITY_TYPE: 'CONTACT_ENTITY_TYPE'
  };

  private setOptionsList(type, data) {
    this.optionsList[type] = data;
  }

  public getOptionsList(type) {
    return this.optionsList[type];
  }

  public isDataResolved(): boolean {
    return this._isDataResolved;
  }

  private setDropDownOptionsList(type, data) {
    this.dropdownOptionsList[type] = new DropdownModel(null, null, null, null, data);
  }

  public getDropDownOptionsList(type) {
    return this.dropdownOptionsList[type];
  }

  private setCountryOptionsList(type, data) {
    this.countryOptionsList[type] = new DropdownModel(null, null, null, null, data);
  }

  public getCountryOptionsList(type) {
    return this.countryOptionsList[type];
  }

  private getDropdownOptions(response, type): any {
    const options: any[] = [];
    const list = response.picklists;
    for (let i = 0; i < Object.keys(list).length; i++) {
      const item = list[i];
      const obj = { value: list[i].value, route: '', id: list[i].id, data: list[i] };
      if (type === this.LIST_CONSTANT.COUNTRIES) {
        obj['abbreviation'] = item['abbreviation'];
      }
      options.push(obj);
    }
    return options;
  }

  private getDropdownOptionsCountryState(response, type): any {
    let list: any;
    const options: any[] = [];
    if (type === 'countrystate/COUNTRIES') {
      list = response.countriesList;
    } else {
      list = response;
    }
    for (let i = 0; i < Object.keys(list).length; i++) {
      const item = list[i];
      const obj = { value: list[i].value, route: '', id: list[i].id, data: list[i] };
      if (type === this.LIST_CONSTANT.COUNTRIES) {
        obj['abbreviation'] = item['abbreviation'];
      }
      options.push(obj);
    }
    return options;
  }

  private setDropdowns(response, type) {
    let options = '';
    if (type === 'countrystate/COUNTRIES' || type === 'countrystate/STATES/US') {
      options = this.getDropdownOptionsCountryState(response, type);
    } else {
      options = this.getDropdownOptions(response, type);
    }
    this.setDropDownOptionsList(type, options);
  }

  private setOptions(response, type) {
    const options = this.getDropdownOptions(response, type);
    this.setOptionsList(type, options);
  }

  private setCountryOptions(response, type) {
    const options = this.getDropdownOptionsCountryState(response, type);
    this.setCountryOptionsList(type, options);
  }

  private picklistService(type: string): Observable<any> {
    const url = this.urlResolverService.getServiceEndpointUrl('/api/common/picklist/' + type);
    return this.httpClient.get(url);
  }

  private picklistServiceCountryState(type: string): Observable<any> {
    const url = this.urlResolverService.getServiceEndpointUrl('/api/rollcall/picklist/' + type);
    return this.httpClient.get(url);
  }


  public resolveAPIS(): Observable<any> {
    const staff_level = this.picklistService(this.LIST_CONSTANT.STAFF_LEVEL);
    const contact_type = this.picklistService(this.LIST_CONSTANT.CONTACT_TYPE);
    const company_type = this.picklistService(this.LIST_CONSTANT.COMPANY_TYPE);
    const social_media = this.picklistService(this.LIST_CONSTANT.SOCIAL_MEDIA);
    const phone_type = this.picklistService(this.LIST_CONSTANT.PHONE_TYPE);
    const states = this.picklistServiceCountryState(this.LIST_CONSTANT.STATES);
    const email = this.picklistService(this.LIST_CONSTANT.EMAIL);
    const address_type = this.picklistService(this.LIST_CONSTANT.ADDRESS_TYPE);
    const countries = this.picklistServiceCountryState(this.LIST_CONSTANT.COUNTRIES);
    const company_entity_type = this.picklistService(this.LIST_CONSTANT.COMPANY_ENTITY_TYPE);
    const contact_entity_type = this.picklistService(this.LIST_CONSTANT.CONTACT_ENTITY_TYPE);
    const contact_occupation = this.picklistService(this.LIST_CONSTANT.CONTACT_OCCUPATION);

    return new Observable(observer => {
      Observable.forkJoin([staff_level, contact_type, company_type, social_media, phone_type, states, email, address_type, countries,
        company_entity_type, contact_entity_type, contact_occupation]).
        subscribe(
          results => {
            this.setDropdowns(results[0], this.LIST_CONSTANT.STAFF_LEVEL);
            this.setDropdowns(results[1], this.LIST_CONSTANT.CONTACT_TYPE);
            this.setDropdowns(results[2], this.LIST_CONSTANT.COMPANY_TYPE);
            this.setDropdowns(results[3], this.LIST_CONSTANT.SOCIAL_MEDIA);
            this.setDropdowns(results[4], this.LIST_CONSTANT.PHONE_TYPE);
            this.setDropdowns(results[5], this.LIST_CONSTANT.STATES);
            this.setDropdowns(results[6], this.LIST_CONSTANT.EMAIL);
            this.setDropdowns(results[7], this.LIST_CONSTANT.ADDRESS_TYPE);
            this.setCountryOptions(results[8], this.LIST_CONSTANT.COUNTRIES);
            this.setOptions(results[9], this.LIST_CONSTANT.COMPANY_ENTITY_TYPE);
            this.setOptions(results[10], this.LIST_CONSTANT.CONTACT_ENTITY_TYPE);
            this.setDropdowns(results[11], this.LIST_CONSTANT.CONTACT_OCCUPATION);
            this._isDataResolved = true;
            observer.next(true);
            observer.complete();
          });
    });
  }
  
  public getIdByProperty(array:any[], prop:string, value: string){
    if(array){
      return array.find(item => (item[prop] === value)).id;
    }
  }
}
