export function performerNameFormatter(first: string, last: string, displayName?: string) {
  let name = '';
  if (first) {
    name += first;
  }
  if (last) {
    name += ' ' + last;
  }
  if (displayName) {
    name = displayName;
  }
  return name.trim();
}
