export function stringToDateFormatter(stringDate) {
  return new Date(stringDate + 'T00:00:01');
}
