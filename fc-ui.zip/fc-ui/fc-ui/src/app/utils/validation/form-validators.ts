import { ValidatorFn, AbstractControl, FormGroup } from '@angular/forms';

/**
 * The FormValidators
 *
 * Class for defining custom form validators for use in Reactive forms.
 */
export class FormValidators {

  // TODO: This is not used any more and is just an example
  public static validateFeeType(feeTypeForm: FormGroup): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      const form = control.parent;

      if (form && form.controls) {
        if (form.touched) {
          return Object.keys(form.controls).length > 2 ? null : {'noFeesAttached': {value: control.value}};
        } else {
          return {'noFeesAttached': {value: control.value}};
        }
      }
    };
  }

  public static validateModelValue(field: string): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      if (control.value[field] === null || control.value[field] === undefined) {
        return {'noModelValue': {value: control.value[field]}};
      } else {
        return null;
      }
    };
  }
}
