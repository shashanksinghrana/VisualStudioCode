import { Component, Input, OnInit, ViewChild, HostListener, AfterViewInit } from '@angular/core';
import { SidebarModel, ToasterService, ModalGenericComponent} from 'c2c-common-lib';
import { SidebarService } from './services/sidebar/sidebar.service';
import { environment } from '../environments/environment';
import { LoadingIndicatorService } from './services/other/loading-indicator.service';
import { CurrentUserService } from './services/http/users/current-user.service';
import { CurrentUserName } from './models/users/current-user-name.model';
import { NavigationItemsService } from './services/other/navigation-items.service';
import { CurrentUserPersistService } from './services/persist/user/current-user-persist.service';
import { UserPermissionService } from './services/http/permission/user-permission.service';
import { ComponentSource } from 'ag-grid/dist/lib/components/framework/componentResolver';
import { SessionService } from './services/other/session.service';
import { Subscription } from 'rxjs';
import { AutoLogoutService } from './services/other/autoLogout.service';

@Component({
  selector: 'fc-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [SidebarService, NavigationItemsService]
})
export class AppComponent implements OnInit, AfterViewInit {
  @ViewChild('logoutModal') public logoutModal: ModalGenericComponent;
  public appLoading: boolean = false;
  public authority: any = [];
  public currentUserName: string;
  public moduleLink: string = '#';
  public modulePrefix: string = environment.context;
  public navigationServ: any;
  public navLinks: Array<SidebarModel> = [];
  public sidebarCollapsed: boolean = false;
  public Date: any;
  public subscription: Subscription = new Subscription();
  public openModal: boolean;
  public sessionId: any;
  public pluginStart: boolean = true;

  constructor(private sidebarService: SidebarService,
              private navigationService: NavigationItemsService,
              private currentUserService: CurrentUserService,
              private loadingService: LoadingIndicatorService,
              private toasterService: ToasterService,
              private currentUserPersistService: CurrentUserPersistService,
              private userPermissionService: UserPermissionService,
              private sessionService: SessionService,
              private autoLogoutService: AutoLogoutService
            ) {
    this.loadingService.onLoadingChanged.subscribe(
      (isLoading) => {
        this.appLoading = isLoading;
      }
    );
    this.Date = new Date().getTime();
    localStorage.setItem('LAST_REQUEST_SENT_TIMESTAMP', this.Date);
  }

  @HostListener('document:click', ['$event'])
  public clickout(event) {
    const currentTimeStamp: any = new Date().getTime();
    localStorage.setItem('LAST_REQUEST_SENT_TIMESTAMP', currentTimeStamp);
  }
  private getCurrentUser(): void {
    this.currentUserService.get()
    .subscribe(
      res => {
        this.currentUserPersistService.setCurrentUser(res);
        this.sidebarService.setNavItems();
        this.currentUserName = new CurrentUserName(res.firstName, res.lastName, '', '', '').getCurrentUserName();
        this.userPermissionService.setPermissions(res);
        this.navLinks = this.sidebarService.getNavItems();
      },
      err => console.error(`Server error: ${err.status} - Details: ${err.error}`),
      () => console.log('complete')
    );
  }

  /**Angular life cycle hook */
  public ngOnInit(): void {
    this.getCurrentUser();
    this.navigationServ = this.navigationService;
    this.subscription.add(this.sessionService.isModalOpen.subscribe(response => {
      this.openModal = response;
      if (this.openModal === true) {
        this.logoutModal.open();
        setInterval(() => {
          sessionStorage.removeItem('NAV_BAR_HISTORY');
          window.location.href = './saml/logout';
        }, 5000);
      }
    }));
    this.sessionId = setInterval(() => {
      this.autoLogoutService.checkTimeStamp();
    }, 5000);
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.pluginStart = false;
    });
  }

  public ngOnDestroy(): void {
    if (this.sessionId) {
      clearInterval(this.sessionId);
    }
  }
  }



