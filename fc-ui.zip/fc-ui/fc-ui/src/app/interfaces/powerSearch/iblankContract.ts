export interface IblankContract {
    address:any;
    contractType:any;
    production:Object;
    signatories:Object;
    title:any;
    
    
}
