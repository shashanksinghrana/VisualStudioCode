export interface IAuthority {
  authority: string;
}
