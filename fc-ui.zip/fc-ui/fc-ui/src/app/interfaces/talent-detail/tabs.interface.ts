export interface tabs {
    label?: any;
    route?: any;

   }