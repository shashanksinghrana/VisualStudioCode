export interface ICurrentUserName {
  firstName: string;
  lastname: string;
}
