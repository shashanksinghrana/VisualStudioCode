export interface ICurrentUser {
  accountNonExpired: boolean;
  accountNonLocked: boolean;
  authorities: Array<object>;
  credentialsNonExpired: boolean;
  endabled: boolean;
  firstName: string;
  lastName: string;
  password: string;
  role: string;
  username: string;
  studioId: string;
  view: string;
  masterDataset: string;

}
