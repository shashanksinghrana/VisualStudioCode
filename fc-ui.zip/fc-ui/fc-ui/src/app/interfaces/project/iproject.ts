export interface IProject {
    akaNames: Array<any>;
    creationDate: any;
    id: number;
    note: Array<any>;
    castingCompanySet: Array<any>;
    title: Object;
    releaseDate: any;
    sagProdId: number;
    sapCode: string;
    startDate: any;
    projectStatusId: number;
    studio: any;
    projectTypeId: number;
    wrapDate: any;
    assignToUserId: string;
}
