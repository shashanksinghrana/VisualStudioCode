import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UtilsService } from './utils/utils.service';
import { Injectable } from '@angular/core';

@Injectable()
export class AppResolver implements Resolve<any> {
    constructor(private utilService: UtilsService) { }
    public resolve() {
        if (!this.utilService.isDataResolved()) {
            return this.utilService.resolveAPIS().catch(() => {
                return Observable.of('API resolved');
            });
        } else {
            return Observable.of('API already resolved');
        }
    }
}