
import { IblankContract } from '../../interfaces/powerSearch/iblankContract';

export class BlankContractModel implements IblankContract {
    address:any;
    contractType:Object;
    production:Object;
    signatories:Object;
    title:Object;
    dailyRate:any
    // akaNames: Array<any>;
    // creationDate: any;
    // id: number;
    // note: Array<any>;
    // castingCompanySet: Array<any>;
    // title: Object;
    // releaseDate: any;
    // sagProdId: number;
    // sapCode: string;
    // startDate: any;
    // projectStatusId: number;
    // studio: any;
    // projectTypeId: number;
    // wrapDate: any;
    // assignToUserId: string;
    // createdByApp: string;

    constructor(
        address?:any,
        contractType?:any,
        production?:any,
        signatories?:any,
        title?:any,
     
       
    ) {
        this.address=address
        this.contractType=contractType
        this.production=production
        this.signatories=signatories
        this.title=title

    }
}
