
import { tabs } from '../../interfaces/talent-detail/tabs.interface';

export class TabsModel implements tabs {
  public label: any;
  public route: any;
}
