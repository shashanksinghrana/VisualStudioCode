export class PerqsTypeTwoModel {
    public perqsTermTwo: string = "defaullt perq type text";
    public perqsTermTwoNote: string = "defaullt perq type notes";
    public perqsPaidAdChek : boolean = false;
  
    constructor(
        perqsTermTwo: string,
        perqsPaidAdChek : boolean,
        perqsTermTwoNote: string
    ) {
      this.perqsTermTwo = perqsTermTwo;
      this.perqsPaidAdChek = perqsPaidAdChek;
      this.perqsTermTwoNote = perqsTermTwoNote;
    }
}