import { RepSetModel } from "./rep-set.model";
import { DirectContactModel } from "./direct-contact.model";

export class NoticesPaymentsModel {
  public representators: RepSetModel;
  public directContact: DirectContactModel;

  constructor(
    representators: RepSetModel,
    directContact: DirectContactModel
  ) {
    this.representators = representators;
    this.directContact = directContact;
  }
}
