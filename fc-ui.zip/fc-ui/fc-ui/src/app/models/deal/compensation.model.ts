/**
 * The CompensationModel
 */
export class CompensationModel {
    public dealId: number;
    public guaranteeNumber: number;
    public guaranteeType: string;
    public feeTypeId: number;
    public rate: string;
    public descript: string;
    public startDate: string;
    public periodId: number;
    public interval: number;
    public contractReturnedDate: string;
    public contractRevisiedDate: string;
    public contractSentDate: string;
    public contractText: string;
    public contractInfo: string;
    public totalAmount: number;
    public voidFlag: string;
    public principalFree: string;
    public principalFreeInterval: string;
    public postFree: string;
    public postFreeInterval: string;
    public adjustmentInterval: string;
    public startDateQualifierId: string;
    public id: number;
  
    constructor(
        dealId?: number,
        guaranteeNumber?: number,
        guaranteeType?: string,
        feeTypeId?: number,
        rate?: string,
        descript?: string,
        startDate?: string,
        periodId?: number,
        interval?: number,
        contractReturnedDate?: string,
        contractRevisiedDate?: string,
        contractSentDate?: string,
        contractText?: string,
        contractInfo?: string,
        totalAmount?: number,
        voidFlag?: string,
        principalFree?: string,
        principalFreeInterval?: string,
        postFree?: string,
        postFreeInterval?: string,
        adjustmentInterval?: string,
        startDateQualifierId?: string,
        id?: number
    ) {
      this.dealId = dealId;
      this.guaranteeNumber = guaranteeNumber;
      this.guaranteeType = guaranteeType;
      this.feeTypeId = feeTypeId;
      this.rate = rate;
      this.id = id;
      this.descript = descript;
      this.startDate = startDate;
      this.periodId = periodId;
      this.startDate = startDate;
      this.interval = interval;
      this.contractReturnedDate = contractReturnedDate;
      this.contractRevisiedDate = contractRevisiedDate;
      this.contractSentDate = contractSentDate;
      this.contractText = contractText;
      this.contractInfo = contractInfo;
      this.totalAmount = totalAmount;
      this.voidFlag = voidFlag,
      this.principalFree = principalFree,
      this.principalFreeInterval = principalFreeInterval,
      this.postFree = postFree,
      this.postFreeInterval = postFreeInterval,
      this.adjustmentInterval = adjustmentInterval,
      this.startDateQualifierId = startDateQualifierId,
      this.id = id
    }
  }
  