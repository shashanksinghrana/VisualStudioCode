export class RepAddressModel {
  public addressId: string;
  public locationName: string;
  public addressType: string;
  public firstLine: string;
  public secondLine: string;
  public thirdLine: string;
  public city: string;
  public state: string;
  public zip: string;
  public country: string;

  constructor(
    addressId: string,
    locationName: string,
    addressType: string,
    firstLine: string,
    secondLine: string,
    thirdLine: string,
    city: string,
    state: string,
    zip: string,
    country: string
  ) {
    this.addressId = addressId;
    this.locationName = locationName;
    this.addressType = addressType;
    this.firstLine = firstLine;
    this.secondLine = secondLine;
    this.thirdLine = thirdLine;
    this.city = city;
    this.state = state;
    this.zip = zip;
    this.country = country;
  }
}
