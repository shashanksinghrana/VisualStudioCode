export class CreditSetModel {
  public mainEndTitle: string = "defaullt title";
  public card: string = "defaullt card";
  public position: string = "defaullt position";

  constructor(
    mainEndTitle: string,
    card: string,
    position: string
  ) {
    this.mainEndTitle = mainEndTitle;
    this.card = card;
    this.position = position;
    }
}
