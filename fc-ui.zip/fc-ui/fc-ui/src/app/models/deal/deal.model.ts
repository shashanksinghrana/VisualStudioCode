import { ProjectModel } from '../project/project.model';
import { PerformerModel } from './performer.model';
import { LookupModel } from '../shared/lookup.model';
import { ProductionCompanyModel } from './productionCompany.model';

export class DealModel {
  public dealDate: any;
  public i9StatusNote: string;
  public id: number;
  public lead: boolean; // String?
  public loanoutId: number;
  public noQuoteDeal: boolean; // String?
  public performer: PerformerModel;
  public performerINineStatus: LookupModel;
  public performerNote: string;
  public performerRole: string;
  public performerRoleNumber: number;
  public productionCompany: ProductionCompanyModel;
  public project: ProjectModel;
  public sagStatusLookup: LookupModel;
  public sagStatusNote: string;
  public unionLookup: LookupModel;
  public updateBy: string;
  public updateDate: any;
  public contractExist: boolean;
  public loanoutIdVer: number;

  constructor(
      dealDate: any,
      performer: PerformerModel,
      project: ProjectModel,
      i9StatusNote?: string,
      id?: number,
      lead?: boolean,
      loanoutId?: number,
      noQuoteDeal?: boolean,
      performerINineStatus?: LookupModel,
      performerNote?: string,
      performerRole?: string,
      performerRoleNumber?: number,
      productionCompany?: ProductionCompanyModel,
      sagStatusLookup?: LookupModel,
      sagStatusNote?: string,
      unionLookup?: LookupModel,
      updateBy?: string,
      updateDate?: any,
      contractExist?: boolean,
      loanoutIdVer?: number
  ) {
    this.dealDate = dealDate;
    this.performer = performer;
    this.project = project;
    this.i9StatusNote = i9StatusNote;
    this.id = id;
    this.lead = lead;
    this.loanoutId = loanoutId;
    this.noQuoteDeal = noQuoteDeal;
    this.performerINineStatus = performerINineStatus;
    this.performerNote = performerNote;
    this.performerRole = performerRole;
    this.performerRoleNumber = performerRoleNumber;
    this.productionCompany = productionCompany;
    this.sagStatusLookup = sagStatusLookup;
    this.sagStatusNote = sagStatusNote;
    this.unionLookup = unionLookup;
    this.updateBy = updateBy;
    this.updateDate = updateDate;
    this.contractExist = contractExist;
    this.loanoutIdVer = loanoutIdVer;
  }
}
