import { CreditSetModel } from "./credit-set.model";
import { BillingSetModel } from "./billing-set.model";

export class CreditModel {
  public creditedName: String;
  public creditDetail: CreditSetModel;
  public creditBilling: BillingSetModel;

  constructor(
    creditedName: String,
    creditDetail: CreditSetModel,
    creditBilling: BillingSetModel
  ) {
    this.creditedName = creditedName;
    this.creditDetail = creditDetail;
    this.creditBilling = creditBilling;
  }
}
