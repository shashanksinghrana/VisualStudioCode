import { perqs } from "./perqs-type-one.model";

export class PerqsModel {
  public perqs: perqs;

  constructor(
    perqs : perqs
  ) {
    this.perqs = perqs;
  }
}