export class RepContactModel {
  public id: string;
  public contactId: string;
  public value: string;
  public primary: boolean;
  public typeId: string;
  public type: string;
  public displayValue: string;

  constructor(
    id: string,
    contactId: string,
    value: string,
    primary: boolean,
    typeId: string,
    type: string,
    displayValue: string
  ) {
    this.id = id;
    this.contactId = contactId;
    this.value = value;
    this.primary = primary;
    this.typeId = typeId;
    this.type = type;
    this.displayValue = displayValue;
  }
}
