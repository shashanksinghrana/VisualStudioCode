export class LoanoutModel {
  public relationID: number;
  public dealId: number;
  public partyID: number;
  public stateID: number;
  public countryID: number;
  public ein: number ;
  public loanoutComp: string;
  public primary: boolean;
  public talent_partyID: number

  constructor(
    dealId: number,
    relationID: number,
    partyID: number,
    stateID: number,
    countryID: number,
    ein: number,
    loanoutComp:string,
    primary: boolean,
    talent_partyID: number
  ) {
    this.dealId = dealId;
    this.relationID = relationID;
    this.partyID = partyID;
    this.stateID = stateID;
    this.countryID = countryID;
    this.loanoutComp = loanoutComp;
    this.ein = ein;
    this.primary = primary;
    this.talent_partyID = talent_partyID;
    }
    
}
