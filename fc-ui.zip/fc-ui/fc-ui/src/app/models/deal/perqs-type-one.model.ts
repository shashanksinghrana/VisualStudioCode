export class perqs {
    public perqsTermVal: string = "defaullt perq type text";
    public perqText: string = "defaullt perq type notes";
    public paidAdInd : boolean = false;
  
    constructor(
        perqsTermVal: string,
        perqText: string,
        paidAdInd : boolean
    ) {
      this.perqsTermVal = perqsTermVal;
      this.perqText = perqText;
      this.paidAdInd = paidAdInd;
    }
}

