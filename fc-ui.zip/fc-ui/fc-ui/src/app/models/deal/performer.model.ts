export class PerformerModel {
  public agencyList: Array<string>;
  public firstName: string;
  public gender: string;
  public lastName: string;
  public middleName: string;
  public minor: boolean;
  public partyId: number;
  public typeAheadDisplayName: string;
  public partyType: string;
  public akaId: string;

  constructor(
      agencyList?: Array<string>,
      firstName?: string,
      gender?: string,
      lastName?: string,
      middleName?: string,
      minor?: boolean,
      partyId?: number,
      typeAheadDisplayName?: string
    ) {
    this.agencyList = agencyList;
    this.firstName = firstName;
    this.gender = gender;
    this.lastName = lastName;
    this.middleName = middleName;
    this.minor = minor;
    this.partyId = partyId;
    this.typeAheadDisplayName = typeAheadDisplayName;
    }
}
