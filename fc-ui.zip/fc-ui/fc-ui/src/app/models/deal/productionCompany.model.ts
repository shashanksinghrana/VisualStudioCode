export class ProductionCompanyModel {
  public entityName: string;
  public agency : string;
  public akaId : number;
  public firstName : string;
  public partyId : number;
  public partyType : string;
  public typeAheadDisplayName : string;
  public primaryName : string;
  public ssnEndChars : string;
  public teamMembers : string;
  
  constructor(
    entityName?: string,
    agency? : string,
    akaId? : number,
    firstName? : string,
    partyId? : number,
    partyType? : string,
    typeAheadDisplayName? : string,
    teamMembers? : string,
    ssnEndChars? : string,
    primaryName? : string

  ) {
    this.entityName = entityName;
    this.agency = agency;
    this.akaId = akaId;
    this.firstName = firstName;
    this.partyId = partyId;
    this.partyType = partyType;
    this.typeAheadDisplayName = typeAheadDisplayName;
    this.teamMembers = teamMembers;
    this.ssnEndChars = ssnEndChars;
    this.primaryName = primaryName;
  }
}