export class BillingSetModel {
  public billingText: string = "defaullt billing text";
  public billingNotes: string = "defaullt billing notes";

  constructor(
    billingText: string,
    billingNotes: string
  ) {
    this.billingText = billingText;
    this.billingNotes = billingNotes;
  }
}
