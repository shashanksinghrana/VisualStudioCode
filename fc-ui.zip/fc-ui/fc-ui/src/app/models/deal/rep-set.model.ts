import { RepAddressModel } from "./rep-address.model";
import { RepContactModel } from "./rep-contact.model";

export class RepSetModel {
  public repName: string;
  public repType: string;
  public companyName: string;
  public repAddress: RepAddressModel;
  public contactInfo: RepContactModel;
  public contractAddress: boolean;
  public primaryRep: boolean;  
  public phoneOnContract: boolean;

  constructor(
    repName: string,
    repType: string,
    companyName: string,
    repAddress: RepAddressModel,
    contactInfo: RepContactModel,
    contractAddress: boolean,
    primaryRep: boolean,    
    phoneOnContract: boolean
  ) {
    this.repName = repName;
    this.repType = repType;
    this.companyName = companyName;
    this.repAddress = repAddress;
    this.contactInfo = contactInfo;
    this.primaryRep = primaryRep;
    this.phoneOnContract = phoneOnContract;
  }
}
