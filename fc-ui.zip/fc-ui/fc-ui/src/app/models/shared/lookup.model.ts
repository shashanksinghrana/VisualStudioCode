export class LookupModel {
  public displayOrder: number;
  public id: number;
  public name: string;
  public type: string;
  public checked?: boolean;

  constructor(
    displayOrder?: number,
    id?: number,
    name?: string,
    type?: string,
    checked?: boolean,
  ) {
    this.displayOrder = displayOrder;
    this.id = id;
    this.name = name;
    this.type = type;
    this.checked = checked;
  }
}
