/**
 * The ProjectDetailModel
 */
export class ProjectDetailModel {
  public akaNames: Array<Object>;
  public assignedToUserId: string;
  public castingCompanySet: Array<Object>;
  public createDate: string;
  public createdBy: string;
  public id: number;
  public note: string;
  public releaseDate: string;
  public sapCode: string;
  public startDate: string;
  public status: string;
  public studio: Object;
  public title: Object;
  public type: string;
  public updateDate: string;
  public updatedBy: string;
  public wrapDate: string;

  constructor(
    akaNames: Array<Object>,
    assignedToUserId: string,
    castingCompanySet: Array<Object>,
    createDate: string,
    createdBy: string,
    id: number,
    note: string,
    releaseDate: string,
    sapCode: string,
    startDate: string,
    status: string,
    studio: Object,
    title: Object,
    type: string,
    updateDate: string,
    updatedBy: string,
    wrapDate: string
  ) {
    this.akaNames = akaNames;
    this.assignedToUserId = assignedToUserId;
    this.castingCompanySet = castingCompanySet;
    this.createDate = createDate;
    this.createdBy = createdBy;
    this.id = id;
    this.note = note;
    this.releaseDate = releaseDate;
    this.sapCode = sapCode;
    this.startDate = startDate;
    this.status = status;
    this.studio = studio;
    this.title = title;
    this.type = type;
    this.updateDate = updateDate;
    this.updatedBy = updatedBy;
    this.wrapDate = wrapDate;
  }
}
