export class ProjectTitleModel {
  public aka: string;
  public projectId: number;
  public projectTitleId: number;
  public title: string;

  constructor(
      aka?: string,
      projectId?: number,
      projectTitleId?: number,
      title?: string
  ) {
    this.aka = aka;
    this.projectId = projectId;
    this.projectTitleId = projectTitleId;
    this.title = title;
  }
}
