import { IProject } from '../../interfaces/project/iproject';

export class ProjectModel implements IProject {
    akaNames: Array<any>;
    creationDate: any;
    id: number;
    note: Array<any>;
    castingCompanySet: Array<any>;
    title: Object;
    releaseDate: any;
    sagProdId: number;
    sapCode: string;
    startDate: any;
    projectStatusId: number;
    studio: any;
    projectTypeId: number;
    wrapDate: any;
    assignToUserId: string;
    createdByApp: string;

    constructor(
        akaNames?: Array<any>,
        creationDate?: any,
        id?: number,
        note?: Array<any>,
        castingCompanySet?: Array<any>,
        title?: Object,
        releaseDate?: any,
        sagProdId?: number,
        sapCode?: string,
        startDate?: any,
        projectStatusId?: number,
        studio?: any,
        projectTypeId?: number,
        wrapDate?: any,
        assignToUserId?: string
    ) {
        this.akaNames = akaNames;
        this.creationDate = creationDate;
        this.id = id;
        this.note = note;
        this.castingCompanySet = castingCompanySet;
        this.title = title;
        this.releaseDate = releaseDate;
        this.sagProdId = sagProdId;
        this.sapCode = sapCode;
        this.startDate = startDate;
        this.projectStatusId = projectStatusId;
        this.studio = studio;
        this.projectTypeId = projectTypeId;
        this.wrapDate = wrapDate;
        this.assignToUserId = assignToUserId;
    }
}
