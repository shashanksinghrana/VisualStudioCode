import { IAuthority } from '../interfaces/iauthority.interface';

export class Authority implements IAuthority {
  public authority: string;
}
