import { ICurrentUser } from '../../interfaces/users/icurrent-user.interface';
import { Authority } from '../authoritiy.model';

export class CurrentUser implements ICurrentUser {
  public accountNonExpired: boolean;
  public accountNonLocked: boolean;
  public authorities: Array<Authority>;
  public credentialsNonExpired: boolean;
  public endabled: boolean;
  public firstName: string;
  public lastName: string;
  public password: string;
  public role: string;
  public username: string;
  public studioId: string;
  public view: string;
  public masterDataset: string;
}
