import { ICurrentUserName } from '../../interfaces/users/icurrent-user-name.interface';

export class CurrentUserName implements ICurrentUserName {

  constructor(public firstName: string, public lastname: string, public role: string, public view: string,public masterDataset: any) {
    this.firstName = firstName;
    this.lastname = lastname;
    this.role = role;
    this.view = view;
    this.masterDataset = masterDataset;
  }

  public getCurrentUserName(): string {
    return this.firstName + ' ' + this.lastname;
  }

  public getUserRole(): string {
    return this.role;
  }

  public getUserView(): string {
    return this.view;
  }

  public getDataSet(): any {
    return this.masterDataset;
  }

}
