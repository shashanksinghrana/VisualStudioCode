export class CompensationModel {
    feeType: {};
    rate: number;
    startDate: Date;
    startDateAccuracy: string;
    adjustmentInterval: number;
    interval: string;
    principalFree: number;
    principalFreeInterval: string;
    postFree: number;
    postFreeInterval: string;
    contractInfo: string;
    totalAmount: number;
    contracts: {}[];

    constructor (
        feeType: {},
        rate: number,
        startDate: Date,
        startDateAccuracy: string,
        adjustmentInterval: number,
        interval: string,
        principalFree: number,
        principalFreeInterval: string,
        postFree: number,
        postFreeInterval: string,
        contractInfo: string,
        totalAmount: number,
        contracts: {}[]
    ) {
        this.feeType = feeType;
        this.rate = rate;
        this.startDate = startDate;
        this.startDateAccuracy = startDateAccuracy;
        this.adjustmentInterval = adjustmentInterval;
        this.interval = interval;
        this.principalFree = principalFree;
        this.principalFreeInterval = principalFreeInterval;
        this.postFree = postFree;
        this.postFreeInterval = postFreeInterval;
        this.contractInfo = contractInfo;
        this.totalAmount = totalAmount;
        this.contracts = contracts;
    }
}