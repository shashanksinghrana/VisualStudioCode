const PROXY_CONFIG = [{
  context: [
    "/api",
    "/api/allProjects",
    "/api/compensations",
    "/api/credit",
    "/api/deal/",
    "/api/formulas",
    "/api/lookup/type",
    "/api/performer",
    "/api/performerDeal",
    "/api/performerDeals",
    "/api/perqs",
    "/api/project",
    "/api/projectDetails",
    "/api/rep",
    "/api/rep/add",
    "/api/generic/lookup",
    "/api/companies",
    "/api/typeAhead/performers",
    "/api/typeAhead/productionCompanies",
    "/api/typeAhead/projectTitles",
    "/api/powersearch",
    "/api/contacts",
    "/api/wizards",
    "/api/wizard",
    "/api/projects",
    "/typeAheadNames",
    "/api/powersearch/queries",
	"/addAlias"
  ],

  "target": "http://localhost:8084/fc/",
  "secure": false
}]

module.exports = PROXY_CONFIG;
// "target": "http://dev.concept2alize.com/wb-reg/fc/",
// "target": "http://dev.concept2alize.com/fc/dev1/fc",
// "target": "http://localhost:8084/fc/",
